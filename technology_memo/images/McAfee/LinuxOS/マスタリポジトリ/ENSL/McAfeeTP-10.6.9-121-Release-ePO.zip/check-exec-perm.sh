#!/bin/sh
# Copyright (C) 2019 McAfee, LLC. All Rights Reserved.

# This script will be called by detection McS script to check execute permission
exit 0
