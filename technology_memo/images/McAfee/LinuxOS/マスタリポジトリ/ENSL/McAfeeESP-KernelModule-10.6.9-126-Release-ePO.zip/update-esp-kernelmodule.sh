#!/bin/bash
# Copyright (C) 2019 McAfee, LLC. All Rights Reserved.
# Script to extract validate if ESP installation / upgrade can be done.
# It also works for HF packages

# Exit codes during dry run of this script are
# 0 - Upgrade is possible for at least one kernel module on this system
# 1 - Upgrade is not possible for either Kernel Module on this system.
#     This can happen if same or a higher version of both kernel modules is already installed
# Exit codes on failure in normal execution of this script are
# 1 - This script can be run by bash shell only.
# 2 - Invalid command line option passed during installation.
# 5 - Must be a root user to run this script.
# 7 - Installation file is missing.
# 8 - Installation RPM or DEB file is missing.
# 9 - Installation failed.
# 10 - Failed to extract downloaded installation file.
# 16 - Installation conflicts with existing TP installation.
# 0 - Installation was successful
# NOTE: Exit codes are kept uniform for all installation and uninstallation scripts

# Use only bash for executing the script
ps -o args= -p "$$" | grep bash > /dev/null

# Unset all the language locale and set LANG to C to disable localization
unset LC_ALL
unset LANG
export LANG=C
export LC_ALL=C

if [ $? -ne 0 ]
then
    echo "Error: This script can be run by bash shell only"
    echo "Usage: $0 [dryrun]"
    echo "dryrun is a keyword that can be used to test if ESP Kernel Modules can be installed"
    exit 1
fi

#unset the LD_LIBRARY_PATH
unset LD_LIBRARY_PATH

usage()
{
    echo "Usage: $0 [dryrun]"
    echo "dryrun is a keyword that can be used to test if ESP Kernel Modules can be installed"
    exit 2
}

# Echo's the message on the console as well as logs the message in syslog file
logMessage()
{
    message=$1
    echo "${message}"
    logger -t ${me} "${message}"
}

# Compares two product versions a and b and return its value. Both should be in 10.2.2.1105 format
# Returns 1 for more (a > b), 2 for less (a < b) and 0 for equal version (a == b)
vercomp () {
    if [[ $1 == $2 ]]
    then
        return 0
    fi
    a=$1
    b=$2
    a=$(echo ${a}| sed 's/-/./')
    b=$(echo ${b} | sed 's/-/./')
    local IFS=.
    local i ver1=($a) ver2=($b)
    # fill empty fields in ver1 with zeros
    for ((i=${#ver1[@]}; i<${#ver2[@]}; i++))
    do
        ver1[i]=0
    done
    for ((i=0; i<${#ver1[@]}; i++))
    do
        if [[ -z ${ver2[i]} ]]
        then
            # fill empty fields in ver2 with zeros
            ver2[i]=0
        fi
        if ((10#${ver1[i]} > 10#${ver2[i]}))
        then
            return 1
        fi
        if ((10#${ver1[i]} < 10#${ver2[i]}))
        then
            return 2
        fi
    done
    return 0
}

# Common method to get the version of a product installed
# First argument is the name of the product whose version is required. The letters case of the product name
# should be that of rpm as rpm is case sensitive whereas dpkg command is case insensitive.
# Uses echo to return the installed product version in the format: 10.6.6.102 which caller should save
getInstalledProductVersion()
{
    productName=$1
    if [ ${DEB_VARIANT} = "yes" ]
    then
        installedProductVersion=$(dpkg -s ${productName} | grep ^Version | awk -F ': ' '{print $2}')
    else
        installedProductVersion=$(rpm -q --queryformat "%{VERSION}.%{RELEASE}\n" ${productName})
    fi
    echo ${installedProductVersion}
}

# This method accepts
# $1 - Name of the product
# $2 - Version of the product that is currently available
# This method returns-
# 0- when no upgrade is required or when the product is not installed and fresh install is not supported.
# 1- when version installed in this system is older than available version
getInstallTypeRPM()
{
    productName=$1
    availableProductVersionString=$2
    installedProductVersionString=$(rpm -q --queryformat "%{VERSION}.%{RELEASE}\n" ${productName})
    if [ $? -ne 0 ]
    then
        logMessage "Installing ${productName} is not supported as it is currently not installed and this script only supports upgrade"
        return 0
    fi
    logMessage "${productName} installed in this system is - ${installedProductVersionString}"
    availableProductVersionString=$(echo ${availableProductVersionString} | sed 's/\(.*\)-/\1./')
    vercomp ${availableProductVersionString} ${installedProductVersionString}
    upgradeType=$?
    if [ ${upgradeType} -eq 1 ]
    then
        logMessage "${productName} is an upgrade candidate, since version installed in this system is ${installedProductVersionString}, which is older than available version ${availableProductVersionString}"
        return 1
    elif [ ${upgradeType} -eq 2 ]
    then
        logMessage "Not upgrading ${productName} since version installed in this system is ${installedProductVersionString}, which is newer than available version ${availableProductVersionString}"
        return 0
    elif [ ${upgradeType} -eq 0 ]
    then
        logMessage "Not upgrading ${productName} since version installed in this system is ${installedProductVersionString}, is same as available version ${availableProductVersionString}"
        return 0
    fi
}

# This method accepts
# $1 - Name of the product
# $2 - Version of the product that is currently available
# This method returns-
# 0- when no upgrade is required or when the product is not installed and fresh install is not supported.
# 1- when version installed in this system is older than available version
getInstallTypeDEB()
{
    productName=$1
    availableProductVersionString=$2
    minSupportedProductVersionString=$3
    installedProductVersionString=$(dpkg -s ${productName} 2>/dev/null | grep ^Version | awk -F ': ' '{print $2}')
    if [ -z ${installedProductVersionString} ]
    then
        logMessage "Installing ${productName} is not supported as it is currently not installed and this script only supports upgrade"
        return 0
    else
        logMessage "${productName} installed in this system is - ${installedProductVersionString}"
        dpkg --compare-versions "${availableProductVersionString}" gt "${installedProductVersionString}"
        if [ $? -eq 0 ]
        then
            logMessage "${productName} is an upgrade candidate, since version installed in this system is ${installedProductVersionString}, which is older than available version ${availableProductVersionString}"
            return 1
        else
            dpkg --compare-versions "${availableProductVersionString}" lt "${installedProductVersionString}"
            if [ $? -eq 0 ]
            then
                logMessage "Not upgrading ${productName} since version installed in this system is ${installedProductVersionString}, which is newer than available version ${availableProductVersionString}"
            fi
            return 0
        fi
    fi
}

# Function to obsolete a package, if present. Else install the other provided package via getInstallTypeRPM
# 1st param - Package which is going to be obsoleted. (package 1)
# 2nd param - New package which is obsoleting 1st package. (package 2)
# 3rd param - Version of package 2 bundled in this pack.
# This function returns -
# 2 : If package 1 is present and is getting updated to package 2
# Return value of getInstallTypeRPM() : In case if package 1 is not present.
upgradeObsoletedOrInstallTypeRPM()
{
    packagesListToObsolete=( $(echo "$1") )
    packageToInstall=$2
    packageToInstallVersionString=$3
    for packageToObsolete in "${packagesListToObsolete[@]}"
    do
        # Check whether the package to be obsoleted is present or not.
        rpm -qa | grep -q ${packageToObsolete}
        if [ $? -eq 0 ]
        then
            obsoletedPackageVersion=$(rpm -q --queryformat "%{VERSION}.%{RELEASE}\n" ${packageToObsolete})
            logMessage "${packageToObsolete} installed in this system is - ${obsoletedPackageVersion}"
            logMessage "${packageToObsolete} will be upgraded to ${packageToInstall}"
            return 2
        fi
    done
    # The package that we attempted to obsolete is not present, proceed with normal course of installation.
    getInstallTypeRPM ${packageToInstall} ${packageToInstallVersionString}
    return $?
}

# Function to obsolete a package, if present. Else install the other provided package via getInstallTypeDEB
# 1st param - Package which is going to be obsoleted. (package 1)
# 2nd param - New package which is obsoleting 1st package. (package 2)
# 3rd param - Version of package 2 bundled in this pack.
# This function returns -
# 2 : If package 1 is present and is getting updated to package 2
# Return value of getInstallTypeDEB() : In case if package 1 is not present.
upgradeObsoletedOrInstallTypeDEB()
{
    packageToObsolete=$1
    packageToInstall=$2
    packageToInstallVersionString=$3

    # Check whether the package to be obsoleted is present or not.
    obsoletedPackageVersion=$(dpkg -s ${packageToObsolete} 2>/dev/null | grep ^Version | awk -F ': ' '{print $2}')
    if [ ! -z "${obsoletedPackageVersion}" ]
    then
        logMessage "${packageToObsolete} installed in this system is - ${obsoletedPackageVersion}"
        logMessage "${packageToObsolete} will be upgraded to ${packageToInstall}"
        return 2
    else
        # The package that we attempted to obsolete is not present, proceed with normal course of installation.
        getInstallTypeDEB ${packageToInstall} ${packageToInstallVersionString}
        return $?
    fi
}

# Test if RPM package installation generates a conflict with TP
# Update global variables for any conflicts
checkForRPMConflicts()
{
    fileToTest=$1
    productNameToTest=$2
    logMessage "Testing for any conflict in installing ${productNameToTest}"
    resultOfTest=$(rpm --test -i ${fileToTest} 2>&1)
    checkForISecTPConflict=$(echo ${resultOfTest} | grep -q -E 'ISecTP .* conflicts')
    # Returns 0 if grep was successful in getting a match
    if [ $? -eq 0 ]
    then
        isISecTPConflicted=1
        installedISecTPVersion=$(getInstalledProductVersion ISecTP 2>/dev/null)
        logMessage "New version of ${productNameToTest} conflicts with installed ISecTP ${installedISecTPVersion}. ISecTP should also be upgraded."
    else
        checkForMFETPConflict=$(echo ${resultOfTest} | grep -q -E 'McAfeeTP .* conflicts')
        if [ $? -eq 0 ]
        then
            isTPConflicted=1
            installedMFETPVersion=$(getInstalledProductVersion McAfeeTP 2>/dev/null)
            logMessage "New version of ${productNameToTest} conflicts with installed McAfeeTP ${installedMFETPVersion}. McAfeeTP should also be upgraded."
        fi
    fi
}

# Test if DEB package installation generates a conflict with mcafeetp
# Update global variables for any conflicts
checkForDEBConflicts()
{
    fileToTest=$1
    productNameToTest=$2
    logMessage "Testing for any conflict in installing ${productNameToTest}"
    resultOfTest=$(apt-get --no-remove -s -o Dir::Etc::Sourcelist=${tmpDir}/sources.list -o Dir::Cache::Archives=${tmpDir}/cache/apt/archives -o Dir::State::Lists=${tmpDir}/lib/apt/lists -o DPkg::Options::=--admindir=${tmpDir}/lib/dpkg install ${productNameToTest} 2>&1)
    checkForISecTPConflict=$(echo ${resultOfTest} | grep -q -iE isectp)
    # Returns 0 if grep was successful in getting a match
    if [ $? -eq 0 ]
    then
        isISecTPConflicted=1
        # Using the product name used for rpm as dpkg command is case insensitive
        installedISecTPVersion=$(getInstalledProductVersion ISecTP 2>/dev/null)
        logMessage "New version of ${productNameToTest} conflicts with installed isectp ${installedISecTPVersion}. isectp should also be upgraded."
    else
        checkForMFETPConflict=$(echo ${resultOfTest} | grep -q -iE mcafeetp)
        if [ $? -eq 0 ]
        then
            isTPConflicted=1
            installedMFETPVersion=$(getInstalledProductVersion McAfeeTP 2>/dev/null)
            logMessage "New version of ${productNameToTest} conflicts with installed mcafeetp ${installedMFETPVersion}. mcafeetp should also be upgraded."
        fi
    fi
}

# Function to cleanup temporary files
cleanup()
{
    # Save exit code
    exitCode=$1
    # Delete the temporary directory
    rm -rf "${tmpDir}"
    exit ${exitCode}
}

# Function to check process state (running or stopped).
# param 1 the process name to check
# return 1 if running, 0 otherwise
checkIfServiceIsRunning()
{
    serviceName=$1
    if (( $(ps -ef | grep -v grep | grep $serviceName$ | wc -l) > 0 ))
    then
        return 1
    else
        return 0
    fi
}

# This will be used to automatically determine the name of the output log file
declare -r me=${0##*/}
# Set default permissions of files to allow read / write only for owner
umask 077
# Used to track if this is a rpm or deb based system
# yes - Debian based system, no for RPM based system
DEB_VARIANT="no"
# Used to track if this uses zypper as the package management system
SUSE_VARIANT="no"

# Set this to 1, if this is a ePO installer
ePOInstaller=1

# ePO Installer script should not be executed in standalone mode
if [ ${ePOInstaller} = 1 -a -t 1 ]
then
    echo "ERROR: This script should be run only by McAfee agent and does not support standalone installation"
    echo "Use the standalone installer instead"
    exit 9
fi

# Check installer is executed as root
ID="$(id -u)"
if [ $? -ne 0 -o "$ID" -ne 0 ]
then
    logMessage "Must be root to install this product"
    exit 5
fi

# Flag which can be set to test if Kernel Module can be installed on this system
dryRunUpgrade="no"

numargs=$#
for ((i=1 ; i <= numargs ; i++))
do
    case $1 in
        "dryrun")
            dryRunUpgrade="yes"
            ;;
        "--help")
            usage
            ;;
        "-h")
            usage
            ;;
        *)
            usage
            ;;
    esac
    shift
done

# Kernel module package, eg: McAfeeESP-KernelModule-10.6.1-180-Full.linux.tar.gz
installerFile="McAfeeESP-KernelModule-10.6.9-126-Full.linux.tar.gz"


# Flags to set installation type for each module
# 0 - Do not install or package not installed, 1 - Upgrade module
mfeESPFileAccessInstall=0
mfeESPAACInstall=0
# This is the number of packages that needs to be installed / upgraded
noOfPkgsToInstall=0

# Flags to track if any of the ESP packages have a conflict with a PP
# 0 - No conflict with PP, 1 - new ESP conflicts with PP
isTPConflicted=0
isISecTPConflicted=0

PACKAGED_MFE_ESP_FILEACCESS_VERSION_INT="10.6.9-126"
PACKAGED_MFE_ESP_AAC_VERSION_INT="10.6.9-126"

# All known rpm based systems either have /etc/redhat-release (Redhat, Fedora, CentOS) or /etc/SuSE-release (SuSE, openSuSE)
if [ -f /etc/redhat-release -o -f /etc/SuSE-release ]
then
    DEB_VARIANT="no"
    if [ -f /etc/SuSE-release ]
    then
        SUSE_VARIANT="yes"
    fi
elif [ -f /etc/system-release ]
then
    # Amazon Linux AMI is rpm based, has /etc/system-release and its content starts with Amazon
    distribRel=$(cat /etc/system-release)
    amazonSearchPattern="^Amazon"
    if [[ $distribRel =~ $amazonSearchPattern ]]
    then
        DEB_VARIANT="no"
    fi
elif [ -f /etc/os-release ]
then
    # SuSE 15 and above does not ship with /etc/SuSE-release; check /etc/os-release instead
    distribId=$(cat /etc/os-release | grep ^ID=)
    slesSearchPattern="sles|sled"
    if [[ $distribId =~ $slesSearchPattern ]]
    then
        SUSE_VARIANT="yes"
        DEB_VARIANT="no"
    else
        DEB_VARIANT="yes"
    fi
else
    DEB_VARIANT="yes"
fi

# For Dry run upgrade from older versions, return 0 if upgrade of either File Access or AAC Kernel Modules can be attempted
# Dry run does not test for obsoleting HIPS or pre 10.6.6 ISeC products as it only tests for upgrading itself
if [ "${dryRunUpgrade}" = "yes" ]
then
    if [ "${DEB_VARIANT}" = "no" ]
    then
        # For RPM based systems, getInstallTypeRPM returns 1, if it is upgradeable
        getInstallTypeRPM McAfeeESPFileAccess ${PACKAGED_MFE_ESP_FILEACCESS_VERSION_INT}
        mfeESPFileAccessInstall=$?
        getInstallTypeRPM McAfeeESPAac ${PACKAGED_MFE_ESP_AAC_VERSION_INT}
        mfeESPAACInstall=$?
    else
        # For DEB based systems, getInstallTypeDEB returns 1, if it is upgradeable
        getInstallTypeDEB McAfeeESPFileAccess ${PACKAGED_MFE_ESP_FILEACCESS_VERSION_INT}
        mfeESPFileAccessInstall=$?
        getInstallTypeDEB McAfeeESPAac ${PACKAGED_MFE_ESP_AAC_VERSION_INT}
        mfeESPAACInstall=$?
    fi
    # Assume none of the kernel modules are upgradeable
    retVal=1
    # If either of Kernel module is upgradable in the dry run, then return 0
    if [ ${mfeESPFileAccessInstall} -eq 1 -o ${mfeESPAACInstall} -eq 1 ]
    then
        retVal=0
    fi
    exit ${retVal}
fi

# ESP Kernel Module script can only be run during a upgrade where options cannot be provided.
tmpDir="/tmp/ens_pkg"
rm -rf ${tmpDir}
# Create temporary directory to extract the installer file
mkdir -p ${tmpDir}
# Directory from where package managers will install our packages
pkgMgrDir=${tmpDir}/install
mkdir -p ${pkgMgrDir}

logMessage "${me} execution time: $(date)"

if [ ! -f "${installerFile}" ]
then
    logMessage "Unable to locate the main installation file ${installerFile}"
    exit 7
fi

tar -C "${tmpDir}" -xzf ${installerFile}
if [ $? -ne 0 ]
then
    logMessage "Failed to extract the installation file ${installerFile}"
    cleanup 10
fi

if [ ${DEB_VARIANT} = "yes" ]
then
    logMessage "Detected deb based distribution"
    # Since this is a RPM based distribution, delete any DEB packages.
    # Delete any tar.gz which will also not be required.
    /bin/rm -f ${tmpDir}/*.rpm ${tmpDir}/*.tar.gz
else
    logMessage "Detected rpm based distribution"
    # Since this is a RPM based distribution, delete any DEB packages.
    # Delete any tar.gz which will also not be required.
    /bin/rm -f ${tmpDir}/*.deb ${tmpDir}/*.tar.gz
fi

# For every known rpm / deb in the directory; check if it can be installed or upgraded
# If it cannot be installed or upgraded, then delete it from the directory
# Caller script should install the left over rpm / deb in the directory using yum / zypper / apt-get
for file in ${tmpDir}/*
do
    case "$file" in
        *McAfeeESPAac-*)
            MCAFEE_ESP_AAC_PACKAGE_FILE="${file}"
            if [ ${DEB_VARIANT} = "yes" ]
            then
                AVAILABLE_MCAFEE_ESP_AAC_VERSION_INT=$(echo "${file}" | sed 's/.*McAfeeESPAac-\(.*\).deb/\1/')
                 # If McAfeeESPAAC is shipped, Check if ISecESPAAC for Linux is installed
                # If yes, we need to upgrade it to McAfeeESPAAC
                # Else we need to go with normal McAfeeESPAAC installation.
                upgradeObsoletedOrInstallTypeDEB isecespaac mcafeeespaac ${AVAILABLE_MCAFEE_ESP_AAC_VERSION_INT}
                mfeESPAACInstall=$?
            else
                AVAILABLE_MCAFEE_ESP_AAC_VERSION_INT=$(echo "${file}" | sed 's/.*McAfeeESPAac-\(.*\).x86_64.rpm/\1/')
                # If McAfeeESPAAC is shipped, Check if ISecESPAAC for Linux or HIPS(HIPS can be present only on RPM based distributions)
                # If yes, we need to upgrade it to McAfeeESPAAC
                # Else we need to go with normal McAfeeESPAAC installation.
                # Pass the packages to be obsoletes as array variable
                obsoletePackageArray=("ISecESPAac" "MFEhiplsm")
                obsoletePacakes="${obsoletePackageArray[@]}"
                upgradeObsoletedOrInstallTypeRPM $obsoletePacakes McAfeeESPAac ${AVAILABLE_MCAFEE_ESP_AAC_VERSION_INT}
                mfeESPAACInstall=$?
            fi
            # Delete the package, if it is not being installed or upgraded
            if [ ${mfeESPAACInstall} -eq 0 ]
            then
                rm -f ${file}
            else
                let noOfPkgsToInstall="${noOfPkgsToInstall}+1"
            fi
            ;;
        *McAfeeESPFileAccess-*)
            MFE_ESP_FILEACCESS_PACKAGE_FILE="${file}"
            if [ ${DEB_VARIANT} = "yes" ]
            then
                AVAILABLE_MFE_ESP_FILEACCESS_VERSION_INT=$(echo "${file}" | sed 's/.*McAfeeESPFileAccess-\(.*\).deb/\1/')
                # If ESPFileAccess is shipped, Check if ESPFileAccess for Linux is installed
                # If ESPFileAccess is shipped, Check if ISecESPFileAccess for Linux is installed
                # If yes, we need to upgrade it to McAfeeESPFileAccess
                # Else we need to go with normal McAfeeESPFileAccess installation.
                upgradeObsoletedOrInstallTypeDEB isecespfileaccess MFE_ESP_FILEACCESS_PRODUCT_NAME_LOWERCASE ${AVAILABLE_MFE_ESP_FILEACCESS_VERSION_INT}
                mfeESPFileAccessInstall=$?
            else
                AVAILABLE_MFE_ESP_FILEACCESS_VERSION_INT=$(echo "${file}" | sed 's/.*McAfeeESPFileAccess-\(.*\).x86_64.rpm/\1/')
                # If ESPFileAccess is shipped, Check if ESPFileAccess for Linux is installed
                # If ESPFileAccess is shipped, Check if ISecESPFileAccess for Linux is installed
                # If yes, we need to upgrade it to McAfeeESPFileAccess
                # Else we need to go with normal McAfeeESPFileAccess installation.
                upgradeObsoletedOrInstallTypeRPM isecespfileaccess MFE_ESP_FILEACCESS_PRODUCT_NAME_LOWERCASE ${AVAILABLE_MFE_ESP_FILEACCESS_VERSION_INT}
                mfeESPFileAccessInstall=$?
            fi
            # Delete the package, if it is not being installed or upgraded
            if [ ${mfeESPFileAccessInstall} -eq 0 ]
            then
                rm -f ${file}
            else
                let noOfPkgsToInstall="${noOfPkgsToInstall}+1"
            fi
            ;;
    esac
done

# Test if package installation generates a conflict with a known product, at least one package should be upgradable
retVal=0
if [ ${noOfPkgsToInstall} -gt 0 ]
then
    # For Debian based distribution, create a temporary file repository
    if [ ${DEB_VARIANT} = "yes" ]
    then
        logMessage "Creating a temporary file based apt repository in ${tmpDir}"
        echo "deb file:${tmpDir} ./" > ${tmpDir}/sources.list
        # Create the cache and lib directory
        mkdir -p ${tmpDir}/cache/apt/archives
        mkdir -p ${tmpDir}/lib/apt/lists
        # Reuse the existing system dpkg directory
        ln -s /var/lib/dpkg ${tmpDir}/lib/dpkg
        if [ $? -ne 0 ]
        then
            logMessage "Error in creating a symlink to existing dpkg administrative directory"
            cleanup 9
        fi
        logMessage "Created a symlink to existing dpkg administrative directory"
        pushd ${tmpDir} > /dev/null 2>&1
        apt-ftparchive packages . > Packages
        gzip -f Packages
        popd > /dev/null 2>&1
        cp -f ${tmpDir}/Packages.gz ${tmpDir}/lib/apt/lists/
        if [ $? -ne 0 ]
        then
            logMessage "Error in creating Packages.gz containing our packages"
            cleanup 9
        fi
        apt-get -q -o Dir::Etc::Sourcelist=${tmpDir}/sources.list -o Dir::Etc::SourceParts=${tmpDir} -o Dir::Cache::Archives=${tmpDir}/cache/apt/archives -o Dir::State::Lists=${tmpDir}/lib/apt/lists -o DPkg::Options::=--admindir=${tmpDir}/lib/dpkg -o Acquire::AllowInsecureRepositories=true -o APT::Sandbox::User=root update > /dev/null 2>&1
        if [ $? -ne 0 ]
        then
            logMessage "Error in running apt-get update from temporary apt repository"
            cleanup 9
        fi
        if [ ${mfeESPAACInstall} -gt 0 ]
        then
            checkForDEBConflicts ${MCAFEE_ESP_AAC_PACKAGE_FILE} "mcafeeespaac"
        fi
        if [ ${mfeESPFileAccessInstall} -gt 0 ]
        then
            checkForDEBConflicts ${MFE_ESP_FILEACCESS_PACKAGE_FILE} "mcafeeespfileaccess"
        fi
    else
        if [ ${mfeESPAACInstall} -gt 0 ]
        then
            checkForRPMConflicts ${MCAFEE_ESP_AAC_PACKAGE_FILE} "McAfeeESPAac"
        fi
        if [ ${mfeESPFileAccessInstall} -gt 0 ]
        then
            checkForRPMConflicts ${MFE_ESP_FILEACCESS_PACKAGE_FILE} "McAfeeESPFileAccess"
        fi
    fi
    if [ ${isTPConflicted} -eq 1 -o ${isISecTPConflicted} -eq 1 ]
    then
        retVal=16
    else
        # Check if mfetpd/isectpd service is running
        if [ ${isISecTPConflicted} -eq 1 ]
        then
            checkIfServiceIsRunning isectpd
            wasTPDaemonProcessRunning=$?
            if [ ${wasTPDaemonProcessRunning} -eq 1 ]
            then
                /opt/isec/ens/threatprevention/bin/isectpdControl.sh stop 2>/dev/null || :
            fi
        else
            checkIfServiceIsRunning mfetpd
            wasTPDaemonProcessRunning=$?
            if [ ${wasTPDaemonProcessRunning} -eq 1 ]
            then
                /opt/McAfee/ens/tp/init/mfetpd-control.sh stop 2>/dev/null || :
            fi
        fi
        actualUpgradeCmdRetVal=0
        if [ ${DEB_VARIANT} = "yes" ]
        then
            DEBIAN_FRONTEND=noninteractive apt-get -q --yes --allow-unauthenticated -o Dir::Etc::Sourcelist=${tmpDir}/sources.list -o Dir::Etc::SourceParts=${tmpDir} -o Dir::Cache::Archives=${tmpDir}/cache/apt/archives -o Dir::State::Lists=${tmpDir}/lib/apt/lists -o DPkg::Options::=--admindir=${tmpDir}/lib/dpkg -o Acquire::AllowInsecureRepositories=true -o APT::Sandbox::User=root install mcafeeespaac mcafeeespfileaccess
            actualUpgradeCmdRetVal=$?
        elif [ ${SUSE_VARIANT} = "yes" ]
        then
            zypper --no-refresh --no-cd --no-remote --no-gpg-checks -q -n install ${tmpDir}/*.rpm > /dev/null 2>&1
            actualUpgradeCmdRetVal=$?
        else
            yum -y --nogpgcheck --disablerepo=* install ${tmpDir}/*.rpm
            actualUpgradeCmdRetVal=$?
        fi

        if [ ${actualUpgradeCmdRetVal} -eq 0 ]
        then
            retVal=0
        else
            retVal=9
        fi

        if [ ${wasTPDaemonProcessRunning} -eq 1 ]
        then
            /opt/McAfee/ens/tp/init/mfetpd-control.sh start 2>/dev/null || :
        fi
    fi
else
    retVal=9
fi

exit ${retVal}
