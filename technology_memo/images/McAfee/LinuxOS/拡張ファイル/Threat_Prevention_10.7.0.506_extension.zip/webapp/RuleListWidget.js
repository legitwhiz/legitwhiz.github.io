//Copyright (C) 2017 McAfee, Inc.  All rights reserved.
//

//This file is a copy of the VSECommon.js file with some modifications to support multiple text columns. The entire
//VSECommon.js file has not been copied over - just the ListItem and ListWidget controls
var VSE = window.VSE || {};

// Added this flag due to the fact that we are not initializing any of the form
// elements when they are loaded. This is because the data in the form is populated
// based on which policy type (server/wrkstn) is selected.
var g_FirstValidationCheck = true;

// Global Dirty flag to handle list control
var g_bFormDirty = false;

var g_Disabled = false;

/****************************************************************************/
/* List Item for use with the List Widget                                   */
/****************************************************************************/
VSE.ListItem = function(){
    this.itemData = null;
    this.itemChecked = false;
    this.displayText0 = "";  //text column 1
    this.displayText1 = "";  //text column 2
    this.displayText2 = "";  //text column 3
    this.displayText3 = "";  //text column 4
}

VSE.ListItem.prototype = {
    setDisplayText : function(text)
    {
        this.displayText = text;
    }
    ,
    setItemData : function(data)
    {
        this.itemData = data;
    }
    ,
    setItemChecked : function(checked)
    {
        this.itemChecked = checked;
    }
}

/****************************************************************************/
/* VSE.ListWidget                                                           */
/*                                                                          */
/* Displays a list of VSE.ListItem objects and allows the inclusion of a    */
/* checkbox for the item.                                                   */
/****************************************************************************/
VSE.ListWidget = function(obj){
    this.cntrid = null;
    this.cntr = null;
    this.id = 0;
    this.list = {};                         // an array of VSE.ListItem objects
    this.addCallback = null;
    this.removeCallback = null;
    this.onchangeSelectionCallback = null;
    this.checkboxCallback = null;
    this.readOnly=false;
    this.width = 800;
    this.height = 150;
    this.listTable = null;
    this.checkboxCount = 0;
    this.columnCount = 0;
    this.objectName = obj["objectName"];
    this.content="";
    this.showZebra=false;

    if(obj["container"] != null)
    {
        this.cntrid = obj["container"];
        this.cntr = document.getElementById(obj["container"]);
    }

    if(obj["content"] != null)
    {
        this.content = obj["content"];
    }

    if(obj["addCallback"] != null)
    {
        this.addCallback = obj["addCallback"];
    }

    if(obj["removeCallback"] != null)
    {
        this.removeCallback = obj["removeCallback"];
    }

    if(obj["onchangeSelectionCallback"] != null)
    {
        this.onchangeSelectionCallback = obj["onchangeSelectionCallback"];
    }

    if(obj["checkboxCallback"] != null)
    {
        this.checkboxCallback = obj["checkboxCallback"];
    }

    if(obj["readOnly"] != null)
    {
        this.readOnly = obj["readOnly"];
    }

    if(obj["width"] != null)
    {
        this.width = obj["width"];
    }

    if(obj["height"] != null)
    {
        this.height = obj["height"];
    }

    if(obj["checkboxCount"] != null)
    {
        this.checkboxCount = obj["checkboxCount"];
    }

    if(obj["columnCount"] != null)
    {
        this.columnCount = obj["columnCount"];
    }

    if(obj["data"] != null)
    {
        this.data = obj["data"];
    }

    if(obj["showZebra"] != null)
    {
        this.showZebra = (obj["showZebra"] === true);
    }

    // create the table to contain the list
    if(this.cntr != null)
    {
        var listDiv = document.createElement('div');
        listDiv.style.overflow = "auto";
        listDiv.style.width = "" + this.width + "px";
        var browserVersion = getBrowserVersion();

        if(browserVersion > 0 && browserVersion < 7)
        {
            listDiv.style.height = "" + this.height + "px";

        }
        else
        {
            listDiv.style.minHeight = "" + this.height + "px";
            listDiv.style.maxHeight = "1px";
        }
        listDiv.style.borderStyle = "solid";
        listDiv.style.borderWidth = "thin";
        listDiv.style.padding = "0px";
        listDiv.style.margin = "0px";

        this.listTable = document.createElement('table');
        this.listTable.id = this.cntrid+"_listContainer";
        this.listTable.width = this.width;
        this.listTable.cellPadding = 0;
        this.listTable.cellSpacing = 0;
        this.listTable.border = 0;
        this.selectedRow = "undefined";

        listDiv.appendChild(this.listTable);
        this.cntr.appendChild(listDiv);
    }
}

VSE.ListWidget.prototype.add = function(listItem)
{
    if(listItem == null)
    {
        return;
    }
    this.id++;

    // Create a new row in the table
    var newRow = this.listTable.insertRow(this.listTable.rows.length);

    if (this.showZebra && (newRow.rowIndex % 2 === 1)){
        newRow.className = 'oddRow'
    }

    newRow.id = this.cntrid + "_lwrow_" + this.id;

    // this is the text for the function call to be used for onclick events to handle the selection
    // and unselection of the table rows.
    var selectRowFunctionCall = this.objectName + ".SelectRow('" + newRow.id + "');";

    // add the checkbox cell to the row if needed
    var cellCount = 0;
    for(var i=0; i < this.checkboxCount; ++i)
    {
        var checkboxColumn = newRow.insertCell(cellCount);
        ++cellCount;
        var checkboxID = newRow.id + "_checkbox" + i;
        //checkboxColumn.style.width = 25;
        checkboxColumn.setAttribute("onclick", selectRowFunctionCall);

        var checkboxElement = document.createElement('input');
        checkboxElement.type = "checkbox";
        checkboxElement.name = checkboxID;
        checkboxElement.id = checkboxID;
        checkboxElement.checked = listItem.itemChecked;
        checkboxColumn.appendChild(checkboxElement);
        // this is essentially the same as the code above, except that the code above does not work on IE.
        $(checkboxID).checked = listItem.itemChecked;
        if(this.checkboxCallback != null)
        {
            $(checkboxID).onclick = this.checkboxCallback;
        }
    }

    for(var i=0; i < this.columnCount; ++i)
    {
        var contentColumn = newRow.insertCell(cellCount);

        contentColumn.id = this.cntrid + "_lwrow_" + this.id + "_content";
        contentColumn.setAttribute("onclick", selectRowFunctionCall);

        var contentHref = document.createElement('a');
        contentHref.href = "JavaScript:" + selectRowFunctionCall;
        contentHref.style.textDecoration = "none";
        contentHref.id = newRow.id + "_contentHref";

        var dynamicProperty = "displayText" + i;
        contentHref.innerHTML = OrionCore.escapeHtml(listItem[dynamicProperty]);

        contentColumn.appendChild(contentHref);
        ++cellCount;
        this.list[this.cntrid+"_lwrow_"+this.id] = listItem;
    }
    // call the add callback if one is set
    if(this.addCallback != null)
    {
        this.addCallback(newRow);
    }
}

VSE.ListWidget.prototype.getItemList = function()
{
    var items = new Array();
    for(i in this.list)
    {
        if(this.list[i])
        {
            this.list[i].itemChecked = $(i+"_checkbox").checked;
            items.push(this.list[i]);
        }
    }

    return items;
}

VSE.ListWidget.prototype.renameSelected = function(name)
{
    if(this.selectedRow != "undefined")
    {
        $(this.selectedRow + "_contentHref").innerHTML = name;
    }
}

VSE.ListWidget.prototype.removeSelected = function()
{
    if(this.selectedRow != "undefined")
    {
        for(var i=0; i < this.listTable.rows.length; ++i)
        {
            if(this.listTable.rows[i].id == this.selectedRow)
            {
                this.list[this.selectedRow] = null;
                this.unhighlightRow(this.selectedRow);
                this.listTable.deleteRow(i);
                if (this.listTable.rows.length > 0)
                {
                    this.highlightRow(this.listTable.rows[Math.min(i, this.listTable.rows.length - 1)].id);
                    this.selectedRow = this.listTable.rows[Math.min(i, this.listTable.rows.length - 1)].id;
                }
                else
                {
                    this.selectedRow = "undefined";
                }
                if(this.removeCallback != null)
                {
                    this.removeCallback();
                }
                break;
            }
        }
    }
}

VSE.ListWidget.prototype.SelectRow = function(rowID)
{
    var previousRow = "";
    if(this.selectedRow != "undefined")
    {
        previousRow = this.selectedRow;
        this.unhighlightRow(this.selectedRow);
    }

    this.highlightRow(rowID);
    this.selectedRow = rowID;

    // the selection change callback should only be called when the selection
    // actually changes.
    if(this.onchangeSelectionCallback != null && (previousRow != this.selectedRow))
    {
        this.onchangeSelectionCallback(this.list[this.selectedRow]);
    }
}

VSE.ListWidget.prototype.highlightRow = function(rowID)
{
    var targetRow = $(rowID);
    targetRow.bgColor = "lightsteelblue";
    targetRow.className += ' selectedRow';
}

VSE.ListWidget.prototype.unhighlightRow = function(rowID)
{
    var targetRow = $(rowID);
    targetRow.bgColor = "white";
    targetRow.className =
        targetRow.className.replace( /(?:^|\s)selectedRow(?!\S)/g , '' )
}

VSE.ListWidget.prototype.getSelected = function()
{
    if(this.selectedRow == "undefined")
    {
        return null;
    }
    else
    {
        return this.list[this.selectedRow];
    }
}

VSE.ListWidget.prototype.getItem = function(rowID)
{
    return this.list[rowID];
}

VSE.ListWidget.prototype.clearList = function()
{
    for(var i = this.listTable.rows.length-1; i > -1; i--)
    {
        this.listTable.deleteRow(i)
    }
    this.list = {};
    this.id = 0;
    this.selectedRow = "undefined";
}

function disableSection(sectionId,enable)
{
    var section = document.getElementById(sectionId);
    var slist = getElementsAsArray(sectionId);

    for(var i=0;i<slist.length;i++){
        //OrionCore.setEnabled(slist[i],enable);
        slist[i].disabled = !enable;
    }
}

function getElementsAsArray(sectionId)
{
    var sectd = document.getElementById(sectionId);
    var slistt = new Array();
    var slist = slistt.concat(__arrayme(sectd.getElementsByTagName("LABEL")),
        __arrayme(sectd.getElementsByTagName("INPUT")),
        __arrayme(sectd.getElementsByTagName("SELECT")),
        __arrayme(sectd.getElementsByTagName("TEXTAREA")));

    return slist;

    function __arrayme(obj){
        var n = new Array();
        for(var j=0;j<obj.length;j++){
            n.push(obj[j]);
        }
        return n;
    }
}


// ===========================================================================
// Called by orion whenever the state of the form changes (checkbox checked,
// textbox edited, etc.)
//
// We use this to deteremine whether or not the Apply button should be
// enabled
// ===========================================================================
function stateChangeHandler( isDirty, isValid )
{
    if((isDirty || g_bFormDirty) && !g_FirstValidationCheck && isValid)
    {
        epoEnableApplyButton();
    }
    else
    {
        epoDisableApplyButton();
    }

    // Now that the form has been validated, we're past the first check, so
    // set this flag to false.
    if(g_FirstValidationCheck)
    {
        g_FirstValidationCheck = false;
    }
}
function getBrowserVersion()
{
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf ( "MSIE " );
    var ver = 0;

    if ( msie > 0 )
    {
        // If Internet Explorer, return version number
        ver = parseInt (ua.substring (msie+5, ua.indexOf (".", msie )));
    }

    return ver;
}
