//Copyright (C) 2017 McAfee, Inc.  All rights reserved.
//

function createTPRulesFromAMSIEvents()
{
    function setMessageText(html)
    {
        if (OrionAction) OrionAction.addStatusMessage(html, OrionAction.STATUS_PLAIN);
    }

    function onCreateFailure()
    {
        OrionCore.showPleaseWait(false);
    }

    function onCreateFromClientRuleOK()
    {
        if(actionAllowed) {
            var mapParams = [
                "TPCopyDestination",$("selectedValue").value];

            OrionCore.doAsyncAction("/ENDP_AM_1000/CreateAMSIExclusionsFromEvents.do", mapParams, setMessageText, onCreateFailure, "POST");
        }

        OrionCore.showAsyncDialogBox(false);

        return true;
    }

    function onCreateFromClientRuleCancel()
    {
        OrionCore.showAsyncDialogBox(false);
        OrionAction.clearStatus();
    }

    OrionCore.dialogBoxOkHandler = onCreateFromClientRuleOK;
    OrionCore.dialogBoxCancelHandler = onCreateFromClientRuleCancel;

    OrionCore.showAsyncDialogBox(true, "/ENDP_AM_1000/ListOptionsTargetPolicies.do", OrionCore.DIALOG_OK_CANCEL);
}