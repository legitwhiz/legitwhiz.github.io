//Copyright (C) 2017 McAfee, Inc.  All rights reserved.
//

function createTPRulesFromEvents()
{
    function setMessageText(html)
    {
        if (OrionAction) OrionAction.addStatusMessage(html, OrionAction.STATUS_PLAIN);
    }

    function onCreateFailure()
    {
        OrionCore.showPleaseWait(false);
    }

    function onCreateFromClientRuleOK()
    {
        var mapParams = [
            "TPCopyDestination",$("selectedValue").value];

        OrionCore.showAsyncDialogBox(false);

        OrionCore.doAsyncAction("/ENDP_AM_1000/CreateXPExclusionsFromEvents.do", mapParams, setMessageText, onCreateFailure, "POST");
        return true;
    }

    function onCreateFromClientRuleCancel()
    {
        OrionCore.showAsyncDialogBox(false);
        OrionAction.clearStatus();
    }

    OrionCore.dialogBoxOkHandler = onCreateFromClientRuleOK;
    OrionCore.dialogBoxCancelHandler = onCreateFromClientRuleCancel;
    OrionCore.showAsyncDialogBox(true, "/ENDP_AM_1000/ListTPTargetPolicies.do", OrionCore.DIALOG_OK_CANCEL);
}