//Copyright (C) 2017 McAfee, Inc.  All rights reserved.
//

var g_locationsAddWidget;
var g_exclusionsAddWidget;
var g_bMASInstalled;

// Note: these values only appear in the registry and should NOT be localized.
var g_ScanItemValues = new Array();
g_ScanItemValues[0] = "Invalid";
g_ScanItemValues[1] = "SpecialScanForRootkits";
g_ScanItemValues[2] = "SpecialMemory";
g_ScanItemValues[3] = "SpecialCritical";
g_ScanItemValues[4] = "My Computer";
g_ScanItemValues[5] = "LocalDrives";
g_ScanItemValues[6] = "All fixed disks";
g_ScanItemValues[7] = "All removable media";
g_ScanItemValues[8] = "All Network drives";
g_ScanItemValues[9] = "HomeDir";
g_ScanItemValues[10] = "ProfileDir";
g_ScanItemValues[11] = "WinDir";
g_ScanItemValues[12] = "ProgramFilesDir";
g_ScanItemValues[13] = "TempDir";
g_ScanItemValues[14] = "SpecialRecycleName";
g_ScanItemValues[15] = "FileOrFolder";
g_ScanItemValues[16] = "SpecialRegistry";

var SCAN_ITEM_INVALID = 0;
var SCAN_ITEM_FILE_FOLDER = 15;
var SCAN_ITEM_REGISTRY = 16;
var SCAN_ITEM_COOKIES = 17;

var ACTION_VALUE_INVALID = 0;
var ACTION_VALUE_CLEAN = 1;
var ACTION_VALUE_DELETE = 2;
var ACTION_VALUE_CONTINUE = 6;

var ACTION_INDEX_CLEAN = 0;
var ACTION_INDEX_DELETE = 1;
var ACTION_INDEX_CONTINUE = 2;

var g_iCurrentPrimaryActionValue = 0;
var g_iCurrentPrimaryActionUnwantedValue = 0;
var g_iCurrentSecondaryActionValue = 0;
var g_iCurrentSecondaryActionUnwantedValue = 0;

// Exclusions constants to OR against the "flags" value..
var ON_READ = 2;
var ON_WRITE = 1;
var INCLUDE_SUBFOLDERS = 4;

// Exclusions
var g_bNewExclusion = false;
var g_ExclusionListWidget;
var g_arrListExclusionData = [];
var ExclusionsList = [];

ExclusionDataItem = function (obj)
{
    var exclData = "";
}

// Global DOM objects
var g_primaryActionSelect;
var g_secondaryActionSelect;
var g_primaryActionSelectUnwanted;
var g_secondaryActionSelectUnwanted;

// ===========================================================================
// ===========================================================================
function fnSetPrimaryAction(selectID_CurrentAction, iPrimaryValue)
{
    for (var i = 0; i < selectID_CurrentAction.length; i++)
    {
        if (parseInt(selectID_CurrentAction.options[i].value) == parseInt(iPrimaryValue))
        {
            selectID_CurrentAction.selectedIndex = i;
        }
    }
}

// ===========================================================================
// ===========================================================================
function fnSetSecondaryActionValue(selectID_CurrentSecondaryAction, iSecondaryValue)
{
    for (var i = 0; i < selectID_CurrentSecondaryAction.length; i++)
    {
        if (selectID_CurrentSecondaryAction.options[i].value == iSecondaryValue)
        {
            selectID_CurrentSecondaryAction.selectedIndex = i;
        }
    }
}

// ===========================================================================
// ===========================================================================
function fnSecondaryAction_OnChange(selectID_CurrentSecondaryAction, iSecondaryValue, bPromptForDelete)
{
    if (selectID_CurrentSecondaryAction == g_secondaryActionSelect)
    {
        g_iCurrentSecondaryActionValue = iSecondaryValue;
    }
    else
    {
        if (selectID_CurrentSecondaryAction == g_secondaryActionSelectUnwanted)
        {
            g_iCurrentSecondaryActionUnwantedValue = iSecondaryValue;
        }
    }

    fnSetSecondaryActionValue(selectID_CurrentSecondaryAction, iSecondaryValue);
}

// ===========================================================================
// ===========================================================================
function locAddCallback(newDiv)
{
    if (newDiv != null)
    {
        var itemID = newDiv.id.replace("locationsList_awrow_", "");
        var hiddenValueName = "locationsList_hiddenvalue_" + itemID;
        var hiddenValueElement = document.getElementById(hiddenValueName);
        var hiddenValue = g_ScanItemValues[0];
        var pathValueElement = document.getElementById("item_path_" + itemID);
        var selectElement = document.getElementById("select_location_" + itemID);

        if (hiddenValueElement != null)
        {
            if (hiddenValueElement.value != "")
            {
                hiddenValue = hiddenValueElement.value;
            }
        }

        // clear the path value for newly added items
        if (hiddenValue == g_ScanItemValues[0])
        {
            if (pathValueElement != null)
            {
                pathValueElement.value = "";
            }
        }

        // set the selection index to the appropriate index based on the the value of
        // the select object.
        var bSelectedItemSet = false;
        if (selectElement != null)
        {
            for (var i = 0; i < SCAN_ITEM_FILE_FOLDER; ++i)
            {
                if (hiddenValue == g_ScanItemValues[i])
                {
                    selectElement.selectedIndex = i;
                    bSelectedItemSet = true;
                }
            }

            if (hiddenValue == g_ScanItemValues[SCAN_ITEM_REGISTRY])
            {
                selectElement.selectedIndex = SCAN_ITEM_REGISTRY;
                bSelectedItemSet = true;
            }
            else
            {
                if (hiddenValue == g_ScanItemValues[SCAN_ITEM_COOKIES])
                {
                    selectElement.selectedIndex = SCAN_ITEM_COOKIES;
                    bSelectedItemSet = true;
                }
            }
        }

        // The value was not found so it is either a folder or a file
        if (!bSelectedItemSet)
        {
            pathValueElement.value = hiddenValue;
            selectElement.selectedIndex = SCAN_ITEM_FILE_FOLDER;
            showPathInput(itemID, selectElement.selectedIndex, true);
        }

        // Register Event Handlers
        OrionEvent.registerHandlerById("select_location_" + itemID,
                                       function ()
                                       {
                                           selectScanItemChange($("select_location_" + itemID));
                                           validatePolicy();
                                       },
                                       null,
                                       "change",
                                       false);

        OrionEvent.registerHandlerById("item_path_" + itemID,
                                       function ()
                                       {
                                           locationPathOnBlur($("item_path_" + itemID));
                                       },
                                       null,
                                       "blur",
                                       false);

        OrionEvent.registerHandlerById("item_path_" + itemID,
                                       function ()
                                       {
                                           locationPathOnKeyup($("item_path_" + itemID));
                                           validatePolicy();
                                       },
                                       null,
                                       "keyup",
                                       false);

        updateLocationIDList();
        onChange();
        // if adding a new scan location, disable locations already selected
        if (selectElement.selectedIndex == SCAN_ITEM_INVALID)
        {
            selectScanItemAdd(selectElement);
        }
    }
}

// ===========================================================================
// ===========================================================================
function locRemoveCallback()
{
    // We don't know what was deleted
    // make all scan location options that can be disabled enabled in all select elements, then disable the ones
    // that need to be disabled

    var myrows = g_locationsAddWidget.getList();
    for (var i in myrows)
    {
        var currentRow = myrows[i].replace("locationsList_awrow_", "");
        var currentElement = document.getElementById("select_location_" + currentRow);
        var currentOptions = currentElement.getElementsByTagName("option");
        for (var j = 1; j < SCAN_ITEM_FILE_FOLDER; j++)
        {
            currentOptions[j].disabled = false;
        }
    }
    for (var i in myrows)
    {
        var currentRow = myrows[i].replace("locationsList_awrow_", "");
        var currentElement = document.getElementById("select_location_" + currentRow);
        selectScanItemChange(currentElement);
    }

    updateLocationIDList();
    onChange();
}

// ===========================================================================
// ===========================================================================
function selectScanItemAdd(selectItem)
{
    var Options = selectItem.getElementsByTagName("option");
    var myrows = g_locationsAddWidget.getList();

    for (var i in myrows)
    {
        var currentRow = myrows[i].replace("locationsList_awrow_", "");
        var currentElement = document.getElementById("select_location_" + currentRow);

        // never disable invalid or file/folder options
        if (currentElement.selectedIndex > SCAN_ITEM_INVALID && currentElement.selectedIndex < SCAN_ITEM_FILE_FOLDER )
        {
            Options[currentElement.selectedIndex].disabled = true;
        }
    }
}

// ===========================================================================
// ===========================================================================
function selectScanItemChange(selectItem)
{
    var itemValue = selectItem.value;
    var itemID = selectItem.id.replace("select_location_", "");

    // loop through the list of locations and disable the new selection in all the other select menus.
    // also enable the old selection in all the other select menus.

    // find previous value of select element
    var oldItemValue = document.getElementById("locationsList_hiddenvalue_" + itemID).value;
    var myrows = g_locationsAddWidget.getList();
    for (var i in myrows)
    {
        // skip the select element that was just changed
        var currentRow = myrows[i].replace("locationsList_awrow_", "");
        if (currentRow != itemID)
        {
            var currentElement = document.getElementById("select_location_" + currentRow);
            var currentOptions = currentElement.getElementsByTagName("option");

            // never enable/disable the first (invalid) or last (file or folder) elements
            // iterate over all the scan location options
            for (var j = 1; j < SCAN_ITEM_FILE_FOLDER; j++)
            {
                // find newly selected option in current element and disable it
                if (currentOptions[j].value == itemValue)
                {
                    currentOptions[j].disabled = true;
                }
                // find previously selected option in current element and enable it
                // if (itemValue != oldItemValue && currentOptions[j].value == oldItemValue)
                else if (currentOptions[j].value == oldItemValue)
                {
                    currentOptions[j].disabled = false;
                }
            }
        }
    }

    if (itemValue == "FileOrFolder")
    {
        showPathInput(itemID, SCAN_ITEM_FILE_FOLDER, true);
        validatePath(itemID);
    }
    else
    {
        showPathInput(itemID, 0, false);
    }

    // save newly selected option so that we can enable the old option when we get the change event
    document.getElementById("locationsList_hiddenvalue_" + itemID).value = itemValue;
    updateLocationIDList();
    onChange();
}

// ===========================================================================
// ===========================================================================
function updateLocationIDList()
{
    // update the hidden list of element ID's containing values
    var myrows = g_locationsAddWidget.getList();
    var elementIDList = "";
    for (var i in myrows)
    {
        var currentItemID = myrows[i].replace("locationsList_awrow_", "");
        var currentElement = $("select_location_" + currentItemID);

        if (currentElement.value == "FileOrFolder")
        {
            elementIDList += ("item_path_" + currentItemID);
        }
        else
        {
            elementIDList += ("select_location_" + currentItemID);
        }
        elementIDList += ",";
    }

    $("hiddenID_LocationItemIDList").value = elementIDList.substring(0, elementIDList.length - 1);
}

// ===========================================================================
// ===========================================================================
function locationPathOnKeyup(locationPathInput)
{
    var itemValue = locationPathInput.value;
    var itemID = locationPathInput.id.replace("item_path_", "");
    var hiddenSelectValueInput = $("select_hidden_value_");

    validatePath(itemID);
    onChange();
}

// ===========================================================================
// add the backslash to the path if it is missing for folders
// ===========================================================================
function locationPathOnBlur(locationPathInput)
{
    var itemValue = locationPathInput.value;
    var itemID = locationPathInput.id.replace("item_path_", "");
    var scanItemSelectionValue = $("select_location_" + itemID).value;

    if (IsValidODSFile(itemValue))
    {
        if ((scanItemSelectionValue == "FileOrFolder"))
        {
            locationPathInput.value = itemValue;
        }
    }
}

// ===========================================================================
// ===========================================================================
function showPathInput(itemID, scanItemType, bShow)
{
    var pathDivElement = document.getElementById("div_itempath_" + itemID);

    if (pathDivElement != null)
    {
        if (bShow)
        {
            pathDivElement.style.display = "inline";
            if (scanItemType == SCAN_ITEM_FILE_FOLDER)
            {
                $("labelID_path_" + itemID).style.display = "";
            }
            else
            {
                $("labelID_path_" + itemID).style.display = "none";
            }
        }
        else
        {
            pathDivElement.style.display = "none";
        }
    }
}

// ===========================================================================
// Callback function that is called whenever an item is added to the
// ListWidget2 for the exclusion list.
//
// The data that was passed into the Add function when the item was added
// to the list is available in the exclusionList_hiddenvalue_X element.
// This data is parsed and used to select the appropriate type of
// exlcusion and to fill in the necessary data.
//
// INPUT: The container object for the item that was just added to the list.
// ===========================================================================
function Exclusion_AddCallback(newRow)
{
    _DisplayNewRowData(newRow);

    validatePolicy();
    updateExclList();
    enableExclusionButtons();
}

function exclUpdateRowDataCallback(selectedRow)
{
    // Update ExclusionData with data stored in Widget
    var exclItems = g_ExclusionListWidget.getItemList();
    g_arrListExclusionData = new Array();
    for (i = 0; i < exclItems.length; ++i)
    {
        g_arrListExclusionData[i] = exclItems[i].itemData;
    }

    validatePolicy();
    populateExclusionsList();
    updateExclList();
}

// ===========================================================================
// Callback function that is passed into the ListWidget2 to be called whenever
// an item is removed from the exclusion list.
// ===========================================================================
function exclRemoveCallback()
{
    updateExclList();
    validatePolicy();
    enableExclusionButtons();
}

function Exclusion_onSelectionChange()
{
    enableExclusionButtons();
}

function enableExclusionButtons()
{
    var enable = g_ExclusionListWidget.getItemList().length > 0;
    var selected = g_ExclusionListWidget.getSelected() != null;
    OrionCore.setEnabledById("buttonID_EditAPExclusion", selected);
    OrionCore.setEnabledById("buttonID_RemoveExcl", selected);
    OrionCore.setEnabledById("buttonID_ClearExcl", enable);
}

// ===========================================================================
// Updates the hidden exclusion list that stores a list of exclusions
//
// The list is a comma-separated list of exclusions
// ===========================================================================
function updateExclList()
{
    var exclItems = g_ExclusionListWidget.getItemList();
    var szExclusionList = "";

    for (var i = 0; i < exclItems.length; ++i)
    {
        if (exclItems[i].itemData != "")
        {
            szExclusionList += exclItems[i].itemData;
            if ((i + 1) < exclItems.length)
            {
                szExclusionList += Constants.LIST_TOKEN_SPLITTER;
            }
        }
    }
    $("hiddenID_ExclusionList").value = szExclusionList;
}

// ===========================================================================
// Function for custom configuration of dialog when Add Exclusion is clicked
// ===========================================================================
function Exclusion_AddEditConfiguration()
{
    _hideWhenToExcludeContent();
}

// ===========================================================================
// Validates the path element and displays an error if the path is invalid
//
// INPUT: The ID of the path element that contains the value to be checked.
// ===========================================================================
function validatePath(itemID)
{
    var szPath = $("item_path_" + itemID).value;

    if ((szPath == "") || !IsValidODSFile(szPath))
    {
        $("labelID_path_error_" + itemID).style.display = "";
    }
    else
    {
        $("labelID_path_error_" + itemID).style.display = "none";
    }
}

// ===========================================================================
// Check for invalid characters in the filename/folder path
//
// INPUT: The filename/folderpath to be checked.
// RETURNS: true if the path is valid for mac. false otherwise
// ===========================================================================
function IsValidODSFile_mac_linux(szPath)
{
    return ((g_locationsAddWidget.macLicensed || g_locationsAddWidget.linuxLicensed) && (szPath.indexOf('/') === 0));
}


// ===========================================================================
// Check for invalid characters in the filename/folder path
//
// INPUT: The filename/folderpath to be checked.
// RETURNS: true if the path is valid. false otherwise
// ===========================================================================
function IsValidODSFile(szPath)
{
    //1st check for valid mac path and linux path
    var valid = IsValidODSFile_mac_linux(szPath);

    /*
    //Now validate windows paths
    if(!valid)
    {
        valid = IsValidPath(szPath, false) || IsValidFilename(szPath, false);
    }
    return valid;
    */

    //Now validate windows paths
    if (!valid) {
        var r = -1;
        var invalidWinChars = ['/', '"', '|', ';', '*', '?', '<', '>'];
        for (var i = 0; (r === -1) && (i < invalidWinChars.length); ++i) {
            r = szPath.indexOf(invalidWinChars[i]);
        }
        valid = (r === -1);
    }
    return valid;
}

// ===========================================================================
// Function to validate both items that are handled and not handled by Orion
// validatoin
//
// REUTRN: true if the task contains valid data. false otherwise.
// ===========================================================================
function isTaskValid()
{
    var valid = true;
    var myrows = g_locationsAddWidget.getList();
    for (var i in myrows)
    {
        var currentItemID = myrows[i].replace("locationsList_awrow_", "");
        var currentElement = $("select_location_" + currentItemID);

        if (currentElement.value == "FileOrFolder")
        {
            var pathValue = $("item_path_" + currentItemID).value;
            if ((pathValue == "") || !IsValidODSFile(pathValue))
            {
                valid = false;
                break;
            }
        }
    }

    if (valid)
    {
        // if still valid, use orion validation to determine whether or not the task is valid.
        // this will work only for items that have an onvalidate attribute.
        valid = OrionForm.isFormValid();
    }

    return valid;
}

// ===========================================================================
// Generic event handler for items that do not need specific handling when
// their state is changed.
// ===========================================================================
function onChange()
{
    validatePolicy();
}

// ==========================================================`=================
// Called by orion whenever the state of the form changes (checkbox checked,
// textbox edited, etc.)
//
// We use this to determine whether or not the Save button should be
// enabled
// ===========================================================================
function taskStateChangeHandler(isDirty, isValid)
{
    if (isValid)
    {
        isValid = validatePassword()
    }

    if (isValid && g_locationsAddWidget != null)
    {
        isValid = validateScanLocations(g_locationsAddWidget.getList());
    }

    if (isValid)
    {
       isValid = isTaskValid();
    }

    if (isValid)
    {
        if ($("bEnforceMaxScanTime").checked && $("uScannerThreadTimeOut").value == "")
        {
            isValid = false;
        }
    }
	if (isValid)
    {
        if ($("bEnforceMaxODSThreads").checked && $("uScannerMaxODSThreads").value == "")
        {
            isValid = false;
        }
    }
    // this function taskStateChangeHandler can be called by us or by MFS directly.  If MFS calls us directly,
    // it has already called it's isValid function and calling it a second time is
    // redundant.  But we if call this function, we have to include MFS in the validators.
    if (isValid)
    {
        isValid = OrionForm.isFormValid();
    }

    if (isValid && isDirty)
    {
        OrionWizard.enableNavigation();
    }
    else
    {
        OrionWizard.disableNavigation();
    }
}

// ===========================================================================
// Validator for File Types text boxes
//
// ===========================================================================
function validateFileTypes(szFileTypes)
{
    var valid = true;
    var filetypelen = 0;
    var wildcharlen = 0;

    if (szFileTypes != "")
    {
        // convert whitespace to spaces
        szFileTypes.replace(/\W+/g, ' ');
        var szFileTypeTokens = szFileTypes.split(" ");

        var r = szFileTypes.indexOf("/");

        if (r == -1)
        {
            r = szFileTypes.indexOf("\"");
        }

        if (r == -1)
        {
            r = szFileTypes.indexOf("|");
        }

        if (r == -1)
        {
            r = szFileTypes.indexOf("<");
        }

        if (r == -1)
        {
            r = szFileTypes.indexOf(">");
        }

        if (r == -1)
        {
            r = szFileTypes.indexOf("\\");
        }

        //We do not allow * for filetypes.

        if (r == -1)
        {
            r = szFileTypes.indexOf("*");
        }

        //We do not allow only ? for filetype, for eg: ?, ???
        if (r == -1)
        {
            filetypelen = szFileTypes.length;

            for (var i = 0; i < filetypelen; i++)
            {
                if (szFileTypes.charAt(i) == "?")
                {
                    wildcharlen++;
                }
            }

            if (filetypelen == wildcharlen)
            {
                valid = false;
            }
        }

        if (r != -1)
        {
            valid = false;
        }

        for (var i = 0; valid && (i < szFileTypeTokens.length); ++i)
        {
            if (szFileTypeTokens[i] != ":::")
            {
                r = szFileTypeTokens[i].indexOf(":");
                if (r != -1)
                {
                    valid = false;
                }
            }
        }

    }

    return valid;
}

function validateScanLocations(scanLocationRows)
{
    var valid = true;
    for (var i in scanLocationRows)
    {
        var currentItemID = scanLocationRows[i].replace("locationsList_awrow_", "");
        var locationSelection = $("select_location_" + currentItemID).selectedIndex;
        $("select_location_" + currentItemID + "_empty").style.display = "none";

        if (locationSelection == ACTION_VALUE_INVALID)
        {
            $("select_location_" + currentItemID + "_empty").style.display = "";
            valid = false;
        }

        if (locationSelection == SCAN_ITEM_FILE_FOLDER)
        {
            var szFileName = $("item_path_" + currentItemID).value;
            if (szFileName == null || szFileName == "")
            {
                valid = false;
            }

            if (!IsValidODSFile(szFileName))
            {
                valid = false;
            }
        }
    }

    return valid;
}

// ************************************************************************
// ************************************************************************
// Exclusion DialogBox support code
// ************************************************************************
// ************************************************************************

function validateMaxDeferTime(szMaxDeferTime)
{
    if (document.getElementById("checkboxID_PermitUserDefer").checked == false)
    {
        return true;
    }

    if (szMaxDeferTime == null || szMaxDeferTime == "")
    {
        return false;
    }

    return OrionValidate.isIntString(szMaxDeferTime) && OrionValidate.isIntBetween(szMaxDeferTime, 1, 23);
}

function validateMessageDurationTime(szMessageDurationTime)
{
    if (document.getElementById("checkboxID_PermitUserDefer").checked == false)
    {
        return true;
    }

    if (szMessageDurationTime == null || szMessageDurationTime == "")
    {
        return false;
    }

    return OrionValidate.isIntString(szMessageDurationTime) && OrionValidate.isIntBetween(szMessageDurationTime, 30, 300);
}
function validateMaxScanTime(szMaxScanTime)
{
    var valid = true;

    if($("bEnforceMaxScanTime").checked == false)
    {
        return true;
    }

    if(szMaxScanTime == null || szMaxScanTime == "")
    {
        valid = false;
    }

    if(valid)
    {
        valid = OrionValidate.isIntString(szMaxScanTime) && OrionValidate.isIntBetween(szMaxScanTime, 10, 9999);
    }

    return valid;
}
function validateMaxODSThreads(szMaxODSThreads)
{
    var valid = true;

    if($("bEnforceMaxODSThreads").checked == false)
    {
        return true;
    }

    if(szMaxODSThreads == null || szMaxODSThreads == "")
    {
        valid = false;
    }

    if(valid)
    {
        valid = OrionValidate.isIntString(szMaxODSThreads) && OrionValidate.isIntBetween(szMaxODSThreads, 1, 9999);
    }

    return valid;
}

function validateCPUPercentage(szCPUPercentage)
{
    var valid = true;

    if($("radio_CPUScanThrottle").checked == false)
    {
        return true;
    }

    if(szCPUPercentage == null || szCPUPercentage == "")
    {
        valid = false;
    }

    if(valid)
    {
        valid = OrionValidate.isIntString(szCPUPercentage) && OrionValidate.isIntBetween(szCPUPercentage, 25, 99);
    }

    return valid;
}
