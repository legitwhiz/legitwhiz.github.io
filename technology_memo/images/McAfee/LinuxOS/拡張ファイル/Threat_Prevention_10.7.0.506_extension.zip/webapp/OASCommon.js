//Copyright (C) 2017 McAfee, Inc.  All rights reserved.
//

// "ExtensionMode" enumeration
var g_ExtensionMode = 0;
var g_AllFiles      = 1;
var g_Default       = 2;
var g_DefaultPlus   = 3;
var g_Specified     = 4;

 // Exclusions constants to OR against the "flags" value..
var ON_READ 		= 2;
var ON_WRITE		= 1;
var INCLUDE_SUBFOLDERS	= 4;

var ACTION_VALUE_INVALID	= 0;
var ACTION_VALUE_CLEAN		= 1;
var ACTION_VALUE_DELETE		= 2;
var ACTION_VALUE_DENY		= 3;
var ACTION_VALUE_ALLOW      = 4;
var ACTION_VALUE_CONTINUE	= 6;


var g_iCurrentPrimaryActionValue 			= 0;
var g_iCurrentPrimaryActionUnwantedValue 	= 0;
//var g_iCurrentPrimaryActionBehavioralValue 	= 0;
var g_iCurrentSecondaryActionValue			= 0;
var g_iCurrentSecondaryActionUnwantedValue	= 0;
//var g_iCurrentSecondaryActionBehavioralValue	= 0;

// Global DOM objects
var g_primaryActionSelect;
var g_secondaryActionSelect;
var g_primaryActionSelectUnwanted;
var g_secondaryActionSelectUnwanted;
//var g_primaryActionSelectBehavioral;
//var g_secondaryActionSelectBehavioral;

// Exclusions
var g_bNewExclusion = false;
var g_ExclusionListWidget;
var g_ExclusionsByRisk = new Array();
g_ExclusionsByRisk[0] = new Array();
g_ExclusionsByRisk[1] = new Array();
g_ExclusionsByRisk[2] = new Array();

ExclusionDataItem = function(obj)
{
    var exclData = "";
};

var uAction;
var uSecAction;
var dwMacroHeuristicsLevel;
var dwProgramHeuristicsLevel;
var ScanArchives;
var ScanMime;
var ScanBackupReads;
var bNetworkScanEnabled;
var bScanWriting;
var bScanReading;
var ExtensionMode;
var szProgExts;
var bOverwriteExclusions;
var ApplyNVP;
var uAction_Program;
var uSecAction_Program;
var uTimeOutAction;
var uScanErrorAction;
//var bBehavioral;
//var uAction_Behavioral;
//var uSecAction_Behavioral;

function fnApplyPolicySuccess()
{
    fnGoBack();
}

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
}

function enableExclusionButtons()
{
    var enable = g_ExclusionListWidget.getItemList().length > 0;
    var selected = g_ExclusionListWidget.getSelected() != null;
    OrionCore.setEnabledById("buttonID_EditAPExclusion", selected);
    OrionCore.setEnabledById("buttonID_RemoveExcl", selected);
    OrionCore.setEnabledById("buttonID_ClearExcl", enable);
}

function Exclusion_onSelectionChange()
{
    enableExclusionButtons();
}

function Exclusion_AddCallback(newRow)
{
    _DisplayNewRowData(newRow);
    enableExclusionButtons();
    validatePolicy();
}

function exclUpdateRowDataCallback(selectedRow)
{
    // Update ExclusionData with data stored in Widget
    var exclItems = g_ExclusionListWidget.getItemList();
    g_ExclusionsByRisk[g_CurrentProcessType]= new Array();
    for(i = 0; i < exclItems.length; ++i)
    {
        g_ExclusionsByRisk[g_CurrentProcessType][i] = exclItems[i].itemData;
    }

    populateExclusionsList(g_CurrentProcessType);
}

function exclRemoveCallback()
{
    enableExclusionButtons();
    validatePolicy();
}

function Exclusion_AddEditConfiguration()
{
    // remove the Access option from the Access type dropdown for age.
    if ($("selectID_AccessType").options.length > 2)
    {
        $("selectID_AccessType").options[1] = null;
    }
}

function fnSetPrimaryAction(selectID_CurrentAction, iPrimaryValue)
{
	for (var i = 0; i < selectID_CurrentAction.length; i++)
	{
		if ( parseInt(selectID_CurrentAction.options[i].value) == parseInt(iPrimaryValue) )
		{
			selectID_CurrentAction.selectedIndex = i;
		}
	}
}

function fnSetSecondaryActionValue(selectID_CurrentSecondaryAction, iSecondaryValue)
{
	for(var i=0; i<selectID_CurrentSecondaryAction.length;i++)
	{
		if (selectID_CurrentSecondaryAction.options[i].value == iSecondaryValue)
		{
			selectID_CurrentSecondaryAction.selectedIndex = i;
		}
	}
}

function fnSecondaryAction_OnChange(selectID_CurrentSecondaryAction, iSecondaryValue, bPromptForDelete)
{
    if( selectID_CurrentSecondaryAction == g_secondaryActionSelect )
    {
        g_iCurrentSecondaryActionValue = iSecondaryValue;
    }
    else if( selectID_CurrentSecondaryAction == g_secondaryActionSelectUnwanted )
    {
        g_iCurrentSecondaryActionUnwantedValue = iSecondaryValue;
    }
/*    else if( selectID_CurrentSecondaryAction == g_secondaryActionSelectBehavioral )
    {
        g_iCurrentSecondaryActionBehavioralValue = iSecondaryValue;
    }*/

    fnSetSecondaryActionValue(selectID_CurrentSecondaryAction, iSecondaryValue);
}

function fnApplyNVPChange()
{
    fnToggleApplyNVPState();
    validatePolicy();
}

function fnToggleApplyNVPState()
{
    $("selectID_UnwantedPrimaryAction").disabled = false;
    $("selectID_UnwantedSecondaryAction").disabled = false;

    if ($("checkboxID_ApplyNVP").checked)
    {
        $("selectID_UnwantedPrimaryAction").disabled = false;

        if(($("selectID_UnwantedPrimaryAction").value != ACTION_VALUE_ALLOW)&&
           ($("selectID_UnwantedPrimaryAction").value != ACTION_VALUE_DENY))
        {
            $("selectID_UnwantedSecondaryAction").disabled = false;
        }
        else
        {
            $("selectID_UnwantedSecondaryAction").disabled = true;
        }
    }
    else
    {
        $("selectID_UnwantedPrimaryAction").disabled = true;
        $("selectID_UnwantedSecondaryAction").disabled = true;
    }
}

/*function fnApplyBehavioralChange()
{
    fnToggleApplyBehavioralState();
    validatePolicy();
}

function fnToggleApplyBehavioralState()
{
    $("selectID_BehavioralPrimaryAction").disabled = false;
    $("selectID_BehavioralSecondaryAction").disabled = false;

    if ($("checkboxID_bBehavioral").checked)
    {
        $("selectID_BehavioralPrimaryAction").disabled = false;

        if(($("selectID_BehavioralPrimaryAction").value != ACTION_VALUE_ALLOW)&&
           ($("selectID_BehavioralPrimaryAction").value != ACTION_VALUE_DENY))
        {
            $("selectID_BehavioralSecondaryAction").disabled = false;
        }
        else
        {
            $("selectID_BehavioralSecondaryAction").disabled = true;
        }
    }
    else
    {
        $("selectID_BehavioralPrimaryAction").disabled = true;
        $("selectID_BehavioralSecondaryAction").disabled = true;
    }
}*/

function validateFileTypes(szFileTypes)
{
    var valid = true;
    var filetypelen = 0;
    var wildcharlen = 0;

    if(szFileTypes != "")
    {
        // convert whitespace to spaces
        szFileTypes.replace(/\W+/g,' ');
        var szFileTypeTokens = szFileTypes.split(" ");

        var r = szFileTypes.indexOf("/");

        if (r == -1)
            r = szFileTypes.indexOf("\"");

        if (r == -1)
            r = szFileTypes.indexOf("|");

        if (r == -1)
            r = szFileTypes.indexOf("<");

        if (r == -1)
            r = szFileTypes.indexOf(">");

        if (r == -1)
            r = szFileTypes.indexOf("\\");

//We do not allow * for filetypes.

        if (r == -1)
            r = szFileTypes.indexOf("*");

//We do not allow only ? for filetype, for eg: ?, ???
        if (r == -1)
        {
           filetypelen = szFileTypes.length;

           for(var i=0; i<filetypelen; i++)
           {
                if(szFileTypes.charAt(i) == "?")
                {
                    wildcharlen++;
                }
            }

            if(filetypelen == wildcharlen)
                valid = false;
        }

        if(r != -1)
        {
            valid = false;
        }

        for(var i=0; valid && (i < szFileTypeTokens.length); ++i)
        {
            if(szFileTypeTokens[i] != ":::") 
            {
                r = szFileTypeTokens[i].indexOf(":");
                if (r != -1)
                {
                    valid = false;
                }
            }
        }

    }

    return valid;
}

