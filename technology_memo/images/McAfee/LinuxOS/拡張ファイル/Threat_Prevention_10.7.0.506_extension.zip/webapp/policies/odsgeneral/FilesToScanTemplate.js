//Copyright (C) 2017 McAfee, Inc.  All rights reserved.
//

function initODSFilesTypesTemplate(extensionMode, progExts, scanMode)
{
    if (scanMode == G_SCAN_MODE_FS)
    {
        var allFilesRadio = document.getElementById("FSradioID_AllFiles");
        var defaultFilesRadio = document.getElementById("FSradioID_DefaultAndSpecified");
        var specifiedFilesRadio = document.getElementById("FSradioID_SpecifiedOnly");
        var scanForMacrosCheckbox = document.getElementById("FScheckboxID_ScanForMacros");
        var additionalFileTypesTextArea = document.getElementById("FStextareaID_AdditionalFileTypes");
        var specifiedFileTypesTextArea = document.getElementById("FStextareaID_SpecifiedFileTypes");
        var additionalNoExtensionCheckBox = document.getElementById("FScheckboxID_AdditionalNoExtension");
        var specifiedNoExtensionCheckBox = document.getElementById("FScheckboxID_SpecifiedNoExtension");
    }
    else if (scanMode == G_SCAN_MODE_QS)
    {
        var allFilesRadio = document.getElementById("QSradioID_AllFiles");
        var defaultFilesRadio = document.getElementById("QSradioID_DefaultAndSpecified");
        var specifiedFilesRadio = document.getElementById("QSradioID_SpecifiedOnly");
        var scanForMacrosCheckbox = document.getElementById("QScheckboxID_ScanForMacros");
        var additionalFileTypesTextArea = document.getElementById("QStextareaID_AdditionalFileTypes");
        var specifiedFileTypesTextArea = document.getElementById("QStextareaID_SpecifiedFileTypes");
        var additionalNoExtensionCheckBox = document.getElementById("QScheckboxID_AdditionalNoExtension");
        var specifiedNoExtensionCheckBox = document.getElementById("QScheckboxID_SpecifiedNoExtension");
    }
    else if (scanMode == G_SCAN_MODE_RS)
    {
        var allFilesRadio = document.getElementById("RSradioID_AllFiles");
        var defaultFilesRadio = document.getElementById("RSradioID_DefaultAndSpecified");
        var specifiedFilesRadio = document.getElementById("RSradioID_SpecifiedOnly");
        var scanForMacrosCheckbox = document.getElementById("RScheckboxID_ScanForMacros");
        var additionalFileTypesTextArea = document.getElementById("RStextareaID_AdditionalFileTypes");
        var specifiedFileTypesTextArea = document.getElementById("RStextareaID_SpecifiedFileTypes");
        var additionalNoExtensionCheckBox = document.getElementById("RScheckboxID_AdditionalNoExtension");
        var specifiedNoExtensionCheckBox = document.getElementById("RScheckboxID_SpecifiedNoExtension");
    }

    allFilesRadio.checked = (extensionMode == 1);
    defaultFilesRadio.checked = (extensionMode == 2 || extensionMode == 3);
    specifiedFilesRadio.checked = (!allFilesRadio.checked && !defaultFilesRadio.checked);
    scanForMacrosCheckbox.checked = (extensionMode == 3);

    if (allFilesRadio.checked)
    {
        fnODSWhatToScanOnChange(allFilesRadio.value, scanMode);
    }
    else
    if (defaultFilesRadio.checked)
    {

        initFileTypesTextArea(progExts, additionalFileTypesTextArea,specifiedFileTypesTextArea,
            additionalNoExtensionCheckBox, specifiedNoExtensionCheckBox);

        if (scanForMacrosCheckbox.checked)
        {
            fnODSWhatToScanOnChange("defaultPlusFiles", scanMode);
        }
        else
        {
            fnODSWhatToScanOnChange(defaultFilesRadio.value, scanMode);
        }
    }
    else
    {
        initFileTypesTextArea(progExts, specifiedFileTypesTextArea, additionalFileTypesTextArea,
            specifiedNoExtensionCheckBox, additionalNoExtensionCheckBox);

        fnODSWhatToScanOnChange(specifiedFilesRadio.value, scanMode);
    }
}

function fnODSWhatToScanOnChange(scanType, scanMode)
{
    if (scanMode == G_SCAN_MODE_QS)
    {
        var addtionalFilesDiv = document.getElementById("QSdiv_AdditionalFileTypes");
        var specifiedFilesDiv = document.getElementById("QSdiv_SpecifiedFileTypes");
        var scanForMacrosCheckbox = document.getElementById("QScheckboxID_ScanForMacros");
        var additionalNoExtensionCheckbox = document.getElementById("QScheckboxID_AdditionalNoExtension");
        var additionalNoExtensionCheckboxLabel = document.getElementById("QScheckboxID_AdditionalNoExtension_label");
        var specifiedNoExtensionCheckbox = document.getElementById("QScheckboxID_SpecifiedNoExtension");
        var textareaIDSpecifiedFileTypes = "QStextareaID_SpecifiedFileTypes";
    }
    else if (scanMode == G_SCAN_MODE_FS)
    {
        var addtionalFilesDiv = document.getElementById("FSdiv_AdditionalFileTypes");
        var specifiedFilesDiv = document.getElementById("FSdiv_SpecifiedFileTypes");
        var scanForMacrosCheckbox = document.getElementById("FScheckboxID_ScanForMacros");
        var additionalNoExtensionCheckbox = document.getElementById("FScheckboxID_AdditionalNoExtension");
        var additionalNoExtensionCheckboxLabel = document.getElementById("FScheckboxID_AdditionalNoExtension_label");
        var specifiedNoExtensionCheckbox = document.getElementById("FScheckboxID_SpecifiedNoExtension");
        var textareaIDSpecifiedFileTypes = "FStextareaID_SpecifiedFileTypes";
    }
    else if (scanMode == G_SCAN_MODE_RS)
    {
        var addtionalFilesDiv = document.getElementById("RSdiv_AdditionalFileTypes");
        var specifiedFilesDiv = document.getElementById("RSdiv_SpecifiedFileTypes");
        var scanForMacrosCheckbox = document.getElementById("RScheckboxID_ScanForMacros");
        var additionalNoExtensionCheckbox = document.getElementById("RScheckboxID_AdditionalNoExtension");
        var additionalNoExtensionCheckboxLabel = document.getElementById("RScheckboxID_AdditionalNoExtension_label");
        var specifiedNoExtensionCheckbox = document.getElementById("RScheckboxID_SpecifiedNoExtension");
        var textareaIDSpecifiedFileTypes = "RStextareaID_SpecifiedFileTypes";
    }

    //OrionForm.setFieldRequired("QStextareaID_SpecifiedFileTypes", false);
    requireSpecifiedFileTypes(textareaIDSpecifiedFileTypes, false);

    if (scanType == "defaultFiles")
    {
        addtionalFilesDiv.style.display = "inline";
        specifiedFilesDiv.style.display = "none";
        scanForMacrosCheckbox.checked = false;
        specifiedNoExtensionCheckbox.checked = false;
        additionalNoExtensionCheckbox.style.display = "none";
        additionalNoExtensionCheckboxLabel.style.display = "none";
    }
    else
    if (scanType == "defaultPlusFiles")
    {
        addtionalFilesDiv.style.display = "inline";
        specifiedFilesDiv.style.display = "none";
        specifiedNoExtensionCheckbox.checked = false;
        additionalNoExtensionCheckbox.style.display = "none";
        additionalNoExtensionCheckboxLabel.style.display = "none";
    }
    else
    if (scanType == "specifiedFiles")
    {
        addtionalFilesDiv.style.display = "none";
        specifiedFilesDiv.style.display = "inline";
        scanForMacrosCheckbox.checked = false;
        additionalNoExtensionCheckbox.checked = false;
        requireSpecifiedFileTypes(textareaIDSpecifiedFileTypes, !(document.getElementById("QScheckboxID_SpecifiedNoExtension").checked));
    }
    else
    {
        addtionalFilesDiv.style.display = "none";
        specifiedFilesDiv.style.display = "none";
        scanForMacrosCheckbox.checked = false;
        additionalNoExtensionCheckbox.checked = false;
        specifiedNoExtensionCheckbox.checked = false;
    }
}

function requireSpecifiedFileTypes(textareaID_SpecifiedFileTypes, require)
{
    OrionForm.setFieldRequired(textareaID_SpecifiedFileTypes, require);
}

function initFileTypesTextArea(progExts, setFileTypes, clearFileTypes, setCheckBox, clearCheckBox)
{
    if (progExts.indexOf(":::") != -1)
    {
        setFileTypes.value = removeNoExtensionMarker(progExts);
        clearFileTypes.value = "";
        setCheckBox.checked = true;
        clearCheckBox.checked = false;
    }
    else
    {
        setFileTypes.value = progExts;
        clearFileTypes.value = "";
        setCheckBox.checked = false;
        clearCheckBox.checked = false;
    }
}

// *******************************************************************
// removeNoExtensionMarker - Removes all ::: entries
//
// Input: szExtensions - semi-colon delimited list of extensions
//
// Returns: A semi-colon delimited list of extensions with ::: removed
// *******************************************************************
function removeNoExtensionMarker(szExtensions)
{
    var szReturn = "";
    var szExtItems = szExtensions.split(/,+/);
    szExtItems = szExtItems.sort();

    for (var i = 0; i < szExtItems.length; ++i)
    {
       if (szExtItems[i] != ":::")
       {
           if ( szReturn.length > 0 )
           {
               szReturn += ",";
           }
           szReturn += szExtItems[i];

       }
    }

   return szReturn;
}