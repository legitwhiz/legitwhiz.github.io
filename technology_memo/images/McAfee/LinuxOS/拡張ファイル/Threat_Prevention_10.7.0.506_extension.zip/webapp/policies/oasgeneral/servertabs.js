//Copyright (C) 2017 McAfee, Inc.  All rights reserved.
//

var tabs = function(){

  return{
    info : null,
    target : null,
    name : null,
    height : null,
    width : null,

    create : function(obj){

        this.target = document.getElementById(obj.target);
        this.info = obj.info;
        this.name = obj.name;
        this.height = obj.height;
        this.width = obj.width;

        for(var i=this.info.length-1; i>=0; i--){
            var tab = document.createElement("div");
            tab.setAttribute('id',this.name+'tab'+i);
            tab.className = 'taboff';
            var html = this.info[i].label;
            tab.innerHTML = html;

            var self = this;
            tab.onclick = function(){
                if(!disableNonDefaultTabs)
                {
                    for (var i = 0; i < self.info.length; i++) {
                        var tab = document.getElementById(self.name+'tab'+i);
                        var content = document.getElementById(self.info[i].content);
                        if(tab==this){
                            tab.className = "tabon";
                            onPolicyTypeToggle(i);
                        }else{
                            tab.className = "taboff";
                        }
                    }
                }
            };

            tab.style.height = "18px";
            this.target.insertBefore(tab, this.target.firstChild);

            var cont = document.getElementById(this.info[i].content);
            cont.style.left = 0;
            cont.style.display = 'none';
            cont.style.width = this.width;
            cont.style.top = (tab.offsetHeight - 1) + 'px';
        }

        document.getElementById(this.name+'tab0').className = "tabon";
        document.getElementById(this.info[0].content).style.display='block';
	}
  };
}

function displayDefaultTab()
{
    var tab0 = document.getElementById('demo2tab0');
    tab0.className = "tabon";
    var tab1 = document.getElementById('demo2tab1');
    tab1.className = "taboff";
    var tab2 = document.getElementById('demo2tab2');
    tab2.className = "taboff";
}

function greyOutNonDefaultTabs(action)
{
    if (action)
    {
        var tab1 = document.getElementById('demo2tab1');
        tab1.className = "tabdisabled";
        var tab2 = document.getElementById('demo2tab2');
        tab2.className = "tabdisabled";
    }
    else
    {
        var tab1 = document.getElementById('demo2tab1');
        tab1.className = "taboff";
        var tab2 = document.getElementById('demo2tab2');
        tab2.className = "taboff";
    }
}

function showtabs(defaultTabName, highRiskTabName, lowRiskTabName){
	var tab1 = tabs();
	tab1.create(
		{
			name : "demo2",
			target:"tabdiv2",
			width : "530px",
			info:[
				{label:defaultTabName , content: "ctab1"},
				{label:highRiskTabName , content: "ctab2"},
				{label:lowRiskTabName , content: "ctab3"}
			]
		}
	);
}
