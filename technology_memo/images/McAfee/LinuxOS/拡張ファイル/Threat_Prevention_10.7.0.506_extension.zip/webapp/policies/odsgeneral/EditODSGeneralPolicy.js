//Copyright (C) 2017 McAfee, Inc.  All rights reserved.
//

var g_bNewExclusion = false;
var g_FSExclusionListWidget;
var g_QSExclusionListWidget;
var g_RSExclusionListWidget;
var g_FSExclusions = new Array();
var g_QSExclusions = new Array();
var g_RSExclusions = new Array();
var FSdwScannerThreadTimeout;
// Exclusions constants to OR against the "flags" value..
var ON_READ 		= 2;
var ON_WRITE		= 1;
var INCLUDE_SUBFOLDERS	= 4;

ExclusionDataItem = function(obj)
{
    var exclData = "";
};

var g_FSlocationsAddWidget;
var g_QSlocationsAddWidget;

// Note: these values only appear in the registry and should NOT be localized.
var g_FSScanItemValues = new Array();
g_FSScanItemValues[0] = "Invalid";
g_FSScanItemValues[1] = "SpecialScanForRootkits";
g_FSScanItemValues[2] = "SpecialMemory";
g_FSScanItemValues[3] = "SpecialCritical";
g_FSScanItemValues[4] = "My Computer";
g_FSScanItemValues[5] = "LocalDrives";
g_FSScanItemValues[6] = "All fixed disks";
g_FSScanItemValues[7] = "All removable media";
g_FSScanItemValues[8] = "All Network drives";
g_FSScanItemValues[9] = "HomeDir";
g_FSScanItemValues[10] = "ProfileDir";
g_FSScanItemValues[11] = "WinDir";
g_FSScanItemValues[12] = "ProgramFilesDir";
g_FSScanItemValues[13] = "TempDir";
g_FSScanItemValues[14] = "SpecialRecycleName";
g_FSScanItemValues[15] = "FileOrFolder";
g_FSScanItemValues[16] = "SpecialRegistry";

//var SCAN_ITEM_FOLDER = 15;
var FS_SCAN_ITEM_INVALID = 0;
var FS_SCAN_ITEM_FILE_OR_FOLDER = 15;
var FS_SCAN_ITEM_REGISTRY = 16;
var FS_SCAN_ITEM_COOKIES = 17;

var g_QSScanItemValues = new Array();
g_QSScanItemValues[0] = "Invalid";
g_QSScanItemValues[1] = "SpecialScanForRootkits";
g_QSScanItemValues[2] = "SpecialMemory";
g_QSScanItemValues[3] = "SpecialCritical";
g_QSScanItemValues[4] = "All removable media";
g_QSScanItemValues[5] = "HomeDir";
//g_QSScanItemValues[6] = "ProfileDir";
g_QSScanItemValues[6] = "WinDir";
//g_QSScanItemValues[8] = "ProgramFilesDir";
g_QSScanItemValues[7] = "TempDir";
g_QSScanItemValues[8] = "FileOrFolder";
g_QSScanItemValues[9] = "SpecialRegistry";

//var SCAN_ITEM_FOLDER = 15;
var QS_SCAN_ITEM_INVALID = 0;
var QS_SCAN_ITEM_FILE_OR_FOLDER = 8;
var QS_SCAN_ITEM_REGISTRY = 9;
var QS_SCAN_ITEM_COOKIES = 10;

function enableFSExclusionButtons()
{
    var enable = g_FSExclusionListWidget.getItemList().length > 0;
    var selected = g_FSExclusionListWidget.getSelected() != null;
    OrionCore.setEnabledById("FSbuttonID_EditAPExclusion", selected);
    OrionCore.setEnabledById("FSbuttonID_RemoveExcl", selected);
    OrionCore.setEnabledById("FSbuttonID_ClearExcl", enable);
}
function enableQSExclusionButtons()
{
    var enable = g_QSExclusionListWidget.getItemList().length > 0;
    var selected = g_QSExclusionListWidget.getSelected() != null;
    OrionCore.setEnabledById("QSbuttonID_EditAPExclusion", selected);
    OrionCore.setEnabledById("QSbuttonID_RemoveExcl", selected);
    OrionCore.setEnabledById("QSbuttonID_ClearExcl", enable);
}
function enableRSExclusionButtons()
{
    var enable = g_RSExclusionListWidget.getItemList().length > 0;
    var selected = g_RSExclusionListWidget.getSelected() != null;
    OrionCore.setEnabledById("RSbuttonID_EditAPExclusion", selected);
    OrionCore.setEnabledById("RSbuttonID_RemoveExcl", selected);
    OrionCore.setEnabledById("RSbuttonID_ClearExcl", enable);
}

function FSExclusion_AddCallback(newRow)
{
    FS_DisplayNewRowData(newRow);
    enableFSExclusionButtons();
    validatePolicy();
}

function QSExclusion_AddCallback(newRow)
{
    QS_DisplayNewRowData(newRow);
    enableQSExclusionButtons();
    validatePolicy();
}

function RSExclusion_AddCallback(newRow)
{
    RS_DisplayNewRowData(newRow);
    enableRSExclusionButtons();
    validatePolicy();
}

function FSexclUpdateRowDataCallback(selectedRow)
{
    // Update ExclusionData with data stored in Widget
    var exclItems = g_FSExclusionListWidget.getItemList();
    g_FSExclusions = new Array();
    for(var i = 0; i < exclItems.length; ++i)
    {
        g_FSExclusions[i] = exclItems[i].itemData;
    }

    populateFSExclusionsList();
}

function populateFSExclusionsList()
{
    g_FSExclusionListWidget.clearList();

    if (g_FSExclusions.length > 0)
    {
        for (var i = 0; i < g_FSExclusions.length; ++i)
        {
            var item = new VSE.ListItem2();
            item.itemData = g_FSExclusions[i];
            g_FSExclusionListWidget.add(item);
        }
    }
    enableFSExclusionButtons();
}

function QSexclUpdateRowDataCallback(selectedRow)
{
    // Update ExclusionData with data stored in Widget
    var exclItems = g_QSExclusionListWidget.getItemList();
    g_QSExclusions = new Array();
    for(var i = 0; i < exclItems.length; ++i)
    {
        g_QSExclusions[i] = exclItems[i].itemData;
    }

    populateQSExclusionsList();
}

function populateQSExclusionsList()
{
    g_QSExclusionListWidget.clearList();

    if (g_QSExclusions.length > 0)
    {
        for (var i = 0; i < g_QSExclusions.length; ++i)
        {
            var item = new VSE.ListItem2();
            item.itemData = g_QSExclusions[i];
            g_QSExclusionListWidget.add(item);
        }
    }
    enableQSExclusionButtons();
}

function RSexclUpdateRowDataCallback(selectedRow)
{
    // Update ExclusionData with data stored in Widget
    var exclItems = g_RSExclusionListWidget.getItemList();
    g_RSExclusions = new Array();
    for(var i = 0; i < exclItems.length; ++i)
    {
        g_RSExclusions[i] = exclItems[i].itemData;
    }

    populateRSExclusionsList();
}

function populateRSExclusionsList()
{
    g_RSExclusionListWidget.clearList();

    if (g_RSExclusions.length > 0)
    {
        for (var i = 0; i < g_RSExclusions.length; ++i)
        {
            var item = new VSE.ListItem2();
            item.itemData = g_RSExclusions[i];
            g_RSExclusionListWidget.add(item);
        }
    }
    enableRSExclusionButtons();
}

function FSExclusion_RemoveCallback()
{
    enableFSExclusionButtons();
    validatePolicy();
}

function QSExclusion_RemoveCallback()
{
    enableQSExclusionButtons();
    validatePolicy();
}

function RSExclusion_RemoveCallback()
{
    enableRSExclusionButtons();
    validatePolicy();
}

function FSExclusion_onSelectionChange()
{
    enableFSExclusionButtons();
}

function QSExclusion_onSelectionChange()
{
    enableQSExclusionButtons();
}
function RSExclusion_onSelectionChange()
{
    enableRSExclusionButtons();
}

function writeHiddenData()
{
    var szExclusionList = "";
    var exclItems;
    var i;

    exclItems = g_FSExclusionListWidget.getItemList();
    g_FSExclusions = new Array();
    for(i = 0; i < exclItems.length; ++i)
    {
        g_FSExclusions[i] = exclItems[i].itemData;
    }

    for(i = 0; i < g_FSExclusions.length; ++i)
    {
        szExclusionList += g_FSExclusions[i];
        if((i+1) < g_FSExclusions.length)
        {
            //szExclusionList += Constants.LIST_TOKEN_SPLITTER;
            szExclusionList += "zzzTOKENzzz";
        }
    }
    $("hiddenID_FSExclusionList").value = szExclusionList;

    szExclusionList = "";
    exclItems = g_QSExclusionListWidget.getItemList();
    g_QSExclusions = new Array();
    for(i = 0; i < exclItems.length; ++i)
    {
        g_QSExclusions[i] = exclItems[i].itemData;
    }

    for(i = 0; i < g_QSExclusions.length; ++i)
    {
        szExclusionList += g_QSExclusions[i];
        if((i+1) < g_QSExclusions.length)
        {
            //szExclusionList += Constants.LIST_TOKEN_SPLITTER;
            szExclusionList += "zzzTOKENzzz";
        }
    }
    $("hiddenID_QSExclusionList").value = szExclusionList;

    szExclusionList = "";
    exclItems = g_RSExclusionListWidget.getItemList();
    g_RSExclusions = new Array();
    for(i = 0; i < exclItems.length; ++i)
    {
        g_RSExclusions[i] = exclItems[i].itemData;
    }

    for(i = 0; i < g_RSExclusions.length; ++i)
    {
        szExclusionList += g_RSExclusions[i];
        if((i+1) < g_RSExclusions.length)
        {
            //szExclusionList += Constants.LIST_TOKEN_SPLITTER;
            szExclusionList += "zzzTOKENzzz";
        }
    }
    $("hiddenID_RSExclusionList").value = szExclusionList;
}

function epoApplyPolicySettings()
{
    writeHiddenData();
    writeFileTypesToHiddenData(G_SCAN_MODE_FS);
    writeFileTypesToHiddenData(G_SCAN_MODE_QS);
    writeFileTypesToHiddenData(G_SCAN_MODE_RS);
    OrionCore.doAsyncFormAction("/ENDP_AM_1000/SaveODSGeneralPolicy.do",
        [
            "hiddenID_pageState", $("hiddenID_pageState").value
        ], fnApplyPolicySuccess, fnApplyPolicyFailure);

    return false;
};

function fnApplyPolicySuccess()
{
    fnGoBack();
};

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
};
function validateFSMaxScanTime(szMaxScanTime)
{
    var valid = true;

    if($("bFSEnforceMaxScanTime").checked == false)
    {
        return true;
    }

    if(szMaxScanTime == null || szMaxScanTime == "")
    {
        valid = false;
    }

    if(valid)
    {
        valid = OrionValidate.isIntString(szMaxScanTime) && OrionValidate.isIntBetween(szMaxScanTime, 10, 9999);
    }

    return valid;
}
function validateFSMaxODSThreads(szMaxODSThreads)
{
    var valid = true;

    if($("bFSEnforceMaxODSThreads").checked == false)
    {
        return true;
    }

    if(szMaxODSThreads == null || szMaxODSThreads == "")
    {
        valid = false;
    }

    if(valid)
    {
        valid = OrionValidate.isIntString(szMaxODSThreads) && OrionValidate.isIntBetween(szMaxODSThreads, 1, 999);
    }

    return valid;
}
function validateQSMaxODSThreads(szMaxODSThreads)
{
    var valid = true;

    if($("bQSEnforceMaxODSThreads").checked == false)
    {
        return true;
    }

    if(szMaxODSThreads == null || szMaxODSThreads == "")
    {
        valid = false;
    }

    if(valid)
    {
        valid = OrionValidate.isIntString(szMaxODSThreads) && OrionValidate.isIntBetween(szMaxODSThreads, 1, 999);
    }

    return valid;
}
function validateQSMaxScanTime(szMaxScanTime)
{
    var valid = true;

    if($("bQSEnforceMaxScanTime").checked == false)
    {
        return true;
    }

    if(szMaxScanTime == null || szMaxScanTime == "")
    {
        valid = false;
    }

    if(valid)
    {
        valid = OrionValidate.isIntString(szMaxScanTime) && OrionValidate.isIntBetween(szMaxScanTime, 10, 9999);
    }

    return valid;
}
