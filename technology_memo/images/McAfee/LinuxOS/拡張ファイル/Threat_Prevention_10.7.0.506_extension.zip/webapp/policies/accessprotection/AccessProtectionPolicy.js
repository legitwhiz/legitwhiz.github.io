//Copyright (C) 2017 McAfee, Inc.  All rights reserved.
//

// global variables
var g_APRuleListWidget;
var g_isNew = false;
var g_readOnly = false;

// Access Protection Data
var bAPEnabled;

var g_editedBOFRules = new Array();
var g_arrListRuleData = new Array();

function epoApplyPolicySettings()
{
    writeHiddenData();

    //$("hiddenID_dwAPRuleBlocks").value = g_arrListRuleData.length;
    var ruleListJSON = JSON.stringify(g_arrListRuleData);
    OrionCore.showPleaseWait(true);
    OrionCore.doAsyncFormAction("/ENDP_AM_1000/SaveAccessProtectionPolicy.do", ["ruleListJSON", ruleListJSON], fnApplyPolicySuccess, fnApplyPolicyFailure);

    //set gobackType, in case that is called from policies and tasks, for some reason only works if
    // has only one depth of callers
    if (getLastSelectedPageIfHasBeenChanged() !== "")
    {
        g_backType =getLastSelectedPageIfHasBeenChanged();
    }

    return false;
};

function fnApplyPolicySuccess()
{
    fnGoBack();
};

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
};

function writeHiddenData()
{
    storePolicyData();

    $("hiddenID_APEnabled").value = bAPEnabled;

}

APRuleData = function(obj)
{
    var ruleName = "";
    var ruleId = "";
    var ruleType = "";
    var ruleBlock = false;
    var ruleReport = false;
    var executables = "";
    var exclusions = "";
    var inclusions = "";
    var ruleNote = "";
    var userNames = "";
    var subRules = "";
    var policySettingsId = -1;
    var platform="WINDOWS";
}

function trackEditedBOFRule(ruleDataItem)
{
    var bAlreadyInList = false;

    for(var i = 0; i < g_editedBOFRules.length; ++i)
    {
        if(g_editedBOFRules[i] == ruleDataItem)
        {
            bAlreadyInList = true;
            break;
        }
    }

    if(!bAlreadyInList)
    {
        g_editedBOFRules.push(ruleDataItem);
    }
}

function ruleListAddCallback(newDiv)
{
    var ruleItem = g_APRuleListWidget.getItem(newDiv.id);
    if(ruleItem != null)
    {
        $(newDiv.id + "_checkbox0").checked = ruleItem.itemData.ruleBlock;
        $(newDiv.id + "_checkbox1").checked = ruleItem.itemData.ruleReport;

        $(newDiv.id + "_checkbox0").disabled = g_readOnly;
        $(newDiv.id + "_checkbox1").disabled = g_readOnly;
    }
}

function ruleListCheckboxOnClickCallback(evt)
{
    var checkboxID = "";
    var rowID = "";

    if(evt != null)
    {
        checkboxID = evt.target.id;
    }
    else
    {
        checkboxID =  window.event.srcElement.id;
    }

    rowID = $(checkboxID).parentNode.parentNode.id;

    if(rowID != "")
    {
        var ruleItem = g_APRuleListWidget.getItem(rowID);
        if(ruleItem != null)
        {
            var checkboxNum = checkboxID.replace(rowID + "_", "")
            if(checkboxNum == "checkbox0")
            {
                ruleItem.itemData.ruleBlock = $(checkboxID).checked
            }
            else
            {
                ruleItem.itemData.ruleReport = $(checkboxID).checked
            }

            trackEditedBOFRule(ruleItem.itemData);

            g_bFormDirty = true;
            validatePolicy();
        }
    }

    var bAllBlocked = true;
    var bAllReported = true;
    for (var i = 0; i < g_arrListRuleData.length; ++i)
    {
        if (g_arrListRuleData[i].ruleName != "")
        {
            if (g_arrListRuleData[i].ruleBlock == false)
            {
                bAllBlocked = false;
            }
            if (g_arrListRuleData[i].ruleReport == false)
            {
                bAllReported = false;
            }
        }
    }
    $("checkboxID_APBlockAll").checked = bAllBlocked;
    $("checkboxID_APReportAll").checked = bAllReported;
}

function storePolicyData()
{
    // We don't need to store the rule data because it is already stored in variables.
    // Only need to store AP, Self Protection, and Log settings
    bAPEnabled = $("checkboxID_APEnabled").checked;
}

function displayPolicyData()
{
    _APTabInit();
    _doReadonly();
}