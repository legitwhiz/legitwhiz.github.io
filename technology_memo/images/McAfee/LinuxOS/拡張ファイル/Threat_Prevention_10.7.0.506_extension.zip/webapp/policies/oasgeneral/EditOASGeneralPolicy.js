//Copyright (C) 2017 McAfee, Inc.  All rights reserved.
//

var g_MAX_TIMEOUT_OFF         = 4294967295;   // (0xFFFFFFFF)
var g_MIN_TIMEOUT_OFF         = 0;            // (0x00000000)
var g_DEFAULT_DIALOG_MESSAGE = "IDS_OAS_DEFAULT_THREAT_MESSAGE";

// For OASEnabled
var g_SCANNER_ENABLED           = 1;
var g_SCANNER_DISABLED          = 0;

// globals

var g_cancelHandler;

var bScanBootSectors;
var ScanProcessesOnEnable;
var bScanTrustedInstallers;
var bScanCopyLocalFolders;
var scanCopyNetworkRemovable;
var scanEmailAttachments;
var scanUsingAMSIHooks;
var enableAMSIObserveMode;
var scanShadowCopyDisableStatus;
var bEnforceMaxScanTime;
var dwScannerThreadTimeout;
var bStartEnabled;
var bOASEnabled;
//var CacheType = new Array();
var bOnlyUseDefaultConfig;
var bAllowDisableViaMcTray;

//GTI section values
var bEnableGTI;
var GTISensitivityLevel;

    // ScriptScan Section Values
var ScriptScanEnabled;

    // Blocking Section Values
//var VSIDBlock = new Array();
//var VSIDBlockTimeout = new Array();
//var VSIDBlockOnNonVirus = new Array();

    // Messages Section Values
var bShowAlerts;
var szDialogMessage;
var szDialogMessageDefault;
//var bCleanFiles;
//var bDeleteFiles;

var g_arrListRPData = new Array();
var g_RiskProcessesListWidget;
var addeditRPDialog = null;
var g_bNewRPItem = false;

RPDataItem = function(obj)
{
    var rpProcess = "";
    var rpRiskType = "";
}

function epoApplyPolicySettings()
{
    //fnSetWFlags();
    //fnSetHiddenValues();
    writeHiddenData();

    OrionCore.doAsyncFormAction("/ENDP_AM_1000/SaveOASGeneralPolicy.do",
        [
        "hiddenID_pageState", $("hiddenID_pageState").value
        ], fnApplyPolicySuccess, fnApplyPolicyFailure);

    return false;
};

function fnApplyPolicySuccess()
{
    fnGoBack();
};

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
};

function fnSetWFlags()
{
    var enableOASOnEnforce = document.getElementById("checkboxID_EnableOASOnEnforce").checked;

    if(enableOASOnEnforce)
    {
        document.getElementById("checkboxID_EnableOASOnEnforce").value = g_SCANNER_ENABLED;
    }
    else
    {
        document.getElementById("checkboxID_EnableOASOnEnforce").value = g_SCANNER_DISABLED;
    }
};

// function fnSetHiddenValues()
// {
//     var ScanBootSectors = document.getElementById("checkboxID_ScanBootSectors").checked;
//     var ScanAtStartup = document.getElementById("checkboxID_EnableOASAtStartup").checked;
//     var EnableOASOnEnforce = document.getElementById("checkboxID_EnableOASOnEnforce").checked;
//     var EnforceMaxScanTime = document.getElementById("checkboxID_EnforceMaxScanTime").checked;
//     var ScanCopyNetworkRemovable = document.getElementById("checkboxID_ScanCopyNetworkRemovable").checked;
//     var ScanEmailAttachments = document.getElementById("checkboxID_ScanEmailAttachments").checked;
//     var ScanUsingAMSIHooks = document.getElementById("checkboxID_ScanUsingAMSIHooks").checked;
//     var EnableAMSIExclusions = document.getElementById("checkboxID_EnableAMSIExclusions").checked;
//
//     document.getElementById("checkboxID_ScanBootSectors").value = !ScanBootSectors;
//     document.getElementById("checkboxID_EnableOASAtStartup").value = !ScanAtStartup;
//     document.getElementById("checkboxID_EnableOASOnEnforce").value = !EnableOASOnEnforce;
//     document.getElementById("checkboxID_EnforceMaxScanTime").value = !EnforceMaxScanTime;
//     document.getElementById("checkboxID_ScanCopyNetworkRemovable").value = !ScanCopyNetworkRemovable;
//     document.getElementById("checkboxID_ScanEmailAttachments").value = !ScanEmailAttachments;
//     document.getElementById("checkboxID_ScanUsingAMSIHooks").value = !ScanUsingAMSIHooks;
//     document.getElementById("checkboxID_EnableAMSIExclusions").value = !EnableAMSIExclusions;
// };

function storeRiskProcessItems()
{
    // Store RiskProcesses items data
    var RiskProcessesItems = g_RiskProcessesListWidget.getItemList();
    g_arrListRPData = new Array();
    for(i = 0; i < RiskProcessesItems.length; ++i)
    {
        g_arrListRPData[i] = RiskProcessesItems[i].itemData;
    }
}

function writeAppIDListHiddenData()
{
    var processes = "";
    var processTypes = "";
    var length = 0;

    // update the hidden list of element ID's containing values
    storeRiskProcessItems();
    for(var i = 0; i < g_arrListRPData.length; ++i)
    {
        processes += g_arrListRPData[i].rpProcess;
        processTypes += g_arrListRPData[i].rpRiskType;
        if((i+1) < g_arrListRPData.length)
        {
            processes += ",";
            processTypes += ",";
        }
    }

    $("hiddenID_ApplicationItemIDList").value = processes;
    $("hiddenID_ApplicationTypeItemIDList").value = processTypes;
}

function writeHiddenData()
{

    storePolicyData();

    writeSSURLExclusionsHiddenData();
    writeAppIDListHiddenData();

    $("hiddenID_ScanBootSectors").value = bScanBootSectors;
    $("hiddenID_ScanProcessesOnEnable").value = ScanProcessesOnEnable;
    $("hiddenID_ScanTrustedInstallers").value = bScanTrustedInstallers;
    $("hiddenID_ScanCopyLocalFolders").value = bScanCopyLocalFolders;
    $("hiddenID_ScanCopyNetworkRemovable").value = scanCopyNetworkRemovable;
    $("hiddenID_ScanEmailAttachments").value = scanEmailAttachments;
    $("hiddenID_ScanUsingAMSIHooks").value = scanUsingAMSIHooks;
    $("hiddenID_EnableAMSIObserveMode").value = enableAMSIObserveMode;
    $("hiddenID_ScanShadowCopyDisableStatus").value = scanShadowCopyDisableStatus;
    $("hiddenID_EnforceMaxScanTime").value = bEnforceMaxScanTime;
    $("hiddenID_dwScannerThreadTimeout").value = dwScannerThreadTimeout;

    $("hiddenID_EnableOASAtStartup").value = bStartEnabled;
    $("hiddenID_EnableOASOnEnforce").value = bOASEnabled;
    $("hiddenID_UseDefaultConfig").value = bOnlyUseDefaultConfig;
    //$("hiddenID_CacheType").value = CacheType;
     // ScriptScan Section Values

    $("hiddenID_bEnableGTI").value = bEnableGTI;
    $("hiddenID_GTISensitivityLevel").value = GTISensitivityLevel;

    $("hiddenID_EnableScriptScan").value = ScriptScanEnabled;

        // Blocking Section Values
//    $("hiddenID_VSIDBlock").value = VSIDBlock;
//    $("hiddenID_VSIDBlockTimeout").value = VSIDBlockTimeout;
//    $("hiddenID_VSIDBlockOnNonVirus").value = VSIDBlockOnNonVirus;

      // Messages Section Values
    $("hiddenID_ShowAlerts").value = bShowAlerts;
    $("hiddenID_DialogMessage").value = szDialogMessage;
//    $("hiddenID_CleanFiles").value = bCleanFiles;
    //    $("hiddenID_DeleteFiles").value = bDeleteFiles;

    $("hiddenID_AllowDisableViaMcTray").value = bAllowDisableViaMcTray;

    storeProcessData(g_CurrentProcessType);
    writeHiddenProcessData();
}

function writeHiddenProcessData()
{
    $("hiddenID_DefaultbScanWritingByPass").value = bScanWriting[DEFAULT_POLICY];
    $("hiddenID_DefaultbScanReadingByPass").value = bScanReading[DEFAULT_POLICY];
    $("hiddenID_DefaultbNetworkScanEnabled").value = bNetworkScanEnabled[DEFAULT_POLICY];
    $("hiddenID_DefaultbScanBackupReads").value = bScanBackupReads[DEFAULT_POLICY];
    $("hiddenID_DefaultExtensionMode").value = ExtensionMode[DEFAULT_POLICY];
    $("hiddenID_DefaultProgExts").value = removeDuplicateExtensions(szProgExts[DEFAULT_POLICY]);
    $("hiddenID_DefaultbScanArchives").value = bScanArchives[DEFAULT_POLICY];
    $("hiddenID_DefaultbScanMime").value = bScanMime[DEFAULT_POLICY];
    $("hiddenID_DefaultbUnknownProgramHeuristics").value = bUnknownProgramHeuristics[DEFAULT_POLICY];
    $("hiddenID_DefaultbUnknownMacroHeuristics").value = bUnknownMacroHeuristics[DEFAULT_POLICY];
    $("hiddenID_DefaultbApplyNVP").value = bApplyNVP[DEFAULT_POLICY];
    $("hiddenID_DefaultThreatPrimaryAction").value = uAction[DEFAULT_POLICY];
    $("hiddenID_DefaultThreatSecondaryAction").value = uSecAction[DEFAULT_POLICY];
    $("hiddenID_DefaultUnwantedPrimaryAction").value = uAction_Program[DEFAULT_POLICY];
    $("hiddenID_DefaultUnwantedSecondaryAction").value = uSecAction_Program[DEFAULT_POLICY];
    $("hiddenID_DefaultOverwriteClient").value = bOverwriteExclusions[DEFAULT_POLICY];
	$("hiddenID_DefaultTimeoutAction").value = uTimeOutAction[DEFAULT_POLICY];
    $("hiddenID_DefaultScanErrorAction").value = uScanErrorAction[DEFAULT_POLICY];

    $("hiddenID_HighbScanWritingByPass").value = bScanWriting[HIGH_RISK_POLICY];
    $("hiddenID_HighbScanReadingByPass").value = bScanReading[HIGH_RISK_POLICY];
    $("hiddenID_HighbNetworkScanEnabled").value = bNetworkScanEnabled[HIGH_RISK_POLICY];
    $("hiddenID_HighbScanBackupReads").value = bScanBackupReads[HIGH_RISK_POLICY];
    $("hiddenID_HighExtensionMode").value = ExtensionMode[HIGH_RISK_POLICY];
    $("hiddenID_HighProgExts").value = removeDuplicateExtensions(szProgExts[HIGH_RISK_POLICY]);
    $("hiddenID_HighbScanArchives").value = bScanArchives[HIGH_RISK_POLICY];
    $("hiddenID_HighbScanMime").value = bScanMime[HIGH_RISK_POLICY];
    $("hiddenID_HighbUnknownProgramHeuristics").value = bUnknownProgramHeuristics[HIGH_RISK_POLICY];
    $("hiddenID_HighbUnknownMacroHeuristics").value = bUnknownMacroHeuristics[HIGH_RISK_POLICY];
    $("hiddenID_HighbApplyNVP").value = bApplyNVP[HIGH_RISK_POLICY];
    $("hiddenID_HighThreatPrimaryAction").value = uAction[HIGH_RISK_POLICY];
    $("hiddenID_HighThreatSecondaryAction").value = uSecAction[HIGH_RISK_POLICY];
    $("hiddenID_HighUnwantedPrimaryAction").value = uAction_Program[HIGH_RISK_POLICY];
    $("hiddenID_HighUnwantedSecondaryAction").value = uSecAction_Program[HIGH_RISK_POLICY];
    $("hiddenID_HighOverwriteClient").value = bOverwriteExclusions[HIGH_RISK_POLICY];
	$("hiddenID_HighTimeoutAction").value = uTimeOutAction[HIGH_RISK_POLICY];
    $("hiddenID_HighScanErrorAction").value = uScanErrorAction[HIGH_RISK_POLICY];

    $("hiddenID_LowbScanWritingByPass").value = bScanWriting[LOW_RISK_POLICY];
    $("hiddenID_LowbScanReadingByPass").value = bScanReading[LOW_RISK_POLICY];
    $("hiddenID_LowbNetworkScanEnabled").value = bNetworkScanEnabled[LOW_RISK_POLICY];
    $("hiddenID_LowbScanBackupReads").value = bScanBackupReads[LOW_RISK_POLICY];
    $("hiddenID_LowExtensionMode").value = ExtensionMode[LOW_RISK_POLICY];
    $("hiddenID_LowProgExts").value = removeDuplicateExtensions(szProgExts[LOW_RISK_POLICY]);
    $("hiddenID_LowbScanArchives").value = bScanArchives[LOW_RISK_POLICY];
    $("hiddenID_LowbScanMime").value = bScanMime[LOW_RISK_POLICY];
    $("hiddenID_LowbUnknownProgramHeuristics").value = bUnknownProgramHeuristics[LOW_RISK_POLICY];
    $("hiddenID_LowbUnknownMacroHeuristics").value = bUnknownMacroHeuristics[LOW_RISK_POLICY];
    $("hiddenID_LowbApplyNVP").value = bApplyNVP[LOW_RISK_POLICY];
    $("hiddenID_LowThreatPrimaryAction").value = uAction[LOW_RISK_POLICY];
    $("hiddenID_LowThreatSecondaryAction").value = uSecAction[LOW_RISK_POLICY];
    $("hiddenID_LowUnwantedPrimaryAction").value = uAction_Program[LOW_RISK_POLICY];
    $("hiddenID_LowUnwantedSecondaryAction").value = uSecAction_Program[LOW_RISK_POLICY];
    $("hiddenID_LowOverwriteClient").value = bOverwriteExclusions[LOW_RISK_POLICY];
	$("hiddenID_LowTimeoutAction").value = uTimeOutAction[LOW_RISK_POLICY];
    $("hiddenID_LowScanErrorAction").value = uScanErrorAction[LOW_RISK_POLICY];


    var szExclusionList = "";

    for(var i = 0; i < g_ExclusionsByRisk[DEFAULT_POLICY].length; ++i)
    {
        szExclusionList += g_ExclusionsByRisk[DEFAULT_POLICY][i];
        if((i+1) < g_ExclusionsByRisk[DEFAULT_POLICY].length)
        {
            szExclusionList += Constants.LIST_TOKEN_SPLITTER;
        }
    }
    $("hiddenID_DefaultExclusionList").value = szExclusionList;

    szExclusionList = "";
    for(var i = 0; i < g_ExclusionsByRisk[HIGH_RISK_POLICY].length; ++i)
    {
        szExclusionList += g_ExclusionsByRisk[HIGH_RISK_POLICY][i];
        if((i+1) < g_ExclusionsByRisk[HIGH_RISK_POLICY].length)
        {
            szExclusionList += Constants.LIST_TOKEN_SPLITTER;
        }
    }
    $("hiddenID_HighExclusionList").value = szExclusionList;

    szExclusionList = "";
    for(var i = 0; i < g_ExclusionsByRisk[LOW_RISK_POLICY].length; ++i)
    {
        szExclusionList += g_ExclusionsByRisk[LOW_RISK_POLICY][i];
        if((i+1) < g_ExclusionsByRisk[LOW_RISK_POLICY].length)
        {
            szExclusionList += Constants.LIST_TOKEN_SPLITTER;
        }
    }
    $("hiddenID_LowExclusionList").value = szExclusionList;
}

function storePolicyData()
{
    bOASEnabled = $("checkboxID_EnableOASOnEnforce").checked;
    bScanBootSectors = $("checkboxID_ScanBootSectors").checked;
    ScanProcessesOnEnable = $("checkboxID_ScanProcessesOnEnable").checked;
    bScanTrustedInstallers = $("checkboxID_ScanTrustedInstallers").checked;
    bScanCopyLocalFolders = $("checkboxID_ScanCopyLocalFolders").checked;
    scanCopyNetworkRemovable = $("checkboxID_ScanCopyNetworkRemovable").checked;
    scanEmailAttachments = $("checkboxID_ScanEmailAttachments").checked;
    scanUsingAMSIHooks = $("checkboxID_ScanUsingAMSIHooks").checked;
    enableAMSIObserveMode = $("checkboxID_EnableAMSIObserveMode").checked;
    scanShadowCopyDisableStatus = $("checkboxID_ScanShadowCopyDisableStatus").checked;
    bOnlyUseDefaultConfig = $("radioID_UseDefaultConfig").checked;
    //CacheType = $("selectID_CacheType").value;

    bEnableGTI = $("checkboxID_bEnableGTI").checked;
    GTISensitivityLevel = $("selectID_GTISensitivityLevel").value;

    bEnforceMaxScanTime = $("checkboxID_EnforceMaxScanTime").checked;
    dwScannerThreadTimeout = $("textboxID_dwScannerThreadTimeout").value;

    bStartEnabled = $("checkboxID_EnableOASAtStartup").checked;
    bAllowDisableViaMcTray = $("checkboxID_AllowDisableViaMcTray").checked;

    /*if($("checkboxID_EnableOASOnEnforce").checked)
    {
        OASEnabled = g_SCANNER_ENABLED;
    }
    else
    {
        OASEnabled = g_SCANNER_DISABLED;
    }*/

    // ScriptScan Section Values
    ScriptScanEnabled = $("checkboxID_EnableScriptScan").checked;

        // Blocking Section Values
    /*VSIDBlock = $("checkboxID_VSIDBlock").checked;
    if($("checkboxID_VSIDBlock").checked)
    {
        VSIDBlockTimeout = $("textboxID_VSIDBlockTimeout").value;
    }
    else
    {
        VSIDBlockTimeout = g_MIN_TIMEOUT_OFF;
    }
    VSIDBlockOnNonVirus = $("checkboxID_VSIDBlockOnNonVirus").checked;
*/
    // Messages Section Values
    bShowAlerts = $("checkboxID_ShowAlerts").checked;
    var message = OrionCore.trim($("textboxID_DialogMessage").value);
    //If the message in the current dialog is the default then use the IDS string
    if ( message === szDialogMessageDefault )
    {
        szDialogMessage = g_DEFAULT_DIALOG_MESSAGE;
    }
    else  //otherwise use the new actual text what ever that may be
    {
        szDialogMessage = message;
    }

//    bCleanFiles = $("checkboxID_CleanFiles").checked;
//    bDeleteFiles = $("checkboxID_DeleteFiles").checked;
    storeRiskProcessItems();
}

function displayPolicyData()
{
    $("checkboxID_ScanBootSectors").checked = bScanBootSectors;
    $("checkboxID_ScanProcessesOnEnable").checked = ScanProcessesOnEnable;
    $("checkboxID_ScanTrustedInstallers").checked = bScanTrustedInstallers;
    $("checkboxID_ScanCopyLocalFolders").checked = bScanCopyLocalFolders;
    $("checkboxID_ScanCopyNetworkRemovable").checked = scanCopyNetworkRemovable;
    $("checkboxID_ScanEmailAttachments").checked = scanEmailAttachments;
    $("checkboxID_ScanUsingAMSIHooks").checked = scanUsingAMSIHooks;
    $("checkboxID_EnableAMSIObserveMode").checked = enableAMSIObserveMode;
  	$("checkboxID_ScanShadowCopyDisableStatus").checked = scanShadowCopyDisableStatus;
//    $("selectID_CacheType").value = CacheType;

    $("checkboxID_EnableOASAtStartup").checked = bStartEnabled;
    $("checkboxID_EnableOASOnEnforce").checked = bOASEnabled;//(OASEnabled == g_SCANNER_ENABLED);
    $("checkboxID_AllowDisableViaMcTray").checked = bAllowDisableViaMcTray;

    $("checkboxID_EnforceMaxScanTime").checked = bEnforceMaxScanTime;
    $("textboxID_dwScannerThreadTimeout").value = dwScannerThreadTimeout;

    //GTI section values
    $("checkboxID_bEnableGTI").checked = bEnableGTI;
    fnSetDropBox($("selectID_GTISensitivityLevel"), GTISensitivityLevel);
    setGTIEnabled(bEnableGTI, $("GTIEnabledTBody"));

    //AMSI section values
    setAMSIEnabled(scanUsingAMSIHooks, $("AMSIEnabledTBody"));

    if(bOnlyUseDefaultConfig)
    {
        document.getElementById("radioID_UseDefaultConfig").checked = true;
    }
    else
    {
        document.getElementById("radioID_UseDifferentSettings").checked = true;
    }

    // ScriptScan Section Values
    $("checkboxID_EnableScriptScan").checked = ScriptScanEnabled;
    // Messages Section Values
    $("checkboxID_ShowAlerts").checked = bShowAlerts;
//    $("checkboxID_CleanFiles").checked = bCleanFiles;
//    $("checkboxID_DeleteFiles").checked = bDeleteFiles;
    fnEnableMessageAlert();
    fnSetUseDefaultConfigState($("radioID_UseDefaultConfig").checked);

    populateRiskProcessesList();
    _doReadonly();
}

function validateMaxScanTime(szMaxScanTime)
{
    var valid = true;

    if($("checkboxID_EnforceMaxScanTime").checked == false)
    {
        return true;
    }

    if(szMaxScanTime == null || szMaxScanTime == "")
    {
        valid = false;
    }

    if(valid)
    {
        valid = OrionValidate.isIntString(szMaxScanTime) && OrionValidate.isIntBetween(szMaxScanTime, 10, 9999);
    }

    return valid;
}

function validateScanArchiveTimeout(szScanArchiveTimeout)
{
    var valid = true;
    $("spanID_ScanArchiveTimeout_error").style.display = "none";

    if(szScanArchiveTimeout == null || szScanArchiveTimeout == "")
    {
        valid = false;
    }

    if(valid)
    {
        valid = OrionValidate.isIntString(szMaxScanTime) && OrionValidate.isIntBetween(szMaxScanTime, 10, 9999);
    }

    if(valid)
    {
        if($("checkboxID_EnforceMaxScanTime").checked)
        {
            var maxScanTime = $("textboxID_dwScannerThreadTimeout").value;
            if(maxScanTime == null || maxScanTime == "" || (scanArchiveTimeout >= parseInt(maxScanTime)))
            {
                $("spanID_ScanArchiveTimeout_error").style.display = "";
                valid = false;
            }
        }
    }
    return valid;
}

/*
function validateBlockTimeout(szTimeout)
{
    var valid = true;

    if($("checkboxID_VSIDBlock").checked)
    {
        valid = (szTimeout > 0 && szTimeout < 10000);
    }

    return valid;
}
*/

function validateSSExclusion(szExclusion)
{
    var r = -1;

    // Don't allow blank process name
    if (szExclusion == "")
        r = 1;

    if(r == -1)
	    r = szExclusion.indexOf("/");

	if(r == -1)
		r = szExclusion.indexOf("\\");

    if(r == -1)
		r = szExclusion.indexOf("\*");

	if(r == -1)
		r = szExclusion.indexOf("?");

	if(r == -1)
		r = szExclusion.indexOf("\"");

	if(r == -1)
		r = szExclusion.indexOf("|");

    if(r == -1)
		r = szExclusion.indexOf("<");

    if(r == -1)
		r = szExclusion.indexOf(">");

    if(r == -1)
		r = szExclusion.indexOf(":");

    if(r == -1)
		return true;

	return false;
}

//probably need a validation function for URL exclusion
function validateSSURLExclusion(szExclusion)
{
    var r = -1;

    // Don't allow blank URL name
    if (szExclusion == "")
        r = 1;

	r = szExclusion.indexOf("/");

	if(r == -1)
		r = szExclusion.indexOf("\\");

    if(r == -1)
		r = szExclusion.indexOf("\*");

    if(r == -1)
		r = szExclusion.indexOf("?");

	if(r == -1)
		r = szExclusion.indexOf("\"");

	if(r == -1)
		r = szExclusion.indexOf("|");

    if(r == -1)
		r = szExclusion.indexOf("<");

    if(r == -1)
		r = szExclusion.indexOf(">");

    if(r == -1)
		r = szExclusion.indexOf(":");

    if(r == -1)
		return true;

	return false;

}
