//Copyright (C) 2017 McAfee, Inc.  All rights reserved.
//

// *******************************************************************
// removeDuplicateExtensions - Sorts and removes duplicates from list
//
// Input: szExtensions - comma delimited list of extensions
//
// Returns: A comma delimited sorted list of extensions with duplicates
// removed.
// *******************************************************************
function removeDuplicateExtensions(szExtensions)
{
    var szReturn = "";

    //if the ::: exists, remove it from the list and re-add it after the sort
    var removedColons = false;
    if (szExtensions.indexOf(":::") != -1)
    {
        szExtensions = removeNoExtensionMarker(szExtensions);
        removedColons = true;
    }

    var szExtItems = szExtensions.split(/,/);
    szExtItems = szExtItems.sort();

    for(var i=0; i < szExtItems.length;)
    {
        var szCurrentItem = szExtItems[i];
        szReturn += szCurrentItem;
        ++i;
        while(i < szExtItems.length && szCurrentItem == szExtItems[i])
        {
            ++i;
        }

        if(i < szExtItems.length)
        {
            szReturn += ",";
        }
    }

    //if colons were removed, add them back in
   if (removedColons)
   {
       if (szReturn.length > 0)
       {
           szReturn += ",:::";
       }
       else
       {
           szReturn = ":::";
       }
   }

    return szReturn;
}

// *******************************************************************
// validateWidget - Prevents duplicate entries from being entered in the plus/minus control widget
//
// Input: szNewExclusion    - the current value being entered
//        listWidget        - the name of the plus/minus widget
//        listDelimeter     - the internal delimiter for the list
//        delimeter         - The other delimeter
//
// Returns: Boolean. Returns true if a duplicate entry was NOT found. If this returns false, don't set the local functions g_bFormDirty to true
//
// Example: validateWidget(szNewExclusion, g_UPExclusionsAddWidget, "upexclusionslist_awrow_", "up_exclusion_");
//
// *******************************************************************
function validateWidget(szNewExclusion, listWidget, listDelimeter, delimeter)
{
    var UPExclusionsList = listWidget.getList();
    var exclusions = "";
    var founditem = 0;

    for(var i=0; i < UPExclusionsList.length; ++i)//-1
    {
        var currentItemID = UPExclusionsList[i].replace(listDelimeter, "");
        var currentExclusion = $(delimeter+currentItemID);

        if((OrionCore.trim(currentExclusion.value) == OrionCore.trim(szNewExclusion)) && (OrionCore.trim(szNewExclusion) != ""))
        {
            //we look for 2 or more occurances of the item as itself already always exists in the list
            founditem += 1;
            if (founditem >=2)
            {
                return false;
            }
        }
    }
    return true;
}

//This function calls validateWidget for all elements to make sure that the entire list is free of duplicates.
function validateEntireWidget(listWidget, listDelimeter, delimeter)
{
    var UPExclusionsList = listWidget.getList();

    for (var i=0; i < UPExclusionsList.length; ++i)
    {
        var currentItemID = UPExclusionsList[i].replace(listDelimeter, "");
        var currentExclusion = $(delimeter+currentItemID);
        if (validateWidget(currentExclusion.value, listWidget, listDelimeter, delimeter) == false)
        {
            return false;
        }
    }
    return true;
}

/*
This function toggles the display for errorElement if szElement is empty or not empty.
active should be true if the field being validated is active. For instance,
the field containing szElement may only be relevant if a certain checkbox is checked.
Otherwise, an inactive field would still display the error message.
*/
function checkRequiredToDisplayError(szElement, errorElement, active)
{
    if (errorElement)
    {
        var isValid = ((OrionCore.trim(szElement) != "") || !active);
        if (isValid)
        {
            errorElement.style.display = "none";
        }
        else
        {
            errorElement.style.display = "";
        }
    }
}

//Passwords work a bit different in that spaces in the password field are not treated as empty, so trim() doesn't work here.
function checkPasswordRequiredToDisplayError(szElement, errorElement, active)
{
    if (errorElement)
    {
        var isValid = ((szElement != "") || !active);
        if (isValid)
        {
            errorElement.style.display = "none";
        }
        else
        {
            errorElement.style.display = "";
        }
    }
}