------------------------------------------------------------------
--Copyright (c) 2018 McAfee LLC - All Rights Reserved
------------------------------------------------------------------
-- insert 10.6.0 product technology data
IF NOT EXISTS(SELECT 1 FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_AM_1060')
BEGIN
    INSERT INTO [dbo].[EAMP.GSE.Blades]([ProductCode], [DispName], [TechnologyCount]) VALUES
        (N'ENDP_AM_1060', N'Endpoint Security Threat Prevention', 4)
END
GO

IF NOT EXISTS(SELECT [COLUMN_NAME] FROM INFORMATION_SCHEMA.COLUMNS WHERE [TABLE_NAME] = N'AM_CustomPropsMT' AND [COLUMN_NAME] = N'scanUsingAMSIHooks')
BEGIN
    ALTER TABLE [AM_CustomPropsMT]
      ADD [scanUsingAMSIHooks]  [bit] NULL
END
GO

IF NOT EXISTS(SELECT [COLUMN_NAME] FROM INFORMATION_SCHEMA.COLUMNS WHERE [TABLE_NAME] = N'AM_CustomPropsMT' AND [COLUMN_NAME] = N'enableAMSIObserveMode')
BEGIN
    ALTER TABLE [AM_CustomPropsMT]
      ADD [enableAMSIObserveMode]  [bit] NULL
END
GO
