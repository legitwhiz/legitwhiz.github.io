-- grant access rights to the Signatures views and sps
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureTextXlate To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureTextXlate To mcafeeOps
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureTextXlate To mcafeeSystem

GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_Signature To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_Signature To mcafeeSystem
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_Signature To mcafeeOps

GRANT SELECT  ON IPS_SignatureTextXlateMT To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureTextXlateMT To mcafeeOps
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureTextXlateMT To mcafeeSystem

GRANT SELECT ON IPS_SignatureMT To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureMT To mcafeeSystem
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureMT To mcafeeOps

GRANT EXECUTE ON [dbo].[IPS_GET_SignatureLocalized] TO mcafeeSystem
GRANT EXECUTE ON [dbo].[IPS_GET_SignatureLocalized] TO mcafeeOps
GRANT EXECUTE ON [dbo].[IPS_GET_SignatureLocalized] TO mcafeeTenant

GRANT EXECUTE ON [dbo].[IPS_SET_SignatureTextXlate] TO mcafeeSystem
GRANT EXECUTE ON [dbo].[IPS_SET_SignatureTextXlate] TO mcafeeOps
--GRANT EXECUTE ON [dbo].[IPS_SET_SignatureTextXlate] TO mcafeeTenant

GRANT EXECUTE ON [dbo].[IPS_SET_Signature] TO mcafeeSystem
GRANT EXECUTE ON [dbo].[IPS_SET_Signature] TO mcafeeOps
--GRANT EXECUTE ON [dbo].[IPS_SET_Signature] TO mcafeeTenant

GO