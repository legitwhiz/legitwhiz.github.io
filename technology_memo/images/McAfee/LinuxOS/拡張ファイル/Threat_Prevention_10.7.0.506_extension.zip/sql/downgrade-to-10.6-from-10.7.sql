DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_AM_1070'
GO

IF EXISTS(SELECT *
          FROM dbo.syscolumns
          WHERE id = OBJECT_ID('[dbo].[AM_CustomPropsMT]') AND (name = 'TPAMSISupportedStatus'))
  BEGIN
    ALTER TABLE [dbo].[AM_CustomPropsMT]
    DROP COLUMN [TPAMSISupportedStatus];
  END
GO

IF EXISTS(SELECT *
          FROM dbo.syscolumns
          WHERE id = OBJECT_ID('[dbo].[AM_CustomPropsMT]') AND (name = 'TPAMSISupportedStatusReason'))
  BEGIN
    ALTER TABLE [dbo].[AM_CustomPropsMT]
    DROP COLUMN [TPAMSISupportedStatusReason];
  END
GO

IF EXISTS(SELECT *
          FROM dbo.syscolumns
          WHERE id = OBJECT_ID('[dbo].[ENSRollup_AM_CustomProps]') AND (name = 'TPAMSISupportedStatus'))
  BEGIN
    ALTER TABLE [dbo].[ENSRollup_AM_CustomProps]
    DROP COLUMN [TPAMSISupportedStatus];
  END
GO

IF EXISTS(SELECT *
          FROM dbo.syscolumns
          WHERE id = OBJECT_ID('[dbo].[ENSRollup_AM_CustomProps]') AND (name = 'TPAMSISupportedStatusReason'))
  BEGIN
    ALTER TABLE [dbo].[ENSRollup_AM_CustomProps]
    DROP COLUMN [TPAMSISupportedStatusReason];
  END
GO