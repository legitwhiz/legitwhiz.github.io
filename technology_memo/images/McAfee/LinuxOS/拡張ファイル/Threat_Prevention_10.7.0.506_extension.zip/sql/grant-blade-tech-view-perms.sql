
if exists (select 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[AMBladeTechView]') and OBJECTPROPERTY(id, N'IsView') = 1)
begin
    grant select on [dbo].[AMBladeTechView] to [mcafeeOps]
    grant select on [dbo].[AMBladeTechView] to [mcafeeTenant]
end
go