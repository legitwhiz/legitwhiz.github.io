------------------------------------------------------------------
--Copyright (c) 2017 McAfee Inc. - All Rights Reserved
------------------------------------------------------------------

-----------------------------------------Start Ips_Signature and IPS_SignatureTextXlate for buffer overflow signatures-------------------------------------

--
--  IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SET_Signature]') AND type in (N'P', N'PC'))
-- DROP PROCEDURE [dbo].[IPS_SET_Signature]
-- GO
-- IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SET_SignatureTextXlate]') AND type in (N'P', N'PC'))
-- DROP PROCEDURE [dbo].[IPS_SET_SignatureTextXlate]
-- GO
--
-- IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_GET_SignatureLocalized]') AND type in (N'P', N'PC'))
-- DROP PROCEDURE [dbo].[IPS_GET_SignatureLocalized]
-- GO
--
-- IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureTextXlate]') and OBJECTPROPERTY(OBJECT_ID, N'IsView') = 1)
-- DROP VIEW [dbo].[IPS_SignatureTextXlate]
-- GO
-- IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_Signature]')  and OBJECTPROPERTY(OBJECT_ID, N'IsView') = 1)
-- DROP VIEW [dbo].[IPS_Signature]
-- GO
-- IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureTextXlate]') AND type in (N'U'))
-- DROP TABLE [dbo].[IPS_SignatureTextXlate]
-- GO
-- IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_Signature]') AND type in (N'U'))
-- DROP TABLE [dbo].[IPS_Signature]
-- GO
--
-- IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureTextXlateMT]') AND type in (N'U'))
-- DROP TABLE [dbo].[IPS_SignatureTextXlateMT]
-- GO
-- IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureMT]') AND type in (N'U'))
-- DROP TABLE [dbo].[IPS_SignatureMT]
-- GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[IPS_SignatureMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[IPS_SignatureMT](
	[SignatureID] [int] NOT NULL,
	[TenantId] [int] NOT NULL,
	[cveLink] [varchar](1000) NULL,
	[SigType] [varchar](50) NOT NULL,
	[Severity]  [char](1) NOT NULL,
	[SignatureType] varchar(10) NOT NULL,
	[Version] varchar(15) NOT NULL,

 CONSTRAINT [PK_IPS_SIGNATUREMT] PRIMARY KEY NONCLUSTERED
(
	[SignatureID] ASC
))
END
GO


IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureMT]') AND name = N'IX_IPS_SignatureMT_TenantId_SignatureID')
  DROP INDEX [IX_IPS_SignatureMT_TenantId_SignatureID] ON [dbo].[IPS_SignatureMT] WITH ( ONLINE = OFF )
GO

CREATE UNIQUE CLUSTERED INDEX [IX_IPS_SignatureMT_TenantId_SignatureID] ON [dbo].[IPS_SignatureMT]
(
  [TenantId] ASC, [SignatureID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF,
    ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


IF NOT EXISTS(SELECT * FROM sysconstraints WHERE id=OBJECT_ID('IPS_SignatureMT') AND COL_NAME(id,colid)='TenantId' AND OBJECTPROPERTY(constid, N'IsDefaultCnst')=1)
BEGIN
ALTER TABLE [dbo].[IPS_SignatureMT]
  ADD CONSTRAINT [DF_IPS_SignatureMT_TenantId]
  DEFAULT dbo.FN_Core_GetContextTenantId() FOR [TenantId]
END
GO



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[IPS_Signature]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[IPS_Signature]
GO

CREATE VIEW [dbo].[IPS_Signature] AS
  SELECT
        [SignatureID],
        --[TenantId],
        [cveLink],
        [SigType],
        [Severity],
        [SignatureType],
        [Version]
    FROM
      [IPS_SignatureMT]
    where
      -- [IPS_SignatureMT].[TenantId] = convert(int, substring(CONTEXT_INFO(), 5, 4))
       [IPS_SignatureMT].[TenantId] = 1 --fix to one for now as system user
GO



IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[IPS_SignatureTextXlateMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[IPS_SignatureTextXlateMT](
	[SignatureID] [int] NOT NULL,
	[TenantId] [int] NOT NULL,
	[LanguageID] [int] NOT NULL,
	[SignatureName] [nvarchar](256) NOT NULL,
	[SignatureStat] [nvarchar](4000)  NULL,
	[SignatureFP] [nvarchar](4000)  NULL,
 CONSTRAINT [PK_IPS_SignatureTextXlateMT] PRIMARY KEY NONCLUSTERED
  (
    [SignatureID] ASC,
    [LanguageID] ASC

  ) ON [PRIMARY]
)
END
GO

IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureTextXlateMT]') AND name = N'IX_APS_SignatureTextXlateMT_TenantId_SignatureID_LanguageID')
  DROP INDEX [IX_APS_SignatureTextXlateMT_TenantId_SignatureID_LanguageID] ON [dbo].[IPS_SignatureTextXlateMT] WITH ( ONLINE = OFF )
GO

CREATE UNIQUE CLUSTERED INDEX [IX_APS_SignatureTextXlateMT_TenantId_SignatureID_LanguageID] ON [dbo].[IPS_SignatureTextXlateMT]
(
  [TenantId] ASC, [SignatureID] ASC, [LanguageID]  ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF,
    ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF NOT EXISTS(SELECT * FROM sysconstraints WHERE id=OBJECT_ID('IPS_SignatureTextXlateMT') AND COL_NAME(id,colid)='TenantId' AND OBJECTPROPERTY(constid, N'IsDefaultCnst')=1)
BEGIN
ALTER TABLE [dbo].[IPS_SignatureTextXlateMT]
  ADD CONSTRAINT [DF_SignatureTextXlateMT_TenantId]
  DEFAULT dbo.FN_Core_GetContextTenantId() FOR [TenantId]
END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[IPS_SignatureTextXlate]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[IPS_SignatureTextXlate]
GO

CREATE VIEW [dbo].[IPS_SignatureTextXlate] AS
  SELECT
        [SignatureID],
      --  [TenantId],
        [LanguageID],
        [SignatureName],
        [SignatureStat],
        [SignatureFP]
    FROM
      [IPS_SignatureTextXlateMT]
    WHERE
     --[IPS_SignatureTextXlateMT].[TenantId] = convert(int, substring(CONTEXT_INFO(), 5, 4))
     [IPS_SignatureTextXlateMT].[TenantId]  = 1 --fix to one for now as system user
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SET_Signature]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[IPS_SET_Signature]
GO

CREATE PROCEDURE [dbo].[IPS_SET_Signature]
(
	@SignatureID		INT,
	@cveValue	NVARCHAR(1000),
	@SigType varchar(50),
	@Severity char (1),
	@SignatureType varchar(10),
	@Version varchar(20)
)
AS
BEGIN
	SET NOCOUNT ON
	SET XACT_ABORT ON

	UPDATE [IPS_Signature]
	SET
	    [cveLink] = @cveValue,
      [SigType] = @SigType,
      [Severity] = @Severity,
      [SignatureType] = @SignatureType,
      [Version] = @Version

	WHERE  [SignatureID] = @SignatureID

	IF (@@ROWCOUNT = 0)
	BEGIN

		INSERT INTO [IPS_Signature] ([SignatureID], [cveLink],[SigType],[Severity],[SignatureType],[Version])
		VALUES (@SignatureID, @cveValue,@SigType,@Severity,@SignatureType,@Version);
	END

END
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_GET_SignatureLocalized]') AND type in (N'P', N'PC'))
  DROP PROCEDURE [dbo].[IPS_GET_SignatureLocalized]
GO

CREATE PROCEDURE [dbo].[IPS_GET_SignatureLocalized]
(
	@LocaleID  INT,
	@DefaultLocale INT
)
AS
BEGIN
	SET NOCOUNT ON
	SET XACT_ABORT ON

SELECT
	loc.SignatureID,
	COALESCE(sig.signatureName,eng.SignatureName ) as name,
	COALESCE(sig.SignatureStat,eng.SignatureStat ) as stat,
	COALESCE(sig.SignatureFP,eng.SignatureFP ) as FP,
	COALESCE( sig.languageid,eng.languageid) as languageid,
	COALESCE(loc.cvelink,'') as link,
	COALESCE(loc.SigType,'') as SigType,
	COALESCE(loc.Severity,'') as Severity,
	COALESCE(loc.SignatureType,'') as SignatureType,
	COALESCE(loc.Version,'') as [Version]
FROM
	IPS_Signature as loc
LEFT JOIN
	IPS_SignatureTextXlate as sig
ON
	sig.SignatureID=loc.SignatureID and sig.LanguageID=@LocaleID
LEFT JOIN
	IPS_SignatureTextXlate as eng
ON
	loc.SignatureID=eng.SignatureID and eng.LanguageID=@DefaultLocale

END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SET_SignatureTextXlate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[IPS_SET_SignatureTextXlate]
GO


CREATE PROCEDURE [dbo].[IPS_SET_SignatureTextXlate]
(
	@SignatureID INT ,
	@LanguageID  INT,
	@SignatureName NVARCHAR(256) ,
	@SignatureStat NVARCHAR(4000) ,
	@SignatureFP NVARCHAR(4000)
)
AS
BEGIN
	SET NOCOUNT ON
	SET XACT_ABORT ON

	UPDATE
		[IPS_SignatureTextXlate]
	SET
		SignatureName = @SignatureName,
		SignatureStat = @SignatureStat,
		SignatureFP = @SignatureFP
	WHERE
		[SignatureID] = @SignatureID
		AND  [LanguageID] = @LanguageID

	IF (@@ROWCOUNT = 0)
	BEGIN

		INSERT INTO [IPS_SignatureTextXlate]
		(
			[SignatureID],
			[LanguageID],
			[SignatureName],
			[SignatureStat],
			[SignatureFP])
		VALUES
			(
			@SignatureID,
			@LanguageID,
			@SignatureName,
			@SignatureStat,
			@SignatureFP
			);
	END

END
GO
-----------------------------------------END Ips_Signature and IPS_SignatureTextXlate for buffer overflow signatures-------------------------------------

--View for the TP event aggregration data source
-- refer to create-tp-events-view-mt.sql
