------------------------------------------------------------------
--Copyright (c) 2016 McAfee Inc. - All Rights Reserved
------------------------------------------------------------------
-- insert 10.5.0 product technology data
if not exists(select 1 from [dbo].[EAMP.GSE.Blades] where [ProductCode] = N'ENDP_AM_1050')
begin
    INSERT INTO [dbo].[EAMP.GSE.Blades]([ProductCode], [DispName], [TechnologyCount]) VALUES
        (N'ENDP_AM_1050', N'Endpoint Security Threat Prevention', 4)
end
GO

if not exists(select [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'AM_CustomPropsMT' and [COLUMN_NAME] = N'AMCoreContentDate')
begin
	alter table [AM_CustomPropsMT]
		add [AMCoreContentDate] datetime NULL
end
GO
