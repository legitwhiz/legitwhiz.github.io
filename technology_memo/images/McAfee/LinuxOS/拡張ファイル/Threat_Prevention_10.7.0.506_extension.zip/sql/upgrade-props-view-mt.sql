
-- Views must be recreated if any new columns are added to base table
-- View is now the same for both cloud and on-prem, EPOProdPropsView_THREATPREVENTION does the tenant filtering
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view [dbo].[AM_CustomProps]
GO
create view [dbo].[AM_CustomProps] AS
	select am.*, pp.[ParentID] [LeafNodeID],
		[ODSFullAverageScanDuration] =
		CASE
			WHEN [ODSLastFullScanDuration] IS NULL THEN 'Unknown'
			WHEN [ODSLastFullScanDuration] < 1 * 60 * 60 THEN '< 1'
			WHEN [ODSLastFullScanDuration] < 2 * 60 * 60 THEN '1'
			WHEN [ODSLastFullScanDuration] < 3 * 60 * 60 THEN '2'
			WHEN [ODSLastFullScanDuration] < 4 * 60 * 60 THEN '3'
			WHEN [ODSLastFullScanDuration] < 5 * 60 * 60 THEN '4'
			WHEN [ODSLastFullScanDuration] < 6 * 60 * 60 THEN '5'
			WHEN [ODSLastFullScanDuration] < 7 * 60 * 60 THEN '6'
			WHEN [ODSLastFullScanDuration] < 8 * 60 * 60 THEN '7'
			WHEN [ODSLastFullScanDuration] < 9 * 60 * 60 THEN '8'
			WHEN [ODSLastFullScanDuration] >= 9 * 60 * 60 THEN '9+'
		END,
		[ODSQuickAverageScanDuration] =
		CASE
			WHEN [ODSLastQuickScanDuration] IS NULL THEN 'Unknown'
			WHEN [ODSLastQuickScanDuration] < 5 * 60 THEN '< 5'
			WHEN [ODSLastQuickScanDuration] < 10 * 60 THEN '05 - 09'
			WHEN [ODSLastQuickScanDuration] < 15 * 60 THEN '10 - 14'
			WHEN [ODSLastQuickScanDuration] < 20 * 60 THEN '15 - 19'
			WHEN [ODSLastQuickScanDuration] < 25 * 60 THEN '20 - 24'
			WHEN [ODSLastQuickScanDuration] < 30 * 60 THEN '25 - 29'
			WHEN [ODSLastQuickScanDuration] >=30 * 60 THEN '30+'
		END,
		pp.[ProductCode]
	from [AM_CustomPropsMT] am
		inner join [EPOProductProperties_Fast] pp ON am.[ParentID] = pp.[AutoID]
	where am.[TenantId] = convert(int, substring(CONTEXT_INFO(), 5, 4))
GO

grant select,insert,update,delete on [dbo].[AM_CustomProps] TO [mcafeeOps];
grant select,insert,update,delete on [dbo].[AM_CustomProps] TO [mcafeeTenant];
GO