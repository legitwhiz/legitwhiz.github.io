------------------------------------------------------------------
--Copyright (c) 2020 McAfee LLC - All Rights Reserved
------------------------------------------------------------------
-- insert 10.7.0 product technology data
IF NOT EXISTS(SELECT 1 FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_AM_1070')
BEGIN
    INSERT INTO [dbo].[EAMP.GSE.Blades]([ProductCode], [DispName], [TechnologyCount]) VALUES
        (N'ENDP_AM_1070', N'Endpoint Security Threat Prevention', 4)
END
GO

