DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] in ( N'ENDP_AM_1050LYNX')
GO