/*  Copyright (c) 2018 McAfee LLC. - All Rights Reserved  */

-- Drop \ create the TP_Events view. --
if exists (select 1 from dbo.sysobjects where [id] = object_id(N'TP_Events') and OBJECTPROPERTY([id], N'IsView') = 1)
	drop view [dbo].[TP_Events]
go

create view [dbo].[TP_Events] as
	select ln.[AutoID] [leafNodeId], e.*, ex.*
		from [EPOLeafNode] ln
			inner join [EPOEvents] e on ln.[TenantId] = e.[TenantId] and ln.[AgentGUID] = e.[AgentGUID]
			inner join [EPExtendedEvent] ex on e.[AutoID] = ex.[EventAutoID]
		where e.[ThreatEventId] in (18051,18052,18053,18054,18055,18056,18057)
go
