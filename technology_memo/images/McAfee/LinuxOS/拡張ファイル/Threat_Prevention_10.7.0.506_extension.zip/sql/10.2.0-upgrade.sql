-- insert 10.2.0 product technology data
if not exists(select 1 from [dbo].[EAMP.GSE.Blades] where [ProductCode] = N'ENDP_AM_1020')
begin
    INSERT INTO [dbo].[EAMP.GSE.Blades]([ProductCode], [DispName], [TechnologyCount]) VALUES
        (N'ENDP_AM_1020', N'Endpoint Security Threat Prevention', 4)
end
GO

-- Add the V2 DAT column for non-windows products --
if not exists(select [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'AM_CustomPropsMT' and [COLUMN_NAME] = N'V2DATVersion')
begin
	alter table [AM_CustomPropsMT]
		add [V2DATVersion] nvarchar(20) NULL
end
GO
