-- Dropping 10.5.5 Mac Product id
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_AM_1055MACX'
if not exists(select [ProductCode] from [EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_AM_1000MACX')
begin
	INSERT INTO [dbo].[EAMP.GSE.Blades]
	  ([ProductCode],
	  [DispName],
	  [TechnologyCount])
	  VALUES (
	  N'ENDP_AM_1000MACX',
	  N'Endpoint Security Anti Malware',
	  1
	)
end
GO
