
if exists (select 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[AMBladeTechView]') and OBJECTPROPERTY(id, N'IsView') = 1)
begin
    drop view [dbo].[AMBladeTechView]
end
GO

create view [dbo].[AMBladeTechView] as
    select pp.[AutoIDOAS] [AutoID], pp.[LeafNodeID], 1 [TechnologyType], pp.[bOASEnabled] [Enabled], pp.[ProductCode]
        from [AM_CustomProps] pp with(nolock)
    union
    select pp.[AutoIDBO] [AutoID], pp.[LeafNodeID], 2 [TechnologyType], pp.[bOASEnabled] [Enabled], pp.[ProductCode]
        from [AM_CustomProps] pp with(nolock)
        where pp.[ProductCode] <> N'ENDP_AM_1000MACX'
    union
    select pp.[AutoIDAP] [AutoID], pp.[LeafNodeID], 3 [TechnologyType], pp.[bOASEnabled] [Enabled], pp.[ProductCode]
        from [AM_CustomProps] pp with(nolock)
        where pp.[ProductCode] <> N'ENDP_AM_1000MACX'
    union
    select pp.[AutoIDSS] [AutoID], pp.[LeafNodeID], 4 [TechnologyType], pp.[bOASEnabled] [Enabled], pp.[ProductCode]
        from [AM_CustomProps] pp with(nolock)
        where pp.[ProductCode] <> N'ENDP_AM_1000MACX'
GO