
if not exists(select 1 from [dbo].[EAMP.GSE.Blades] where [ProductCode] = N'ENDP_AM_1050LYNX')
BEGIN

    INSERT INTO [dbo].[EAMP.GSE.Blades]([ProductCode], [DispName], [TechnologyCount])
    VALUES  (N'ENDP_AM_1050LYNX', N'Endpoint Security Threat Prevention', 1)  -- linux product
END

GO