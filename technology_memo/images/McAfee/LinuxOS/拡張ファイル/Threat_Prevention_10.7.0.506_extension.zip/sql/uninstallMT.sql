------------------------------------------------------------------
--Copyright (c) 2015 McAfee Inc. - All Rights Reserved
------------------------------------------------------------------

DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] in (N'ENDP_AM_1000', N'ENDP_AM_1010', N'ENDP_AM_1020', N'ENDP_AM_1050', N'ENDP_AM_1060', N'ENDP_AM_1070', N'ENDP_AM_1000MACX', N'ENDP_AM_1020LYNX', N'ENDP_AM_1050LYNX',  N'ENDP_AM_1060LYNX', N'ENDP_AM_1055MACX', N'ENDP_AM_1060MACX', N'ENDP_AM_1066MACX', N'ENDP_AM_1066LYNX')
GO

-----------------------------------------Start AM_CustomPropsMT Table and AM_CustomProps View-------------------------------------
--first drop the view
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[AM_CustomProps]
GO
--next delete the foreign key
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_AM_CustomPropsMT_EPOProductPropertiesMT]') AND parent_object_id = OBJECT_ID(N'[dbo].[AM_CustomPropsMT]'))
ALTER TABLE [dbo].[AM_CustomPropsMT] DROP CONSTRAINT [FK_AM_CustomPropsMT_EPOProductPropertiesMT]
GO
--finally drop the table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AM_CustomPropsMT]') AND type in (N'U'))
DROP TABLE [dbo].[AM_CustomPropsMT]
GO
-----------------------------------------End AM_CustomPropsMT Table and AM_CustomProps View-------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[AM_EndpointTechnologyStatus_View]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[SP_EndpointTechnologyStatus_View]
GO



-----------------------------------------Start Ips_Signature and IPS_SignatureTextXlate for buffer overflow signatures-------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[IPS_Signature]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[IPS_Signature]
  END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_Signature]') AND type in (N'U'))
  DROP TABLE [dbo].[IPS_Signature]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureMT]') AND type in (N'U'))
  DROP TABLE [dbo].[IPS_SignatureMT]
GO


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[IPS_SignatureTextXlate]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[IPS_SignatureTextXlate]
  END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureTextXlateMT]') AND type in (N'U'))
DROP TABLE [dbo].[IPS_SignatureTextXlateMT]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureTextXlate]') AND type in (N'U'))
  DROP TABLE [dbo].[IPS_SignatureTextXlate]
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SET_Signature]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[IPS_SET_Signature]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_GET_SignatureLocalized]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[IPS_GET_SignatureLocalized]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SET_SignatureTextXlate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[IPS_SET_SignatureTextXlate]
GO

-----------------------------------------END Ips_Signature and IPS_SignatureTextXlate for buffer overflow signatures-------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[AMBladeTechView]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[AMBladeTechView]
  END
GO

--View for the TP event aggregration data source
if exists (select * from dbo.sysobjects where id = object_id(N'TP_Events') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW TP_Events
GO
