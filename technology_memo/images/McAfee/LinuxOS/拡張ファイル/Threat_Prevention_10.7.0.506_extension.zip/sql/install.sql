------------------------------------------------------------------
--Copyright (c) 2015 McAfee Inc. - All Rights Reserved
------------------------------------------------------------------

-- Make sure there is only one installed blade record
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] in (N'ENDP_AM_1000', N'ENDP_AM_1010', N'ENDP_AM_1020', N'ENDP_AM_1050', N'ENDP_AM_1060', N'ENDP_AM_1070', N'ENDP_AM_1000MACX',  N'ENDP_AM_1055MACX', N'ENDP_AM_1060MACX', N'ENDP_AM_1066MACX', N'ENDP_AM_1020LYNX', N'ENDP_AM_1050LYNX', N'ENDP_AM_1060LYNX', N'ENDP_AM_1066LYNX')
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]([ProductCode], [DispName], [TechnologyCount]) VALUES
  (N'ENDP_AM_1000', N'Endpoint Security Threat Prevention', 4), -- windows product 10.0
  (N'ENDP_AM_1010', N'Endpoint Security Threat Prevention', 4), -- windows product 10.1
  (N'ENDP_AM_1020', N'Endpoint Security Threat Prevention', 4), -- windows product 10.2
  (N'ENDP_AM_1050', N'Endpoint Security Threat Prevention', 4), -- windows product 10.5
  (N'ENDP_AM_1060', N'Endpoint Security Threat Prevention', 4), -- windows product 10.6
  (N'ENDP_AM_1070', N'Endpoint Security Threat Prevention', 4), -- windows product 10.7
  (N'ENDP_AM_1000MACX', N'Endpoint Security Threat Prevention', 1),  -- mac product
  (N'ENDP_AM_1055MACX', N'Endpoint Security Threat Prevention', 1),  -- mac 10.5.5 product
  (N'ENDP_AM_1060MACX', N'Endpoint Security Threat Prevention', 1),  -- mac 10.6 product
  (N'ENDP_AM_1066MACX', N'Endpoint Security Threat Prevention', 1),  -- mac 10.6.6 product
  (N'ENDP_AM_1020LYNX', N'Endpoint Security Threat Prevention', 1),  -- linux 10.2 product
  (N'ENDP_AM_1050LYNX', N'Endpoint Security Threat Prevention', 1),  -- linux 10.5 product
  (N'ENDP_AM_1060LYNX', N'Endpoint Security Threat Prevention', 1),  -- linux 10.6 product
  (N'ENDP_AM_1066LYNX', N'Endpoint Security Threat Prevention', 1)  -- linux 10.6.6 product
GO

-----------------------------------------Start AM_CustomPropsMT Table and AM_CustomProps View-------------------------------------
--CUSTOM PROPERTIES TABLE
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[AM_CustomPropsMT](
    [AutoID]                                 [int] NOT NULL IDENTITY (1,1),
    [ParentID]                               [int] NOT NULL,             -- Required for custom properties

    [bOASEnabled]                            [bit] NOT NULL CONSTRAINT DF_AM_CustomPropsMT_bOASEnabled DEFAULT ((0)),
    [AutoIDOAS]                              [uniqueidentifier] DEFAULT NEWSEQUENTIALID(),
    [bAPEnabled]                             [bit] NOT NULL CONSTRAINT DF_AM_CustomPropsMT_bAPEnabled DEFAULT ((0)),
    [AutoIDAP]                               [uniqueidentifier] DEFAULT NEWSEQUENTIALID(),
    [bBOEnabled]                             [bit] NOT NULL CONSTRAINT DF_AM_CustomPropsMT_bBOEnabled DEFAULT ((0)),
    [AutoIDBO]                               [uniqueidentifier] DEFAULT NEWSEQUENTIALID(),
    [bScriptScanEnabled]                     [bit] NOT NULL CONSTRAINT DF_AM_CustomPropsMT_bScriptScanEnabled DEFAULT ((0)),
    [AutoIDSS]                               [uniqueidentifier] DEFAULT NEWSEQUENTIALID(),

--     [EmailEnabled]                           [nvarchar] (100) NULL,
    [AVCMComplianceDays]                     [nvarchar] (100) NULL,
    [OASbComplianceStatus]                   [bit] NOT NULL CONSTRAINT DF_AM_CustomPropsMT_OASbComplianceStatus DEFAULT ((0)),
    [OASComplianceStatus]                    [nvarchar] (100) NULL,
    [OASAdditionalComplianceStatus]          [nvarchar] (100) NULL,
    [OASGTILevel]                            [tinyint] NULL,
    [ODSbComplianceStatus]                   [bit] NOT NULL CONSTRAINT DF_AM_CustomPropsMT_ODSbComplianceStatus DEFAULT ((0)),
    [ODSComplianceStatus]                    [nvarchar] (100) NULL,
    [ODSAdditionalComplianceStatus]          [nvarchar] (100) NULL,
    [ODSLastFullScanDuration]                [int],
    [ODSLastQuickScanDuration]               [int],
    [ODSLastFullScanDate]                    [datetime] NULL,
    [ODSLastQuickScanDate]                   [datetime] NULL,
    [ODSFullScanGTILevel]                    [tinyint] NULL,
    [ODSQuickScanGTILevel]                   [tinyint] NULL,
    [ODSRightClickScanGTILevel]              [tinyint] NULL,
--     [ODSCustomScanGTILevel]                  [tinyint] NULL,
--     [EmailScannerbComplianceStatus]          [bit] NOT NULL CONSTRAINT DF_AM_CustomPropsMT_EmailScannerbComplianceStatus DEFAULT ((0)),
--     [EmailScannerComplianceStatus]           [nvarchar] (100) NULL,
--     [EmailScannerAdditionalComplianceStatus] [nvarchar] (100) NULL,
    [AVCMGRbComplianceStatus]                [bit] NOT NULL CONSTRAINT DF_AM_CustomPropsMT_AVCMGRbComplianceStatus DEFAULT ((0)),
    [AVCMGRComplianceStatus]                 [nvarchar] (100) NULL,
    [AVCMGRAdditionalComplianceStatus]       [nvarchar] (100) NULL,
    [BObComplianceStatus]                    [bit] NOT NULL CONSTRAINT DF_AM_CustomPropsMT_BObComplianceStatus DEFAULT ((0)),
    [BOComplianceStatus]                     [nvarchar] (100) NULL,
    [BOAdditionalComplianceStatus]           [nvarchar] (100) NULL,
    [SSbComplianceStatus]                    [bit] NOT NULL CONSTRAINT DF_AM_CustomPropsMT_SSbComplianceStatus DEFAULT ((0)),
    [SSComplianceStatus]                     [nvarchar] (100) NULL,
    [SSAdditionalComplianceStatus]           [nvarchar] (100) NULL,
    [APbComplianceStatus]                    [bit] NOT NULL CONSTRAINT DF_AM_CustomPropsMT_APbComplianceStatus DEFAULT ((0)),
    [APComplianceStatus]                     [nvarchar] (100) NULL,
    [APAdditionalComplianceStatus]           [nvarchar] (100) NULL,
    [V2DATVersion]                           [nvarchar] (20) NULL,
    [ManifestVersion]                        [nvarchar] (20) NULL,
    [EngineVersion]                          [nvarchar] (20) NULL,
    [Hotfixes]                               [nvarchar] (256) NULL,
    [Patch]                                  [nvarchar] (3000) NULL,
    [LicenseStatus]                          [nvarchar] (256) NULL,
    [Language]                               [nvarchar] (256) NULL,
    [szExtraDATNames]                        [nvarchar] (3000) NULL,
    [AMCoreContentDate]                      [datetime] NULL,
    [ExploitPreventionContentCreated]        [datetime] NULL,
    [ExploitPreventionContentVersion]        [nvarchar](128) NULL,
    [scanUsingAMSIHooks]                     [bit] NULL,
    [enableAMSIObserveMode]                  [bit] NULL,
	[TPAMSISupportedStatus]                  [bit] NULL,
	[TPAMSISupportedStatusReason]            [nvarchar](256) NULL,
 CONSTRAINT [PK_AM_CustomPropsMT] PRIMARY KEY CLUSTERED
(
    [AutoID] ASC
)
)
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_AM_CustomPropsMT_EPOProductProperties]') AND parent_object_id = OBJECT_ID(N'[dbo].[AM_CustomPropsMT]'))
BEGIN
ALTER TABLE [dbo].[AM_CustomPropsMT] ADD
    CONSTRAINT [FK_AM_CustomPropsMT_EPOProductProperties] FOREIGN KEY (
        [ParentID]
    ) REFERENCES [dbo].[EPOProductProperties] (
        [AutoID]
    ) ON DELETE CASCADE ON UPDATE NO ACTION
END
GO

--create unique index on the foreign key column
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_ParentID')
BEGIN
CREATE UNIQUE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_ParentID] ON [dbo].[AM_CustomPropsMT]
(
    [ParentID] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_AutoIDOAS')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_AutoIDOAS] ON [dbo].[AM_CustomPropsMT]
(
    [AutoIDOAS] ASC
)
END
GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_bOASEnabled')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_bOASEnabled] ON [dbo].[AM_CustomPropsMT]
-- (
--     [bOASEnabled] ASC
-- )
-- END
-- GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_bAPEnabled')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_bAPEnabled] ON [dbo].[AM_CustomPropsMT]
-- (
--     [bAPEnabled] ASC
-- )
-- END
-- GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_bBOEnabled')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_bBOEnabled] ON [dbo].[AM_CustomPropsMT]
-- (
--     [bBOEnabled] ASC
-- )
-- END
-- GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_bScriptScanEnabled')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_bScriptScanEnabled] ON [dbo].[AM_CustomPropsMT]
-- (
--     [bScriptScanEnabled] ASC
-- )
-- END
-- GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_OASbComplianceStatus')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_OASbComplianceStatus] ON [dbo].[AM_CustomPropsMT]
-- (
--     [OASbComplianceStatus] ASC
-- )
-- END
-- GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_OASGTILevel')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_OASGTILevel] ON [dbo].[AM_CustomPropsMT]
-- (
--     [OASGTILevel] ASC
-- )
-- END
-- GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_ODSbComplianceStatus')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_ODSbComplianceStatus] ON [dbo].[AM_CustomPropsMT]
-- (
--     [ODSbComplianceStatus] ASC
-- )
-- END
-- GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_ODSLastFullScanDuration')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_ODSLastFullScanDuration] ON [dbo].[AM_CustomPropsMT]
(
    [ODSLastFullScanDuration] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_ODSLastQuickScanDuration')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_ODSLastQuickScanDuration] ON [dbo].[AM_CustomPropsMT]
(
    [ODSLastQuickScanDuration] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_ODSLastFullScanDate')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_ODSLastFullScanDate] ON [dbo].[AM_CustomPropsMT]
(
    [ODSLastFullScanDate] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_ODSLastQuickScanDate')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_ODSLastQuickScanDate] ON [dbo].[AM_CustomPropsMT]
(
    [ODSLastQuickScanDate] ASC
)
END
GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_ODSFullScanGTILevel')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_ODSFullScanGTILevel] ON [dbo].[AM_CustomPropsMT]
-- (
--     [ODSFullScanGTILevel] ASC
-- )
-- END
-- GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_ODSQuickScanGTILevel')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_ODSQuickScanGTILevel] ON [dbo].[AM_CustomPropsMT]
-- (
--     [ODSQuickScanGTILevel] ASC
-- )
-- END
-- GO

/*IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_ODSRightClickScanGTILevel')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_ODSRightClickScanGTILevel] ON [dbo].[AM_CustomPropsMT]
(
    [ODSRightClickScanGTILevel] ASC
)
END
GO*/

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_ODSCustomScanGTILevel')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_ODSCustomScanGTILevel] ON [dbo].[AM_CustomPropsMT]
-- (
--     [ODSCustomScanGTILevel] ASC
-- )
-- END
-- GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_AVCMGRbComplianceStatus')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_AVCMGRbComplianceStatus] ON [dbo].[AM_CustomPropsMT]
(
    [AVCMGRbComplianceStatus] ASC
)
END
GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_BObComplianceStatus')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_BObComplianceStatus] ON [dbo].[AM_CustomPropsMT]
-- (
--     [BObComplianceStatus] ASC
-- )
-- END
-- GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_SSbComplianceStatus')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_SSbComplianceStatus] ON [dbo].[AM_CustomPropsMT]
-- (
--     [SSbComplianceStatus] ASC
-- )
-- END
-- GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_APbComplianceStatus')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_APbComplianceStatus] ON [dbo].[AM_CustomPropsMT]
-- (
--     [APbComplianceStatus] ASC
-- )
-- END
-- GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_ManifestVersion')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_ManifestVersion] ON [dbo].[AM_CustomPropsMT]
(
    [ManifestVersion] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_Hotfixes')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_Hotfixes] ON [dbo].[AM_CustomPropsMT]
(
    [Hotfixes] ASC
)
END
GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[AM_CustomPropsMT]') AND name = N'IX_AM_CustomPropsMT_ExploitPreventionContentVersion')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_AM_CustomPropsMT_ExploitPreventionContentVersion] ON [dbo].[AM_CustomPropsMT]
-- (
--     [ExploitPreventionContentVersion] ASC
-- )
-- END
-- GO

--NOW CREATE THE VIEW FOR THE AM_CustomPropsMT Table
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[AM_CustomProps]
GO
CREATE VIEW [dbo].[AM_CustomProps] AS
    SELECT am.*, pp.[ParentID] [LeafNodeID],
    ODSFullAverageScanDuration =
    CASE
        WHEN ODSLastFullScanDuration IS NULL THEN 'Unknown'
        WHEN ODSLastFullScanDuration < 1 * 60 * 60 THEN '< 1'
        WHEN ODSLastFullScanDuration < 2 * 60 * 60 THEN '1'
        WHEN ODSLastFullScanDuration < 3 * 60 * 60 THEN '2'
        WHEN ODSLastFullScanDuration < 4 * 60 * 60 THEN '3'
        WHEN ODSLastFullScanDuration < 5 * 60 * 60 THEN '4'
        WHEN ODSLastFullScanDuration < 6 * 60 * 60 THEN '5'
        WHEN ODSLastFullScanDuration < 7 * 60 * 60 THEN '6'
        WHEN ODSLastFullScanDuration < 8 * 60 * 60 THEN '7'
        WHEN ODSLastFullScanDuration < 9 * 60 * 60 THEN '8'
        WHEN ODSLastFullScanDuration >= 9 * 60 * 60 THEN '9+'
    END,
    ODSQuickAverageScanDuration =
    CASE
        WHEN ODSLastQuickScanDuration IS NULL THEN 'Unknown'
        WHEN ODSLastQuickScanDuration < 5 * 60 THEN '< 5'
        WHEN ODSLastQuickScanDuration < 10 * 60 THEN '05 - 09'
        WHEN ODSLastQuickScanDuration < 15 * 60 THEN '10 - 14'
        WHEN ODSLastQuickScanDuration < 20 * 60 THEN '15 - 19'
        WHEN ODSLastQuickScanDuration < 25 * 60 THEN '20 - 24'
        WHEN ODSLastQuickScanDuration < 30 * 60 THEN '25 - 29'
        WHEN ODSLastQuickScanDuration >=30 * 60 THEN '30+'
    END,
    pp.[ProductCode], pp.[TheHiddenTimestamp] [timestamp]
    FROM [AM_CustomPropsMT] am
      inner join  [EPOProductProperties] pp ON am.[ParentID] = pp.[AutoID]
GO
-----------------------------------------End AM_CustomPropsMT Table and AM_CustomProps View-------------------------------------

-- GSE extension upgrades all Tech Status views.
-- Make sure to update GSE extension if there are any changes to this view
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[SP_EndpointTechnologyStatus_View]
GO
CREATE VIEW [dbo].[SP_EndpointTechnologyStatus_View] AS
    SELECT PP.[AutoIDOAS] [AutoID], PP.[LeafNodeID], 1 [TechnologyType], PP.[bOASEnabled] [Enabled], PP.[ProductCode]
      FROM  [AM_CustomProps] PP WITH(NOLOCK)
    UNION
    SELECT PP.[AutoIDBO] [AutoID], PP.[LeafNodeID], 2 [TechnologyType], PP.[bBOEnabled] [Enabled], PP.[ProductCode]
      FROM  [AM_CustomProps] PP WITH(NOLOCK)
      WHERE [ProductCode] <> N'ENDP_AM_1000MACX'
    UNION
    SELECT PP.[AutoIDAP] [AutoID], PP.[LeafNodeID], 3 [TechnologyType], PP.[bAPEnabled] [Enabled], PP.[ProductCode]
      FROM  [AM_CustomProps] PP WITH(NOLOCK)
      WHERE ProductCode <> N'ENDP_AM_1000MACX'
    UNION
    SELECT PP.[AutoIDSS] [AutoID], PP.[LeafNodeID], 4 [TechnologyType], PP.[bScriptScanEnabled] [Enabled], PP.[ProductCode]
      FROM  [AM_CustomProps] PP WITH(NOLOCK)
      WHERE ProductCode <> N'ENDP_AM_1000MACX'
GO


-----------------------------------------Start Ips_Signature and IPS_SignatureTextXlate for buffer overflow signatures-------------------------------------
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[IPS_SignatureMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[IPS_SignatureMT](
	[SignatureID] [int] NOT NULL,
	[cveLink] [varchar](1000) NULL,
	[SigType] [varchar](50) NOT NULL,
	[Severity]  [char](1) NOT NULL,
	[SignatureType] varchar(10) NOT NULL,
	[Version] varchar(15) NOT NULL,

 CONSTRAINT [PK_IPS_SIGNATUREMT] PRIMARY KEY CLUSTERED
(
	[SignatureID] ASC
))
END
GO


--NOW CREATE THE VIEW FOR THE IPS_SignatureMT Table
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[IPS_Signature]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[IPS_Signature]
GO

CREATE VIEW [dbo].[IPS_Signature] AS
  SELECT [SignatureID]
        ,[cveLink]
        ,[SigType]
        ,[Severity]
        ,[SignatureType]
        ,[Version]
    FROM
      [IPS_SignatureMT]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[IPS_SignatureTextXlateMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[IPS_SignatureTextXlateMT](
	[SignatureID] [int] NOT NULL,
	[LanguageID] [int] NOT NULL,
	[SignatureName] [nvarchar](256) NOT NULL,
	[SignatureStat] [nvarchar](4000)  NULL,
	[SignatureFP] [nvarchar](4000)  NULL,
 CONSTRAINT [PK_IPS_SignatureTextXlateMT] PRIMARY KEY CLUSTERED
(
	[SignatureID] ASC,
	[LanguageID] ASC

) ON [PRIMARY]
)
END
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[IPS_SignatureTextXlate]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[IPS_SignatureTextXlate]
GO
CREATE VIEW [dbo].[IPS_SignatureTextXlate] AS
  SELECT
        [SignatureID]
        ,[LanguageID]
        ,[SignatureName]
        ,[SignatureStat]
        ,[SignatureFP]
    FROM
      [IPS_SignatureTextXlateMT]

GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SET_Signature]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[IPS_SET_Signature]
GO

CREATE PROCEDURE [dbo].[IPS_SET_Signature]
(
	@SignatureID		INT,
	@cveValue	NVARCHAR(1000),
	@SigType varchar(50),
	@Severity char (1),
	@SignatureType varchar(10),
	@Version varchar(20)
)
AS
BEGIN
	SET NOCOUNT ON
	SET XACT_ABORT ON

	UPDATE [IPS_Signature]
	SET
	    [cveLink] = @cveValue,
      [SigType] = @SigType,
      [Severity] = @Severity,
      [SignatureType] = @SignatureType,
      [Version] = @Version

	WHERE  [SignatureID] = @SignatureID

	IF (@@ROWCOUNT = 0)
	BEGIN

		INSERT INTO [IPS_SignatureMT] ([SignatureID], [cveLink],[SigType],[Severity],[SignatureType],[Version])
		VALUES (@SignatureID, @cveValue,@SigType,@Severity,@SignatureType,@Version);
	END

END
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_GET_SignatureLocalized]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[IPS_GET_SignatureLocalized]
GO
CREATE PROCEDURE dbo.IPS_GET_SignatureLocalized
(
	@LocaleID  INT,
	@DefaultLocale INT
)
AS
BEGIN
	SET NOCOUNT ON
	SET XACT_ABORT ON

SELECT
	loc.SignatureID,
	COALESCE(sig.signatureName,eng.SignatureName ) as name,
	COALESCE(sig.SignatureStat,eng.SignatureStat ) as stat,
	COALESCE(sig.SignatureFP,eng.SignatureFP ) as FP,
	COALESCE( sig.languageid,eng.languageid) as languageid,
	COALESCE(loc.cvelink,'') as link,
	COALESCE(loc.SigType,'') as SigType,
	COALESCE(loc.Severity,'') as Severity,
	COALESCE(loc.SignatureType,'') as SignatureType,
	COALESCE(loc.Version,'') as [Version]
FROM
	IPS_Signature as loc
LEFT JOIN
	IPS_SignatureTextXlate as sig
ON
	sig.SignatureID=loc.SignatureID and sig.LanguageID=@LocaleID
LEFT JOIN
	IPS_SignatureTextXlate as eng
ON
	loc.SignatureID=eng.SignatureID and eng.LanguageID=@DefaultLocale
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SET_SignatureTextXlate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[IPS_SET_SignatureTextXlate]
GO


CREATE PROCEDURE [dbo].[IPS_SET_SignatureTextXlate]
(
	@SignatureID INT ,
	@LanguageID  INT,
	@SignatureName NVARCHAR(256) ,
	@SignatureStat NVARCHAR(4000) ,
	@SignatureFP NVARCHAR(4000)
)
AS
BEGIN
	SET NOCOUNT ON
	SET XACT_ABORT ON

	UPDATE
		[IPS_SignatureTextXlate]
	SET
		SignatureName = @SignatureName,
		SignatureStat = @SignatureStat,
		SignatureFP = @SignatureFP
	WHERE
		[SignatureID] = @SignatureID
		AND  [LanguageID] = @LanguageID

	IF (@@ROWCOUNT = 0)
	BEGIN

		INSERT INTO [IPS_SignatureTextXlate]
		(
			[SignatureID],
			[LanguageID],
			[SignatureName],
			[SignatureStat],
			[SignatureFP])
		VALUES
			(
			@SignatureID,
			@LanguageID,
			@SignatureName,
			@SignatureStat,
			@SignatureFP
			);
	END

END
GO


-----------------------------------------END Ips_Signature and IPS_SignatureTextXlate for buffer overflow signatures-------------------------------------


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[AMBladeTechView]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW [dbo].[AMBladeTechView]
  END
GO

create view [dbo].[AMBladeTechView] as
    select pp.[AutoIDOAS] [AutoID], pp.[LeafNodeID], 1 [TechnologyType], pp.[bOASEnabled] [Enabled], pp.[ProductCode]
        from [AM_CustomProps] pp with(nolock)
    union
    select pp.[AutoIDBO] [AutoID], pp.[LeafNodeID], 2 [TechnologyType], pp.[bOASEnabled] [Enabled], pp.[ProductCode]
        from [AM_CustomProps] pp with(nolock)
        where pp.[ProductCode] <> N'ENDP_AM_1000MACX'
    union
    select pp.[AutoIDAP] [AutoID], pp.[LeafNodeID], 3 [TechnologyType], pp.[bOASEnabled] [Enabled], pp.[ProductCode]
        from [AM_CustomProps] pp with(nolock)
        where pp.[ProductCode] <> N'ENDP_AM_1000MACX'
    union
    select pp.[AutoIDSS] [AutoID], pp.[LeafNodeID], 4 [TechnologyType], pp.[bOASEnabled] [Enabled], pp.[ProductCode]
        from [AM_CustomProps] pp with(nolock)
        where pp.[ProductCode] <> N'ENDP_AM_1000MACX'
GO

-- View for the TP event aggregration data source --
-- refer to create-tp-events-view.sql

--------- ePO Rollup Reporting ---------
-- AM_CustomProps rollup target --
if not exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ENSRollup_AM_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
	create table [dbo].[ENSRollup_AM_CustomProps]
	(
		[RegSvrId]							[int] not null,
		[AutoID]							[int] not null,
		[ParentID]							[int] not null,
		[bOASEnabled]						[bit] null,
		[AutoIDOAS]							[uniqueidentifier] null,
		[bAPEnabled]						[bit] null,
		[AutoIDAP]							[uniqueidentifier] null,
		[bBOEnabled]						[bit] null,
		[AutoIDBO]							[uniqueidentifier] null,
		[bScriptScanEnabled]				[bit] null,
		[AutoIDSS]							[uniqueidentifier] null,

		[AVCMComplianceDays]				[nvarchar](100) null,
		[OASbComplianceStatus]				[bit] null,
		[OASComplianceStatus]				[nvarchar](100) null,
		[OASAdditionalComplianceStatus]		[nvarchar](100) null,
		[OASGTILevel]						[tinyint] null,
		[ODSbComplianceStatus]				[bit] null,
		[ODSComplianceStatus]				[nvarchar](100) null,
		[ODSAdditionalComplianceStatus]		[nvarchar](100) null,
		[ODSLastFullScanDuration]			[int],
		[ODSLastQuickScanDuration]			[int],
		[ODSLastFullScanDate]				[datetime] null,
		[ODSLastQuickScanDate]				[datetime] null,
		[ODSFullScanGTILevel]				[tinyint] null,
		[ODSQuickScanGTILevel]				[tinyint] null,
		[ODSRightClickScanGTILevel]			[tinyint] null,
		[AVCMGRbComplianceStatus]			[bit] null,
		[AVCMGRComplianceStatus]			[nvarchar](100) null,
		[AVCMGRAdditionalComplianceStatus]	[nvarchar](100) null,
		[BObComplianceStatus]				[bit] null,
		[BOComplianceStatus]				[nvarchar](100) null,
		[BOAdditionalComplianceStatus]		[nvarchar](100) null,
		[SSbComplianceStatus]				[bit] null,
		[SSComplianceStatus]				[nvarchar](100) null,
		[SSAdditionalComplianceStatus]		[nvarchar](100) null,
		[APbComplianceStatus]				[bit] null,
		[APComplianceStatus]				[nvarchar](100) null,
		[APAdditionalComplianceStatus]		[nvarchar](100) null,
		[V2DATVersion]						[nvarchar](20) null,
		[ManifestVersion]					[nvarchar](20) null,
		[EngineVersion]						[nvarchar](20) null,
		[Hotfixes]							[nvarchar](256) null,
		[Patch]								[nvarchar](3000) null,
		[LicenseStatus]						[nvarchar](256) null,
		[Language]							[nvarchar](256) null,
		[szExtraDATNames]					[nvarchar](3000) null,
		[AMCoreContentDate]					[datetime] null,
		[ExploitPreventionContentCreated]	[datetime] null,
		[ExploitPreventionContentVersion]	[nvarchar](128) null,
		[scanUsingAMSIHooks]              [bit] null,
		[enableAMSIObserveMode]           [bit] null,
		[TPAMSISupportedStatus]             [bit] NULL,
	    [TPAMSISupportedStatusReason]       [nvarchar](256) NULL,
		constraint [PK_ENSRollup_AM_CustomProps] primary key clustered
		([RegSvrId] asc, [AutoID] asc)
	)
end
go

if not exists (select 1 from [sys].[foreign_keys] where [object_id] = OBJECT_ID(N'[FK_ENSRollup_AM_CustomProps_EPORollup_ProductProperties]') and [parent_object_id] = OBJECT_ID(N'[dbo].[ENSRollup_AM_CustomProps]'))
begin
	alter table [dbo].[ENSRollup_AM_CustomProps] add
	constraint [FK_ENSRollup_AM_CustomProps_EPORollup_ProductProperties] foreign key
		([RegSvrId], [ParentID])
		references [dbo].[EPORollup_ProductProperties]
		([ServerId], [ExternalId])
		on delete cascade on update no action
end
go

--create unique index on the foreign key
if exists(select 1 from [dbo].[sysobjects] where [id] = OBJECT_ID(N'[dbo].[ENSRollup_AM_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
	and not exists(select 1 from [dbo].[sysindexes] where [id] = OBJECT_ID(N'[dbo].[ENSRollup_AM_CustomProps]') and [name] = N'IX_ENSRollup_AM_CustomProps_ParentID')
begin
	create unique nonclustered index [IX_ENSRollup_AM_CustomPropss_ParentID] on [dbo].[ENSRollup_AM_CustomProps]
		([RegSvrId] asc, [ParentID] asc)
end
go
