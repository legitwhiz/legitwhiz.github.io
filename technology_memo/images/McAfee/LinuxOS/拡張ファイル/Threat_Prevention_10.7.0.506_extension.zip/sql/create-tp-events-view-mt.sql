/*  Copyright (c) 2018 McAfee LLC. - All Rights Reserved  */

-- Drop \ create the TP_Events view. --
if exists (select 1 from dbo.sysobjects where [id] = object_id(N'TP_Events') and OBJECTPROPERTY([id], N'IsView') = 1)
	drop view [dbo].[TP_Events]
go

/*
Select columns from EPExtendedEvents individually, both EPOEvents and EPExtendedEvents have TenantId columns.
*/
create view [dbo].[TP_Events] as
	select ln.[AutoID] [leafNodeId], e.*, ex.[Location], ex.[BladeName], ex.[AnalyzerTechnologyVersion],
			ex.[AnalyzerContentCreationDate], ex.[AnalyzerContentVersion], ex.[AMCoreContentVersion], ex.[AnalyzerRuleID],
			ex.[AnalyzerRuleName], ex.[AnalyzerRegInfo], ex.[AnalyzerGTIQuery], ex.[ThreatDetectedOnCreation],
			ex.[ThreatImpact], ex.[SourcePort], ex.[SourceShareName], ex.[SourceProcessHash], ex.[SourceProcessSigned],
			ex.[SourceProcessSigner], ex.[SourceParentProcessName], ex.[SourceParentProcessHash],
			ex.[SourceParentProcessSigned], ex.[SourceParentProcessSigner], ex.[SourceFilePath], ex.[SourceFileSize],
			ex.[SourceHash], ex.[SourceSigned], ex.[SourceSigner], ex.[SourceModifyTime], ex.[SourceAccessTime],
			ex.[SourceCreateTime], ex.[SourceDeviceDisplayName], ex.[SourceDeviceSerialNumber], ex.[SourceDeviceVID],
			ex.[SourceDevicePID], ex.[SourceDescription], ex.[SourceURLRatingCode], ex.[SourceURLWebCategory], ex.[TargetURL],
			ex.[TargetShareName], ex.[TargetHash], ex.[TargetSigned], ex.[TargetSigner], ex.[TargetParentProcessSigned],
			ex.[TargetParentProcessSigner], ex.[TargetParentProcessName], ex.[TargetParentProcessHash], ex.[TargetName],
			ex.[TargetPath], ex.[TargetFileSize], ex.[TargetModifyTime], ex.[TargetAccessTime], ex.[TargetCreateTime],
			ex.[TargetDeviceDisplayName], ex.[TargetDeviceSerialNumber], ex.[TargetDeviceVID], ex.[TargetDevicePID],
			ex.[TargetDescription], ex.[Cleanable], ex.[TaskName], ex.[APIName], ex.[FirstAttemptedAction],
			ex.[FirstActionStatus], ex.[SecondAttemptedAction], ex.[SecondActionStatus], ex.[Topic], ex.[AttackVectorType],
			ex.[AccessRequested], ex.[DurationBeforeDetection], ex.[NaturalLangDescription], ex.[Direction]
		from [EPOLeafNode_Fast] ln
			inner join [EPOEvents_Fast] e on ln.[TenantId] = e.[TenantId] and ln.[AgentGUID] = e.[AgentGUID]
			inner join [EPExtendedEvent] ex on e.[AutoID] = ex.[EventAutoID]
		where e.[ThreatEventId] in (18051,18052,18053,18054,18055,18056,18057)
go

-- grant permission to the view --
grant select on [dbo].[TP_Events] to [mcafeeOps];
grant select on [dbo].[TP_Events] to [mcafeeTenant];
go
