
-- Update the view to: performance and make it read only
ALTER VIEW [dbo].[SP_EndpointTechnologyStatus_View] AS
    SELECT PP.[AutoIDOAS] [AutoID], PP.[LeafNodeID], 1 [TechnologyType], PP.[bOASEnabled] [Enabled], PP.[ProductCode]
      FROM  [AM_CustomProps] PP WITH(NOLOCK)
    UNION
    SELECT PP.[AutoIDBO] [AutoID], PP.[LeafNodeID], 2 [TechnologyType], PP.[bBOEnabled] [Enabled], PP.[ProductCode]
      FROM  [AM_CustomProps] PP WITH(NOLOCK)
      WHERE [ProductCode] <> N'ENDP_AM_1000MACX'
    UNION
    SELECT PP.[AutoIDAP] [AutoID], PP.[LeafNodeID], 3 [TechnologyType], PP.[bAPEnabled] [Enabled], PP.[ProductCode]
      FROM  [AM_CustomProps] PP WITH(NOLOCK)
      WHERE ProductCode <> N'ENDP_AM_1000MACX'
    UNION
    SELECT PP.[AutoIDSS] [AutoID], PP.[LeafNodeID], 4 [TechnologyType], PP.[bScriptScanEnabled] [Enabled], PP.[ProductCode]
      FROM  [AM_CustomProps] PP WITH(NOLOCK)
      WHERE ProductCode <> N'ENDP_AM_1000MACX'
GO

-- udpate permissions
REVOKE SELECT,INSERT,UPDATE,DELETE,REFERENCES ON [dbo].[SP_EndpointTechnologyStatus_View] TO [mcafeeSystem]
GRANT SELECT ON [dbo].[SP_EndpointTechnologyStatus_View] TO [mcafeeOps]
GRANT SELECT ON [dbo].[SP_EndpointTechnologyStatus_View] TO [mcafeeTenant]
GO

-- Rebuild the tech status view
exec [dbo].[GSRebuildTechnologyStatus_View]
go

-- Drop unused indexes bug 1187187

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_APbComplianceStatus' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_APbComplianceStatus ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_bAPEnabled' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_bAPEnabled ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_bBOEnabled' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_bBOEnabled ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_bOASEnabled' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_bOASEnabled ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_BObComplianceStatus' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_BObComplianceStatus ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_bScriptScanEnabled' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_bScriptScanEnabled ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_ExploitPreventionContentVersion' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_ExploitPreventionContentVersion ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_OASbComplianceStatus' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_OASbComplianceStatus ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_OASGTILevel' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_OASGTILevel ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_ODSbComplianceStatus' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_ODSbComplianceStatus ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_ODSFullScanGTILevel' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_ODSFullScanGTILevel ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_ODSQuickScanGTILevel' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_ODSQuickScanGTILevel ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_ODSRightClickScanGTILevel' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_ODSRightClickScanGTILevel ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_SSbComplianceStatus' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_SSbComplianceStatus ON AM_CustomPropsMT;
GO
