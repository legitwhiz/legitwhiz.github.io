------------------------------------------------------------------
--Copyright (c) 2020 McAfee LLC - All Rights Reserved
------------------------------------------------------------------
IF NOT EXISTS(select [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'AM_CustomPropsMT' and [COLUMN_NAME] = N'TPAMSISupportedStatus')
BEGIN
	ALTER TABLE [AM_CustomPropsMT]
		ADD [TPAMSISupportedStatus] [bit] NULL
END
GO

IF NOT EXISTS(select [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'AM_CustomPropsMT' and [COLUMN_NAME] = N'TPAMSISupportedStatusReason')
BEGIN
	ALTER TABLE [AM_CustomPropsMT]
		ADD [TPAMSISupportedStatusReason] [nvarchar] (256) NULL
END
GO

--NOW REFRESH THE VIEW FOR THE AM_CustomPropsMT Table
EXEC sp_refreshview '[dbo].[AM_CustomProps]';


