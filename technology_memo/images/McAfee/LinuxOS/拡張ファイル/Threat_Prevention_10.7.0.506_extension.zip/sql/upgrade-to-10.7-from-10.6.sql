------------------------------------------------------------------
--Copyright (c) 2020 McAfee LLC - All Rights Reserved
------------------------------------------------------------------
-- insert 10.7.0 product technology data
IF NOT EXISTS(SELECT 1 FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_AM_1070')
BEGIN
    INSERT INTO [dbo].[EAMP.GSE.Blades]([ProductCode], [DispName], [TechnologyCount]) VALUES
        (N'ENDP_AM_1070', N'Endpoint Security Threat Prevention', 4)
END
GO

IF NOT EXISTS(select [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'AM_CustomPropsMT' and [COLUMN_NAME] = N'TPAMSISupportedStatus')
BEGIN
	ALTER TABLE [AM_CustomPropsMT]
		ADD [TPAMSISupportedStatus] [bit] NULL
END
GO

IF NOT EXISTS(select [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'AM_CustomPropsMT' and [COLUMN_NAME] = N'TPAMSISupportedStatusReason')
BEGIN
	ALTER TABLE [AM_CustomPropsMT]
		ADD [TPAMSISupportedStatusReason] [nvarchar] (256) NULL
END
GO

IF NOT EXISTS(select [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'ENSRollup_AM_CustomProps' and [COLUMN_NAME] = N'TPAMSISupportedStatus')
BEGIN
	ALTER TABLE [ENSRollup_AM_CustomProps]
		ADD [TPAMSISupportedStatus] [bit] NULL
END
GO

IF NOT EXISTS(select [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'ENSRollup_AM_CustomProps' and [COLUMN_NAME] = N'TPAMSISupportedStatusReason')
BEGIN
	ALTER TABLE [ENSRollup_AM_CustomProps]
		ADD [TPAMSISupportedStatusReason] [nvarchar] (256) NULL
END
GO

--NOW REFRESH THE VIEW FOR THE AM_CustomPropsMT Table
EXEC sp_refreshview '[dbo].[AM_CustomProps]';
