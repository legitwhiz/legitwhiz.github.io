DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_AM_1060'
GO
