
-- Update the view to: performance and make it read only
ALTER VIEW [dbo].[SP_EndpointTechnologyStatus_View] AS
    SELECT PP.[AutoIDOAS] [AutoID], PP.[LeafNodeID], 1 [TechnologyType], PP.[bOASEnabled] [Enabled], PP.[ProductCode]
      FROM  [AM_CustomProps] PP WITH(NOLOCK)
    UNION
    SELECT PP.[AutoIDBO] [AutoID], PP.[LeafNodeID], 2 [TechnologyType], PP.[bBOEnabled] [Enabled], PP.[ProductCode]
      FROM  [AM_CustomProps] PP WITH(NOLOCK)
      WHERE [ProductCode] <> N'ENDP_AM_1000MACX'
    UNION
    SELECT PP.[AutoIDAP] [AutoID], PP.[LeafNodeID], 3 [TechnologyType], PP.[bAPEnabled] [Enabled], PP.[ProductCode]
      FROM  [AM_CustomProps] PP WITH(NOLOCK)
      WHERE ProductCode <> N'ENDP_AM_1000MACX'
    UNION
    SELECT PP.[AutoIDSS] [AutoID], PP.[LeafNodeID], 4 [TechnologyType], PP.[bScriptScanEnabled] [Enabled], PP.[ProductCode]
      FROM  [AM_CustomProps] PP WITH(NOLOCK)
      WHERE ProductCode <> N'ENDP_AM_1000MACX'
GO

-- Rebuild the tech status view
exec [dbo].[GSRebuildTechnologyStatus_View]
go

-- Drop unused indexes bug 1187187

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_APbComplianceStatus' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_APbComplianceStatus ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_bAPEnabled' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_bAPEnabled ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_bBOEnabled' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_bBOEnabled ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_bOASEnabled' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_bOASEnabled ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_BObComplianceStatus' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_BObComplianceStatus ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_bScriptScanEnabled' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_bScriptScanEnabled ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_ExploitPreventionContentVersion' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_ExploitPreventionContentVersion ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_OASbComplianceStatus' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_OASbComplianceStatus ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_OASGTILevel' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_OASGTILevel ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_ODSbComplianceStatus' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_ODSbComplianceStatus ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_ODSFullScanGTILevel' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_ODSFullScanGTILevel ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_ODSQuickScanGTILevel' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_ODSQuickScanGTILevel ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_ODSRightClickScanGTILevel' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_ODSRightClickScanGTILevel ON AM_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_AM_CustomPropsMT_SSbComplianceStatus' -- Index Name
		AND so.[Name] = N'AM_CustomPropsMT')
	DROP INDEX IX_AM_CustomPropsMT_SSbComplianceStatus ON AM_CustomPropsMT;
GO

--------- ePO Rollup Reporting ---------
-- AM_CustomProps rollup target --
if not exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ENSRollup_AM_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
	create table [dbo].[ENSRollup_AM_CustomProps]
	(
		[RegSvrId]							[int] not null,
		[AutoID]							[int] not null,
		[ParentID]							[int] not null,
		[bOASEnabled]						[bit] null,
		[AutoIDOAS]							[uniqueidentifier] null,
		[bAPEnabled]						[bit] null,
		[AutoIDAP]							[uniqueidentifier] null,
		[bBOEnabled]						[bit] null,
		[AutoIDBO]							[uniqueidentifier] null,
		[bScriptScanEnabled]				[bit] null,
		[AutoIDSS]							[uniqueidentifier] null,

		[AVCMComplianceDays]				[nvarchar](100) null,
		[OASbComplianceStatus]				[bit] null,
		[OASComplianceStatus]				[nvarchar](100) null,
		[OASAdditionalComplianceStatus]		[nvarchar](100) null,
		[OASGTILevel]						[tinyint] null,
		[ODSbComplianceStatus]				[bit] null,
		[ODSComplianceStatus]				[nvarchar](100) null,
		[ODSAdditionalComplianceStatus]		[nvarchar](100) null,
		[ODSLastFullScanDuration]			[int],
		[ODSLastQuickScanDuration]			[int],
		[ODSLastFullScanDate]				[datetime] null,
		[ODSLastQuickScanDate]				[datetime] null,
		[ODSFullScanGTILevel]				[tinyint] null,
		[ODSQuickScanGTILevel]				[tinyint] null,
		[ODSRightClickScanGTILevel]			[tinyint] null,
		[AVCMGRbComplianceStatus]			[bit] null,
		[AVCMGRComplianceStatus]			[nvarchar](100) null,
		[AVCMGRAdditionalComplianceStatus]	[nvarchar](100) null,
		[BObComplianceStatus]				[bit] null,
		[BOComplianceStatus]				[nvarchar](100) null,
		[BOAdditionalComplianceStatus]		[nvarchar](100) null,
		[SSbComplianceStatus]				[bit] null,
		[SSComplianceStatus]				[nvarchar](100) null,
		[SSAdditionalComplianceStatus]		[nvarchar](100) null,
		[APbComplianceStatus]				[bit] null,
		[APComplianceStatus]				[nvarchar](100) null,
		[APAdditionalComplianceStatus]		[nvarchar](100) null,
		[V2DATVersion]						[nvarchar](20) null,
		[ManifestVersion]					[nvarchar](20) null,
		[EngineVersion]						[nvarchar](20) null,
		[Hotfixes]							[nvarchar](256) null,
		[Patch]								[nvarchar](3000) null,
		[LicenseStatus]						[nvarchar](256) null,
		[Language]							[nvarchar](256) null,
		[szExtraDATNames]					[nvarchar](3000) null,
		[AMCoreContentDate]					[datetime] null,
		[ExploitPreventionContentCreated]	[datetime] null,
		[ExploitPreventionContentVersion]	[nvarchar](128) null,
		constraint [PK_ENSRollup_AM_CustomProps] primary key clustered
		([RegSvrId] asc, [AutoID] asc)
	)
end
go

if not exists (select 1 from [sys].[foreign_keys] where [object_id] = OBJECT_ID(N'[FK_ENSRollup_AM_CustomProps_EPORollup_ProductProperties]') and [parent_object_id] = OBJECT_ID(N'[dbo].[ENSRollup_AM_CustomProps]'))
begin
	alter table [dbo].[ENSRollup_AM_CustomProps] add
	constraint [FK_ENSRollup_AM_CustomProps_EPORollup_ProductProperties] foreign key
		([RegSvrId], [ParentID])
		references [dbo].[EPORollup_ProductProperties]
		([ServerId], [ExternalId])
		on delete cascade on update no action
end
go

--create unique index on the foreign key
if exists(select 1 from [dbo].[sysobjects] where [id] = OBJECT_ID(N'[dbo].[ENSRollup_AM_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
	and not exists(select 1 from [dbo].[sysindexes] where [id] = OBJECT_ID(N'[dbo].[ENSRollup_AM_CustomProps]') and [name] = N'IX_ENSRollup_AM_CustomProps_ParentID')
begin
	create unique nonclustered index [IX_ENSRollup_AM_CustomProps_ParentID] on [dbo].[ENSRollup_AM_CustomProps]
		([RegSvrId] asc, [ParentID] asc)
end
go
