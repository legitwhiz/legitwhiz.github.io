-- Adding 10.6.6 Linux Product id
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_AM_1066LYNX'
if not exists(select [ProductCode] from [EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_AM_1066LYNX')
begin
	INSERT INTO [dbo].[EAMP.GSE.Blades]
	  ([ProductCode],
	  [DispName],
	  [TechnologyCount])
	  VALUES (
	  N'ENDP_AM_1066LYNX',
	  N'Endpoint Security Threat Prevention',
	  1
	)
end
GO
