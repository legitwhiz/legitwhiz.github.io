
-- grant access rights to the AM_CustomProps VIEW
grant select,insert,update,delete on [dbo].[AM_CustomProps] TO [mcafeeOps]
grant select,insert,update,delete on [dbo].[AM_CustomProps] TO [mcafeeTenant]
GO
