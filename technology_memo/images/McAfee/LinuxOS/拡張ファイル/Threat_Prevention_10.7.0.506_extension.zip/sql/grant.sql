------------------------------------------------------------------
--Copyright (c) 2015 McAfee Inc. - All Rights Reserved
------------------------------------------------------------------
--FOR MULTI-TENANT ONLY

--AM_CustomProps VIEW
grant select,insert,update,delete on [dbo].[AM_CustomProps] TO [mcafeeOps]
grant select,insert,update,delete on [dbo].[AM_CustomProps] TO [mcafeeTenant]
--AM_CustomPropsMT TABLE
GRANT SELECT, INSERT, UPDATE, DELETE ON AM_CustomPropsMT To mcafeeSystem

--SP_EndpointTechnologyStatus VIEW
GRANT SELECT ON [dbo].[SP_EndpointTechnologyStatus_View] To [mcafeeOps]
GRANT SELECT ON [dbo].[SP_EndpointTechnologyStatus_View] To [mcafeeTenant]

--AMBladeTechView VIEW
GRANT SELECT ON [dbo].[AMBladeTechView] To [mcafeeOps]
GRANT SELECT ON [dbo].[AMBladeTechView] To [mcafeeTenant]

--TP_Events VIEW
GRANT SELECT ON TP_Events To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON TP_Events To mcafeeSystem
GRANT SELECT, INSERT, UPDATE, DELETE ON TP_Events To mcafeeOps


GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureTextXlate To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureTextXlate To mcafeeOps
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureTextXlate To mcafeeSystem

GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_Signature To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_Signature To mcafeeSystem
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_Signature To mcafeeOps

GRANT SELECT  ON IPS_SignatureTextXlateMT To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureTextXlateMT To mcafeeOps
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureTextXlateMT To mcafeeSystem

GRANT SELECT ON IPS_SignatureMT To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureMT To mcafeeSystem
GRANT SELECT, INSERT, UPDATE, DELETE ON IPS_SignatureMT To mcafeeOps

GRANT EXECUTE ON [dbo].[IPS_GET_SignatureLocalized] TO mcafeeSystem
GRANT EXECUTE ON [dbo].[IPS_GET_SignatureLocalized] TO mcafeeOps
GRANT EXECUTE ON [dbo].[IPS_GET_SignatureLocalized] TO mcafeeTenant

GRANT EXECUTE ON [dbo].[IPS_SET_SignatureTextXlate] TO mcafeeSystem
GRANT EXECUTE ON [dbo].[IPS_SET_SignatureTextXlate] TO mcafeeOps
--GRANT EXECUTE ON [dbo].[IPS_SET_SignatureTextXlate] TO mcafeeTenant

GRANT EXECUTE ON [dbo].[IPS_SET_Signature] TO mcafeeSystem
GRANT EXECUTE ON [dbo].[IPS_SET_Signature] TO mcafeeOps
--GRANT EXECUTE ON [dbo].[IPS_SET_Signature] TO mcafeeTenant

GO