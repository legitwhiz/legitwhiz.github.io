------------------------------------------------------------------
--Copyright (c) 2016 McAfee Inc. - All Rights Reserved
------------------------------------------------------------------

-----------------------------------------Start Ips_Signature and IPS_SignatureTextXlate for buffer overflow signatures-------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SET_Signature]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[IPS_SET_Signature]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SET_SignatureTextXlate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[IPS_SET_SignatureTextXlate]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_GET_SignatureLocalized]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[IPS_GET_SignatureLocalized]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureTextXlate]') AND type in (N'U'))
DROP TABLE [dbo].[IPS_SignatureTextXlate]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_Signature]') AND type in (N'U'))
DROP TABLE [dbo].[IPS_Signature]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureTextXlate]') and OBJECTPROPERTY(OBJECT_ID, N'IsView') = 1)
DROP VIEW [dbo].[IPS_SignatureTextXlate]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_Signature]')  and OBJECTPROPERTY(OBJECT_ID, N'IsView') = 1)
DROP VIEW [dbo].[IPS_Signature]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureTextXlateMT]') AND type in (N'U'))
DROP TABLE [dbo].[IPS_SignatureTextXlateMT]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPS_SignatureMT]') AND type in (N'U'))
DROP TABLE [dbo].[IPS_SignatureMT]
GO

-----------------------------------------END Ips_Signature and IPS_SignatureTextXlate for buffer overflow signatures-------------------------------------

if exists(select [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'AM_CustomPropsMT' and [COLUMN_NAME] = N'AMCoreContentDate')
begin
	alter table [AM_CustomPropsMT]
		drop COLUMN AMCoreContentDate
end
GO

DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_AM_1050'
go