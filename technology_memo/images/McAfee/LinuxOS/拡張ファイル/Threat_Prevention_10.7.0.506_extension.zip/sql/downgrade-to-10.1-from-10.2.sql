------------------------------------------------------------------
--Copyright (c) 2016 McAfee Inc. - All Rights Reserved
------------------------------------------------------------------

DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_AM_1020'
go