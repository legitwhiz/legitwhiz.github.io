//Copyright (C) 2017 McAfee, Inc.  All rights reserved.

var GE = window.GE || new GEUtil();

// ****************************************************************************
// Global Exclusion
// ****************************************************************************
function GEUtil()
{
    var dialog = null;
    var listWidget = null;
    var dlg = new GEDlg(this);

    this.DLG = dlg;

    this.initialize = function(geJson)
    {
        dialog = new VSE.DialogBox();
        dialog.setDialogDiv($('divID_GlobalExclusionDialog'));
        this.dialog = dialog;

        listWidget = new VSE.ListWidget2({
            thisObject: listWidget,
            objectName: 'GE.listWidget',
            container: 'divID_SPGlobalExclusionsList',
            headerContent: $('globalexclusions_list_header').innerHTML,
            content: $('globalexclusions_listitem_template').innerHTML,
            readonly: 'false',
            includeCheckbox: 'false',
            width: '100%',
            height: '175px',
            addCallback: GE.onAddItem,
            selectedRowUpdateCallback: GE.onSelectedRowUpdate,
            removeCallback: GE.onRemoveItem,
            clearCallback: GE.onClear
        });
        this.listWidget = listWidget;

        //populate the GE widget
        var geItems = (geJson ? JSON.parse(geJson) : []);
        this.populateList(geItems);
    };

    this.getData = function()
    {
        var arData = [], items = listWidget.getItemList();
        for(var i = 0; i < items.length; ++i)
        {
            arData.push(items[i].itemData);
        }
        return JSON.stringify(arData);
    };

    this.populateList = function(arItems)
    {
        if(listWidget)
        {
            var item;
            for(var i = 0; i < arItems.length; ++i)
            {
                item = new VSE.ListItem2();
                item.itemData = arItems[i];
                listWidget.add(item);
            }
        }
    };

    // ************************************************************************
    // Global Exclusion - ListWidget2 Callbacks
    // ************************************************************************

    this.onAddItem = function(newRow)
    {
        var id = newRow.id.replace('divID_SPGlobalExclusionsList_lwrow_', '');
        var excl = getItem(newRow.id);
        uiUpdateItem(id, excl);
        updateFormState();
    };

    this.onSelectedRowUpdate = function(selectedRow)
    {
        var id = selectedRow.id.replace('divID_SPGlobalExclusionsList_lwrow_', '');
        var excl = getItem(selectedRow.id);
        uiUpdateItem(id, excl);
        updateFormState();
    };

    this.onRemoveItem = function()
    {
        updateFormState();
    };

    this.onClear = function()
    {
        updateFormState();
    };

    function getItem(rowId)
    {
        var item = listWidget.getItem(rowId);
        var value = item ? item.itemData : '';
        return value.split('|');
    }

    function uiUpdateItem(id, excl)
    {
        $('ap_globalexclusion_filename_' + id).innerText = (excl[0] ? excl[0] : '');
        $('ap_globalexclusion_md5_' + id).innerText = (excl[1] ? excl[1] : '');
        $('ap_globalexclusion_signer_' + id).innerText = (excl[2] ? excl[2] : '');
        $('ap_globalexclusion_description_' + id).innerText = (excl[3] ? excl.slice(3).join('|') : '');
    }

    function updateFormState()
    {
        onFormStateChange(true, OrionForm.isFormValid());
    }

    // ************************************************************************
    // Global Exclusion - UI Handlers
    // ************************************************************************

    this.addItem_onclick = function()
    {
        dlg.clear();
        dlg.newItem = true;

        dialog.showDialog(true);
    };

    this.editItem_onclick = function()
    {
        var selected = listWidget.getSelected();
        var excl = selected ? selected.itemData.split('|') : null;
        if(excl && (excl.length > 3))
        {
            dlg.init(excl[0], excl[1], excl[2], excl[3] ? excl.slice(3).join('|') : '');
            dlg.newItem = false;
            dialog.showDialog(true);
        }
    };

    this.removeItem_onclick = function()
    {
        listWidget.removeSelected();
    };

    this.clearItems_onclick = function()
    {
        listWidget.clearList();
    };

    // ************************************************************************
    // Global Exclusion - Dialog Handlers
    // ************************************************************************
    function GEDlg(geUtil)
    {
        var parent = geUtil;
        var me = this;

        this.clear = function()
        {
            $('textID_globalexclusion_process').value = '';
            $('textID_globalexclusion_hash').value = '';
            $('textID_globalexclusion_signerHash').value = '';
            $('textID_globalexclusion_notes').value = '';
            me.validateItem();
        };

        this.init = function(app, hash, signerHash, notes)
        {
            $('textID_globalexclusion_process').value = app ? app : '';
            $('textID_globalexclusion_hash').value = hash ? hash :'';
            $('textID_globalexclusion_signerHash').value = signerHash ? signerHash : '';
            $('textID_globalexclusion_notes').value = notes ? notes : '';
            return me.validateItem();
        };

        this.onCancel = function()
        {
            parent.dialog.showDialog(false);
        };

        this.onOK = function()
        {
            parent.dialog.showDialog(false);

            var szItem = $('textID_globalexclusion_process').value + '|' + $('textID_globalexclusion_hash').value + '|' +
                $('textID_globalexclusion_signerHash').value + '|' + $('textID_globalexclusion_notes').value;
            if (me.newItem === true)
            {
                var item = new VSE.ListItem2();
                item.itemData = szItem;
                parent.listWidget.add(item);
            }
            else
            {
                parent.listWidget.getSelected().itemData = szItem;
                parent.listWidget.selectedRowUpdate();
            }
        };

        this.enableOK = function(valid)
        {
            var btnOk = $('buttonID_GlobalExclusionOK');
            btnOk.disabled = !valid;
            btnOk.className = (valid ? 'orionButtonEnabled' : 'orionButtonDisabled');
        };

        var processRegex = null;
        this.isValidProcess = function(item)
        {
            if (processRegex === null)
            {
                processRegex = new RegExp('^(?:[a-zA-Z]:|\\\\\\\\[^\\\\/:*?"<>|]+|%.+?%[^\\\\/:*?"<>|]*)(?:\\\\(?=([^\\\\/:*?"<>|]+))\\1)+$');
            }
            return processRegex.test(item);
        };

        var md5Regex = null;
        this.isValidMD5 = function(item)
        {
            if (md5Regex == null)
            {
                md5Regex = new RegExp('^[a-fA-F0-9]{32}$');
            }
            return md5Regex.test(item);
        };

        this.validateProcess = function()
        {
            var item = $('textID_globalexclusion_process').value;
            var oRes = {empty: (item === ''), valid: me.isValidProcess(item)};

            $('globalexclusions_process_empty').style.display = (oRes.empty ? '' : 'none');
            $('globalexclusions_process_error').style.display = ((oRes.empty || oRes.valid) ? 'none' : '');
            return oRes;
        };

        this.validateHash = function()
        {
            return hashValidation($('textID_globalexclusion_hash'), $('globalexclusions_hash_error'));
        };

        this.validateSignerHash = function()
        {
            return hashValidation($('textID_globalexclusion_signerHash'), $('globalexclusions_signerHash_error'));
        };

        this.validateItem = function()
        {
            var process = me.validateProcess();
            var hash = me.validateHash();
            var signer = me.validateSignerHash();
            var valid = (process.valid && ((hash.valid && (signer.valid || signer.empty)) ||
                    (signer.valid && (hash.valid || hash.empty))));

            $('globalexclusions_hashes_required').style.display = ((hash.empty && signer.empty) ? '' : 'none');
            me.enableOK(valid);
            return valid;
        };

        function hashValidation(elemHash, elemErr)
        {
            var hash = elemHash.value, oRes = {empty: (hash === ''), valid: me.isValidMD5(hash)};
            elemErr.style.display = ((oRes.empty || oRes.valid) ? 'none' : '');
            return oRes;
        }
    } //GEDlg
} //GEUtil
