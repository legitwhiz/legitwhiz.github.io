//Copyright (C) 2015 McAfee, Inc.  All rights reserved.
//
// This file is shared by all ENS extensions.  To use this file,
// your jsp page must use the same control Ids and class names used in this file.

// Show / hide controls when platform checkboxes are clicked
function platformsChanged(bWinLicensed, bMacLicensed, bLynxLicensed)
{
    //show \ hide windows only controls
    ((bLynxLicensed || bMacLicensed) && !bWinLicensed) ? $j(".ensWindowsOnlySection").hide() : $j(".ensWindowsOnlySection").show();
    //show \ hide windows only indicators
    //((bLynxLicensed || bMacLicensed) && bWinLicensed) ? $j(".ensWindowsOnlyText").show() : $j(".ensWindowsOnlyText").hide();	
	if((bLynxLicensed || bMacLicensed) && bWinLicensed)
	{
		$j(".ensWindowsOnlyText").show();
		$j(".ensWindows_MacOnlyText").show();
		$j(".ensWindows_LinuxOnlyText").show();
	}
	else
	{
		$j(".ensWindowsOnlyText").hide();
		$j(".ensWindows_MacOnlyText").hide();
		$j(".ensWindows_LinuxOnlyText").hide();
		
	}
}
