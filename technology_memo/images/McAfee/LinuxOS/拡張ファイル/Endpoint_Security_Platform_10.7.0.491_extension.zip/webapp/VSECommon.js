var VSE = window.VSE || {};
var g_Disabled = false;

// Used for macro validation, these strings should NOT be localized!
var g_szValidMacros = new Array();
g_szValidMacros[0]	= "SYSTEM_DRIVE";
g_szValidMacros[1]	= "SYSTEM_ROOT";
g_szValidMacros[2]	= "SYSTEM_DIR";
g_szValidMacros[3]	= "TEMP_DIR";
g_szValidMacros[4]	= "PROGRAM_FILES_DIR";
g_szValidMacros[5]	= "PROGRAM_FILES_COMMON_DIR";
g_szValidMacros[6]	= "SOFTWARE_INSTALLED_DIR";

/**
 * The opening "class" for the AddWidget (+/-) row adder
 * @param {obj} obj	An object holding the default parameters (container/content)
 * @return {obj} THe instance of the Widget
 */
VSE.AddWidget = function(obj){
	this.cntrid = obj["container"];
	this.cntr = document.getElementById(obj["container"]);
	this.id = 0;
	this.list = {};
    this.addCallback = null;
    this.removeCallback = null;
    this.readOnly=false;
    this.icons = {
		"plus":"<img src='/core/images/button/add-button.gif' border='0' width='27' height='19' align='absmiddle'>",
		"minus":"<img src='/core/images/button/delete-button.gif' border='0' width='27' height='19' align='absmiddle'>"
	};
	this.content = "";
	if(obj["content"] != null){
	    this.content = obj["content"];
	}else{
	    this.content = "<INPUT TYPE='text' size='15' value='@VALUE'>";
	}
    if(obj["addCallback"] != null)
    {
        this.addCallback = obj["addCallback"];
    }

    if(obj["removeCallback"] != null)
    {
        this.removeCallback = obj["removeCallback"];
    }
    if(obj["readOnly"] != null)
    {
        this.readOnly = obj["readOnly"];
    }
}
/**
 * The AddWidget method for adding new rows
 * @param {obj} inval   An object holding any replacements for placeholders in the HTML content
 * @return void
 */
VSE.AddWidget.prototype.add = function(inval){

    if(g_Disabled)
    {
        return;
    }

	this.id++;
	var newbox = document.createElement('div');
	newbox.setAttribute("id",this.cntrid+"_awrow_"+this.id);
	newbox.setAttribute("style","margin-bottom: 3px;");

    var contentSpan = document.createElement('span');
    contentSpan.setAttribute("id",this.cntrid+"_awrow_"+this.id+"_content");

    var buttonSpan = document.createElement('span');
    buttonSpan.setAttribute("id",this.cntrid+"_awrow_"+this.id+"_buttons");

    newbox.appendChild(contentSpan);
    newbox.appendChild(buttonSpan);

    if(inval == null){
	    inval = {"@VALUE":""};
	}

    // Store the @VALUE from the passed in object
    var hiddenValue = document.createElement('input');
    hiddenValue.setAttribute("id",this.cntrid+"_hiddenvalue_"+this.id);
    hiddenValue.setAttribute("value", inval["@VALUE"]);
    hiddenValue.setAttribute("type", "hidden");
    newbox.appendChild(hiddenValue);
    
    // add or update our default @ID attribute
    inval["@ID"]=this.id;

    var field = this.content;
	for(var i in inval){
        // let's replace all instances.  Don't want to worry about regex quoting, this is easy:
        while(field.indexOf(i)!=-1)
        {
            field = field.replace(i,OrionCore.escapeHtml(inval[i]));
        }
    }

    contentSpan.innerHTML = field;

    this.cntr.appendChild(newbox);
	this.list[this.cntrid+"_awrow_"+this.id] = true;

    this.toggle();

    // call the add callback if one is set
    if(this.addCallback != null)
    {
        this.addCallback(newbox);
    }
}
/**
 * The AddWidget method for placing the plus and minus buttons on the screen.
 */
VSE.AddWidget.prototype.toggle = function(){
    // Due to scope loss in the add/remove, the buttons are redrawn on every click.

    // Add Minuses
    var instn = this;
    var psave = 0;

    // clear out buttons
    for (var i in this.list) {
        var span = document.getElementById(i + "_buttons");
        if (span != null) {
            span.innerHTML = "";
        }
    }

    // don't add any buttons if the adder is read-only
    if (!this.readOnly)
    {
        // Ugly roll to accomodate the Mercury style of having no minus on the first row.
        var trues = 0;
        for (var i in this.list) {
            if (this.list[i]) {
                trues++;
            }
        }

        for (var i in this.list) {
            if (this.list[i]) {
                if (trues > 1) { // ugly from above
                    var div = document.getElementById(i);
                    var span = document.getElementById(i + "_buttons");

                    if (span != null)
                    {
                        var space = document.createElement('SPAN');
                        space.innerHTML = "&nbsp;";
                        span.appendChild(space);

                        var minus = document.createElement('a');
                        minus.setAttribute("href", "javascript:;");
                        minus.onclick = function(evt)
                        {
                            evt = evt || event;
                            if (! evt.target) {
                                evt.target = evt.srcElement;
                            }
                            instn.remove(evt.target);
                        }

                        minus.innerHTML = this.icons["minus"];

                        span.appendChild(minus);
                    }
                }
                psave = i;
            }
        }

        // Add plus to last element
        var psave = document.getElementById(psave + "_buttons");
        var space = document.createElement('SPAN');
        space.innerHTML = "&nbsp;";
        psave.appendChild(space);

        var adder = document.createElement('a');
        adder.setAttribute("href", "javascript:;");
        adder.onclick = function()
        {
            instn.add();
        }
        adder.innerHTML = this.icons["plus"];
        psave.appendChild(adder);
        if (psave.style.display == "block") {
            psave.childNodes[0].focus();
        }
    }
}
/**
 * The AddWidget method for removing rows
 * @param {obj} me   The row to remove
 * @return void
 */
VSE.AddWidget.prototype.remove = function(me){

    if(g_Disabled)
    {
        return;
    }

    var mom = me.parentNode.parentNode.parentNode;
 	if(this.cntr.childNodes.length > 1){
 	    this.list[mom.getAttribute("id")] = false;
		mom.parentNode.removeChild(mom);
	}else{
	    mom.childNodes[0].value = "";
	}
	this.toggle();

    if(this.removeCallback != null)
    {
        this.removeCallback();
    }
}
/**
 * The AddWidget method for retreiving active rows
 * @return {array} A collection list of DIV tags objects with content in them.
 */
VSE.AddWidget.prototype.getList = function(){
	var its = new Array();
	for(i in this.list){
		if(this.list[i]){
		    its.push(i);
        }
	}
	return its;
}

VSE.AddWidget.prototype.getRows = function(){
	var its = {};
	for(i in this.list){
		if(this.list[i]){
			var cut = i.split("_");
		    its[cut[2]] = document.getElementById(i);
        }
	}
	return its;
}

/****************************************************************************/
/* List Item for use with the List Widget                                   */
/****************************************************************************/
VSE.ListItem2 = function()
{
    this.itemData = null;
};

VSE.ListItem2.prototype =
{
    setDisplayText : function(text)
    {
        this.displayText = text;
    },
    setItemData : function(data)
    {
        this.itemData = data;        
    },
    setItemChecked : function(checked)
    {
        this.itemChecked = checked;
    }
};

/****************************************************************************/
/* VSE.ListWidget2                                                           */
/*                                                                          */
/* Displays a list of VSE.ListItem2 objects and allows the inclusion of a    */
/* checkbox for the item.                                                   */
/****************************************************************************/
VSE.ListWidget2 = function(obj)
{
	this.cntrid = null;
	this.cntr = null;
	this.id = -1;
    this.list = {};                         // an array of VSE.ListItem2 objects
    this.addCallback = null;
    this.removeCallback = null;
    this.clearCallback = null;
    this.selectedRowUpdateCallback = null;
    this.onchangeSelectionCallback = null;
    this.checkboxCallback = null;
    this.readOnly=false;
    this.width = '600px';
    this.height = '150px';
    this.listTable = null;
    this.checkboxCount = 0;
    this.objectName = obj["objectName"];
    this.content="";
    this.thisObject = obj["thisObject"];
    this.macLicensed = obj['macLicensed'];
    this.linuxLicensed = obj['linuxLicensed'];

    if(obj["container"] != null)
    {
        this.cntrid = obj["container"];
        this.cntr = document.getElementById(obj["container"]);
    }

    if(obj["headerContent"] != null)
    {
        this.headerContent = obj["headerContent"];
    }

    if(obj["content"] != null)
    {
        this.content = obj["content"];
    }

    if(obj["addCallback"] != null)
    {
        this.addCallback = obj["addCallback"];
    }

    if(obj["removeCallback"] != null)
    {
        this.removeCallback = obj["removeCallback"];
    }

    if(obj["clearCallback"] != null)
    {
        this.clearCallback = obj["clearCallback"];
    }
    if(obj["selectedRowUpdateCallback"] != null)
    {
        this.selectedRowUpdateCallback = obj["selectedRowUpdateCallback"];
    }

    if(obj["onchangeSelectionCallback"] != null)
    {
        this.onchangeSelectionCallback = obj["onchangeSelectionCallback"];
    }

    if(obj["checkboxCallback"] != null)
    {
        this.checkboxCallback = obj["checkboxCallback"];
    }

    if(obj["readOnly"] != null)
    {
        this.readOnly = obj["readOnly"];
    }

    if(obj["width"] != null)
    {
        this.width = obj["width"];
    }

    if(obj["height"] != null)
    {
        this.height = obj["height"];
    }

    if(obj["checkboxCount"] != null)
    {
        this.checkboxCount = obj["checkboxCount"];
    }

    if(obj["data"] != null)
    {
        this.data = obj["data"];
    }

    // create the table to contain the list
    if(this.cntr != null)
    {
        var listDiv = document.createElement('div');
        listDiv.style.overflow = "auto";
        listDiv.style.width = "" + this.width;
        var browserVersion = getBrowserVersion();

        if(browserVersion > 0 && browserVersion < 7)
        {
            listDiv.style.height = "" + this.height;
        }
        else
        {
            listDiv.style.minHeight = "" + this.height;
            listDiv.style.maxHeight = "1px";
        }
        listDiv.style.borderStyle = "solid";
        listDiv.style.borderWidth = "thin";
        listDiv.style.padding = "0px";
        listDiv.style.margin = "0px";
        
        this.listTable = document.createElement('table');
	    this.listTable.id = this.cntrid+"_listContainer";
	    this.listTable.width = this.width;
        this.listTable.cellPadding = 0;
        this.listTable.cellSpacing = 0;
        this.listTable.border = 0;
        this.listTable.style.tableLayout = 'fixed';
        this.selectedRow = "undefined";

        if(this.headerContent)
        {
            this.listTable.innerHTML = this.headerContent;
        }

        if(!this.listTable.tBodies || !this.listTable.tBodies[0])
        {
            this.listTable.appendChild(document.createElement('tbody'));
        }

        listDiv.appendChild(this.listTable);
        this.cntr.appendChild(listDiv);
    }
};

VSE.ListWidget2.prototype.add = function(listItem)
{
	if(listItem == null)
    {
        return;
    }
    this.id++;

    // Create a new row in the table
    var newRow = this.listTable.tBodies[0].insertRow();
    newRow.id = this.cntrid + "_lwrow_" + this.id;
    newRow.style.cursor = "pointer";

    // this is the text for the function call to be used for onclick events to handle the selection
    // and unselection of the table rows.
    var selectRowFunctionCall = this.objectName + ".SelectRow('" + newRow.id + "');";
    newRow.onmouseup = function() {rowClickListener(this.id);};
    
    // add or update our default @ID attribute
    var field = this.content;
    while(field.indexOf("@ID") != -1)
    {
        field = field.replace("@ID", this.id);
    }
    newRow.innerHTML = field;

    // add a hidden href to table row
    // This href contains the code that will be called to select the row
    var contentHref = document.createElement('a');
    contentHref.href = "JavaScript:" + selectRowFunctionCall;
    contentHref.style.textDecoration = "none";
    contentHref.style.display = "none";
    contentHref.id = newRow.id + "_SelectRow";
    if(listItem.displayText)
    {
        contentHref.innerHTML = listItem.displayText;
    }
    newRow.appendChild(contentHref);

    this.list[newRow.id] = listItem;
    //this.SelectRow(newRow.id);
    //this.cntr.scrollTop = this.cntr.scrollHeight - this.cntr.clientHeight;

    // call the add callback if one is set
    if(this.addCallback != null)
    {
        this.addCallback(newRow);
    }
};

VSE.ListWidget2.prototype.getItemList = function()
{
    var items = new Array();
    for(i in this.list)
    {
        if(this.list[i])
        {
            items.push(this.list[i]);
        }
    }

    return items;
};

VSE.ListWidget2.prototype.selectedRowUpdate = function()
{
    if(this.selectedRow != "undefined" && this.selectedRowUpdateCallback != null)
    {
        var selectedRowElement = $(this.selectedRow);
        if(selectedRowElement != null)
    {
            this.selectedRowUpdateCallback(selectedRowElement);
    }
}
};

VSE.ListWidget2.prototype.removeSelected = function()
{
    if(this.selectedRow != "undefined")
    {
        var rows = this.listTable.tBodies[0].rows;
        for(var i=0; i < rows.length; ++i)
        {
            if(rows[i].id == this.selectedRow)
            {
                this.list[this.selectedRow] = null;
                this.unhighlightRow(this.selectedRow);
                this.listTable.tBodies[0].deleteRow(i);
                if (rows.length > 0)
                {
                    this.highlightRow(rows[Math.min(i, rows.length - 1)].id);
                    this.selectedRow = rows[Math.min(i, rows.length - 1)].id;
                }
                else
                {
                    this.selectedRow = "undefined";
                }
                if(this.removeCallback != null)
                {
                    this.removeCallback();
                }
                break;
            }
        }
    }
};

VSE.ListWidget2.prototype.SelectRow = function(rowID)
{
    var previousRow = "";
    if(this.selectedRow != "undefined")
    {
        previousRow = this.selectedRow;
        this.unhighlightRow(this.selectedRow);
    }

    this.highlightRow(rowID);
    this.selectedRow = rowID;

    // the selection change callback should only be called when the selection
    // actually changes.
    if(this.onchangeSelectionCallback != null && previousRow != this.selectedRow)
    {
        this.onchangeSelectionCallback(this.list[this.selectedRow]);
}
};

VSE.ListWidget2.prototype.highlightRow = function(rowID)
{
    var targetRow = $(rowID);
    if(targetRow)
    {
        targetRow.bgColor = "lightsteelblue";
    }
};

VSE.ListWidget2.prototype.unhighlightRow = function(rowID)
{
    var targetRow = $(rowID);
    if(targetRow)
    {
        targetRow.bgColor = "white";
    }
};

VSE.ListWidget2.prototype.getSelected = function()
{
    if(this.selectedRow == "undefined")
    {
        return null;
    }
    else
    {
        return this.list[this.selectedRow];
    }
};

VSE.ListWidget2.prototype.getItem = function(rowID)
{
    return this.list[rowID];
};

VSE.ListWidget2.prototype.clearList = function()
{
    var nRows = this.listTable.tBodies[0].rows.length - 1;
    for(var i = nRows; i > -1; --i)
    {
        this.listTable.tBodies[0].deleteRow(i);
    }
    this.list = {};
    this.id = -1;
    this.selectedRow = "undefined";

    // call the clear callback if one is set
    if((this.clearCallback != null) && (nRows > 0))
    {
        this.clearCallback();
    }
};

function rowClickListener(rowID)
{
    var hiddenHref = $(rowID + "_SelectRow");
    if(hiddenHref != null)
    {
        document.location.href = hiddenHref.href;
    }
}

// *******************************************************************

function numbers_only(e)
{
    var k;
    k=document.all?parseInt(e.keyCode): parseInt(e.which);

    // allow numbers and backspaces only
    return ((k>45 && k<57) || k==8);
}

// *******************************************************************
// validateWidget - Prevents duplicate entries from being entered in the plus/minus control widget
//
// Input: szNewExclusion    - the current value being entered
//        listWidget        - the name of the plus/minus widget
//        listDelimeter     - the internal delimiter for the list
//        delimeter         - The other delimeter
//
// Returns: Boolean. Returns true if a duplicate entry was NOT found. If this returns false, don't set the local functions g_bFormDirty to true
//
// Example: validateWidget(szNewExclusion, g_UPExclusionsAddWidget, "upexclusionslist_awrow_", "up_exclusion_");
//
// *******************************************************************
function validateWidget(szNewExclusion, listWidget, listDelimeter, delimeter)
{
    var UPExclusionsList = listWidget.getList();
    var exclusions = "";
    var founditem = 0;

    for(var i=0; i < UPExclusionsList.length; ++i)//-1
    {
        var currentItemID = UPExclusionsList[i].replace(listDelimeter, "");
        var currentExclusion = $(delimeter+currentItemID);

        if((OrionCore.trim(currentExclusion.value) == OrionCore.trim(szNewExclusion)) && (OrionCore.trim(szNewExclusion) != ""))
        {
            //we look for 2 or more occurances of the item as itself already always exists in the list
            founditem += 1;
            if (founditem >=2)
            {
                return false;
            }
        }
    }
    return true;
}


function IsValidPath(szPath)
{
    var r;

    r = szPath.indexOf("/");

    if(r == -1)
        r = szPath.indexOf("\*");

    if(r == -1)
        r = szPath.indexOf("?");

    if(r == -1)
        r = szPath.indexOf("\"");

    if(r == -1)
        r = szPath.indexOf("|");

    if(r == -1)
        r = szPath.indexOf("<");

    if(r == -1)
        r = szPath.indexOf(">");

    if(r == -1)
        return true;

    return false;
}

function IsValidPath(szPath, wildcardsAllowed)
{
    var isValid = false;

    isValid = IsValidDriveLetterPath(szPath, wildcardsAllowed);

    // not a valid drive letter path, so check if it's a UNC path
    if(!isValid)
    {
        isValid = IsValidUNCPath(szPath, wildcardsAllowed);
    }

    // still not valid so see if it is a wildcard path **\blah
    if(!isValid && wildcardsAllowed)
    {
        isValid = IsValidWildcardPath(szPath);
    }

    return isValid;
}

function IsValidDriveLetterPath(szPath, wildcardsAllowed)
{
    var isValid = false;

    // Check drive path first
    var validDrivePathRegEx;
    if(wildcardsAllowed)
    {
        // RegEx = drive letter or ? followed by : and \ as long as \ is not followed by another \, then zero or more
        // of any character not in the list (\,/,:,",<,>,|) followed by 0 or 1 \.
        // This is done for compatibility with previous regex implementation where isValidDriveLetterPath matched all valid paths
        // This expression is optimized to avoid performance issues from BZ 1204964
       validDrivePathRegEx = new RegExp(/^(((([a-zA-Z*?]:(\\(?!\\))))(([^\\\/"<>|]+(\\(?!\\)))|([^\\\/"<>|]))*))$/);
    }
    else
    {
        // RegEx = drive letter followed by : and \ as long as \ is not followed by another \, then zero or more
        // of any character not in the list (\,/,:,",<,>,|,*,?) followed by 0 or 1 \.
        validDrivePathRegEx = new RegExp(/^(([a-zA-Z]:)(\\(?!\\))+([^\\/"<>|*?]*(\\(?!\\))*)*)$/);
    }
    isValid = validDrivePathRegEx.test(szPath);

    return isValid;
}

function IsValidUNCPath(szPath, wildcardsAllowed)
{
    var isValid = false;

    var validUNCPathRegEx;
    if(wildcardsAllowed)
    {
        validUNCPathRegEx = new RegExp(/^((\\\\[^\\/:"<>|]+)\\(?!\\)([^\\/"<>|]*(\\(?!\\))*)*)$/);
    }
    else
    {
        validUNCPathRegEx = new RegExp(/^((\\\\[^\\/:"<>|*?]+)\\(?!\\)([^\\/"<>|*?]*(\\(?!\\))*)*)$/);
    }
    isValid = validUNCPathRegEx.test(szPath);

    return isValid;
}

function IsValidWildcardPath(szPath)
{
    var isValid = false;

    var validWildcardPathRegEx = new RegExp(/^\*\*\\((?:[^\\/"<>|])+(?:\\(?!\\))*)+$/);
    isValid = validWildcardPathRegEx.test(szPath);

    return isValid;
}

function IsValidFilename(szPath, wildcardsAllowed)
{
    var isValid = false;

    var validFilenameRegex;
    if(wildcardsAllowed)
    {
        validFilenameRegex = new RegExp(/^([^\\/"<>|]+)$/);
    }
    else
    {
        validFilenameRegex = new RegExp(/^([^\\/"<>|*?]+)$/);
    }
    isValid = validFilenameRegex.test(szPath);

    return isValid;
}

function getBrowserVersion()
{
    var ver = 0;
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
    if(msie > 0)
    {
        // If Internet Explorer, return version number
        ver = parseInt (ua.substring (msie+5, ua.indexOf (".", msie )));
    }
    return ver;
}