/********************************************************************************/
/* If DB contains the table GSEForceFailureOfGSEUpgrade execute DDL that will   */
/* fail.  This is in place to provide QA and dev with a way to test downgrade.  */
/********************************************************************************/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[GSEForceFailureOfGSEUpgrade]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
 BEGIN
    Alter table GSEDoesNotExist
    Add
        [dummy] [nvarchar](30) NULL
  END
GO