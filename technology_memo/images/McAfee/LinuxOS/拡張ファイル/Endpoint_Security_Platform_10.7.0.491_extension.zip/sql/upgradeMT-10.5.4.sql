
/*Added Table ClientUILockOutStatusTable in 10.5.4 for DOD , if this table exists then Adde new tenant coloumn */

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ClientUILockOutStatusTable]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
     IF NOT EXISTS(SELECT 1 FROM sys.columns WHERE Name = N'TenantId' AND Object_ID = Object_ID(N'[dbo].[ClientUILockOutStatusTable]'))
     BEGIN
        ALTER TABLE ClientUILockOutStatusTable  ADD TenantId  [int] NOT NULL CONSTRAINT DF_ClientUILockOutStatusTable_TenantId DEFAULT ((1))
     END
  END
GO


IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ClientUILockOutStatusTable]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    CREATE TABLE [dbo].[ClientUILockOutStatusTable](
      [AutoID] [bigint] NOT NULL IDENTITY (1,1),
      [TenantId] [int]  NOT NULL CONSTRAINT DF_ClientUILockOutStatusTable_TenantId DEFAULT dbo.FN_Core_GetContextTenantId(),
      [AgentGuid] [uniqueidentifier] NOT NULL,
      [Username] [nvarchar](50) NULL,
      [UiUnlockTime] [int] NOT NULL,
      [FailedAttemptTimeStamp] [datetime] NULL,
      [FailedAttemptCount] [int] NOT NULL,
      [MaxAttemptCount] [int] NOT NULL
        primary key (AutoID)
    )
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[findClientUILockOutSystems]') AND OBJECTPROPERTY(id, N'IsTableFunction') = 1)
  BEGIN
    DROP FUNCTION [dbo].[findClientUILockOutSystems]
  END
GO

CREATE FUNCTION [dbo].[findClientUILockOutSystems]()
  RETURNS @lockedSystems TABLE
  (
    AutoId int primary key NOT NULL,
    TenantId [int] NOT NULL,
    AgentGuid nvarchar(255) NOT NULL,
    Username nvarchar(255) NOT NULL,
    UiUnlockTime nvarchar(50) NOT NULL,
    FailedAttemptTimeStamp datetime NOT NULL ,
    FailedAttemptCount int not null,
    MaxAttemptCount int not null
  )
AS
  BEGIN
    DECLARE @temp TABLE
    (
      AutoId INT PRIMARY KEY NOT NULL,
      TenantId [int] NOT NULL,
      AgentGuid NVARCHAR(255) NOT NULL,
      Username NVARCHAR(255) NOT NULL,
      UiUnlockTime NVARCHAR(50) NOT NULL,
      FailedAttemptTimeStamp DATETIME NOT NULL ,
      FailedAttemptCount INT NOT NULL,
      MaxAttemptCount INT NOT NULL
    )
    DECLARE @LockedTableData TABLE
    (
      AutoId INT PRIMARY KEY NOT NULL,
      TenantId [int] NOT NULL,
      AgentGuid NVARCHAR(255) NOT NULL,
      Username NVARCHAR(255) NOT NULL,
      UiUnlockTime NVARCHAR(50) NOT NULL,
      FailedAttemptTimeStamp DATETIME NOT NULL ,
      FailedAttemptCount INT NOT NULL,
      MaxAttemptCount INT NOT NULL
    )

    -- Getting all the data into temp
    INSERT @temp SELECT AutoId,TenantId,AgentGuid,Username,UiUnlockTime,FailedAttemptTimeStamp,FailedAttemptCount,
					    MaxAttemptCount FROM [ClientUILockOutStatusTable]

    -- deleting temp data where unlock events are older than past 24 hours.
    DELETE FROM @temp WHERE FailedAttemptCount=0
                            AND DATEDIFF(SECOND,FailedAttemptTimeStamp,GETUTCDATE()) > 60*60*24

    -- Getting relevant locked event data along with unlock events.
    INSERT @LockedTableData
      SELECT * FROM @temp
      WHERE (DATEDIFF(SECOND,FailedAttemptTimeStamp,GETUTCDATE() ) < 60*UiUnlockTime
             AND FailedAttemptCount >= MaxAttemptCount) OR [FailedAttemptCount]=0

    -- Deleting old locked events for which new locked or unlocked event has already occured.
    DELETE t1
    FROM @LockedTableData AS t1 JOIN @LockedTableData AS t2
        ON t1.AgentGuid= t2.AgentGuid AND t1.username= t2.username AND t1.AutoID < t2.AutoID AND t1.[FailedAttemptTimeStamp]< t2.[FailedAttemptTimeStamp]

    -- Returning only locked system data
    INSERT @lockedSystems
      SELECT MAX(t1.AutoID),MAX(t1.TenantId), t1.AgentGuid, t1.Username, MAX(t1.UiUnlockTime), MAX(t1.FailedAttemptTimeStamp), MAX(t1.FailedAttemptCount), MAX(t1.MaxAttemptCount)
      FROM @LockedTableData t1 WHERE FailedAttemptCount!=0
      GROUP BY t1.AgentGuid, t1.Username

    RETURN
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ClientUICurrentLockOutStatus_View]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW [dbo].[ClientUICurrentLockOutStatus_View]
  END
GO

CREATE VIEW [dbo].[ClientUICurrentLockOutStatus_View] AS
  SELECT AutoID, AgentGuid, Username, UiUnlockTime, FailedAttemptTimeStamp, FailedAttemptCount, MaxAttemptCount from findClientUILockOutSystems() where  TenantId = dbo.FN_Core_GetContextTenantId()
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ClientUILockOutStatusTable_view]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW [dbo].[ClientUILockOutStatusTable_view]
  END
GO

CREATE VIEW [dbo].[ClientUILockOutStatusTable_view] AS
  SELECT AutoID, AgentGuid, Username, UiUnlockTime, FailedAttemptTimeStamp, FailedAttemptCount, MaxAttemptCount from ClientUILockOutStatusTable where  TenantId = dbo.FN_Core_GetContextTenantId()
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON [ClientUILockOutStatusTable] To [mcafeeOPS]
GRANT SELECT, INSERT, UPDATE, DELETE ON [ClientUILockOutStatusTable] To [mcafeeTenant]

GRANT SELECT, INSERT, UPDATE, DELETE ON [ClientUILockOutStatusTable_view] To [mcafeeOPS]
GRANT SELECT, INSERT, UPDATE, DELETE ON [ClientUILockOutStatusTable_view] To [mcafeeTenant]

grant select on [dbo].[ClientUICurrentLockOutStatus_View] to [mcafeeOps]
grant select on [dbo].[ClientUICurrentLockOutStatus_View] to [mcafeeTenant]
GO
