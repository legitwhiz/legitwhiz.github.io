------------------------------------------------------------------
--Copyright (c) 2018 McAfee LLC - All Rights Reserved
------------------------------------------------------------------
-- insert 10.6.0 product technology data
IF NOT EXISTS(SELECT 1 FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_GS_1060')
  BEGIN
    INSERT INTO [dbo].[EAMP.GSE.Blades]([ProductCode], [DispName], [TechnologyCount]) VALUES
      (N'ENDP_GS_1060', N'Endpoint Security Common', 1) -- windows product
  END
GO

if exists (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'EPExtendedEventMT' AND COLUMN_NAME = 'SourceDescription'
      AND DATA_TYPE = 'nvarchar' AND CHARACTER_MAXIMUM_LENGTH = 256)
  ALTER TABLE EPExtendedEventMT
    ALTER COLUMN SourceDescription NVARCHAR(512) NULL
GO

-- add GS_CustomProps.[GlobalExclusionStatus] column --
if exists(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[GS_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  if not exists(SELECT 1 FROM sys.columns WHERE Name = N'GlobalExclusionStatus' AND Object_ID = Object_ID(N'[dbo].[GS_CustomPropsMT]'))
  begin
      alter table [dbo].[GS_CustomPropsMT]
          add [GlobalExclusionStatus] [tinyint] null
  end
GO

-- GS_CustomProps rollup target --
--  Note: the table does not (and should not) exist in cloud,
--  so the column will only be added in on-prem.
if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ESPRollup_GS_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
  if not exists(SELECT 1 FROM sys.columns WHERE Name = N'GlobalExclusionStatus' AND Object_ID = Object_ID(N'[dbo].[ESPRollup_GS_CustomProps]'))
  begin
      alter table [dbo].[ESPRollup_GS_CustomProps]
        add [GlobalExclusionStatus] [tinyint] null
  end
go
