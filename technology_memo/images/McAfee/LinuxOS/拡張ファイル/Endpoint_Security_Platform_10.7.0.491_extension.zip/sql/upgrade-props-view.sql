
-- Rebuild props view, since column(s) were added --
alter view [dbo].[GS_CustomProps] as
select gs.*, pp.[ParentID] [LeafNodeID], pp.[ProductCode], pp.[TheHiddenTimestamp] [timestamp]
from [GS_CustomPropsMT] gs
  inner join [EPOProductProperties] pp on gs.[ParentID] = pp.[AutoID]
go
