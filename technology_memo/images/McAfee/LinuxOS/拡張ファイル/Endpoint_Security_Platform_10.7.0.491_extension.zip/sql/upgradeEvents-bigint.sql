-------------------------------------------Upgrade EPExtendedEventMT Table to bigint---------------------------------------
-- If EPOEvents table has BIGINT column and EPExtendedEventMT has int, need to upgrade to BIGINT
IF	EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'BIGINT' AND TABLE_NAME = 'EPOEventsMT' AND COLUMN_NAME = 'AutoID')
AND EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'INT' AND TABLE_NAME = 'EPExtendedEventMT' AND COLUMN_NAME = 'EventAutoID')
BEGIN
-- Drop Constraints --
  IF EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EPExtendedEventMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[EPExtendedEventMT]'))
    BEGIN
      ALTER TABLE [dbo].[EPExtendedEventMT] DROP CONSTRAINT [FK_EPExtendedEventMT_EPOEvents]
    END

  IF EXISTS (SELECT * FROM [INFORMATION_SCHEMA].[CONSTRAINT_TABLE_USAGE] WHERE TABLE_NAME = 'EPExtendedEventMT' AND CONSTRAINT_NAME = 'PK_EPExtendedEventMT')
    BEGIN
      ALTER TABLE [dbo].[EPExtendedEventMT] DROP CONSTRAINT [PK_EPExtendedEventMT]
    END

-- Drop Indexes --
  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_AccessRequested')
    BEGIN
      DROP INDEX [IX_EPExtendedEventMT_AccessRequested] ON [dbo].[EPExtendedEventMT]
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_AnalyzerGTIQuery')
    BEGIN
      DROP INDEX [IX_EPExtendedEventMT_AnalyzerGTIQuery] ON [dbo].[EPExtendedEventMT]
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_AttackVectorType')
    BEGIN
      DROP INDEX [IX_EPExtendedEventMT_AttackVectorType] ON [dbo].[EPExtendedEventMT]
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_BladeName')
    BEGIN
      DROP INDEX [IX_EPExtendedEventMT_BladeName] ON [dbo].[EPExtendedEventMT]
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_DurationBeforeDetection')
    BEGIN
      DROP INDEX [IX_EPExtendedEventMT_DurationBeforeDetection] ON [dbo].[EPExtendedEventMT]
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_Location')
    BEGIN
      DROP INDEX [IX_EPExtendedEventMT_Location] ON [dbo].[EPExtendedEventMT]
    END

-- Alter Column --
   ALTER TABLE [dbo].[EPExtendedEventMT] ALTER COLUMN EventAutoID BIGINT NOT NULL;

-- Add Constraint --
  ALTER TABLE [dbo].[EPExtendedEventMT] ADD  CONSTRAINT [PK_EPExtendedEventMT] PRIMARY KEY CLUSTERED
    (
        [EventAutoID] ASC
    )

  IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EPExtendedEventMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[EPExtendedEventMT]'))
    BEGIN
      ALTER TABLE [dbo].[EPExtendedEventMT]  WITH CHECK ADD
          CONSTRAINT [FK_EPExtendedEventMT_EPOEvents] FOREIGN KEY
          (
              [EventAutoID]
          )
      REFERENCES [dbo].[EPOEventsMT]
          (
              [AutoID]
          ) ON DELETE CASCADE ON UPDATE NO ACTION
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_Location')
    BEGIN
      CREATE NONCLUSTERED INDEX [IX_EPExtendedEventMT_Location] ON [dbo].[EPExtendedEventMT]
      (
          [Location] ASC
      )
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_BladeName')
    BEGIN
      CREATE NONCLUSTERED INDEX [IX_EPExtendedEventMT_BladeName] ON [dbo].[EPExtendedEventMT]
      (
          [BladeName] ASC
      )
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_AnalyzerGTIQuery')
    BEGIN
      CREATE NONCLUSTERED INDEX [IX_EPExtendedEventMT_AnalyzerGTIQuery] ON [dbo].[EPExtendedEventMT]
      (
          [AnalyzerGTIQuery] ASC
      )
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_AttackVectorType')
    BEGIN
      CREATE NONCLUSTERED INDEX [IX_EPExtendedEventMT_AttackVectorType] ON [dbo].[EPExtendedEventMT]
      (
          [AttackVectorType] ASC
      )
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_AccessRequested')
    BEGIN
      CREATE NONCLUSTERED INDEX [IX_EPExtendedEventMT_AccessRequested] ON [dbo].[EPExtendedEventMT]
      (
          [AccessRequested] ASC
      )
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_DurationBeforeDetection')
    BEGIN
      CREATE NONCLUSTERED INDEX [IX_EPExtendedEventMT_DurationBeforeDetection] ON [dbo].[EPExtendedEventMT]
      (
          [DurationBeforeDetection] ASC
      )
    END

END
GO

IF	EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'BIGINT' AND TABLE_NAME = 'EPOEventsMT' AND COLUMN_NAME = 'AutoID')
    AND EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'INT' AND TABLE_NAME = 'EPCertEventMT' AND COLUMN_NAME = 'EventAutoID')
  BEGIN
    -- Drop Constraints --
    IF EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EPCertEventMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[EPCertEventMT]'))
      BEGIN
        ALTER TABLE [dbo].[EPCertEventMT] DROP CONSTRAINT [FK_EPCertEventMT_EPOEvents]
      END

    IF EXISTS (SELECT * FROM [INFORMATION_SCHEMA].[CONSTRAINT_TABLE_USAGE] WHERE TABLE_NAME = 'EPCertEventMT' AND CONSTRAINT_NAME = 'PK_EPCertEventMT')
      BEGIN
        ALTER TABLE [dbo].[EPCertEventMT] DROP CONSTRAINT [PK_EPCertEventMT]
      END

    -- Alter Column --
    ALTER TABLE [dbo].[EPCertEventMT] ALTER COLUMN EventAutoID BIGINT NOT NULL;

    -- Add Constraint --
    ALTER TABLE [dbo].[EPCertEventMT] ADD  CONSTRAINT [PK_EPCertEventMT] PRIMARY KEY CLUSTERED
      (
        [EventAutoID] ASC
      )

    IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EPCertEventMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[EPCertEventMT]'))
      BEGIN
        ALTER TABLE [dbo].[EPCertEventMT]  WITH CHECK ADD
        CONSTRAINT [FK_EPCertEventMT_EPOEvents] FOREIGN KEY
          (
            [EventAutoID]
          )
        REFERENCES [dbo].[EPOEventsMT]
        (
          [AutoID]
        ) ON DELETE CASCADE ON UPDATE NO ACTION
      END
  END
GO