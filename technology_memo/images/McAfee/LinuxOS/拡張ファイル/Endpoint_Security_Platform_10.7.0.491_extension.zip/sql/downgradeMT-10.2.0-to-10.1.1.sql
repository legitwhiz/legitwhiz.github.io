-- Make sure there is only one installed blade record
DELETE FROM [dbo].[EAMP.GSE.Blades]
WHERE [ProductCode] IN (N'ENDP_GS_1000', N'ENDP_GS_1000MACX', N'ENDP_GS_1010', N'ENDP_GS_1020')
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
([ProductCode], [DispName], [TechnologyCount])
VALUES
  (N'ENDP_GS_1000', N'Endpoint Security Common', 1), -- windows product
  (N'ENDP_GS_1000MACX', N'Endpoint Security Common', 1),   -- mac product
  (N'ENDP_GS_1010', N'Endpoint Security Common', 1) -- windows product
GO


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GSRebuildTechnologyStatus_View]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[GSRebuildTechnologyStatus_View]
GO

CREATE PROCEDURE [dbo].[GSRebuildTechnologyStatus_View]
AS

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
		DROP VIEW [dbo].[AM_EndpointTechnologyStatus_View]

	DECLARE @sqlstring NVARCHAR(4000)

	SET @sqlstring = 'CREATE VIEW [dbo].[AM_EndpointTechnologyStatus_View] AS
			  SELECT * FROM GS_EndpointTechnologyStatus_View'

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	BEGIN
		SET @sqlstring = @sqlstring + ' UNION SELECT * FROM SP_EndpointTechnologyStatus_View'
	END

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	BEGIN
		SET @sqlstring = @sqlstring + ' UNION SELECT * FROM WP_EndpointTechnologyStatus_View'
	END

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FW_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	BEGIN
		SET @sqlstring = @sqlstring + ' UNION SELECT * FROM FW_EndpointTechnologyStatus_View'
	END

	EXEC (@sqlstring)

      GRANT SELECT ON AM_EndpointTechnologyStatus_View To mcafeeTenant
      GRANT SELECT, INSERT, UPDATE, DELETE ON AM_EndpointTechnologyStatus_View To mcafeeSystem
GO

IF EXISTS(SELECT *
          FROM dbo.syscolumns
          WHERE id = OBJECT_ID('[dbo].[GS_CustomPropsMT]') AND (name = 'IsATPClientDebugLoggingEnabled'))
  BEGIN
    ALTER TABLE [dbo].[GS_CustomPropsMT]
    DROP CONSTRAINT DF_GS_CustomPropsMT_IsATPClientDebugLoggingEnabled;
    ALTER TABLE [dbo].[GS_CustomPropsMT]
    DROP COLUMN [IsATPClientDebugLoggingEnabled]
  END
GO

IF EXISTS(SELECT *
              FROM dbo.syscolumns
              WHERE id = OBJECT_ID('[dbo].[GS_CustomPropsMT]') AND (name = 'ATPEventFilterlevel'))
  BEGIN
    ALTER TABLE [dbo].[GS_CustomPropsMT]
    DROP COLUMN [ATPEventFilterlevel];
  END
GO

-- Upgrade ENDP_GSE_EX 10.1.0 -> 10.1.1
--	EPCertificate changes to support NoSQL (aka HBase) changes
if object_id(N'EPSP_Insert_Certificate', N'P') is not null
  drop procedure [dbo].[EPSP_Insert_Certificate]
go

create procedure [dbo].[EPSP_Insert_Certificate]
    @tenantId int,
    @hash varchar(40),
    @vendor nvarchar(256) = null,
    @subject nvarchar(512) = null,
    @cert varchar(max) = null
as
  begin
    set nocount on;

    merge [dbo].[EPCertificateMT] dest
    using
      (
        select @tenantId, @hash, @vendor,@subject, @cert
      ) src ([TenantId], [Hash], [Vendor], [Subject], [Cert])
    on
      dest.[TenantId] = src.[TenantId]
      and dest.[Hash] = src.[Hash]
    when not matched then
    insert([TenantId], [Hash], [Vendor], [Subject], [Cert])
      values(src.[TenantId], src.[Hash], src.[Vendor], src.[Subject], src.[Cert])
    ;
  end
go

grant execute on [dbo].[EPSP_Insert_Certificate] to mcafeeSystem
go
