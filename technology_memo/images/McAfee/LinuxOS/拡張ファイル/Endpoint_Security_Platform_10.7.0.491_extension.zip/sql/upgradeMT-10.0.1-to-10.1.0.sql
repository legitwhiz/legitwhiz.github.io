-- Upgrade existing 10.1.0 ---
if exists(select * from INFORMATION_SCHEMA.TABLE_CONSTRAINTS where TABLE_NAME = N'EPCertEventMT' and CONSTRAINT_TYPE = 'PRIMARY KEY' and CONSTRAINT_NAME = N'PK_EPCertEventMT')
begin
  -- drop the PK constraint
  alter table [dbo].[EPCertEventMT] drop constraint [PK_EPCertEventMT];

  -- recreate the PK
  alter table [dbo].[EPCertEventMT] add constraint [PK_EPCertEventMT] primary key clustered
  (
    [TenantId] ASC, [EventAutoID] ASC
  )
end
go

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    -- If EPOEvents table has BIGINT column then create ParentID column as BIGINT
    IF	EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'BIGINT' AND TABLE_NAME = 'EPOEventsMT' AND COLUMN_NAME = 'AutoID')
      BEGIN
        CREATE TABLE [dbo].[EPCertEventMT](
          [EventAutoID] [bigint] NOT NULL,
          [TenantId] [int] NOT NULL,
          [Vendor] [nvarchar](256) NULL,
          [Subject] [nvarchar](512) NULL,
          [Hash] [varchar](40) NULL,
          [Cert] [varchar](MAX) NULL,
          CONSTRAINT [PK_EPCertEventMT] PRIMARY KEY CLUSTERED
          (
            [TenantId] ASC, [EventAutoID] ASC
          )
        )
      END
    ELSE
      BEGIN
        CREATE TABLE [dbo].[EPCertEventMT](
          [EventAutoID] [int] NOT NULL,
          [TenantId] [int] NOT NULL,
          [Vendor] [nvarchar](256) NULL,
          [Subject] [nvarchar](512) NULL,
          [Hash] [varchar](40) NULL,
          [Cert] [varchar](MAX) NULL,
          CONSTRAINT [PK_EPCertEventMT] PRIMARY KEY CLUSTERED
          (
            [TenantId] ASC, [EventAutoID] ASC
          )
        )
      END
  END
GO

IF NOT EXISTS(SELECT * FROM sysconstraints WHERE id=OBJECT_ID('EPCertEventMT') AND COL_NAME(id,colid)='TenantId' AND OBJECTPROPERTY(constid, N'IsDefaultCnst')=1)
  BEGIN
    ALTER TABLE [dbo].[EPCertEventMT]
    ADD CONSTRAINT [DF_EPCertEventMT_TenantId]
    DEFAULT dbo.FN_Core_GetContextTenantId() FOR TenantId
  END
GO

-- Drop existing FK constraints --
IF EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EPCertEventMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[EPCertEventMT]'))
BEGIN
  ALTER TABLE [dbo].[EPCertEventMT] DROP CONSTRAINT [FK_EPCertEventMT_EPOEvents]
END
GO

-- (Re)Create the FK constraint --
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EPCertEventMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[EPCertEventMT]'))
  BEGIN
    ALTER TABLE [dbo].[EPCertEventMT]  WITH CHECK ADD
    CONSTRAINT [FK_EPCertEventMT_EPOEvents] FOREIGN KEY
    (
      [TenantId], [EventAutoID]
    )
    REFERENCES [dbo].[EPOEvents]
    (
      [TenantId], [AutoID]
    ) ON DELETE CASCADE ON UPDATE NO ACTION
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPCertEventMT]')
    AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPCertEventMT]')
    AND name = N'IX_EPCertEventMT_TenantId_Hash')
BEGIN
    CREATE INDEX [IX_EPCertEventMT_TenantId_Hash] ON [dbo].[EPCertEventMT]
    (
        [TenantId] ASC, [Hash] ASC
    )
END
GO

--NOW CREATE THE VIEW FOR THE EPCertEventMT Table
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPCertEvent]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[EPCertEvent]
GO

CREATE VIEW [dbo].[EPCertEvent] AS
  WITH tenants AS
  (
    SELECT dbo.FN_Core_GetContextTenantId() [TenantId]
  )

  SELECT ce.[TenantId], ce.[EventAutoID], ce.[Hash], ce.[Vendor], ce.[Subject], ce.[Cert]
  FROM [dbo].[EPCertEventMT] ce
    INNER JOIN tenants t ON ce.[TenantId] = t.[TenantId]
GO

EXEC EPOCore_AddInsertTriggerToMTTable 'EPCertEvent'
GO

EXEC EPOCore_AddUpdateTriggerToMTTable 'EPCertEvent'
GO

EXEC EPOCore_AddDeleteTriggerToMTTable 'EPCertEvent'
GO

--EPCertEvent VIEW
GRANT SELECT, INSERT, UPDATE, DELETE ON EPCertEvent To mcafeeTenant
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON EPCertEvent To mcafeeSystem
GO

--EPCertEventMT TABLE
GRANT DELETE ON EPCertEventMT To mcafeeOps
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON EPCertEventMT To mcafeeSystem
GO
--temporary workaround for event insertion bug in EPO #913667
GRANT INSERT ON EPCertEventMT To mcafeeTenant
GO

-- Upgrade existing 10.1.0 ---
if exists(select * from INFORMATION_SCHEMA.TABLE_CONSTRAINTS where TABLE_NAME = N'EPCertificateMT' and CONSTRAINT_TYPE = 'PRIMARY KEY' and CONSTRAINT_NAME = N'PK_EPCertificateMT')
begin
  -- drop the PK constraint
  alter table [dbo].[EPCertificateMT] drop constraint [PK_EPCertificateMT];

  -- recreate the PK
  alter table [dbo].[EPCertificateMT] add constraint [PK_EPCertificateMT] primary key clustered
  (
    [TenantId] ASC, [Hash] ASC
  )
end
go

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertificateMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    CREATE TABLE [dbo].[EPCertificateMT](
      [TenantId] [int] NOT NULL,
      [Vendor] [nvarchar](256) NULL,
      [Subject] [nvarchar](512) NULL,
      [Hash] [varchar](40) NOT NULL,
      [Cert] [varchar](MAX) NULL,
      CONSTRAINT [PK_EPCertificateMT] PRIMARY KEY CLUSTERED
      (
        [TenantId] ASC, [Hash] ASC
      )
    )
  END
GO

IF NOT EXISTS(SELECT * FROM sysconstraints WHERE id=OBJECT_ID('EPCertificateMT') AND COL_NAME(id,colid)='TenantId' AND OBJECTPROPERTY(constid, N'IsDefaultCnst')=1)
  BEGIN
    ALTER TABLE [dbo].[EPCertificateMT]
    ADD CONSTRAINT [DF_EPCertificateMT_TenantId]
    DEFAULT dbo.FN_Core_GetContextTenantId() FOR TenantId
  END
GO

--NOW CREATE THE VIEW FOR THE EPCertificateMT Table
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPCertificate]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[EPCertificate]
GO

CREATE VIEW [dbo].[EPCertificate] AS
  WITH tenants AS
  (
    SELECT dbo.FN_Core_GetContextTenantId() [TenantId]
  )

  SELECT c.[TenantId], c.[Hash], c.[Vendor], c.[Subject], c.[Cert]
  FROM [dbo].[EPCertificateMT] c
    INNER JOIN tenants t ON c.[TenantId] = t.[TenantId]
GO

EXEC EPOCore_AddInsertTriggerToMTTable 'EPCertificate'
GO

EXEC EPOCore_AddUpdateTriggerToMTTable 'EPCertificate'
GO

EXEC EPOCore_AddDeleteTriggerToMTTable 'EPCertificate'
GO

IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT_Insert]') AND objectproperty(id, N'IsTrigger') = 1)
  DROP TRIGGER [dbo].[EPCertEventMT_Insert]
GO

CREATE TRIGGER [dbo].[EPCertEventMT_Insert] ON [dbo].[EPCertEventMT] FOR INSERT AS
  INSERT INTO [dbo].[EPCertificateMT] ([TenantId], [Vendor], [Subject], [Hash], [Cert])
    SELECT [i].[TenantId], [i].[Vendor], [i].[Subject], [i].[Hash], [i].[Cert]
    FROM [INSERTED] as [i]
      LEFT JOIN [dbo].[EPCertificateMT] AS [c] ON ([i].[TenantId] = [c].[TenantId] AND [i].[Hash] = [c].[Hash])
    WHERE [c].[Hash] IS NULL
GO

--EPCertificate VIEW
GRANT SELECT, INSERT, UPDATE, DELETE ON EPCertificate To mcafeeTenant
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON EPCertificate To mcafeeSystem
GO
--EPCertificateMT TABLE
GRANT DELETE ON EPCertificateMT To mcafeeOps
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON EPCertificateMT To mcafeeSystem
GO
--temporary workaround for event insertion bug in EPO #913667
GRANT INSERT ON EPCertificateMT To mcafeeTenant
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GS_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[GS_CustomProps]
GO

CREATE VIEW [dbo].[GS_CustomProps] AS
  WITH tenants AS
  (
    SELECT dbo.FN_Core_GetContextTenantId() [TenantId]
  )

  SELECT cp.*, ppv.[LeafNodeID]
  FROM [GS_CustomPropsMT] cp
    INNER JOIN [EPOProdPropsView_ENDPOINTSECURITYPLATFORM] ppv ON ppv.[ProductPropertiesID] = cp.[ParentID]
    INNER JOIN tenants t on cp.[TenantId] = t.[TenantId]
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON GS_CustomProps To mcafeeTenant
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON GS_CustomProps To mcafeeSystem
GO

EXEC EPOCore_AddInsertTriggerToMTTable 'GS_CustomProps'
GO

EXEC EPOCore_AddUpdateTriggerToMTTable 'GS_CustomProps'
GO

EXEC EPOCore_AddDeleteTriggerToMTTable 'GS_CustomProps'
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
([ProductCode], [DispName], [TechnologyCount])
VALUES
  (N'ENDP_GS_1010', N'Endpoint Security Common', 1)
GO
if exists (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_NAME = 'EPExtendedEventMT' AND COLUMN_NAME = 'AccessRequested'
             AND DATA_TYPE = 'nvarchar' AND CHARACTER_MAXIMUM_LENGTH = 70)
    ALTER TABLE EPExtendedEventMT
        ALTER COLUMN AccessRequested NVARCHAR(512)
GO
