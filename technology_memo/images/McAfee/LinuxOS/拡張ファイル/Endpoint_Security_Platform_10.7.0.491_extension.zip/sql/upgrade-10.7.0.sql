------------------------------------------------------------------
--Copyright (c) 2018-2020 McAfee LLC. - All Rights Reserved
------------------------------------------------------------------
/*
10.7.0 - Common steps for cloud and on-prem upgrade
*/

-- Update EPExtendedEventMT table --
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
  -- convert FileSize columns to bigint --
  IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'EPExtendedEventMT' AND COLUMN_NAME = 'SourceFileSize' AND DATA_TYPE = 'INT')
  BEGIN
    ALTER TABLE [dbo].[EPExtendedEventMT] ALTER COLUMN [SourceFileSize] bigint NULL
  END

  IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'EPExtendedEventMT' AND COLUMN_NAME = 'TargetFileSize' AND DATA_TYPE = 'INT')
  BEGIN
    ALTER TABLE [dbo].[EPExtendedEventMT] ALTER COLUMN [TargetFileSize] bigint NULL
  END

  -- increase length of SourceShareName --
  IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'EPExtendedEventMT' AND COLUMN_NAME = 'SourceShareName' AND CHARACTER_MAXIMUM_LENGTH < 260)
  BEGIN
      ALTER TABLE [dbo].[EPExtendedEventMT] ALTER COLUMN [SourceShareName] nvarchar(260) NULL
  END

  -- target path --
  IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'EPExtendedEventMT' AND COLUMN_NAME = 'TargetPath' AND CHARACTER_MAXIMUM_LENGTH < 512)
  BEGIN
    ALTER TABLE [dbo].[EPExtendedEventMT] ALTER COLUMN [TargetPath] [nvarchar](512) NULL
  END
  ;

  -- refresh the view definitions --
  EXEC sp_refreshview '[dbo].[EPExtendedEvent]'

  -- Re-create View for the TP event aggregration data source
  -- Note:  This view is owned by the TP Extension.  TP_Events view will be invalid due to column data type changes
  --  in the EPExtendedEvent table.  So re-create the view.
  if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].TP_Events]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    EXEC sp_refreshview N'[dbo].[TP_Events]'
  END
  ;
END
GO

-- Upgrade GS_CustomProps --
if exists(select 1 from dbo.sysobjects WHERE id = object_id(N'[dbo].[GS_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
begin
  -- create IsODSScannedFileLoggingEnabled column
  if not exists(select 1 from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = N'GS_CustomPropsMT' and COLUMN_NAME = N'IsODSScannedFileLoggingEnabled')
  begin
    alter table [dbo].[GS_CustomPropsMT]
      add [IsODSScannedFileLoggingEnabled] [bit] null
  end

  ---- update GS_CustomPropsMT, make SPbComplianceStatus nullable ----
  -- allow nulls --
  if(COLUMNPROPERTY(OBJECT_ID('[dbo].[GS_CustomPropsMT]'), N'SPbComplianceStatus', 'AllowsNull') = 0)
  begin
      alter table [dbo].[GS_CustomPropsMT] alter column [SPbComplianceStatus] bit null
  end

  -- drop the default constraint --
  if (OBJECT_ID(N'[dbo].[DF_GS_CustomPropsMT_SPbComplianceStatus]', 'D') is not null)
  begin
      alter table [dbo].[GS_CustomPropsMT] drop constraint [DF_GS_CustomPropsMT_SPbComplianceStatus]
  end
  ;

  -- refresh views --
  exec sp_refreshview N'[dbo].[GS_CustomProps]';
end
go
