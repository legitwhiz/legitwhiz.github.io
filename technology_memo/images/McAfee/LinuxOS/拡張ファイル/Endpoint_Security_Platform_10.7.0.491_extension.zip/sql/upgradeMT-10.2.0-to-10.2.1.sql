/*
*	BZ: Bug 1158941 - Endpoint Security: Self Protection Compliance dashboard doesn't retrieve data as expected
*	GS_CustomPropsMT table was modified in 10.2.0, but the GS_CustomProps view was not updated
*/

/****** Object:  View [dbo].[GS_CustomProps] ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GS_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[GS_CustomProps]
GO

CREATE VIEW [dbo].[GS_CustomProps] AS
	select cp.*, ppv.[LeafNodeID]
		from [GS_CustomPropsMT] cp
			inner join [EPOProdPropsView_ENDPOINTSECURITYPLATFORM] ppv ON cp.[ParentID] = ppv.[ProductPropertiesID]
		where cp.[TenantId] = convert(int, substring(context_info(), 5, 4))
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON [GS_CustomProps] To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON [GS_CustomProps] To mcafeeSystem
go
