-- upgrade-10.5.2 --

---------- Performance ---------
-- update GS_CustomProps view:  performance --
alter view [dbo].[GS_CustomProps] as
    select gs.*, pp.[ParentID] [LeafNodeID], pp.[ProductCode], pp.[TheHiddenTimestamp] [timestamp]
    from [GS_CustomPropsMT] gs
        inner join [EPOProductProperties] pp on gs.[ParentID] = pp.[AutoID]
go

-- update tech status: make it read only
alter view [dbo].[GS_EndpointTechnologyStatus_View] as
    select pp.[AutoIDSP] [AutoID], pp.[LeafNodeID], 5 [TechnologyType], pp.[IsSPEnabled] [Enabled], pp.[ProductCode]
    from [GS_CustomProps] pp with(nolock)
go

alter procedure [dbo].[GSRebuildTechnologyStatus_View] as
    if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
        drop view [dbo].[AM_EndpointTechnologyStatus_View]

    declare @sql varchar(4000) = 'create view [dbo].[AM_EndpointTechnologyStatus_View] as' +
            char(13) + char(9) + 'select * from [GS_EndpointTechnologyStatus_View] with(nolock)'

    if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
        set @sql = @sql + char(13) + char(9) + 'union select * from [SP_EndpointTechnologyStatus_View] with(nolock)'

    if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FW_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
        set @sql = @sql + char(13) + char(9) + 'union select * from [FW_EndpointTechnologyStatus_View] with(nolock)'

    if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
        set @sql = @sql + char(13) + char(9) + 'union select * from [WP_EndpointTechnologyStatus_View] with(nolock)'

    exec(@sql)
go

-- rebuild the tech view
exec [dbo].[GSRebuildTechnologyStatus_View]
go

--------- remove unwanted indexes ---------
IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_GS_CustomPropsMT_AutoIDSP' -- Index Name
                                                                                      AND so.[Name] = N'GS_CustomPropsMT')
    DROP INDEX IX_GS_CustomPropsMT_AutoIDSP ON GS_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_GS_CustomPropsMT_SPbComplianceStatus' -- Index Name
                                                                                      AND so.[Name] = N'GS_CustomPropsMT')
    DROP INDEX IX_GS_CustomPropsMT_SPbComplianceStatus ON GS_CustomPropsMT;
GO

--------- ePO Rollup Reporting ---------
-- EPExtendedEvent rollup source, join to EPOEvents for the timestamp --
if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ESPRollup_EPExtendedEvent_Source]') and OBJECTPROPERTY([id], N'IsView') = 1)
	drop view [dbo].[ESPRollup_EPExtendedEvent_Source]
go

create view [dbo].[ESPRollup_EPExtendedEvent_Source] as
	select ex.*, e.[TheTimestamp] [timestamp]
		from [dbo].[EPExtendedEvent] ex
			inner join [dbo].[EPOEvents] e on ex.[EventAutoID] = e.[AutoID]
go

-- EPExtendedEvent rollup target --
if not exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ESPRollup_EPExtendedEvent]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
	declare @idType nvarchar(128)
	select @idType = ISNULL([DATA_TYPE], N'bigint') FROM INFORMATION_SCHEMA.COLUMNS WHERE [TABLE_NAME] = 'EPORollup_Events' AND [COLUMN_NAME] = 'AutoID'

	declare @sql nvarchar(4000) =
N'create table [dbo].[ESPRollup_EPExtendedEvent]
(
	[RegSvrId] [int] not null,
	[EventAutoID] [' + @idType + '] not null,
	[Location] [nvarchar](128) null,
	[BladeName] [nvarchar](24) null,
	[AnalyzerTechnologyVersion] [nvarchar](20) null,
	[AnalyzerContentCreationDate] [datetime] null,
	[AnalyzerContentVersion] [nvarchar](20) null,
	[AMCoreContentVersion] [nvarchar](20) null,
	[AnalyzerRuleID] [nvarchar](36) null,
	[AnalyzerRuleName] [nvarchar](128) null,
	[AnalyzerRegInfo] [nvarchar](128) null,
	[AnalyzerGTIQuery] [bit] null,
	[ThreatDetectedOnCreation] [bit] null,
	[ThreatImpact] [nvarchar](128) null,
	[SourcePort] [int] null,
	[SourceShareName] [nvarchar](260) null,
	[SourceProcessHash] [nvarchar](512) null,
	[SourceProcessSigned] [bit] null,
	[SourceProcessSigner] [nvarchar](1024) null,
	[SourceParentProcessName] [nvarchar](260) null,
	[SourceParentProcessHash] [nvarchar](512) null,
	[SourceParentProcessSigned] [bit] null,
	[SourceParentProcessSigner] [nvarchar](1024) null,
	[SourceFilePath] [nvarchar](260) null,
	[SourceFileSize] [bigint] null,
	[SourceHash] [nvarchar](512) null,
	[SourceSigned] [bit] null,
	[SourceSigner] [nvarchar](1024) null,
	[SourceModifyTime] [datetime] null,
	[SourceAccessTime] [datetime] null,
	[SourceCreateTime] [datetime] null,
	[SourceDeviceDisplayName] [nvarchar](128) null,
	[SourceDeviceSerialNumber] [nvarchar](512) null,
	[SourceDeviceVID] [nvarchar](512) null,
	[SourceDevicePID] [nvarchar](512) null,
	[SourceDescription] [nvarchar](512) null,
	[SourceURLRatingCode] [nvarchar](100) null,
	[SourceURLWebCategory] [nvarchar](100) null,
	[TargetURL] [nvarchar](1024) null,
	[TargetShareName] [nvarchar](128) null,
	[TargetHash] [nvarchar](512) null,
	[TargetSigned] [bit] null,
	[TargetSigner] [nvarchar](1024) null,
	[TargetParentProcessSigned] [bit] null,
	[TargetParentProcessSigner] [nvarchar](1024) null,
	[TargetParentProcessName] [nvarchar](260) null,
	[TargetParentProcessHash] [nvarchar](512) null,
	[TargetName] [nvarchar](260) null,
	[TargetPath] [nvarchar](512) null,
	[TargetFileSize] [bigint] null,
	[TargetModifyTime] [datetime] null,
	[TargetAccessTime] [datetime] null,
	[TargetCreateTime] [datetime] null,
	[TargetDeviceDisplayName] [nvarchar](128) null,
	[TargetDeviceSerialNumber] [nvarchar](512) null,
	[TargetDeviceVID] [nvarchar](512) null,
	[TargetDevicePID] [nvarchar](512) null,
	[TargetDescription] [nvarchar](256) null,
	[Cleanable] [bit] null,
	[TaskName] [nvarchar](256) null,
	[APIName] [nvarchar](128) null,
	[FirstAttemptedAction] [nvarchar](24) null,
	[FirstActionStatus] [bit] null,
	[SecondAttemptedAction] [nvarchar](24) null,
	[SecondActionStatus] [bit] null,
	[Topic] [nvarchar](50) null,
	[AttackVectorType] [int] null,
	[AccessRequested] [nvarchar](512) null,
	[DurationBeforeDetection] [int] null,
	[NaturalLangDescription] [nvarchar](max) null,
	[Direction] [bit] null,
	CONSTRAINT [PK_ESPRollup_EPExtendedEvent] primary key clustered
	([RegSvrId] asc, [EventAutoID] asc)
)'
	exec(@sql)
end
go

if not exists (select 1 from [sys].[foreign_keys] where [object_id] = OBJECT_ID(N'[FK_ESPRollup_EPExtendedEvent_EPORollup_Events]') and [parent_object_id] = OBJECT_ID(N'[dbo].[ESPRollup_EPExtendedEvent]'))
begin
	alter table [dbo].[ESPRollup_EPExtendedEvent]
	add constraint [FK_ESPRollup_EPExtendedEvent_EPORollup_Events] foreign key
		([RegSvrId], [EventAutoID])
		references [dbo].[EPORollup_Events]
		([RegSvrId], [AutoID])
		on delete cascade on update no action
end
go

-- GS_CustomProps rollup target --
if not exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ESPRollup_GS_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
	create table [dbo].[ESPRollup_GS_CustomProps]
	(
		[RegSvrId] [int] not null,
		[AutoID] [int] not null,
		[ParentID] [int] not null,
		[IsSPEnabled] [bit] null,
		[AutoIDSP] [uniqueidentifier] null,
		[SPbComplianceStatus] [bit] null,
		[SPComplianceStatus] [nvarchar](100) null,
		[SPAdditionalComplianceStatus] [nvarchar](100) null,
		[UIPasswordChanged] [datetime] null,
		[clientUIAccessLevel] [int] null,
		[gtiProxyType] [int] null,
		[IsWindowsApplicationLoggingEnabled] [bit] null,
		[IsSendEventsToepoEnabled] [bit] null,
		[APEventFilterlevel] [int] null,
		[BOEventFilterlevel] [int] null,
		[FWEventFilterlevel] [int] null,
		[OASEventFilterlevel] [int] null,
		[ODSEventFilterlevel] [int] null,
		[WPEventFilterlevel] [int] null,
		[IsClientActivityLoggingEnabled] [bit] null,
		[IsODSScannedFileLoggingEnabled] [bit] null,
		[IsAPClientDebugLoggingEnabled] [bit] null,
		[IsBOClientDebugLoggingEnabled] [bit] null,
		[IsOASClientDebugLoggingEnabled] [bit] null,
		[IsODSClientDebugLoggingEnabled] [bit] null,
		[IsFWClientDebugLoggingEnabled] [bit] null,
		[IsWPClientDebugLoggingEnabled] [bit] null,
		[ClientActivityLogSizeMB] [int] null,
		[ClientDebugLogSizeMB] [int] null,
		[ClientLogFilesLocation] [nvarchar](128) null,
		[AacVersion] [nvarchar](128) null,
		[Hotfixes] [nvarchar](256) null,
		[Patch] [nvarchar](3000) null,
		[LicenseStatus] [nvarchar](256) null,
		[Language] [nvarchar](256) null,
		[IsATPClientDebugLoggingEnabled] [bit] null,
		[ATPEventFilterlevel] [int] null,
		[IsTimeBasedPasswordEnabled] [bit] null,
		constraint [PK_ESPRollup_GS_CustomProps] primary key clustered
		([RegSvrId] asc, [AutoID] asc)
	)
end
go

if not exists (select 1 from [sys].[foreign_keys] where [object_id] = OBJECT_ID(N'[FK_ESPRollup_GS_CustomProps_EPORollup_ProductProperties]') and [parent_object_id] = OBJECT_ID(N'[dbo].[ESPRollup_GS_CustomProps]'))
begin
	alter table [dbo].[ESPRollup_GS_CustomProps] add
	constraint [FK_ESPRollup_GS_CustomProps_EPORollup_ProductProperties] foreign key
		([RegSvrId], [ParentID])
		references [dbo].[EPORollup_ProductProperties]
		([ServerId], [ExternalId])
		on delete cascade on update no action
end
go

--create unique index on the foreign key
if exists(select 1 from [dbo].[sysobjects] where [id] = OBJECT_ID(N'[dbo].[ESPRollup_GS_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
	and not exists(select 1 from [dbo].[sysindexes] where [id] = OBJECT_ID(N'[dbo].[ESPRollup_GS_CustomProps]') and [name] = N'IX_ESPRollup_GS_CustomProps_ParentID')
begin
	create unique nonclustered index [IX_ESPRollup_GS_CustomProps_ParentID] on [dbo].[ESPRollup_GS_CustomProps]
		([RegSvrId] asc, [ParentID] asc)
end
go
