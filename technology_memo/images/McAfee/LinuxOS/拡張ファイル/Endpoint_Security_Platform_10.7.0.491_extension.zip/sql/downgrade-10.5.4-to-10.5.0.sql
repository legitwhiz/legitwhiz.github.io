
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[findClientUILockOutSystems]') AND OBJECTPROPERTY(id, N'IsTableFunction') = 1)
  BEGIN
    DROP FUNCTION [dbo].[findClientUILockOutSystems]
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ClientUICurrentLockOutStatus_View]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW [dbo].[ClientUICurrentLockOutStatus_View]
  END
GO
