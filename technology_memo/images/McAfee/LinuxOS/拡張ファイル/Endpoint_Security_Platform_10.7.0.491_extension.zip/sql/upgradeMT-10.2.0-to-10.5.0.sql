-- Make sure there is only one installed blade record
DELETE FROM [dbo].[EAMP.GSE.Blades]
WHERE [ProductCode] IN (N'ENDP_GS_1000', N'ENDP_GS_1000MACX', N'ENDP_GS_1010', N'ENDP_GS_1020', N'ENDP_GS_1050')
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
([ProductCode], [DispName], [TechnologyCount])
VALUES
  (N'ENDP_GS_1000', N'Endpoint Security Common', 1), -- windows product
  (N'ENDP_GS_1000MACX', N'Endpoint Security Common', 1),   -- mac product
  (N'ENDP_GS_1010', N'Endpoint Security Common', 1), -- windows product
  (N'ENDP_GS_1020', N'Endpoint Security Common', 1), -- windows product
  (N'ENDP_GS_1050', N'Endpoint Security Common', 1) -- windows product
GO

IF NOT EXISTS (SELECT *
                FROM dbo.syscolumns
                WHERE id = object_id(N'[dbo].[GS_CustomPropsMT]') AND (name = 'IsTimeBasedPasswordEnabled'))
  BEGIN
    ALTER TABLE [dbo].[GS_CustomPropsMT]
      ADD [IsTimeBasedPasswordEnabled] [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsTimeBasedPasswordEnabled DEFAULT ((0));
  END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GS_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[GS_CustomProps]
GO
CREATE VIEW [dbo].[GS_CustomProps] AS
    SELECT [GS_CustomPropsMT].*, [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[LeafNodeID]
    FROM [GS_CustomPropsMT]
    INNER JOIN [EPOProdPropsView_ENDPOINTSECURITYPLATFORM] ON [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[ProductPropertiesID] = [GS_CustomPropsMT].[ParentID]
GO

--Reapply permissions
GRANT SELECT, INSERT, UPDATE, DELETE ON GS_CustomProps To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON GS_CustomProps To mcafeeSystem

--GS_CustomPropsMT TABLE
GRANT DELETE ON GS_CustomPropsMT To mcafeeOps
GRANT SELECT, INSERT, UPDATE, DELETE ON GS_CustomPropsMT To mcafeeSystem

------------------------------------------------

-----drop the index - fix for Defect #1151734-----
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
        AND EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_AccessRequested')
BEGIN
  DROP INDEX IX_EPExtendedEventMT_AccessRequested
  ON EPExtendedEventMT;
END
GO
------------------------------------------------

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ESPRegisteredInstallationStatus]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    CREATE TABLE [dbo].[ESPRegisteredInstallationStatus](
      [ProductFamily] [nvarchar](50) NOT NULL,
      CONSTRAINT [PK_ESPRegisteredInstallationStatus] PRIMARY KEY CLUSTERED
        (
          [ProductFamily] ASC
        )
    )
  END
GO

GRANT SELECT ON [ESPRegisteredInstallationStatus] To mcafeeTenant
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON [ESPRegisteredInstallationStatus] To mcafeeSystem
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ESPSystemProductVersionInfo]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[ESPSystemProductVersionInfo]
  END
GO

CREATE VIEW [dbo].[ESPSystemProductVersionInfo]
AS
  SELECT [spvi].*
  FROM [EPOSystemProductVersionInfo] AS [spvi]
    INNER JOIN [ESPRegisteredInstallationStatus] AS [ris]
      ON [spvi].[ProductFamily] = [ris].[ProductFamily]
GO

GRANT SELECT ON [ESPSystemProductVersionInfo] To mcafeeTenant
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON [ESPSystemProductVersionInfo] To mcafeeSystem
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ESPEndPointSecurityTechnologyStatus]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[ESPEndPointSecurityTechnologyStatus]
  END
GO

CREATE VIEW [dbo].[ESPEndPointSecurityTechnologyStatus]
AS
  SELECT [cp].[AutoIDSP] AS [AutoID], [ppv].[LeafNodeID], 5 AS [TechnologyType], [cp].[IsSPEnabled] AS [Enabled], [ppv].[ProductCode]
  FROM [GS_CustomPropsMT] AS [cp]
    LEFT JOIN [EPOProdPropsView_ENDPOINTSECURITYPLATFORM] AS [ppv]
      ON [ppv].[ProductPropertiesID] = [cp].[ParentID]
GO

GRANT SELECT ON [ESPEndPointSecurityTechnologyStatus] To mcafeeTenant
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON [ESPEndPointSecurityTechnologyStatus] To mcafeeSystem
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ESPRegisteredTechnologyStatus]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    CREATE TABLE [dbo].[ESPRegisteredTechnologyStatus](
      [TechnologyView] [nvarchar](128) NOT NULL,
      CONSTRAINT [PK_ESPRegisteredTechnologyStatus] PRIMARY KEY CLUSTERED
        (
          [TechnologyView] ASC
        )
    )
  END
GO

GRANT SELECT ON [ESPRegisteredTechnologyStatus] To mcafeeTenant
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON [ESPRegisteredTechnologyStatus] To mcafeeSystem
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[ESPBuildTechnologyStatusView]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
  BEGIN
    DROP PROCEDURE [dbo].[ESPBuildTechnologyStatusView]
  END
GO

CREATE PROCEDURE [dbo].[ESPBuildTechnologyStatusView]
AS
  BEGIN
    IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ESPTechnologyStatus]') and OBJECTPROPERTY(id, N'IsView') = 1)
      BEGIN
        DROP VIEW [dbo].[ESPTechnologyStatus]
      END

    DECLARE @sqlstring NVARCHAR(MAX)

    SET @sqlstring = 'CREATE VIEW [dbo].[ESPTechnologyStatus] AS
			  SELECT [AutoID], [LeafNodeID], [TechnologyType], [Enabled], [ProductCode]
			  FROM ESPEndPointSecurityTechnologyStatus'

    DECLARE @TechnologyView NVARCHAR(128)

    DECLARE Technologies CURSOR FAST_FORWARD FOR
      SELECT TechnologyView FROM ESPRegisteredTechnologyStatus

    OPEN Technologies
    FETCH NEXT FROM Technologies
    INTO @TechnologyView

    WHILE @@FETCH_STATUS = 0
      BEGIN
        IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].'+ @TechnologyView) and OBJECTPROPERTY(id, N'IsView') = 1)
          BEGIN
            SET @sqlstring = @sqlstring + ' UNION SELECT [AutoID], [LeafNodeID], [TechnologyType], [Enabled], [ProductCode] FROM ' + @TechnologyView
          END

        FETCH NEXT FROM Technologies
        INTO @TechnologyView
      END

    CLOSE Technologies
    DEALLOCATE Technologies

    EXEC (@sqlstring)

    GRANT SELECT ON [ESPTechnologyStatus] To mcafeeTenant
    GRANT SELECT, INSERT, UPDATE, DELETE ON [ESPTechnologyStatus] To mcafeeSystem
  END
GO

EXEC ESPBuildTechnologyStatusView
GO
