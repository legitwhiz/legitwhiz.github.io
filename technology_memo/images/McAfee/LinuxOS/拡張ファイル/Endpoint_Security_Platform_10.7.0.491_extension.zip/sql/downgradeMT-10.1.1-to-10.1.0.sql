-- Downgrade \ uninstall ENDP_GSE_EX 10.1.1 -> 10.1.0
--	EPCertificate changes to support NoSQL (aka HBase) changes
if object_id(N'EPSP_Insert_Certificate', N'P') is not null
	drop procedure [dbo].[EPSP_Insert_Certificate]
go
