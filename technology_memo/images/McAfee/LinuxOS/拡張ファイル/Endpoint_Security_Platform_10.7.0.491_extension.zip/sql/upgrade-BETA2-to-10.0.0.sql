--NOW CREATE THE VIEW FOR THE EPExtendedEventMT Table
IF exists(SELECT *
          FROM dbo.sysobjects
          WHERE id = object_id(N'[dbo].[EPExtendedEvent]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[EPExtendedEvent]
GO

CREATE VIEW [dbo].[EPExtendedEvent] AS
  SELECT
    EventAutoID,
    Location,
    BladeName,
    AnalyzerTechnologyVersion,
    AnalyzerContentCreationDate,
    AnalyzerContentVersion,
    AMCoreContentVersion,
    AnalyzerRuleID,
    AnalyzerRuleName,
    AnalyzerRegInfo,
    AnalyzerGTIQuery,
    ThreatDetectedOnCreation,
    ThreatImpact,
    SourcePort,
    SourceShareName,
    SourceProcessHash,
    SourceProcessSigned,
    SourceProcessSigner,
    SourceParentProcessName,
    SourceParentProcessHash,
    SourceParentProcessSigned,
    SourceParentProcessSigner,
    SourceFilePath,
    SourceFileSize,
    SourceHash,
    SourceSigned,
    SourceSigner,
    SourceModifyTime,
    SourceAccessTime,
    SourceCreateTime,
    SourceDeviceDisplayName,
    SourceDeviceSerialNumber,
    SourceDeviceVID,
    SourceDevicePID,
    SourceDescription,
    SourceURLRatingCode,
    SourceURLWebCategory,
    TargetURL,
    TargetShareName,
    TargetHash,
    TargetSigned,
    TargetSigner,
    TargetParentProcessSigned,
    TargetParentProcessSigner,
    TargetParentProcessName,
    TargetParentProcessHash,
    TargetName,
    TargetPath,
    TargetFileSize,
    TargetModifyTime,
    TargetAccessTime,
    TargetCreateTime,
    TargetDeviceDisplayName,
    TargetDeviceSerialNumber,
    TargetDeviceVID,
    TargetDevicePID,
    TargetDescription,
    Cleanable,
    TaskName,
    APIName,
    FirstAttemptedAction,
    FirstActionStatus,
    SecondAttemptedAction,
    SecondActionStatus,
    Topic,
    CASE WHEN AttackVectorType IN (0, 1, 2, 3, 4, 5, 6, 7)
      THEN AttackVectorType
    ELSE 99 END AS AttackVectorType,
    AccessRequested,
    DurationBeforeDetection,
    NaturalLangDescription,
    Direction
  FROM EPExtendedEventMT
GO

IF NOT EXISTS(SELECT *
              FROM dbo.syscolumns
              WHERE id = OBJECT_ID('[dbo].[GS_CustomPropsMT]') AND (name = 'IsSendEventsToepoEnabled'))
  BEGIN
    ALTER TABLE [dbo].[GS_CustomPropsMT]
    ADD [IsSendEventsToepoEnabled] [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsSendEventsToepoEnabled DEFAULT ((0));
  END
GO
