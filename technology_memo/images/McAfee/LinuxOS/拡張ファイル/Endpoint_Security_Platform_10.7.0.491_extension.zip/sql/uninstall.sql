IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GSRebuildTechnologyStatus_View]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[GSRebuildTechnologyStatus_View]
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EAMP.GSE.Blades]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
 DROP TABLE [dbo].[EAMP.GSE.Blades]
END
GO

 --first delete the view
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EndpointInstallationStatus_View]'))
BEGIN
   DROP VIEW[dbo].EndpointInstallationStatus_View
END
GO

------Start EPExtendedEventMT Table and EPExtendedEvent View------
--first delete the view
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPExtendedEvent]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[EPExtendedEvent]
GO
--next delete the foreign key
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EPExtendedEventMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[EPExtendedEventMT]'))
ALTER TABLE [dbo].[EPExtendedEventMT] DROP CONSTRAINT [FK_EPExtendedEventMT_EPOEvents]
GO
--finally drop the table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EPExtendedEventMT]') AND type in (N'U'))
DROP TABLE [dbo].[EPExtendedEventMT]
GO
------End EPExtendedEventMT Table and EPExtendedEvent View------

------Start GS_CustomPropsMT Table and GS_CustomProps View------
--first drop the view
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GS_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[GS_CustomProps]
GO
--next delete the foreign key for 5.0/5.1
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GS_CustomPropsMT_EPOProductProperties]') AND parent_object_id = OBJECT_ID(N'[dbo].[GS_CustomPropsMT]'))
ALTER TABLE [dbo].[GS_CustomPropsMT] DROP CONSTRAINT [FK_GS_CustomPropsMT_EPOProductProperties]
GO
--next delete the foreign key for 5.2
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GS_CustomPropsMT_EPOProductPropertiesMT]') AND parent_object_id = OBJECT_ID(N'[dbo].[GS_CustomPropsMT]'))
ALTER TABLE [dbo].[GS_CustomPropsMT] DROP CONSTRAINT [FK_GS_CustomPropsMT_EPOProductPropertiesMT]
GO
--finally drop the table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GS_CustomPropsMT]') AND type in (N'U'))
DROP TABLE [dbo].[GS_CustomPropsMT]
GO
------End GS_CustomPropsMT Table and GS_CustomProps View------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[AM_EndpointTechnologyStatus_View]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GS_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[GS_EndpointTechnologyStatus_View]
GO

------Certificate Items------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPCertificate]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[EPCertificate]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPCertEvent]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[EPCertEvent]
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertificateMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    DROP TABLE [dbo].[EPCertificateMT]
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    DROP TABLE [dbo].[EPCertEventMT]
  END
GO

-- Downgrade \ uninstall ENDP_GSE_EX 10.1.1 -> 10.1.0
--  EPCertificate changes to support NoSQL (aka HBase) changes
if object_id(N'EPSP_Insert_Certificate', N'P') is not null
  drop procedure [dbo].[EPSP_Insert_Certificate]
go

------ End Certificate Items------
--------- ePO Rollup Reporting ---------

-- EPExtendedEvent rollup source --
if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ESPRollup_EPExtendedEvent_Source]') and OBJECTPROPERTY([id], N'IsView') = 1)
  drop view [dbo].[ESPRollup_EPExtendedEvent_Source]
go

-- EPExtendedEvent rollup target --
if exists (select 1 from [sys].[foreign_keys] where [object_id] = OBJECT_ID(N'[FK_ESPRollup_EPExtendedEvent_EPORollup_Events]') and [parent_object_id] = OBJECT_ID(N'[dbo].[ESPRollup_EPExtendedEvent]'))
begin
	alter table [dbo].[ESPRollup_EPExtendedEvent] drop constraint [FK_ESPRollup_EPExtendedEvent_EPORollup_Events]
end
go

if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ESPRollup_EPExtendedEvent]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
	drop table [dbo].[ESPRollup_EPExtendedEvent]
end
go

-- GS_CustomProps rollup target --
if exists (select 1 from [sys].[foreign_keys] where [object_id] = OBJECT_ID(N'[FK_ESPRollup_GS_CustomProps_EPORollup_ProductProperties]') and [parent_object_id] = OBJECT_ID(N'[dbo].[ESPRollup_GS_CustomProps]'))
begin
  alter table [dbo].[ESPRollup_GS_CustomProps] drop constraint [FK_ESPRollup_GS_CustomProps_EPORollup_ProductProperties]
end

if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ESPRollup_GS_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
  drop table [dbo].[ESPRollup_GS_CustomProps]
end
go

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ClientUILockOutStatusTable]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    DROP TABLE [dbo].[ClientUILockOutStatusTable]
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[findClientUILockOutSystems]') AND OBJECTPROPERTY(id, N'IsFunction') = 1)
  BEGIN
    DROP FUNCTION [dbo].[findClientUILockOutSystems]
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ClientUICurrentLockOutStatus_View]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW [dbo].[ClientUICurrentLockOutStatus_View]
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ClientUILockOutStatusTable_view]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW [dbo].[ClientUILockOutStatusTable_view]
  END
GO
