------------------------------------------------------------------
--Copyright (c) 2014 McAfee Inc. - All Rights Reserved
------------------------------------------------------------------
--FOR MULTI-TENANT ONLY

--EAMP.GSE.Blades
GRANT SELECT ON [EAMP.GSE.Blades] To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON [EAMP.GSE.Blades] To mcafeeSystem

--EPExtendedEvent VIEW
GRANT SELECT, INSERT, UPDATE, DELETE ON EPExtendedEvent To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON EPExtendedEvent To mcafeeSystem

--EPExtendedEventMT TABLE
GRANT DELETE ON EPExtendedEventMT To mcafeeOps
GRANT SELECT, INSERT, UPDATE, DELETE ON EPExtendedEventMT To mcafeeSystem
--temporary workaround for event insertion bug in EPO #913667
GRANT INSERT ON EPExtendedEventMT To mcafeeTenant

--GS_CustomProps VIEW
GRANT SELECT, INSERT, UPDATE, DELETE ON GS_CustomProps To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON GS_CustomProps To mcafeeSystem

--GS_CustomPropsMT TABLE
GRANT DELETE ON GS_CustomPropsMT To mcafeeOps
GRANT SELECT, INSERT, UPDATE, DELETE ON GS_CustomPropsMT To mcafeeSystem

--EndpointInstallationStatus VIEW
GRANT SELECT ON EndpointInstallationStatus_View To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON EndpointInstallationStatus_View To mcafeeSystem

--GS_EndpointTechnologyStatus_View
GRANT SELECT ON GS_EndpointTechnologyStatus_View To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON GS_EndpointTechnologyStatus_View To mcafeeSystem

--AM_EndpointTechnologyStatus_View
GRANT SELECT ON AM_EndpointTechnologyStatus_View To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON AM_EndpointTechnologyStatus_View To mcafeeSystem

--ClientUILockOutStatus View
GRANT SELECT, INSERT, UPDATE, DELETE ON [ClientUILockOutStatusTable] To [mcafeeOPS]
GRANT SELECT, INSERT, UPDATE, DELETE ON [ClientUILockOutStatusTable] To [mcafeeTenant]

GRANT SELECT, INSERT, UPDATE, DELETE ON [ClientUILockOutStatusTable_view] To [mcafeeOPS]
GRANT SELECT, INSERT, UPDATE, DELETE ON [ClientUILockOutStatusTable_view] To [mcafeeTenant]

grant select on [dbo].[ClientUICurrentLockOutStatus_View] to [mcafeeOps]
grant select on [dbo].[ClientUICurrentLockOutStatus_View] to [mcafeeTenant]

