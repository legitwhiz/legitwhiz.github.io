------------------------------------------------------------------
--Copyright (c) 2014 McAfee Inc. - All Rights Reserved
------------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EAMP.GSE.Blades]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[EAMP.GSE.Blades](
  [AutoID] [int] NOT NULL IDENTITY (1,1),
	[ProductCode] [nvarchar](50) NULL,
	[DispName] [nvarchar](256) NULL,   --We can join with EPOProductFamilies to get the friendly name of the blade, then we don't need this field
	[TechnologyCount] [int] NULL,
 CONSTRAINT [PK_EAMP.GSE.Blades] PRIMARY KEY CLUSTERED
(
	[AutoID] ASC
)
)
END
GO

-- Make sure there is only one installed blade record
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] in (N'ENDP_GS_1000', N'ENDP_GS_1020LYNX', N'ENDP_GS_1060LYNX')
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
  ([ProductCode], [DispName], [TechnologyCount])
VALUES
  ('ENDP_GS_1000', 'Endpoint Security Common', 1),
  ('ENDP_GS_1020LYNX', 'Endpoint Security Common', 1),
  ('ENDP_GS_1060LYNX', 'Endpoint Security Common', 1)
GO

-------------------------------------------Start EPExtendedEventMT Table and EPExtendedEvent View---------------------------------------
--EXTENDED CUSTOM EVENT TABLE
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    -- If EPOEvents table has BIGINT column then create ParentID column as BIGINT
    IF	EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'BIGINT' AND TABLE_NAME = 'EPOEventsMT' AND COLUMN_NAME = 'AutoID')
    BEGIN
      CREATE TABLE [dbo].[EPExtendedEventMT](
        [EventAutoID] [bigint] NOT NULL,
        [TenantId] [int] NOT NULL,
        [Location] [nvarchar](128) NULL,
        [BladeName] [nvarchar](24) NULL,
        [AnalyzerTechnologyVersion] [nvarchar](20) NULL,
        [AnalyzerContentCreationDate] [datetime] NULL,
        [AnalyzerContentVersion] [nvarchar] (20) NULL,
        [AMCoreContentVersion] [nvarchar](20) NULL,
        [AnalyzerRuleID] [nvarchar](36) NULL,
        [AnalyzerRuleName] [nvarchar](128) NULL,
        [AnalyzerRegInfo] [nvarchar](128) NULL,
        [AnalyzerGTIQuery] [bit] NULL,
        [ThreatDetectedOnCreation] [bit] NULL,
        [ThreatImpact] [nvarchar](128) NULL,
        [SourcePort] [int] NULL,
        [SourceShareName] [nvarchar](260) NULL,
        [SourceProcessHash] [nvarchar](512) NULL,
        [SourceProcessSigned] [bit] NULL,
        [SourceProcessSigner] [nvarchar](1024) NULL,
        [SourceParentProcessName] [nvarchar](260) NULL,
        [SourceParentProcessHash] [nvarchar](512) NULL,
        [SourceParentProcessSigned] [bit] NULL,
        [SourceParentProcessSigner] [nvarchar](1024) NULL,
        [SourceFilePath] [nvarchar](260) NULL,
        [SourceFileSize] [bigint] NULL,
        [SourceHash] [nvarchar](512) NULL,
        [SourceSigned] [bit] NULL,
        [SourceSigner] [nvarchar](1024) NULL,
        [SourceModifyTime] [datetime] NULL,
        [SourceAccessTime] [datetime] NULL,
        [SourceCreateTime] [datetime] NULL,
        [SourceDeviceDisplayName] [nvarchar](128) NULL,
        [SourceDeviceSerialNumber] [nvarchar](512) NULL,
        [SourceDeviceVID] [nvarchar](512) NULL,
        [SourceDevicePID] [nvarchar](512) NULL,
        [SourceDescription] [nvarchar](512) NULL,
        [SourceURLRatingCode] [nvarchar](100) NULL,
        [SourceURLWebCategory] [nvarchar](100) NULL,
        [TargetURL] [nvarchar](1024) NULL,
        [TargetShareName] [nvarchar](128) NULL,
        [TargetHash] [nvarchar](512) NULL,
        [TargetSigned] [bit] NULL,
        [TargetSigner] [nvarchar](1024) NULL,
        [TargetParentProcessSigned] [bit] NULL,
        [TargetParentProcessSigner] [nvarchar](1024) NULL,
        [TargetParentProcessName] [nvarchar](260) NULL,
        [TargetParentProcessHash] [nvarchar](512) NULL,
        [TargetName] [nvarchar](260) NULL,
        [TargetPath] [nvarchar](512) NULL,
        [TargetFileSize] [bigint] NULL,
        [TargetModifyTime] [datetime] NULL,
        [TargetAccessTime] [datetime] NULL,
        [TargetCreateTime] [datetime] NULL,
        [TargetDeviceDisplayName] [nvarchar](128) NULL,
        [TargetDeviceSerialNumber] [nvarchar](512) NULL,
        [TargetDeviceVID] [nvarchar](512) NULL,
        [TargetDevicePID] [nvarchar](512) NULL,
        [TargetDescription] [nvarchar](256) NULL,
        [Cleanable] [bit] NULL,
        [TaskName] [nvarchar](256) NULL,
        [APIName] [nvarchar](128) NULL,
        [FirstAttemptedAction] [nvarchar](24) NULL,
        [FirstActionStatus] [bit] NULL,
        [SecondAttemptedAction] [nvarchar](24) NULL,
        [SecondActionStatus] [bit] NULL,
        [Topic] [nvarchar](50) NULL,
        [AttackVectorType] [int] NULL,
        [AccessRequested] [nvarchar](70) NULL,
        [DurationBeforeDetection] [int] NULL,
        [NaturalLangDescription] [nvarchar](max) NULL,
        [Direction] [bit] NULL,
        CONSTRAINT [PK_EPExtendedEventMT] PRIMARY KEY NONCLUSTERED (
          [EventAutoID] ASC
        )
      )
    END
  ELSE
    BEGIN
      CREATE TABLE [dbo].[EPExtendedEventMT](
        [EventAutoID] [int] NOT NULL,
        [TenantId] [int] NOT NULL,
        [Location] [nvarchar](128) NULL,
        [BladeName] [nvarchar](24) NULL,
        [AnalyzerTechnologyVersion] [nvarchar](20) NULL,
        [AnalyzerContentCreationDate] [datetime] NULL,
        [AnalyzerContentVersion] [nvarchar] (20) NULL,
        [AMCoreContentVersion] [nvarchar](20) NULL,
        [AnalyzerRuleID] [nvarchar](36) NULL,
        [AnalyzerRuleName] [nvarchar](128) NULL,
        [AnalyzerRegInfo] [nvarchar](128) NULL,
        [AnalyzerGTIQuery] [bit] NULL,
        [ThreatDetectedOnCreation] [bit] NULL,
        [ThreatImpact] [nvarchar](128) NULL,
        [SourcePort] [int] NULL,
        [SourceShareName] [nvarchar](260) NULL,
        [SourceProcessHash] [nvarchar](512) NULL,
        [SourceProcessSigned] [bit] NULL,
        [SourceProcessSigner] [nvarchar](1024) NULL,
        [SourceParentProcessName] [nvarchar](260) NULL,
        [SourceParentProcessHash] [nvarchar](512) NULL,
        [SourceParentProcessSigned] [bit] NULL,
        [SourceParentProcessSigner] [nvarchar](1024) NULL,
        [SourceFilePath] [nvarchar](260) NULL,
        [SourceFileSize] [bigint] NULL,
        [SourceHash] [nvarchar](512) NULL,
        [SourceSigned] [bit] NULL,
        [SourceSigner] [nvarchar](1024) NULL,
        [SourceModifyTime] [datetime] NULL,
        [SourceAccessTime] [datetime] NULL,
        [SourceCreateTime] [datetime] NULL,
        [SourceDeviceDisplayName] [nvarchar](128) NULL,
        [SourceDeviceSerialNumber] [nvarchar](512) NULL,
        [SourceDeviceVID] [nvarchar](512) NULL,
        [SourceDevicePID] [nvarchar](512) NULL,
        [SourceDescription] [nvarchar](512) NULL,
        [SourceURLRatingCode] [nvarchar](100) NULL,
        [SourceURLWebCategory] [nvarchar](100) NULL,
        [TargetURL] [nvarchar](1024) NULL,
        [TargetShareName] [nvarchar](128) NULL,
        [TargetHash] [nvarchar](512) NULL,
        [TargetSigned] [bit] NULL,
        [TargetSigner] [nvarchar](1024) NULL,
        [TargetParentProcessSigned] [bit] NULL,
        [TargetParentProcessSigner] [nvarchar](1024) NULL,
        [TargetParentProcessName] [nvarchar](260) NULL,
        [TargetParentProcessHash] [nvarchar](512) NULL,
        [TargetName] [nvarchar](260) NULL,
        [TargetPath] [nvarchar](512) NULL,
        [TargetFileSize] [bigint] NULL,
        [TargetModifyTime] [datetime] NULL,
        [TargetAccessTime] [datetime] NULL,
        [TargetCreateTime] [datetime] NULL,
        [TargetDeviceDisplayName] [nvarchar](128) NULL,
        [TargetDeviceSerialNumber] [nvarchar](512) NULL,
        [TargetDeviceVID] [nvarchar](512) NULL,
        [TargetDevicePID] [nvarchar](512) NULL,
        [TargetDescription] [nvarchar](256) NULL,
        [Cleanable] [bit] NULL,
        [TaskName] [nvarchar](256) NULL,
        [APIName] [nvarchar](128) NULL,
        [FirstAttemptedAction] [nvarchar](24) NULL,
        [FirstActionStatus] [bit] NULL,
        [SecondAttemptedAction] [nvarchar](24) NULL,
        [SecondActionStatus] [bit] NULL,
        [Topic] [nvarchar](50) NULL,
        [AttackVectorType] [int] NULL,
        [AccessRequested] [nvarchar](70) NULL,
        [DurationBeforeDetection] [int] NULL,
        [NaturalLangDescription] [nvarchar](max) NULL,
        [Direction] [bit] NULL,
        CONSTRAINT [PK_EPExtendedEventMT] PRIMARY KEY NONCLUSTERED (
          [EventAutoID] ASC
        )
      )
    END
END
GO

IF NOT EXISTS(SELECT * FROM sysconstraints WHERE id=OBJECT_ID('EPExtendedEventMT') AND COL_NAME(id,colid)='TenantId' AND OBJECTPROPERTY(constid, N'IsDefaultCnst')=1)
BEGIN
ALTER TABLE [dbo].[EPExtendedEventMT]
  ADD CONSTRAINT [DF_EPExtendedEventMT_TenantId]
  DEFAULT dbo.FN_Core_GetContextTenantId() FOR TenantId
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EPExtendedEventMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[EPExtendedEventMT]'))
BEGIN
ALTER TABLE [dbo].[EPExtendedEventMT]  WITH CHECK ADD
    CONSTRAINT [FK_EPExtendedEventMT_EPOEvents] FOREIGN KEY
    (
        [EventAutoID]
    )
REFERENCES [dbo].[EPOEventsMT]
    (
        [AutoID]
    ) ON DELETE CASCADE ON UPDATE NO ACTION
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]')
    AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]')
    AND name = N'IX_EPExtendedEventMT_TenantId_EventAutoID')
BEGIN
    CREATE UNIQUE CLUSTERED INDEX [IX_EPExtendedEventMT_TenantId_EventAutoID] ON [dbo].[EPExtendedEventMT]
    (
        [TenantId] ASC, [EventAutoID] ASC
    )
END

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_Location')
BEGIN
CREATE NONCLUSTERED INDEX [IX_EPExtendedEventMT_Location] ON [dbo].[EPExtendedEventMT]
(
    [Location] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_BladeName')
BEGIN
CREATE NONCLUSTERED INDEX [IX_EPExtendedEventMT_BladeName] ON [dbo].[EPExtendedEventMT]
(
    [BladeName] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_AnalyzerGTIQuery')
BEGIN
CREATE NONCLUSTERED INDEX [IX_EPExtendedEventMT_AnalyzerGTIQuery] ON [dbo].[EPExtendedEventMT]
(
    [AnalyzerGTIQuery] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_AttackVectorType')
BEGIN
CREATE NONCLUSTERED INDEX [IX_EPExtendedEventMT_AttackVectorType] ON [dbo].[EPExtendedEventMT]
(
    [AttackVectorType] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[EPExtendedEventMT]') AND name = N'IX_EPExtendedEventMT_DurationBeforeDetection')
BEGIN
CREATE NONCLUSTERED INDEX [IX_EPExtendedEventMT_DurationBeforeDetection] ON [dbo].[EPExtendedEventMT]
(
    [DurationBeforeDetection] ASC
)
END

--NOW CREATE THE VIEW FOR THE EPExtendedEventMT Table
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPExtendedEvent]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[EPExtendedEvent]
GO

CREATE VIEW [dbo].[EPExtendedEvent] AS
	SELECT TenantId, EventAutoID, Location, BladeName, AnalyzerTechnologyVersion, AnalyzerContentCreationDate, AnalyzerContentVersion, AMCoreContentVersion, AnalyzerRuleID, AnalyzerRuleName, AnalyzerRegInfo,
    AnalyzerGTIQuery, ThreatDetectedOnCreation, ThreatImpact, SourcePort, SourceShareName, SourceProcessHash, SourceProcessSigned, SourceProcessSigner, SourceParentProcessName,
    SourceParentProcessHash, SourceParentProcessSigned, SourceParentProcessSigner, SourceFilePath, SourceFileSize, SourceHash, SourceSigned, SourceSigner, SourceModifyTime, SourceAccessTime,
    SourceCreateTime, SourceDeviceDisplayName, SourceDeviceSerialNumber, SourceDeviceVID, SourceDevicePID, SourceDescription, SourceURLRatingCode, SourceURLWebCategory, TargetURL,
    TargetShareName, TargetHash, TargetSigned, TargetSigner, TargetParentProcessSigned, TargetParentProcessSigner, TargetParentProcessName, TargetParentProcessHash, TargetName, TargetPath,
    TargetFileSize, TargetModifyTime, TargetAccessTime, TargetCreateTime, TargetDeviceDisplayName, TargetDeviceSerialNumber, TargetDeviceVID, TargetDevicePID, TargetDescription, Cleanable, TaskName,
    APIName, FirstAttemptedAction, FirstActionStatus, SecondAttemptedAction, SecondActionStatus, Topic,
    CASE WHEN AttackVectorType IN (0, 1, 2, 3, 4, 5, 6, 7) then AttackVectorType ELSE 99 END AS AttackVectorType,
    AccessRequested, DurationBeforeDetection, NaturalLangDescription, Direction
  FROM EPExtendedEventMT
  WHERE TenantId = 0
    OR [TenantId] = (SELECT TOP(1) [tid] FROM [dbo].[epofn_GetTenancyInfoTable]())
    OR EXISTS (SELECT TOP(1) [ops] FROM [epofn_GetTenancyInfoTable]() WHERE [ops] = 1)
GO

EXEC EPOCore_AddInsertTriggerToMTTable 'EPExtendedEvent'
GO

EXEC EPOCore_AddUpdateTriggerToMTTable 'EPExtendedEvent'
GO

EXEC EPOCore_AddDeleteTriggerToMTTable 'EPExtendedEvent'
GO

-------------------------------------------End EPExtendedEventMT Table and EPExtendedEvent View---------------------------------------

-----------------------------------------Start GS_CustomPropsMT Table and GS_CustomProps View-------------------------------------
--CUSTOM PROPERTIES TABLE
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[GS_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[GS_CustomPropsMT](
    [AutoID]                                 [int] NOT NULL IDENTITY (1,1),
    [ParentID]                               [int] NOT NULL,             -- Required for custom properties
    [TenantId]                               [int] NOT NULL,

    [IsSPEnabled]                            [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsSPEnabled DEFAULT ((0)),
    [AutoIDSP]                               [uniqueidentifier] DEFAULT NEWSEQUENTIALID(),
    [SPbComplianceStatus]                    [bit] NULL,
    [SPComplianceStatus]                     [nvarchar] (100) NULL,
    [SPAdditionalComplianceStatus]           [nvarchar] (100) NULL,
    [UIPasswordChanged]                      [datetime] NULL,
    [clientUIAccessLevel]                    [int] NULL,
    [gtiProxyType]                           [int] NULL,
    [IsWindowsApplicationLoggingEnabled]     [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsWindowsApplicationLoggingEnabled DEFAULT ((0)),
    [IsSendEventsToepoEnabled]     [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsSendEventsToepoEnabled DEFAULT ((0)),
    [APEventFilterlevel]                     [int] NULL,
    [BOEventFilterlevel]                     [int] NULL,
    [FWEventFilterlevel]                     [int] NULL,
    [OASEventFilterlevel]                    [int] NULL,
    [ODSEventFilterlevel]                    [int] NULL,
    [ATPEventFilterlevel]                    [int] NULL,
    [WPEventFilterlevel]                     [int] NULL,
    [IsClientActivityLoggingEnabled]         [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsClientActivityLoggingEnabled DEFAULT ((0)),
    [IsODSScannedFileLoggingEnabled]         [bit] NULL,
    [IsAPClientDebugLoggingEnabled]          [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsAPClientDebugLoggingEnabled DEFAULT ((0)),
    [IsBOClientDebugLoggingEnabled]          [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsBOClientDebugLoggingEnabled DEFAULT ((0)),
    [IsOASClientDebugLoggingEnabled]         [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsOASClientDebugLoggingEnabled DEFAULT ((0)),
    [IsODSClientDebugLoggingEnabled]         [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsODSClientDebugLoggingEnabled DEFAULT ((0)),
    [IsFWClientDebugLoggingEnabled]          [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsFWClientDebugLoggingEnabled DEFAULT ((0)),
    [IsWPClientDebugLoggingEnabled]          [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsWPClientDebugLoggingEnabled DEFAULT ((0)),
    [IsATPClientDebugLoggingEnabled]         [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsATPClientDebugLoggingEnabled DEFAULT ((0)),
    [ClientActivityLogSizeMB]                [int] NULL,
    [ClientDebugLogSizeMB]                   [int] NULL,
    [ClientLogFilesLocation]                 [nvarchar](128) NULL,
    [AacVersion]                             [nvarchar](128) NULL,
    [Hotfixes]                               [nvarchar] (256) NULL,
    [Patch]                                  [nvarchar] (3000) NULL,
    [LicenseStatus]                          [nvarchar] (256) NULL,
    [Language]                               [nvarchar] (256) NULL,
    [GlobalExclusionStatus]                  [tinyint] NULL,

    CONSTRAINT [PK_GS_CustomPropsMT] PRIMARY KEY NONCLUSTERED
    (
      [AutoID] ASC
    )
)
END
GO

/****** Object:  Index [IX_GS_CustomPropsMT_TenantId_AutoID] ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[GS_CustomPropsMT]') AND name = N'IX_GS_CustomPropsMT_TenantId_AutoID')
	DROP INDEX [IX_GS_CustomPropsMT_TenantId_AutoID] ON [dbo].[GS_CustomPropsMT] WITH ( ONLINE = OFF )
GO

CREATE UNIQUE CLUSTERED INDEX [IX_GS_CustomPropsMT_TenantId_AutoID] ON [dbo].[GS_CustomPropsMT]
(
	[TenantId] ASC,	[AutoID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF,
		ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF NOT EXISTS(SELECT * FROM sysconstraints WHERE id=OBJECT_ID('GS_CustomPropsMT') AND COL_NAME(id,colid)='TenantId' AND OBJECTPROPERTY(constid, N'IsDefaultCnst')=1)
BEGIN
ALTER TABLE [dbo].[GS_CustomPropsMT]
  ADD CONSTRAINT [DF_GS_CustomPropsMT_TenantId]
  DEFAULT dbo.FN_Core_GetContextTenantId() FOR TenantId
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GS_CustomPropsMT_EPOProductPropertiesMT]') AND parent_object_id = OBJECT_ID(N'[dbo].[GS_CustomPropsMT]'))
BEGIN
ALTER TABLE [dbo].[GS_CustomPropsMT] ADD
    CONSTRAINT [FK_GS_CustomPropsMT_EPOProductPropertiesMT] FOREIGN KEY (
        [ParentID]
    ) REFERENCES [dbo].[EPOProductPropertiesMT] (
        [AutoID]
    ) ON DELETE CASCADE ON UPDATE NO ACTION
END
GO

--create unique index on the foreign key column
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[GS_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[GS_CustomPropsMT]') AND name = N'IX_GS_CustomPropsMT_ParentID')
BEGIN
CREATE UNIQUE NONCLUSTERED INDEX [IX_GS_CustomPropsMT_ParentID] ON [dbo].[GS_CustomPropsMT]
(
    [ParentID] ASC
)
END
GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[GS_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[GS_CustomPropsMT]') AND name = N'IX_GS_CustomPropsMT_AutoIDSP')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_GS_CustomPropsMT_AutoIDSP] ON [dbo].[GS_CustomPropsMT]
-- (
--     [AutoIDSP] ASC
-- )
-- END
-- GO

-- IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[GS_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[GS_CustomPropsMT]') AND name = N'IX_GS_CustomPropsMT_SPbComplianceStatus')
-- BEGIN
-- CREATE NONCLUSTERED INDEX [IX_GS_CustomPropsMT_SPbComplianceStatus] ON [dbo].[GS_CustomPropsMT]
-- (
--     [SPbComplianceStatus] ASC
-- )
-- END
-- GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[GS_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[GS_CustomPropsMT]') AND name = N'IX_GS_CustomPropsMT_Hotfixes')
BEGIN
CREATE NONCLUSTERED INDEX [IX_GS_CustomPropsMT_Hotfixes] ON [dbo].[GS_CustomPropsMT]
(
    [Hotfixes] ASC
)
END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GS_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[GS_CustomProps]
GO
CREATE VIEW [dbo].[GS_CustomProps] AS
    SELECT [GS_CustomPropsMT].*, [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[LeafNodeID]
    FROM [GS_CustomPropsMT]
    INNER JOIN [EPOProdPropsView_ENDPOINTSECURITYPLATFORM] ON [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[ProductPropertiesID] = [GS_CustomPropsMT].[ParentID]
    WHERE TenantId IN (SELECT TOP(1) tid FROM [epofn_GetTenancyInfoTable]())
       OR    TenantId = 0
       OR    EXISTS (SELECT TOP(1) ops FROM [epofn_GetTenancyInfoTable]() WHERE ops = 1)
GO

EXEC EPOCore_AddInsertTriggerToMTTable 'GS_CustomProps'
GO

EXEC EPOCore_AddUpdateTriggerToMTTable 'GS_CustomProps'
GO

EXEC EPOCore_AddDeleteTriggerToMTTable 'GS_CustomProps'
GO
-----------------------------------------End GS_CustomPropsMT Table and GS_CustomProps View-------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EndpointInstallationStatus_View]'))
BEGIN
     DROP VIEW[dbo].EndpointInstallationStatus_View
END
GO

CREATE VIEW [dbo].EndpointInstallationStatus_View
AS
    select  convert(nvarchar(20), vi.[autoId]) + N'_' + vi.[ProductFamily] [AutoId], vi.[autoId] [LeafNodeId],
            vi.[ProductVersion], vi.[FamilyDispName], vi.[ProductCode]
    from [EPOSystemProductVersionInfo_Fast] vi
    where
        vi.[ProductFamily] = N'THREATPREVENTION'
      or vi.[ProductFamily] = N'WEBCONTROL'
      or vi.[ProductFamily] = N'FIREWALL'
      or (vi.[ProductFamily] = N'TIEClientMETA' and vi.[FamilyDispName] = N'Endpoint Security Adaptive Threat Protection')
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GS_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[GS_EndpointTechnologyStatus_View]
GO
CREATE VIEW [dbo].[GS_EndpointTechnologyStatus_View] AS
SELECT [GS_CustomProps].AutoIDSP AS AutoID, [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[LeafNodeID], 5 AS TechnologyType, [GS_CustomProps].[IsSPEnabled] AS Enabled
FROM  [GS_CustomProps]
LEFT JOIN [EPOProdPropsView_ENDPOINTSECURITYPLATFORM] ON [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[ProductPropertiesID] = [GS_CustomProps].[ParentID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[AM_EndpointTechnologyStatus_View]
GO
CREATE VIEW [dbo].[AM_EndpointTechnologyStatus_View] AS
SELECT * FROM [dbo].[GS_EndpointTechnologyStatus_View]
GO




IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ClientUILockOutStatusTable]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    CREATE TABLE [dbo].[ClientUILockOutStatusTable](
      [AutoID] [bigint] NOT NULL IDENTITY (1,1),
      [TenantId] [int]  NOT NULL CONSTRAINT DF_ClientUILockOutStatusTable_TenantId DEFAULT dbo.FN_Core_GetContextTenantId(),
      [AgentGuid] [uniqueidentifier] NOT NULL,
      [Username] [nvarchar](50) NULL,
      [UiUnlockTime] [int] NOT NULL,
      [FailedAttemptTimeStamp] [datetime] NULL,
      [FailedAttemptCount] [int] NOT NULL,
      [MaxAttemptCount] [int] NOT NULL
        primary key (AutoID)
    )
  END
GO


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[findClientUILockOutSystems]') AND OBJECTPROPERTY(id, N'IsTableFunction') = 1)
  BEGIN
    DROP FUNCTION [dbo].[findClientUILockOutSystems]
  END
GO

CREATE FUNCTION [dbo].[findClientUILockOutSystems]()
  RETURNS @lockedSystems TABLE
  (
    AutoId int primary key NOT NULL,
    TenantId [int] NOT NULL,
    AgentGuid nvarchar(255) NOT NULL,
    Username nvarchar(255) NOT NULL,
    UiUnlockTime nvarchar(50) NOT NULL,
    FailedAttemptTimeStamp datetime NOT NULL ,
    FailedAttemptCount int not null,
    MaxAttemptCount int not null
  )
AS
  BEGIN
    DECLARE @temp TABLE
    (
      AutoId INT PRIMARY KEY NOT NULL,
	    TenantId [int] NOT NULL,
      AgentGuid NVARCHAR(255) NOT NULL,
      Username NVARCHAR(255) NOT NULL,
      UiUnlockTime NVARCHAR(50) NOT NULL,
      FailedAttemptTimeStamp DATETIME NOT NULL ,
      FailedAttemptCount INT NOT NULL,
      MaxAttemptCount INT NOT NULL
    )
    DECLARE @LockedTableData TABLE
    (
      AutoId INT PRIMARY KEY NOT NULL,
	    TenantId [int] NOT NULL,
      AgentGuid NVARCHAR(255) NOT NULL,
      Username NVARCHAR(255) NOT NULL,
      UiUnlockTime NVARCHAR(50) NOT NULL,
      FailedAttemptTimeStamp DATETIME NOT NULL ,
      FailedAttemptCount INT NOT NULL,
      MaxAttemptCount INT NOT NULL
    )

    -- Getting all the data into temp
    INSERT @temp SELECT AutoId,TenantId,AgentGuid,Username,UiUnlockTime,FailedAttemptTimeStamp,FailedAttemptCount,
					    MaxAttemptCount FROM [ClientUILockOutStatusTable]

    -- deleting temp data where unlock events are older than past 24 hours.
    DELETE FROM @temp WHERE FailedAttemptCount=0
                            AND DATEDIFF(SECOND,FailedAttemptTimeStamp,GETUTCDATE()) > 60*60*24

    -- Getting relevant locked event data along with unlock events.
    INSERT @LockedTableData
      SELECT * FROM @temp
      WHERE (DATEDIFF(SECOND,FailedAttemptTimeStamp,GETUTCDATE() ) < 60*UiUnlockTime
             AND FailedAttemptCount >= MaxAttemptCount) OR [FailedAttemptCount]=0

    -- Deleting old locked events for which new locked or unlocked event has already occured.
    DELETE t1
    FROM @LockedTableData AS t1 JOIN @LockedTableData AS t2
        ON t1.AgentGuid= t2.AgentGuid AND t1.username= t2.username AND t1.AutoID < t2.AutoID AND t1.[FailedAttemptTimeStamp]< t2.[FailedAttemptTimeStamp]

    -- Returning only locked system data
    INSERT @lockedSystems
      SELECT MAX(t1.AutoID),MAX(t1.TenantId), t1.AgentGuid, t1.Username, MAX(t1.UiUnlockTime), MAX(t1.FailedAttemptTimeStamp), MAX(t1.FailedAttemptCount), MAX(t1.MaxAttemptCount)
      FROM @LockedTableData t1 WHERE FailedAttemptCount!=0
      GROUP BY t1.AgentGuid, t1.Username

    RETURN
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ClientUICurrentLockOutStatus_View]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW [dbo].[ClientUICurrentLockOutStatus_View]
  END
GO

CREATE VIEW [dbo].[ClientUICurrentLockOutStatus_View] AS
  SELECT AutoID, AgentGuid, Username, UiUnlockTime, FailedAttemptTimeStamp, FailedAttemptCount, MaxAttemptCount from findClientUILockOutSystems() where  TenantId = dbo.FN_Core_GetContextTenantId()
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ClientUILockOutStatusTable_view]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW [dbo].[ClientUILockOutStatusTable_view]
  END
GO

CREATE VIEW [dbo].[ClientUILockOutStatusTable_view] AS
  SELECT AutoID, AgentGuid, Username, UiUnlockTime, FailedAttemptTimeStamp, FailedAttemptCount, MaxAttemptCount from ClientUILockOutStatusTable where  TenantId = dbo.FN_Core_GetContextTenantId()
GO

-- insert 10.7.0 product technology data
IF NOT EXISTS(SELECT 1 FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_GS_1070')
  BEGIN
    INSERT INTO [dbo].[EAMP.GSE.Blades]([ProductCode], [DispName], [TechnologyCount]) VALUES
      (N'ENDP_GS_1070', N'Endpoint Security Common', 1) -- windows product
  END
GO
