IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GSRebuildTechnologyStatus_View]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[GSRebuildTechnologyStatus_View]
GO

CREATE PROCEDURE [dbo].[GSRebuildTechnologyStatus_View]
AS

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
		DROP VIEW [dbo].[AM_EndpointTechnologyStatus_View]

	DECLARE @sqlstring NVARCHAR(4000)

	SET @sqlstring = 'CREATE VIEW [dbo].[AM_EndpointTechnologyStatus_View] AS
			  SELECT * FROM GS_EndpointTechnologyStatus_View'

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	BEGIN
		SET @sqlstring = @sqlstring + ' UNION SELECT * FROM SP_EndpointTechnologyStatus_View'
	END

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	BEGIN
		SET @sqlstring = @sqlstring + ' UNION SELECT * FROM WP_EndpointTechnologyStatus_View'
	END

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FW_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	BEGIN
		SET @sqlstring = @sqlstring + ' UNION SELECT * FROM FW_EndpointTechnologyStatus_View'
	END

	EXEC (@sqlstring)

GO
