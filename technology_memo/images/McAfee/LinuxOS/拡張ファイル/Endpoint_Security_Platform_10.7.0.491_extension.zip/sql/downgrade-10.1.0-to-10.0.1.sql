if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPCertificate]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[EPCertificate]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPCertEvent]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[EPCertEvent]
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertificateMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    DROP TABLE [dbo].[EPCertificateMT]
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    DROP TABLE [dbo].[EPCertEventMT]
  END
GO

DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] in (N'ENDP_GS_1010')
GO
