-- upgrade-10.5.2

-- update GS_CustomProps view:  performance --
alter view [dbo].[GS_CustomProps] as
	select gs.*, pp.[ParentID] [LeafNodeID], pp.[ProductCode]
	from [GS_CustomPropsMT] gs
		inner join [EPOProductProperties_Fast] pp on gs.[ParentID] = pp.[AutoID]
    where gs.[TenantID] = convert(int, substring(CONTEXT_INFO(), 5, 4))
go

-- correct view permissions --
revoke select,insert,update,delete,references on [dbo].[GS_CustomProps] to [mcafeeSystem]
grant select,insert,update,delete on [dbo].[GS_CustomProps] to [mcafeeOps]
grant select,insert,update,delete on [dbo].[GS_CustomProps] to [mcafeeTenant]
go

-- update tech status: make it read only
alter view [dbo].[GS_EndpointTechnologyStatus_View] as
    select pp.[AutoIDSP] [AutoID], pp.[LeafNodeID], 5 [TechnologyType], pp.[IsSPEnabled] [Enabled], pp.[ProductCode]
    from [GS_CustomProps] pp with(nolock)
go

-- correct view permissions --
revoke select,insert,update,delete,references on [dbo].[GS_EndpointTechnologyStatus_View] to [mcafeeSystem]
grant select on [dbo].[GS_EndpointTechnologyStatus_View] to [mcafeeOps]
grant select on [dbo].[GS_EndpointTechnologyStatus_View] to [mcafeeTenant]
go

alter procedure [dbo].[GSRebuildTechnologyStatus_View] as
    if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
        drop view [dbo].[AM_EndpointTechnologyStatus_View]

    declare @sql varchar(4000) = 'create view [dbo].[AM_EndpointTechnologyStatus_View] as' +
            char(13) + char(9) + 'select * from [GS_EndpointTechnologyStatus_View] with(nolock)'

    if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
        set @sql = @sql + char(13) + char(9) + 'union select * from [SP_EndpointTechnologyStatus_View] with(nolock)'

    if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FW_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
        set @sql = @sql + char(13) + char(9) + 'union select * from [FW_EndpointTechnologyStatus_View] with(nolock)'

    if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
        set @sql = @sql + char(13) + char(9) + 'union select * from [WP_EndpointTechnologyStatus_View] with(nolock)'

    exec(@sql)

    grant select on [dbo].[AM_EndpointTechnologyStatus_View] to [mcafeeOps]
    grant select on [dbo].[AM_EndpointTechnologyStatus_View] to [mcafeeTenant]
go

-- rebuild 
exec [dbo].[GSRebuildTechnologyStatus_View]
go

-- remove unwanted indexes


IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_GS_CustomPropsMT_AutoIDSP' -- Index Name
                                                                                      AND so.[Name] = N'GS_CustomPropsMT')
    DROP INDEX IX_GS_CustomPropsMT_AutoIDSP ON GS_CustomPropsMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_GS_CustomPropsMT_SPbComplianceStatus' -- Index Name
                                                                                      AND so.[Name] = N'GS_CustomPropsMT')
    DROP INDEX IX_GS_CustomPropsMT_SPbComplianceStatus ON GS_CustomPropsMT;
GO
