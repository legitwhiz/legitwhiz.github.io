-- Make sure there is only one installed blade record
DELETE FROM [dbo].[EAMP.GSE.Blades]
WHERE [ProductCode] IN (N'ENDP_GS_1000', N'ENDP_GS_1000MACX', N'ENDP_GS_1010', N'ENDP_GS_1020', N'ENDP_GS_1050')
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
([ProductCode], [DispName], [TechnologyCount])
VALUES
  (N'ENDP_GS_1000', N'Endpoint Security Common', 1), -- windows product
  (N'ENDP_GS_1000MACX', N'Endpoint Security Common', 1),   -- mac product
  (N'ENDP_GS_1010', N'Endpoint Security Common', 1), -- windows product
  (N'ENDP_GS_1020', N'Endpoint Security Common', 1) -- windows product
GO

IF EXISTS (SELECT *
                FROM dbo.syscolumns
                WHERE id = object_id(N'[dbo].[GS_CustomPropsMT]') AND (name = 'IsTimeBasedPasswordEnabled'))
  BEGIN
    ALTER TABLE [dbo].[GS_CustomPropsMT]
      DROP CONSTRAINT [DF_GS_CustomPropsMT_IsTimeBasedPasswordEnabled]

    ALTER TABLE [dbo].[GS_CustomPropsMT]
      DROP COLUMN [IsTimeBasedPasswordEnabled]     
  END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GS_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[GS_CustomProps]
GO

if EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[ESPRegisteredInstallationStatus]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    DROP TABLE [dbo].[ESPRegisteredInstallationStatus]
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ESPSystemProductVersionInfo]'))
  BEGIN
    DROP VIEW[dbo].ESPSystemProductVersionInfo
  END
GO

--Registered Technology Status
if EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[ESPRegisteredTechnologyStatus]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    DROP TABLE [dbo].[ESPRegisteredTechnologyStatus]
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ESPEndPointSecurityTechnologyStatus]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[ESPEndPointSecurityTechnologyStatus]
  END
GO

IF exists(SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ESPTechnologyStatus]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW [dbo].[ESPTechnologyStatus]
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[ESPBuildTechnologyStatusView]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
  BEGIN
    DROP PROCEDURE [dbo].[ESPBuildTechnologyStatusView]
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[findClientUILockOutSystems]') AND OBJECTPROPERTY(id, N'IsTableFunction') = 1)
  BEGIN
    DROP FUNCTION [dbo].[findClientUILockOutSystems]
  END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ClientUICurrentLockOutStatus_View]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW [dbo].[ClientUICurrentLockOutStatus_View]
  END
GO
