------------------------------------------------------------------
--Copyright (c) 2018-2020 McAfee LLC. - All Rights Reserved
------------------------------------------------------------------
/*
10.7.0 Update - Steps for cloud upgrade
  Note depends on common SQL upgrade
*/

-- Add ATP to the view --
alter view [dbo].[EndpointInstallationStatus_View] as
  select  convert(nvarchar(20), vi.[autoId]) + N'_' + vi.[ProductFamily] [AutoId], vi.[autoId] [LeafNodeId],
          vi.[ProductVersion], vi.[FamilyDispName], vi.[ProductCode]
    from [EPOSystemProductVersionInfo_Fast] vi
    where
        vi.[ProductFamily] = N'THREATPREVENTION'
      or vi.[ProductFamily] = N'WEBCONTROL'
      or vi.[ProductFamily] = N'FIREWALL'
      or (vi.[ProductFamily] = N'TIEClientMETA' and vi.[FamilyDispName] = N'Endpoint Security Adaptive Threat Protection')
go