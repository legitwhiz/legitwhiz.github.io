-- Make sure there is only one installed blade record
DELETE FROM [dbo].[EAMP.GSE.Blades]
WHERE [ProductCode] IN (N'ENDP_GS_1000', N'ENDP_GS_1000MACX', N'ENDP_GS_1010', N'ENDP_GS_1020')
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
([ProductCode], [DispName], [TechnologyCount])
VALUES
  (N'ENDP_GS_1000', N'Endpoint Security Common', 1), -- windows product
  (N'ENDP_GS_1000MACX', N'Endpoint Security Common', 1),   -- mac product
  (N'ENDP_GS_1010', N'Endpoint Security Common', 1), -- windows product
  (N'ENDP_GS_1020', N'Endpoint Security Common', 1) -- windows product
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GSRebuildTechnologyStatus_View]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[GSRebuildTechnologyStatus_View]
GO

CREATE PROCEDURE [dbo].[GSRebuildTechnologyStatus_View]
AS

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
		DROP VIEW [dbo].[AM_EndpointTechnologyStatus_View]

	DECLARE @sqlstring NVARCHAR(4000)

	SET @sqlstring = 'CREATE VIEW [dbo].[AM_EndpointTechnologyStatus_View] AS
			  SELECT * FROM GS_EndpointTechnologyStatus_View'

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	BEGIN
		SET @sqlstring = @sqlstring + ' UNION SELECT * FROM SP_EndpointTechnologyStatus_View'
	END

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	BEGIN
		SET @sqlstring = @sqlstring + ' UNION SELECT * FROM WP_EndpointTechnologyStatus_View'
	END

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FW_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	BEGIN
		SET @sqlstring = @sqlstring + ' UNION SELECT * FROM FW_EndpointTechnologyStatus_View'
	END

	EXEC (@sqlstring)

      GRANT SELECT ON AM_EndpointTechnologyStatus_View To mcafeeTenant
      GRANT SELECT, INSERT, UPDATE, DELETE ON AM_EndpointTechnologyStatus_View To mcafeeSystem
GO

IF NOT EXISTS(SELECT * FROM dbo.syscolumns WHERE id = OBJECT_ID('[dbo].[EPCertificateMT]') AND (name = 'AutoId')) AND
	 EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[PK_EPCertificateMT]') AND OBJECTPROPERTY(id, N'IsPrimaryKey') = 1)
	BEGIN
		ALTER TABLE dbo.EPCertificateMT
		DROP CONSTRAINT PK_EPCertificateMT
	END
GO

IF NOT EXISTS(SELECT * FROM dbo.syscolumns WHERE id = OBJECT_ID('[dbo].[EPCertificateMT]') AND (name = 'AutoId')) AND
	 EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[DF_EPCertificateMT_TenantId]') AND OBJECTPROPERTY(id, N'IsDefaultCnst') = 1)
	BEGIN
		ALTER TABLE dbo.EPCertificateMT
		DROP CONSTRAINT DF_EPCertificateMT_TenantId
	END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertificateMT_Temp]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [dbo].[EPCertificateMT_Temp]
	END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertificateMT_Temp]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) AND
	 NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[DF_EPCertificateMT_AutoId]') AND OBJECTPROPERTY(id, N'IsDefaultCnst') = 1) AND
	 NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[DF_EPCertificateMT_TenantId]') AND OBJECTPROPERTY(id, N'IsDefaultCnst') = 1) AND
	 NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[PK_EPCertificateMT]') AND OBJECTPROPERTY(id, N'IsPrimaryKey') = 1)
	BEGIN
		CREATE TABLE [dbo].[EPCertificateMT_Temp](
			[AutoId] [uniqueidentifier] NOT NULL CONSTRAINT DF_EPCertificateMT_AutoId DEFAULT NEWSEQUENTIALID(),
			[TenantId] [int] NOT NULL CONSTRAINT [DF_EPCertificateMT_TenantId] DEFAULT dbo.FN_Core_GetContextTenantId(),
			[Vendor] [nvarchar](256) NULL,
			[Subject] [nvarchar](512) NULL,
			[Hash] [varchar](512) NULL,
			[Cert] [varchar](MAX) NULL,
			CONSTRAINT [PK_EPCertificateMT] PRIMARY KEY CLUSTERED
				(
					[AutoId] ASC
				)
		)
	END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertificateMT_Temp]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) AND
	 EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertificateMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		INSERT INTO EPCertificateMT_Temp ([TenantId], [Vendor], [Subject], [Hash], [Cert])
			SELECT [TenantId], [Vendor], [Subject], [Hash], [Cert]
			FROM EPCertificateMT
	END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertificateMT_Temp]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) AND
	 EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertificateMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [dbo].[EPCertificateMT]
	END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[EPCertificateMT_Temp]') AND OBJECTPROPERTY(id,N'IsUserTable') = 1)AND
	 NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertificateMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		EXEC sp_rename 'EPCertificateMT_Temp', 'EPCertificateMT', 'OBJECT'
	END
GO


--NOW CREATE THE VIEW FOR THE EPCertificateMT Table
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPCertificate]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[EPCertificate]
GO

CREATE VIEW [dbo].[EPCertificate] AS
	SELECT [AutoId], [TenantId], [Vendor], [Subject], [Hash], [Cert]
	FROM [dbo].[EPCertificateMT]
	WHERE [TenantId] IN (SELECT [TenantId] from FN_Core_GetContextTenancyInfo())
				OR EXISTS (SELECT [IsSystemUser] FROM FN_Core_GetContextTenancyInfo() WHERE IsSystemUser = 1)
GO

EXEC EPOCore_AddInsertTriggerToMTTable 'EPCertificate'
GO

EXEC EPOCore_AddUpdateTriggerToMTTable 'EPCertificate'
GO

EXEC EPOCore_AddDeleteTriggerToMTTable 'EPCertificate'
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT_Temp]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [dbo].[EPCertEventMT_Temp]
	END
GO

IF EXISTS(SELECT * FROM dbo.syscolumns WHERE id = OBJECT_ID('[dbo].[EPCertEventMT]') AND (name = 'Hash') AND ([length] = 40)) AND
	 EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[PK_EPCertEventMT]') AND OBJECTPROPERTY(id, N'IsPrimaryKey') = 1)
	BEGIN
		ALTER TABLE dbo.EPCertEventMT
		DROP CONSTRAINT PK_EPCertEventMT
	END
GO

IF EXISTS(SELECT * FROM dbo.syscolumns WHERE id = OBJECT_ID('[dbo].[EPCertEventMT]') AND (name = 'Hash') AND ([length] = 40)) AND
	 EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[DF_EPCertEventMT_TenantId]') AND OBJECTPROPERTY(id, N'IsDefaultCnst') = 1)
	BEGIN
		ALTER TABLE dbo.EPCertEventMT
		DROP CONSTRAINT DF_EPCertEventMT_TenantId
	END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT_Temp]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) AND
	 NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[PK_EPCertEventMT]') AND OBJECTPROPERTY(id, N'IsPrimaryKey') = 1)
	BEGIN
		-- If EPOEvents table has BIGINT column then create ParentID column as BIGINT
		IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'BIGINT' AND TABLE_NAME = 'EPOEventsMT' AND COLUMN_NAME = 'AutoID')
			BEGIN
				CREATE TABLE [dbo].[EPCertEventMT_Temp](
					[EventAutoID] [bigint] NOT NULL,
					[TenantId] [int] NOT NULL,
					[Vendor] [nvarchar](256) NULL,
					[Subject] [nvarchar](512) NULL,
					[Hash] [varchar](512) NULL,
					[Cert] [varchar](max) NULL,
					CONSTRAINT [PK_EPCertEventMT] PRIMARY KEY CLUSTERED
						(
							[EventAutoID] ASC
						)
				)
			END
		ELSE
			BEGIN
				CREATE TABLE [dbo].[EPCertEventMT_Temp](
					[EventAutoID] [int] NOT NULL,
					[TenantId] [int] NOT NULL,
					[Vendor] [nvarchar](256) NULL,
					[Subject] [nvarchar](512) NULL,
					[Hash] [varchar](512) NULL,
					[Cert] [varchar](max) NULL,
					CONSTRAINT [PK_EPCertEventMT] PRIMARY KEY CLUSTERED
						(
							[EventAutoID] ASC
						)
				)
			END
	END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT_Temp]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) AND
	 EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		INSERT INTO EPCertEventMT_Temp
			SELECT [EventAutoId], [TenantId], [Vendor], [Subject], [Hash], [Cert]
			FROM EPCertEventMT
	END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT_Temp]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) AND
	 EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [dbo].[EPCertEventMT]
	END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[EPCertEventMT_Temp]') AND OBJECTPROPERTY(id,N'IsUserTable') = 1) AND
	 NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		EXEC sp_rename 'EPCertEventMT_Temp', 'EPCertEventMT', 'OBJECT'
	END
GO

--EPCertEventMT TABLE
GRANT DELETE ON EPCertEventMT To mcafeeOps
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON EPCertEventMT To mcafeeSystem
GO
--temporary workaround for event insertion bug in EPO #913667
GRANT INSERT ON EPCertEventMT To mcafeeTenant
GO

IF NOT EXISTS(SELECT * FROM sysconstraints WHERE id=OBJECT_ID('EPCertEventMT') AND COL_NAME(id,colid)='TenantId' AND OBJECTPROPERTY(constid, N'IsDefaultCnst')=1)
	BEGIN
		ALTER TABLE [dbo].[EPCertEventMT]
		ADD CONSTRAINT [DF_EPCertEventMT_TenantId]
		DEFAULT dbo.FN_Core_GetContextTenantId() FOR TenantId
	END
GO


IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EPCertEventMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[EPCertEventMT]'))
	BEGIN
		ALTER TABLE [dbo].[EPCertEventMT]  WITH CHECK ADD
		CONSTRAINT [FK_EPCertEventMT_EPOEvents] FOREIGN KEY
			(
				[EventAutoID]
			)
		REFERENCES [dbo].[EPOEvents]
		(
			[AutoID]
		) ON DELETE CASCADE ON UPDATE NO ACTION
	END
GO

IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT_Insert]') AND objectproperty(id, N'IsTrigger') = 1)
	DROP TRIGGER [dbo].[EPCertEventMT_Insert]
GO

CREATE TRIGGER [dbo].[EPCertEventMT_Insert] ON [dbo].[EPCertEventMT] FOR INSERT AS
	MERGE INTO [dbo].[EPCertificateMT] WITH (HOLDLOCK) AS c
	USING [INSERTED] AS i
	ON (c.[TenantId] = i.[TenantId] AND c.[Cert] = i.[Cert])
	WHEN MATCHED AND LEN(i.Hash) > LEN(c.Hash) THEN
	UPDATE SET c.[Hash] = i.[Hash]
	WHEN NOT MATCHED BY TARGET THEN
	INSERT ([TenantId], [Vendor], [Subject], [Hash], [Cert])
		VALUES (i.[TenantId], i.[Vendor], i.[Subject], i.[Hash], i.[Cert]);
GO

--EPCertificate VIEW

GRANT SELECT ON [EPCertificate] To mcafeeOPS
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON EPCertificate To mcafeeTenant
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON EPCertificate To mcafeeSystem
GO
--EPCertificateMT TABLE
GRANT DELETE ON EPCertificateMT To mcafeeOps
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON EPCertificateMT To mcafeeSystem
GO
--temporary workaround for event insertion bug in EPO #913667
GRANT INSERT ON EPCertificateMT To mcafeeTenant
GO

IF NOT EXISTS(SELECT *
              FROM dbo.syscolumns
              WHERE id = OBJECT_ID('[dbo].[GS_CustomPropsMT]') AND (name = 'IsATPClientDebugLoggingEnabled'))
  BEGIN
    ALTER TABLE [dbo].[GS_CustomPropsMT]
    ADD [IsATPClientDebugLoggingEnabled] [bit] NULL CONSTRAINT DF_GS_CustomPropsMT_IsATPClientDebugLoggingEnabled DEFAULT ((0));
  END
GO

IF NOT EXISTS(SELECT *
              FROM dbo.syscolumns
              WHERE id = OBJECT_ID('[dbo].[GS_CustomPropsMT]') AND (name = 'ATPEventFilterlevel'))
  BEGIN
    ALTER TABLE [dbo].[GS_CustomPropsMT]
    ADD [ATPEventFilterlevel] [int] NULL;
  END
GO


-- Upgrade ENDP_GSE_EX 10.1.1 -> 10.2.0
--	EPCertificate changes to support NoSQL (aka HBase) changes
if object_id(N'EPSP_Insert_Certificate', N'P') is not null
  drop procedure [dbo].[EPSP_Insert_Certificate]
go

create procedure [dbo].[EPSP_Insert_Certificate]
    @tenantId int,
    @hash varchar(512),
    @vendor nvarchar(256) = null,
    @subject nvarchar(512) = null,
    @cert varchar(max) = null
as
  begin
    set nocount on;

    merge [dbo].[EPCertificateMT] dest
    using
      (
        select @tenantId, @hash, @vendor,@subject, @cert
      ) src ([TenantId], [Hash], [Vendor], [Subject], [Cert])
    on
      dest.[TenantId] = src.[TenantId]
      and dest.[Cert] = src.[Cert]
    WHEN MATCHED AND LEN(src.Hash) > LEN(dest.Hash) THEN
    UPDATE SET dest.[Hash] = src.[Hash]
    when not matched then
    insert([TenantId], [Hash], [Vendor], [Subject], [Cert])
      values(src.[TenantId], src.[Hash], src.[Vendor], src.[Subject], src.[Cert])
    ;
  end
go

grant execute on [dbo].[EPSP_Insert_Certificate] to mcafeeSystem
go