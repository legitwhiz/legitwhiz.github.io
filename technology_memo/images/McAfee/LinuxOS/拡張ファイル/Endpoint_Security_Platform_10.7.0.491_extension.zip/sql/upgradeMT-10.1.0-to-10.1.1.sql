-- Upgrade ENDP_GSE_EX 10.1.0 -> 10.1.1
--	EPCertificate changes to support NoSQL (aka HBase) changes
if object_id(N'EPSP_Insert_Certificate', N'P') is not null
	drop procedure [dbo].[EPSP_Insert_Certificate]
go

create procedure [dbo].[EPSP_Insert_Certificate]
	@tenantId int,
	@hash varchar(40),
	@vendor nvarchar(256) = null,
	@subject nvarchar(512) = null,
	@cert varchar(max) = null
as
begin
	set nocount on;

	merge [dbo].[EPCertificateMT] dest
	using
	(
		select @tenantId, @hash, @vendor,@subject, @cert
	) src ([TenantId], [Hash], [Vendor], [Subject], [Cert])
	on
		dest.[TenantId] = src.[TenantId]
		and dest.[Hash] = src.[Hash]
	when not matched then
		insert([TenantId], [Hash], [Vendor], [Subject], [Cert])
			values(src.[TenantId], src.[Hash], src.[Vendor], src.[Subject], src.[Cert])
	;
end
go

grant execute on [dbo].[EPSP_Insert_Certificate] to mcafeeSystem
go

-- Optimize Tenant Filtering --
/****** Object:  View [dbo].[EPExtendedEvent]  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPExtendedEvent]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[EPExtendedEvent]
GO

CREATE VIEW [dbo].[EPExtendedEvent] AS
	select TenantId, EventAutoID, Location, BladeName, AnalyzerTechnologyVersion, AnalyzerContentCreationDate, AnalyzerContentVersion, AMCoreContentVersion, AnalyzerRuleID, AnalyzerRuleName, AnalyzerRegInfo,
		AnalyzerGTIQuery, ThreatDetectedOnCreation, ThreatImpact, SourcePort, SourceShareName, SourceProcessHash, SourceProcessSigned, SourceProcessSigner, SourceParentProcessName,
		SourceParentProcessHash, SourceParentProcessSigned, SourceParentProcessSigner, SourceFilePath, SourceFileSize, SourceHash, SourceSigned, SourceSigner, SourceModifyTime, SourceAccessTime,
		SourceCreateTime, SourceDeviceDisplayName, SourceDeviceSerialNumber, SourceDeviceVID, SourceDevicePID, SourceDescription, SourceURLRatingCode, SourceURLWebCategory, TargetURL,
		TargetShareName, TargetHash, TargetSigned, TargetSigner, TargetParentProcessSigned, TargetParentProcessSigner, TargetParentProcessName, TargetParentProcessHash, TargetName, TargetPath,
		TargetFileSize, TargetModifyTime, TargetAccessTime, TargetCreateTime, TargetDeviceDisplayName, TargetDeviceSerialNumber, TargetDeviceVID, TargetDevicePID, TargetDescription, Cleanable, TaskName,
		APIName, FirstAttemptedAction, FirstActionStatus, SecondAttemptedAction, SecondActionStatus, Topic,
		CASE WHEN AttackVectorType IN (0, 1, 2, 3, 4, 5, 6, 7) then AttackVectorType ELSE 99 END AS AttackVectorType,
		AccessRequested, DurationBeforeDetection, NaturalLangDescription, Direction
	from EPExtendedEventMT
	where [TenantId] = convert(int, substring(context_info(), 5, 4))
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON [EPExtendedEvent] To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON [EPExtendedEvent] To mcafeeSystem
go


/****** Object:  View [dbo].[EPCertEvent]  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPCertEvent]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[EPCertEvent]
GO

CREATE VIEW [dbo].[EPCertEvent] AS
	select ce.[TenantId], ce.[EventAutoID], ce.[Hash], ce.[Vendor], ce.[Subject], ce.[Cert]
		from [dbo].[EPCertEventMT] ce
    	where ce.[TenantId] = convert(int, substring(context_info(), 5, 4))
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON [EPCertEvent] To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON [EPCertEvent] To mcafeeSystem
go

/****** Object:  View [dbo].[EPCertificate]   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPCertificate]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[EPCertificate]
GO

CREATE VIEW [dbo].[EPCertificate] AS
	select c.[TenantId], c.[Hash], c.[Vendor], c.[Subject], c.[Cert]
		from [dbo].[EPCertificateMT] c
		where c.[TenantId] = convert(int, substring(context_info(), 5, 4))
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON [EPCertificate] To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON [EPCertificate] To mcafeeSystem
go

/****** Object:  View [dbo].[GS_CustomProps] ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GS_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[GS_CustomProps]
GO

CREATE VIEW [dbo].[GS_CustomProps] AS
	select cp.*, ppv.[LeafNodeID]
		from [GS_CustomPropsMT] cp
			inner join [EPOProdPropsView_ENDPOINTSECURITYPLATFORM] ppv ON cp.[ParentID] = ppv.[ProductPropertiesID]
   		where cp.[TenantId] = convert(int, substring(context_info(), 5, 4))
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON [GS_CustomProps] To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON [GS_CustomProps] To mcafeeSystem
go

-- Fix entries in EAMP.GSE.Blades table, GS_1000 is no longer needed, and GS_1010 may have multiple entries --
delete from [dbo].[EAMP.GSE.Blades]
	where [ProductCode] in (N'ENDP_GS_1000', N'ENDP_GS_1010')
go

insert into [EAMP.GSE.Blades] ([ProductCode], [DispName], [TechnologyCount]) values
  (N'ENDP_GS_1010', N'Endpoint Security Common', 1)
go