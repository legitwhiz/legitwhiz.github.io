-- 10.0.1 Changes

-- Make sure there is only one installed blade record
DELETE FROM [dbo].[EAMP.GSE.Blades]
WHERE [ProductCode] IN (N'ENDP_GS_1000', N'ENDP_GS_1000MACX', N'ENDPM_GS1000')
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
([ProductCode], [DispName], [TechnologyCount])
VALUES
  (N'ENDP_GS_1000', N'Endpoint Security Common', 1), -- windows product
  (N'ENDP_GS_1000MACX', N'Endpoint Security Common', 1)   -- mac product
GO

---- Recreate the technology status VIEW, ProductCode column was added
-- Recreate all views, the AM Tech view can't be rebuilt until all views are updated.
-- Create view and Alter view must be the 1st statement in a batch, so use dynamic sql as workaround

-- GS View
IF exists(SELECT *
          FROM dbo.sysobjects
          WHERE id = object_id(N'[dbo].[GS_EndpointTechnologyStatus_View]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[GS_EndpointTechnologyStatus_View]
GO
CREATE VIEW [dbo].[GS_EndpointTechnologyStatus_View] AS
  SELECT
    [GS_CustomProps].AutoIDSP      AS AutoID,
    [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[LeafNodeID],
    5                              AS TechnologyType,
    [GS_CustomProps].[IsSPEnabled] AS Enabled,
    [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[ProductCode]
  FROM [GS_CustomProps]
    LEFT JOIN [EPOProdPropsView_ENDPOINTSECURITYPLATFORM]
      ON [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[ProductPropertiesID] = [GS_CustomProps].[ParentID]
GO

--GS_EndpointTechnologyStatus_View
GRANT SELECT ON GS_EndpointTechnologyStatus_View TO mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON GS_EndpointTechnologyStatus_View TO mcafeeSystem
GO

-- SP View
IF exists(SELECT *
          FROM dbo.sysobjects
          WHERE id = object_id(N'[dbo].[SP_EndpointTechnologyStatus_View]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DECLARE @sql VARCHAR(4000) =
    'ALTER VIEW [dbo].[SP_EndpointTechnologyStatus_View] AS
SELECT [AM_CustomProps].[AutoIDOAS] AS AutoID, [EPOProdPropsView_THREATPREVENTION].[LeafNodeID], 1 AS TechnologyType, [AM_CustomProps].[bOASEnabled] AS Enabled, [EPOProdPropsView_THREATPREVENTION].[ProductCode]
FROM  [AM_CustomProps]
LEFT JOIN [EPOProdPropsView_THREATPREVENTION] ON [EPOProdPropsView_THREATPREVENTION].[ProductPropertiesID] = [AM_CustomProps].[ParentID]
UNION
SELECT [AM_CustomProps].[AutoIDBO] AS AutoID, [EPOProdPropsView_THREATPREVENTION].[LeafNodeID], 2 AS TechnologyType, [AM_CustomProps].[bBOEnabled] AS Enabled, [EPOProdPropsView_THREATPREVENTION].[ProductCode]
FROM  [AM_CustomProps]
LEFT JOIN [EPOProdPropsView_THREATPREVENTION] ON [EPOProdPropsView_THREATPREVENTION].[ProductPropertiesID] = [AM_CustomProps].[ParentID]
WHERE [EPOProdPropsView_THREATPREVENTION].ProductCode <> ''ENDP_AM_1000MACX''
UNION
SELECT [AM_CustomProps].[AutoIDAP] AS AutoID, [EPOProdPropsView_THREATPREVENTION].[LeafNodeID], 3 AS TechnologyType, [AM_CustomProps].[bAPEnabled] AS Enabled, [EPOProdPropsView_THREATPREVENTION].[ProductCode]
FROM  [AM_CustomProps]
LEFT JOIN [EPOProdPropsView_THREATPREVENTION] ON [EPOProdPropsView_THREATPREVENTION].[ProductPropertiesID] = [AM_CustomProps].[ParentID]
WHERE [EPOProdPropsView_THREATPREVENTION].ProductCode <> ''ENDP_AM_1000MACX''
UNION
SELECT [AM_CustomProps].[AutoIDSS] AS AutoID, [EPOProdPropsView_THREATPREVENTION].[LeafNodeID], 4 AS TechnologyType, [AM_CustomProps].[bScriptScanEnabled] AS Enabled, [EPOProdPropsView_THREATPREVENTION].[ProductCode]
FROM  [AM_CustomProps]
LEFT JOIN [EPOProdPropsView_THREATPREVENTION] ON [EPOProdPropsView_THREATPREVENTION].[ProductPropertiesID] = [AM_CustomProps].[ParentID]
WHERE [EPOProdPropsView_THREATPREVENTION].ProductCode <> ''ENDP_AM_1000MACX'''
    EXEC (@sql)
  END
GO

-- FW View
IF EXISTS(SELECT 1
          FROM dbo.sysobjects
          WHERE id = object_id(N'[dbo].[FW_EndpointTechnologyStatus_View]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DECLARE @sql VARCHAR(4000) =
    'ALTER VIEW [dbo].[FW_EndpointTechnologyStatus_View]
    AS
    SELECT
        fw.[AutoIDSP]   AS AutoID
    ,   pp.[LeafNodeID] AS LeafNodeID
    ,   6               AS TechnologyType
    ,   fw.[FWStatus]   AS Enabled
    ,   pp.[ProductCode]
    FROM    [FW_CustomProps]    fw
    LEFT JOIN   [EPOProdPropsView_FIREWALL] pp  ON  pp.[ProductPropertiesID] = fw.[ParentID]'
    EXEC (@sql)
  END
GO

-- WP View
IF exists(SELECT *
          FROM dbo.sysobjects
          WHERE id = object_id(N'[dbo].[WP_EndpointTechnologyStatus_View]') AND OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DECLARE @sql VARCHAR(4000) =
    'ALTER VIEW [dbo].[WP_EndpointTechnologyStatus_View] AS
    SELECT [WP_CustomProps].[AutoIDWP] AS AutoID, [EPOProdPropsView_WEBCONTROL].[LeafNodeID], 7 AS TechnologyType, [WP_CustomProps].[bWPEnabled] AS Enabled, [EPOProdPropsView_WEBCONTROL].[ProductCode]
    FROM  [WP_CustomProps]
    LEFT JOIN [EPOProdPropsView_WEBCONTROL] ON [EPOProdPropsView_WEBCONTROL].[ProductPropertiesID] = [WP_CustomProps].[ParentID]'
    EXEC (@sql)
  END
GO

---- Rebuild the AM Tech status view
EXEC [dbo].[GSRebuildTechnologyStatus_View]

--AM_EndpointTechnologyStatus_View
GRANT SELECT ON AM_EndpointTechnologyStatus_View TO mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON AM_EndpointTechnologyStatus_View TO mcafeeSystem
GO
