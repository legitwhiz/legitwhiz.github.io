IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    -- If EPOEvents table has BIGINT column then create ParentID column as BIGINT
    IF	EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'BIGINT' AND TABLE_NAME = 'EPOEventsMT' AND COLUMN_NAME = 'AutoID')
      BEGIN
        CREATE TABLE [dbo].[EPCertEventMT](
          [EventAutoID] [bigint] NOT NULL,
          [Vendor] [nvarchar](256) NULL,
          [Subject] [nvarchar](512) NULL,
          [Hash] [varchar](40) NULL,
          [Cert] [varchar](MAX) NULL,
          CONSTRAINT [PK_EPCertEventMT] PRIMARY KEY CLUSTERED
            (
              [EventAutoID] ASC
            )
        )
      END
    ELSE
      BEGIN
        CREATE TABLE [dbo].[EPCertEventMT](
          [EventAutoID] [int] NOT NULL,
          [Vendor] [nvarchar](256) NULL,
          [Subject] [nvarchar](512) NULL,
          [Hash] [varchar](40) NULL,
          [Cert] [varchar](MAX) NULL,
          CONSTRAINT [PK_EPCertEventMT] PRIMARY KEY CLUSTERED
            (
              [EventAutoID] ASC
            )
        )
      END
  END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EPCertEventMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[EPCertEventMT]'))
  BEGIN
    ALTER TABLE [dbo].[EPCertEventMT]  WITH CHECK ADD
    CONSTRAINT [FK_EPCertEventMT_EPOEvents] FOREIGN KEY
      (
        [EventAutoID]
      )
    REFERENCES [dbo].[EPOEvents]
    (
      [AutoID]
    ) ON DELETE CASCADE ON UPDATE NO ACTION
  END
GO

--NOW CREATE THE VIEW FOR THE EPCertEventMT Table
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPCertEvent]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[EPCertEvent]
GO

CREATE VIEW [dbo].[EPCertEvent] AS
  SELECT [EventAutoID], [Vendor], [Subject], [Hash], [Cert]
  FROM [EPCertEventMT]
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertificateMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  BEGIN
    CREATE TABLE [dbo].[EPCertificateMT](
      [Vendor] [nvarchar](256) NULL,
      [Subject] [nvarchar](512) NULL,
      [Hash] [varchar](40) NOT NULL,
      [Cert] [varchar](MAX) NULL,
      CONSTRAINT [PK_EPCertificateMT] PRIMARY KEY CLUSTERED
        (
          [Hash] ASC
        )
    )
  END
GO

--NOW CREATE THE VIEW FOR THE EPCertificateMT Table
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPCertificate]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[EPCertificate]
GO

CREATE VIEW [dbo].[EPCertificate] AS
  SELECT [Vendor], [Subject], [Hash], [Cert]
  FROM [dbo].[EPCertificateMT]
GO

IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertEventMT_Insert]') AND objectproperty(id, N'IsTrigger') = 1)
  DROP TRIGGER [dbo].[EPCertEventMT_Insert]
GO

CREATE TRIGGER [dbo].[EPCertEventMT_Insert] ON [dbo].[EPCertEventMT] FOR INSERT AS
  INSERT INTO [dbo].[EPCertificateMT] ([Vendor], [Subject], [Hash], [Cert])
  SELECT [i].[Vendor], [i].[Subject], [i].[Hash], [i].[Cert]
  FROM [INSERTED] as [i]
  LEFT JOIN [dbo].[EPCertificateMT] AS [c] ON ([i].[Hash] = [c].[Hash])
  WHERE [c].[Hash] IS NULL
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GS_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[GS_CustomProps]
GO
CREATE VIEW [dbo].[GS_CustomProps] AS
  SELECT [GS_CustomPropsMT].*, [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[LeafNodeID]
  FROM [GS_CustomPropsMT]
    INNER JOIN [EPOProdPropsView_ENDPOINTSECURITYPLATFORM] ON [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[ProductPropertiesID] = [GS_CustomPropsMT].[ParentID]
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
([ProductCode], [DispName], [TechnologyCount])
VALUES
  (N'ENDP_GS_1010', N'Endpoint Security Common', 1)
GO
if exists (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_NAME = 'EPExtendedEventMT' AND COLUMN_NAME = 'AccessRequested'
             AND DATA_TYPE = 'nvarchar' AND CHARACTER_MAXIMUM_LENGTH = 70)
    ALTER TABLE EPExtendedEventMT
        ALTER COLUMN AccessRequested NVARCHAR(512)
GO
