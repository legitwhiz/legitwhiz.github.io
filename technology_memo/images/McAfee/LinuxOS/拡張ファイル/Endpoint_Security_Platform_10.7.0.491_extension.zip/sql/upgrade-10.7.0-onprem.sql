------------------------------------------------------------------
--Copyright (c) 2018-2020 McAfee LLC. - All Rights Reserved
------------------------------------------------------------------
/*
10.7.0 Update - Steps for on-prem upgrade
  Note depends on common SQL upgrade
*/

-- Add ATP to the view --
alter view [dbo].[EndpointInstallationStatus_View] as
  select  convert(nvarchar(20), vi.[autoId]) + N'_' + vi.[ProductFamily] [AutoId], vi.[autoId] [LeafNodeId],
          vi.[ProductVersion], vi.[FamilyDispName], vi.[ProductCode]
    from [EPOSystemProductVersionInfo] vi
    where
        vi.[ProductFamily] = N'THREATPREVENTION'
      or vi.[ProductFamily] = N'WEBCONTROL'
      or vi.[ProductFamily] = N'FIREWALL'
      or (vi.[ProductFamily] = N'TIEClientMETA' and vi.[FamilyDispName] = N'Endpoint Security Adaptive Threat Protection')
go

-- Update ESPRollup_EPExtendedEvent table --
if exists(select 1 from dbo.sysobjects where [id] = object_id(N'[dbo].[ESPRollup_EPExtendedEvent]') AND OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
  -- SourceDescription --
  IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'ESPRollup_EPExtendedEvent' AND COLUMN_NAME = 'SourceDescription' AND CHARACTER_MAXIMUM_LENGTH < 512)
  BEGIN
    ALTER TABLE [dbo].[ESPRollup_EPExtendedEvent]
      ALTER COLUMN [SourceDescription] [nvarchar](512) NULL;
  END

  -- update SourceShareName --
  if exists(select 1 from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'ESPRollup_EPExtendedEvent' AND [COLUMN_NAME] = N'SourceShareName' AND [CHARACTER_MAXIMUM_LENGTH] < 260)
  begin
    alter table [dbo].[ESPRollup_EPExtendedEvent]
      alter column [SourceShareName] nvarchar(260) null
  end

  -- TargetName --
  IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'ESPRollup_EPExtendedEvent' AND COLUMN_NAME = 'TargetPath' AND CHARACTER_MAXIMUM_LENGTH < 512)
  BEGIN
    ALTER TABLE [dbo].[ESPRollup_EPExtendedEvent]
      ALTER COLUMN [TargetPath] [nvarchar](512) NULL;
  END

  -- refresh the rollup view definition --
  EXEC sp_refreshview 'ESPRollup_EPExtendedEvent_Source';
end
go

-- GS_CustomProps rollup target --
if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ESPRollup_GS_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
  -- create IsODSScannedFileLoggingEnabled column
  if not exists(select 1 from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = N'ESPRollup_GS_CustomProps' and COLUMN_NAME = N'IsODSScannedFileLoggingEnabled')
  begin
    alter table [dbo].[ESPRollup_GS_CustomProps]
      add [IsODSScannedFileLoggingEnabled] bit null
  end
  ;
end
go
