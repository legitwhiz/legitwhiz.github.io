-- Adding 10.6.0 Linux Product id
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_GS_1060LYNX'
if not exists(select [ProductCode] from [EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_GS_1060LYNX')
begin
	INSERT INTO [dbo].[EAMP.GSE.Blades]
	  ([ProductCode],
	  [DispName],
	  [TechnologyCount])
	  VALUES (
	  N'ENDP_GS_1060LYNX',
	  N'Endpoint Security Common',
	  1
	)
end
GO