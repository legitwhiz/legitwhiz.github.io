-- Make sure there is only one installed blade record
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] in (N'ENDP_GS_1000', N'ENDP_GS_1000MACX', N'ENDPM_GS1000')
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
  ([ProductCode], [DispName], [TechnologyCount])
VALUES
  ('ENDP_GS_1000', 'Endpoint Security Common', 1)
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GS_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[GS_EndpointTechnologyStatus_View]
GO
CREATE VIEW [dbo].[GS_EndpointTechnologyStatus_View] AS
  SELECT [GS_CustomProps].AutoIDSP AS AutoID, [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[LeafNodeID], 5 AS TechnologyType, [GS_CustomProps].[IsSPEnabled] AS Enabled
  FROM  [GS_CustomProps]
    LEFT JOIN [EPOProdPropsView_ENDPOINTSECURITYPLATFORM] ON [EPOProdPropsView_ENDPOINTSECURITYPLATFORM].[ProductPropertiesID] = [GS_CustomProps].[ParentID]
GO

GRANT SELECT ON GS_EndpointTechnologyStatus_View TO mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON GS_EndpointTechnologyStatus_View TO mcafeeSystem
GO
