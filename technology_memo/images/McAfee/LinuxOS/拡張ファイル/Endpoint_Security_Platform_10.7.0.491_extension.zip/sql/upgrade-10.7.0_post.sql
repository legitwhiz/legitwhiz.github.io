------------------------------------------------------------------
--Copyright (c) 2020 McAfee LLC. - All Rights Reserved
------------------------------------------------------------------
/*
10.7.0 - Common steps for cloud and on-prem post_upgrade
*/

-- insert 10.7.0 product technology data
IF NOT EXISTS(SELECT 1 FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_GS_1070')
  BEGIN
    INSERT INTO [dbo].[EAMP.GSE.Blades]([ProductCode], [DispName], [TechnologyCount]) VALUES
      (N'ENDP_GS_1070', N'Endpoint Security Common', 1) -- windows product
  END
GO
