-- Make sure there is only one installed blade record
DELETE FROM [dbo].[EAMP.GSE.Blades]
WHERE [ProductCode] IN (N'ENDP_GS_1000', N'ENDP_GS_1000MACX', N'ENDP_GS_1010', N'ENDP_GS_1020')
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
([ProductCode], [DispName], [TechnologyCount])
VALUES
  (N'ENDP_GS_1000', N'Endpoint Security Common', 1), -- windows product
  (N'ENDP_GS_1000MACX', N'Endpoint Security Common', 1),   -- mac product
  (N'ENDP_GS_1010', N'Endpoint Security Common', 1) -- windows product
GO


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GSRebuildTechnologyStatus_View]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[GSRebuildTechnologyStatus_View]
GO

CREATE PROCEDURE [dbo].[GSRebuildTechnologyStatus_View]
AS

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
		DROP VIEW [dbo].[AM_EndpointTechnologyStatus_View]

	DECLARE @sqlstring NVARCHAR(4000)

	SET @sqlstring = 'CREATE VIEW [dbo].[AM_EndpointTechnologyStatus_View] AS
			  SELECT * FROM GS_EndpointTechnologyStatus_View'

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	BEGIN
		SET @sqlstring = @sqlstring + ' UNION SELECT * FROM SP_EndpointTechnologyStatus_View'
	END

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	BEGIN
		SET @sqlstring = @sqlstring + ' UNION SELECT * FROM WP_EndpointTechnologyStatus_View'
	END

	IF exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FW_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	BEGIN
		SET @sqlstring = @sqlstring + ' UNION SELECT * FROM FW_EndpointTechnologyStatus_View'
	END

	EXEC (@sqlstring)

GO

IF EXISTS(SELECT *
          FROM dbo.syscolumns
          WHERE id = OBJECT_ID('[dbo].[GS_CustomPropsMT]') AND (name = 'IsATPClientDebugLoggingEnabled'))
  BEGIN
    ALTER TABLE [dbo].[GS_CustomPropsMT]
    DROP CONSTRAINT DF_GS_CustomPropsMT_IsATPClientDebugLoggingEnabled;
    ALTER TABLE [dbo].[GS_CustomPropsMT]
    DROP COLUMN [IsATPClientDebugLoggingEnabled]
  END
GO

IF EXISTS(SELECT *
          FROM dbo.syscolumns
          WHERE id = OBJECT_ID('[dbo].[GS_CustomPropsMT]') AND (name = 'ATPEventFilterlevel'))
  BEGIN
    ALTER TABLE [dbo].[GS_CustomPropsMT]
    DROP COLUMN [ATPEventFilterlevel];
  END
GO