IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[EPCertificateMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  IF NOT EXISTS(SELECT 1 FROM sys.columns WHERE Name = N'EpoCert' AND Object_ID = Object_ID(N'[dbo].[EPCertificateMT]'))
  BEGIN
    ALTER TABLE [dbo].[EPCertificateMT] ADD
      [EpoCert] [varchar](MAX) NULL
  END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[EPCertificate]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[EPCertificate]
GO

CREATE VIEW [dbo].[EPCertificate] AS
  SELECT [AutoId], [Vendor], [Subject], [Hash], [Cert], [EpoCert]
  FROM [dbo].[EPCertificateMT]
GO
