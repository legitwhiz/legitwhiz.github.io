
-- Rebuild props view, since column(s) were added --
alter view [dbo].[GS_CustomProps] as
select gs.*, pp.[ParentID] [LeafNodeID], pp.[ProductCode]
from [GS_CustomPropsMT] gs
  inner join [EPOProductProperties_Fast] pp on gs.[ParentID] = pp.[AutoID]
where gs.[TenantID] = convert(int, substring(CONTEXT_INFO(), 5, 4))
go
