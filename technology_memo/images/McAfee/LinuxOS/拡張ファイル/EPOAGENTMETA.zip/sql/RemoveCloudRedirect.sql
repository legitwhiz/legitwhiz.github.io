IF EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[MA_CloudRedirectData]')
    AND type in (N'U')
)
BEGIN
	DROP TABLE [dbo].[MA_CloudRedirectData]
END

IF  EXISTS
(
    SELECT * FROM dbo.sysobjects
    WHERE id = OBJECT_ID(N'[dbo].[MA_PopulateCloudRedirect]')
    AND OBJECTPROPERTY(id,N'IsProcedure') = 1
)
BEGIN
    DROP PROCEDURE [dbo].[MA_PopulateCloudRedirect]
END