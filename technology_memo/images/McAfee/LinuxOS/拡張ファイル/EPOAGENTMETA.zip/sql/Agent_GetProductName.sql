IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[Agent_GetProductName]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[Agent_GetProductName]
GO
CREATE PROCEDURE [dbo].[Agent_GetProductName]
(
	@ProdID nvarchar(50),
	@LangID nvarchar(20)
)

AS
BEGIN
	-- squelch client callbacks
	declare @SoftwareName nvarchar(255);
	
	-- try with EPOSoftware
	SELECT @SoftwareName = SoftwareName FROM EPOSoftware WHERE EPOSoftware.ProductCode = @ProdID and Language = @LangID;
	
	if (@SoftwareName is NOT NULL)
		begin
			SELECT SoftwareName FROM EPOSoftware WHERE EPOSoftware.ProductCode = @ProdID and Language = @LangID;
	
		end 
	else
		begin
			SELECT @SoftwareName = SoftwareName FROM EPOSoftware WHERE EPOSoftware.ProductCode = @ProdID and Language = '0409';
			if (@SoftwareName is NOT NULL)
			begin
				SELECT SoftwareName FROM EPOSoftware WHERE EPOSoftware.ProductCode = @ProdID and Language = '0409';
			end 
			else -- try EPOMetaTable
			begin
				
				SELECT @SoftwareName = SoftwareName FROM EPOSoftware,EPOMetaSoftware WHERE EPOMetaSoftware.ProductCode = @ProdID and Language = @LangID AND EPOSoftware.ProductCode=EPOMetaSoftware.MetaProductID;
				if (@SoftwareName is NULL)
				begin
					SELECT SoftwareName FROM EPOSoftware,EPOMetaSoftware WHERE EPOMetaSoftware.ProductCode  = @ProdID and Language = '0409' AND EPOSoftware.ProductCode=EPOMetaSoftware.MetaProductID;
					
				end
				else
				begin
					SELECT SoftwareName FROM EPOSoftware,EPOMetaSoftware WHERE EPOMetaSoftware.ProductCode = @ProdID and Language = @LangID AND EPOSoftware.ProductCode=EPOMetaSoftware.MetaProductID;
				
				end
			end 
		end
	RETURN @@ERROR;
END
