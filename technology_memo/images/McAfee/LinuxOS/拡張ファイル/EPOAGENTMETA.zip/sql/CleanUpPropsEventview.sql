



IF OBJECT_ID('MAPropsCollectionEvents') IS NOT NULL
BEGIN
	DROP VIEW MAPropsCollectionEvents
END
GO