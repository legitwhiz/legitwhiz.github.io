-- Deleting the migrated stuff for Agent, this will be updated in the real CMA extension

DELETE FROM EPOSoftware WHERE     (ProductCode = 'EPOAGENT3000')

DELETE FROM EPOSoftware WHERE     (ProductCode = 'EPOAGENT3700LYNX')

DELETE FROM EPOSoftware WHERE     (ProductCode = 'EPOAGENT3700MACX')

DELETE FROM EPOSoftware WHERE     (ProductCode = 'EPOAGENT3700WSHD')

DELETE FROM EPOSoftware WHERE     (ProductCode = 'EPOAGENT3700SLRS')

DELETE FROM EPOSoftware WHERE     (ProductCode = 'EPOAGENT4000HPUX')

DELETE FROM EPOSoftware WHERE     (ProductCode = 'EPOAGENT4000AIXX')



