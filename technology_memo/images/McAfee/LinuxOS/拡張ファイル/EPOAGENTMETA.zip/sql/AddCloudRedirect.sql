IF NOT EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[MA_CloudRedirectData]')
    AND type in (N'U')
)
BEGIN
	CREATE TABLE [dbo].[MA_CloudRedirectData]
	(
		[DataKey]				    [nvarchar](20) NOT NULL ,
		[Content]					  [nvarchar](MAX) NOT NULL,
		CONSTRAINT [PK_MA_CloudRedirectData]					PRIMARY KEY ([DataKey])
	)
END