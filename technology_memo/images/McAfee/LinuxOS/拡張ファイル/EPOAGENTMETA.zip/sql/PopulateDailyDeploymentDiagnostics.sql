IF EXISTS (SELECT * from dbo.sysobjects where id = object_id(N'[dbo].[MA_PopulateDailyAgentDiagnostic]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[MA_PopulateDailyAgentDiagnostic]
END
GO

CREATE PROCEDURE [dbo].[MA_PopulateDailyAgentDiagnostic]
(
	@Adhoc bit = 0
)
AS
BEGIN
SET NOCOUNT ON;

	DECLARE 
		@ReportDate DATE	= (SELECT MAX(RowDate) FROM [dbo].[MA_DailyDeploymentEvents] WITH (NOLOCK) WHERE RowDate < CAST(GETUTCDATE() AS date));

	IF @Adhoc = 1
		SELECT	@ReportDate = GETUTCDATE();

	SELECT DISTINCT
		RowDate,
		AgentGuid,
		DiagnosticType,
		CASE WHEN DiagnosticType IN (1,2) THEN 0.5 ELSE 2 END AS Weigh
	INTO #DiagnosticWeigh
	FROM MA_DailyDeploymentEvents
	WHERE RowDate = @ReportDate;

	SELECT 
		RowDate,
		AgentGuid,
		SUM(Weigh) AS Weigh
	INTO #DiagnosticWeighSum
	FROM #DiagnosticWeigh
	GROUP BY RowDate, AgentGuid;

	SELECT 
		A.RowDate,
		A.AgentGuid,
		CASE WHEN B.Weigh = 0.5 AND DiagnosticType IN (1,2) THEN DiagnosticType
		WHEN B.Weigh = 1 AND DiagnosticType IN (1,2) THEN DiagnosticType
		WHEN B.Weigh = 2 AND DiagnosticType IN (4,5) THEN DiagnosticType
		WHEN B.Weigh = 2.5 AND DiagnosticType IN (1,2) THEN DiagnosticType
		WHEN B.Weigh = 3 AND DiagnosticType IN (1,2) THEN DiagnosticType
		WHEN B.Weigh = 4 AND DiagnosticType IN (4,5) THEN DiagnosticType
		WHEN B.Weigh = 4.5 AND DiagnosticType IN (1,2) THEN DiagnosticType
		WHEN B.Weigh = 5 AND DiagnosticType IN (1,2) THEN DiagnosticType END  AS DiagnosticType

	INTO #FinalDiagnosticType
	FROM #DiagnosticWeigh A JOIN #DiagnosticWeighSum B
	ON A.AgentGuid = B.AgentGuid;


	INSERT [dbo].[MA_DailyDeploymentDiagnostics] 
	(
		RowDate,
		DiagnosticType,
		NodeCount
	)

	SELECT  RowDate, DiagnosticType, COUNT(distinct AgentGuid) NodeCount
	FROM #FinalDiagnosticType
	WHERE DiagnosticType IS NOT NULL
	GROUP BY RowDate, DiagnosticType;

	DROP TABLE #DiagnosticWeigh, #DiagnosticWeighSum, #FinalDiagnosticType;
	
	/* Purge System Diagnostic Table */
	DELETE dbo.MA_DailyDeploymentEvents
	WHERE RowDate < DATEADD(dd,-30,GETUTCDATE());
END
