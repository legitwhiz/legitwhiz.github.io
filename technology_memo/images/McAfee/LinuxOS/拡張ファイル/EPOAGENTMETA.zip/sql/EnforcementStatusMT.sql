 SET ANSI_NULLS ON
 GO

 SET QUOTED_IDENTIFIER ON
 GO

 IF EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = OBJECT_ID(N'[dbo].[FK_MAEnforcementStatus_EPOProductProperties]') AND type = 'F')
 	ALTER TABLE [dbo].[MAEnforcementStatus] DROP CONSTRAINT [FK_MAEnforcementStatus_EPOProductProperties]
 GO

 IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[MAEnforcementStatusView]'))
     DROP VIEW [dbo].[MAEnforcementStatusView]
 GO

 IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[MAEnforcementStatus]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
 BEGIN

 CREATE TABLE [dbo].[MAEnforcementStatus](
 	[id]             [int] IDENTITY(1,1) NOT NULL,
 	[parentid]       [int] NOT NULL,
 	[pestatus]       [int] NULL,
 	[pcstatus]       [int] NULL
   CONSTRAINT [PK_MAEnforcementStatus] PRIMARY KEY CLUSTERED
    (
      [id] ASC
    )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

 ) ON [PRIMARY]

 END
 GO

 ALTER TABLE [dbo].[MAEnforcementStatus] ADD
 	CONSTRAINT [FK_MAEnforcementStatus_EPOProductProperties] FOREIGN KEY
 	(
 		[parentid]
 	) REFERENCES [dbo].[EPOProductPropertiesMT] (
 		[AutoID]
 	) ON DELETE CASCADE ON UPDATE NO ACTION
 GO

 CREATE VIEW [dbo].[MAEnforcementStatusView] AS
     SELECT ProdProps.ParentID as LeafNodeID, MAES.id, MAES.parentid, MAES.pestatus,MAES.pcstatus
     FROM [dbo].[EPOProductPropertiesMT] AS ProdProps
     JOIN [dbo].[MAEnforcementStatus] as MAES ON ProdProps.AutoID=MAES.parentid
 GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[MAEnforcementStatus]') AND name = N'IX_MAEnforcementStatus_ParentID')
	CREATE INDEX [IX_MAEnforcementStatus_ParentID] ON [dbo].[MAEnforcementStatus] ([ParentID] ASC);
GO
