
IF NOT EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[MA_TelemetryExtensionDataTable]')
    AND type in (N'U')
)
BEGIN
    CREATE TABLE [dbo].[MA_TelemetryExtensionDataTable]
    (
        [ProductId] [nvarchar](50) NOT NULL,
        [JsonData] [nvarchar] (MAX) NOT NULL,
        CONSTRAINT [PK_MA_TelemetryExtensionDataTable]	PRIMARY KEY ([ProductId])
    )
END


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddPPExtensionTelemetryData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	drop procedure [dbo].[AddPPExtensionTelemetryData]
END
GO

CREATE PROCEDURE [dbo].[AddPPExtensionTelemetryData]
  @ProductId [nvarchar](50),
  @JsonData [nvarchar] (MAX)

AS
BEGIN
IF EXISTS (SELECT * FROM [dbo].[MA_TelemetryExtensionDataTable]
				WHERE ProductId = @ProductId )
	BEGIN
		UPDATE [dbo].[MA_TelemetryExtensionDataTable]
		Set
			JsonData = @JsonData
		WHERE ProductId = @ProductId
	END
ELSE
	BEGIN
		INSERT INTO [dbo].[MA_TelemetryExtensionDataTable]
		([ProductId], [JsonData])
		VALUES (@ProductId, @JsonData)
	END
END
