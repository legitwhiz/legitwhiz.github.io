-- ClouudDisableAHGroupFromDefaultRepoPolicy

EXEC EPOCore_DropStoredProc N'MAEX_REPO_POL_DISABLE_AH_GROUP';
GO

CREATE PROCEDURE MAEX_REPO_POL_DISABLE_AH_GROUP
AS

BEGIN

        DECLARE @PolicySettingId int;
        DECLARE @GroupName nvarchar(255)

        -- VERIFY THAT THINGS EXISTS AND WE HAVE THE PolicySettingID and GroupName
        SELECT @PolicySettingId =	ps.PolicySettingsID
                                    FROM EPOPolicySettings ps
                                        INNER JOIN EPOPolicyObjectToSettingsMT pots ON pots.PolicySettingsID = ps.PolicySettingsID
                                        INNER JOIN EPOPolicyObjectsMT po ON po.PolicyObjectID = pots.PolicyObjectID
                                        INNER JOIN EPOPolicyTypes pt ON ps.TypeID = pt.TypeID
                                    WHERE
                                        pt.FeatureTextID = 'EPOAGENTMETA'
                                    and pt.CategoryTextID = 'Repository'
                                    and pt.TypeTextID = 'Repository'
                                    and ps.Name = 'McAfee Default'
                                    and po.Name = 'McAfee Default'

        IF (@PolicySettingId is null) return;
        --print 'Psid ' + cast(@PolicySettingId as varchar(50))

        SELECT @GroupName =  ((SELECT TOP(1) name FROM EPOAgentHandlerGroup WHERE LoadBalancerSet=1
                                                                              and Enabled = 1))

        IF (@GroupName IS NULL) RETURN;
        --print 'group ' + @groupName

        -- ALL GOOD START
        IF exists (  SELECT psv.PolicySettingValuesID
                     FROM EPOPolicySettingValuesMT psv
                        WHERE psv.PolicySettingsID = @PolicySettingId
                         and  psv.SectionName = 'InetManager'
                         and  psv.SettingName = 'DisabledSiteNum')

            UPDATE EPOPolicySettingValuesMT SET SettingValue = 1
            WHERE	 PolicySettingsID = @PolicySettingId
                AND  SectionName = 'InetManager'
                AND  SettingName = 'DisabledSiteNum';

        ELSE
           INSERT INTO EPOPolicySettingValuesMT
                           (PolicySettingsID,	SectionName,   SettingName,			SettingValue)
                    VALUES (@PolicySettingId,  'InetManager', 'DisabledSiteNum',	1 )


        DELETE EPOPolicySettingValuesMT
        WHERE SettingName like '%DisabledSites%'
            and SectionName = 'InetManager'
            and PolicySettingsID = @PolicySettingId


        INSERT INTO EPOPolicySettingVALUES (PolicySettingsID, SectionName, SettingName, SettingValue, LastUpdate)
                            VALUES ( @PolicySettingId, 'InetManager', 'DisabledSites_0', @GroupName, GETUTCDATE() )

END

