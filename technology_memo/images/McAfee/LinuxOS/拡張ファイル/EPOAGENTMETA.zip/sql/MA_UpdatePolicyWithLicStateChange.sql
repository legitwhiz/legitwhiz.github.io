/* This SP does the
1. Parse the XML and fetch the tenant id and product code along with over use bit
2. Fetch the policy type for the given tenant of type "PPLicense"
3. Get the policy Object ID. If not available create one of type 'PP license'. Always make sure that it is editable, if not update the flag
4. Get the policy Settings ID
5. Get the policy Setting value and make the Setting value for PPLicense+(ProductCode) => to Overuse
*/

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MA_UpdatePolicyWithLicStateChange]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[MA_UpdatePolicyWithLicStateChange]
END
GO


CREATE PROCEDURE [dbo].MA_UpdatePolicyWithLicStateChange(
	@xmlString AS NVARCHAR(MAX)
)
AS
BEGIN

--Convert NVARCHAR(MAX) to XML
DECLARE @XML AS XML;
DECLARE @TypeId AS INT;
SET @XML = CAST(@xmlString AS XML);

CREATE TABLE #TempParsedXML
(
	tenantId VARCHAR(10),
	productCode VARCHAR(20),
	Overuse BIT
)

-- Creates Temp DB with parsed XML contents
INSERT INTO #TempParsedXML
SELECT
	T.v.value('./../@Id', 'int') as tenantId,
	'productCode' = T.v.query('(./ProductCode)').value('.','VARCHAR(20)'),
	'Overuse'= T.v.query('(./Overuse)').value('.','BIT')
FROM @XML.nodes('/Tenants/TID/LicUsage') as T(v);

-- Updates the PolicySettingValues to <STATE=Paid|Trail>,overuse; when there is actual overuse of license for given
-- product code with appropriate tenant context;
--Need to fine tune it further

SELECT 
@TypeId = TypeID 
FROM EPOPolicyTypes 
WHERE TypeTextID = 'PPLicense' AND FeatureTextID = 'EPOAGENTMETA' AND CategoryTextID = 'PPLicense';

UPDATE
	PSV
	SET PSV.LastUpdate=GETUTCDATE(), PSV.SettingValue = 
		CASE 
			WHEN PSV.SettingValue NOT LIKE '%overuse%' 
					AND tpx.Overuse = 1 
				 THEN REPLACE(PSV.SettingValue,';',',overused;')
			WHEN PSV.SettingValue LIKE '%overuse%'
					AND tpx.Overuse = 0
				 THEN REPLACE(PSV.SettingValue,',overused;',';')
			ELSE
				PSV.SettingValue
		END

FROM EPOPolicyObjects AS PO
INNER JOIN EPOPolicyObjectToSettings AS POS
	ON PO.PolicyObjectID = POS.PolicyObjectID AND PO.TypeID = @TypeId
INNER JOIN EPOPolicySettings AS PS 
	ON PO.TenantId=PS.TenantId AND PO.TypeID = PS.TypeID 
	AND PO.TenantId > 1 AND POS.PolicySettingsID = PS.PolicySettingsID 
INNER JOIN EPOPolicySettingValues AS PSV 
	ON PSV.PolicySettingsID=PS.PolicySettingsID AND PSV.TenantId=PS.TenantId
INNER JOIN #TempParsedXML AS tpx 
	ON tpx.tenantId = PS.TenantId AND tpx.productCode=PSV.SettingName



DROP TABLE #TempParsedXML;

END
GO