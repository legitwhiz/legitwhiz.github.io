IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MA_UpdatePolicyWithLicStateChange]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[MA_UpdatePolicyWithLicStateChange]
END
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MA_UpdatePolicyWithLicRemoveProductsChange]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[MA_UpdatePolicyWithLicRemoveProductsChange]
END
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MA_fn_ProductCodeSplit]') AND (OBJECTPROPERTY(id, N'IsScalarFunction') = 1 OR OBJECTPROPERTY(id, N'IsTableFunction') = 1))
BEGIN
	DROP FUNCTION [dbo].[MA_fn_ProductCodeSplit]
END
GO


