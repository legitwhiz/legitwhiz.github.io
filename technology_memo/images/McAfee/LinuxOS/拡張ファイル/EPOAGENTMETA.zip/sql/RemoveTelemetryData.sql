IF EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[MA_TelemetryDataTable]')
    AND type in (N'U')
)
BEGIN
	DROP TABLE [dbo].[MA_TelemetryDataTable]
END


IF EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[MA_TelemetryExtensionDataTable]')
    AND type in (N'U')
)
BEGIN
	DROP TABLE [dbo].[MA_TelemetryExtensionDataTable]
END

/*Commenting for now as dashboards is out of 5.6.1 scope*/
/*IF EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[MA_DailyDeploymentDiagnostics]')
    AND type in (N'U')
)
BEGIN
	DROP TABLE [dbo].[MA_DailyDeploymentDiagnostics]
END

IF EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[MA_DailyDeploymentEvents]')
    AND type in (N'U')
)
BEGIN
	DROP TABLE [dbo].[MA_DailyDeploymentEvents]
END
*/
IF EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[MA_TelemetryComputerProductSnapshot]')
    AND type in (N'U')
)
BEGIN
	DROP TABLE [dbo].[MA_TelemetryComputerProductSnapshot]
END



    IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[AddClientTelemetryData]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
  BEGIN
    DROP PROCEDURE [dbo].[AddClientTelemetryData]
  END

  IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[AddPPExtensionTelemetryData]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
  BEGIN
    DROP PROCEDURE [dbo].[AddPPExtensionTelemetryData]
  END

/*Commenting for now as dashboards is out of 5.6.1 scope*/
 /* IF EXISTS (SELECT * from dbo.sysobjects where id = object_id(N'[dbo].[MA_PopulateDailyDeploymentEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[MA_PopulateDailyDeploymentEvents]
END


IF EXISTS (SELECT * from dbo.sysobjects where id = object_id(N'[dbo].[MA_PopulateDailyAgentDiagnostic]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[MA_PopulateDailyAgentDiagnostic]
END */




