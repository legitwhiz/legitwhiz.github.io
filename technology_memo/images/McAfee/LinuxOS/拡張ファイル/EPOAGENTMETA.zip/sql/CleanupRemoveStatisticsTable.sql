IF EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[StatisticsTable_EPOAgent3000]')
    AND type in (N'U')
)
BEGIN

	DROP TABLE [dbo].[StatisticsTable_EPOAgent3000]
END

GO
