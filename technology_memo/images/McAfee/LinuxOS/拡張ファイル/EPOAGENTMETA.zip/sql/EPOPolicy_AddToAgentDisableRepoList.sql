
-- update agent policies to include a disabled repository being
--  added by some external action.
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[EPOPolicy_AddToAgentDisableRepoList]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[EPOPolicy_AddToAgentDisableRepoList]
GO
CREATE PROCEDURE [dbo].[EPOPolicy_AddToAgentDisableRepoList]
(
	@reponame nvarchar(128)
)
AS
BEGIN
	-- squelch client callbacks for row update reporting
	SET NOCOUNT ON;

	DECLARE @tbl TABLE
	(
		poid int,
		psid int, 
		psvid int, 
		disabled int, 
		section nvarchar(128), 
		setting nvarchar(128), 
		val nvarchar(128)
	);
	
	INSERT INTO @tbl(poid, psid, psvid, disabled, section, setting, val)
		SELECT  
			EPOPolicyObjectToSettings.PolicyObjectID,
			EPOPolicySettingValues.PolicySettingsID, 
			EPOPolicySettingValues.PolicySettingValuesID, 
			CONVERT(int, ISNULL(EPOPolicySettingValues.SettingValue,0))+1,
			N'InetManager', 
			N'DisabledSites_' + ISNULL(EPOPolicySettingValues.SettingValue,N'0'), 
			@reponame
		FROM EPOPolicyTypes INNER JOIN EPOPolicyObjects
		ON EPOPolicyTypes.TypeID = EPOPolicyObjects.TypeID
		INNER JOIN EPOPolicyObjectToSettings
		ON EPOPolicyObjects.PolicyObjectID = EPOPolicyObjectToSettings.PolicyObjectID
		INNER JOIN EPOPolicySettingValues
		ON EPOPolicyObjectToSettings.PolicySettingsID = EPOPolicySettingValues.PolicySettingsID
		INNER JOIN EPOPolicySettingValues PSV2 ON PSV2.PolicySettingsID = EPOPolicyObjectToSettings.PolicySettingsID
		WHERE EPOPolicyTypes.FeatureTextID LIKE N'EPOAGENTMETA'
		AND EPOPolicyTypes.CategoryTextID = N'Repository'
		AND EPOPolicyTypes.TypeTextID = N'Repository'
		AND EPOPolicySettingValues.SectionName = N'InetManager'
		AND EPOPolicySettingValues.SettingName = N'DisabledSiteNum'
		AND PSV2.SectionName = N'InetManager'
		AND PSV2.SettingName = N'includeReposByDefault'
		AND PSV2.SettingValue <> N'1'

	DELETE FROM @tbl WHERE psid IN 
		(SELECT PolicySettingsID FROM EPOPolicySettingValues
		 INNER JOIN @tbl A ON EPOPolicySettingValues.PolicySettingsID = A.psid
		 WHERE EPOPolicySettingValues.SectionName = N'InetManager'
		 AND EPOPolicySettingValues.SettingName LIKE N'DisabledSites_%'
		 AND EPOPolicySettingValues.SettingValue = @reponame);

    DECLARE @the_cursor CURSOR;
    SET @the_cursor = CURSOR FOR
        SELECT poid, psid, psvid, disabled, section, setting, val FROM @tbl

    -- open the cursor on the current db content
    OPEN @the_cursor;

	DECLARE @poid int;
	DECLARE @psid int;
	DECLARE @psvid int;
	DECLARE	@disabled int;
	DECLARE	@section nvarchar(128);
	DECLARE @setting nvarchar(128);
    DECLARE @val nvarchar(128);

    FETCH NEXT FROM @the_cursor INTO @poid, @psid, @psvid, @disabled, @section, @setting, @val;
    WHILE (@@FETCH_STATUS = 0)
    BEGIN
		UPDATE EPOPolicySettingValues SET SettingValue=@val
			WHERE PolicySettingsID = @psid AND SectionName = @section AND SettingName=@setting 
		IF (@@ROWCOUNT = 0)
		BEGIN
	INSERT INTO EPOPolicySettingValues(PolicySettingsID, SectionName, SettingName, SettingValue)
					VALUES (@psID, @section, @setting, @val)
		END
		FETCH NEXT FROM @the_cursor INTO @poid, @psid, @psvid, @disabled, @section, @setting, @val;
	END

	CLOSE @the_cursor;
	DEALLOCATE @the_cursor;

	UPDATE psvs
		SET SettingValue = CONVERT(nvarchar(128), local.disabled)
		FROM EPOPolicySettingValues psvs INNER JOIN @tbl local
		ON psvs.PolicySettingValuesID = local.psvid




	DECLARE @tble TABLE
	(
		poid int,
		psid int,
		psvid int,
		orderNum int,
		section nvarchar(128),
		setting nvarchar(128),
		val nvarchar(128)
	);

	INSERT INTO @tble(poid, psid, psvid, orderNum, section, setting, val)
		SELECT
			EPOPolicyObjectToSettings.PolicyObjectID,
			EPOPolicySettingValues.PolicySettingsID,
			EPOPolicySettingValues.PolicySettingValuesID,
			CONVERT(int, ISNULL(EPOPolicySettingValues.SettingValue,0))+1,
			N'InetManager',
			N'SitelistOrder_' + ISNULL(EPOPolicySettingValues.SettingValue,N'0'),
			@reponame
		FROM EPOPolicyTypes INNER JOIN EPOPolicyObjects
		ON EPOPolicyTypes.TypeID = EPOPolicyObjects.TypeID
		INNER JOIN EPOPolicyObjectToSettings
		ON EPOPolicyObjects.PolicyObjectID = EPOPolicyObjectToSettings.PolicyObjectID
		INNER JOIN EPOPolicySettingValues
		ON EPOPolicyObjectToSettings.PolicySettingsID = EPOPolicySettingValues.PolicySettingsID
		WHERE EPOPolicyTypes.FeatureTextID LIKE N'EPOAGENTMETA'
		AND EPOPolicyTypes.CategoryTextID = N'Repository'
		AND EPOPolicyTypes.TypeTextID = N'Repository'
		AND EPOPolicySettingValues.SectionName = N'InetManager'
		AND EPOPolicySettingValues.SettingName = N'SitelistOrderNum'


	DELETE FROM @tble WHERE psid IN
		(SELECT PolicySettingsID FROM EPOPolicySettingValues
		 INNER JOIN @tble A ON EPOPolicySettingValues.PolicySettingsID = A.psid
		 WHERE EPOPolicySettingValues.SectionName = N'InetManager'
		 AND EPOPolicySettingValues.SettingName LIKE N'SitelistOrder_%'
		 AND EPOPolicySettingValues.SettingValue = @reponame);

    DECLARE @the_cursore CURSOR;
    SET @the_cursore = CURSOR FOR
        SELECT poid, psid, psvid, orderNum, section, setting, val FROM @tble

    -- open the cursor on the current db content
    OPEN @the_cursore;

	DECLARE	@orderNum int;


    FETCH NEXT FROM @the_cursore INTO @poid, @psid, @psvid, @orderNum, @section, @setting, @val;
    WHILE (@@FETCH_STATUS = 0)
    BEGIN
		UPDATE EPOPolicySettingValues SET SettingValue=@val
			WHERE PolicySettingsID = @psid AND SectionName = @section AND SettingName=@setting
		IF (@@ROWCOUNT = 0)
		BEGIN
	INSERT INTO EPOPolicySettingValues(PolicySettingsID, SectionName, SettingName, SettingValue)
					VALUES (@psID, @section, @setting, @val)
		END
		FETCH NEXT FROM @the_cursore INTO @poid, @psid, @psvid, @disabled, @section, @setting, @val;
	END

	CLOSE @the_cursore;
	DEALLOCATE @the_cursore;

	UPDATE psvs
		SET SettingValue = CONVERT(nvarchar(128), local.orderNum)
		FROM EPOPolicySettingValues psvs INNER JOIN @tble local
		ON psvs.PolicySettingValuesID = local.psvid





	SELECT A.Name AS PolicyName
		FROM EPOPolicyObjects A INNER JOIN @tbl B
		ON A.PolicyObjectID = B.poid
		ORDER BY A.Name ASC
END
GO
