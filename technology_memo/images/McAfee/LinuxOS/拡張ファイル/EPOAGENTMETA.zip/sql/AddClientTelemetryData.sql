
IF NOT EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[MA_TelemetryDataTable]')
    AND type in (N'U')
)
BEGIN
    CREATE TABLE [dbo].[MA_TelemetryDataTable]
    (
        [AgentGuid] [nvarchar](50) NOT NULL,
        [JsonData]  [nvarchar] (MAX) NOT NULL,
        [LastSeen]  [nvarchar] (50) NOT NULL,
        CONSTRAINT [PK_MA_TelemetryDataTable]	PRIMARY KEY ([AgentGuid])
    )
END

/*Commenting for now as dashboards is out of 5.6.1 scope*/
/* Create Daily Diagnostics Table
IF NOT EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[MA_DailyDeploymentDiagnostics]')
    AND type in (N'U')
)
BEGIN
    CREATE TABLE [dbo].[MA_DailyDeploymentDiagnostics]
    (
       [RowDate]        [date],
       [DiagnosticType] [tinyint],
       [NodeCount]      [int]
    )
END

/* Create Daily DeploymentEvents Table*/
IF NOT EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[MA_DailyDeploymentEvents]')
    AND type in (N'U')
)
BEGIN
    CREATE TABLE [dbo].[MA_DailyDeploymentEvents]
    (
        [RowDate]  [date],
        [AgentGuid] [nvarchar](50) NOT NULL,
        [ProductCode] [nvarchar](50),
        [ProductVersion] [nvarchar](50),
        [ErrorCode]  [int],
        [DiagnosticType] [tinyint],
    )
END
*/

IF NOT EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[MA_TelemetryComputerProductSnapshot]')
    AND type in (N'U')
)
BEGIN
    CREATE TABLE [dbo].[MA_TelemetryComputerProductSnapshot]
    (
        [AgentGuid] [nvarchar](50) NOT NULL,
        [ProductCode]  [nvarchar](20),
        [ProductVersion]  [nvarchar](20),
        [CrashCount] [int],
        [SnapshotTime]  [datetime]
    )
END



IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[MA_TelemetryComputerProductSnapshot]') AND name = N'IX_MATelemetryComputerProductSnapshot_AgentGuid')
	CREATE INDEX [IX_MATelemetryComputerProductSnapshot_AgentGuid] ON [dbo].[MA_TelemetryComputerProductSnapshot] ([AgentGuid] ASC);
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddClientTelemetryData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	drop procedure [dbo].[AddClientTelemetryData]
END
GO

CREATE PROCEDURE [dbo].[AddClientTelemetryData]
  @AgentGuid [nvarchar](50),
  @JsonData [nvarchar] (MAX),
  @LastSeen [nvarchar](50)

AS
BEGIN
IF EXISTS (SELECT * FROM [dbo].[MA_TelemetryDataTable]
				WHERE AgentGuid = @AgentGuid)
	BEGIN
		UPDATE [dbo].[MA_TelemetryDataTable]
		Set
			JsonData = @JsonData,
 			LastSeen = @LastSeen
		WHERE AgentGuid = @AgentGuid
	END
ELSE
	BEGIN
		INSERT INTO [dbo].[MA_TelemetryDataTable]
		([AgentGuid], [JsonData], [LastSeen])
		VALUES (@AgentGuid, @JsonData,@LastSeen)
	END
END
