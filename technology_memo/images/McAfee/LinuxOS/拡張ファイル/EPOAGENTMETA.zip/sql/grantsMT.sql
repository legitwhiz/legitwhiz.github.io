EXEC ('GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[MAEnforcementStatusView] TO mcafeeTenant')
EXEC ('GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[MAEnforcementStatusView] TO mcafeeOps')
EXEC ('GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[MAEnforcementStatusView] TO mcafeeSystem')
EXEC ('GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[MAEnforcementStatus] TO mcafeeTenant')
EXEC ('GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[MAEnforcementStatus] TO mcafeeOps')
EXEC ('GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[MAEnforcementStatus] TO mcafeeSystem')

EXEC ('GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[StatisticsTable_EPOAgent3000] TO mcafeeTenant')
EXEC ('GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[StatisticsTable_EPOAgent3000] TO mcafeeOps')
EXEC ('GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[StatisticsTable_EPOAgent3000] TO mcafeeSystem')

EXEC ('GRANT EXECUTE ON [dbo].[Agent_GetProductName] TO mcafeeSystem')
EXEC ('GRANT EXECUTE ON [dbo].[Agent_GetProductName] TO mcafeeOps')
EXEC ('GRANT EXECUTE ON [dbo].[Agent_GetProductName] TO mcafeeTenant')

EXEC ('GRANT EXECUTE ON [dbo].[MA_UpdatePolicyWithLicRemoveProductsChange] TO mcafeeSystem');
EXEC ('GRANT EXECUTE ON [dbo].[MA_UpdatePolicyWithLicRemoveProductsChange] TO mcafeeOps');
EXEC ('GRANT EXECUTE ON [dbo].[MA_UpdatePolicyWithLicRemoveProductsChange] TO mcafeeTenant');

EXEC ('GRANT EXECUTE ON [dbo].[MA_UpdatePolicyWithLicStateChange] TO mcafeeSystem');
EXEC ('GRANT EXECUTE ON [dbo].[MA_UpdatePolicyWithLicStateChange] TO mcafeeOps');
EXEC ('GRANT EXECUTE ON [dbo].[MA_UpdatePolicyWithLicStateChange] TO mcafeeTenant');

--mafn_ProductCodeSplit is a Table Valued Function, hence Grant Select permission
EXEC ('GRANT SELECT ON [dbo].[MA_fn_ProductCodeSplit] TO mcafeeSystem');
EXEC ('GRANT SELECT ON [dbo].[MA_fn_ProductCodeSplit] TO mcafeeOps');
EXEC ('GRANT SELECT ON [dbo].[MA_fn_ProductCodeSplit] TO mcafeeTenant');

--FedRAMP/Cloud redirect table and sp grants
EXEC ('GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[MA_CloudRedirectData] TO mcafeeSystem');
EXEC ('GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[MA_CloudRedirectData] TO mcafeeOps');

EXEC ('GRANT EXECUTE ON [dbo].[MA_PopulateCloudRedirect] TO mcafeeSystem')
EXEC ('GRANT EXECUTE ON [dbo].[MA_PopulateCloudRedirect] TO mcafeeOps')
GO
