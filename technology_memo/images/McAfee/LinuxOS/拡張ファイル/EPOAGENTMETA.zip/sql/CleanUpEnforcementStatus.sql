SET ANSI_NULLS ON
 GO

 SET QUOTED_IDENTIFIER ON
 GO

 IF EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = OBJECT_ID(N'[dbo].[FK_MAEnforcementStatus_EPOProductProperties]') AND type = 'F')
 	ALTER TABLE [dbo].[MAEnforcementStatus] DROP CONSTRAINT [FK_MAEnforcementStatus_EPOProductProperties]
 GO

 IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[MAEnforcementStatusView]'))
     DROP VIEW [dbo].[MAEnforcementStatusView]
 GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[MAEnforcementStatus]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)

DROP TABLE [dbo].[MAEnforcementStatus]

GO