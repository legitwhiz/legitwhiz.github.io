IF NOT EXISTS
(
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[StatisticsTable_EPOAgent3000]')
    AND type in (N'U')
)
BEGIN

	CREATE TABLE [dbo].[StatisticsTable_EPOAgent3000]
	(
		[AutoID]				    [int] IDENTITY(1,1) ,
		[AgentGUID]				    [nvarchar](255) NOT NULL ,
		[GMTTime]					[nvarchar](255) NOT NULL,
		[IPAddress]					[nvarchar](255) NOT NULL,
		[OSName]				    [nvarchar](255) NOT NULL,
		[UserName]					[nvarchar](255) NOT NULL ,
		[TimeZoneBias]				[nvarchar](255) NOT NULL ,
		[MachineName]				[nvarchar](255) NOT NULL ,
		[RawMACAddress]				[nvarchar](255) NOT NULL ,
		[ProductID]					[nvarchar](255) NOT NULL DEFAULT 'EPOAGENT3000',
        --Relay stats
		[FailedConnections]			[int] DEFAULT 0,
		[NumberOfTimesMaxed]		[int] DEFAULT 0,

		--SA-HU stats
		[SAHUBandwidthsaved]		[nvarchar](255) DEFAULT '0.00 MB',

		--P2P stats
		[P2PBandwidthSaved]		        [nvarchar](255) DEFAULT '0.00 MB',

		CONSTRAINT [PK_StatisticsTable_EPOAgent3000]					PRIMARY KEY ([AutoID])
	)

END
ELSE IF NOT EXISTS
(
		SELECT * FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME='StatisticsTable_EPOAgent3000'
		AND COLUMN_NAME='P2PBandwidthSaved'
)
BEGIN
    ALTER TABLE [dbo].[StatisticsTable_EPOAgent3000]
    ADD	[P2PBandwidthSaved] [nvarchar] (255) DEFAULT '0.00 MB'
END

GO

