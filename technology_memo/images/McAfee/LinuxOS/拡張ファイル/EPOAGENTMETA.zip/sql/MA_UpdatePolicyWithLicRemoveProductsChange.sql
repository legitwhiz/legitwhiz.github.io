
/*-------------------------------------------------------------------------------------
This stored proc will remove the settings values from the EPOPolicySettingsValues Table
for all those productcode which were passed as input along with the TenantID.
---------------------------------------------------------------------------------------*/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MA_UpdatePolicyWithLicRemoveProductsChange]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[MA_UpdatePolicyWithLicRemoveProductsChange]
END
GO

CREATE PROCEDURE [dbo].MA_UpdatePolicyWithLicRemoveProductsChange(
	@TenantId AS INT,
	@removePP AS NVARCHAR(MAX)
)
AS
BEGIN

	DELETE 
	psv
	FROM EPOPolicySettings AS PS
	INNER JOIN EPOPolicySettingValues AS PSV 
		ON PS.PolicySettingsID = PSV.PolicySettingsID
		AND PS.TenantId=@TenantId 
	INNER JOIN MA_fn_ProductCodeSplit(@removePP, DEFAULT) as pc
		ON pc.id = PSV.SettingName;

END
GO