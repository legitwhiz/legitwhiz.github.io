
IF OBJECT_ID('MAPolicyEnforcementEvents') IS NOT NULL
BEGIN
	DROP VIEW MAPolicyEnforcementEvents
END
GO