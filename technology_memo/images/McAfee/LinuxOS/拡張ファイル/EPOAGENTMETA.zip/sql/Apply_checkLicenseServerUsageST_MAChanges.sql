/*---------------------------------------------------------------
This stored proc will help user to split the list with delimiter.
By default ',' (Comma) seperator is considered as delimiter
-----------------------------------------------------------------*/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MA_fn_ProductCodeSplit]') AND (OBJECTPROPERTY(id, N'IsScalarFunction') = 1 OR OBJECTPROPERTY(id, N'IsTableFunction') = 1))
BEGIN
	DROP FUNCTION [dbo].[MA_fn_ProductCodeSplit]
END
GO

CREATE FUNCTION dbo.MA_fn_ProductCodeSplit
(
	@list nvarchar(max),
	@delim nchar(1) = N','
)
RETURNS @tbl TABLE( id NVARCHAR(MAX) )
AS
BEGIN
	DECLARE @id nvarchar(MAX);
	DECLARE @start int, @stop int;

	-- list must have leading and trailing delimeters.
	SET @list = LTRIM(RTRIM(@list));

	-- add leading and trailing delimiters if not already present
	IF (SUBSTRING(@list, 1, 1) <> @delim)
		SET @list = @delim + @list;
	IF (SUBSTRING(@list, LEN(@list), 1) <>  @delim)
		SET @list = @list + @delim;

	-- prime starting and stopping points.
	SET @start = CHARINDEX(@delim, @list, 0)
	SET @stop = CHARINDEX(@delim, @list, @start+1);

	WHILE ((@start > 0) AND (@stop > @start))
	BEGIN
		SET @id = LTRIM(RTRIM(SUBSTRING(@list, @start+1, (@stop - @start) - 1)));
		IF (@id <> N'')
		BEGIN
			INSERT INTO @tbl(id) VALUES (CAST(@id AS nvarchar));
			SET @start = @stop;
			SET @stop = CHARINDEX(@delim, @list, @start+1);
		END
		ELSE
		BEGIN
			BREAK;
		END
	END
	RETURN
END
GO




/*-------------------------------------------------------------------------------------
This stored proc will remove the settings values from the EPOPolicySettingsValues Table
for all those productcode which were passed as input along with the TenantID.
---------------------------------------------------------------------------------------*/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MA_UpdatePolicyWithLicRemoveProductsChange]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[MA_UpdatePolicyWithLicRemoveProductsChange]
END
GO

CREATE PROCEDURE [dbo].MA_UpdatePolicyWithLicRemoveProductsChange(
	@TenantId AS INT,
	@removePP AS NVARCHAR(MAX)
)
AS
BEGIN

	DELETE 
	psv
	FROM EPOPolicySettings AS PS
	INNER JOIN EPOPolicySettingValues AS PSV 
		ON PS.PolicySettingsID = PSV.PolicySettingsID
		AND PS.TenantId=@TenantId 
	INNER JOIN MA_fn_ProductCodeSplit(@removePP, DEFAULT) as pc
		ON pc.id = PSV.SettingName;

END
GO



/* This SP does the
1. Parse the XML and fetch the tenant id and product code along with over use bit
2. Fetch the policy type for the given tenant of type "PPLicense"
3. Get the policy Object ID. If not available create one of type 'PP license'. Always make sure that it is editable, if not update the flag
4. Get the policy Settings ID
5. Get the policy Setting value and make the Setting value for PPLicense+(ProductCode) => to Overuse
*/

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MA_UpdatePolicyWithLicStateChange]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[MA_UpdatePolicyWithLicStateChange]
END
GO


CREATE PROCEDURE [dbo].MA_UpdatePolicyWithLicStateChange(
	@xmlString AS NVARCHAR(MAX)
)
AS
BEGIN

--Convert NVARCHAR(MAX) to XML
DECLARE @XML AS XML;
DECLARE @TypeId AS INT;
SET @XML = CAST(@xmlString AS XML);

CREATE TABLE #TempParsedXML
(
	tenantId VARCHAR(10),
	productCode VARCHAR(20),
	Overuse BIT
)

-- Creates Temp DB with parsed XML contents
INSERT INTO #TempParsedXML
SELECT
	T.v.value('./../@Id', 'int') as tenantId,
	'productCode' = T.v.query('(./ProductCode)').value('.','VARCHAR(20)'),
	'Overuse'= T.v.query('(./Overuse)').value('.','BIT')
FROM @XML.nodes('/Tenants/TID/LicUsage') as T(v);

-- Updates the PolicySettingValues to <STATE=Paid|Trail>,overuse; when there is actual overuse of license for given
-- product code with appropriate tenant context;
--Need to fine tune it further

SELECT 
@TypeId = TypeID 
FROM EPOPolicyTypes 
WHERE TypeTextID = 'PPLicense' AND FeatureTextID = 'EPOAGENTMETA' AND CategoryTextID = 'PPLicense';

UPDATE
	PSV
	SET PSV.LastUpdate=GETUTCDATE(), PSV.SettingValue = 
		CASE 
			WHEN PSV.SettingValue NOT LIKE '%overuse%' 
					AND tpx.Overuse = 1 
				 THEN REPLACE(PSV.SettingValue,';',',overused;')
			WHEN PSV.SettingValue LIKE '%overuse%'
					AND tpx.Overuse = 0
				 THEN REPLACE(PSV.SettingValue,',overused;',';')
			ELSE
				PSV.SettingValue
		END

FROM EPOPolicyObjects AS PO
INNER JOIN EPOPolicyObjectToSettings AS POS
	ON PO.PolicyObjectID = POS.PolicyObjectID AND PO.TypeID = @TypeId
INNER JOIN EPOPolicySettings AS PS 
	ON PO.TenantId=PS.TenantId AND PO.TypeID = PS.TypeID 
	AND PO.TenantId > 1 AND POS.PolicySettingsID = PS.PolicySettingsID 
INNER JOIN EPOPolicySettingValues AS PSV 
	ON PSV.PolicySettingsID=PS.PolicySettingsID AND PSV.TenantId=PS.TenantId
INNER JOIN #TempParsedXML AS tpx 
	ON tpx.tenantId = PS.TenantId AND tpx.productCode=PSV.SettingName



DROP TABLE #TempParsedXML;

END
GO


----Granting permission to the newly introduced SP's
EXEC ('GRANT EXECUTE ON [dbo].[MA_UpdatePolicyWithLicRemoveProductsChange] TO mcafeeSystem');
EXEC ('GRANT EXECUTE ON [dbo].[MA_UpdatePolicyWithLicRemoveProductsChange] TO mcafeeOps');
EXEC ('GRANT EXECUTE ON [dbo].[MA_UpdatePolicyWithLicRemoveProductsChange] TO mcafeeTenant');

EXEC ('GRANT EXECUTE ON [dbo].[MA_UpdatePolicyWithLicStateChange] TO mcafeeSystem');
EXEC ('GRANT EXECUTE ON [dbo].[MA_UpdatePolicyWithLicStateChange] TO mcafeeOps');
EXEC ('GRANT EXECUTE ON [dbo].[MA_UpdatePolicyWithLicStateChange] TO mcafeeTenant');

--mafn_ProductCodeSplit is a Table Valued Function, hence Grant Select permission
EXEC ('GRANT SELECT ON [dbo].[MA_fn_ProductCodeSplit] TO mcafeeSystem');
EXEC ('GRANT SELECT ON [dbo].[MA_fn_ProductCodeSplit] TO mcafeeOps');
EXEC ('GRANT SELECT ON [dbo].[MA_fn_ProductCodeSplit] TO mcafeeTenant');

