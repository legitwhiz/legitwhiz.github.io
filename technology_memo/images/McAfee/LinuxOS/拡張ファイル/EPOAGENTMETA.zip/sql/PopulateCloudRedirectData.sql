IF EXISTS (SELECT * from dbo.sysobjects where id = object_id(N'[dbo].[MA_PopulateCloudRedirect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    BEGIN
        DROP PROCEDURE [dbo].[MA_PopulateCloudRedirect]
    END
GO
CREATE PROCEDURE [dbo].[MA_PopulateCloudRedirect]
(
        @DataKey [NVARCHAR] (20),
        @Content [NVARCHAR] (MAX)
)
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT [DataKey] FROM [dbo].[MA_CloudRedirectData] WHERE  [DataKey] = @DataKey)
        BEGIN
            UPDATE [dbo].[MA_CloudRedirectData]
                Set Content=@Content
            WHERE [DataKey] = @DataKey;
        END
    ELSE
        INSERT INTO [dbo].[MA_CloudRedirectData]
        VALUES (@DataKey, @Content)
END
