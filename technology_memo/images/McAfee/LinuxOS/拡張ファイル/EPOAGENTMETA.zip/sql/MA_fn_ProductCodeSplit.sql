/*---------------------------------------------------------------
This stored proc will help user to split the list with delimiter.
By default ',' (Comma) seperator is considered as delimiter
-----------------------------------------------------------------*/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MA_fn_ProductCodeSplit]') AND (OBJECTPROPERTY(id, N'IsScalarFunction') = 1 OR OBJECTPROPERTY(id, N'IsTableFunction') = 1))
BEGIN
	DROP FUNCTION [dbo].[MA_fn_ProductCodeSplit]
END
GO

CREATE FUNCTION dbo.MA_fn_ProductCodeSplit
(
	@list nvarchar(max),
	@delim nchar(1) = N','
)
RETURNS @tbl TABLE( id NVARCHAR(MAX) )
AS
BEGIN
	DECLARE @id nvarchar(MAX);
	DECLARE @start int, @stop int;

	-- list must have leading and trailing delimeters.
	SET @list = LTRIM(RTRIM(@list));

	-- add leading and trailing delimiters if not already present
	IF (SUBSTRING(@list, 1, 1) <> @delim)
		SET @list = @delim + @list;
	IF (SUBSTRING(@list, LEN(@list), 1) <>  @delim)
		SET @list = @list + @delim;

	-- prime starting and stopping points.
	SET @start = CHARINDEX(@delim, @list, 0)
	SET @stop = CHARINDEX(@delim, @list, @start+1);

	WHILE ((@start > 0) AND (@stop > @start))
	BEGIN
		SET @id = LTRIM(RTRIM(SUBSTRING(@list, @start+1, (@stop - @start) - 1)));
		IF (@id <> N'')
		BEGIN
			INSERT INTO @tbl(id) VALUES (CAST(@id AS nvarchar));
			SET @start = @stop;
			SET @stop = CHARINDEX(@delim, @list, @start+1);
		END
		ELSE
		BEGIN
			BREAK;
		END
	END
	RETURN
END
GO