var g_locationsAddWidget;

var g_ActionItemValues = new Array();
g_ActionItemValues[0] = "Install";
g_ActionItemValues[1] = "Remove";

   
function updateLocationIDList()
{
   // update the hidden list of element ID's containing values
   var myrows = g_locationsAddWidget.getList();
   var elementIDList = "";
   for(var i in myrows)
   {
       var currentItemID = myrows[i].replace("locationsList_awrow_", "");
       elementIDList +=  currentItemID;
       elementIDList += ",";
   }

   $("hiddenID_LocationItemIDList").value = elementIDList.substring(0, elementIDList.length-1);
}

function getSelectedPkgNumber()
{
   var count=0;
   if(g_locationsAddWidget !=null)
   {
       var myrows = g_locationsAddWidget.getList();

       for(var i in myrows)
       {
           var currentItemID = myrows[i].replace("locationsList_awrow_", "");
           var elementID = ("select_location_" + currentItemID);
           var element = document.getElementById(elementID);
           if(element.selectedIndex != 0)
           {
                count++;
           }
//         console.log(element);     admin
       }
   }

   return count;
}







