
function breakPointMe()
{
    var variable = "breakpointer";
    variable = "create a breakpoint here and you can step out into the request code";
}

var Aramid = window.Aramid || {};

// This either: 1) runs through all the fields and checks for declared
// validation methods to run, or 2) it runs a specific method if sent.
function _validateFields(){
    var result = true;

    if(arguments[0]){
        var me = OrionEvent.getUserProperty(arguments[0]);
        var fn = me["validate"];
        if(fn != null){
            eval(fn+"(true);");
        }
    }else{

        // Check fields in form
        var formy = document.forms[0];
        for(var i=0;i<formy.elements.length;i++){
            var fn = formy.elements[i].getAttribute("validate");
            if(fn != null){
                eval(fn+"();");
            }

        }

        result = _showErr();
        if(result == false){
            ERR = new Array();
        }
    }
    return result;
}

// Call this function on page load. It runs through the form elements
// and adds an onchange event to enable the save button. Alternatively
// it adds a validation event if the field calls for it.
function _setButtonEnabler(){
    var formy = document.forms[0];
    for(var i=0;i<formy.elements.length;i++){
        var myval = formy.elements[i].getAttribute("validate");
        if(myval != null){
            OrionEvent.registerHandler(formy.elements[i],_validateFields,{"validate":myval},"change",true);
        }else{
            OrionEvent.registerHandler(formy.elements[i],epoEnableApplyButton,"","change",true);
        }
    }
}

function dateToString(date,hours,minutes)
{
    var year = date.getFullYear();
    var month = date.getMonth()+1;
    var day = date.getDate();

    if( day < 10 ) day = "0"+day;
    if( month < 10 ) month = "0"+month;
    if( hours < 10 ) hours = "0"+hours;
    if( minutes < 10 ) minutes = "0"+minutes;

    var value = year+"-"+month+"-"+day + " "+hours+":"+minutes+":00";

    return value;
}

function _findElementByIdPrefix(parent,id)
{
    for( var i=0; i<parent.childNodes.length;i++)
    {
        if( parent.childNodes[i].id && (parent.childNodes[i].id.indexOf(id) == 0) )
        {
            return parent.childNodes[i];
        }
    }
    return undefined;
}

function _enableAllExceptButtons(bEnable)
{
    var formy = document.forms[0];
    for(var i=0;i<formy.elements.length;i++){
        if(formy.elements[i].type != "button")
        {
            formy.elements[i].disabled=!bEnable;
        }
    }
}

function _hideElement(name,bHide)
{
    var element = document.getElementById(name);
    if (element)
    {
        if (bHide)
        {
            element.style.display = "none";
        }
        else
        {
            element.style.display = "";
        }
    }
}


function _enableById(subString,bEnable)
{
    var formy = document.forms[0];
    for(var i=0;i<formy.elements.length;i++){
        if(formy.elements[i].id.indexOf(subString) != -1)
        {
            formy.elements[i].disabled=!bEnable;
        }
    }
}

function _enableDivs(subString, enable)
{
    // find all divs in the document
    var divs = document.getElementsByTagName('DIV');
    for (i = 0; i < divs.length; i++)
    {
        if (divs[i].id.indexOf(subString) != -1)
        {
            if( enable )
            {
                divs[i].style.display = "";
            }
            else
            {
                divs[i].style.display = "none";
            }
        }
    }
}

function isValidUsername(username)
{
    var trimmed = OrionCore.trim(username);
    var regEx = /^.+\\.+$|^.+@.+$/;
    return regEx.test(trimmed);
}

function isValidMD5Hash(value)
{
    var trimmed = OrionCore.trim(value);
    var regEx = /^[a-fA-f0-9]{32}$/;
    return regEx.test(trimmed);
}

function isValidWindowsPartialPath(proc)
{
    var trimmed = OrionCore.trim(proc);

    if(trimmed.indexOf(":") == 1)
    {
        return isValidWindowsProcName(proc);    // then this should be a valid full path
    }

    var myRegexp = new RegExp("[\"<>|/]");
    var result =  myRegexp.exec(trimmed);
    if( result )
    {
        return false;                           // we found a disallowed character
    }
    else if(trimmed.lastIndexOf(":")>1)
    {
        return false;                           // there is a colon somewhere other than #2
    }

    return true;
}

function isValidWindowsProcName(proc)
{
    var trimmed = OrionCore.trim(proc);
    if(trimmed.indexOf(":") == 1 && trimmed.indexOf("\\") == 2 && (trimmed.indexOf("/") < 0))
    {// we can guess that this is windows file name

        var myRegexp = new RegExp("[\"<>|/]");
        var result =  myRegexp.exec(trimmed);
        if( result )                        // we found a disallowed character
        {
            return false;
        }
        else if(trimmed.lastIndexOf(":")>1)    // there is a colon somewhere other than #2
        {
            return false;
        }
        else if(trimmed.length == 3)            // c:\ is not valid by itself
        {
            return false;
        }
        return true;
    }
    
    return false;
}

function isValidProcName(proc)
{
    var trimmed = OrionCore.trim(proc);
    if(isValidWindowsProcName(trimmed) ||
        trimmed.charAt(0)=='/' ||  // unix full path begins with a "/"
        trimmed.charAt(0)=='*' ||  // to allow any procname with a leading '*' to take care of full path
        trimmed.charAt(0)=='%')    // to allow any procname beginning with a variable e.g. %SystemRoot%
    {
        return true;
    }

    return false;
}

function matchIPv6(value)
{
    var pattern1 = '([A-Fa-f0-9]{1,4}:){7}[A-Fa-f0-9]{1,4}';
    var pattern2 = '[A-Fa-f0-9]{1,4}::([A-Fa-f0-9]{1,4}:){0,5}[A-Fa-f0-9]{1,4}';
    var pattern3 = '([A-Fa-f0-9]{1,4}:){2}:([A-Fa-f0-9]{1,4}:){0,4}[A-Fa-f0-9]{1,4}';
    var pattern4 = '([A-Fa-f0-9]{1,4}:){3}:([A-Fa-f0-9]{1,4}:){0,3}[A-Fa-f0-9]{1,4}';
    var pattern5 = '([A-Fa-f0-9]{1,4}:){4}:([A-Fa-f0-9]{1,4}:){0,2}[A-Fa-f0-9]{1,4}';
    var pattern6 = '([A-Fa-f0-9]{1,4}:){5}:([A-Fa-f0-9]{1,4}:){0,1}[A-Fa-f0-9]{1,4}';
    var pattern7 = '([A-Fa-f0-9]{1,4}:){6}:[A-Fa-f0-9]{1,4}';
    var pattern8 = '::([A-Fa-f0-9]{1,4}:){0,6}[A-Fa-f0-9]{1,4}';

    var pattern = "^"+pattern2+"$|^"+pattern1+"$|^("+pattern3+")$|^("+pattern4+
               ")$|^("+pattern5+")$|^("+pattern6+")$|^("+pattern7+")$|^("+pattern8+")$";

    var myRegexp = new RegExp(pattern);


    var result =  myRegexp.exec(OrionCore.trim(value));

    return result != null;
}

function matchIPv4(value)
{
    var pattern = '^((2[0-5]{2}|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)\\.){3}(2[0-5]{2}|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)$';

    var myRegexp = new RegExp(pattern);
    var result = myRegexp.exec(OrionCore.trim(value));

    return result != null;
}

function matchIPv4Range(value)
{
    var addrs = value.split("-");
    if(addrs==null || addrs.length!=2)
    {
        return false;
    }

    return matchIPv4(addrs[0]) && matchIPv4(addrs[1]);
}

function matchIPv6Range(value)
{
    var addrs = value.split("-");
    if( addrs == null || addrs.length!=2)
    {
        return false;
    }

    return matchIPv6(addrs[0]) && matchIPv6(addrs[1]);
}

function matchIPv6Net(value)
{
    var parts = value.split("\/");
    if( parts == null || parts.length!=2)
    {
        return false;
    }

    var maskBits = parts[1];

    var pattern = '^12[0-8]$|^1[0-1][0-9]$|^[1-9]?[0-9]$';

    var myRegexp = new RegExp(pattern);
    var result = myRegexp.exec(OrionCore.trim(maskBits))!=null;

    return result && matchIPv6(parts[0]);
}

function matchIPv4Net(value)
{
    var parts = value.split("\/");
    if( parts == null || parts.length!=2)
    {
        return false;
    }

    var maskBits = parts[1];
    var pattern = '^3[0-2]$|^[1-2]?[0-9]$';

    var myRegexp = new RegExp(pattern);
    var result = myRegexp.exec(OrionCore.trim(maskBits))!=null;


    return result && matchIPv4(parts[0]);
}

function disableSection(sectionId,enable)
{
    var section = document.getElementById(sectionId);
    var slist = getElementsAsArray(sectionId);

    for(var i=0;i<slist.length;i++){
        OrionCore.setEnabled(slist[i],enable);
    }
}

function getElementsAsArray(sectionId)
{
    var sectd = document.getElementById(sectionId);
    var slistt = new Array();
    var slist = slistt.concat(__arrayme(sectd.getElementsByTagName("LABEL")),
        __arrayme(sectd.getElementsByTagName("INPUT")),
        __arrayme(sectd.getElementsByTagName("SELECT")),
        __arrayme(sectd.getElementsByTagName("TEXTAREA")));

    return slist;
    
    function __arrayme(obj){
        var n = new Array();
        for(var j=0;j<obj.length;j++){
            n.push(obj[j]);
        }
        return n;
    }
}

function toggleSection(me,sect){
    var sectd = document.getElementById(sect);
    var slistt = new Array();
    var slist = slistt.concat(__arrayme(sectd.getElementsByTagName("LABEL")),
        __arrayme(sectd.getElementsByTagName("INPUT")),
        __arrayme(sectd.getElementsByTagName("SELECT")),
        __arrayme(sectd.getElementsByTagName("TEXTAREA")));
    for(var i=0;i<slist.length;i++){
        OrionCore.setEnabled(slist[i],me.checked);
    }
    function __arrayme(obj){
        var n = new Array();
        for(var j=0;j<obj.length;j++){
            n.push(obj[j]);
        }
        return n;
    }
}

function getChildCheckboxes( ancestor, checkboxes )
{
    if (ancestor)
    {
        if ( ancestor.type == "checkbox")
        {
            if( !checkboxes ) checkboxes = new Array();
            checkboxes.push(ancestor);
        }
        else
        {
            for (var i = 0; i < ancestor.childNodes.length; i++)
            {
                var child = ancestor.childNodes[i];
                getChildCheckboxes(child,checkboxes);
            }
        }
    }
    
    return checkboxes;
}

function getSelectedChildCheckboxes( ancestor )
{
    var selected = new Array();
    var checkboxes = getChildCheckboxes(ancestor,new Array());

    for(var i in checkboxes)
    {
        if(checkboxes[i].checked) selected.push(checkboxes[i]);
    }

    return selected;
}


function cleanupActions()
{
    if (OrionCore && window.OrionAction != undefined)
    {
        OrionCore.removeResizeHandler(OrionAction.updateActionButtons);
        OrionAction = null;
    }
}

function findIndexOf(selector,value)
{
    for(var i=0;i<selector.options.length;i++)
    {
        if(selector.options[i] && selector.options[i].value==value) return i;
    }

    return 0;
}

function hide(element)
{
    if (element)
    {
        element.style.display = "none";
    }
}

function show(element)
{
    if (element)
    {
        element.style.display = "";
    }
}

function arrayToString(values)
{
    var out = '';

    for(var i in values)
    {
        var value = OrionCore.encode(values[i]);
        value = value.replace(/#/g,"%23");
        out += value+"#";
    }

    return out;
}