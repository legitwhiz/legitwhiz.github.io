/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

var filenameRenderer = new TruncatedCellRenderer(50);
filenameRenderer.valueToString = filenameToDisplayTransform;


var fingerprintRenderer = new MapCellRenderer({"00000000000000000000000000000000": ""});

/*
* Networks are stored in a map.  So the value parameter is in the form [[key, net], [key2, net2]]
*/
var networkRenderer = new TruncatedCellRenderer(15);
networkRenderer.valueToString = function(value){
	var hostStr = "";
	for(var i = 0; i < value.length; ++i){
		if(value[i][1]) {
			for (var j = 0; j < value[i][1].hosts.length; ++j) {
				if(hostStr.length != 0){
					hostStr += ", ";
				}
				hostStr += new IpAddress(value[i][1].hosts[j].ipStr).displayString();
			}
		}
	}
	return hostStr;
};

var mediaRenderer = new MapCellRenderer(mediaStrs); //strings defined in Resources.jsp
mediaRenderer.getValue = function(rowObj, tree, id){
	return rowObj[id][0];
};

var serviceRenderer = new TruncatedCellRenderer(15);
serviceRenderer.getValue = function(rowObj, tree, id, depth){
	return rowObj[id][0];
};

var protocolRenderer = new CellRenderer();
protocolRenderer.appliesTo = function(rowObj){
	return rowObj.transportProtocol != null && rowObj.networkProtocols != null && rowObj.networkProtocols.length != null;
};

protocolRenderer.getValue = function(rowObj){
	var netProtoNums = new Array();
	for(var i = 0; i < rowObj.networkProtocols.length; ++i){
		netProtoNums.push(parseInt(rowObj.networkProtocols[i]));
	}
	return {
		transProtoNum: parseInt(rowObj.transportProtocol),
		netProtoNums: netProtoNums
	};
};

protocolRenderer.valueToString = function(value){
	return toProtocolString(value.transProtoNum, value.netProtoNums);
};


