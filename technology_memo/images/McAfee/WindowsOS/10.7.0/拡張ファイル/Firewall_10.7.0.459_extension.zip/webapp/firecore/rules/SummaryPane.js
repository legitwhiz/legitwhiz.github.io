/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

/**
 * Creates a summary binding, assuming the standard summary layout (see EditFWRules.jsp)
 * @param prefix The id prefix.
 * @return the binding
 */
function initSummary(prefix){
	function getNetworkChildren(rowObj){
		return safeSortAndReturn(rowObj["hosts"], hostComparator);
	}

	/**
	 * Override TreeTableListBinding.setValue for local / remote Networks.
	 * Binding class expects an array of Aggregates [agg1, agg2].
	 * However, networks are stored in a map which results in [[id1, agg1], [id2, agg2]].
	 * Convert the map format
	 *
	 * @param value
     */
	function setHosts(value)
	{
		var rows = new Array();
		var list = TreeTable.deepCopy(value);
		for(var i = 0; i < list.length; ++i)
		{
			if(list[i][1])
			{
				rows.push(list[i][1]);
			}
		}
		this.tree.setRowData(safeSortAndReturn(rows, this.comparator));
	}

	var colList = ["name", "ipStr"];
	var localNetworksTree = new TreeTable(prefix + "_localNetworksTree", MasterColMap, colList, new Array(), false, false);
	localNetworksTree.getChildren = getNetworkChildren;
	var localNetworkBinding = new TreeTableListBinding(localNetworksTree, nameComparator);
	localNetworkBinding.setValue = setHosts;

	var remoteNetworksTree = new TreeTable(prefix + "_remoteNetworksTree", MasterColMap, colList, new Array(), false, false);
	remoteNetworksTree.getChildren = getNetworkChildren;
	var remoteNetworkBinding = new TreeTableListBinding(remoteNetworksTree, nameComparator);
	remoteNetworkBinding.setValue = setHosts;

	colList = ["name", "filename", "fingerprint", "description", "signerName"];
	var applicationsTree = new TreeTable(prefix + "_applicationsTree", MasterColMap, colList, new Array(), false, false);
	applicationsTree.getChildren = function(rowObj){
		return safeSortAndReturn(rowObj.executables, nameComparator);
	};

	var colMap = MasterColMap.select(["name", "ipStr", "regKey", "requireEpoReachable", "isolated"]);
	colList = ["name", "ipStr", "regKey", "requireEpoReachable", "isolated"];
	var locationTree = new TreeTable(prefix + "_locationTree", colMap, colList, new Array(), false, false);
	locationTree.getChildren = setLocationCriteriaNames(locationCriteriaNames);
	var locationBinding = new TreeTableListBinding(locationTree);
	locationBinding.setValue = function(value){
		var list = new Array();
		list.push(TreeTable.deepCopy(value));
		this.tree.setRowData(list);
	};

	var actionBinding = new HideShowObjectBinding(prefix + "_action_row", new TextContainerBinding(prefix + "_action", actionStrs));
	actionBinding.shouldHide = function(value){
		return value == "JUMP";
	};

	function nullOrEmpty(value){
		return value == null || value == "";
	}
	var localServiceBinding = new HideShowObjectBinding(prefix + "_localServiceList_row", new TextContainerBinding(prefix + "_localServiceList"));
	localServiceBinding.shouldHide = nullOrEmpty;
	var remoteServiceBinding = new HideShowObjectBinding(prefix + "_remoteServiceList_row", new TextContainerBinding(prefix + "_remoteServiceList"));
	remoteServiceBinding.shouldHide = nullOrEmpty;

	var protoBinding = new MultiValueBinding(["transportProtocol", "networkProtocols"]);
	protoBinding.id = prefix + "_protocolContainer";
	protoBinding.render = function(){
		var text = toProtocolString(this.valueMap["transportProtocol"], this.valueMap["networkProtocols"]);
		var elem = document.getElementById(this.id);
		while(elem.firstChild != null){
			elem.removeChild(elem.firstChild);
		}
		elem.appendChild(document.createTextNode(text));
	};

	var clickTimeoutBinding = new HideShowObjectBinding(prefix + "_schedule_clickTimeout_row", new TextContainerBinding(prefix + "_schedule_clickTimeout"));
	clickTimeoutBinding.shouldHide = function(value){
		return value == 0;
	};

	return new ChainedMapBinding({
		"@_NodeName": new NullBinding(),
		"id": new NullBinding(),
		"version": new NullBinding(),
		"name": new TextContainerBinding(prefix + "_name"),
		"note": new TextContainerBinding(prefix + "_note"),
		"action": actionBinding,
		"enabled": new HideShowBooleanBinding(prefix + "_disabled", true),
		"direction": new TextContainerBinding(prefix + "_direction", directionStrs),
		"media": new TextContainerBinding(prefix + "_media", mediaStrs),
		"networkProtocols": protoBinding.getView("networkProtocols"),
		"localNetworks": new HideShowObjectBinding(prefix + "_localNetworks", localNetworkBinding),
		"remoteNetworks": new HideShowObjectBinding(prefix + "_remoteNetworks", remoteNetworkBinding),
		"transportProtocol": protoBinding.getView("transportProtocol"),
		"localServiceList": localServiceBinding,
		"remoteServiceList": remoteServiceBinding,
		"applications": new HideShowObjectBinding(prefix + "_applications", new TreeTableListBinding(applicationsTree, nameComparator)),
		"location": new HideShowObjectBinding(prefix + "_location", locationBinding),
		"intrusion": new HideShowBooleanBinding(prefix + "_intrusion"),
		"trafficLogged": new HideShowBooleanBinding(prefix + "_trafficLogged"),
		"schedule": new ScheduleBinding(prefix + "_schedule", new ChainedMapBinding({
			"clickTimeout": clickTimeoutBinding,
			"scheduleStartHours": new TextContainerBinding(prefix + "_schedule_start_time_hour"),
			"scheduleStartMinutes": new TextContainerBinding(prefix + "_schedule_start_time_min"),
			"scheduleEndHours": new TextContainerBinding(prefix + "_schedule_end_time_hour"),
			"scheduleEndMinutes": new TextContainerBinding(prefix + "_schedule_end_time_min"),
			"scheduleEnabled": new TextContainerBinding(prefix + "_schedule_status", scheduleStatus),
			"weekMask": new BitMaskTextBinding(prefix + "_schedule_weekMask", WEEK_DAYS)
		})),
		"tcpFlags": new NullBinding(),
		"lastModified": new DateBinding(prefix + "_lastModified"),
		"lastModifyingUsername": new HideShowObjectBinding(prefix + "_lastModified_row", new TextContainerBinding(prefix + "_lastModifyingUsername")),
		"spaces": new NullBinding()
	});
}
