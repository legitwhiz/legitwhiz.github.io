/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

/**
 * Utility function to transform the JSON list-of-lists map into a JS object.
 */
function jsonMapToObj(jsonObj){
	var ret = {};

	//get the value of the only property, whatever its name may be
	//noinspection LoopStatementThatDoesntLoopJS
	for(var key in jsonObj){
		var entryList = jsonObj[key];
		break;
	}

	for(var i=0; i < entryList.length; ++i){
		ret[entryList[i][0]] = entryList[i][1];
	}

	return ret;
}

function setOptions(select, optionMap){
	while(select.firstChild != null){
		select.removeChild(select.firstChild);
	}
	for(var val in optionMap){
		var opt = document.createElement("option");
		opt.setAttribute("value", val);
		opt.appendChild(document.createTextNode(optionMap[val]));
		if(select.firstChild == null){
			//first option
			opt.selected = true;
		}
		select.appendChild(opt);
	}
}

function invert(obj){
	var ret = {};
	for(var key in obj){
		ret[obj[key]] = val;
	}

	return ret;
}