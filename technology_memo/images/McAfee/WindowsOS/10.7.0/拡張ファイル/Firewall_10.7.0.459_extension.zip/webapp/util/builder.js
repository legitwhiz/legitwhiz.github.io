/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

/**
 * Attaches a ListBinding to a Builder
 *
 * @param builder
 */
function ListBindingBuilderAdapter(builder) {
    this.builder = builder;
    this.listBinding = null;

    var self = this;
    this.builder.registerAddListener(function(row) {
        self._addHandler(row);
    });
    this.builder.registerRemoveListener(function(row) {
        self._removeHandler(row);
    });
}

ListBindingBuilderAdapter.prototype._addHandler = function(row) {
	var binding = this.createBinding(row);

	row.binding = binding;
	this.listBinding.addBinding(binding);
};

ListBindingBuilderAdapter.prototype._removeHandler = function(row) {
	this.listBinding.removeBinding(row.binding);
};

ListBindingBuilderAdapter.prototype.addControl = function() {
	this.builder.add();
};

ListBindingBuilderAdapter.prototype.truncate = function(numRows) {
	this.builder.truncate(numRows);
};

/**
 * Override me to create a Binding for a new row.
 *
 * @param row The row to make the binding for.
 */
ListBindingBuilderAdapter.prototype.createBinding = function(row) {
	var container = row.firstChild;
	var control = container.firstChild;
	return new ValueBinding(control.id);
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * A Builder control whose tree manipulation routines can be entirely overridden.  Users will almost certainly 
 * want to provide their own createContent(contentContainer) method.  Validation handlers can be attached to
 * individual form elements there.  If you want to validate cardinality or some other builder-wide property,
 * register add and remove listeners.
 * <p>
 * Data binding is best acomplished via a ListBindingBuilderAdapter, customized to fit your content customizations.
 * The createBinding method of that class recieves a reference to newly created row elements.  By default,
 * row.firstChild is the contentContainer passed to createContent.
 * <p>
 * The properties rowContainerTagName and columnContainerTagName are passed to document.createElement(tagName)
 * when creating rows and columns.  Setting these to "tr" and "td" respectively is all that you need to make the
 * Builder build table rows.
 * <p>
 * The properties addFirstButtonLbl and addFirstButtonClass affect the appearance of the "add first" button, which
 * appears when the builder is empty.
 * <p>
 * Depends on OrionEvent.registerHandler().
 *
 * @param containerId The id of the element that is to contain our rows.  Usually a div, possibly a tbody with
 * appropriate customizations.
 */
function Builder(containerId, isReadOnly) {
    this.containerId = containerId;

	//you can override these string values with things more appropriate to your environment.
    this.addButtonUrl = "/core/images/button/add-button.png";
    this.addButtonClass = "addButton";
    this.removeButtonUrl = "/core/images/button/delete-button.png";
    this.removeButtonClass = "removeButton";

	this.addFirstButtonLbl = "Add";
	this.addFirstButtonClass = "orionButtonEnabled";

	this.rowContainerTagName = "div";
	this.rowContainerClass = "";
	this.columnContainerTagName = "span";
	this.columnContainerClass = "";

	this.buttonContainerClass = "";

	this.contentClass = "";

	this.isReadOnly = isReadOnly;

	this._init();
}

//Subclasses must call this method in their constructor, so that they get their own copies of these values.
Builder.prototype._init = function() {
	this._serialNo = 0;
	this._addListeners = new Array();
	this._removeListeners = new Array();
};

//These methods are the public row creation and removal interface.  They can be used by-value as event handlers.
Builder.prototype.add = function() {
	var row = this._createRow();
	for (var i = 0; i < this._addListeners.length; ++i) {
		this._addListeners[i](row);
	}

    //This code is used on multiple screens. In some screens the first field is a text input field (LocationEdit.jsp), in
    //some screens the text input field is the second field (NamedNetworkEdit.jsp), in some screens the text input field is
    //the third field. The for loop handles all the three cases.
    var index;
    for (i = 0; i < row.firstChild.childNodes.length; i++)
    {
        if ( (document.getElementById(row.firstChild.childNodes[i].id).type) == 'text')
        {
            index = i;
            break;
        }
    }

    OrionCore.focusOn(row.firstChild.childNodes[index].id);
	return row;
};

Builder.prototype.remove = function(orionEvent) {
	var rowId = orionEvent;

	if (typeof orionEvent == 'object') {
		rowId = OrionEvent.getUserProperty(orionEvent);
	}

	this.removeById(rowId);
};

Builder.prototype.truncate = function(numRows) {
	var container = document.getElementById(this.containerId);
	if (container.firstChild.id == this.containerId + "_addFirstButton") {
		return;  //there are no rows, just the add first button
	}
	var toDelete = container.childNodes.length - numRows;

	for (var i = 0; i < toDelete; ++i) {
		var row = container.lastChild;
		this.removeById(row.id);
	}
};

Builder.prototype.clear = function(){
	this.truncate(0);
};

Builder.prototype.removeById = function(rowId) {
	var row = document.getElementById(rowId);
	for (var i = 0; i < this._removeListeners.length; ++i) {
		this._removeListeners[i](row);
	}
	return this._removeRow(rowId);
};

//listeners receive the newly created/deleted row as their single param
Builder.prototype.registerAddListener = function(func) {
	this._addListeners.push(func);
};

Builder.prototype.registerRemoveListener = function(func) {
	this._removeListeners.push(func);
};

Builder.prototype.createAddFirst = function() {
	var btn = document.createElement("input");
	btn.setAttribute("type", "button");
	btn.className = this.addFirstButtonClass;
	btn.id = this.containerId + "_addFirstButton";
	btn.setAttribute("title", this.addFirstButtonLbl);
	btn.setAttribute("value", this.addFirstButtonLbl);

	var self = this;
	var handler = function() {
		self.add();
	};
	OrionEvent.registerHandler(btn, handler, null, "click", true);
	document.getElementById(this.containerId).appendChild(btn);
	OrionCore.setEnabled(btn, !this.isReadOnly);
};

Builder.prototype._removeAddFirst = function() {
	var btn = document.getElementById(this.containerId + "_addFirstButton");
	if (btn != null) {
		document.getElementById(this.containerId).removeChild(btn);
	}
};

Builder.prototype._getAddButton = function() {
	if (this.addButton == null && !this.isReadOnly) {
		this.addButton = document.createElement("img");
		this.addButton.setAttribute("src", this.addButtonUrl);
		this.addButton.className = this.addButtonClass;

		var self = this;
		var handler = function() {
			self.add();
		};
		OrionEvent.registerHandler(this.addButton, handler, null, "click", true);
	}
	return this.addButton;
};

Builder.prototype._getNextId = function() {
	return this.containerId + "_" + (this._serialNo++);
};

Builder.prototype._createRow = function() {
	var row = this.createRowElement(this._getNextId());

	this._removeAddFirst();
	document.getElementById(this.containerId).appendChild(row);
	this.initRow(row);

	return row;
};

/**
 * This method removes the row with the given id, and returns the row element.  It moves the add button
 * if necessary.  It makes assumptions about the dom tree structure.  If you change the tree structure,
 * you'll need to fix this method.
 * @param id The id of the row to remove.
 */
Builder.prototype._removeRow = function(id) {
	var toRemove = document.getElementById(id);
	var parent = toRemove.parentNode;
	//move the add button if it's about to get blown away
	if (!this.isReadOnly && this.addButton.parentNode.parentNode == toRemove) {
		//don't bother if this is the last node
		if (toRemove.previousSibling) {
			toRemove.previousSibling.firstChild.nextSibling.appendChild(this.addButton);
		}
	}
	parent.removeChild(toRemove);
	if (parent.firstChild == null) {
		this.createAddFirst();
	}

	return toRemove;
};


//Row Creation engine ///////////////////////////////////////////////////////////////////////////////////////////////

//noinspection JSUnusedLocalSymbols
Builder.prototype.initRow = function(rowElem) {
	//Do nothing by default.
};

/**
 * This method is responsible for creating, initializing, and return the row element, which is a Div by default.
 * The default implementation calls createRowContent to create the row's children.
 */
Builder.prototype.createRowElement = function(id) {
	var row = document.createElement(this.rowContainerTagName);
	row.id = id;
	row.className = this.rowContainerClass;
	this.createRowContent(row);
	return row;
};

/**
 * This method is responsible for creating everything the row contains, including the buttons.  The default
 * implementation calls createContentElement and createButtonElement, and appends the results to the row.
 * <p>
 * It is suggested that implementors continue to call createButtonElement().
 *
 * @param row The row to append the content elements to.
 */
Builder.prototype.createRowContent = function(row) {
	var content = this.createContentElement();
	row.appendChild(content);

	if(!this.isReadOnly){
		var buttons = this.createButtonElement(row.id);
		row.appendChild(buttons);
	}
};

/**
 * This method is responsible for creating, initializing and returning the content element, which is usually some sort
 * of form control.  By default, it delegates initialization of the container to createContent()
 * <p>
 * Called by createRowContent().  If you override that method, this method may not be called.
 */
Builder.prototype.createContentElement = function() {
	var content = document.createElement(this.columnContainerTagName);
	content.className = this.columnContainerClass;

	this.createContent(content);
	return content;
};

/**
 * This method is responsible for initializing the content element.  By default, it creates a single textarea
 * inside a span.  When overriding this method, be sure to set the id property of each form control to something
 * unique (the return value of getNextId() is a good candidate).  You will almost certainly override this method.
 *
 * Called be createContentElement.
 *
 * @param contentContainer
 */
Builder.prototype.createContent = function(contentContainer) {
	var thing = document.createElement("textarea");
	var id = this._getNextId();
	thing.setAttribute("id", id);
	thing.className = this.contentClass;

	contentContainer.appendChild(thing);
};

/**
 * This method is responsible for creating, initializing, and returning the button element, containing the add
 * and remove buttons.  The add button element should be retrieved by a call to getAddButton().
 * <p>
 * Called by createRowContent().  There should be little need to override this method.
 *
 * @param rowId The id of the row being created.  Useful in remove button event handlers.
 */
Builder.prototype.createButtonElement = function(rowId) {
	if(!this.isReadOnly){
		var buttonContainer = document.createElement(this.columnContainerTagName);
		buttonContainer.className = this.buttonContainerClass;

		var subtract = document.createElement("img");
		subtract.className = this.removeButtonClass;
		subtract.setAttribute("src", this.removeButtonUrl);

		var add = this._getAddButton();

		var self = this;
		var handler = function(id) {
			self.remove(id);
		};
		OrionEvent.registerHandler(subtract, handler, rowId, "click", true);

		buttonContainer.appendChild(subtract);
		buttonContainer.appendChild(add);
		return buttonContainer;
	}else{
		return null;
	}
};

