/*
 * Copyright (C) 2007-2009, McAfee, Inc.  All Rights Reserved.
 */

function readOnlyApplies(obj, depth){
	return isReadOnly() && depth == 0;
}

function writableApplies(obj, depth){
	return !isReadOnly() && depth == 0;
}

function curryRowAction(action){
	return function(rowObj){
		doRowAction(action, rowObj.id);
	};
}

var rowActions = [
		new TreeTableAction(Resource.editButton, curryRowAction("editItem"), writableApplies),
		new TreeTableAction(Resource.viewButton, curryRowAction("viewItem"), readOnlyApplies),
		new TreeTableAction(Resource.duplicateButton, curryRowAction("duplicateItem"), writableApplies),
		new TreeTableAction(Resource.deleteButton, curryRowAction("deleteItem"), writableApplies),
		new TreeTableAction(Resource.exportButton, curryRowAction("exportItem"))
];

MasterColMap["catalogActions"] = new ColSpec("catalogActions", Resource.rowActionHeader, new TreeTableActionRenderer(rowActions));

