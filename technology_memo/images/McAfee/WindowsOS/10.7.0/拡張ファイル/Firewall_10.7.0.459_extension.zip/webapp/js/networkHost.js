OrionForm.setValidateHandler(enableSubmit);

OrionCore.focusOn("ipAddress");

var errorKey = '';

function validatePage() {

    var isValid = validateHost();

    if (isValid < 0) {
        displayError(true);
        enableButtons(false);
    } else {
        displayError(false);
        enableButtons(true);
    }

}

function displayError(isError) {
    document.getElementById('errorText').style.display = 'none';
    if (isError) {
        document.getElementById("errorText").style.display = 'table-row';
    }


}

function enableSubmit(isValid)
{
    OrionCore.setEnabledById("orion.dialog.box.ok", false);
    if (isValid) {
        OrionCore.setEnabledById("orion.dialog.box.ok", true);
    }
}


function validateHost() {

    var ipErr = 0;
    var ipType = document.getElementById("ipType").value;
    var ipValue = document.getElementById("ipAddress").value;

    try {
        var addr = new IpAddress(ipValue);
        var type = addr.getAddrType();
        $("ipType").value = addr;

        if (ipType.toString() != type.toString()) {
            ipErr = -1
        }
    }
    catch(e) {
        ipErr = -1;
        errorKey = e.message;

    }

    validateHost2();
    return ipErr;

}


function networkHostValidation()
{
    OrionCore.setEnabledById('ipAddress', true);
    var ipType = $("ipType").value;

    var valid = false;


    if (ipType == IpAddress.SINGLE)
    {
        valid = (OrionValidate.isValidIPv4String($("ipAddress").value) || OrionValidate.isValidIPv6String($("ipAddress").value));
    } else if (ipType == IpAddress.NETWORK) {
        valid = OrionValidate.isNotEmpty($("ipAddress").value);

    } else if (ipType == IpAddress.LOCAL_SUBNET) {
        $("ipAddress").value = IpAddress.LOCAL_SUBNET_STR;
        OrionCore.setEnabledById('ipAddress', false);
        valid = OrionValidate.isValidIPv4String($("ipAddress").value);

    } else if (ipType == IpAddress.RANGE) {
        valid = (OrionValidate.isValidIPv4AddrGroup($("ipAddress").value) || OrionValidate.isValidIPv6AddrGroup($("ipAddress").value));
    } else if (ipType == IpAddress.TRUSTED) {
        $("ipAddress").value = '[TRUSTED]';
        OrionCore.setEnabledById('ipAddress', false);

        valid = OrionValidate.isNotEmpty($("ipAddress").value);
    } else if (ipType == IpAddress.DOMAIN) {
        valid = isValidDomain($("ipAddress").value);
    } else if (ipType == IpAddress.FQDN) {
        valid = isValidDomain($("ipAddress").value);
    }

    //    if (validateHost2()) {
    //        valid = true;
    //    }


    return valid;
}


validateHost2 = function() {

    var isValid = false;

    var type = $("ipType").value;
    var ipAddr = $("ipAddress").value;
    var ip;
    try {
        if (type == IpAddress.ANY) {
            ip = new IpAddress(IpAddress.ANY_STR);
        } else if (type == IpAddress.TRUSTED) {
            ip = new IpAddress(IpAddress.TRUSTED_STR);
        } else if (type == IpAddress.LOCAL_SUBNET) {
            ip = new IpAddress(IpAddress.LOCAL_SUBNET_STR);
        } else if (type == IpAddress.SINGLE || type == IpAddress.FQDN || type == IpAddress.NETWORK) {
            ip = new IpAddress(ipAddr);
        } else {
            //must be range (but possibly one of the special any values, which are actually ranges)
            ip = new IpAddress(ipAddr);
        }
        ipAddr = ip;


        isValid = (ip.getAddrType() == type);
    } catch(e) {
        ipAddr = null;
        isValid = false;
    }

    return isValid
}

