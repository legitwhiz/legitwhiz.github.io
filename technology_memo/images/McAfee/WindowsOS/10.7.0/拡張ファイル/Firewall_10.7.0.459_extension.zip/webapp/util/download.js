function getIFrame(name){
	var iframe = document.getElementById(name);
	if(iframe == null){
		iframe = document.createElement("iframe");
		iframe.id = name;
		iframe.setAttribute("name", name);
		iframe.style.display = "none";

		var parent = document.getElementsByTagName("body")[0];
		parent.appendChild(iframe);
	}

	return iframe;
}
