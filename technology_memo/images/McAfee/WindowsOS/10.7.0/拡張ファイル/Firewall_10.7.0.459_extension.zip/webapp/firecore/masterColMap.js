/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

var MasterColMap = new Object();

MasterColMap.select = function(availableColumns){
	var ret = new Object();
	for(var i = 0; i < availableColumns.length; ++i){
		ret[availableColumns[i]] = MasterColMap[availableColumns[i]];
	}
	return ret;
};

//decorators
function colorLocationGroups(cell, rowObj){
	if(rowObj.location != null){
		cell.className += " locationAwareCell";
	}
	return cell;
}

function colorAction(cell, rowObj){
	if(rowObj.action == "ALLOW"){
		cell.className += " allowCell";
	} else if(rowObj.action == "BLOCK"){
		cell.className += " blockCell";
	}
	return cell;
}


MasterColMap["name"] = new ColSpec("name", Resource.nameHeader, new CellDecorator(
		new CellDecorator(
				new TwistyCellRenderer(), colorAction),
		colorLocationGroups));

MasterColMap["enabled"] = new ColSpec("enabled", Resource.statusHeader,
		new MapCellRenderer({
			"trueText": Resource.statusEnabled,
			"falseText": Resource.statusDisabled
		},
			null,
			function(value){
				return value + "Text";
			}));

MasterColMap["action"] = new ColSpec("action", Resource.actionHeader, new CellDecorator(new MapCellRenderer({
	"ALLOW": Resource.actionAllow,
	"BLOCK": Resource.actionBlock,
	"JUMP": ""
}), colorAction));

MasterColMap["direction"] = new ColSpec("direction", Resource.directionHeader, new MapCellRenderer({
	"IN": Resource.dirIn,
	"OUT": Resource.dirOut,
	"EITHER": Resource.dirEither
}));

MasterColMap["media"] = new ColSpec("media", Resource.mediaHeader, mediaRenderer);

MasterColMap["localNetworks"] = new ColSpec("localNetworks", Resource.localAddressHeader, networkRenderer);
MasterColMap["remoteNetworks"] = new ColSpec("remoteNetworks", Resource.remoteAddressHeader, networkRenderer);

MasterColMap["localServiceList"] = new ColSpec("localServiceList", Resource.localPortHeader, serviceRenderer);
MasterColMap["localServiceList"].maxLength = 15;
MasterColMap["remoteServiceList"] = new ColSpec("remoteServiceList", Resource.remotePortHeader, serviceRenderer);
MasterColMap["remoteServiceList"].maxLength = 15;

MasterColMap["protocol"] = new ColSpec("protocol", Resource.protocolHeader, protocolRenderer);
MasterColMap["protocol"].netMap = netMap;
MasterColMap["protocol"].transMap = transMap;

MasterColMap["executable"] = new ColSpec("executable",Resource.exeHeader,new MapCellRenderer({
                                "trueText"   : "\u2713",
                                "falseText"    : ""
                            },
                            null,
                            function(value){
                                if(value.length > 0)
                                {
                                    return "trueText";
                                }
                                else
                                {
                                    return "falseText";
                                }
                            }));
MasterColMap["filename"] = new ColSpec("filename", Resource.filenameHeader, filenameRenderer);

MasterColMap["fingerprint"] = new ColSpec("fingerprint", Resource.fingerprintHeader,  new MapCellRenderer({
                                "trueText"   : "\u2713",
                                "falseText"    : ""
                            },
                            null,
                            function(value){
	                            if(value.length > 0 && value != "00000000000000000000000000000000")
                                {
                                    return "trueText";
                                }
                                else
                                {
                                    return "falseText";
                                }
                            }));
MasterColMap["signerName"] = new ColSpec("signerName", Resource.signerNameHeader, new TruncatedCellRenderer(50));
MasterColMap["signature"] = new ColSpec("signature",Resource.exeSignatureHeader,
        new MapCellRenderer({
                                "trueText"   : "\u2713",
                                "falseText"    : ""
                            },
                            null,
                            function(value){
                                if(value.length > 0)
                                {
                                    return "trueText";
                                }
                                else
                                {
                                    return "falseText";
                                }
                            }));
MasterColMap["ruleApplicationNames"] = new ColSpec("applications", Resource.applicationNamesHeader, new ArrayPropertyCellRenderer("name", 50));

MasterColMap["note"] = new ColSpec("note", Resource.noteHeader, new TruncatedCellRenderer(30));
MasterColMap["description"] = new ColSpec("description", Resource.descriptionHeader, new TruncatedCellRenderer(30));

MasterColMap["port"] = new ColSpec("port", Resource.portHeader);

MasterColMap["ipStr"] = new ColSpec("ipStr", Resource.addressHeader, new IpCellRenderer());

MasterColMap["addressValue"]         = new ColSpec("addressValue", Resource.defNetworkHeader, new IpCellRenderer());
MasterColMap["addressType"]     = new ColSpec("addressType",Resource.defNetworkAddrTypeHeader, new TruncatedCellRenderer(30));
MasterColMap["isTrusted"]         = new ColSpec("isTrusted", Resource.defNetworkTrustedHeader, new MapCellRenderer({
			"trueText": Resource.defNetworkIsTrusted,
			"falseText": Resource.defNetworkIsNotTrusted
		},
			null,
			function(value){
				return value + "Text";
			}));

MasterColMap["isolated"] = new ColSpec("isolated", Resource.isolatedHeader,
		new MapCellRenderer({
			"trueText": "X",
			"falseText": ""
		},
			null,
			function(value){
				return value + "Text";
			}));

MasterColMap["requireEpoReachable"] = new ColSpec("requireEpoReachable", Resource.requireEpoReachableHeader,
		new MapCellRenderer({
			"trueText": "X",
			"falseText": ""
		},
			null,
			function(value){
				return value + "Text";
			}));


MasterColMap["inPolicy"] = new ColSpec("inPolicy", Resource.inPolicyHeader,
		new MapCellRenderer({
			"trueText": "X",
			"falseText": ""
		},
			null,
			function(value){
				return value + "Text";
			}));


MasterColMap["inCatalog"] = new ColSpec("inCatalog", Resource.inCatalogHeader,
		new MapCellRenderer({
			"trueText": "X",
			"falseText": ""
		},
			null,
			function(value){
				return value + "Text";
			}));


MasterColMap["className"] = new ColSpec("className", Resource.classNameHeader,
	new MapCellRenderer({
			"com_mcafee_endp_fw_catalog_model_Group": Resource.com_mcafee_endp_fw_catalog_model_Group,
			"com_mcafee_endp_fw_catalog_model_Rule": Resource.com_mcafee_endp_fw_catalog_model_Rule,
			"com_mcafee_endp_fw_catalog_model_Application": Resource.com_mcafee_endp_fw_catalog_model_Application,
			"com_mcafee_endp_fw_catalog_model_Executable": Resource.com_mcafee_endp_fw_catalog_model_Executable,
			"com_mcafee_endp_fw_catalog_model_NamedNetwork": Resource.com_mcafee_endp_fw_catalog_model_NamedNetwork,
			"com_mcafee_endp_fw_catalog_model_Location": Resource.com_mcafee_endp_fw_catalog_model_Location,
			"com_mcafee_endp_fw_catalog_model_ServiceName": Resource.com_mcafee_endp_fw_catalog_model_ServiceName,
			"com_mcafee_endp_fw_catalog_model_FCFWPolicy": Resource.com_mcafee_endp_fw_catalog_model_FCFWPolicy
		}, 
		null,
		function(value){
			return value.replace(/\./g, "_");
		}
	)
);

MasterColMap["ipProtocol"] = new ColSpec("ipProtocol", Resource.protocolHeader, new MapCellRenderer(transMap));
MasterColMap["regKey"] = new ColSpec("regKey", Resource.regKeyHeader, new TruncatedCellRenderer(30));
