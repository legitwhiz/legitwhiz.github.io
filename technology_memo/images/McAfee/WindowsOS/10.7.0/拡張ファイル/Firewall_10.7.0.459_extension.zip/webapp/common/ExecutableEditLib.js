/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

function newExecutableBinding(prefix){
	return new ChainedMapBinding({
		"executable": new ChainedMapBinding({
			"id": new NullBinding(),
			"version": new NullBinding(),
			"@_NodeName": new NullBinding("executable"),
			"name": new ValueBinding(prefix + "_name"),
			"description": new ValueBinding(prefix + "_description"),
			"filename": new FilenameBinding(new ValueBinding(prefix + "_filename")),
			"fingerprint": new FingerprintBinding(prefix + "_fingerprint"),
			"signerName": new SignerNameBinding(prefix + "_signerType_None", prefix + "_signerType_Any", prefix + "_signerType_Specify", prefix + "_signerName"),
			"note": new ValueBinding(prefix + "_note"),
			"lastModified": new DateBinding(prefix + "_lastModified"),
			"lastModifyingUsername": new TextContainerBinding(prefix + "_lastModifyingUsername"),
			"spaces": new NullBinding(),
			"policySettingsId":new NullBinding()
		})
	});
}

function initExecutableEdit(prefix, asyncValidator){
	if(!prefix){
		prefix = "executable";
	}

	var hp = "#" + prefix;

	//autocomplete
	function formatItem(row){
		return "<pre>" + row + "</pre>";
	}

	function selectSpecify(){
		$jq(hp+"_signerType_Specify").click();
	}

	function dnValid(applyValid){
		var value = $jq(hp+"_signerName").val();
		if(dnValid.lastValue != value){
			dnValid.lastValue = value;
			function handler(data, status, req){
				if(data == "true"){
					dnValid.lastResult = true;
					applyValid(true);
				}else{
					dnValid.lastResult = false;
					applyValid(false);
				}
			}

			$jq.ajax({
				data: {"s": value},
				url: "/ENDP_FW_META/ExecutableValidateSignerName.do",
				success: handler
			});
		}else{
			applyValid(dnValid.lastResult);
		}
	}

	asyncValidator.addValidator(prefix+"_signerName", dnValid);

	function revalidateDN(){
		asyncValidator.revalidateAll();
	}

	$jq(hp+"_signerName").autocomplete("/ENDP_FW_META/ExecutableAutocompleteSignerNames.do", {
		matchContains: true,
		max: 80,
		minChars: 2,
		cacheLength: 200,
		formatItem: formatItem
	}).click(selectSpecify).bind("blur keyup focus paste input change select dragdrop mouseout", revalidateDN);

	//require at least one criterion
	function criteriaValid(){
		return executableHasCriteria(prefix);
	}
	OrionForm.addFieldValidators(prefix + "_validationHook", [criteriaValid], prefix + "_missingCriterion");
	OrionForm.setValidateWhenEmpty(prefix + "_validationHook", true);

	return newExecutableBinding(prefix);
}

function executableHasCriteria(prefix){
	var hp = "#" + prefix;
	var desc = $jq.trim($jq(hp + "_description").val());
	var path = $jq.trim($jq(hp + "_filename").val());
	var hash = $jq(hp + "_fingerprint").val();
	var signature="";
	var chk= $jq(hp+"_signerType_None").attr('checked');

	if(chk==true) {
		signature = $jq.trim($jq(hp + "_signerType_container *:radio:checked").val());
	}
	return desc.length > 0 || path.length > 0 || hash.length > 0 || signature.length > 0;
}

function AsyncValidate(){
	this.validMap = {};
	this.validatorMap = {};
	this.validatorCount = 0;
	this.cookie = 0;
	this.resultCount = 0;
	this.resultListeners = [];
	this.errorMap = {};
}

AsyncValidate.prototype.addResultListener = function(func){
	this.resultListeners.push(func);
};

AsyncValidate.prototype.addValidator = function(id, valfunc, errorElemId){
	if(this.validatorMap[id] == null){
		this.validatorMap[id] = [];
	}
	if(!errorElemId){
		errorElemId = id + "_error_async";
	}
	this.errorMap[id] = errorElemId;
	this.validatorMap[id].push(valfunc);
	++this.validatorCount;
	this.reset();
};

AsyncValidate.prototype.setValidators = function(id, validators, errorElemId){
	if(this.validatorMap[id] == null){
		this.validatorMap[id] = [];
	}
	if(!errorElemId){
		errorElemId = id + "_error_async";
	}
	this.errorMap[id] = errorElemId;
	this.validatorMap[id] = validators;
	this.validatorCount += validators.length;
	this.reset();
};

AsyncValidate.prototype.removeValidators = function(id){
	if(this.validatorMap[id] != null){
		this.validatorCount -= this.validatorMap[id].length;
		delete this.validatorMap[id];
		delete this.errorMap[id];
	}
	this.reset();
};

AsyncValidate.prototype.reset = function(){
	for(var id in this.validatorMap){
		this.validMap[id] = [];
		for(var i = 0; i < this.validatorMap[id].length; ++i){
			this.validMap[id].push(null);
		}
	}
	this.resultCount = 0;
	//cookie ensures that if we reset while a validation pass is in progress, it fizzles
	return ++this.cookie;
};

AsyncValidate.prototype.revalidate = function(cookie, id){
	if(this.cookie == cookie){
		var self = this;
		function makeApplyValid(cookie, id, index){
			return function (isValid){
				self.setValid(cookie, id, index, isValid);
			};
		}
		var valfuncs = this.validatorMap[id];
		for(var i = 0; i < valfuncs.length; ++i){
			valfuncs[i](makeApplyValid(cookie, id, i));
		}
	}
};

AsyncValidate.prototype.revalidateAll = function(){
	var cookie = this.reset();
	for(var id in this.validatorMap){
		this.revalidate(cookie, id);
	}
};

AsyncValidate.prototype.setValid = function(cookie, id, index, isValid){
	if(this.cookie == cookie){
		if(this.validMap[id][index] == null && isValid != null){
			++this.resultCount;
		}
		var wasValid = this.validMap[id][index];
		this.validMap[id][index] = isValid;
		if(isValid){
			$jq("#"+this.errorMap[id]).hide();
		}else{
			$jq("#"+this.errorMap[id]).show();
		}
		if((wasValid != isValid) && this.resultCount == this.validatorCount){
			this.deliverResults();
		}
	}
};

AsyncValidate.prototype.deliverResults = function(){
	var allAreValid = true;
	for(var id in this.validMap){
		for(var i = 0; allAreValid && i < this.validMap[id].length; ++i){
			allAreValid = allAreValid && this.validMap[id][i];
		}
		if(!allAreValid){
			break;
		}
	}

	for(i = 0; i < this.resultListeners.length; ++i){
		this.resultListeners[i](allAreValid);
	}
};
