var paramMap = [];
var editInProgress = "${fwRuleEditInProgress}";

function setEditInProgress(inProgress)
{
    editInProgress = inProgress;
}

function execute()
{
    if ("fnDoNetworkDelete" == infoObject.okHandler)
    {
        NETWORKS.fnDoNetworkDelete(infoObject.objectId);
    }
    else if ("fnAddNetworkToCatalog" == infoObject.okHandler)
    {
        NETWORKS.fnAddNetworkToCatalog(infoObject.objectId);
    }
    else if ("fnDoNetworkBreak" == infoObject.okHandler)
    {
        NETWORKS.fnDoNetworkBreak(infoObject.objectId);
    }
    else if ("fnDoApplicationDelete" == infoObject.okHandler)
    {
        fnDoApplicationDelete(infoObject.objectId);
    }
    else if ("fnAddAppToCatalog" == infoObject.okHandler)
    {
        fnAddAppToCatalog(infoObject.objectId);
    }
    else if ("fnDoAppBreak" == infoObject.okHandler)
    {
        fnDoAppBreak(infoObject.objectId);
    }
    else if ("fnNavigate" == infoObject.okHandler)
    {
        fnNavigate();
    }
    else if ("fnAddLocationToCatalog" == infoObject.okHandler)
    {
        LOCATION.fnAddLocationToCatalog(infoObject.objectId);
    }
    else if ("fnDoBreak" == infoObject.okHandler)
    {
        LOCATION.fnDoBreak(infoObject.objectId);
    }
}

function fnNavigate()
{
    OrionCore.showPleaseWait(false);
}

function fnOnCancel()
{
    OrionCore.showPleaseWait(false);
}

function fnPopulateParamMap()
{
    TRANSPORT.populateParamMap(paramMap);
}

function fnOnStateChangeHandler(isDirty, isValid)
{
    var networkIpOk = validateNetworkIp();
    var mediaOk = validateMedia();
    var scheduleOk = validateSchedule();
    if(editInProgress)
    {
        isDirty = true;
    }

    if (networkIpOk && mediaOk && scheduleOk && isDirty && isValid)
    {
        OrionCore.setEnabledById("saveButton", true);
    }
    else
    {
        OrionCore.setEnabledById("saveButton", false);
    }
}

