/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

/**
 * Use maxlength=50 instead.
 * @param name
 */
function validName(name)
{
    return validName.re.test(name);
}
validName.re = /^.{0,50}$/;

function validMD5(str)
{
    return validMD5.re.test(str);
}
validMD5.re = /^[0-9a-fA-F]{32}$/;

/**
 * Use maxlength=50 instead.
 * @param name
 */
function validSigner(str)
{
    return validSigner.re.test(str);
}
validSigner.re = /^.{0,1024}$/;

/**
 * You could probably curry this to make it work with the Orion validation framework, and register the curried
 * function with each of the fields.  But it's an awkward fit.  Validation for hosts depends on the coorelation of
 * several fields, which the Orion validation framework simply doesn't support natively.
 * @param typeSelect
 * @param addrStart
 * @param addrEnd
 */
function validHost(typeSelect, addrStart, addrEnd)
{
    var type = typeSelect.value;
    var ip;
    try
    {
        if (type == IpAddress.ANY) {
            ip = new IpAddress(IpAddress.ANY_STR);
        } else if (type == IpAddress.TRUSTED) {
            ip = new IpAddress(IpAddress.TRUSTED_STR);
        }
        else if (type == IpAddress.ANY_LOCAL_IP) {
            ip = new IpAddress(IpAddress.ANY_LOCAL_IP_STR);
        }
        else if (type == IpAddress.LOCAL_SUBNET) {
            ip = new IpAddress(IpAddress.LOCAL_SUBNET_STR);
        } else if (type == IpAddress.SINGLE || type == IpAddress.NETWORK) {
            ip = new IpAddress(addrStart.value);
        } else if (type == IpAddress.FQDN) {
            if (!FQDNValidator(addrStart.value)) {
                return false
            } else {
                ip = new IpAddress(addrStart.value);
            }
        }
        else {
            //must be range (but possibly one of the special any values, which are actually ranges)
            ip = new IpAddress(addrStart.value + "-" + addrEnd.value);
        }
        typeSelect.ip = ip;

        return ip.getAddrType() == type;
    } catch (e)
    {
        typeSelect.ip = null;
        return false;
    }
}

/**
 * IntegerRangeSets are used for service lists.  Of the form "1-3, 7, 12-23".
 * @param value
 */
function validateIntegerRangeSet(value)
{
    return validateIntegerRangeSet.re.test(value);
}
validateIntegerRangeSet.re = /^\s*(?:(?:\d+(?:\s*-\s*\d+\s*)?)\s*,\s*)*(?:\d+\s*(?:\s*-\s*\d+)?)\s*$/;

/**
 * Validates a simple IP field, without type constraint.
 * @param value
 */
function validateIp(value)
{
    try
    {
        new IpAddress(value);
        return true;
    } catch (e)
    {
        return false;
    }
}

/**
 * Validates that the input is a plausible DNS suffix string
 * @param value
 */
function dnsSuffixValidator(value)
{
    var dnsSuffixPattern = /^(?:[a-zA-Z0-9\*\?](?:[-a-zA-Z0-9\*\?]{0,61}[a-zA-Z0-9\*\?])?\.){1,255}(?:[a-zA-Z0-9\*\?][-a-zA-Z0-9\*\?]{0,61}[a-zA-Z\*\?]|\*)\.?$/;
    if ((value.length > 255) || (value.length == 0))
    {
        return false;
    }
    return dnsSuffixPattern.test(value);
}

/**
 * Validates that the input is a FQDN string
 * @param value
 */
function FQDNValidator(value)
{
    var dnsSuffixPattern = /^(?:[a-zA-Z0-9](?:[-a-zA-Z0-9]{0,61}[a-zA-Z0-9])?\.){1,255}(?:[a-zA-Z0-9][-a-zA-Z0-9]{0,61}[a-zA-Z])\.?$/;
    if (value.length > 255)
    {
        return false;
    }
    return dnsSuffixPattern.test(value);
}


/**
 * Validates that value represents an IP address of Single type.
 * @param value
 */
function singleIpValidator(value)
{
    try
    {
        var ip = new IpAddress(value);
        return ip.getAddrType() == IpAddress.SINGLE;
    } catch (e)
    {
        return false;
    }
}

/**
 * Validate that the value is numeric and in a range.  Curry this with its first three params.
 * @param base The base for the string representation of the number.
 * @param min Minimum value, inclusive.
 * @param max Maximum value, inclusive.
 * @param value
 */
function numericValidator(base, min, max, value)
{
    var num = parseInt(value, base);
    return min <= num && num <= max;  //false on parse error
}

function decimalValidator(min, max, value)
{
    if (!/^\d+$/.test(value))
    {
        return false;
    }
    return numericValidator(10, min, max, value);
}

function hexValidator(min, max, value)
{
    if (!/^[a-fA-F0-9]+$/.test(value))
    {
        return false;
    }
    return numericValidator(16, min, max, value);
}

function regKeyValidator(value)
{
    var parts = value.split("\\");
    var foundRoot = false;
    for (var i = 0; i < regKeyValidator.ROOTS.length; ++i)
    {
        if (regKeyValidator.ROOTS[i] == parts[0].toUpperCase())
        {
            foundRoot = true;
            break;
        }
    }
    if (!foundRoot)
    {
        //root key is not on allowed list
        return false;
    }
    var key = parts.slice(1, parts.length - 1).join("\\");
    if (key == "" || key.indexOf("=") >= 0 || key.indexOf("\\\\") >= 0)
    {
        //bad key path
        return false;
    }
    if (parts[parts.length - 1].indexOf("=") >= 0)
    {
        //there's an equals sign in the value name; no good
        return false;
    }
    return true;
}
regKeyValidator.ROOTS = ["HKEY_CLASSES_ROOT", "HKEY_CURRENT_CONFIG", "HKEY_CURRENT_USER", "HKEY_LOCAL_MACHINE", "HKEY_USERS"];
