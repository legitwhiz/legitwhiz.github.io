/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

function setLocationCriteriaNames(nameMap){
	return function locationGetChildren(rowObj){
		if(rowObj.children == null && rowObj.name != null){
			//rowObj is a Location.  Build its virtual child array.
			var newChildren = new Array();

			function appendVirtualChild(propName, array){
				if(rowObj[propName] != null && rowObj[propName].length > 0){
					var virtualChild = new Object();
					virtualChild.children = rowObj[propName];
					virtualChild.name = nameMap[propName];
					array.push(virtualChild);
				}
			}
			function appendVirtualStringChild(propName, array, key){
				if(rowObj[propName] != null && rowObj[propName].length > 0){
					var virtualChild = new Object();
					virtualChild.children = new Array();
					for(var i = 0; i < rowObj[propName].length; ++i){
						var newChild = new Object();
						newChild[key] = rowObj[propName][i];
						virtualChild.children.push(newChild);
					}
					virtualChild.name = nameMap[propName];
					array.push(virtualChild);
				}
			}
			safeSortAndReturn(rowObj["defaultGateway"], hostComparator);
			appendVirtualChild("defaultGateway", newChildren);
			safeSortAndReturn(rowObj["dhcpServer"], hostComparator);
			appendVirtualChild("dhcpServer", newChildren);
			safeSortAndReturn(rowObj["dnsServer"], hostComparator);
			appendVirtualChild("dnsServer", newChildren);
            safeSortAndReturn(rowObj["dnsSuffix"]);
            appendVirtualStringChild("dnsSuffix", newChildren, "ipStr");
            safeSortAndReturn(rowObj["domainReachable"]);
            appendVirtualStringChild("domainReachable", newChildren, "ipStr");
            safeSortAndReturn(rowObj["primaryWins"], hostComparator);
			appendVirtualChild("primaryWins", newChildren);
			safeSortAndReturn(rowObj["secondaryWins"], hostComparator);
			appendVirtualChild("secondaryWins", newChildren);
			safeSortAndReturn(rowObj["regKeys"]);
			appendVirtualStringChild("regKeys", newChildren, "regKey");
			if(newChildren.length > 0){
				rowObj.children = newChildren;
			}
		}
		return rowObj.children;
	};
}
