/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

//This library depends on YUI.  You need the event and dragdrop modules.
//The only Orion dependency is OrionCore.setEnabledById.

var UP_ARROW = '\u25b2';
var RIGHT_ARROW = '\u25ba';
var DOWN_ARROW = '\u25bc';
var LEFT_ARROW = '\u25c4';

var EXPANDED_CHAR = DOWN_ARROW;
var CONTRACTED_CHAR = RIGHT_ARROW;

/**
 * bindingCore integration for TreeTable.
 *
 * @param tree The TreeTable to bind to.
 * @param rowComparator Optional.  If specified, it will be used to sort the rows of the tree.
 */
function TreeTableListBinding(tree, rowComparator)
{
    this.tree = tree;
    this.comparator = rowComparator;
}

TreeTableListBinding.prototype.getValue = function ()
{
    return this.tree.getRowData();
};

TreeTableListBinding.prototype.setValue = function (value)
{
    var rows = TreeTable.deepCopy(value);
    if (!!this.comparator)
    {
        rows.sort(this.comparator);
    }
    this.tree.setRowData(rows);
};

/**
 * ColSpec describes how to render a particular column.  TreeTable's constructor will set the "tree"
 * property of each ColSpec to reference itself.
 *
 * @param id The column's id, which is used to refer to the column elsewhere.  Should be a valid identifier.
 * @param label A string to display as the column header.
 * @param cellRenderer A CellRenderer.  Defaults to the basic CellRenderer implementation.
 * This function becomes a method of this ColSpec object.
 */
function ColSpec(id, label, cellRenderer)
{
    this.id = id;
    this.label = label;
    if (cellRenderer == null)
    {
        cellRenderer = new CellRenderer();
    }
    this.renderer = cellRenderer;  //function that takes the row's data object as a param and returns a TD element.
    this.tree = null; //set by the TreeTable's constructor
}

ColSpec.prototype.getCell = function (rowObj, depth)
{
    return this.renderer.makeCell(rowObj, this.tree, this.id, depth);
};


/**
 * TreeTable is the core tree table class.  It renders the tree table, manages its data structures,
 * and handles events.
 *
 * @param id The id of the element to contain the TreeTable.  A Table element (and children) will be created
 * within the specified element.
 * @param colMap A map of the form {"id", new ColSpec("id", "Label For ID", function()...}.  Describes the columns
 * the table can render.
 * @param colList The ordered list of column IDs to render.  constructTable must be called if you change this
 * property after construction.
 * @param rowData The list of objects to display in the table.  May be omitted and set later with setRowData.
 * Children must be listed in array properties named "children", unless you override the TreeTable.getChildren method.
 * This structure has the form:
 * <pre>
 * [
 *   {
 *     name: "leaf object",
 *     value: "value 1"
 *   },
 *   {
 *     name: "parent object",
 *     value: "value 2",
 *     children: [
 *       {
 *         name: "child leaf object",
 *         value: "value 3"
 *       }
 *     ]
 *   }
 * }
 * </pre>
 */
function TreeTable(id, colMap, colList, rowData, enableDragDrop, enableSelect, sortColumnId, sortAscending, sortableColumns, sortCallback)
{
    this.id = id;
    this.colMap = TreeTable.deepCopy(colMap);
    for (var key in this.colMap)
    {
        this.colMap[key].tree = this;
    }

    this.colList = colList;
    this.rowData = rowData;
    this.enableDragDrop = !!enableDragDrop;
    this.enableSelect = !!enableSelect;
    this.sortColumnId = sortColumnId;
    this.sortableColumns = sortableColumns;
    this.sortCallback = sortCallback;
    this.sortAscending = sortAscending;

    this.selectListeners = new Array();
    this.changeListeners = new Array();
}

TreeTable.IS_EXPANDED = "_isExpanded";
TreeTable.IS_SELECTED = "_isSelected";
TreeTable.viewOnlyRowSelectedCounter = 0;

/**
 * Sets the row data for the TreeTable, and (re-)constructs the table.
 * @param rowData
 */
TreeTable.prototype.setRowData = function (rowData)
{
    this.rowData = rowData;
    this.constructTable();
};

/**
 * @return a sanitized deep-copy of the rowData.
 */
TreeTable.prototype.getRowData = function ()
{
    return TreeTable.sanitize(this.rowData);
};

/**
 * @return a list of all available column IDs.  Used by column picker integration.
 */
TreeTable.prototype.getAvailableColumns = function ()
{
    var colIds = TreeTable.keysOfObj(this.colMap);

    colIds.sort();
    return colIds;
};

TreeTable.prototype.getColumnLabels = function (colIds)
{
    var ret = [];
    for (var i = 0; i < colIds.length; ++i)
    {
        ret.push(this.colMap[colIds[i]].label);
    }
    return ret;
};

TreeTable.keysOfObj = function (obj)
{
    var ret = [];
    for (var name in obj)
    {
        ret.push(name);
    }
    return ret;
};

/**
 * @return the ordered list of display columns.
 */
TreeTable.prototype.getColList = function ()
{
    return this.colList;
};

/**
 * Registers a callback to be called whenever the selection state changes.
 * @param callback function(selection, tree) to be called when selection state changes.
 */
TreeTable.prototype.registerSelectListener = function (callback)
{
    this.selectListeners.push(callback);
};

TreeTable.prototype.notifySelectListeners = function ()
{
    if (this.selectListeners.length > 0)
    {
        var selection = this.getSelection();
        for (var i = 0; i < this.selectListeners.length; ++i)
        {
            this.selectListeners[i](selection, this);
        }
    }
};

/**
 * Registers a callback to be notified when something is inserted into or deleted from the tree.  This
 * includes move up/down, duplicate and what have you.
 * @param callback function(tree) that will be called on insert and delete.
 */
TreeTable.prototype.registerChangeListener = function (callback)
{
    this.changeListeners.push(callback);
};

TreeTable.prototype.notifyChangeListeners = function ()
{
    if (this.changeListeners.length > 0)
    {
        for (var i = 0; i < this.changeListeners.length; ++i)
        {
            this.changeListeners[i](this);
        }
    }
};

/**
 * (Re-)construct the entire table.  rowData must be set (via the constructor or the setter) before calling this.
 */
TreeTable.prototype.constructTable = function ()
{
    if (this.rowData == null)
    {
        throw new Error("rowData not set");
    }
    var container = document.getElementById(this.id);
    while (container.hasChildNodes())
    {
        container.removeChild(container.firstChild);
    }

    var table = document.createElement("table");
    table.className = "treeTable";

    var thead = this.constructHead();

    var tbody = document.createElement("tbody");
    tbody.id = this.id + "Body";
    tbody.className = "tableContentBody";

    var rows = this.makeRows(this.rowData);
    for (var i = 0; i < rows.length; ++i)
    {
        tbody.appendChild(rows[i]);
        if (i % 2 != 0)
        {
            rows[i].className = "orionTableRowAlt";
        }
    }

    table.appendChild(thead);
    table.appendChild(tbody);

    container.appendChild(table);
};

TreeTable.prototype.constructHead = function ()
{
    var thead = document.createElement("thead");
    var tr = document.createElement("tr");
    if (this.enableDragDrop)
    {
        tr.appendChild(document.createElement("th"));
    }
    var i;
    for (i = 0; i < this.colList.length; ++i)
    {
        var colId = this.colList[i];
        var colSpec = this.colMap[colId];
        var th = document.createElement("th");
        th.id = colId + "Header";
        th.appendChild(document.createTextNode(colSpec.label));

        if (this.sortColumnId)
        {
            function sortHandler(tree, evt, elem)
            {
                tree.setSortColumnId(elem.colId);
            }

            th.colId = colId;
            if (colId == this.sortColumnId)
            {
                if (this.sortAscending)
                {
                    th.className = "sortedColumnAscending";
                    th.appendChild(document.createTextNode(" " + DOWN_ARROW));
                } else
                {
                    th.className = "sortedColumnDescending";
                    th.appendChild(document.createTextNode(" " + UP_ARROW));
                }
                YAHOO.util.Event.addListener(th, "click", this.bindHandler(sortHandler, th));
            } else if (this.isSortable(colId))
            {
                th.className = "sortableColumn";
                YAHOO.util.Event.addListener(th, "click", this.bindHandler(sortHandler, th));
            }
        }

        tr.appendChild(th);
    }
    thead.appendChild(tr);
    return thead;
};

TreeTable.prototype.replaceHead = function ()
{
    var tableElem = document.getElementById(this.id).firstChild;
    tableElem.replaceChild(this.constructHead(), tableElem.firstChild);
};

TreeTable.prototype.setSortColumnId = function (sortColumnId)
{
    if (!this.isSortable(sortColumnId))
    {
        throw new Error("Cannot sort on column " + sortColumnId);
    }
    if (this.sortColumnId == sortColumnId)
    {
        this.sortAscending = !this.sortAscending;
    } else
    {
        this.sortAscending = true;
    }
    this.sortColumnId = sortColumnId;
    this.replaceHead();
    if (this.sortCallback)
    {
        this.sortCallback(this.sortColumnId, this.sortAscending);
    }
};

TreeTable.prototype.getSortColumnId = function ()
{
    return this.sortColumnId;
};

TreeTable.prototype.isSortable = function (colId)
{
    if (this.sortableColumns != null)
    {
        for (var i = 0; i < this.sortableColumns.length; ++i)
        {
            if (this.sortableColumns[i] == colId)
            {
                return true;
            }
        }
        return false;
    }
    return this.sortColumnId != null;
};

/**
 * Return an array of rows (tr elements) for a given list of row objects, rendered appropriately for a given depth.  Calls itself
 * recursively to render expanded children.  Called by constructTable, as well as insert.
 *
 * @param rowData The array of row objects to render.
 * @param depth The current depth in the tree.  Root is 0, and is assumed if depth is not specified.
 */
TreeTable.prototype.makeRows = function (rowData, depth)
{
    if (depth == null)
    {
        depth = 0;
    }
    var ret = new Array();
    for (var i = 0; i < rowData.length; ++i)
    {
        var rowObj = rowData[i];
        ret.push(this.makeRow(rowObj, depth));
        if (rowObj[TreeTable.IS_EXPANDED])
        {
            ret = ret.concat(this.makeRows(this.getChildren(rowObj), depth + 1));
        }
    }

    return ret;
};

/**
 * Returns an individual row (tr element) for a particular row object, at a particular depth.  Called by makeRows.
 *
 * @param rowObj The object to render.
 * @param depth The indentation depth.
 */
TreeTable.prototype.makeRow = function (rowObj, depth)
{
    var tr = document.createElement("tr");
    var cols = this.makeColumns(rowObj, depth);
    for (var j = 0; j < cols.length; ++j)
    {
        tr.appendChild(cols[j]);
    }
    if (this.enableDragDrop  && (rowObj.viewonly == false))
    {
        this.configDragDrop(tr);
    }
    if (rowObj[TreeTable.IS_SELECTED])
    {
        TreeTable.setClassName(tr, "orionTableCellSelected", true);
        tr.isSelected = true;
    }
    return tr;
};

/**
 * You may override this method to customize the drag and drop behavior.
 *
 * @param tr
 */
TreeTable.prototype.configDragDrop = function (tr)
{
    YAHOO.util.DDM.mode = YAHOO.util.DDM.INTERSECT;
    tr.ddObj = new TreeTable.TreeDD(tr, this.id + "_ddGroup", {
        tree:this
    });
};

TreeTable.TreeDD = function (elem, sGroup, config)
{
    this.tree = config.tree;
    TreeTable.TreeDD.superclass.constructor.apply(this, arguments);
    var handleId = YAHOO.util.Event.generateId(elem.firstChild);
    this.setHandleElId(handleId);
};

YAHOO.extend(TreeTable.TreeDD, YAHOO.util.DDProxy, {
    tree:null,
    init:function ()
    {
        //Call the parent's init method
        TreeTable.TreeDD.superclass.init.apply(this, arguments);
        this.setXConstraint(0, 0);
    },
    initConstraints:function ()
    {
        //Get the element we are working on
        var elem = this.getEl();

        //Get the top, right, bottom and left positions
        var region = YAHOO.util.Dom.getRegion(elem.parentNode);

        //Get the y position of elem
        var y = YAHOO.util.Dom.getY(elem);

        //Set top to y minus top
        var top = y - region.top;

        //Get the height
        var elemRegion = YAHOO.util.Dom.getRegion(elem);
        var height = elemRegion.bottom - elemRegion.top;

        //Set bottom to bottom minus y minus height
        var bottom = region.bottom - y - height;

        //Set the constraints based on the above calculations
        this.setYConstraint(top, bottom);
    },
    getDDM:function ()
    {
        return YAHOO.util.DDM;
    },
    getBestMatch:function (dds)
    {
        //return the bottom of the first two candidate objects.  In effect, drop "between" the two.
        if (dds.length == 1)
        {
            return dds[0];
        } else
        {
            var index0 = this.tree.rowToIndex(dds[0].getEl());
            var index1 = this.tree.rowToIndex(dds[1].getEl());
            if (index0 > index1)
            {
                return dds[0];
            } else
            {
                return dds[1];
            }
        }
    },
    onDragDrop:function (e, ddObjs)
    {
        var id = this.getBestMatch(ddObjs).id;
        var targetRow = document.getElementById(id);
        var srcRow = this.getEl();
        if (targetRow == null)
        {
            this.getDDM().stopDrag(null, true);
            throw new Error("targetRow is null. id = " + id);
        }
        if (srcRow == null)
        {
            this.getDDM().stopDrag(null, true);
            throw new Error("srcRow is null.  this.id = " + this.id);
        }

        var tree = this.tree;
        var targetPath = tree.rowToPath(targetRow);
        var srcPath = tree.rowToPath(srcRow);
        if (targetPath == null)
        {
            this.getDDM().stopDrag(null, true);
            throw new Error("targetPath is null. id = " + id);
        }
        if (srcPath == null)
        {
            this.getDDM().stopDrag(null, true);
            throw new Error("srcPath is null.  this.id = " + this.id);
        }

        //is target writable?
        if (tree.isWritable(targetPath))
        {

            //decide if we're moving up or down
            var diff = tree.pathCompare(srcPath, targetPath);
            var obj;
            if (diff > 0)
            {
                //moving up, remove and insert
                obj = tree.remove(srcPath);
                tree.insert(obj, targetPath);
            } else if (diff < 0)
            {
                if (tree.pathCompare(srcPath, targetPath.slice(0, srcPath.length)) == 0)
                {
                    //Ack!  Attempt to become our own child.
                    return;
                }
                //moving down
                obj = tree.remove(srcPath);

                //we may have to modify the insert path after remove, because indicies change.
                if (srcPath.length <= targetPath.length)
                {
                    if (tree.pathCompare(srcPath.slice(0, srcPath.length - 1), targetPath.slice(0, srcPath.length - 1)) == 0)
                    {
                        targetPath[srcPath.length - 1] -= 1;
                    }
                }
                tree.insert(obj, targetPath);
            }
            //if diff == 0, do nothing
            dragDropUpdate();
        }
        //target not writable, do nothing
    },
    startDrag:function ()
    {
        this.initConstraints();
    },
    endDrag:function ()
    {
        var srcRow = this.getEl();
        YAHOO.util.Dom.setStyle(srcRow, "position", "");
        YAHOO.util.Dom.setStyle(srcRow, "top", "");
        YAHOO.util.Dom.setStyle(srcRow, "left", "");
        if (this.overElem)
        {
            YAHOO.util.Dom.setStyle(this.overElem, "border-top", "");
            delete this.overElem;
        }
    },
    b4MouseDown:function ()
    {
        TreeTable.TreeDD.superclass.b4MouseDown.apply(this, arguments);
        this.resetConstraints();
    },
    onDragOver:function (e, ddObjs)
    {
        var dd = this.getBestMatch(ddObjs);
        var elem = dd.getEl();
        if (this.overElem != elem)
        {
            if (this.overElem)
            {
                YAHOO.util.Dom.setStyle(this.overElem, "border-top", "");
            }
            YAHOO.util.Dom.setStyle(elem, "border-top", "1px solid red");
            this.overElem = elem;
        }
    }
});

/**
 * Users may override this method to implement different logic for child list retrieval.
 *
 * @param rowObj
 */
TreeTable.prototype.getChildren = function (rowObj)
{
    return rowObj.children;
};

/**
 * Path comparator.  The moral equivalent of left - right.
 *
 * @param left
 * @param right
 */
TreeTable.prototype.pathCompare = function (left, right)
{
    for (var i = 0; i < left.length && i < right.length; ++i)
    {
        var diff = left[i] - right[i];
        if (diff != 0)
        {
            return diff;
        }
    }
    return left.length - right.length;
};

/**
 * Invokes the column renderers for the individual columns in a row.  Returns an array of the results
 * (generally td elements).
 *
 * @param rowObj The object to be rendered.
 * @param depth The tree depth at which to render the object.
 */
TreeTable.prototype.makeColumns = function (rowObj, depth)
{
    var ret = new Array();

    if (this.enableDragDrop)
    {
        //make drag handle
        var handleTd = document.createElement("td");
        var img = document.createElement("img");
        img.src = "/ENDP_FW_META/util/handle.gif";
        img.width = 13;
        img.height = 17;

        handleTd.style.textIndent = "0px";
        handleTd.appendChild(img);

        if (this.enableSelect)
        {
            this.addListener(handleTd, "mousedown", TreeTable.onCellClick, false);
        }
        ret.push(handleTd);
    }

    for (var i = 0; i < this.colList.length; ++i)
    {
        var colSpec = this.colMap[this.colList[i]];
        var td = colSpec.getCell(rowObj, depth);
        if (this.enableSelect)
        {
            this.addListener(td, "mousedown", TreeTable.onCellClick, false);
        }
        ret.push(td);
    }
    return ret;
};

/**
 * Expands or contracts a row in response to a twisty-click.
 *
 * @param row The row to toggle expansion of.
 */
TreeTable.prototype.expandContract = function (row)
{
    var path = this.objToPath(this.rowToObj(row));
    var rowObj = this.remove(path);
    rowObj[TreeTable.IS_EXPANDED] = !rowObj[TreeTable.IS_EXPANDED];
    if (this.clearSelection(rowObj))
    {
        this.notifySelectListeners();
    }
    this.insert(rowObj, path);
};

/**
 * Clears a selection on the specified sub-tree.  Operates on row data only; the select state in the
 * related rows (if any) is now out of sync.
 * @param rowObj  The sub-tree to clear.  Null for the whole tree.
 * @return true if and only if the select state of at least one row object changed.
 */
TreeTable.prototype.clearSelection = function (rowObj)
{
    var selectionChanged = false;
    var childList;
    if (rowObj)
    {
        if (rowObj[TreeTable.IS_SELECTED])
        {
            selectionChanged = true;
            rowObj[TreeTable.IS_SELECTED] = false;
        }
        if (rowObj[TreeTable.IS_EXPANDED])
        {
            childList = this.getChildren(rowObj);
        } else
        {
            childList = null;
        }
    } else
    {
        childList = this.rowData;
    }

    if (childList)
    {
        for (var i = 0; i < childList.length; ++i)
        {
            if (this.clearSelection(childList[i]))
            {
                selectionChanged = true;
            }
        }
    }

    return selectionChanged;
};

/**
 * Returns this TreeTable's tbody element.
 */
TreeTable.prototype.getBody = function ()
{
    return document.getElementById(this.id + "Body");
};

/**
 * Curries a function func(tree, evt) -> func(evt), binding it to this tree.
 *
 * @param func The function to curry.  Must accept a TreeTable parameter as its first argument.
 */
TreeTable.prototype.bindHandler = function (func, elem)
{
    var self = this;
    return function (evt)
    {
        func(self, evt, elem);
    };
};

/**
 * Binds an event handler to this tree and registers it with the specified element.
 *
 * @param elem The element to register the event handler on.
 * @param type The event type to handle.
 * @param handler A function of the form function(tree, evt, elem) to be used as the event handler.
 */
TreeTable.prototype.addListener = function (elem, type, handler)
{
    YAHOO.util.Event.addListener(elem, type, this.bindHandler(handler, elem));
};

TreeTable.prototype.indexToObj = function (index)
{
    if (index == null)
    {
        return null;
    }
    return this.indexToObjImpl(index)[0];
};

/**
 * DFS with a step limit.  Non-expanded children are ignored.
 * @param stopAt The step limit
 * @param list The list to search.
 * @return [obj, stepsSoFar]
 */
TreeTable.prototype.indexToObjImpl = function (stopAt, list)
{
    if (list == null)
    {
        list = this.rowData;
    }
    var childNodesTraversed = 0;
    var i;
    var obj = null;
    for (i = 0; (i + childNodesTraversed) < stopAt && i < list.length; ++i)
    {
        if (list[i][TreeTable.IS_EXPANDED])
        {
            var response = this.indexToObjImpl(stopAt - (i + childNodesTraversed + 1), this.getChildren(list[i]));
            obj = response[0];
            childNodesTraversed += response[1];
        }
    }
    if (obj != null)
    {
        //successful sub-search
        return [obj, i + childNodesTraversed];
    } else if (i + childNodesTraversed == stopAt)
    {
        //reached step limit.  Is i valid?
        if (i < list.length)
        {
            //Yes.  Successful search
            return [list[i], i + childNodesTraversed];
        } else
        {
            //No.  Unsuccessful search
            return [null, i + childNodesTraversed];
        }
    } else
    {
        //ran out of elements before we hit the step limit. Unsuccessful search.
        return [null, i + childNodesTraversed];
    }
};

TreeTable.prototype.indexToPath = function (index)
{
    if (index == null)
    {
        return null;
    }
    return this.objToPath(this.indexToObj(index));
};

TreeTable.prototype.indexToRow = function (index)
{
    if (index == null)
    {
        return null;
    }
    return this.getBody().childNodes[index];
};


TreeTable.prototype.objToIndex = function (rowObj)
{
    if (rowObj == null)
    {
        return null;
    }
    var result = this.objToIndexImpl(rowObj);
    if (result[1])
    {
        return result[0];
    } else
    {
        return null;
    }
};

/**
 * Depth-first recursive search of list for rowObj.  We don't search children if the parent is not expanded.
 *
 * @param rowObj  The object to search for.
 * @param list  The list to search recursively.  defaults to this.rowData if omitted.
 * @return [integer numSteps, boolean foundObj]
 */
TreeTable.prototype.objToIndexImpl = function (rowObj, list)
{
    if (list == null)
    {
        list = this.rowData;
    }
    var childNodesTraversed = 0;
    var foundObj = false;
    for (var i = 0; !foundObj && i < list.length; ++i)
    {
        if (list[i] == rowObj)
        {
            foundObj = true;
            break; //don't increment i
        } else if (list[i][TreeTable.IS_EXPANDED])
        {
            var result = this.objToIndexImpl(rowObj, this.getChildren(list[i]));
            childNodesTraversed += result[0];
            if (result[1])
            {
                foundObj = true;
            }
        }
    }
    //caller needs to know childNodesTraversed for unsuccessful search, and that the search was unsuccessful.
    return [childNodesTraversed + i, foundObj];
};

TreeTable.prototype.objToPath = function (rowObj, list, path)
{
    if (rowObj == null)
    {
        return null;
    }
    //depth-first recursive search
    if (path == null)
    {
        path = new Array();
    }
    if (list == null)
    {
        list = this.rowData;
    }
    for (var i = 0; i < list.length; ++i)
    {
        if (list[i] == rowObj)
        {
            return path.concat(i);
        } else if (list[i][TreeTable.IS_EXPANDED])
        {
            var ret = this.objToPath(rowObj, this.getChildren(list[i]), path.concat(i));
            if (ret != null)
            {
                //found it, we're done
                return ret;
            }
        }
    }
    return null;
};

TreeTable.prototype.objToRow = function (rowObj)
{
    if (rowObj == null)
    {
        return null;
    }
    return this.indexToRow(this.objToIndex(rowObj));
};


TreeTable.prototype.pathToIndex = function (path)
{
    if (path == null)
    {
        return null;
    }
    return this.objToIndex(this.pathToObj(path));
};

TreeTable.prototype.pathToObj = function (path)
{
    if (path == null)
    {
        return null;
    }
    var container = this.rowData;
    while (path.length > 1)
    {
        container = this.getChildren(container[path[0]]);
        path = path.slice(1);
    }
    return container[path[0]];
};

TreeTable.prototype.pathToRow = function (path)
{
    if (path == null)
    {
        return null;
    }
    return this.indexToRow(this.pathToIndex(path));
};


TreeTable.prototype.rowToIndex = function (row)
{
    if (row == null)
    {
        return null;
    }
    //find the index of the specified row
    var nodeList = this.getBody().childNodes;
    for (var i = 0; i < nodeList.length; ++i)
    {
        if (nodeList[i] == row)
        {
            return i;
        }
    }
    return null;
};

TreeTable.prototype.rowToObj = function (row)
{
    if (row == null)
    {
        return null;
    }
    return this.indexToObj(this.rowToIndex(row));
};

TreeTable.prototype.rowToPath = function (row)
{
    if (row == null)
    {
        return null;
    }
    return this.objToPath(this.rowToObj(row));
};


/**
 * Returns the path to the row above the row indicated by this path.
 *
 * @param path
 */
TreeTable.prototype.pathPrev = function (path)
{
    if (path == null || path.length == 0)
    {
        return null;
    }
    var retPath = path.slice(0);
    retPath[retPath.length - 1] -= 1;
    if (this.pathToObj(retPath) == null)
    {
        return retPath.slice(0, retPath.length - 1);  //parent is prev of 0th child.
    }
    return retPath;
};

/**
 * Return the path to the next row below the row indicated by this path, skipping child rows.
 * The return value will never be deeper than the argument.
 *
 * @param path
 */
TreeTable.prototype.pathNext = function (path)
{
    if (path == null || path.length == 0)
    {
        return null;
    }
    var retPath = path.slice(0);
    retPath[retPath.length - 1] += 1;
    if (this.pathToObj(retPath) == null)
    {
        return this.pathNext(retPath.slice(0, retPath.length - 1));
    }
    return retPath;
};

/**
 * Returns the path that is this path's new position if it were to "move up" one step.
 * @param path
 * @return New path.  May or may not be a valid path within the current tree.
 */
TreeTable.prototype.pathUp = function (path)
{
    //three possibilities:  previous sibling, parent, or expanded previous sibling's child position.
    if (path[path.length - 1] == 0)
    {
        if (path.length == 1)
        {
            //we're the top element.  There is no up.
            return null;
        } else
        {
            //we're at the top of a group, so up is our parent.
            return path.slice(0, path.length - 1);
        }
    } else
    {
        //find previous sibling
        var prevPath = this.pathPrev(path);
        var prevSibObj = this.pathToObj(prevPath);
        if (prevSibObj[TreeTable.IS_EXPANDED])
        {
            //find our previous sibling's last descendent
            var finalIndex = this.getChildren(prevSibObj).length;
            return prevPath.concat(finalIndex);
        } else
        {
            return prevPath;
        }
    }
};

/**
 * Returns the path that is this path's new position if it were to "move down" one step.
 * @param path
 * @return New path.  May or may not be a valid path within the current tree.
 */
TreeTable.prototype.pathDown = function (path)
{
    //three possibilities:  next-next sibling, parent's next sibling, next sibling's first child position.
    var parentPath = path.slice(0, path.length - 1);
    var parent = this.pathToObj(parentPath);
    if (parentPath.length > 0 && path[path.length - 1] == this.getChildren(parent).length - 1)
    {
        //we're our parent's last child.  Return the path to our parent's next sibling (may not exist).
        parentPath[parentPath.length - 1] += 1;
        return parentPath;
    } else
    {
        //either we're at the top level, or we have a next sibling.  Possibly both.
        var nextPath = this.pathNext(path);
        var nextSibObj = this.pathToObj(nextPath);
        if (nextSibObj != null)
        {
            //we have a next sibling.
            if (nextSibObj[TreeTable.IS_EXPANDED])
            {
                //return nextSibObj's first child path
                return nextPath.concat(0);
            } else
            {
                //return next-next sibling path (may not exist).
                nextPath[nextPath.length - 1] += 1;
                return nextPath;
            }
        } else
        {
            //we're top-level, and have no next sibling.  There is no down.
            return null;
        }
    }
};

/**
 * Moves the tree object at the specified path "up" one level.  This may make it the previous sibling of its former
 * parent, the previous sibling of its former previous sibling (basically, they swap places), or the last child of
 * its former previous sibling.
 *
 * @param path
 */
TreeTable.prototype.moveUp = function (path)
{
    var upPath = this.pathUp(path);
    if (upPath != null && tree.isWritable(path) && tree.isWritable(upPath))
    {
        var obj = this.remove(path);
        this.insert(obj, upPath);
    }
    return upPath;
};

/**
 * Moves the tree object at the specified path "down" one level.  This may make it the next sibling of its
 * former next sibling (they swap places), the next sibling of it's former parent, or the first child of it's
 * former next sibling.
 * @param path
 */
TreeTable.prototype.moveDown = function (path)
{
    var downPath = this.pathDown(path);
    if (downPath != null && tree.isWritable(path) && tree.isWritable(downPath))
    {
        var obj = this.remove(path);
        if (downPath.length >= path.length)
        {
            downPath[path.length - 1] -= 1;
        }
        this.insert(obj, downPath);
    }
    return downPath;
};

/**
 * Iterates over each row, checking its selection status.
 *
 * @return Array of row indicies that are selected.
 */
TreeTable.prototype.getSelection = function ()
{
    var tbody = this.getBody();
    var selection = new Array();
    if (tbody != null)
    {
        for (var i = 0; i < tbody.childNodes.length; ++i)
        {
            if (tbody.childNodes[i].isSelected)
            {
                selection.push(i);
            }
        }
    }

    return selection;
};

/**
 * Selects or deselects a row.
 *
 * @param row
 * @param isSelected
 */
TreeTable.prototype.updateSelect = function (row, isSelected)
{
    if (row == null)
    {
        return;
    }
    if (isSelected)
    {
        TreeTable.setClassName(row, "orionTableRowAlt", false);
    }

    TreeTable.setClassName(row, "orionTableCellSelected", isSelected);
    row.isSelected = isSelected;
    var rowObj = this.rowToObj(row);
    rowObj[TreeTable.IS_SELECTED] = isSelected;

    if (!isSelected)
    {
        this.restripe(this.rowToIndex(row), 1);
    }

    var enableButton = true;
    if (typeof isPolicyReadOnly != "undefined")
    {
        enableButton = !isPolicyReadOnly;
    }

    if ((rowObj.viewonly == true) && isSelected)
    {

            TreeTable.viewOnlyRowSelectedCounter = 1;
     }
    else
    {
        TreeTable.viewOnlyRowSelectedCounter = 0;
    }


    if (TreeTable.viewOnlyRowSelectedCounter > 0)
    {
        tree.configSelectionStatusControl("up", false, false, false);
        tree.configSelectionStatusControl("down", false, false, false);
        tree.configSelectionStatusControl("delete", false, false, false);
        tree.configSelectionStatusControl("duplicate", false, enableButton, false);
        tree.configSelectionStatusControl("addRule", false, false, false);
        tree.configSelectionStatusControl("addGroup", false, false, false);
        tree.configSelectionStatusControl("addCatalogRule", false, false, false);
        tree.configSelectionStatusControl("addCatalogGroup", false, false, false);
        tree.configSelectionStatusControl("exportBtn", true, true, true);
    }
    else
    {
        tree.configSelectionStatusControl("up", false, enableButton, false);
        tree.configSelectionStatusControl("down", false, enableButton, false);
        tree.configSelectionStatusControl("delete", false, enableButton, enableButton);
        tree.configSelectionStatusControl("duplicate", false, enableButton, false);
        tree.configSelectionStatusControl("addRule", enableButton, enableButton, false);
        tree.configSelectionStatusControl("addGroup", enableButton, enableButton, false);
        tree.configSelectionStatusControl("addCatalogRule", enableButton, enableButton, false);
        tree.configSelectionStatusControl("addCatalogGroup", enableButton, enableButton, false);
        tree.configSelectionStatusControl("exportBtn", true, true, true);
    }

    if(tree.rowData[0].viewonly == true)
    {
        if(tree.rowData[0]._isExpanded == true)
        {
            if(row.rowIndex == (2 + tree.rowData[0].children.length))
            {
                //entry cannot move above the Factory Default Rule Group
                tree.configSelectionStatusControl("up", false, false, false);
            }
        }
        else
        {
            if(row.rowIndex == 2)
            {
                //entry cannot move above the Factory Default Rule Group
                tree.configSelectionStatusControl("up", false, false, false);
            }
        }
    }

    this.notifySelectListeners();
};

/**
 * Insert a row object at the specified position in the tree.  If an object exists at the specified position,
 * the new object is inserted before the existing object (and thus the existing object's path changes).
 *
 * It is valid to insert an entire subtree using this method (ie. rowObj may have children).
 *
 * @param rowObj The object to be inserted.
 * @param path The position where the object should be inserted.
 */
TreeTable.prototype.insert = function (rowObj, path)
{
    if (path == null)
    {
        path = [this.rowData.length];
    }

    var containerPath = path.slice(0, path.length - 1);
    var container;
    if (containerPath.length > 0)
    {
        container = this.getChildren(this.pathToObj(containerPath));
    } else
    {
        container = this.rowData;
    }

    var tbody = this.getBody();

    var insertBeforeRow = null;
    var firstRowIndex = tbody.childNodes.length;

    var insertIndex = path[path.length - 1];

    if (container.length > insertIndex)
    {
        //something exists at this location
        firstRowIndex = this.objToIndex(container[insertIndex]);
        insertBeforeRow = this.indexToRow(firstRowIndex);
    } else
    {
        //nothing there.  Find the next row anyway
        var prev = this.pathPrev(path); //element before the current position.
        var next = this.pathNext(prev); //next row path
        if (next != null)
        {
            firstRowIndex = this.pathToIndex(next);
            insertBeforeRow = this.indexToRow(firstRowIndex);
        }
    }
    container.splice(insertIndex, 0, rowObj);

    var depth = path.length - 1;
    var rows = this.makeRows([rowObj], depth);

    var i;
    var selectCount = 0;
    for (i = 0; i < rows.length; ++i)
    {
        tbody.insertBefore(rows[i], insertBeforeRow);
        if (rows[i].isSelected)
        {
            ++selectCount;
        }
    }
    this.notifyChangeListeners();
    if (selectCount > 0)
    {
        this.notifySelectListeners();
    }
    if (rows.length % 2 > 0)
    {
        //odd number of rows inserted; must re-stripe to the end
        this.restripe(firstRowIndex);
    } else
    {
        this.restripe(firstRowIndex, i);
    }
};

/**
 * Remove (and return) the row object at the specified path.  May operate on an entire sub-tree.
 *
 * @param path
 */
TreeTable.prototype.remove = function (path)
{
    var containerPath = path.slice(0, path.length - 1);
    var container;
    if (containerPath.length > 0)
    {
        container = this.getChildren(this.pathToObj(containerPath));
    } else
    {
        container = this.rowData;
    }
    var startRowIndex = this.pathToIndex(path);
    var endRowIndex = this.pathToIndex(this.pathNext(path));

    var removeIndex = path[path.length - 1];
    var ret = container.splice(removeIndex, 1)[0];

    var tbody = this.getBody();
    if (endRowIndex == null)
    {
        endRowIndex = tbody.childNodes.length;
    }
    var numRows = endRowIndex - startRowIndex;
    var targetSize = tbody.childNodes.length - numRows;
    while (tbody.childNodes.length > targetSize)
    {
        var toRemove = tbody.childNodes[startRowIndex];
        if (toRemove.ddObj)
        {
            toRemove.ddObj.unreg();
        }
        tbody.removeChild(toRemove);
    }
    this.notifyChangeListeners();

    if (numRows % 2 != 0)
    {
        //odd number of rows removed; must re-stripe
        this.restripe(startRowIndex);
    }

    return ret;
};

/**
 * Re-assign zebra-striping to a portion of the table.
 *
 * @param startIndex The index at which to start re-striping.  0 assumed if omitted.
 * @param numRows The number of rows to re-stripe.  All rows (from startIndex on) assumed if omitted.
 */
TreeTable.prototype.restripe = function (startIndex, numRows)
{
    if (startIndex == null)
    {
        startIndex = 0;
    }

    var tbody = this.getBody();
    var endIndex;
    if (numRows != null && (numRows + startIndex) <= tbody.childNodes.length)
    {
        endIndex = startIndex + numRows;
    } else
    {
        endIndex = tbody.childNodes.length;
    }

    for (var i = startIndex; i < endIndex; ++i)
    {
        var row = tbody.childNodes[i];
        if (!row.isSelected)
        {
            TreeTable.setClassName(row, "orionTableRowAlt", (i % 2 != 0));
        }
    }
};

TreeTable.prototype.configSelectionStatusControl = function (id, enableNone, enableSingle, enableMulti)
{
    function callback(selection)
    {
        var isEnabled = false;
        if (selection.length == 0)
        {
            isEnabled = !!enableNone;
        } else if (selection.length == 1)
        {
            isEnabled = !!enableSingle;
        } else
        {
            isEnabled = !!enableMulti;
        }
        OrionCore.setEnabledById(id, isEnabled);
    }

    this.registerSelectListener(callback);
};

/**
 * Determine if a path (assumed to be a valid path) is writable.  The default implementation always
 * returns true.  Used by drag and drop to identify valid drop targets.
 * @param path the path to check
 * @return true if writable, false otherwise.
 */
TreeTable.prototype.isWritable = function (path)
{
    return true;
};


//Utils
/**
 * Add/remove a className to/from an element.
 * @param elem The element to modify.
 * @param className The className to operate on.
 * @param isEnabled true for Add, false for Remove.
 */
TreeTable.setClassName = function (elem, className, isEnabled)
{
    if (elem == null)
    {
        return;
    }
    if (isEnabled)
    {
        if (elem.className.indexOf(className) < 0)
        {
            elem.className = elem.className + " " + className;
        }
    } else
    {
        if (elem.className.indexOf(className) >= 0)
        {
            var regex = new RegExp("\\b" + className + "\\b");
            elem.className = elem.className.replace(regex, "");
        }
    }
};

/**
 * Performs a deep copy of any JS type.  Immutable primitives and functions are return as-is, arrays are
 * returned as arrays with all their contents copied.  Objects are returned as objects (with
 * all properties copied), with their prototype intact.
 *
 * @param obj
 * @param filter function(obj, key) that returns true iff that key of that object should be copied.
 * @return a deep copy of obj
 */
TreeTable.deepCopy = function (obj, filter)
{
    if ((obj === null) || (typeof obj == "number") || (typeof obj == "string") || (typeof obj == "boolean"))
    {
        //primitives are immutable.
        return obj;
    } else if (typeof obj == "object")
    {
        var ret;
        if (obj.constructor == Array)
        {
            ret = new Array();
        } else
        {
            function F()
            {
            }

            F.prototype = obj.constructor.prototype;
            ret = new F();
        }
        for (var key in obj)
        {
            if (!filter || filter(obj, key))
            {
                if (!((key in ret.constructor.prototype) && ret.constructor.prototype[key] === obj[key]))
                {
                    ret[key] = TreeTable.deepCopy(obj[key], filter);
                }
            }
        }
        return ret;
    } else if (typeof obj == "function")
    {
        return obj;
    } else
    {
        //some unknown type, don't deep copy.
        return obj;
    }
};

TreeTable.getSelectionIndicies = function (available, selections)
{
    function arrayIndexOf(a, x)
    {
        if (a.indexOf)
        {
            return a.indexOf(x);
        } else
        {
            for (var j = 0; j < a.length; ++j)
            {
                if (a[j] == x)
                {
                    return j;
                }
            }
            return -1;
        }
    }

    var ret = [];
    for (var i = 0; i < selections.length; ++i)
    {
        ret.push(arrayIndexOf(available, selections[i]));
    }

    return ret;
};

/**
 * Makes a deep copy of an array of row objects, removing any properties that TreeTable added.  Useful if you're
 * JSONifying tree.rowData.
 *
 * @param rowData
 */
TreeTable.sanitize = function (rowData)
{
    function filter(obj, key)
    {
        return (key != TreeTable.IS_EXPANDED) && (key != TreeTable.IS_SELECTED);
    }

    return TreeTable.deepCopy(rowData, filter);
};

//Event handlers.  These must be Curried with a reference to the TreeTable they should operate on.  TreeTable.prototype.addListener will do this automatically.
TreeTable.onCellClick = function (tree, evt, currentTarget)
{
    var row = currentTarget.parentNode;

    if (evt.shiftKey)
    {
        var inRegion = false;
        var tbody = tree.getBody();
        if (tbody != null)
        {
            //Reset the counter on shift select.
            TreeTable.viewOnlyRowSelectedCounter = 0;
            for (var i = 0; i < tbody.childNodes.length; ++i)
            {
                var currentRow = tbody.childNodes[i];
                //tree.rowLastClicked and row form a closed interval.  Everything in that interval gets selected.
                if (!inRegion)
                {
                    if (currentRow == tree.rowLastClicked || currentRow == row)
                    {
                        inRegion = !inRegion;
                    }
                    tree.updateSelect(tbody.childNodes[i], inRegion);
                } else
                {
                    tree.updateSelect(tbody.childNodes[i], inRegion);
                    if (currentRow == tree.rowLastClicked || currentRow == row)
                    {
                        inRegion = !inRegion;
                    }
                }
            }
        }
    } else if (evt.ctrlKey)
    {
        //control-select behavior
        tree.updateSelect(row, !row.isSelected);
        tree.rowLastClicked = row;
    } else
    {
        //clear selection
        tbody = tree.getBody();
        if (tbody != null)
        {
            for (i = 0; i < tbody.childNodes.length; ++i)
            {
                if (tbody.childNodes[i].isSelected)
                {
                    tree.updateSelect(tbody.childNodes[i], false);
                }
            }
        }

        //select the clicked node
        tree.updateSelect(row, true);
        tree.rowLastClicked = row;
    }
    //YAHOO.util.Event.stopPropagation(evt);
};

TreeTable.handleExpandContract = function (tree, evt, currentTarget)
{
    tree.expandContract(currentTarget.parentNode.parentNode);

    YAHOO.util.Event.stopPropagation(evt);
};

TreeTable.handleUp = function (tree)
{
    var selection = tree.getSelection();
    if (selection.length != 1)
    {
        return;
    }
    var selPath = tree.indexToPath(selection[0]);
    var newPath = tree.moveUp(selPath);

    if (newPath != null)
    {
        var row = tree.pathToRow(newPath);
        tree.updateSelect(row, true);
    }
};

TreeTable.handleDown = function (tree)
{
    var selection = tree.getSelection();
    if (selection.length != 1)
    {
        return;
    }
    var selPath = tree.indexToPath(selection[0]);
    var newPath = tree.moveDown(selPath);

    if (newPath != null && tree.isWritable(newPath))
    {
        var row = tree.pathToRow(newPath);
        tree.updateSelect(row, true);
    }
};

TreeTable.handleDuplicate = function (tree)
{
    var selection = tree.getSelection();
    if (selection.length != 1)
    {
        return;
    }

    var selPath = tree.indexToPath(selection[0]);
    if (!tree.isWritable(selPath))
    {
        return;
    }

    var rowObj = TreeTable.makeDuplicate(tree.pathToObj(selPath));

    if (rowObj.viewonly == true)
    {
        //make new policy editable
        rowObj.viewonly = false;
        selPath[0] = selPath[0] + 1;
        //if new policy has children, make them editable
        if (rowObj.children.length > 0)
        {
            for (i = 0; i < rowObj.children.length; ++i)
            {
                rowObj.children[i].viewonly = false;
            }
        }

    }
    tree.insert(rowObj, selPath);
};

TreeTable.makeDuplicate = function (rowObj)
{
    return TreeTable.deepCopy(rowObj, function (obj, key)
    {
        return key != "id";
    });
};

TreeTable.handleDelete = function (tree)
{
    var selection = tree.getSelection();
    //work backward, so that we don't have to worry about indicies changing, or parents being deleted.
    for (var i = selection.length - 1; i >= 0; --i)
    {
        var rowIndex = selection[i];
        var selPath = tree.indexToPath(rowIndex);
        if (tree.isWritable(selPath))
            tree.remove(selPath);
    }
    tree.notifySelectListeners();
};


/**
 * An asynchronous version of TreeTable.  It supports pruned children.
 *
 * A rather odd coding style is employed here in several places.  The async calls
 * require that certain methods call callbacks instead of returning values.  This
 * is particularly complicated in recursive methods, such as giveRows.
 *
 * To have any hope of understanding this code, please be familiar with the
 * concepts of recursion and closures.
 *
 * @see TreeTable
 */
function AsyncTreeTable(id, colMap, colList, rowData, enableDragDrop, enableSelect, sortColumnId, sortableColumns, sortCallback)
{
    AsyncTreeTable.superclass.constructor.apply(this, arguments);
}

/**
 * Graft is the heart of async support.  It takes a pruned array (a singleton array
 * containing only a prune marker) and replaces the array's contents with the result
 * of an async request to the server for those contents.
 *
 * Because the request is asynchronous, graft cannot return the grafted array, nor can
 * it ensure that it waits for the request to complete.  Instead, the user may provide
 * a callback function that takes the array as a parameter.  This function will be
 * called when grafting has finished.
 *
 * @param array
 * @param notifyCallback function(array)
 */
AsyncTreeTable.graft = function (array, notifyCallback)
{
    if ((array == null) || !AsyncTreeTable.isPruned(array))
    {
        throw new Error("Cannot graft null or unpruned arrays.");
    }

    var params = new Array();
    params.push("jsonData");
    params.push(toJsonString({"list":array }));

    function finishGraft(text)
    {
        var result = eval("(" + text + ")")["list"];
        array.pop();
        for (var i = 0; i < result.length; ++i)
        {
            array.push(result[i]);
        }
        if (notifyCallback)
        {
            notifyCallback(array);
        }
    }

    OrionCore.doAsyncAction("/ENDP_FW_META/graft.do", params, finishGraft, null, "POST");
};

/**
 * Identifies pruned arrays.
 * @param array The array to check.  Must be non-null.
 */
AsyncTreeTable.isPruned = function (array)
{
    return array != null && array.length == 1 && array[0] && array[0]["@_NodeName"] && array[0]["@_NodeName"] == "pruned";
};

YAHOO.extend(AsyncTreeTable, TreeTable, {
    /**
     * New version of constructTable that uses giveRows, rather than makeRows.
     */
    constructTable:function ()
    {
        if (this.rowData == null)
        {
            throw new Error("rowData not set");
        }
        var container = document.getElementById(this.id);
        while (container.hasChildNodes())
        {
            container.removeChild(container.firstChild);
        }

        var table = document.createElement("table");
        table.className = "treeTable";

        var thead = this.constructHead();

        var tbody = document.createElement("tbody");
        tbody.id = this.id + "Body";
        tbody.className = "tableContentBody";

        var self = this;

        //completion closure
        function finish(rows)
        {
            self.finishConstructTable(container, table, thead, tbody, rows);
        }

        //giveRows will make the rows from the rowData, and pass them as a params to finish.
        this.giveRows(this.rowData, finish);
    },

    /**
     * Completion method for constructTable
     *
     * @param container
     * @param table
     * @param thead
     * @param tbody
     * @param rows
     */
    finishConstructTable:function (container, table, thead, tbody, rows)
    {
        for (var i = 0; i < rows.length; ++i)
        {
            tbody.appendChild(rows[i]);
            if (i % 2 != 0)
            {
                rows[i].className = "orionTableRowAlt";
            }
        }

        table.appendChild(thead);
        table.appendChild(tbody);

        container.appendChild(table);
    },

    /**
     * gives tr elements to target.
     *
     * @param rowData The rowData array to operate on.
     * @param target The target to deliver the rows to (i.e. target(rows))
     * @param depth The current row depth.  Default 0.
     * @param i The current rowData index.  Default 0.
     * @param rows The accumulated rows.  Default [].  Note that because objects
     * are passed by reference, and we make modifications to rows, it will always
     * contain the complete list of rows, which is how giveRowsGivenChildren
     * passes data to giveMoreRows.
     */
    giveRows:function (rowData, target, depth, i, rows)
    {
        //initialize internal params
        if (depth == null)
        {
            depth = 0;
        }
        if (i == null)
        {
            i = 0;
        }
        if (rows == null)
        {
            rows = [];
        }

        //continuation closures
        var self = this;

        function giveMoreRows()
        {
            //this one just increments the index, working its way down the rowData array
            self.giveRows(rowData, target, depth, i + 1, rows);
        }

        function giveRowsGivenChildren(children)
        {
            //this one increments depth, resets i, and operates on a new rowData array
            //target here is giveMoreRows, which ignores the rows param, which is ok, since the array is modified in-place.
            self.giveRows(children, giveMoreRows, depth + 1, 0, rows);
        }

        //the meat
        if (i < rowData.length)
        {
            //the current index is valid, make a row for it
            var rowObj = rowData[i];
            rows.push(this.makeRow(rowObj, depth));

            //now: how to continue?
            if (rowObj[TreeTable.IS_EXPANDED])
            {
                //need child rows, so give children of rowObj to giveRowsGivenChildren
                this.giveChildren(rowObj, giveRowsGivenChildren);
            } else
            {
                //no children needed; just give more rows incrementing the index
                giveMoreRows();
            }
        } else
        {
            //the current index is beyond the list.  Call the target with the result
            target(rows);
        }
    },

    /**
     * Gives children to target.
     *
     * @param rowObj
     * @param target
     */
    giveChildren:function (rowObj, target)
    {
        var children = this.getChildren(rowObj);
        if (children != null)
        {
            if (AsyncTreeTable.isPruned(children))
            {
                AsyncTreeTable.graft(children, target);
            } else
            {
                target(children);
            }
        } else
        {
            target(null);
        }
    },

    /**
     * insert, written to work with giveRows rather than makeRows.
     *
     * @param rowObj
     * @param path
     * @param target target() is called when done.
     */
    insert:function (rowObj, path, target)
    {
        if (path == null)
        {
            path = [this.rowData.length];
        }

        var containerPath = path.slice(0, path.length - 1);
        var container;
        if (containerPath.length > 0)
        {
            container = this.getChildren(this.pathToObj(containerPath));
        } else
        {
            container = this.rowData;
        }

        var tbody = this.getBody();

        var insertBeforeRow = null;
        var firstRowIndex = tbody.childNodes.length;

        var insertIndex = path[path.length - 1];

        if (container.length > insertIndex)
        {
            //something exists at this location
            firstRowIndex = this.objToIndex(container[insertIndex]);
            insertBeforeRow = this.indexToRow(firstRowIndex);
        } else
        {
            //nothing there.  Find the next row anyway
            var prev = this.pathPrev(path); //element before the current position.
            var next = this.pathNext(prev); //next row path
            if (next != null)
            {
                firstRowIndex = this.pathToIndex(next);
                insertBeforeRow = this.indexToRow(firstRowIndex);
            }
        }
        container.splice(insertIndex, 0, rowObj);

        var self = this;

        function rowTarget(rows)
        {
            self.finishInsert(tbody, insertBeforeRow, firstRowIndex, rows);
            if (target)
            {
                target();
            }
        }

        var depth = path.length - 1;
        this.giveRows([rowObj], rowTarget, depth);
    },

    /**
     * Insert completion method.
     *
     * @param tbody
     * @param insertBeforeRow
     * @param firstRowIndex
     * @param rows
     */
    finishInsert:function (tbody, insertBeforeRow, firstRowIndex, rows)
    {
        var i;
        var selectCount = 0;
        for (i = 0; i < rows.length; ++i)
        {
            tbody.insertBefore(rows[i], insertBeforeRow);
            if (rows[i].isSelected)
            {
                ++selectCount;
            }
        }
        this.notifyChangeListeners();
        if (selectCount > 0)
        {
            this.notifySelectListeners();
        }
        if (rows.length % 2 > 0)
        {
            //odd number of rows inserted; must re-stripe to the end
            this.restripe(firstRowIndex);
        } else
        {
            this.restripe(firstRowIndex, i);
        }
    },

    expandContract:function (row)
    {
        //find the row object
        var rowObj = this.rowToObj(row);
        //clear any selections. Handles children.
        if (this.clearSelection(rowObj))
        {
            this.notifySelectListeners();
        }

        //get the path to the rowObj
        var path = this.objToPath(rowObj);

        //add the spinner
        row.replaceChild(this.makeLoadingCell(rowObj, path.length - 1), row.firstChild);

        //set up the insert target
        var self = this;

        function finish()
        {
            var removePath = self.rowToPath(row);
            self.remove(removePath);
        }

        //insert the new row(s).  The old row will be deleted after insert is finished.
        var newRowObj = TreeTable.deepCopy(rowObj);
        newRowObj[TreeTable.IS_EXPANDED] = !rowObj[TreeTable.IS_EXPANDED];
        this.insert(newRowObj, path, finish);
    },

    makeLoadingCell:function (rowObj, depth)
    {
        var colSpec = this.colMap[this.colList[0]];
        var td = colSpec.getCell(rowObj, depth);
        var img = document.createElement("img");
        img.src = "/core/images/spinner.gif";
        img.width = 14;
        img.height = 14;
        img.style.verticalAlign = "middle";
        td.appendChild(img);

        return td;
    },

    makeRows:function ()
    {
        throw new Error("makeRows not supported.  Use giveRows.");
    }
});


/////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This class helps with setting up action columns in treetables.  Create a list of TreeTableActions,
 * specifying a handler and appliesTo function, then curry TreeTableAction.columnRenderer with the list,
 * and use it as the renderer for your ColSpec.
 */
function TreeTableAction(label, handler, appliesTo)
{
    this.label = label;
    if (handler)
    {
        this.handler = handler;
    }
    if (appliesTo)
    {
        this.appliesTo = appliesTo;
    }
}

//noinspection JSUnusedLocalSymbols
TreeTableAction.prototype.handler = function (obj, tree)
{
    //do nothing
};

TreeTableAction.prototype.appliesTo = function (obj, depth)
{
    return depth == 0;
};

TreeTableAction.columnRenderer = function (tree, actions, rowObj, depth)
{
    var td = document.createElement("td");

    var appendCount = 0;
    for (var i = 0; i < actions.length; ++i)
    {
        if (actions[i].appliesTo(rowObj, depth, tree))
        {
            if (appendCount > 0)
            {
                td.appendChild(document.createTextNode(" | "));
            }
            var link = document.createElement("a");
            link.style.textDecoration = "underline";
            link.style.cursor = "pointer";
            link.appendChild(document.createTextNode(actions[i].label));

            YAHOO.util.Event.addListener(link, "click",
                TreeTableAction.wrapHandler(rowObj, tree, actions[i].handler));

            td.appendChild(link);
            ++appendCount;
        }
    }

    return td;
};

TreeTableAction.wrapHandler = function (rowObj, tree, handler)
{
    return function (evt)
    {
        handler(rowObj, tree);

        YAHOO.util.Event.stopPropagation(evt);
    };
};


/**
 * The CellRenderer base class.  As basic as possible, it just calls rowObj[id].toString and returns a cell with the
 * text, or an empty cell when null.  Handles async grafting.
 */
function CellRenderer()
{
}

/**
 * Determine whether this column can be rendered for this row.  By default, checks rowObj[id] for null.
 *
 * @param rowObj
 * @param tree
 * @param id
 * @param depth
 *
 * @return boolean True iff rendering can proceed.
 */
CellRenderer.prototype.appliesTo = function (rowObj, tree, id, depth)
{
    return rowObj[id] != null;
};

/**
 * Retrieves the value.  By default, rowObj[id].  getValue assumes that appliesTo is true.
 *
 * @param rowObj
 * @param tree
 * @param id
 * @param depth
 *
 * @return The model-side value to be rendered.
 */
CellRenderer.prototype.getValue = function (rowObj, tree, id, depth)
{
    return rowObj[id];
};

/**
 * Transforms the value into a display string.  By default, calls toString() on the value.
 * @param value The value to be displayed
 * @return The display string.
 */
CellRenderer.prototype.valueToString = function (value)
{
    if (value == null)
        return "";
    else
        return value.toString();
};

/**
 * Constructs a td element, and populates it.
 *
 * @param rowObj
 * @param tree
 * @param id
 * @param depth
 *
 * @return The td element to be added to the table.
 */
CellRenderer.prototype.makeCell = function (rowObj, tree, id, depth)
{
    var td = document.createElement("td");
    if (this.appliesTo(rowObj, tree, id, depth))
    {
        var value = this.getValue(rowObj, tree, id, depth);
        if (AsyncTreeTable.isPruned(value))
        {
            this.giveRenderedContent(td, value);
        } else
        {
            this.addRenderedContent(td, value);
        }
    }

    return td;
};

/**
 * Grafts the pruned value back onto the model, and adds the rendered, grafted result to the td element by
 * calling addRenederdContent in the graft callback.
 *
 * @param td
 * @param value
 */
CellRenderer.prototype.giveRenderedContent = function (td, value)
{
    var self = this;

    function callback(graftedValue)
    {
        self.addRenderedContent(td, graftedValue);
    }

    AsyncTreeTable.graft(value, callback);
};

/**
 * Renders the content and calls td.appendChild to append the content to the cell.
 * @param td
 * @param value
 */
CellRenderer.prototype.addRenderedContent = function (td, value)
{
    var text = this.valueToString(value);
    td.appendChild(document.createTextNode(text));
};

/**
 * Perform an arbitrary transform on the output of the CellRenderer.
 *
 * @param cellRenderer The CellRenderer to delegate to.
 * @param decorateCell The decorator function(elem, rowObj, tree, id, depth): elem
 */
function CellDecorator(cellRenderer, decorateCell)
{
    this.cellRenderer = cellRenderer;
    this.decorateCell = decorateCell;
}

CellDecorator.prototype.makeCell = function (rowObj, tree, id, depth)
{
    var cell = this.cellRenderer.makeCell(rowObj, tree, id, depth);
    if (this.decorateCell)
    {
        cell = this.decorateCell(cell, rowObj, tree, id, depth);
    }
    return cell;
};

/**
 * Uses each value as a key in the map, returns the mapped value.
 * @param map The map.
 * @param defaultText If specified, this value will be returned for all unmapped values.
 * The default behavior is to return the value unchanged.
 * @param valueToKeyFn Optional.  If specified, values are passed to this function to
 * obtain the lookup key for the map.  The default behavior is to look up values directly.
 */
function MapCellRenderer(map, defaultText, valueToKeyFn)
{
    if (map == null)
    {
        map = {};
    }
    this.map = map;
    this.defaultText = defaultText;
    this.valueToKeyFn = valueToKeyFn;
    MapCellRenderer.superclass.constructor.apply(this, arguments);
}

YAHOO.extend(MapCellRenderer, CellRenderer, {
    valueToString:function (value)
    {
        var key = value;
        if (this.valueToKeyFn)
        {
            key = this.valueToKeyFn(value);
        }
        var mapped = this.map[key];
        if (mapped != null)
        {
            return mapped;
        } else if (this.defaultText != null)
        {
            return this.defaultText;
        }
        return value;
    }
});


/**
 * Truncates the string value at a given length, with full-string title text.
 * @param maxlength.
 */
function TruncatedCellRenderer(maxlength)
{
    if (maxlength == null)
    {
        maxlength = 25;
    }
    this.maxlength = maxlength;
    TruncatedCellRenderer.superclass.constructor.apply(this, arguments);
}


/**
 * Returns a span that displays the string truncated, but with a title containing the full string.
 * @param str The long string
 * @param cutOff The length cutoff.  Defaults to 1000 characters.
 *
 * @return a span element with appropriate text and title.
 */
TruncatedCellRenderer.createLongStringSpan = function (str, cutOff)
{
    var span = document.createElement("span");
    if (str == null)
    {
        return span;
    }
    if (cutOff == null)
    {
        cutOff = 1000;
    }

    var isTrunc = false;
    var text = str;
    if (text.length > cutOff)
    {
        text = text.substr(0, cutOff - 3) + "...";
        isTrunc = true;
    }
    span.appendChild(document.createTextNode(text));
    span.setAttribute("title", str);
    return span;
};


YAHOO.extend(TruncatedCellRenderer, CellRenderer, {
    addRenderedContent:function (td, value)
    {
        var text = this.valueToString(value);
        var child = TruncatedCellRenderer.createLongStringSpan(text, this.maxlength);
        td.appendChild(child);
    }
});

/**
 * Renders a string property of the elements of an array property of the row object as a
 * comma-delimited list, and truncates.  rowObj[id][i][elementProperty]
 * @param elementProperty
 * @param maxLength
 */
function ArrayPropertyCellRenderer(elementProperty, maxLength)
{
    this.elementProperty = elementProperty;
    ArrayPropertyCellRenderer.superclass.constructor.apply(this, [maxLength]);
}

YAHOO.extend(ArrayPropertyCellRenderer, TruncatedCellRenderer, {
    valueToString:function (value)
    {
        var strings = [];
        if (value)
        {
            for (var i = 0; i < value.length; ++i)
            {
                strings.push(value[i][this.elementProperty]);
            }
        }
        strings.sort();
        return strings.join(", ");
    },
    appliesTo:function (rowObj, tree, id, depth)
    {
        return rowObj[id] && rowObj[id].length != null;
    }
});

/**
 * Uses each value as a key in the map, returns the mapped value.
 * @param map The map, for fixed-string address types.
 * obtain the lookup key for the map.  The default behavior is to look up values directly.
 */
function IpCellRenderer(map)
{
    IpCellRenderer.superclass.constructor.apply(this, [map]);
}

YAHOO.extend(IpCellRenderer, MapCellRenderer, {
    valueToString:function (value)
    {
        var text = new IpAddress(value).displayString();
		if(text == "[trusted]")
		{
			return Resource.Trusted;
		}
		else if(text == "[local]")
		{
			return Resource.Local;
		}
		else
		{
			return IpCellRenderer.superclass.valueToString.apply(this, [text]);
		}
    }
});

/**
 * Renders a properly-indented twisty, at the left side of the cell.
 */
function TwistyCellRenderer()
{
    this.expandContract = TreeTable.handleExpandContract;
    TwistyCellRenderer.superclass.constructor.apply(this, arguments);
}

YAHOO.extend(TwistyCellRenderer, CellRenderer, {
    makeCell:function (rowObj, tree, id, depth)
    {
        var td = document.createElement("td");

        while (depth > 0)
        {
            var shim = document.createElement("span");
            shim.className = "indent";
            td.appendChild(shim);
            --depth;
        }
        if (tree.getChildren(rowObj) != null)
        {
            var twisty = document.createElement("span");
            twisty.className = "twisty";
            twisty.appendChild(document.createTextNode(rowObj[TreeTable.IS_EXPANDED] ? EXPANDED_CHAR : CONTRACTED_CHAR));
            tree.addListener(twisty, "click", this.expandContract);
            YAHOO.util.Event.addListener(twisty, "mousedown", YAHOO.util.Event.stopPropagation);
            td.appendChild(twisty);
        }

        if (this.appliesTo(rowObj, tree, id, depth))
        {
            var value = this.getValue(rowObj, tree, id, depth);
            if (AsyncTreeTable.isPruned(value))
            {
                this.giveRenderedContent(td, value);
            } else
            {
                this.addRenderedContent(td, value);
            }
        }

        return td;
    }
});


/**
 * Renders an action cell.
 */
function TreeTableActionRenderer(actions)
{
    this.actions = actions;
    TreeTableActionRenderer.superclass.constructor.apply(this, []);
}

YAHOO.extend(TreeTableActionRenderer, CellRenderer, {
    appliesTo:function (rowObj, tree, id, depth)
    {
        for (var i = 0; i < this.actions.length; ++i)
        {
            if (this.actions[i].appliesTo(rowObj, depth, tree))
            {
                return true;
            }
        }
        return false;
    },
    getValue:function (rowObj, tree, id, depth)
    {
        var ret = new Array();
        for (var i = 0; i < this.actions.length; ++i)
        {
            if (this.actions[i].appliesTo(rowObj, depth, tree))
            {
                var link = document.createElement("a");
                link.style.textDecoration = "underline";
                link.style.cursor = "pointer";
                link.appendChild(document.createTextNode(this.actions[i].label));

                YAHOO.util.Event.addListener(link, "click",
                    TreeTableAction.wrapHandler(rowObj, tree, this.actions[i].handler));
                ret.push(link);
            }
        }
        return ret;
    },
    addRenderedContent:function (td, links)
    {
        for (var i = 0; i < links.length; ++i)
        {
            if (i > 0)
            {
                td.appendChild(document.createTextNode(" | "));
            }

            td.appendChild(links[i]);
        }
    }
});

