//////////////////////////////////////////////////////////////////////////////////////////////////
/**
* This class is similar in appearance to the Orion List Picker tag, but its model is browser-based.
*/
function DynaList(containerId){
	this.containerId = containerId;

	this.nextId = 0;
	this._ENABLED_ROW_CLASS = "orionListPickerRowEnabled";
	this._DISABLED_ROW_CLASS = "orionListPickerRowDisabled";
}

DynaList.prototype.makeRow = function(text, enabled){
	var row = document.createElement("div");
	row.id = this.getNextId();
	row.title = text;

	var textCell = document.createElement("div");
	textCell.appendChild(document.createTextNode(text));
	row.appendChild(textCell);

	this.setRowEnabled(row, enabled);

	if(this.decorateRow){
		this.decorateRow(row);
	}

	return row;
}

DynaList.prototype.getNextId = function(){
	return this.containerId + "_" + this.nextId++;
}

DynaList.prototype.constructList = function(){
	if(!this.rowData){
		throw new Error("rowData is not set");
	}

	//clear
	var container = document.getElementById(this.containerId);
	while(container.firstChild){
		container.removeChild(container.firstChild);
	}

	//construct
	for(var i = 0; i < this.rowData.length; ++i){
		var row = this.makeRow(this.rowData[i], true);
		container.appendChild(row);
	}
}

DynaList.prototype.setRowData = function(rowData){
	this.rowData = rowData;
	this.constructList();
}

/**
 *
 * @param row the managed row element, or its index
 * @param enabled
 */
DynaList.prototype.setRowEnabled = function(row, enabled){
	if(typeof(row) == "number"){
		row = this.getRow(row);
	}

	row.className = enabled ? this._ENABLED_ROW_CLASS : this._DISABLED_ROW_CLASS;
	row.disabled = !enabled;
}

DynaList.prototype.getRow = function(index){
	var container = document.getElementById(this.containerId);
	return container.childNodes[index];
}

DynaList.prototype.eachRow = function(block){  //a little Rubyism
	var container = document.getElementById(this.containerId);
	//we iterate a copy to make changes to the DOM structure safe
	var children = new Array();
	var node = container.firstChild;
	while(node != null){
		children.push(node);
		node = node.nextSibling;
	}
	for(var i = 0; i < children.length; ++i){
		block(children[i]);
	}
}


////////////////////////////////////////////////////////////////////////////////////////////////

function OrderedColList(containerId){
	this.containerId = containerId;

	this.changeListeners = [];
	this.removeListeners = [];
	this.nextId = 0;
}

OrderedColList.prototype.makeCol = function(text, data){
	var td = document.createElement("td");
	td.className = "columnSelectionContainer";
	td.id = this.getNextId();
	td.data = data;

	var table = document.createElement("table");
	table.style.width = "100%";
	var tbody = document.createElement("tbody");
	var tr = document.createElement("tr");
	tbody.appendChild(tr)
	table.appendChild(tbody)

	var label = document.createElement("td");
	label.className = "columnSelectionLabel";
	label.appendChild(document.createTextNode(text));
	tr.appendChild(label);

	var buttons = document.createElement("td")
	buttons.className = "columnSelectionIcons";

	var self = this;
	var left = document.createElement("img");
	left.src = "/core/images/query-columns-left.gif";
	function moveLeft(evt){
		var col = this.parentNode.parentNode.parentNode.parentNode.parentNode; //up five
		self.moveLeft(col);
	}
	YAHOO.util.Event.addListener(left, "click", moveLeft);
	buttons.appendChild(left);

	var right = document.createElement("img");
	function moveRight(evt){
		var col = this.parentNode.parentNode.parentNode.parentNode.parentNode; //up five
		self.moveRight(col);
	}
	right.src = "/core/images/query-columns-right.gif";
	YAHOO.util.Event.addListener(right, "click", moveRight);
	buttons.appendChild(right);

	var remove = document.createElement("img");
	function removeCol(evt){
		var col = this.parentNode.parentNode.parentNode.parentNode.parentNode; //up five
		self.remove(col);
	}
	remove.src = "/core/images/query-columns-remove.gif";
	YAHOO.util.Event.addListener(remove, "click", removeCol);
	buttons.appendChild(remove);

	tr.appendChild(buttons);

	td.appendChild(table);

	new ColumnDragger(td, text, this);

	return td;
}

OrderedColList.prototype.getNextId = function(){
	return this.containerId + "_" + this.nextId++;
}

/**
 * Inserts a column before a specified column.  To place the new column at the end, specify null.
 * Can also be used to move an existing column.
 *
 * @param labelOrCol The label for the new column, or the column itself.  If the column is already
 * in the tree, it will be removed from its present location before being inserted
 * (calls Node.insertBefore()).
 * @param beforeCol The column that should be to the right of the new column.  Null for right-most
 * position.
 * @param data Data to be associate with this column.  Ignored if labelOrCol is a column.
 */
OrderedColList.prototype.insert = function(labelOrCol, beforeCol, data){
	if(beforeCol == null){
		beforeCol = null; //IE needs this.  IE is that dumb.
	}
	var col;
	if(labelOrCol.constructor == String){
		col = this.makeCol(labelOrCol, data);
	}else{
		col = labelOrCol;
	}
	var container = document.getElementById(this.containerId);

	container.insertBefore(col, beforeCol);

	this.updateButtonState(col);
	if(col.previousSibling != null){
		this.updateButtonState(col.previousSibling);
	}
	if(col.nextSibling != null){
		this.updateButtonState(col.nextSibling);
	}

	this.notifyChangeListeners();
}

OrderedColList.prototype.updateButtonState = function(column){
	var leftStyle = "";
	var rightStyle = "";
	var leftOpacity = 1;
	var rightOpacity = 1;
	if(column.previousSibling == null && column.nextSibling == null){
		//disable both moves, we're the only one
		leftStyle = "disabled";
		rightStyle = "disabled";
		leftOpacity = 0.50;
		rightOpacity = 0.50;
	}else if(column.nextSibling == null){
		//disable move right because we're right-most
		rightStyle = "disabled";
		rightOpacity = 0.50;
	}else if(column.previousSibling == null){
		//disable move left because we're left-most
		leftStyle = "disabled";
		leftOpacity = 0.50;
	}

	//td.table.tbody.tr.td.img
	var leftImg = column.firstChild.firstChild.firstChild.lastChild.firstChild;
	leftImg.className = leftStyle;
	YAHOO.util.Dom.setStyle(leftImg, "opacity", leftOpacity);

	var rightImg = leftImg.nextSibling;
	rightImg.className = rightStyle;
	YAHOO.util.Dom.setStyle(rightImg, "opacity", rightOpacity);

}

OrderedColList.prototype.remove = function(col){
	var container = document.getElementById(this.containerId);
	var left = col.previousSibling;
	var right = col.nextSibling;
	container.removeChild(col);

	if(left != null){
		this.updateButtonState(left);
	}
	if(right != null){
		this.updateButtonState(right);
	}

	this.notifyChangeListeners();
	this.notifyRemoveListeners(col.data);
}

OrderedColList.prototype.moveLeft = function(col){
	var beforeCol = col.previousSibling;
	if(beforeCol != null){
		this.insert(col, beforeCol);
	}
}

OrderedColList.prototype.moveRight = function(col){
	var beforeCol = col.nextSibling;
	if(beforeCol != null){
		//we need to move two steps, but want to avoid exceptions.
		beforeCol = beforeCol.nextSibling;
	}
	//Null beforeCol is ok, it means right-most.

	this.insert(col, beforeCol);
}

OrderedColList.prototype.eachCol = function(block){  //a little Rubyism
	var container = document.getElementById(this.containerId);
	//we iterate a copy to make changes to the DOM structure safe
	var children = new Array();
	var node = container.firstChild;
	while(node != null){
		children.push(node);
		node = node.nextSibling;
	}
	for(var i = 0; i < children.length; ++i){
		block(children[i]);
	}
}

OrderedColList.prototype.isEmpty = function(){
	var container = document.getElementById(this.containerId);
	return container.firstChild == null;
}

OrderedColList.prototype.clear = function(){
	var self = this;
	this.eachCol(function(col){
		self.remove(col);
	});
}

/**
 *
 * @param handler function(orderedColList)
 */
OrderedColList.prototype.addChangeListener = function(handler){
	this.changeListeners.push(handler);
}

OrderedColList.prototype.notifyChangeListeners = function(){
	for(var i = 0; i < this.changeListeners.length; ++i){
		this.changeListeners[i](this);
	}
}

/**
 * Adds a removeListener.
 * @param handler function(orderedColList, colData)
 */
OrderedColList.prototype.addRemoveListener = function(handler){
	this.removeListeners.push(handler);
}

OrderedColList.prototype.notifyRemoveListeners = function(data){
	for(var i = 0; i < this.removeListeners.length; ++i){
		this.removeListeners[i](this, data);
	}
}

OrderedColList.prototype.getData = function(){
	var ret = new Array();
	this.eachCol(function(col){
		ret.push(col.data);
	});
	return ret;
}


////////////////////////////////////////////////////////////////////////////////////////////////
/**
Draggable Column class, mostly stolen from MFS.

Loosly based on the YUI example for sortable drag and drop unordered lists
*/
function ColumnDragger(id, columnLabel, colList) {

    ColumnDragger.superclass.constructor.call(this, id, "");

    var el = this.getDragEl();

    this.goingLeft = false;
    this.lastX = 0;
    this.columnLabel = columnLabel;
	this.colList = colList;

	YAHOO.util.Dom.setStyle(el, "opacity", 0.75);
};


YAHOO.extend(ColumnDragger, YAHOO.util.DDProxy, {

    startDrag: function(x, y)
    {
        var clickEl = this.getEl();
        YAHOO.util.Dom.setStyle(clickEl, "opacity", 0.50);
        YAHOO.util.Dom.setStyle(clickEl, "background-color", "#606060");

        var dragEl = this.getDragEl();
        dragEl.className = "draggerCell";
        dragEl.innerHTML =  this.columnLabel;//clickEl.innerHTML;

        dragEl.style.borderWidth = "1px";

        YAHOO.util.Dom.setStyle(clickEl, "opacity", 0.75);
        this.resetConstraints();

        var srcXY = YAHOO.util.Dom.getXY( clickEl );
        var size = new BrowserUtil().getWindowDimension();

        var xMin = srcXY[0] - 10;
        var xMax = size.width - srcXY[0] - dragEl.clientWidth - 10;

        var yMin = srcXY[1] - 10;
        var yMax = size.height - srcXY[1] - dragEl.clientHeight - 10;

        // constrain the dragging proxy so it can't be moved off the screen.
        this.setXConstraint(xMin, xMax);
        this.setYConstraint(yMin, yMax);

        YAHOO.util.DragDropMgr.refreshCache();
    },

    endDrag: function(e)
    {
        var srcEl = this.getEl();
        var proxy = this.getDragEl();

        YAHOO.util.Dom.setStyle(proxy, "visibility", "");
        var a = new YAHOO.util.Motion( proxy, { points: {to: YAHOO.util.Dom.getXY(srcEl) } },
            0.2,
            YAHOO.util.Easing.easeOut
        )
        var proxyid = proxy.id;
        var thisid = this.id;

        // Hide the proxy and show the source element when finished with the animation
        a.onComplete.subscribe(function() {
                YAHOO.util.Dom.setStyle(proxyid, "visibility", "hidden");
                YAHOO.util.Dom.setStyle(thisid, "visibility", "");
                YAHOO.util.Dom.setStyle(thisid, "background-color", "");
                YAHOO.util.Dom.setStyle(thisid, "opacity", 1);
            });
        a.animate();
   },


    onDrag: function(e)
    {
        // Keep track of the direction of the drag for use during onDragOver
        var x = YAHOO.util.Event.getPageX(e);

        if (x < this.lastX)
        {
            this.goingLeft = true;
        }
        else if (x > this.lastX)
        {
            this.goingLeft = false;
        }

        this.lastX = x;
    },

    onDragOver: function(e, id)
    {
        var srcEl = this.getEl();
        var destEl = YAHOO.util.Dom.get(id);

        if (destEl.nodeName.toLowerCase() == "td")
        {
			if (this.goingLeft){
				this.colList.insert(srcEl, destEl);
			}else{
				this.colList.insert(srcEl, destEl.nextSibling);
			}

            YAHOO.util.DragDropMgr.refreshCache();
        }
    }
});