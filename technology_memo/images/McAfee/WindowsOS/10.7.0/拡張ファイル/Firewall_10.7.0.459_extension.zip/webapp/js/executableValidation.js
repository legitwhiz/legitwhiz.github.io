var errorKey = '';

var signerType = 0;
var matchType = 0;

function validateExeName(value) {

    var validName = OrionValidate.isNotEmpty(value);

    return validName;


}

function exePageValidate(isValid)
{
    enableExeButtons(false);
    if (isValid)
    {
        enableExeButtons(true);
    }
}

function enableExeButtons(isValid)
{
    OrionCore.setEnabledById("orion.dialog.box.ok", isValid);
}



function enableSig() {
    if (document.forms[0].signerType[0].checked) {
        OrionCore.setEnabledById("signerName", false);
        signerType = 0;

    } else if (document.forms[0].signerType[1].checked) {
        OrionCore.setEnabledById("signerName", false);
        signerType = 1;

    } else  if (document.forms[0].signerType[2].checked) {
        OrionCore.setEnabledById("signerName", true);
        signerType = 2;
    }
}


function validatePath(value) {

    var enable = false;
    enable = OrionValidate.isValidWindowsFilePath(value);


    return enable;
}

function validateFingerprint(value) {

    var validPrint = OrionValidate.isNotEmpty(value);

    return validPrint;
}


function validateSigner() {
    signerValid = false;
    if (document.forms[0].signerType[0].checked) {
        signerValid = true;
    }
    return signerValid;
}
