/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * <p>This binding object is used to preserve the structure of an object tree.  propBindingMap needs an entry for each
 * property of the object that will be passed to setValue.  The bindings in propBindingMap will be called from this
 * binding's setValue method with that property's value.  Similarly, ChainedMapBinding.getValue will construct the
 * object's properties by calling getValue on the binding registered for that property.
 *
 * <p>In most cases, you build a heirarchy of ChainedMapBinding objects with leaf nodes used to actually display the
 * values of properties that your UI cares about.  Use NullBinding objects to store property values that you don't
 * care to display or manipulate.  Example:
 *
 * <pre>
var executableBinding = new ChainedMapBinding({
	"executable": new ChainedMapBinding({ //most JSON has this single-property root structure, so this sort of nesting is common
		"id": new NullBinding(),  //we don't need to display these, but need to remember them
		"version": new NullBinding(),
		"@_NodeName": new NullBinding("executable"),  //NullBinding with a default value.
		"name": new ValueBinding("executable_name"),  //Name will go in the textbox with the id "executable_name"
		"filename": new ValueBinding("executable_filename"),
		"fingerprint": new FingerprintBinding("executable_fingerprint"), //custom-built binding object
		"signerName": new ValueBinding("executable_signerName"),
		"note": new ValueBinding("executable_note"),
		"lastModified": new TextContainerBinding("executable_lastModified"), //Want to display this, but not make editable
		"lastModifyingUsername": new TextContainerBinding("executable_lastModifyingUsername"),
		"spaces": new NullBinding()
	})
});

//Some hypothetical JSON that we might display; in practice, this is probably a request attribute filled in at run-time.
//So this would just be:
//executableBinding.setValue(${JSON_DATA});
executableBinding.setValue({
	"executable": {
		"id": "someId",
		"version": 2,
		"@_NodeName": "executable",
		"name": "Nasty Badness",
		"filename": "nastyBadness.exe",
		"fingerprint": "00000000000000000000000000000000",
		"signerName": "",
		"note": "this is a nasty, bad executable that we want to block",
		"lastModified": "some date string",
		"lastModifyingUsername": "admin",
		"spaces": "CATALOG,POLICY"
	}
});
</pre>
 *
 * @param propBindingMap An Object of the form {propName: bindingInstance}.  This maps property names to Binding
 * objects.
 */
function ChainedMapBinding(propBindingMap, orderedProps) {
	this.bindings = propBindingMap;
	if(!orderedProps){
		orderedProps = [];
	}
	this.orderedProps = orderedProps;
}

// arg1 has no specific semantics.  it's just provided so callers can pass a value to a subclass getValue()
ChainedMapBinding.prototype.getValue = function(arg1) {
	var ret = new Object();
	for (var prop in this.bindings) {
        ret[prop] = this.bindings[prop].getValue(arg1);
	}
	return ret;
};

ChainedMapBinding.prototype.setValue = function(value) {
	for(var i = 0; i < this.orderedProps.length; ++i){
		this.bindings[this.orderedProps[i]].setValue(value[this.orderedProps[i]]);
	}
	for (var prop in this.bindings) {
		var skip = false;
		for(i = 0; i < this.orderedProps.length; ++i){
			if(this.orderedProps[i] == prop){
				skip = true;
				break;
			}
		}
		if(!skip){
			this.bindings[prop].setValue(value[prop]);
		}
	}
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Allows you to combine several values into one binding, to, for example, render a single string from several values.
 * Generally, you construct a MultiValueBinding, optionally define a render method, and then call getView to generate
 * value-specific binding objects.
 * @param keys Each value must be identified by a key.
 */
function MultiValueBinding(keys){
	this.valueMap = new Object();
	for(var i = 0; i < keys.length; ++i){
		this.valueMap[keys[i]] = null;
	}
}

/**
 * This function generates binding objects that have the usual getValue and setValue, but are backed by the MultiValueBinding.
 * @param key
 */
MultiValueBinding.prototype.getView = function(key) {
	var view = new Object();
	var self = this;
	view.getValue = function() {
		return self.getValue(key);
	};
	view.setValue = function(value) {
		self.setValue(key, value);
	};
	return view;
};

MultiValueBinding.prototype.getValue = function(key) {
	return this.valueMap[key];
};

MultiValueBinding.prototype.setValue = function(key, value) {
	this.valueMap[key] = value;
	for (key in this.valueMap) {
		if (this.valueMap[key] == null) {
			return;
		}
	}
	//fell through, so we're all set
	if (this.render) {
		this.render();
	}
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Basic Binding class, based on "value" property.  Appropriate for input elements of types text,
 * password, hidden, textareas, and selects.
 */
function ValueBinding(id) {
	this.id = id;
}

/**
 * Basic getter for the underlying element's value attribute.  Override if this isn't what you want.
 */
ValueBinding.prototype.getValue = function() {
	return document.getElementById(this.id).value;
};

/**
 * Basic setter for the underlying element's value attribute.  Override if this isn't what you want.
 */
ValueBinding.prototype.setValue = function(value) {
	document.getElementById(this.id).value = value;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
function MappedValueBinding(valueMap, subBinding){
	this.valueMap = valueMap;
	this.inverseValueMap = new Object();
	for(var key in valueMap){
		this.inverseValueMap[valueMap[key]] = key;
	}
	this.subBinding = subBinding;
}

MappedValueBinding.prototype.getValue = function() {
	var insideValue = this.subBinding.getValue();
	var mappedValue = this.inverseValueMap[insideValue];
	if(mappedValue != null){
		return mappedValue;
	}
	return insideValue;
};

MappedValueBinding.prototype.setValue = function(value) {
	var insideValue = this.valueMap[value];
	if(insideValue == null){
		insideValue = value;
	}
	this.subBinding.setValue(insideValue);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
function HexValueBinding(id){
	this.id = id;
}

HexValueBinding.prototype.getValue = function() {
	var value = document.getElementById(this.id).value;
	var matches = /^\s*(\S|\S.*\S)\s*$/.exec(value);
	if (!matches) {
		return "";
	}
	value = matches[1]; //value = value.trim();
	if (value == "") {
		return "";
	}
	return parseInt(value, 16);
};

HexValueBinding.prototype.setValue = function(value) {
	if (value != "") {
		value = value.toString(16);
	}
	document.getElementById(this.id).value = value;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Appropriate for checkboxes, and individual radio buttons.  See RadioGroupBinding for radio button
 * group support.  getValue returns the underlying checked state, rather than the binding's "value" attribute.
 *
 * @param id The input element ID.
 */
function BooleanBinding(id) {
	this.id = id;
}

BooleanBinding.prototype.getValue = function() {
	return document.getElementById(this.id).checked;
};

BooleanBinding.prototype.setValue = function(value) {
	document.getElementById(this.id).checked = value;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Maps boolean values true and false onto Strings "true" and "false" (by default), and uses the strings with a subbinding.
 *
 * @param subBinding The sub-binding.
 */
function BooleanStringBinding(subBinding, trueValue, falseValue) {
	this.subBinding = subBinding;
	this.trueValue = trueValue ? trueValue: "true";
	this.falseValue = falseValue ? falseValue: "false";
}

BooleanStringBinding.prototype.getValue = function() {
	var boolStr = this.subBinding.getValue();
	return boolStr == this.trueValue;
};

BooleanStringBinding.prototype.setValue = function(value) {
	this.subBinding.setValue(value ? this.trueValue : this.falseValue);
};


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Binds the JSON representation of an EnumSet to a set of checkboxes that have the same name.
 * @param name The (shared) name property of the checkboxes.
 */
function EnumSetBooleanBinding(name){
	var elements = document.getElementsByName(name);
	this.valueMap = new Object();
	for(var i = 0; i < elements.length; ++i){
		this.valueMap[elements[i].value] = elements[i];
	}
}

EnumSetBooleanBinding.prototype.getValue = function() {
	var values = new Array();
	for (var x in this.valueMap) {
		if (this.valueMap[x].checked) {
			values.push(x);
		}
	}
	return [values.join(",")];
};

EnumSetBooleanBinding.prototype.setValue = function(value) {
	for (var x in this.valueMap) {
		this.valueMap[x].checked = false;
	}

	var values = value[0].split(/\s*,\s*/);
	if (values.length == 1 && values[0] == "") {
		return;
	}
	for (var i = 0; i < values.length; ++i) {
		this.valueMap[values[i]].checked = true;
	}
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Binds individual bits from a bitmask to a set of checkboxes that have the same name.  The
 * "value" property of each checkbox must coorespond to its bit ordinal, 0 as LSB.
 * @param name The (shared) name property of the checkboxes.
 */
function BitMaskBooleanBinding(name){
	var elements = document.getElementsByName(name);
	this.valueMap = new Object();
	for(var i = 0; i < elements.length; ++i){
		this.valueMap[elements[i].value] = elements[i];
	}
}

BitMaskBooleanBinding.prototype.getValue = function() {
	var value = 0;
	for (var x in this.valueMap) {
		if (this.valueMap[x].checked) {
			value |= 1 << x;
		}
	}
	return value;
};

BitMaskBooleanBinding.prototype.setValue = function(value) {
	for (var x in this.valueMap) {
		this.valueMap[x].checked = !!(value & (1 << x));
	}
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Makes the controlled element's only child a text node listing the bits that are
 * set in the bitmask.
 *
 * @param id Indicates the controlled element.
 * @param bitNames An array that maps bit indicies to display strings.
 */
function BitMaskTextBinding(id, bitNames){
	this.id = id;
	this.bitNames = bitNames;
	this.value = null;
}

BitMaskTextBinding.prototype.setValue = function(value) {
	this.value = value;

	var text = "";
	for (var i = 0; i < this.bitNames.length; ++i) {
		if ((value & (1 << i)) != 0) {
			if (text != "") {
				text += ", ";
			}
			text += this.bitNames[i];
		}
	}

	var container = document.getElementById(this.id);
	while (container.firstChild != null) {
		container.removeChild(container.firstChild);
	}
	container.appendChild(document.createTextNode(text));
};

BitMaskTextBinding.prototype.getValue = function() {
	return this.value;
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * A Binding appropriate for radio button groups.  Example: <code>new RadioGroupBinding("radioId1", "radioId2")</code>
 *
 * If you pass one parameter, it is treated as the radio group's common name.  Otherwise, the parameter list is
 * assumed to name each radio button by ID.
 * 
 * @param name the name for the radio group.
 * @param id... a variable number of individual button IDs.  Generally more than one.
 */
function RadioGroupBinding(name) {
	if(arguments.length == 1){
		var elems = document.getElementsByName(name);
		this.ids = new Array();
		for(var i = 0; i < elems.length; ++i){
			this.ids.push(elems[i].id);
		}
	}else{
		this.ids = Array.prototype.slice.call(arguments); //this magic converts our varargs into a real array
	}
}

RadioGroupBinding.prototype.getValue = function() {
	var value = null;
	for (var i = 0; i < this.ids.length; ++i) {
		var elem = document.getElementById(this.ids[i]);
		if (elem.checked) {
			value = elem.value;
			break;
		}
	}
	return value;
};

RadioGroupBinding.prototype.setValue = function(value) {
	for (var i = 0; i < this.ids.length; ++i) {
		var elem = document.getElementById(this.ids[i]);
		if (elem.value == value) {
			elem.checked = true;
			return;
		}
	}
	throw new Error("Cannot set value: " + value);
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Binding that doesn't bind to a control, just remembers its value.  Useful for JSON metadata.
 */
function NullBinding(defaultValue){
	if(defaultValue === (void 0)){ //check for undefined and make null, which are slightly different
		defaultValue = null;
	}
	this.value = defaultValue;
}

NullBinding.prototype.getValue = function() {
	return this.value;
};

NullBinding.prototype.setValue = function(value) {
	this.value = value;
};


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * A generic list data binding.
 *
 * @param listBindingAdapter A ListBindingBuilderAdapter (or similar) that manages the Builder that we're supposed
 * to be bound to.  We set listBindingAdapter.listBinding at construction time, and call listBindingAdapter.addControl()
 * to add new elements to the builder.  Further, we expect to always have a binding object in the bindings array
 * for each control in the Builder, and we expect all our bindings to refer to controls that exist.
 *
 * @param bindings An optional array of the existing bindings objects.  By default, it is assumed that none exist.
 *
 * @param comparator Optional comparator to be used to sort the values during setValues. If not specified, no sorting is performed.
 */
function ListBinding(listBindingAdapter, bindings, comparator){
	if(bindings == null){
		bindings = new Array();
	}
	this.bindings = new Array();
	for(var i = 0; i < bindings.length; ++i){
		this.addBinding(bindings[i]);
	}
	listBindingAdapter.listBinding = this;
	this.listBindingAdapter = listBindingAdapter;
	this.nextIdValue = 1;
	this.comparator = comparator;
}

ListBinding.prototype.nextId = function() {
	return this.nextIdValue++;
};

ListBinding.prototype.addBinding = function(binding) {
	binding._listBindingId = this.nextId();
	this.bindings.push(binding);
};

ListBinding.prototype.removeBinding = function(binding) {
	for (var i = 0; i < this.bindings.length; ++i) {
		if (this.bindings[i]._listBindingId == binding._listBindingId) {
			this.bindings.splice(i, 1);
			return true;
		}
	}

	return false;
};

/**
 * An identity transform for type conversion.  Called by the getter to convert a view domain value into a model
 * domain object.  Override as necessary.
 * @param value
 */
ListBinding.prototype.decorateValue = function(value) {
	return value;
};

/**
 * An identity transform for type conversion.  Called by the setter to convert a model domain value into a view
 * domain object.  Override as necessary.
 * @param decoratedValue
 */
ListBinding.prototype.undecorateValue = function(decoratedValue) {
	return decoratedValue;
};

ListBinding.prototype.getValue = function() {
	var ret = new Array();
	for (var i = 0; i < this.bindings.length; ++i) {
		ret.push(this.decorateValue(this.bindings[i].getValue()));
	}

	return ret;
};

ListBinding.prototype.setValue = function(values) {
	var i;
	if(this.comparator){
		values.sort(this.comparator);
	}
	this.listBindingAdapter.truncate(values.length);
	for (i = 0; i < values.length && i < this.bindings.length; ++i) {
		this.bindings[i].setValue(this.undecorateValue(values[i]));
	}
	while (i < values.length) {
		this.listBindingAdapter.addControl();
		this.bindings[i].setValue(this.undecorateValue(values[i]));
		++i;
	}
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
function SingletonListBinding(subBinding){
	this.subBinding = subBinding;
}

SingletonListBinding.prototype.getValue = function() {
	var value = this.subBinding.getValue();

	if (value != null) {
		return [value];
	} else {
		return [];
	}
};

SingletonListBinding.prototype.setValue = function(list) {
	this.subBinding.setValue(list[0]);
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Binds a value to the first child (which will be a text node) of the element with
 * the given ID.  The valueMap parameter can be used to control the rendering of the
 * value.  For further control or more complex rendering, override the renderValue
 * method.
 * @param id
 * @param valueMap
 */
function TextContainerBinding(id, valueMap){
	this.id = id;
	this.value = null;
	this.valueMap = valueMap;
}

TextContainerBinding.prototype.setValue = function(value){
	if((this.id=="summary_schedule_start_time_hour")||
		(this.id=="summary_schedule_start_time_min")||
		(this.id=="summary_schedule_end_time_hour")||
		(this.id=="summary_schedule_end_time_min")||
		(this.id=="groupSummary_schedule_start_time_hour")||
		(this.id=="groupSummary_schedule_start_time_min")||
		(this.id=="groupSummary_schedule_end_time_hour")||
		(this.id=="groupSummary_schedule_end_time_min")
	){
		if(value < 10){
			value = "0"+value;
		}
	}
	this.value = value;
	var container = document.getElementById(this.id);
	while(container.firstChild != null){
		container.removeChild(container.firstChild);
	}
	container.appendChild(this.renderValue(value));
};

TextContainerBinding.prototype.renderValue = function(value){
	var text;
	if(value != null){
		if(this.valueMap != null){
			text = this.valueMap[value.toString()];
		}else{
			text = value.toString();
		}
	}else{
		text = "";
	}
	return document.createTextNode(text);
};

TextContainerBinding.prototype.getValue = function(){
	return this.value;
};


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Binds a date value to the first child (which will be a text node) of the element with
 * the given ID.
 * @param id
 */
function DateBinding(id){
	DateBinding.superclass.constructor.call(this, id);
	//XML datetime pattern groups.  1: year, 2: month, 3: day, 4: hour, 5: minute, 6: second, 7: Timezone offset
	this.dateRe = /^(\d\d\d\d)-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d(?:\.\d+)?)((?:[-+]\d\d:\d\d)|Z)$/;
}

YAHOO.extend(DateBinding, TextContainerBinding, {
	renderValue: function(value){
		var text = "";
		var match = this.dateRe.exec(value);
		if(match){
			//parse timezone into minute offset
			var tz = match[7];
			if(tz == "Z"){
				tz = "+00:00";
			}
			var tzSign = 1;
			if(tz.charAt(0) == "-"){
				tzSign = -1;
			}
			var tzMins = 60 * parseInt(tz.slice(1,3), 10);
			tzMins += parseInt(tz.slice(4,6), 10);
			tzMins *= tzSign;

			//the Date constructor always assumes local time.  So we need to adjust tzMins by the local offset.
			tzMins += new Date().getTimezoneOffset();

			var d = new Date(
					parseInt(match[1],10), //y
					parseInt(match[2],10)-1, //month
					parseInt(match[3],10), //d
					parseInt(match[4],10), //h
					parseInt(match[5],10) - tzMins, //minutes; ECMA-262 implies this is a valid way to deal with tz offset
					parseInt(match[6],10)); //s

			text = d.toLocaleString();
		}
		return document.createTextNode(text);
	}
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This binding will hide or show the element in question depending on the boolean
 * sense of the value.  By default, shows the element when true.
 * @param id The id of the controlled element.
 * @param invert Show the element when the value is false.
 */
function HideShowBooleanBinding(id, invert){
	this.id = id;
	this.invert = !!invert;
	this.value = null;
}

HideShowBooleanBinding.prototype.setValue = function(value) {
	//hide on false, unless inverted.
	this.setHidden(this.id, this.invert ? value : !value);
	this.value = value;
};

HideShowBooleanBinding.prototype.getValue = function() {
	return this.value;
};

HideShowBooleanBinding.prototype.setHidden = function(idOrElem, isHidden) {
	var elem;
	if (idOrElem.constructor == String) {
		elem = document.getElementById(idOrElem);
	} else {
		elem = idOrElem;
	}
	if (isHidden) {
		elem.style.display = "none";
	} else {
		elem.style.display = ""; //stop overriding any classes, etc.
	}
};


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This binding will hide or show the element in question depending on the value.
 * The default behavior is to hide when the value is null or an empty Array.  Override
 * the shouldHide method to customize the behavior.
 *
 * In addition to the hide/show behavior, this binding chains to a subBinding.  Sort
 * of. setValue will delegate to the analogous method on the subBinding, if the
 * controlled element is not hidden.  The "protects" the delegate from a null
 * setValue call.
 *
 * @param id The id of the controlled element.
 * @param subBinding The binding delegate.
 */
function HideShowObjectBinding(id, subBinding){
	this.id = id;
	this.subBinding = subBinding;
	this.value = null;
}

HideShowObjectBinding.prototype.setValue = function(value) {
	this.value = value;
	if (this.shouldHide(value)) {
		this.setHidden(this.id, true);
	} else {
		this.setHidden(this.id, false);
		this.subBinding.setValue(value);
	}
};

HideShowObjectBinding.prototype.shouldHide = function(value) {
	return value == null || (value.constructor == Array && value.length == 0);
};

HideShowObjectBinding.prototype.getValue = function() {
	return this.value;
};

HideShowObjectBinding.prototype.setHidden = function(idOrElem, isHidden) {
	var elem;
	if (idOrElem.constructor == String) {
		elem = document.getElementById(idOrElem);
	} else {
		elem = idOrElem;
	}
	if (isHidden) {
		elem.style.display = "none";
	} else {
		elem.style.display = ""; //stop overriding any classes, etc.
	}
};


/**
 * Splits a string into two parts on a separator, and binds the parts to separate controls.
 * Setting null results in empty strings in the bound controls; similarly getting empty strings from
 * the control with id1 results in null.
 * @param sep Separator
 * @param id1 The id of the first control, bound to the first half of the string.
 * @param id2 The id of the second control.
 */
function StringSplitBinding(sep, id1, id2){
	this.sep = sep;
	this.id1 = id1;
	this.id2 = id2;
}

StringSplitBinding.prototype.getValue = function() {
	var halves = new Array();
	halves[0] = document.getElementById(this.id1).value;
	if (halves[0] != null && halves[0] != "") {
		halves[1] = document.getElementById(this.id2).value;
		return halves.join(this.sep);
	} else {
		return null;
	}
};

StringSplitBinding.prototype.setValue = function(value) {
	if (value != null) {
		var halves = value.split(this.sep, 2);
		document.getElementById(this.id1).value = halves[0];
		if (halves.length > 1) {
			document.getElementById(this.id2).value = halves[1];
		} else {
			document.getElementById(this.id2).value = "";
		}
	} else {
		document.getElementById(this.id1).value = "";
		document.getElementById(this.id2).value = "";
	}
};