
/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

function ServiceFormatter(services){
	var keys = [];
	var values = {};
	jQuery.each(services, function() {
		keys.push(this.port);
		values[this.port] = this;
	});
	this.keys = keys;
	this.values = values;
}

ServiceFormatter.prototype.format = function(key){
	var val = this.values[key];
	if(val){
		return val.name + " (" + val.port + ")";
	}
	return key;
};

function validateServiceList(str, fieldId) {
	try{
		var serviceList = parseServiceList(str);
		jQuery("#"+fieldId).nextAll("input[type=hidden]").val(serviceList);
	}catch(e){
		return false;
	}

	return true;
}

function formatServiceList(str, formatter){
	str = jQuery.trim(str);
	//Allow empty string
	if(str.length == 0){
		return str;
	}

	var result = "";
	var terms = str.split(/\s*,\s*/);
	for(var i = 0; i < terms.length; ++i){
		var term = jQuery.trim(terms[i]);
		var parts = term.split("-");
		var formattedTerm;
		if(parts.length == 2){
			formattedTerm = formatter.format(parts[0]) + " - " + formatter.format(parts[1]);
		}else{
			formattedTerm = formatter.format(term);
		}
		if(result.length != 0){
			result += ", ";
		}
		result += formattedTerm;
	}

	return result;
}

/**
 * Parses a service set string (with optional service names) into an IntegerRangeSet string.
 * @param str The string to parse.  Has parts of the form "http (80)".  Terms are single
 * parts, or ranges (dash separated) of parts.  Terms are comma-separated.
 *
 * E.g. "http (80), https (443), 1234 - 2345"
 * @return An IntegerRangeSet string.  E.g. "80, 443, 1234-2345"
 */
function parseServiceList(str){
	str = jQuery.trim(str);
	//Allow empty string
	if(str.length == 0){
		return str;
	}
	//ignore a trailing comma
	if(str.charAt(str.length-1) == ","){
		str = str.substring(0, str.length - 1);
	}

	var servicesRangeSetStr = "";
	var terms = str.split(/\s*,\s*/);
	for(var i = 0; i < terms.length; ++i){
		var term = jQuery.trim(terms[i]);
		var resultStr;
		//this regex unambiguously breaks ranges into their parts, allowing for dashes in service names.
		var rangeExp = /(\d+|\w[\w\d-]*\s+\(\d+\))\s*-\s*(\d+|\w[\w\d-]*\s+\(\d+\))/;
		var groups = rangeExp.exec(term);
		if(groups){
			var first = parseInt(parsePart(groups[1]));
			var second = parseInt(parsePart(groups[2]));
            if(first > second)
            {
                throw new Error("Lower port number should be first when using range");
            }
			resultStr = first + "-" + second;
		}else{
			resultStr = parsePart(term);
		}

		if(servicesRangeSetStr.length != 0){
			servicesRangeSetStr += ", ";
		}
		servicesRangeSetStr += resultStr;
	}

	return servicesRangeSetStr;
}

/**
 * Extract the port number from the part.
 * @param serviceStr a "part" of the form "http (80)" or just "80".
 * @return the port number string.
 */
function parsePart(serviceStr){
	serviceStr = jQuery.trim(serviceStr);
	var groups = /^\w[\w-]*\s+\((\d+)\)$/.exec(serviceStr);
	if(groups){
		var portNum = parseInt(groups[1]);
		if(portNum >= 0 && portNum <= 65535){
			return portNum.toString();
		}
	}else if(/^\d+$/.test(serviceStr)){
		portNum = parseInt(serviceStr);
		if(portNum >= 0 && portNum <= 65535){
			return portNum.toString();
		}
	}
	throw new Error("\"" + serviceStr + "\" is not a valid service specification");
}
