/**
 * Copyright (C) 2017-2019, McAfee, LLC.  All Rights Reserved.
 *
 * policyutil.js:
 *	Note:  This file contains references to request attributes.  The file must be
 *	included at compile time, and process by the jsp complier.  Use the JSP include directive.
 */
var PUTIL = window.PUTIL || new PolicyUtil();
function PolicyUtil()
{
    /**
     * Initialize the request parameters from ePO pages
     * @param params
     */
    this.initEpoPolicyParams = function(params)
    {
        setBackTypeParam(params);
        switch("${backType}")
        {
            case 'SINGLE_SLOT_POLICY':
            case 'MULTI_SLOT_POLICY':
                initSlotAssignmentParams(params);
                break;
        }
    };

    /**
     * Set the 'backType' request parameter for navigation on policy save \ cancel.
     * Refer to BZ 1239972
	 * @param params
	 */
    function setBackTypeParam(params)
    {
        params.push('backType');
        params.push("${backType}");
    }

    /**
     * Set the request parameters for navigation back to ePO slot assignment
     * pages on policy save \ cancel.
     * Refer to BZ 1259356
     * @param params
     */
    function initSlotAssignmentParams(params)
    {
        params.push('nodeID');
        params.push("${nodeID}");
        params.push('nodeType');
        params.push("${nodeType}");
    }
}