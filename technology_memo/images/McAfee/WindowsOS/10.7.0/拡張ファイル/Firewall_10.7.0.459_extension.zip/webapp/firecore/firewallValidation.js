
function isValidHex(field) {
    var HexRegExpString = "^[A-Fa-f0-9]*$";
    var hexRegExp = new RegExp(HexRegExpString);
    var isValid = false;

    isValid = hexRegExp.test(field);

    return isValid;
}

