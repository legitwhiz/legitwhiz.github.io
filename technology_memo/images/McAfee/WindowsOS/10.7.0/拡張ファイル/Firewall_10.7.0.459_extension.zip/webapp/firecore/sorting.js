/*
 * Copyright (C) 2007-2009, McAfee, Inc.  All Rights Reserved.
 */

function propertyComparator(prop, left, right){
	var leftProp = left[prop];
	var rightProp = right[prop];
	if(leftProp < rightProp){
		return -1;
	}
	if(leftProp > rightProp){
		return 1;
	}
	return 0;
}

function hostComparator(left, right){
	return propertyComparator("ipStr", left, right);
}

function nameComparator(left, right){
	return propertyComparator("name", left, right);
}

function stringComparator(left, right){
	if(left < right){
		return -1;
	}
	if(left > right){
		return 1;
	}
	return 0;
}


function safeSortAndReturn(array, comparator){
	if(array && array.length != null && array.length > 0){
		if(comparator){
			array.sort(comparator);
		}else{
			array.sort();
		}
	}
	return array;
}
