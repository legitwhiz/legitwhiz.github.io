function validateRuleName(input)
{
    var valid = true;
    var szBadChars = ":\\\"`!@#$%^&*/=;,<>?|";

    for (var i = 0; i < szBadChars.length; i++)
    {
        if (input.indexOf(szBadChars.charAt(i)) != -1)
        {
            valid = false;
        }
    }
    return valid;
}

function validateNetName(input)
{
    var valid = true;
    var szBadChars = ":\\\"`!@#$%^&*/=;,<>?|";

    for (var i = 0; i < szBadChars.length; i++)
    {
        if (input.indexOf(szBadChars.charAt(i)) != -1)
        {
            valid = false;
        }
    }
    return valid;
}

/**
 * Returns true if the argument string represents a valid domain definition.
 */
isValidDomain = function(string)
{
    if (!string || string == null)
    {
        return false;
    }

    string = OrionCore.trim(string);

        // ensure that the address contains only lower ASCII characters
    var sAsciiChars = "^[\\x00-\\x7f]+$";
    if (! new RegExp(sAsciiChars).test(string))
    {
        return false;
    }

    var sQtext = '[^\\x0d\\x22\\x5c\\x80-\\xff]';
    var sDtext = '[^\\x0d\\x5b-\\x5d\\x80-\\xff]';
    var sAtom = '[^\\x00-\\x20\\x22\\x28\\x29\\x2c\\x2e\\x3a-\\x3c\\x3e\\x40\\x5b-\\x5d\\x7f-\\xff]+';
    var sQuotedPair = '\\x5c[\\x00-\\x7f]';
    var sDomainLiteral = '\\x5b(' + sDtext + '|' + sQuotedPair + ')*\\x5d';
    var sQuotedString = '\\x22(' + sQtext + '|' + sQuotedPair + ')*\\x22';
    var sDomain_ref = sAtom;
    var sSubDomain = '(' + sDomain_ref + '|' + sDomainLiteral + ')';
    var sDomain = sSubDomain + '(\\x2e' + sSubDomain + ')*';
    var sValidDomain = '^' + sDomain + '$';

    var reValidDomain = new RegExp(sValidDomain);

    if (reValidDomain.test(string))
    {
        return true;
    }

    return false;
}
