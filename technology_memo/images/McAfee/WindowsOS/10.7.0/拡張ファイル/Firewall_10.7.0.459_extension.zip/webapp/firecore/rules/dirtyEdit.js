function SingletonListDefaultBinding(id) {
	this.id = id;
}

SingletonListDefaultBinding.prototype.getValue = function() {
	var val = document.getElementById(this.id).value;
	return [val];
}

SingletonListDefaultBinding.prototype.setValue = function(value) {
	var val = value[0];
	if(val == null){
		val = "";
	}
	document.getElementById(this.id).value = val;
}

function LocationBinding(valMap) {
	this.bindings = valMap;
	this.startJson = toJsonString(this.simpleGetValue());
	this.isNull = true;
}

/**
 * @return object state of child bindings, if it has changed.  Otherwise null.
 */
LocationBinding.prototype.getValue = function() {
	var controlState = this.simpleGetValue();
	if(!this.isNull || this.startJson != toJsonString(controlState)){
		//enforce validity constraints
		this.makeEmptyArrayIfNull(controlState, "dnsSuffix");
		this.makeEmptyArrayIfNull(controlState, "dhcpServer");
		this.makeEmptyArrayIfNull(controlState, "defaultGateway");
		this.makeEmptyArrayIfNull(controlState, "dnsServer");
		this.makeEmptyArrayIfNull(controlState, "primaryWins");
		this.makeEmptyArrayIfNull(controlState, "secondaryWins");

		return controlState;
	}
	return null;
}

LocationBinding.prototype.makeEmptyArrayIfNull = function(obj, prop){
	if(obj[prop] == null){
		obj[prop]= new Array();
	}
}

LocationBinding.prototype.simpleGetValue = function() {
	var ret = new Object();
	for (var prop in this.bindings) {
		ret[prop] = this.bindings[prop].getValue();
	}
	return ret;
}

LocationBinding.prototype.setValue = function(value) {
	if(value != null){
		this.isNull = false;
		for (var prop in this.bindings) {
			this.bindings[prop].setValue(value[prop]);
		}
	}else{
		this.isNull = true;
	}
}

function inputCreateContent(contentContainer){
	var thing = document.createElement("input");
	thing.setAttribute("type", "text");
	var id = this._getNextId();
	thing.setAttribute("id", id);

	contentContainer.appendChild(thing);
}
