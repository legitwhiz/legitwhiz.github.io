/*
 * Copyright (C) 2007-2009, McAfee, Inc.  All Rights Reserved.
 */

//The IP 4/6 range/subnet/address/fqdn object.

/**
 Possible entry formats:
 Single v4
 Single v6
 CIDR v4
 CIDR v6
 Range v4
 Range v6
 fqdn
 IpAddress.*_STR

 The constructor will throw when its parameter is invalid.

 The str field contains the internal representation of the data.  Put this in the database.

 The displayString method pretty-prints the IpAddress.

 The getAddrType method returns one of the type integer constants.
 */

function IpAddress(s)
{
    this.containsIp4Only = true;
    if (!s)
    {
        s = IpAddress.ANY_STR;
    }
    s = String(s).toLowerCase();
    if (s == IpAddress.TRUSTED_STR || s == IpAddress.ANY_LOCAL_IP_STR)
    {
        this.str = s.toLowerCase();
    } else if (s == IpAddress.LOCAL_SUBNET_STR || s == IpAddress.ANY_STR)
    {
        this.str = s;
    } else
    {
        this.str = this.normalizeEntry(s);
    }
}

IpAddress.prototype.displayString = function ()
{
    var addrType = this.getAddrType();
    if (addrType == IpAddress.SINGLE)
    {
        return this.displaySingle(this.str);
    } else if (addrType == IpAddress.FQDN)
    {
        return this.str;
    } else if (addrType == IpAddress.NETWORK)
    {
        var ipPart = this.str.slice(0, IpAddress.IPV6_LEN);
        var cidrPart = this.str.slice(IpAddress.IPV6_LEN + 1);
        if (this.isIp4(ipPart))
        {
            cidrPart = Number(cidrPart) - 96;
        }
        return this.displaySingle(ipPart) + "/" + cidrPart;
    } else if (addrType == IpAddress.RANGE)
    {
        var start = this.str.slice(0, IpAddress.IPV6_LEN);
        var end = this.str.slice(IpAddress.IPV6_LEN + 1);
        return this.displaySingle(start) + "-" + this.displaySingle(end);
    } else if (addrType == IpAddress.ANY)
    {
        return IpAddress.ANY_STR;
    }

    return this.str;
};

IpAddress.prototype.getAddrType = function () {
    if (this.str.charAt(0) == '[') {
        if (this.str.charAt(1) == 't') {
            //trusted
            return IpAddress.TRUSTED;
        } else {
            return IpAddress.ANY_LOCAL_IP;
        }
    } else if (this.str.length < IpAddress.IPV6_LEN || this.str.charAt(4) != ':') {
        //FQDN
        return IpAddress.FQDN;
    } else if (this.str.length == IpAddress.IPV6_LEN) {
        if (this.str == "0000:0000:0000:0000:0000:0000:0000:0000") {
            //Any
            return IpAddress.ANY;
        } else if (this.str == "0000:0000:0000:0000:0000:ffff:0000:0000") {
            //Local Subnet
            return IpAddress.LOCAL_SUBNET;
        } else {
            //Single
            return IpAddress.SINGLE;
        }
    } else if (this.str.charAt(IpAddress.IPV6_LEN) == '/') {
        //Subnet
        return IpAddress.NETWORK;
    } else if (this.str.indexOf('-') != -1) {
        //Range
        if (this.str == IpAddress.ANY_IP4_STR) {
            return IpAddress.ANY_IP4;
        } else if (this.str == IpAddress.ANY_IP6_STR) {
            return IpAddress.ANY_IP6;
        }
        return IpAddress.RANGE;
    }
};

IpAddress.prototype.toString = function ()
{
    return this.str;
};

//These are literals that can be passed to the constructor to create an IpAddress of the appropriate type.
IpAddress.TRUSTED_STR = "[trusted]";
IpAddress.LOCAL_SUBNET_STR = "0000:0000:0000:0000:0000:ffff:0000:0000";
IpAddress.ANY_STR = "0000:0000:0000:0000:0000:0000:0000:0000";
IpAddress.ANY_IP4_STR = "0000:0000:0000:0000:0000:ffff:0000:0000-0000:0000:0000:0000:0000:ffff:ffff:ffff";
IpAddress.ANY_IP6_STR = "0000:0000:0000:0000:0000:0000:0000:0000-ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff";
IpAddress.ANY_LOCAL_IP_STR = "[local]";

//These are the address types return by getAddrType
IpAddress.SINGLE = 0;
IpAddress.NETWORK = 1;
IpAddress.LOCAL_SUBNET = 2;
IpAddress.RANGE = 3;
IpAddress.ANY = 4;
IpAddress.TRUSTED = 5;
IpAddress.DOMAIN = 6; //stored separately
IpAddress.FQDN = 7;
IpAddress.ANY_LOCAL_IP = 9;
IpAddress.ANY_IP4 = 10;
IpAddress.ANY_IP6 = 11;

/////////////////////////////////////////////////////////////////////////////////////////////////
//Privates///////////////////////////////////////////////////////////////////////////////////////
IpAddress.IPV6_LEN = 39;

//this regex matches dotted-quad IPv4 addresses, like 123.123.123.123
IpAddress.v4addr = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/;
//this monster matches all valid IPv6 addresses, including the embedded dotted-quad notation
IpAddress.v6addr = /^(^(([0-9A-Fa-f]{1,4}(((:[0-9A-Fa-f]{1,4}){5}::[0-9A-Fa-f]{1,4})|((:[0-9A-Fa-f]{1,4}){4}::[0-9A-Fa-f]{1,4}(:[0-9A-Fa-f]{1,4}){0,1})|((:[0-9A-Fa-f]{1,4}){3}::[0-9A-Fa-f]{1,4}(:[0-9A-Fa-f]{1,4}){0,2})|((:[0-9A-Fa-f]{1,4}){2}::[0-9A-Fa-f]{1,4}(:[0-9A-Fa-f]{1,4}){0,3})|(:[0-9A-Fa-f]{1,4}::[0-9A-Fa-f]{1,4}(:[0-9A-Fa-f]{1,4}){0,4})|(::[0-9A-Fa-f]{1,4}(:[0-9A-Fa-f]{1,4}){0,5})|(:[0-9A-Fa-f]{1,4}){7}))$|^(::[0-9A-Fa-f]{1,4}(:[0-9A-Fa-f]{1,4}){0,6})$)|^::$)|^(^(([0-9A-Fa-f]{1,4}((((:[0-9A-Fa-f]{1,4}){4}:)|(:[0-9A-Fa-f]{1,4}){3}:(:[0-9A-Fa-f]{1,4}){0,1})|((:[0-9A-Fa-f]{1,4}){2}:(:[0-9A-Fa-f]{1,4}){0,2})|((:[0-9A-Fa-f]{1,4}):(:[0-9A-Fa-f]{1,4}){0,3})|(:(:[0-9A-Fa-f]{1,4}){0,4})|(:[0-9A-Fa-f]{1,4}){5}))|^(::[0-9A-Fa-f]{1,4}(:[0-9A-Fa-f]{1,4}){0,4}))|^:):((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9]{0,2})$/;

//this matches cidr suffixes up to /32
IpAddress.v4cidr = /^\/3[0-2]$|^\/[12]\d$|^\/\d$/;
//and this goes up to /128
IpAddress.v6cidr = /^\/12[0-8]$|^\/1[01]\d$|^\/[1-9]\d$|^\/\d$/;

IpAddress.fqdn = /^(?:[a-zA-Z0-9\*\?](?:[-a-zA-Z0-9\*\?]*[a-zA-Z0-9\*\?])?\.)+[a-zA-Z0-9\*\?](?:[-a-zA-Z0-9\*\?]*[a-zA-Z0-9\*\?])?[a-zA-Z\*\?]$/;

//Any match to this pattern indicates that this is not a valid IPv4 or v6 address, range or network.  It may be an FQDN.
IpAddress.invalid = /[^0-9a-fA-F\.\/:-]/;

//Any match to this pattern indicates that the string is not a valid FQDN.  It may be a valid IP address though.
IpAddress.fqdnInvalid = /[^a-zA-Z0-9\*\?\.-]/;

IpAddress.prototype.isIp4Only = function ()
{
    return this.containsIp4Only;
};

IpAddress.prototype.normalizeEntry = function (entry)
{
    var sep;
    this.containsIp4Only = false;

    entry = String(entry);

    if (!IpAddress.fqdnInvalid.test(entry) //IpAddress.fqdn is O(2^n) for some strings.  This pattern catches those.
        && IpAddress.fqdn.test(entry)
        && !IpAddress.v4addr.test(entry))
    {
        //it's an FQDN
        this.containsIp4Only = true;
        return entry;
    } else if (IpAddress.invalid.test(entry))
    {
        throw new Error("Entry contains invalid characters");
    } else if ((sep = entry.indexOf('-')) != -1)
    {
        //must be a range
        var start = entry.slice(0, sep);
        var end = entry.slice(sep + 1);
        if (IpAddress.v4addr.test(start))
        {
            if (IpAddress.v4addr.test(end))
            {
                start = this.ip4to6(start);
                end = this.ip4to6(end);
                this.containsIp4Only = true;
            } else
            {
                throw new Error("IPv4 range ends with invalid IPv4 address");
            }
        } else if (IpAddress.v6addr.test(start))
        {
            if (IpAddress.v6addr.test(end))
            {
                start = this.normalizeIp6(start);
                end = this.normalizeIp6(end);
            } else
            {
                throw new Error("IPv6 range ends with invalid IPv6 address");
            }
        } else
        {
            throw new Error("Invalid IP range specified");
        }
        //assert that start < end
        for (var i = 0; i < start.length; ++i)
        {
            var startCode = start.charCodeAt(i);
            var endCode = end.charCodeAt(i);
            if (startCode > endCode)
            {
                throw new Error("IP range is backward");
            } else if (startCode < endCode)
            {
                break;
            }
        }
        return start + '-' + end;
    } else if ((sep = entry.indexOf('/')) != -1)
    {
        //must be a network address
        var addr = entry.substr(0, sep);
        var cidrPart = entry.substr(sep);

        if (IpAddress.v4addr.test(addr) && IpAddress.v4cidr.test(cidrPart))
        {
            addr = this.ip4to6(addr);
            //make the ip4 cidr an ip6 cidr
            cidrPart = '/' + String(96 + Number(cidrPart.slice(1)));
            this.containsIp4Only = true;
        } else if (IpAddress.v6cidr.test(cidrPart) && IpAddress.v6addr.test(addr))
        {
            addr = this.normalizeIp6(addr);
        } else
        {
            throw new Error("Invalid network specification");
        }
        return addr + cidrPart;
    } else
    {
        //must be a single IP
        if (IpAddress.v4addr.test(entry))
        {
            this.containsIp4Only = true;
            return this.ip4to6(entry);
        } else if (IpAddress.v6addr.test(entry))
        {
            return this.normalizeIp6(entry);
        }
    }
    throw new Error("Invalid entry");
};

IpAddress.prototype.normalizeIp6 = function (ip)
{
    var parts = ip.split(":");
    if (parts[parts.length - 1].indexOf(".") != -1)
    {
        //deal with dotted-quad suffix
        var bytes = parts[parts.length - 1].split(".");
        var hi = (parseInt(bytes[0]) << 8) + parseInt(bytes[1]);
        var low = (parseInt(bytes[2]) << 8) + parseInt(bytes[3]);
        hi = hi.toString(16);
        low = low.toString(16);

        parts[parts.length - 1] = hi;
        parts.push(low);
    }

    function normalizePart(ip6part)
    {
        var chars = ip6part.split("");
        while (chars.length < 4)
        {
            chars.unshift("0");
        }
        return chars.join("");
    }

    if (parts[0] == "")
    {
        parts[0] = "0000";
    }
    for (var i = 0; i < parts.length; ++i)
    {
        if (parts[i] != "")
        {
            parts[i] = normalizePart(parts[i]);
        } else
        {
            //empty part; this is where the double-colon was
            parts.splice(i, 1);  //remove the empty part
            var missingParts = 8 - parts.length;
            //insert zeros to fill out the address
            var j;
            for (j = 0; j < missingParts; ++j)
            {
                parts.splice(i + j, 0, "0000");
            }
            i += j - 1;
        }
    }

    return parts.join(":");
};

IpAddress.prototype.ip4to6 = function (ip)
{
    return this.normalizeIp6("0000:0000:0000:0000:0000:ffff:" + ip);
};

IpAddress.prototype.ip6to4 = function (s)
{
    s = s.slice(30);
    var parts = s.split(':');
    var a = (parseInt(parts[0], 16) >> 8) & 0xff;
    var b = parseInt(parts[0], 16) & 0xff;
    var c = (parseInt(parts[1], 16) >> 8) & 0xff;
    var d = parseInt(parts[1], 16) & 0xff;

    return a + "." + b + "." + c + "." + d;
};

IpAddress.prototype.isIp4 = function (s)
{
    return s.slice(0, 30).toLowerCase() == "0000:0000:0000:0000:0000:ffff:";
};

IpAddress.prototype.pretty6 = function (s)
{
    var parts = s.split(":");
    for (var i = 0; i < parts.length; ++i)
    {
        //strip leading zeros
        parts[i] = parseInt(parts[i], 16).toString(16);
    }

    //find the longest zero streak, and :: it
    var streakStart = 0;
    var streakLen = 0;
    var maxStreakStart = 0;
    var maxStreakLen = 0;
    var inStreak = false;
    //a streak of zeros can't include the last part, hence length-1
    for (i = 0; i < parts.length - 1; ++i)
    {
        if (parts[i] == '0')
        {
            ++streakLen;
            if (!inStreak)
            {
                inStreak = true;
                streakStart = i;
            }
        } else
        {
            if (streakLen > maxStreakLen)
            {
                maxStreakLen = streakLen;
                maxStreakStart = streakStart;
            }
            inStreak = false;
            streakLen = 0;
        }
    }
    if (inStreak)
    {
        //the last part processed was 0
        if (streakLen > maxStreakLen)
        {
            maxStreakLen = streakLen;
            maxStreakStart = streakStart;
        }
    }
    if (maxStreakLen >= 2)
    {
        //replace the streak with a single empty element, which will cause join to produce the ::
        parts.splice(maxStreakStart, maxStreakLen, "");
        if (maxStreakStart == 0)
        {
            parts.unshift(""); //so we can generate things like ::1
        }
    }

    return parts.join(":");
};

IpAddress.prototype.displaySingle = function (s)
{
    if (this.isIp4(s))
    {
        return this.ip6to4(s);
    } else
    {
        return this.pretty6(s);
    }
};
