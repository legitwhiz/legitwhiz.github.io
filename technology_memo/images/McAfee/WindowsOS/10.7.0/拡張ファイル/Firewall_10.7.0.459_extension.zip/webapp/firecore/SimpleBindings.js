/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

function FilterControlBinding(idOrSubBinding) {
	if(typeof idOrSubBinding == "string"){
		this.subBinding = new ValueBinding(idOrSubBinding);
	}else{
		this.subBinding = idOrSubBinding;
	}
}

FilterControlBinding.prototype.getValue = function() {
	var ret = this.subBinding.getValue();
	if(ret == ""){
		return null;
	}
	return ret;
};

FilterControlBinding.prototype.setValue = function(value) {
	if(value === (void 0)){
		value = "";
	}
	this.subBinding.setValue(value);
};


function ScheduleBinding(id, subBinding){
	ScheduleBinding.superclass.constructor.call(this, id, subBinding);
}

YAHOO.extend(ScheduleBinding, HideShowObjectBinding, {
	shouldHide: function(value){
		return value['scheduleEnabled'] == false;
	},
	setValue: function(value) {
		this.value = value;
		if (this.shouldHide(value)) {
			this.setHidden(this.id, true);
		} else {
			this.setHidden(this.id, false);
		}
		//always call subbinding
		this.subBinding.setValue(value);
	}
});


function FilenameBinding(subBinding){
	this.subBinding = subBinding;
}

FilenameBinding.prototype.getValue = function(){
	var text = this.subBinding.getValue();
	return filenameToModelTransform(text);
};

FilenameBinding.prototype.setValue = function(value){
	this.subBinding.setValue(filenameToDisplayTransform(value));
};


function FingerprintBinding(id){
	this.id = id;
}
FingerprintBinding.EMPTY_VAL = "00000000000000000000000000000000";

FingerprintBinding.prototype.getValue = function() {
	var value = document.getElementById(this.id).value;
	if(value == ""){
		value = FingerprintBinding.EMPTY_VAL;
	}

	return value;
};

FingerprintBinding.prototype.setValue = function(value) {
	if(value == FingerprintBinding.EMPTY_VAL){
		value = "";
	}

	document.getElementById(this.id).value = value;
};

function SignerNameBinding(noneId, anyId, specId, textId){
	this.noneId = noneId;
	this.anyId = anyId;
	this.specId = specId;
	this.textId = textId;
}

SignerNameBinding.prototype.getValue = function(){
	if(document.getElementById(this.noneId).checked) {

		if (document.getElementById(this.anyId).checked) {
			return "*";
		}
		else {
			return document.getElementById(this.textId).value;
		}
	}
	else{
		return "";
	}
};

SignerNameBinding.prototype.setValue = function(value){
	document.getElementById(this.textId).value = "";
	if(value == ""){
		document.getElementById(this.noneId).checked = false;
		document.getElementById(this.anyId).checked=true;
		document.getElementById(this.specId).checked=false;
		document.getElementById(this.textId).value="";
		document.getElementById(this.anyId).disabled=true;
		document.getElementById(this.specId).disabled=true;
		document.getElementById(this.textId).disabled=true;

	}else if(value == "*"){
		document.getElementById(this.noneId).checked = true;
		document.getElementById(this.anyId).checked = true;
		document.getElementById(this.textId).disabled=true;
	}else{
		document.getElementById(this.noneId).checked = true;
		document.getElementById(this.specId).checked = true;
		document.getElementById(this.textId).value = value;
	}
};
