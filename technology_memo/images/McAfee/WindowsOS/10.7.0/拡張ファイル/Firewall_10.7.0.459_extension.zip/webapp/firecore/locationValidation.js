/*
 * Copyright (C) 2007-2009, McAfee, Inc.  All Rights Reserved.
 */

function updateItems(status) {


    var divDisabled = false;
    var divClass = 'orionButtonEnabled';
    var imageStyle = '';

    if (!status) {
        divDisabled = true;
        divClass = 'orionButtonDisabled';
        imageStyle = 'none'
    }

    var divs = $("locationTable").getElementsByTagName("div");
    for (var i = 0; i < divs.length; i++) {

        var test = divs[i].getElementsByTagName('INPUT')[0];
        if (test != null) {

            var element = document.getElementById(test.id);
            if (element.type == 'text') {
                element.className = '';
            } else {
                element.className = divClass;
            }
            element.disabled = divDisabled;


            var imageFields = divs[i].getElementsByTagName('IMG');
            for (var l = 0; l < imageFields.length; l++) {

                imageFields[l].style.display = imageStyle;

            }
        }

    }

    OrionCore.setEnabledById("location_name", status);
    OrionCore.setEnabledById("location_note", status);
    OrionCore.setEnabledById("location_isolated", status);
    OrionCore.setEnabledById("location_requireEpoReachable", status);
    OrionCore.setEnabledById("location_regKeys", status);
    OrionCore.setEnabledById("location_regKeysValue", status);
    OrionCore.setEnabledById("location_note", status);


    var loadButton = $("loadCatalog");
    if (loadButton != null) {
        OrionCore.setEnabledById("loadCatalog", status);
    }

   enableAddButton();

}
function enableAddButton(){
    var requireLocation = $("requireLocation").checked;
    var addButton = $("addToCatalog");

   if (addButton != null) {
     OrionCore.setEnabledById("addToCatalog", false);


        if (OrionForm.isFormValid() && (OrionForm.isFormDirty() || globalIsDirty) && requireLocation) {

            OrionCore.setEnabledById("addToCatalog", true);
        }
    }
}

function setPageOptions(readOnly) {
    var status = false;
    var catalogItem = "";

    if (document.getElementById("requireLocation").checked && !readOnly) {
        status = true;

        catalogItem = getLocation().location.spaces.toString();
        if (catalogItem.indexOf("CATALOG") < 0) {
            updateItems(false);
        }

        OrionForm.revalidate();

    } else {
        OrionWizard.enableNavigation();
    }

    updateItems(status);
}


function initNavigation() {
    YAHOO.util.Event.addListener("orion_prevnext_next", "click", doSave);
}


function saveButtonStateController(isDirty, isValid) {


    OrionCore.setEnabledById("orion_prevnext_next", isValid && isDirty);


}




