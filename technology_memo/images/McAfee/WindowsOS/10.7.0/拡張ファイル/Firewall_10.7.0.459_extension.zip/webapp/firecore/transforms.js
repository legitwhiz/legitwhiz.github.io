/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

function filenameToDisplayTransform(text){
	if(/^\*\*\\/.test(text)){
		text = text.substr(3);
	}
	return text;
}

/**
 * If text does not begin with *, and text does not contain a path separator, prepend **\.
 * @param text
 */
function filenameToModelTransform(text){
	//non-empty strings that don't already start with wildcards or c:\ or a % or < get a prefix
	text = text.trim();
	if (!(text.length == 0
			|| /^\*\*.*[\/\\]/.test(text) 
			|| /^[\w\?]:[\/\\]/.test(text)
			|| /^[%<]/.test(text)
            || /[\\\\][\\\\]/.test(text)
			|| /^\/[\w\?\*]/.test(text))) {
		text = "**\\" + text;
	}
	return text;
}

function fingerprintToDisplayTransform(text){
	if(text == "00000000000000000000000000000000"){
		text = "";
	}
	return text;
}

function toProtocolString(transProtoNum, netProtoNums){
	//The "TCP/" part of "TCP/IPv4"
	var transString = this.transMap[transProtoNum];
	if(!transString){
		transString = "0x" + transProtoNum.toString(16);
	}
	transString = transString + "/";

	//this comparator sorts IPv4 and IPv6 to the top, and uses numeric comparison for others.
	function protoComparator(left, right){
		if(left == right){
			return 0;
		}
		if(left == 0x800){ //IPv4
			return -1;
		}
		if(right == 0x800){
			return 1;
		}
		if(left == 0x86dd){ //IPv6
			return -1;
		}
		if(right == 0x86dd){
			return 1;
		}
		return left - right;
	}
	netProtoNums.sort(protoComparator);

	//now we build the actual string.  Results in something like "TCP/IPv4, TCP/IPv6"
	var text = "";

    if (netProtoNums.length == 0) {
        text += transString + this.netMap[0];
    } else {
        for(var i = 0; i < netProtoNums.length; ++i){
            var netString = this.netMap[netProtoNums[i]];
            if(!netString){
                netString = "0x" + netProtoNums[i].toString(16);
            }
            if(text != ""){
                text += ", ";
            }
            if(netProtoNums[i] == 0x800 || netProtoNums[i] == 0x86dd){
                text += transString + netString;
            }else{
                text += netString;
            }
        }
    }

	return text;
}
