/*
 * Copyright (C) 2007-2010, McAfee, Inc.  All Rights Reserved.
 */

function createFWRulesFromClientRule80()
{
    function setMessageText(html)
    {
        if (OrionAction) OrionAction.addStatusMessage(html, OrionAction.STATUS_PLAIN);
    }

    function onCreateFailure()
    {
        OrionCore.showPleaseWait(false);
    }

    function onCreateFromClientRuleOK()
    {
        var mapParams = [
            "hip8_FWCopyDestination",$("selectedValue").value];

        OrionCore.showAsyncDialogBox(false);

        OrionCore.doAsyncAction("/ENDP_FW_META/CreateFWRulesFromClientRules.do", mapParams, setMessageText, onCreateFailure, "POST");
        return true;
    }

    function onCreateFromClientRuleCancel()
    {
        OrionCore.showAsyncDialogBox(false);
    }

    OrionCore.dialogBoxOkHandler = onCreateFromClientRuleOK;
    OrionCore.dialogBoxCancelHandler = onCreateFromClientRuleCancel;
    OrionCore.showAsyncDialogBox(true, "/ENDP_FW_META/ListFWTargetPolicies.do", OrionCore.DIALOG_OK_CANCEL);
}