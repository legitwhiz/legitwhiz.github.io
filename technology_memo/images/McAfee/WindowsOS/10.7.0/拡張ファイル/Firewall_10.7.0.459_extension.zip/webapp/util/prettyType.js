/*
 * Copyright (C) 2007-2009, McAfee, Inc.  All Rights Reserved.
 */

var getPrettyString = function(value) {
    var results = [];

    var input = value.split(",");
    for (i = 0; i < input.length; i++) {
        results[i] = doPretty(OrionCore.trim(input[i]));
    }
    return results;

}

var prettyType = function (entry) {

    var mappingString = "";


    if (optMap[entry] != null) {
        mappingString = optMap[entry];
    } else {
        mappingString = entry;
    }

    return mappingString;
}

var getGroup = function(value) {
    return /\d+(\s*-\s*\d+)$/.exec(value);
}
var doPretty = function(value) {
    var prettyString = "";

    var groups = getGroup(value);
    if (groups != null) {
        var values = value.split(/\s*(?:-|,)\s*/);

        if (groups[1]) {

            prettyString = prettyType(values[0]) + " - " + prettyType(values[1]);
        }
    } else {
        prettyString = prettyType(value);
    }

    return prettyString;

}