/**
 to use this code - the refering page must have a variable set for the ResponseBean atop the page
 Example = var infoObject = null;

 the parent page must also have the logic for the execute() function, which loads a prticular function based on the
 infoObject.okHandler string
 */

function fnLoadPopup(infoVO)
{
    OrionCore.showPleaseWait(false);
    var info = eval('(' + infoVO + ')');

    if ( info.error )
    {
        fnLoadFailPopup(info);
    }
    else
    {
        fnLoadModalPopup(info);
    }
}


function fnLoadFailPopup(info)
{
    infoObject = info;

    OrionCore.setDialogBoxTitle(info.title);
    OrionCore.dialogBoxOkHandler = execute;
    OrionCore.showDialogBox(true, info.prompt, OrionCore.DIALOG_OK);

}

function fnLoadModalPopup(info)
{
    infoObject = info;

    OrionCore.setDialogBoxTitle(info.title);
    OrionCore.dialogBoxOkHandler = execute;
    OrionCore.dialogBoxCancelHandler = fnOnCancel;
    OrionCore.showDialogBox(true, info.prompt);
}

