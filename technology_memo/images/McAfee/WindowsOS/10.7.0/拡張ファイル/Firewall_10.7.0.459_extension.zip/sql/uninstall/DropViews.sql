-- This file contains all views:

PRINT '-- Executing DropViews.sql --'
SET NOCOUNT ON

-- Create a generic procedure for dropping any procedure only if it exists:

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FWSP_DROP_VIEW]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FWSP_DROP_VIEW]
GO

CREATE PROCEDURE dbo.FWSP_DROP_VIEW
	@ViewName nvarchar(64)
AS
BEGIN
	DECLARE @Stmt nvarchar (2048)

	SET @Stmt = 'if exists (select * from dbo.sysobjects where id = object_id(N''dbo.'
		+@ViewName + ''') and OBJECTPROPERTY(id, N''IsView'') = 1)
			drop view dbo.'+ @ViewName;

	EXEC (@Stmt)
END
GO



-- Drop views

FWSP_DROP_VIEW FW_CustomProps
GO
FWSP_DROP_VIEW FW_Application
GO
FWSP_DROP_VIEW FW_ApplicationExecutable
GO
FWSP_DROP_VIEW FW_Executable
GO
FWSP_DROP_VIEW FW_Group_Rule
GO
FWSP_DROP_VIEW FW_Location
GO
FWSP_DROP_VIEW FW_NamedNetwork
GO
FWSP_DROP_VIEW FW_Rule
GO
FWSP_DROP_VIEW FW_Rule_Application
GO
FWSP_DROP_VIEW FW_Rule_LocalNetwork
GO
FWSP_DROP_VIEW FW_Rule_Location
GO
FWSP_DROP_VIEW FW_ServiceName
GO
FWSP_DROP_VIEW FW_Location_DefaultGateway
GO
FWSP_DROP_VIEW FW_Location_DhcpServer
GO
FWSP_DROP_VIEW FW_Location_DnsServer
GO
FWSP_DROP_VIEW FW_Location_DnsSuffix
GO
FWSP_DROP_VIEW FW_Location_DomainReachable
GO
FWSP_DROP_VIEW FW_Location_PrimaryWins
GO
FWSP_DROP_VIEW FW_Location_RegKey
GO
FWSP_DROP_VIEW FW_Location_SecondaryWins
GO
FWSP_DROP_VIEW FW_NamedNetwork_Hosts
GO
FWSP_DROP_VIEW FW_Rule_NetworkProtocol
GO
FWSP_DROP_VIEW FW_Rule_RemoteNetwork
GO

FWSP_DROP_VIEW FW_ClientRuleExecutableView
GO
FWSP_DROP_VIEW FW_EndpointTechnologyStatus_View
GO
FWSP_DROP_VIEW FW_ClientRuleExecutableView
GO

FWSP_DROP_VIEW FWBladeTechView
GO