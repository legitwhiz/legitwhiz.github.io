-- Make sure there is only one installed blade record
DELETE FROM [dbo].[EAMP.GSE.Blades]
WHERE
	[ProductCode] in (N'ENDP_FW_1000', N'ENDP_FW_1010', N'ENDP_FW_1020', N'ENDP_FW_1050', N'ENDP_FW_1060', N'ENDP_FW_1070', N'ENDP_FW_1000MACX')
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
(
	[ProductCode]
,	[DispName]
,	[TechnologyCount]
)
VALUES
(
	'ENDP_FW_1050'
,	'Endpoint Security Firewall'
,	1
)
GO
