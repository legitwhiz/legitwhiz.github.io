
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FWSP_CONVERT_TABLE_TO_VIEW]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
  BEGIN
    DROP PROCEDURE FWSP_CONVERT_TABLE_TO_VIEW
  END
GO

CREATE PROCEDURE [dbo].[FWSP_CONVERT_TABLE_TO_VIEW]
	@ViewName nvarchar(256),
	@Install   char(1)
AS
BEGIN
/******************************************************************************************
 * FWSP_CONVERT_TABLE_TO_FILTERED_VIEW
 *
 *   Converts the specified table to tenant-filtered view
 *
 *   It renames the table to tableMT, crates a view with the original table name,
 *   and adds triggers to the renamed table for tennant filtering.
 *
 *   Parameters:
 *     @TableName             The table name to be converted to view
 ******************************************************************************************/
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @NewTableName nvarchar(256);

	SET @NewTableName = @ViewName + 'MT';

    -- Add view for a table with tenant id column
	EXEC ('
    IF object_id (''dbo.' + @ViewName + ''', ''V'') IS NOT NULL
      DROP VIEW ' + @ViewName + '
    ');

	EXEC ('
    CREATE VIEW ' + @ViewName + ' AS
      SELECT * FROM ' + @NewTableName);
END
GO

