-- upgrade-to-10.5.2.sql --

-- update [FW_CustomProps] view:  performance --
alter view [dbo].[FW_CustomProps] as
    select fw.*, pp.[ParentID] [LeafNodeID], pp.[ProductCode], pp.[TheHiddenTimestamp] [timestamp]
    from [FW_CustomPropsMT] fw
        inner join [EPOProductProperties] pp on fw.[ParentID] = pp.[AutoID]
go

-- update tech status: use new FW_CustomProps def, and make it read only
alter view [dbo].[FW_EndpointTechnologyStatus_View] as
    select pp.[AutoIDSP] [AutoID], pp.[LeafNodeID], 6 [TechnologyType], pp.[FWStatus] [Enabled], pp.[ProductCode]
    from [FW_CustomProps] pp with(nolock)
go

-- update tech status: use new FW_CustomProps def, and make it read only
alter view [dbo].[FWBladeTechView] as
    select pp.[AutoIDSP] [AutoID], pp.[LeafNodeID], 6 [TechnologyType], pp.[FWStatus] [Enabled], pp.[ProductCode]
    from [FW_CustomProps] pp with(nolock)
go

-- rebuild the Tech Status view
exec [dbo].[GSRebuildTechnologyStatus_View]
go

-- remove unwanted indexes
IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_FW_RuleMT_name' -- Index Name
		AND so.[Name] = N'FW_RuleMT')
	DROP INDEX IX_FW_RuleMT_name ON FW_RuleMT;
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_FW_Rule_NetworkProtocol_RuleID' -- Index Name
		AND so.[Name] = N'FW_Rule_NetworkProtocolMT')
		DROP INDEX [IX_FW_Rule_NetworkProtocol_RuleID] ON dbo.[FW_Rule_NetworkProtocolMT];
GO

--------- ePO Rollup Reporting ---------
-- FW_CustomProps rollup target --
if not exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ENSRollup_FW_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
	create table [dbo].[ENSRollup_FW_CustomProps]
	(
		[RegSvrId]						[int] not null,
		[AutoID]						[int] not null,
		[ParentID]						[int] not null,
		[ComplianceStatus]				[bit] null,
		[ComplianceReason]				[int] null,
		[AdditionalComplianceReason]	[nvarchar](256) null,
		[FWStatus]						[bit] null,
		[FWAdaptiveModeStatus]			[bit] null,
		[FWFault]						[bit] null,
		[FWMode]						[int] null,
		[Hotfix]						[nvarchar](128) null,
		[Language]						[nvarchar](128) null,
		[LastPolicyEnforcement]			[nvarchar](128) null,
		[LicenseStatus]					[bit] null,
		[Patch]							[nvarchar](128) null,
		[PolicyNameClientUI]			[nvarchar](128) null,
		[PolicyNameFwOptions]			[nvarchar](128) null,
		[PolicyNameFwRules]				[nvarchar](128) null,
		[PolicyNameTrustedAppList]		[nvarchar](128) null,
		[PolicyNameTrustedNetworks]		[nvarchar](128) null,
		[ProductVersion]				[nvarchar](128) null,
		[RebootRequired]				[bit] null,
		[ServiceRunning]				[bit] null,
		[InstallDir32]					[nvarchar](128) null,
		[InstallDir64]					[nvarchar](128) null,
		[ProductVer]					[nvarchar](128) null,
		constraint [PK_ENSRollup_FW_CustomProps] primary key clustered
		([RegSvrId] asc, [AutoID] asc)
	)
end
go

if not exists (select 1 from [sys].[foreign_keys] where [object_id] = OBJECT_ID(N'[FK_ENSRollup_FW_CustomProps_EPORollup_ProductProperties]') and [parent_object_id] = OBJECT_ID(N'[dbo].[ENSRollup_FW_CustomProps]'))
begin
	alter table [dbo].[ENSRollup_FW_CustomProps] add
	constraint [FK_ENSRollup_FW_CustomProps_EPORollup_ProductProperties] foreign key
		([RegSvrId], [ParentID])
		references [dbo].[EPORollup_ProductProperties]
		([ServerId], [ExternalId])
		on delete cascade on update no action
end
go

--create unique index on the foreign key
if exists(select 1 from [dbo].[sysobjects] where [id] = OBJECT_ID(N'[dbo].[ENSRollup_FW_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
	and not exists(select 1 from [dbo].[sysindexes] where [id] = OBJECT_ID(N'[dbo].[ENSRollup_FW_CustomProps]') and [name] = N'IX_ENSRollup_FW_CustomProps_ParentID')
begin
	create unique nonclustered index [IX_ENSRollup_FW_CustomProps_ParentID] on [dbo].[ENSRollup_FW_CustomProps]
		([RegSvrId] asc, [ParentID] asc)
end
go
