/**
 *	Remove all Firewall stored procedures.
 */

PRINT '-- Executing DropStoredProcs.sql --'

SET NOCOUNT ON

-- FW_GetPolicySettingValus --
if exists(select 1 from sys.objects where [object_id] = OBJECT_ID(N'[dbo].[FW_GetPolicySettingValues]') and [type] = N'P')
    drop procedure [dbo].[FW_GetPolicySettingValues]
go

-- FW_FindPoliciesLike --
if exists(select 1 from sys.objects where [object_id] = OBJECT_ID(N'[dbo].[FW_FindPoliciesLike]') and [type] = N'P')
    drop procedure [dbo].[FW_FindPoliciesLike]
go

/**
 *	Create Helper Stored Procedures
 */
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FWSP_DROP_PROCEDURE]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROC	[dbo].[FWSP_DROP_PROCEDURE]
END
GO

CREATE PROCEDURE dbo.FWSP_DROP_PROCEDURE
	@ProcName nvarchar(64)
AS 
BEGIN
	DECLARE @Stmt nvarchar (2048)

	SET @Stmt = '
	IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N''dbo.' +@ProcName + ''') AND OBJECTPROPERTY(id, N''IsProcedure'') = 1)
		DROP PROC	dbo.'+ @ProcName;
	
	EXEC (@Stmt)
END
GO

FWSP_DROP_PROCEDURE FWSP_DROP_FUNCTION;
GO

CREATE PROCEDURE dbo.FWSP_DROP_FUNCTION
	@FuncName nvarchar(64)
AS
BEGIN
	DECLARE @Stmt nvarchar (2048)

	SET @Stmt = '
	IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N''dbo.' +@FuncName + ''') AND xtype in (N''FN'', N''IF'', N''TF''))
		DROP FUNCTION dbo.'+ @FuncName;

	EXEC (@Stmt)
END
GO


/**
 *	Drop All Product Stored Procedures
 */
FWSP_DROP_PROCEDURE FWSP_DeprovisionTenant;
GO

/**
 *	Drop All Helper Stored Procedures
 */
FWSP_DROP_PROCEDURE FWSP_DROP_TRIGGER
GO
FWSP_DROP_PROCEDURE FWSP_DROP_FUNCTION;
GO
FWSP_DROP_PROCEDURE FWSP_DROP_VIEW;
GO
FWSP_DROP_PROCEDURE FWSP_ADD_TENANT_ID;
GO
FWSP_DROP_PROCEDURE FWSP_DROP_TENANT_ID;
GO
FWSP_DROP_PROCEDURE FWSP_CONVERT_TABLE_TO_FILTERED_VIEW;
GO
FWSP_DROP_PROCEDURE FWSP_DROP_FILTERED_VIEW;
GO

FWSP_DROP_PROCEDURE FWSP_CONVERT_TABLE_TO_VIEW;
GO

DROP PROC	[dbo].[FWSP_DROP_PROCEDURE]
GO


IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FWFN_GetTenancyInfoTable]') AND OBJECTPROPERTY(id, N'IsFunction') = 1)
BEGIN
	DROP Function	[dbo].[FWFN_GetTenancyInfoTable]
END
GO

PRINT '-- Done DropStoredProcs.sql --'
