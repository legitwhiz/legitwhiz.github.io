

IF EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[FW_RuleMT]') AND name = N'IX_FW_RuleMT_DTYPE')
  BEGIN
    DROP INDEX [dbo].[FW_RuleMT].[IX_FW_RuleMT_DTYPE]
  END
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_FW_RuleMT_bscheduleEnabled]') and OBJECTPROPERTY(id, N'IsConstraint') = 1)
ALTER TABLE [dbo].[FW_RuleMT] DROP [DF_FW_RuleMT_bscheduleEnabled]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_FW_RuleMT_bscheduleDisableDuringTime]') and OBJECTPROPERTY(id, N'IsConstraint') = 1)
ALTER TABLE [dbo].[FW_RuleMT] DROP [DF_FW_RuleMT_bscheduleDisableDuringTime]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_FW_RuleMT_schedule_startHours]') and OBJECTPROPERTY(id, N'IsConstraint') = 1)
ALTER TABLE [dbo].[FW_RuleMT] DROP [DF_FW_RuleMT_schedule_startHours]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_FW_RuleMT_schedule_startMinutes]') and OBJECTPROPERTY(id, N'IsConstraint') = 1)
ALTER TABLE [dbo].[FW_RuleMT] DROP [DF_FW_RuleMT_schedule_startMinutes]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_FW_RuleMT_schedule_endHours]') and OBJECTPROPERTY(id, N'IsConstraint') = 1)
ALTER TABLE [dbo].[FW_RuleMT] DROP [DF_FW_RuleMT_schedule_endHours]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_FW_RuleMT_schedule_endMinutes]') and OBJECTPROPERTY(id, N'IsConstraint') = 1)
ALTER TABLE [dbo].[FW_RuleMT] DROP [DF_FW_RuleMT_schedule_endMinutes]
GO

IF EXISTS(select * from dbo.syscolumns where id = OBJECT_ID('FW_RuleMT') AND (name='scheduleEnabled'))
ALTER TABLE [dbo].[FW_RuleMT]
DROP COLUMN
  [scheduleEnabled]
, [scheduleDisableDuringTime]
, [schedule_startHours]
, [schedule_startMinutes]
, [schedule_endHours]
, [schedule_endMinutes]
GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[FW_RuleMT]') AND name = N'IX_FW_RuleMT_DTYPE')
  BEGIN
    CREATE INDEX [IX_FW_RuleMT_DTYPE] ON [dbo].[FW_RuleMT]
    ([DTYPE])
    INCLUDE ([id], [version], [lastModifyingUsername], [lastModified], [name], [note], [enabled], [action], [direction], [mediaFlags], [tcpFlagsFlags], [transportProtocol], [localServiceList], [remoteServiceList], [intrusion], [trafficLogged], [schedule_start], [schedule_end], [schedule_offHours], [schedule_weekMask], [schedule_clickTimeout])
  END
GO


-- Drop Views

--FW_Application

IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Application]'))
BEGIN
	DROP VIEW	[dbo].[FW_Application]
END
GO

EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Application', 'Y'
GO

--FW_Executable

IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Executable]'))
BEGIN
	DROP VIEW	[dbo].[FW_Executable]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Executable', 'Y'
GO

--FW_ApplicationExecutable

IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_ApplicationExecutable]'))
BEGIN
	DROP VIEW	[dbo].[FW_ApplicationExecutable]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_ApplicationExecutable', 'Y'
GO

--FW_Rule
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule]'))
BEGIN
	DROP VIEW	[dbo].[FW_Rule]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Rule' , 'Y'
GO

--FW_Group_Rule
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Group_Rule]'))
BEGIN
	DROP VIEW	[dbo].[FW_Group_Rule]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Group_Rule' , 'Y'
GO

--FW_Location
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location' , 'Y'
GO

--FW_NamedNetwork
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_NamedNetwork]'))
BEGIN
	DROP VIEW	[dbo].[FW_NamedNetwork]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_NamedNetwork' , 'Y'
GO

--FW_Rule_Application
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_Application]'))
BEGIN
	DROP VIEW	[dbo].[FW_Rule_Application]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Rule_Application' , 'Y'
GO

--FW_Rule_LocalNetwork
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_LocalNetwork]'))
BEGIN
	DROP VIEW	[dbo].[FW_Rule_LocalNetwork]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Rule_LocalNetwork', 'Y'
GO

--FW_Rule_Location
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_Location]'))
BEGIN
	DROP VIEW	[dbo].[FW_Rule_Location]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Rule_Location', 'Y'
GO

--FW_ServiceName
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_ServiceName]'))
BEGIN
	DROP VIEW	[dbo].[FW_ServiceName]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_ServiceName', 'Y'
GO

--FW_Location_DefaultGateway
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DefaultGateway]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_DefaultGateway]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_DefaultGateway' , 'Y'
GO

--FW_Location_DhcpServer
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DhcpServer]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_DhcpServer]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_DhcpServer' , 'Y'
GO

--FW_Location_DnsServer
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DnsServer]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_DnsServer]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_DnsServer' , 'Y'
GO

--FW_Location_DnsSuffix
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DnsSuffix]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_DnsSuffix]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_DnsSuffix' , 'Y'
GO

--FW_Location_DomainReachable
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DomainReachable]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_DomainReachable]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_DomainReachable' , 'Y'
GO

--FW_Location_PrimaryWins
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_PrimaryWins]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_PrimaryWins]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_PrimaryWins' , 'Y'
GO

--FW_Location_RegKey
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_RegKey]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_RegKey]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_RegKey' , 'Y'
GO

--FW_Location_SecondaryWins
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_SecondaryWins]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_SecondaryWins]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_SecondaryWins' , 'Y'
GO

--FW_NamedNetwork_Hosts
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_NamedNetwork_Hosts]'))
BEGIN
	DROP VIEW	[dbo].[FW_NamedNetwork_Hosts]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_NamedNetwork_Hosts' , 'Y'
GO

--FW_Rule_NetworkProtocol
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_NetworkProtocol]'))
BEGIN
	DROP VIEW	[dbo].[FW_Rule_NetworkProtocol]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Rule_NetworkProtocol' , 'Y'
GO

--FW_Rule_RemoteNetwork
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_RemoteNetwork]'))
BEGIN
	DROP VIEW	[dbo].[FW_Rule_RemoteNetwork]
END
GO
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Rule_RemoteNetwork' , 'Y'
GO