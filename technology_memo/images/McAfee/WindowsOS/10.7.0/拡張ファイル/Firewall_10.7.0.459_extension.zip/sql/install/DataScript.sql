-- Make sure there is only one installed blade record
DELETE FROM [dbo].[EAMP.GSE.Blades]
WHERE
	ProductCode	= 'ENDP_FW_1070'
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
(
	[ProductCode]
,	[DispName]
,	[TechnologyCount]
)
VALUES
(
	'ENDP_FW_1070'
,	'Endpoint Security Firewall'
,	1
)
GO
