PRINT '-- Executing DropTables.sql --'
SET NOCOUNT ON

-- Drop Constraints
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Application_OrionTenant]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_ApplicationMT] DROP CONSTRAINT [FK_FW_Application_OrionTenant]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Executable_OrionTenant]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_ExecutableMT] DROP CONSTRAINT [FK_FW_Executable_OrionTenant]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_ApplicationExecutable_FW_Application]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_ApplicationExecutableMT] DROP CONSTRAINT FK_FW_ApplicationExecutable_FW_Application
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_ApplicationExecutable_FW_Executable]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_ApplicationExecutableMT] DROP CONSTRAINT FK_FW_ApplicationExecutable_FW_Executable
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_ApplicationExecutable_OrionTenant]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_ApplicationExecutableMT] DROP CONSTRAINT [FK_FW_ApplicationExecutable_OrionTenant]
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_NamedNetwork_Hosts_FW_NamedNetwork]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_NamedNetwork_HostsMT] DROP CONSTRAINT FK_FW_NamedNetwork_Hosts_FW_NamedNetwork
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Location_DnsSuffix_FW_Location]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Location_DnsSuffixMT] DROP CONSTRAINT FK_FW_Location_DnsSuffix_FW_Location
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Location_DomainReachable_FW_Location]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Location_DomainReachableMT] DROP CONSTRAINT FK_FW_Location_DomainReachable_FW_Location
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Location_DhcpServer_FW_Location]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Location_DhcpServerMT] DROP CONSTRAINT FK_FW_Location_DhcpServer_FW_Location
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Location_DnsServer_FW_Location]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Location_DnsServerMT] DROP CONSTRAINT FK_FW_Location_DnsServer_FW_Location
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Location_DefaultGateway_FW_Location]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Location_DefaultGatewayMT] DROP CONSTRAINT FK_FW_Location_DefaultGateway_FW_Location
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Location_PrimaryWins_FW_Location]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Location_PrimaryWinsMT] DROP CONSTRAINT FK_FW_Location_PrimaryWins_FW_Location
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Location_SecondaryWins_FW_Location]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Location_SecondaryWinsMT] DROP CONSTRAINT FK_FW_Location_SecondaryWins_FW_Location
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Location_RegKey_FW_Location]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Location_RegKeyMT] DROP CONSTRAINT FK_FW_Location_RegKey_FW_Location
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_LocalNetwork_FW_Rule]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Rule_LocalNetworkMT] DROP CONSTRAINT FK_FW_Rule_LocalNetwork_FW_Rule
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_LocalNetwork_FW_NamedNetwork]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Rule_LocalNetworkMT] DROP CONSTRAINT FK_FW_Rule_LocalNetwork_FW_NamedNetwork
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_LocalNetwork_OrionTenant]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Rule_LocalNetworkMT] DROP CONSTRAINT [FK_FW_Rule_LocalNetwork_OrionTenant]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_RemoteNetwork_FW_Rule]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Rule_RemoteNetworkMT] DROP CONSTRAINT FK_FW_Rule_RemoteNetwork_FW_Rule
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_RemoteNetwork_FW_NamedNetwork]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Rule_RemoteNetworkMT] DROP CONSTRAINT FK_FW_Rule_RemoteNetwork_FW_NamedNetwork
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_Location_FW_Rule]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Rule_LocationMT] DROP CONSTRAINT FK_FW_Rule_Location_FW_Rule
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_Location_FW_Location]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Rule_LocationMT] DROP CONSTRAINT FK_FW_Rule_Location_FW_Location
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_Location_OrionTenant]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Rule_LocationMT] DROP CONSTRAINT FK_FW_Rule_Location_OrionTenant
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_NetworkProtocol_FW_Rule]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Rule_NetworkProtocolMT] DROP CONSTRAINT FK_FW_Rule_NetworkProtocol_FW_Rule
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_Application_FW_Rule]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Rule_ApplicationMT] DROP CONSTRAINT FK_FW_Rule_Application_FW_Rule
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_Application_FW_Application]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Rule_ApplicationMT] DROP CONSTRAINT FK_FW_Rule_Application_FW_Application
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Group_FW_Rule]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Group_RuleMT] DROP CONSTRAINT FK_FW_Group_FW_Rule
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Group_FW_Rule2]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Group_RuleMT] DROP CONSTRAINT FK_FW_Group_FW_Rule2
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Group_Rule_OrionTenant]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_Group_RuleMT] DROP CONSTRAINT [FK_FW_Group_Rule_OrionTenant]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_LeafNode]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_RuleMT] DROP CONSTRAINT FK_FW_Rule_LeafNode
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_Rule_OrionTenant]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_RuleMT] DROP CONSTRAINT [FK_FW_Rule_OrionTenant]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_NamedNetwork_OrionTenant]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_NamedNetworkMT] DROP CONSTRAINT [FK_FW_NamedNetwork_OrionTenant]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FW_ServiceName_OrionTenant]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FW_ServiceNameMT] DROP CONSTRAINT [FK_FW_ServiceName_OrionTenant]
GO

if exists (select name from dbo.sysobjects where name like 'FW_ExecutableMT' AND type = 'U')
DROP TABLE [dbo].[FW_ExecutableMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_ApplicationMT' AND type = 'U')
DROP TABLE [dbo].[FW_ApplicationMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_ApplicationExecutableMT' AND type = 'U')
DROP TABLE [dbo].[FW_ApplicationExecutableMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_NamedNetwork_HostsMT' AND type = 'U')
DROP TABLE [dbo].[FW_NamedNetwork_HostsMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_NamedNetworkMT' AND type = 'U')
DROP TABLE [dbo].[FW_NamedNetworkMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_ServiceNameMT' AND type = 'U')
DROP TABLE [dbo].[FW_ServiceNameMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_LocationMT' AND type = 'U')
DROP TABLE [dbo].[FW_LocationMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Rule_NetworkProtocolMT' AND type = 'U')
DROP TABLE [dbo].[FW_Rule_NetworkProtocolMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Location_DnsSuffixMT' AND type = 'U')
DROP TABLE [dbo].[FW_Location_DnsSuffixMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Location_DomainReachableMT' AND type = 'U')
DROP TABLE [dbo].[FW_Location_DomainReachableMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Location_DhcpServerMT' AND type = 'U')
DROP TABLE [dbo].[FW_Location_DhcpServerMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Location_DnsServerMT' AND type = 'U')
DROP TABLE [dbo].[FW_Location_DnsServerMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Location_DefaultGatewayMT' AND type = 'U')
DROP TABLE [dbo].[FW_Location_DefaultGatewayMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Location_PrimaryWinsMT' AND type = 'U')
DROP TABLE [dbo].[FW_Location_PrimaryWinsMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Location_SecondaryWinsMT' AND type = 'U')
DROP TABLE [dbo].[FW_Location_SecondaryWinsMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Location_RegKeyMT' AND type = 'U')
DROP TABLE [dbo].[FW_Location_RegKeyMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_RuleMT' AND type = 'U')
DROP TABLE [dbo].[FW_RuleMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Rule_LocalNetworkMT' AND type = 'U')
DROP TABLE [dbo].[FW_Rule_LocalNetworkMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Rule_RemoteNetworkMT' AND type = 'U')
DROP TABLE [dbo].[FW_Rule_RemoteNetworkMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Rule_LocationMT' AND type = 'U')
DROP TABLE [dbo].[FW_Rule_LocationMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Rule_ApplicationMT' AND type = 'U')
DROP TABLE [dbo].[FW_Rule_ApplicationMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_Group_RuleMT' AND type = 'U')
DROP TABLE [dbo].[FW_Group_RuleMT]
GO

if exists (select name from dbo.sysobjects where name like 'FW_CustomPropsMT' AND type = 'U')
DROP TABLE [dbo].[FW_CustomPropsMT]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FW_CustomProps]') AND type in (N'U'))
	DROP TABLE [dbo].[FW_CustomProps]
GO

--------- ePO Rollup Reporting ---------
if exists (select 1 from [sys].[foreign_keys] where [object_id] = OBJECT_ID(N'[FK_ENSRollup_FW_CustomProps_EPORollup_ProductProperties]') and [parent_object_id] = OBJECT_ID(N'[dbo].[ENSRollup_FW_CustomProps]'))
begin
	alter table [dbo].[ENSRollup_FW_CustomProps] drop constraint [FK_ENSRollup_FW_CustomProps_EPORollup_ProductProperties]
end
go

if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ENSRollup_FW_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
	drop table [dbo].[ENSRollup_FW_CustomProps]
end
go

PRINT '-- Finished DropTables.sql --'
