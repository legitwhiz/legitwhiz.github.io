-- This file contains all stored procedures except those meant for reports:

SET NOCOUNT ON

IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FWFN_GetTenancyInfoTable]') AND OBJECTPROPERTY(id, N'IsTableFunction') = 1)
BEGIN
	DROP Function	[dbo].[FWFN_GetTenancyInfoTable]
END
GO

CREATE FUNCTION [dbo].[FWFN_GetTenancyInfoTable] ()
RETURNS @tid TABLE (tid int, ops bit)
AS
BEGIN
    INSERT INTO @tid SELECT [dbo].[FN_Core_GetContextTenantId](), [dbo].[FN_Core_IsSystemUserInContext]()
    RETURN ;
END
GO

-- Create a generic procedure for dropping any procedure only if it exists:

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FWSP_DROP_PROCEDURE]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[FWSP_DROP_PROCEDURE]
GO

CREATE PROCEDURE dbo.FWSP_DROP_PROCEDURE
		@ProcName nvarchar(64)
AS
	BEGIN
		DECLARE @Stmt nvarchar (2048)

		SET @Stmt = 'if exists (select * from dbo.sysobjects where id = object_id(N''dbo.'
					+@ProcName + ''') and OBJECTPROPERTY(id, N''IsProcedure'') = 1)
			drop procedure dbo.'+ @ProcName;

		EXEC (@Stmt)
	END
GO

-- Create a generic procedure for dropping any trigger only if it exists:

FWSP_DROP_PROCEDURE 'FWSP_DROP_TRIGGER';
GO

CREATE PROCEDURE dbo.FWSP_DROP_TRIGGER
		@TriggerName nvarchar(64)
AS
	BEGIN
		DECLARE @Stmt nvarchar (2048)

		SET @Stmt = 'if exists (select * from dbo.sysobjects where id = object_id(N''dbo.'
					+@TriggerName + ''') and OBJECTPROPERTY(id, N''IsTrigger'') = 1)
			drop trigger dbo.'+ @TriggerName;

		EXEC (@Stmt)
	END
GO


FWSP_DROP_PROCEDURE FWSP_DROP_FUNCTION;
GO

CREATE PROCEDURE dbo.FWSP_DROP_FUNCTION
		@FuncName nvarchar(64)
AS
	BEGIN
		DECLARE @Stmt nvarchar (2048)

		SET @Stmt = 'if exists (select * from dbo.sysobjects where id = object_id(N''dbo.'
					+@FuncName + ''') and  xtype in (N''FN'', N''IF'', N''TF''))
			drop function dbo.'+ @FuncName;

		EXEC (@Stmt)
	END
GO


/***  Create Conversion Procedure   ***/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FWSP_CONVERT_TABLE_TO_FILTERED_VIEW]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
  BEGIN
    DROP PROCEDURE FWSP_CONVERT_TABLE_TO_FILTERED_VIEW
  END
GO

CREATE PROCEDURE [dbo].[FWSP_CONVERT_TABLE_TO_FILTERED_VIEW]
	@TableName nvarchar(256),
	@Install   char(1)
AS
BEGIN
/******************************************************************************************
 * FWSP_CONVERT_TABLE_TO_FILTERED_VIEW
 *
 *   Converts the specified table to tenant-filtered view
 *
 *   It renames the table to tableMT, crates a view with the original table name,
 *   and adds triggers to the renamed table for tennant filtering.
 *
 *   Parameters:
 *     @TableName             The table name to be converted to view
 ******************************************************************************************/
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @NewTableName nvarchar(256);
	DECLARE @ViewName nvarchar(255);
	DECLARE @InsertTriggerName nvarchar(255);
	DECLARE @UpdateTriggerName nvarchar(255);
	DECLARE @DeleteTriggerName nvarchar(255);

	SET @NewTableName = @TableName + 'MT';
	SET @ViewName = @TableName;
	SET @InsertTriggerName = 'TR_' + @TableName + '_INSERT';
	SET @UpdateTriggerName = 'TR_' + @TableName + '_UPDATE';
	SET @DeleteTriggerName = 'TR_' + @TableName + '_DELETE';

	-- Only rename tables on upgrade
	If @Install = 'N'
	  BEGIN
		-- Rename the table
		EXEC ('
		IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N''[' + @TableName + ']'') AND objectproperty(id, N''IsUserTable'') = 1)
		  EXEC sp_rename ''' + @TableName + ''', ''' + @NewTableName + '''
		');
	  END

    -- Add the tenant filtered view for a table with tenant id column
	EXEC ('
    IF object_id (''dbo.' + @ViewName + ''', ''V'') IS NOT NULL
      DROP VIEW ' + @ViewName + '
    ');

	EXEC ('
    CREATE VIEW ' + @ViewName + ' AS
      SELECT * FROM ' + @NewTableName + '
        WHERE TenantId = 0
        OR TenantId = (select tid from FWFN_GetTenancyInfoTable())
     ');

    -- Insert Trigger

	EXEC ('
    IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N''[' + @InsertTriggerName + ']'') AND objectproperty(id, N''IsTrigger'') = 1)
      DROP TRIGGER ' + @InsertTriggerName + '
    ');

	EXEC ('
      CREATE TRIGGER ' + @InsertTriggerName + ' ON ' + @NewTableName + ' FOR INSERT AS
        DECLARE @TenantIds tenant_ids
        INSERT @TenantIds SELECT TenantId FROM inserted
        EXEC SP_Core_ValidateTenancy @@PROCID, @TenantIds
    ');

    -- Update Trigger

	EXEC ('
    IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N''[' + @UpdateTriggerName + ']'') AND objectproperty(id, N''IsTrigger'') = 1)
      DROP TRIGGER ' + @UpdateTriggerName + '
    ');

	EXEC ('
      CREATE TRIGGER ' + @UpdateTriggerName + ' ON ' + @NewTableName + ' FOR UPDATE AS
        DECLARE @TenantIds tenant_ids
        INSERT @TenantIds SELECT TenantId FROM inserted
        EXEC SP_Core_ValidateTenancy @@PROCID, @TenantIds
    ');

    -- Delete Trigger

	EXEC ('
    IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N''[' + @DeleteTriggerName + ']'') AND objectproperty(id, N''IsTrigger'') = 1)
      DROP TRIGGER ' + @DeleteTriggerName + '
    ');

	EXEC ('
      CREATE TRIGGER ' + @DeleteTriggerName + ' ON ' + @NewTableName + ' FOR DELETE AS
        DECLARE @TenantIds tenant_ids
        INSERT @TenantIds SELECT TenantId FROM deleted
        EXEC SP_Core_ValidateTenancy @@PROCID, @TenantIds
    ');

END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FWSP_ADD_TENANT_ID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[FWSP_ADD_TENANT_ID]
GO

CREATE PROCEDURE [dbo].[FWSP_ADD_TENANT_ID]
(
	@table   nvarchar(128),
	@column  nvarchar(128),	-- when building FK index additional column to TenantId
	@huge    int,				-- 0 for normal & 1 for huge tables
	@skipFk  int        -- 0 add FK -- 1 skip
)
AS
BEGIN
	-- variables
	DECLARE	@sql nvarchar(1024);
	DECLARE	@count int;

	DECLARE	@paramDefCount nvarchar(256);
	SET		@paramDefCount = N'@p1 int OUTPUT';

	DECLARE	@fkConst nvarchar(255);
	SET		@fkConst = N'FK_' + @table + N'_OrionTenant';

	DECLARE	@nnConst nvarchar(255);
	SET		@nnConst = N'DF_' + @table + N'_TenantId_NOTNULL';

	DECLARE	@idxName nvarchar(255)
	SET		@idxName = N'IX_'+ @table + N'_TenantId_'+ @column

	DECLARE	@dfConst nvarchar(255);
	SET		@dfConst = N'DF_' + @table + N'_TenantId_Default';

	DECLARE	@multiTenant int;
	SELECT	@multiTenant = ##MultiTenantMode##;

	-- check for index and drop it, if it exists
	SET @sql = N'SELECT @p1 = COUNT(*) FROM [dbo].[sysindexes] '
			 + N'WHERE id = OBJECT_ID(N''[dbo].' + QUOTENAME(@table) + N''') '
			 + N'AND [name] = '''+  @idxName + N'''';
	EXEC sp_executesql @sql, @paramDefCount, @p1 = @count OUTPUT;

	IF @count > 0
	BEGIN
		SET @sql = N'DROP INDEX ' + QUOTENAME(@idxName)
				 + N' ON [dbo].' + QUOTENAME(@table);
		EXEC sp_executesql @sql;
	END

	-- check for foreign key constraint and drop it, if it exists
	SET @sql = N'SELECT @p1 = COUNT(*) FROM [dbo].[sysobjects] '
			 + N'WHERE id = OBJECT_ID(N''[dbo].' + QUOTENAME(@fkConst) + N''') '
			 + N'AND OBJECTPROPERTY(id, N''IsForeignKey'') = 1';
	EXEC sp_executesql @sql, @paramDefCount, @p1 = @count OUTPUT;

	IF @count > 0
	BEGIN
		SET @sql = N'ALTER TABLE [dbo].' + QUOTENAME(@table)
				 + N' DROP CONSTRAINT '+ QUOTENAME(@fkConst);
		EXEC sp_executesql @sql;
	END

	-- check for not null constraint and drop it, if it exists

	SET @sql = N'SELECT @p1 = COUNT(*)  FROM dbo.sysobjects '
			 + N'WHERE id = OBJECT_ID(N''[dbo].' + QUOTENAME(@nnConst) + N''') '
			 + N' AND type = ''D'' ';
	EXEC sp_executesql @sql, @paramDefCount, @p1 = @count OUTPUT;

	IF @count > 0
	BEGIN

		SET @sql = N'ALTER TABLE ' + QUOTENAME(@table)
				 + N' DROP CONSTRAINT '+ QUOTENAME(@nnConst);
		EXEC sp_executesql @sql;
	END

	-- check for tenant ID column and drop it, if it exists
	SET @sql = N'SELECT @p1 = COUNT(*) FROM [dbo].[syscolumns] '
			 + N'WHERE id = OBJECT_ID(N''[dbo].' + QUOTENAME(@table) + N''') '
			 + N'AND name = N''TenantId''';
	EXEC sp_executesql @sql, @paramDefCount, @p1 = @count OUTPUT;

	IF @count > 0
	BEGIN
		SET @sql = N'ALTER TABLE [dbo].' + QUOTENAME(@table)
				 + N' DROP COLUMN TenantId';
		EXEC sp_executesql @sql;
	END

	-- add tenant ID column
	IF ((@multiTenant = 1) OR ((@multiTenant = 0) AND (@huge = 0)))
	BEGIN --  do not allow nulls
		SET @sql = N'ALTER TABLE [dbo].' + QUOTENAME(@table)
				 + N' ADD [TenantId] [int] NOT NULL CONSTRAINT ' + QUOTENAME(@nnConst)
				 + N' DEFAULT [dbo].[FN_Core_GetContextTenantId]()';
		EXEC sp_executesql @sql;
	END
	ELSE
	BEGIN
		PRINT 'BOO'
		SET @sql = N'ALTER TABLE [dbo].' + QUOTENAME(@table)
				 + N' ADD [TenantId] [int] NOT NULL CONSTRAINT ' + QUOTENAME(@dfConst)
				 + N' DEFAULT ([dbo].[FN_Core_GetContextTenantId]())';
		EXEC sp_executesql @sql;

		SET @sql = N'ALTER TABLE [dbo].' + QUOTENAME(@table)
				 + N' WITH NOCHECK ADD CONSTRAINT ' + QUOTENAME(@nnConst)
				 + N' CHECK ([TenantId] IS NOT NULL)';
		EXEC sp_executesql @sql;

	END

	-- add foreign key constraint
	IF (@skipFK = 0)
	BEGIN
          SET @sql = N'ALTER TABLE [dbo].' + QUOTENAME(@table)
               + N' ADD CONSTRAINT ' + QUOTENAME(@fkConst)
               + N' FOREIGN KEY (TenantId) REFERENCES dbo.OrionTenant(TenantId) ON DELETE CASCADE';
          EXEC sp_executesql @sql
  END

	-- add index
	IF (@multiTenant = 1)
	BEGIN
		SET @sql = N'CREATE INDEX ' + QUOTENAME(@idxName)
				 + N' ON [dbo].' + QUOTENAME(@table)
				 + N' (TenantId, ' + @column + ')';
		EXEC sp_executesql @sql;
	END
END
GO


