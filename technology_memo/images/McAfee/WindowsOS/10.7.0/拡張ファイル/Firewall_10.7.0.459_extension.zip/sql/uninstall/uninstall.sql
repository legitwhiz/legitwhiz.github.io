DELETE FROM [dbo].[EAMP.GSE.Blades]
WHERE
	[ProductCode] in (N'ENDP_FW_1000', N'ENDP_FW_1010', N'ENDP_FW_1020', N'ENDP_FW_1050', N'ENDP_FW_1060', N'ENDP_FW_1070', N'ENDP_FW_1000MACX', N'ENDP_FW_1055MACX', N'ENDP_FW_1060MACX', N'ENDP_FW_1060LYNX')
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[AM_EndpointTechnologyStatus_View]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FW_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[FW_EndpointTechnologyStatus_View]
GO
