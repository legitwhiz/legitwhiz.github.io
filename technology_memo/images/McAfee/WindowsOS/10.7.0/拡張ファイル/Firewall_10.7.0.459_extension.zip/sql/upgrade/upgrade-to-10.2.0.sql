---Indexing on leafNodeId in FW_RuleMT table during upgrade
if exists (select 1 from [dbo].[sysindexes] where id = object_id(N'[dbo].[FW_RuleMT]') and [name] = N'IX_FWRuleMT_LeafNodeId')
begin
	drop index [IX_FWRuleMT_LeafNodeId] on [dbo].[FW_RuleMT]
end
go

CREATE NONCLUSTERED INDEX [IX_FWRuleMT_LeafNodeId] ON [dbo].[FW_RuleMT]
		([leafNodeId])
		INCLUDE ([id],[TenantId])
Go