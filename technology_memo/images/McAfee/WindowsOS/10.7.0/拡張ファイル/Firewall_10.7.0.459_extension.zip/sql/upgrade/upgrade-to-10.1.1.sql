-- drop \ create trigger for data validation --
if object_id(N'TR_FW_Executable_Validate', N'TR') is not null
	drop trigger [TR_FW_Executable_Validate]
go

create trigger [TR_FW_Executable_Validate]
on [dbo].[FW_ExecutableMT]
instead of insert, update as
begin
	set nocount on;

	-- validate the fingerprint data
	if exists( select 1 from inserted i where (len(i.[fingerprint]) != 32) or (i.[fingerprint] like N'%[^0-9a-fA-F]%') )
	begin
		raiserror(N'FW_ExecutableMT:  Invalid fingerprint', 11, 1);
		return
	end

	-- upsert the data
	merge [dbo].[FW_ExecutableMT] dest
	using
	(
		select	i.[TenantId], i.[id], i.[version], i.[lastModifyingUsername], i.[lastModified],
				i.[name], i.[description], i.[filename], i.[fingerprint], i.[signerName], i.[note]
			from inserted i
	) src
	on
		dest.[TenantId] = src.[TenantId]
		and dest.[id] = src.[id]
	when matched then
		update set
			dest.[version] = src.[version],
			dest.[lastModifyingUsername] = src.[lastModifyingUsername],
			dest.[lastModified] = src.[lastModified],
			dest.[name] = src.[name],
			dest.[description] = src.[description],
			dest.[filename] = src.[filename],
			dest.[fingerprint] = src.[fingerprint],
			dest.[signerName] = src.[signerName],
			dest.[note] = src.[note]
	when not matched by target then
		insert( [TenantId], [id], [version], [lastModifyingUsername], [lastModified],
				[name], [description], [filename], [fingerprint], [signerName], [note])
		values(	src.[TenantId], src.[id], src.[version], src.[lastModifyingUsername], src.[lastModified],
				src.[name], src.[description], src.[filename], src.[fingerprint], src.[signerName], src.[note])
	;
end
go

-------------- Re-index for FW Catalog performance ---------------
/*** Rules ***/
----- drop fk constraints -----
-- group rule --
alter table [dbo].[FW_Group_RuleMT] drop constraint [FK_FW_Group_FW_Rule]
alter table [dbo].[FW_Group_RuleMT] drop constraint [FK_FW_Group_FW_Rule2]

-- rules --
alter table [dbo].[FW_Rule_ApplicationMT] drop constraint [FK_FW_Rule_Application_FW_Rule]
alter table [dbo].[FW_Rule_LocalNetworkMT] drop constraint [FK_FW_Rule_LocalNetwork_FW_Rule]
alter table [dbo].[FW_Rule_LocationMT] drop constraint [FK_FW_Rule_Location_FW_Rule]
alter table [dbo].[FW_Rule_NetworkProtocolMT] drop constraint [FK_FW_Rule_NetworkProtocol_FW_Rule]
alter table [dbo].[FW_Rule_RemoteNetworkMT] drop constraint [FK_FW_Rule_RemoteNetwork_FW_Rule]
go

----- alter constraints -----
-- fw rule --
alter table [dbo].[FW_RuleMT] drop constraint [PK_FW_Rule];
alter table [dbo].[FW_RuleMT] with check add constraint [PK_FW_Rule] primary key clustered
	([TenantId] asc, [id] asc)
go

-- fw group rule --
alter table [dbo].[FW_Group_RuleMT] drop constraint [PK_FW_Group_Rule];
alter table [dbo].[FW_Group_RuleMT] with check add constraint [PK_FW_Group_Rule] primary key clustered
	([TenantId] asc, [GroupId] asc, [RuleId] asc, [ChildIndex] asc)
go

----- re-create fk constraints -----
-- group rule --
alter table [dbo].[FW_Group_RuleMT] with check add constraint [FK_FW_Group_FW_Rule] foreign key([TenantId], [GroupId])
	references [dbo].[FW_RuleMT] ([TenantId], [id])
alter table [dbo].[FW_Group_RuleMT] with check add constraint [FK_FW_Group_FW_Rule2] foreign key([TenantId], [RuleId])
	references [dbo].[FW_RuleMT] ([TenantId], [id])
	on delete cascade

-- rules --
alter table [dbo].[FW_Rule_ApplicationMT] with check add constraint [FK_FW_Rule_Application_FW_Rule] foreign key([TenantId], [RuleId])
	references [dbo].[FW_RuleMT] ([TenantId], [id])
	on delete cascade
alter table [dbo].[FW_Rule_LocalNetworkMT] with check add constraint [FK_FW_Rule_LocalNetwork_FW_Rule] foreign key([TenantId], [RuleId])
	references [dbo].[FW_RuleMT] ([TenantId], [id])
	on delete cascade
alter table [dbo].[FW_Rule_LocationMT] with check add constraint [FK_FW_Rule_Location_FW_Rule] foreign key([TenantId], [RuleId])
	references [dbo].[FW_RuleMT] ([TenantId], [id])
	on delete cascade
alter table [dbo].[FW_Rule_NetworkProtocolMT] with check add constraint [FK_FW_Rule_NetworkProtocol_FW_Rule] foreign key([TenantId], [RuleId])
	references [dbo].[FW_RuleMT] ([TenantId], [id])
	on delete cascade
alter table [dbo].[FW_Rule_RemoteNetworkMT] with check add constraint [FK_FW_Rule_RemoteNetwork_FW_Rule] foreign key([TenantId], [RuleId])
	references [dbo].[FW_RuleMT] ([TenantId], [id])
	on delete cascade
go

---- rule - dtype index ----
if exists (select 1 from [dbo].[sysindexes] where id = object_id(N'[dbo].[FW_RuleMT]') and [name] = N'IX_FW_RuleMT_DTYPE')
begin
	drop index [IX_FW_RuleMT_DTYPE] on [dbo].[FW_RuleMT]
end
go

if exists (select 1 from [dbo].[sysindexes] where id = object_id(N'[dbo].[FW_RuleMT]') and [name] = N'IX_FW_RuleMT_DTYPE_TenantId')
begin
	drop index [IX_FW_RuleMT_DTYPE_TenantId] on [dbo].[FW_RuleMT]
end
go

create nonclustered index [IX_FW_RuleMT_DTYPE_TenantId]
	on [dbo].[FW_RuleMT] ([TenantId] asc, [DTYPE] asc)
	include([id], [version], [lastModifyingUsername], [lastModified], [name], [note], [enabled], [action],
	[direction], [mediaFlags], [tcpFlagsFlags], [transportProtocol], [localServiceList], [remoteServiceList],
	[intrusion], [trafficLogged], [schedule_start], [schedule_end], [schedule_offHours], [schedule_weekMask],
	[schedule_clickTimeout], [scheduleEnabled], [scheduleDisableDuringTime], [schedule_startHours],
	[schedule_startMinutes], [schedule_endHours], [schedule_endMinutes])
go

---- group rule - GroupId index ----
if exists (select 1 from [dbo].[sysindexes] where id = object_id(N'[dbo].[FW_Group_RuleMT]') and [name] = N'IX_FW_Group_RuleMT_GroupId')
begin
	drop index [IX_FW_Group_RuleMT_GroupId] on [dbo].[FW_Group_RuleMT]
end
go

create nonclustered index [IX_FW_Group_RuleMT_GroupId]
	on [dbo].[FW_Group_RuleMT] ([GroupId])
	include ([RuleId], [ChildIndex], [TenantId])
go

/*** Apps ***/
-- Rule apps --
alter table [dbo].[FW_Rule_ApplicationMT] drop constraint [PK_FW_Rule_Application]
alter table [dbo].[FW_Rule_ApplicationMT] with check add constraint [PK_FW_Rule_Application] primary key clustered
	([TenantId] asc, [RuleId] asc, [ApplicationId] asc)
go

-- apps --
---- drop fk constraints ----
alter table [dbo].[FW_Rule_ApplicationMT] drop constraint [FK_FW_Rule_Application_FW_Application]
alter table [dbo].[FW_ApplicationExecutableMT] drop constraint [FK_FW_ApplicationExecutable_FW_Application]

-- alter constraint --
alter table [dbo].[FW_ApplicationMT] drop constraint [PK_FW_ApplicationMT]
alter table [dbo].[FW_ApplicationMT] with check add constraint [PK_FW_ApplicationMT] primary key clustered
	([TenantId] asc, [Id] asc)

-- re-create fk constraint --
alter table [dbo].[FW_Rule_ApplicationMT] with check add constraint [FK_FW_Rule_Application_FW_Application] foreign key([TenantId], [ApplicationId])
	references [dbo].[FW_ApplicationMT] ([TenantId], [id])
	on delete cascade
alter table [dbo].[FW_ApplicationExecutableMT] with check add constraint [FK_FW_ApplicationExecutable_FW_Application] foreign key([TenantId], [ApplicationId])
	references [dbo].[FW_ApplicationMT] ([TenantId], [id])
	on delete cascade
go

/*** exes ***/
-- app exes --
if exists (select 1 from [dbo].[sysindexes] where id = object_id(N'[dbo].[FW_ApplicationExecutableMT]') and [name] = N'IX_FW_ApplicationExecutableMT_ApplicationId')
begin
	drop index [IX_FW_ApplicationExecutableMT_ApplicationId] on [dbo].[FW_ApplicationExecutableMT]
end

alter table [dbo].[FW_ApplicationExecutableMT] drop constraint [PK_FW_ApplicationExecutable]

if exists(select 1 from [sys].[columns] where object_id = object_id(N'[dbo].[FW_ApplicationExecutableMT]') and [name] = N'Id')
begin
	alter table [dbo].[FW_ApplicationExecutableMT] drop column [Id]
end

alter table [dbo].[FW_ApplicationExecutableMT] with check add constraint [PK_FW_ApplicationExecutable] primary key clustered
	([TenantId] asc, [ApplicationId] asc, [ExecutableId] asc)
go

-- exes --
---- drop fk constraints ----
alter table [dbo].[FW_ApplicationExecutableMT] drop constraint [FK_FW_ApplicationExecutable_FW_Executable]

---- alter constraint ----
alter table [dbo].[FW_ExecutableMT] drop constraint [PK_FW_Executable]
alter table [dbo].[FW_ExecutableMT] with check add constraint [PK_FW_Executable] primary key clustered
	([TenantId] asc, [Id] asc)

---- re-create fk constraint ----
alter table [dbo].[FW_ApplicationExecutableMT] with check add constraint [FK_FW_ApplicationExecutable_FW_Executable] foreign key([TenantId], [ExecutableId])
	references [dbo].[FW_ExecutableMT] ([TenantId], [id])
	on delete cascade
go

/*** networks ***/
-- named networks --
---- drop fk constraints ----
alter table [dbo].[FW_Rule_LocalNetworkMT] drop constraint [FK_FW_Rule_LocalNetwork_FW_NamedNetwork]
alter table [dbo].[FW_Rule_RemoteNetworkMT] drop constraint [FK_FW_Rule_RemoteNetwork_FW_NamedNetwork]
alter table [dbo].[FW_NamedNetwork_HostsMT] drop constraint [FK_FW_NamedNetwork_Hosts_FW_NamedNetwork]

---- alter pk constraint ----
alter table [dbo].[FW_NamedNetworkMT] drop constraint [PK_FW_NamedNetwork]
alter table [dbo].[FW_NamedNetworkMT] with check add constraint [PK_FW_NamedNetwork] primary key clustered
	([TenantId] asc, [Id] asc)

---- re-create fk constraints ----
alter table [dbo].[FW_Rule_LocalNetworkMT] with check add constraint [FK_FW_Rule_LocalNetwork_FW_NamedNetwork] foreign key ([TenantId], [NamedNetworkId])
	references [dbo].[FW_NamedNetworkMT] ([TenantId], [Id])
	on delete cascade
alter table [dbo].[FW_Rule_RemoteNetworkMT] with check add constraint [FK_FW_Rule_RemoteNetwork_FW_NamedNetwork] foreign key ([TenantId], [NamedNetworkId])
	references [dbo].[FW_NamedNetworkMT] ([TenantId], [Id])
	on delete cascade
alter table [dbo].[FW_NamedNetwork_HostsMT] with check add constraint [FK_FW_NamedNetwork_Hosts_FW_NamedNetwork] foreign key ([TenantId], [NamedNetworkId])
	references [dbo].[FW_NamedNetworkMT] ([TenantId], [Id])
	on delete cascade
go

-- local nets --
alter table [dbo].[FW_Rule_LocalNetworkMT] drop constraint [PK_FW_Rule_LocalNetwork]
alter table [dbo].[FW_Rule_LocalNetworkMT] with check add constraint [PK_FW_Rule_LocalNetwork] primary key clustered
	([TenantId] asc, [RuleId] asc, [NamedNetworkId] asc)
go

-- remote nets --
alter table [dbo].[FW_Rule_RemoteNetworkMT] drop constraint [PK_FW_Rule_RemoteNetwork]
alter table [dbo].[FW_Rule_RemoteNetworkMT] with check add constraint [PK_FW_Rule_RemoteNetwork] primary key clustered
	([TenantId] asc, [RuleId] asc, [NamedNetworkId] asc)
go

-- net hosts --
alter table [dbo].[FW_NamedNetwork_HostsMT] drop constraint [PK_FW_NamedNetwork_Hosts]
alter table [dbo].[FW_NamedNetwork_HostsMT] with check add constraint [PK_FW_NamedNetwork_Hosts] primary key clustered
	([TenantId] asc, [NamedNetworkId] asc, [address] asc)
go

/*** locations ***/
-- location ---
---- drop fk constraints ----
alter table [dbo].[FW_Rule_LocationMT] drop constraint [FK_FW_Rule_Location_FW_Location]
alter table [dbo].[FW_Location_DefaultGatewayMT] drop constraint [FK_FW_Location_DefaultGateway_FW_Location]
alter table [dbo].[FW_Location_DhcpServerMT] drop constraint [FK_FW_Location_DhcpServer_FW_Location]
alter table [dbo].[FW_Location_DnsServerMT] drop constraint [FK_FW_Location_DnsServer_FW_Location]
alter table [dbo].[FW_Location_DnsSuffixMT] drop constraint [FK_FW_Location_DnsSuffix_FW_Location]
alter table [dbo].[FW_Location_DomainReachableMT] drop constraint [FK_FW_Location_DomainReachable_FW_Location]
alter table [dbo].[FW_Location_PrimaryWinsMT] drop constraint [FK_FW_Location_PrimaryWins_FW_Location]
alter table [dbo].[FW_Location_RegKeyMT] drop constraint [FK_FW_Location_RegKey_FW_Location]
alter table [dbo].[FW_Location_SecondaryWinsMT] drop constraint [FK_FW_Location_SecondaryWins_FW_Location]

-- alter pk constraint --
alter table [dbo].[FW_LocationMT] drop constraint [PK_FW_Location]
alter table [dbo].[FW_LocationMT] with check add constraint [PK_FW_Location] primary key clustered
	([TenantId] asc, [Id] asc)

---- re-create fk constraints ----
alter table [dbo].[FW_Rule_LocationMT] with check add constraint [FK_FW_Rule_Location_FW_Location] foreign key ([TenantId], [LocationId])
	references [dbo].[FW_LocationMT] ([TenantId], [Id])
	on delete cascade
alter table [dbo].[FW_Location_DefaultGatewayMT] with check add constraint [FK_FW_Location_DefaultGateway_FW_Location] foreign key ([TenantId], [LocationId])
	references [dbo].[FW_LocationMT] ([TenantId], [Id])
	on delete cascade
alter table [dbo].[FW_Location_DhcpServerMT] with check add constraint [FK_FW_Location_DhcpServer_FW_Location] foreign key ([TenantId], [LocationId])
	references [dbo].[FW_LocationMT] ([TenantId], [Id])
	on delete cascade
alter table [dbo].[FW_Location_DnsServerMT] with check add constraint [FK_FW_Location_DnsServer_FW_Location] foreign key ([TenantId], [LocationId])
	references [dbo].[FW_LocationMT] ([TenantId], [Id])
	on delete cascade
alter table [dbo].[FW_Location_DnsSuffixMT] with check add constraint [FK_FW_Location_DnsSuffix_FW_Location] foreign key ([TenantId], [LocationId])
	references [dbo].[FW_LocationMT] ([TenantId], [Id])
	on delete cascade
alter table [dbo].[FW_Location_DomainReachableMT] with check add constraint [FK_FW_Location_DomainReachable_FW_Location] foreign key ([TenantId], [LocationId])
	references [dbo].[FW_LocationMT] ([TenantId], [Id])
	on delete cascade
alter table [dbo].[FW_Location_PrimaryWinsMT] with check add constraint [FK_FW_Location_PrimaryWins_FW_Location] foreign key ([TenantId], [LocationId])
	references [dbo].[FW_LocationMT] ([TenantId], [Id])
	on delete cascade
alter table [dbo].[FW_Location_RegKeyMT] with check add constraint [FK_FW_Location_RegKey_FW_Location] foreign key ([TenantId], [LocationId])
	references [dbo].[FW_LocationMT] ([TenantId], [Id])
	on delete cascade
alter table [dbo].[FW_Location_SecondaryWinsMT] with check add constraint [FK_FW_Location_SecondaryWins_FW_Location] foreign key ([TenantId], [LocationId])
	references [dbo].[FW_LocationMT] ([TenantId], [Id])
	on delete cascade
go

-- default gateway --
alter table [dbo].[FW_Location_DefaultGatewayMT] drop constraint [PK_FW_Location_DefaultGateway]
alter table [dbo].[FW_Location_DefaultGatewayMT] with check add constraint [PK_FW_Location_DefaultGateway] primary key clustered
	([TenantId] asc, [LocationId] asc, [address] asc)
go

-- dhcp server --
alter table [dbo].[FW_Location_DhcpServerMT] drop constraint [PK_FW_Location_DhcpServer]
alter table [dbo].[FW_Location_DhcpServerMT] with check add constraint [PK_FW_Location_DhcpServer] primary key clustered
	([TenantId] asc, [LocationId] asc, [address] asc)
go

-- dns server --
alter table [dbo].[FW_Location_DnsServerMT] drop constraint [PK_FW_Location_DnsServer]
alter table [dbo].[FW_Location_DnsServerMT] with check add constraint [PK_FW_Location_DnsServer] primary key clustered
	([TenantId] asc, [LocationId] asc, [address] asc)
go

-- dns suffix --
alter table [dbo].[FW_Location_DnsSuffixMT] drop constraint [PK_FW_Location_DnsSuffix]
alter table [dbo].[FW_Location_DnsSuffixMT] with check add constraint [PK_FW_Location_DnsSuffix] primary key clustered
	([TenantId] asc, [LocationId] asc, [dnsSuffix] asc)
go

-- reachable domain --
alter table [dbo].[FW_Location_DomainReachableMT] drop constraint [PK_FW_Location_DomainReachable]
alter table [dbo].[FW_Location_DomainReachableMT] with check add constraint [PK_FW_Location_DomainReachable] primary key clustered
	([TenantId] asc, [LocationId] asc, [domainReachable] asc)
go

-- primary wins--
alter table [dbo].[FW_Location_PrimaryWinsMT] drop constraint [PK_FW_Location_PrimaryWins]
alter table [dbo].[FW_Location_PrimaryWinsMT] with check add constraint [PK_FW_Location_PrimaryWins] primary key clustered
	([TenantId] asc, [LocationId] asc, [address] asc)
go

-- reg key --
alter table [dbo].[FW_Location_RegKeyMT] drop constraint [PK_FW_Location_RegKey]
alter table [dbo].[FW_Location_RegKeyMT] with check add constraint [PK_FW_Location_RegKey] primary key clustered
	([TenantId] asc, [LocationId] asc, [regKeyId] asc)
go

-- secondary wins --
alter table [dbo].[FW_Location_SecondaryWinsMT] drop constraint [PK_FW_Location_SecondaryWins]
alter table [dbo].[FW_Location_SecondaryWinsMT] with check add constraint [PK_FW_Location_SecondaryWins] primary key clustered
	([TenantId] asc, [LocationId] asc, [address] asc)
go

/*** service name ***/
alter table [dbo].[FW_ServiceNameMT] drop constraint [PK_FW_ServiceName]
alter table [dbo].[FW_ServiceNameMT] with check add constraint [PK_FW_ServiceName] primary key clustered
	([TenantId] asc, [id] asc)
go


-------------- updated tenant filtering pattern ---------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FWSP_CONVERT_TABLE_TO_VIEW]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
  BEGIN
	DROP PROCEDURE FWSP_CONVERT_TABLE_TO_VIEW
  END
GO

CREATE PROCEDURE [dbo].[FWSP_CONVERT_TABLE_TO_VIEW]
	@ViewName nvarchar(256),
	@Install   char(1)
AS
BEGIN
/******************************************************************************************
 * FWSP_CONVERT_TABLE_TO_FILTERED_VIEW
 *
 *   Creates the specified tenant-filtered view
 *
 *   Parameters:
 *     @TableName             The table name to be converted to view
 ******************************************************************************************/
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @NewTableName nvarchar(256);
	SET @NewTableName = @ViewName + 'MT';

	-- Add view for a table with tenant id column
	EXEC ('
	IF object_id (''dbo.' + @ViewName + ''', ''V'') IS NOT NULL
	  DROP VIEW ' + @ViewName
	);

	EXEC ('
	CREATE VIEW ' + @ViewName + ' AS
		select mt.* from ' + @NewTableName + ' mt ' +
			'where mt.[TenantId] = convert(int, substring(context_info(), 5, 4))'
	);

	exec('
		GRANT SELECT, INSERT, UPDATE, DELETE ON ' + @ViewName + ' To mcafeeTenant
		GRANT SELECT, INSERT, UPDATE, DELETE ON ' + @ViewName + ' To mcafeeSystem'
	)
END
GO

--FW_Application
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Application]'))
BEGIN
	DROP VIEW	[dbo].[FW_Application]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Application', 'Y'

--FW_Executable
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Executable]'))
BEGIN
	DROP VIEW	[dbo].[FW_Executable]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Executable', 'Y'

--FW_ApplicationExecutable
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_ApplicationExecutable]'))
BEGIN
	DROP VIEW	[dbo].[FW_ApplicationExecutable]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_ApplicationExecutable', 'Y'

--FW_Rule
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule]'))
BEGIN
	DROP VIEW	[dbo].[FW_Rule]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Rule' , 'Y'

--FW_Group_Rule
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Group_Rule]'))
BEGIN
	DROP VIEW	[dbo].[FW_Group_Rule]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Group_Rule' , 'Y'

--FW_Location
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location' , 'Y'

--FW_NamedNetwork
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_NamedNetwork]'))
BEGIN
	DROP VIEW	[dbo].[FW_NamedNetwork]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_NamedNetwork' , 'Y'

--FW_Rule_Application
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_Application]'))
BEGIN
	DROP VIEW	[dbo].[FW_Rule_Application]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Rule_Application' , 'Y'

--FW_Rule_LocalNetwork
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_LocalNetwork]'))
BEGIN
	DROP VIEW	[dbo].[FW_Rule_LocalNetwork]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Rule_LocalNetwork', 'Y'

--FW_Rule_Location
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_Location]'))
BEGIN
	DROP VIEW	[dbo].[FW_Rule_Location]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Rule_Location', 'Y'

--FW_ServiceName
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_ServiceName]'))
BEGIN
	DROP VIEW	[dbo].[FW_ServiceName]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_ServiceName', 'Y'

--FW_Location_DefaultGateway
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DefaultGateway]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_DefaultGateway]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_DefaultGateway' , 'Y'

--FW_Location_DhcpServer
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DhcpServer]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_DhcpServer]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_DhcpServer' , 'Y'

--FW_Location_DnsServer
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DnsServer]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_DnsServer]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_DnsServer' , 'Y'

--FW_Location_DnsSuffix
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DnsSuffix]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_DnsSuffix]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_DnsSuffix' , 'Y'

--FW_Location_DomainReachable
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DomainReachable]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_DomainReachable]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_DomainReachable' , 'Y'

--FW_Location_PrimaryWins
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_PrimaryWins]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_PrimaryWins]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_PrimaryWins' , 'Y'

--FW_Location_RegKey
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_RegKey]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_RegKey]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_RegKey' , 'Y'

--FW_Location_SecondaryWins
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_SecondaryWins]'))
BEGIN
	DROP VIEW	[dbo].[FW_Location_SecondaryWins]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_SecondaryWins' , 'Y'

--FW_NamedNetwork_Hosts
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_NamedNetwork_Hosts]'))
BEGIN
	DROP VIEW	[dbo].[FW_NamedNetwork_Hosts]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_NamedNetwork_Hosts' , 'Y'

--FW_Rule_NetworkProtocol
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_NetworkProtocol]'))
BEGIN
	DROP VIEW	[dbo].[FW_Rule_NetworkProtocol]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Rule_NetworkProtocol' , 'Y'

--FW_Rule_RemoteNetwork
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_RemoteNetwork]'))
BEGIN
	DROP VIEW	[dbo].[FW_Rule_RemoteNetwork]
END
EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Rule_RemoteNetwork' , 'Y'
