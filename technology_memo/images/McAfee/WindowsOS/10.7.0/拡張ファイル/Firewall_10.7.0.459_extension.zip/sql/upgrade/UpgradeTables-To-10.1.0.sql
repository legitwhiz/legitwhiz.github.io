PRINT '-- Executing DropTables.sql --'
SET NOCOUNT ON

IF NOT EXISTS (Select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FW_RuleMT' AND COLUMN_NAME = 'scheduleEnabled')
  BEGIN
		ALTER TABLE [dbo].[FW_RuleMT]
		ADD
			[scheduleEnabled]      			BIT         CONSTRAINT DF_FW_RuleMT_bscheduleEnabled DEFAULT ((0)) WITH VALUES
		, [scheduleDisableDuringTime] BIT    			CONSTRAINT DF_FW_RuleMT_bscheduleDisableDuringTime DEFAULT ((0))     WITH VALUES
		, [schedule_startHours]    		INT        	CONSTRAINT DF_FW_RuleMT_schedule_startHours DEFAULT ((0))  WITH VALUES
		, [schedule_startMinutes]  		INT        	CONSTRAINT DF_FW_RuleMT_schedule_startMinutes DEFAULT ((0)) WITH VALUES
		, [schedule_endHours]      		INT        	CONSTRAINT DF_FW_RuleMT_schedule_endHours DEFAULT ((0))    WITH VALUES
		, [schedule_endMinutes]    		INT        	CONSTRAINT DF_FW_RuleMT_schedule_endMinutes DEFAULT ((0))   WITH VALUES
	END

-- Upgrade FW_Rule view to pick up ne columns
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule]') AND OBJECTPROPERTY(id, N'IsView') = 1)
BEGIN
	DROP VIEW	[dbo].[FW_Rule]
END
GO

CREATE VIEW [dbo].[FW_Rule] AS
      SELECT * FROM FW_RuleMT
      WHERE TenantId = 0
        OR TenantId = (select tid from FWFN_GetTenancyInfoTable())

GO


IF EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[FW_RuleMT]') AND name = N'IX_FW_RuleMT_DTYPE')
  BEGIN
    DROP INDEX [dbo].[FW_RuleMT].[IX_FW_RuleMT_DTYPE]
  END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[FW_RuleMT]') AND name = N'IX_FW_RuleMT_DTYPE')
  BEGIN
    CREATE INDEX [IX_FW_RuleMT_DTYPE] ON [dbo].[FW_RuleMT]
    ([DTYPE])
    INCLUDE ([id], [version], [lastModifyingUsername], [lastModified], [name], [note], [enabled], [action], [direction], [mediaFlags], [tcpFlagsFlags], [transportProtocol], [localServiceList], [remoteServiceList], [intrusion], [trafficLogged], [schedule_start], [schedule_end], [schedule_offHours], [schedule_weekMask], [schedule_clickTimeout],[scheduleEnabled],[scheduleDisableDuringTime],[schedule_startHours],[schedule_startMinutes],[schedule_endHours],[schedule_endMinutes])
  END
GO

DECLARE	@multiTenant int;
SELECT	@multiTenant = ##MultiTenantMode##;
IF @multiTenant = 0
  BEGIN

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Application_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Application_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Application_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Application_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Application_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Application_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_ApplicationExecutable_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_ApplicationExecutable_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_ApplicationExecutable_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_ApplicationExecutable_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_ApplicationExecutable_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_ApplicationExecutable_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Executable_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Executable_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Executable_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Executable_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Executable_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Executable_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Group_Rule_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Group_Rule_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Group_Rule_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Group_Rule_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Group_Rule_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Group_Rule_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DefaultGateway_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Location_DefaultGateway_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DefaultGateway_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Location_DefaultGateway_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DefaultGateway_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Location_DefaultGateway_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Location_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DhcpServer_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Location_DhcpServer_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DhcpServer_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Location_DhcpServer_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DhcpServer_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Location_DhcpServer_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DnsServer_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Location_DnsServer_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DnsServer_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Location_DnsServer_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DnsServer_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Location_DnsServer_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DnsSuffix_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Location_DnsSuffix_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DnsSuffix_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Location_DnsSuffix_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DnsSuffix_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Location_DnsSuffix_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DomainReachable_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Location_DomainReachable_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DomainReachable_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Location_DomainReachable_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_DomainReachable_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Location_DomainReachable_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Location_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_PrimaryWins_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Location_PrimaryWins_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_PrimaryWins_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Location_PrimaryWins_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_PrimaryWins_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Location_PrimaryWins_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_RegKey_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Location_RegKey_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_RegKey_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Location_RegKey_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_RegKey_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Location_RegKey_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_SecondaryWins_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Location_SecondaryWins_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_SecondaryWins_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Location_SecondaryWins_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_SecondaryWins_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Location_SecondaryWins_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Location_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Location_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_NamedNetwork_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_NamedNetwork_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_NamedNetwork_Hosts_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_NamedNetwork_Hosts_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_NamedNetwork_Hosts_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_NamedNetwork_Hosts_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_NamedNetwork_Hosts_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_NamedNetwork_Hosts_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_NamedNetwork_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_NamedNetwork_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_NamedNetwork_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_NamedNetwork_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_Application_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Rule_Application_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_Application_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Rule_Application_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_Application_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Rule_Application_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Rule_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Rule_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_LocalNetwork_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Rule_LocalNetwork_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_LocalNetwork_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Rule_LocalNetwork_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_LocalNetwork_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Rule_LocalNetwork_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_Location_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Rule_Location_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_Location_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Rule_Location_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_Location_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Rule_Location_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_NetworkProtocol_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Rule_NetworkProtocol_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_NetworkProtocol_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Rule_NetworkProtocol_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_NetworkProtocol_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Rule_NetworkProtocol_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_RemoteNetwork_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_Rule_RemoteNetwork_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_RemoteNetwork_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_Rule_RemoteNetwork_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_RemoteNetwork_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Rule_RemoteNetwork_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_Rule_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_Rule_UPDATE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_ServiceName_DELETE')
			BEGIN
					DROP TRIGGER TR_FW_ServiceName_DELETE
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_ServiceName_INSERT')
			BEGIN
					DROP TRIGGER TR_FW_ServiceName_INSERT
			END

		IF EXISTS (Select * from sys.triggers WHERE name = 'TR_FW_ServiceName_UPDATE')
			BEGIN
					DROP TRIGGER TR_FW_ServiceName_UPDATE
			END

		--FW_Application
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Application]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Application]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Application', 'Y'

		--FW_Executable

		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Executable]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Executable]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Executable', 'Y'

		--FW_ApplicationExecutable

		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_ApplicationExecutable]'))
		BEGIN
			DROP VIEW	[dbo].[FW_ApplicationExecutable]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_ApplicationExecutable', 'Y'


		--FW_Rule
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Rule]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Rule' , 'Y'


		--FW_Group_Rule
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Group_Rule]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Group_Rule]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Group_Rule' , 'Y'


		--FW_Location
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Location]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location' , 'Y'


		--FW_NamedNetwork
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_NamedNetwork]'))
		BEGIN
			DROP VIEW	[dbo].[FW_NamedNetwork]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_NamedNetwork' , 'Y'


		--FW_Rule_Application
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_Application]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Rule_Application]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Rule_Application' , 'Y'

		--FW_Rule_LocalNetwork
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_LocalNetwork]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Rule_LocalNetwork]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Rule_LocalNetwork', 'Y'


		--FW_Rule_Location
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_Location]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Rule_Location]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Rule_Location', 'Y'


		--FW_ServiceName
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_ServiceName]'))
		BEGIN
			DROP VIEW	[dbo].[FW_ServiceName]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_ServiceName', 'Y'


		--FW_Location_DefaultGateway
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DefaultGateway]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Location_DefaultGateway]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_DefaultGateway' , 'Y'


		--FW_Location_DhcpServer
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DhcpServer]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Location_DhcpServer]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_DhcpServer' , 'Y'


		--FW_Location_DnsServer
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DnsServer]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Location_DnsServer]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_DnsServer' , 'Y'


		--FW_Location_DnsSuffix
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DnsSuffix]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Location_DnsSuffix]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_DnsSuffix' , 'Y'


		--FW_Location_DomainReachable
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_DomainReachable]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Location_DomainReachable]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_DomainReachable' , 'Y'


		--FW_Location_PrimaryWins
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_PrimaryWins]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Location_PrimaryWins]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_PrimaryWins' , 'Y'


		--FW_Location_RegKey
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_RegKey]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Location_RegKey]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_RegKey' , 'Y'


		--FW_Location_SecondaryWins
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Location_SecondaryWins]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Location_SecondaryWins]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Location_SecondaryWins' , 'Y'


		--FW_NamedNetwork_Hosts
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_NamedNetwork_Hosts]'))
		BEGIN
			DROP VIEW	[dbo].[FW_NamedNetwork_Hosts]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_NamedNetwork_Hosts' , 'Y'


		--FW_Rule_NetworkProtocol
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_NetworkProtocol]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Rule_NetworkProtocol]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Rule_NetworkProtocol' , 'Y'


		--FW_Rule_RemoteNetwork
		IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_Rule_RemoteNetwork]'))
		BEGIN
			DROP VIEW	[dbo].[FW_Rule_RemoteNetwork]
		END

		EXEC [FWSP_CONVERT_TABLE_TO_VIEW] 'FW_Rule_RemoteNetwork' , 'Y'

  END
GO