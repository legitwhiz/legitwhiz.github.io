/**
 *	Create All Firewall Tables
 */

IF OBJECT_ID('dbo.FW_ExecutableMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_ExecutableMT
		IF OBJECT_ID('dbo.FW_ExecutableMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_ExecutableMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_ExecutableMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_ExecutableMT]
(
	[id]					UNIQUEIDENTIFIER	NOT NULL
,	[version]				BIGINT				NULL
,	[lastModifyingUsername]	NVARCHAR(100)		NOT NULL
,	[lastModified]			DATETIME			NOT NULL
,	[name]					NVARCHAR(100) 		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[description]			NVARCHAR(255)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[filename]				NVARCHAR(260)		NOT NULL
,	[fingerprint]			NVARCHAR(32)		NOT NULL
,	[signerName]			NVARCHAR(1024)		NOT NULL
,	[note]					NVARCHAR(3000)		NOT NULL
,	[TenantId]				INT					NOT NULL
,	CONSTRAINT [PK_FW_Executable] PRIMARY KEY CLUSTERED
	(
		[id]		ASC
	,	[TenantId]	ASC
	)
)
GO

ALTER TABLE [dbo].[FW_ExecutableMT] ADD  CONSTRAINT [DF_FW_Executable_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_ExecutableMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Executable_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])

ALTER TABLE [dbo].[FW_ExecutableMT] CHECK CONSTRAINT [FK_FW_Executable_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_ExecutableMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_ExecutableMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_ExecutableMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_ApplicationMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_ApplicationMT
		IF OBJECT_ID('dbo.FW_ApplicationMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_ApplicationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_ApplicationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_ApplicationMT]
(
	[id]					UNIQUEIDENTIFIER	NOT NULL
,	[version]				BIGINT				NULL
,	[lastModifyingUsername]	NVARCHAR(100)		NOT NULL
,	[lastModified]			DATETIME			NOT NULL
,	[name]					NVARCHAR(100)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[note]					NVARCHAR(3000)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[TenantId]				INT					NOT NULL
,	CONSTRAINT [PK_FW_ApplicationMT] PRIMARY KEY CLUSTERED 
	(
		[id]		ASC
	,	[TenantId]	ASC
	)
)

ALTER TABLE [dbo].[FW_ApplicationMT] ADD  CONSTRAINT [DF_FW_Application_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_ApplicationMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Application_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])

ALTER TABLE [dbo].[FW_ApplicationMT] CHECK CONSTRAINT [FK_FW_Application_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_ApplicationMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_ApplicationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_ApplicationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_ApplicationExecutableMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_ApplicationExecutableMT
		IF OBJECT_ID('dbo.FW_ApplicationExecutableMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_ApplicationExecutableMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_ApplicationExecutableMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_ApplicationExecutableMT]
(
	[Id]			INT	IDENTITY(1,1)	NOT NULL
,	[ApplicationId]	UNIQUEIDENTIFIER	NOT NULL
,	[ExecutableId]	UNIQUEIDENTIFIER	NOT NULL
,	[TenantId]		INT					NOT NULL
,	CONSTRAINT [PK_FW_ApplicationExecutable] PRIMARY KEY CLUSTERED
	(
		[Id]		ASC
	,	[TenantId]	ASC
	)
)

ALTER TABLE [dbo].[FW_ApplicationExecutableMT] ADD  CONSTRAINT [DF_FW_ApplicationExecutable_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_ApplicationExecutableMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_ApplicationExecutable_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_ApplicationExecutableMT] CHECK CONSTRAINT [FK_FW_ApplicationExecutable_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_ApplicationExecutableMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_ApplicationExecutableMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_ApplicationExecutableMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_NamedNetwork_HostsMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_NamedNetwork_HostsMT
		IF OBJECT_ID('dbo.FW_NamedNetwork_HostsMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_NamedNetwork_HostsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_NamedNetwork_HostsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_NamedNetwork_HostsMT]
(
	[NamedNetworkId]	UNIQUEIDENTIFIER	NOT NULL
,	[address]			NVARCHAR(256)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[TenantId]			INT					NOT NULL
,	CONSTRAINT [PK_FW_NamedNetwork_Hosts] PRIMARY KEY CLUSTERED 
	(
		[NamedNetworkId]	ASC
	,	[address]			ASC
	,	[TenantId]			ASC
	)
)

ALTER TABLE [dbo].[FW_NamedNetwork_HostsMT] ADD  CONSTRAINT [DF_FW_NamedNetwork_Hosts_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_NamedNetwork_HostsMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_NamedNetwork_Hosts_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_NamedNetwork_HostsMT] CHECK CONSTRAINT [FK_FW_NamedNetwork_Hosts_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_NamedNetwork_HostsMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_NamedNetwork_HostsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_NamedNetwork_HostsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_NamedNetworkMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_NamedNetworkMT
		IF OBJECT_ID('dbo.FW_NamedNetworkMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_NamedNetworkMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_NamedNetworkMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_NamedNetworkMT]
(
	[id]					UNIQUEIDENTIFIER	NOT NULL
,	[version]				BIGINT				NULL
,	[lastModifyingUsername]	NVARCHAR(100)		NOT NULL
,	[lastModified]			DATETIME			NOT NULL
,	[name]					NVARCHAR(100)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[note]					NVARCHAR(3000)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[TenantId]				INT					NOT NULL
,	CONSTRAINT [PK_FW_NamedNetwork] PRIMARY KEY CLUSTERED
	(
		[id]		ASC
	,	[TenantId]	ASC
	)
)

ALTER TABLE [dbo].[FW_NamedNetworkMT] ADD  CONSTRAINT [DF_FW_NamedNetwork_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_NamedNetworkMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_NamedNetwork_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])

ALTER TABLE [dbo].[FW_NamedNetworkMT] CHECK CONSTRAINT [FK_FW_NamedNetwork_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_NamedNetworkMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_NamedNetworkMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_NamedNetworkMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_ServiceNameMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_ServiceNameMT
		IF OBJECT_ID('dbo.FW_ServiceNameMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_ServiceNameMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_ServiceNameMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_ServiceNameMT]
(
	[id]					UNIQUEIDENTIFIER	NOT NULL
,	[version]				BIGINT				NULL
,	[lastModifyingUsername]	NVARCHAR(100)		NOT NULL
,	[lastModified]			DATETIME			NOT NULL
,	[name]					NVARCHAR(100)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[note]					NVARCHAR(3000)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[ipProtocol]			INT					NOT NULL
,	[port]					INT					NOT NULL
,	[TenantId]				INT					NOT NULL
,	CONSTRAINT [PK_FW_ServiceName] PRIMARY KEY CLUSTERED
	(
		[id]		ASC
	,	[TenantId]	ASC
)
)

ALTER TABLE [dbo].[FW_ServiceNameMT] ADD  CONSTRAINT [DF_FW_ServiceName_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_ServiceNameMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_ServiceName_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_ServiceNameMT] CHECK CONSTRAINT [FK_FW_ServiceName_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_ServiceNameMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_ServiceNameMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_ServiceNameMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_LocationMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_LocationMT
		IF OBJECT_ID('dbo.FW_LocationMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_LocationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_LocationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_LocationMT]
(
	[id]					UNIQUEIDENTIFIER	NOT NULL
,	[version]				BIGINT				NULL
,	[lastModifyingUsername]	NVARCHAR(100)		NOT NULL
,	[lastModified]			DATETIME			NOT NULL
,	[name]					NVARCHAR(100)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[note]					NVARCHAR(3000)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[isolated]				BIT					NOT NULL
,	[requireEpoReachable]	BIT					NOT NULL
,	[TenantId]				INT					NOT NULL
,	CONSTRAINT [PK_FW_Location] PRIMARY KEY CLUSTERED
	(
		[id]		ASC
	,	[TenantId]	ASC
	)
)

ALTER TABLE [dbo].[FW_LocationMT] ADD  CONSTRAINT [DF_FW_Location_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_LocationMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Location_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])

ALTER TABLE [dbo].[FW_LocationMT] CHECK CONSTRAINT [FK_FW_Location_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_LocationMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_LocationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_LocationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Location_DnsSuffixMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Location_DnsSuffixMT
		IF OBJECT_ID('dbo.FW_Location_DnsSuffixMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Location_DnsSuffixMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Location_DnsSuffixMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Location_DnsSuffixMT]
(
	[LocationId]	UNIQUEIDENTIFIER	NOT NULL
,	[dnsSuffix]		NVARCHAR(256)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[TenantId]		INT					NOT NULL
,	CONSTRAINT [PK_FW_Location_DnsSuffix] PRIMARY KEY CLUSTERED
	(
		[LocationId]	ASC
	,	[dnsSuffix]		ASC
	,	[TenantID]		ASC
	)
)

ALTER TABLE [dbo].[FW_Location_DnsSuffixMT] ADD  CONSTRAINT [DF_FW_Location_DnsSuffix_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Location_DnsSuffixMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Location_DnsSuffix_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Location_DnsSuffixMT] CHECK CONSTRAINT [FK_FW_Location_DnsSuffix_OrionTenant]
GO


IF OBJECT_ID('dbo.FW_Location_DomainReachableMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Location_DomainReachableMT
		IF OBJECT_ID('dbo.FW_Location_DomainReachableMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Location_DomainReachableMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Location_DomainReachableMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Location_DomainReachableMT]
(
	[LocationId]	UNIQUEIDENTIFIER	NOT NULL
,	[domainReachable]		NVARCHAR(256)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[TenantId]		INT					NOT NULL
,	CONSTRAINT [PK_FW_Location_DomainReachable] PRIMARY KEY CLUSTERED
	(
		[LocationId]	ASC
	,	[domainReachable]		ASC
	,	[TenantID]		ASC
	)
)

ALTER TABLE [dbo].[FW_Location_DomainReachableMT] ADD  CONSTRAINT [DF_FW_Location_DomainReachable_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Location_DomainReachableMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Location_DomainReachable_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Location_DomainReachableMT] CHECK CONSTRAINT [FK_FW_Location_DomainReachable_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_Location_DomainReachableMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Location_DomainReachableMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Location_DomainReachableMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Location_DhcpServerMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Location_DhcpServerMT
		IF OBJECT_ID('dbo.FW_Location_DhcpServerMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Location_DhcpServerMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Location_DhcpServerMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Location_DhcpServerMT]
(
	[LocationId]	UNIQUEIDENTIFIER	NOT NULL
,	[address]		NVARCHAR(256)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[TenantId]		INT					NOT NULL
,	CONSTRAINT [PK_FW_Location_DhcpServer] PRIMARY KEY CLUSTERED
	(
		[LocationId]	ASC
	,	[address]		ASC
	,	[TenantID]		ASC
	)
)

ALTER TABLE [dbo].[FW_Location_DhcpServerMT] ADD  CONSTRAINT [DF_FW_Location_DhcpServer_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Location_DhcpServerMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Location_DhcpServer_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Location_DhcpServerMT] CHECK CONSTRAINT [FK_FW_Location_DhcpServer_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_Location_DhcpServerMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Location_DhcpServerMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Location_DhcpServerMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Location_DnsServerMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Location_DnsServerMT
		IF OBJECT_ID('dbo.FW_Location_DnsServerMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Location_DnsServerMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Location_DnsServerMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Location_DnsServerMT]
(
	[LocationId]	UNIQUEIDENTIFIER	NOT NULL
,	[address]		NVARCHAR(256)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[TenantId]		INT					NOT NULL
,	CONSTRAINT [PK_FW_Location_DnsServer] PRIMARY KEY CLUSTERED
	(
		[LocationId]	ASC
	,	[address]		ASC
	,	[TenantID]		ASC
	)
)

ALTER TABLE [dbo].[FW_Location_DnsServerMT] ADD  CONSTRAINT [DF_FW_Location_DnsServer_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Location_DnsServerMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Location_DnsServer_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Location_DnsServerMT] CHECK CONSTRAINT [FK_FW_Location_DnsServer_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_Location_DnsServerMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Location_DnsServerMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Location_DnsServerMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Location_DefaultGatewayMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Location_DefaultGatewayMT
		IF OBJECT_ID('dbo.FW_Location_DefaultGatewayMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Location_DefaultGatewayMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Location_DefaultGatewayMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Location_DefaultGatewayMT]
(
	[LocationId]	UNIQUEIDENTIFIER	NOT NULL
,	[address]		NVARCHAR(256)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[TenantId]		INT					NOT NULL
,	CONSTRAINT [PK_FW_Location_DefaultGateway] PRIMARY KEY CLUSTERED
	(
		[LocationId]	ASC
	,	[address]		ASC
	,	[TenantId]		ASC
	)
)

ALTER TABLE [dbo].[FW_Location_DefaultGatewayMT] ADD  CONSTRAINT [DF_FW_Location_DefaultGateway_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Location_DefaultGatewayMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Location_DefaultGateway_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Location_DefaultGatewayMT] CHECK CONSTRAINT [FK_FW_Location_DefaultGateway_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_Location_DefaultGatewayMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Location_DefaultGatewayMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Location_DefaultGatewayMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Location_PrimaryWinsMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Location_PrimaryWinsMT
		IF OBJECT_ID('dbo.FW_Location_PrimaryWinsMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Location_PrimaryWinsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Location_PrimaryWinsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Location_PrimaryWinsMT]
(
	[LocationId]	UNIQUEIDENTIFIER	NOT NULL
,	[address]		NVARCHAR(256)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[TenantId]		INT					NOT NULL
,	CONSTRAINT [PK_FW_Location_PrimaryWins] PRIMARY KEY CLUSTERED
	(
		[LocationId]	ASC
	,	[address]		ASC
	,	[TenantId]		ASC
	)
)

ALTER TABLE [dbo].[FW_Location_PrimaryWinsMT] ADD  CONSTRAINT [DF_FW_Location_PrimaryWins_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Location_PrimaryWinsMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Location_PrimaryWins_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Location_PrimaryWinsMT] CHECK CONSTRAINT [FK_FW_Location_PrimaryWins_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_Location_PrimaryWinsMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Location_PrimaryWinsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Location_PrimaryWinsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Location_SecondaryWinsMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Location_SecondaryWinsMT
		IF OBJECT_ID('dbo.FW_Location_SecondaryWinsMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Location_SecondaryWinsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Location_SecondaryWinsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Location_SecondaryWinsMT]
(
	[LocationId]	UNIQUEIDENTIFIER	NOT NULL
,	[address]		NVARCHAR(256)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[TenantId]		INT					NOT NULL
,	CONSTRAINT [PK_FW_Location_SecondaryWins] PRIMARY KEY CLUSTERED
	(
		[LocationId]	ASC
	,	[address]		ASC
	,	[TenantId]		ASC
	)
)

ALTER TABLE [dbo].[FW_Location_SecondaryWinsMT] ADD  CONSTRAINT [DF_FW_Location_SecondaryWins_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Location_SecondaryWinsMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Location_SecondaryWins_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Location_SecondaryWinsMT] CHECK CONSTRAINT [FK_FW_Location_SecondaryWins_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_Location_SecondaryWinsMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Location_SecondaryWinsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Location_SecondaryWinsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Location_RegKeyMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Location_RegKeyMT
		IF OBJECT_ID('dbo.FW_Location_RegKeyMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Location_RegKeyMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Location_RegKeyMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Location_RegKeyMT]
(
	[LocationId]	UNIQUEIDENTIFIER	NOT NULL
,	[regKeyId]		INT IDENTITY (1,1)	NOT NULL
,	[regKey]		NVARCHAR(3000)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[TenantId]		INT					NOT NULL
,	CONSTRAINT [PK_FW_Location_RegKey] PRIMARY KEY CLUSTERED
	(
		[LocationId]	ASC
	,	[regKeyId]		ASC
	,	[TenantId]		ASC
	)
)

ALTER TABLE [dbo].[FW_Location_RegKeyMT] ADD  CONSTRAINT [DF_FW_Location_RegKey_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Location_RegKeyMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Location_RegKey_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Location_RegKeyMT] CHECK CONSTRAINT [FK_FW_Location_RegKey_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_Location_RegKeyMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Location_RegKeyMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Location_RegKeyMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Rule_NetworkProtocolMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Rule_NetworkProtocolMT
		IF OBJECT_ID('dbo.FW_Rule_NetworkProtocolMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Rule_NetworkProtocolMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Rule_NetworkProtocolMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Rule_NetworkProtocolMT]
(
	[RuleId]			UNIQUEIDENTIFIER	NOT NULL
,	[networkProtocol]	INT					NOT NULL
,	[TenantId]			INT					NOT NULL
,	CONSTRAINT [PK_FW_Rule_NetworkProtocol] PRIMARY KEY CLUSTERED
	(
		[RuleId]			ASC
	,	[networkProtocol]	ASC
	,	[TenantId]			ASC
	)
)

ALTER TABLE [dbo].[FW_Rule_NetworkProtocolMT] ADD  CONSTRAINT [DF_FW_Rule_NetworkProtocol_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Rule_NetworkProtocolMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Rule_NetworkProtocol_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Rule_NetworkProtocolMT] CHECK CONSTRAINT [FK_FW_Rule_NetworkProtocol_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_Rule_NetworkProtocolMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Rule_NetworkProtocolMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Rule_NetworkProtocolMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_RuleMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_RuleMT
		IF OBJECT_ID('dbo.FW_RuleMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_RuleMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_RuleMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_RuleMT]
(
	[id]					UNIQUEIDENTIFIER	NOT NULL
,	[version]				BIGINT				NULL
,	[lastModifyingUsername]	NVARCHAR(100)		NOT NULL
,	[lastModified]			DATETIME			NOT NULL
,	[name]					NVARCHAR(100)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[note]					NVARCHAR(3000)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[enabled]				BIT					NOT NULL
,	[action]				NVARCHAR(10)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[direction]				NVARCHAR(10)		COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[mediaFlags]			BIGINT				NOT NULL
,	[tcpFlagsFlags]			BIGINT				NOT NULL
,	[transportProtocol]		INT					NOT NULL
,	[localServiceList]		VARCHAR(1000)		NOT NULL
,	[remoteServiceList]		VARCHAR(1000)		NOT NULL
,	[intrusion]				BIT					NOT NULL
,	[trafficLogged]			BIT					NOT NULL
,	[schedule_start]		NVARCHAR(5)			NOT NULL
,	[schedule_end]			NVARCHAR(5)			NOT NULL
,	[schedule_offHours]		NVARCHAR(10)		NOT NULL
,	[schedule_weekMask]		INT					NOT NULL
,	[schedule_clickTimeout]	INT					NOT NULL
,	[DTYPE]					NVARCHAR(30)		NOT NULL
,	[leafNodeId]			INT					NULL
,	[TenantId]				INT					NOT NULL
,	CONSTRAINT [PK_FW_Rule] PRIMARY KEY CLUSTERED
	(
		[id]		ASC
	,	[TenantId]	ASC
	)
)

ALTER TABLE [dbo].[FW_RuleMT] ADD  CONSTRAINT [DF_FW_Rule_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_RuleMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Rule_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])

ALTER TABLE [dbo].[FW_RuleMT] CHECK CONSTRAINT [FK_FW_Rule_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_RuleMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_RuleMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_RuleMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Rule_LocalNetworkMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Rule_LocalNetworkMT
		IF OBJECT_ID('dbo.FW_Rule_LocalNetworkMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Rule_LocalNetworkMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Rule_LocalNetworkMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Rule_LocalNetworkMT]
(
	[RuleId]			UNIQUEIDENTIFIER	NOT NULL
,	[NamedNetworkId]	UNIQUEIDENTIFIER	NOT NULL
,	[TenantId]			INT					NOT NULL
,	CONSTRAINT [PK_FW_Rule_LocalNetwork] PRIMARY KEY CLUSTERED
	(
		[RuleId]			ASC
	,	[NamedNetworkId]	ASC
	,	[TenantId]			ASC
	)
)

ALTER TABLE [dbo].[FW_Rule_LocalNetworkMT] ADD  CONSTRAINT [DF_FW_Rule_LocalNetwork_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Rule_LocalNetworkMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Rule_LocalNetwork_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Rule_LocalNetworkMT] CHECK CONSTRAINT [FK_FW_Rule_LocalNetwork_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_Rule_LocalNetworkMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Rule_LocalNetworkMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Rule_LocalNetworkMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Rule_RemoteNetworkMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Rule_RemoteNetworkMT
		IF OBJECT_ID('dbo.FW_Rule_RemoteNetworkMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Rule_RemoteNetworkMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Rule_RemoteNetworkMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Rule_RemoteNetworkMT]
(
	[RuleId]			UNIQUEIDENTIFIER	NOT NULL
,	[NamedNetworkId]	UNIQUEIDENTIFIER	NOT NULL
,	[TenantId]			INT					NOT NULL
,	CONSTRAINT [PK_FW_Rule_RemoteNetwork] PRIMARY KEY CLUSTERED
	(
		[RuleId]			ASC
	,	[NamedNetworkId]	ASC
	,	[TenantId]			ASC
	)
)

ALTER TABLE [dbo].[FW_Rule_RemoteNetworkMT] ADD  CONSTRAINT [DF_FW_Rule_RemoteNetwork_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Rule_RemoteNetworkMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Rule_RemoteNetwork_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Rule_RemoteNetworkMT] CHECK CONSTRAINT [FK_FW_Rule_RemoteNetwork_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_Rule_RemoteNetworkMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Rule_RemoteNetworkMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Rule_RemoteNetworkMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Rule_LocationMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Rule_LocationMT
		IF OBJECT_ID('dbo.FW_Rule_LocationMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Rule_LocationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Rule_LocationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Rule_LocationMT]
(
	[RuleId]		UNIQUEIDENTIFIER	NOT NULL
,	[LocationId]	UNIQUEIDENTIFIER	NOT NULL
,	[TenantId]		INT					NOT NULL
,	CONSTRAINT [PK_FW_Rule_Location] PRIMARY KEY CLUSTERED
	(
		[RuleId]		ASC
	,	[LocationId]	ASC
	)
)

ALTER TABLE [dbo].[FW_Rule_LocationMT] ADD  CONSTRAINT [DF_FW_Rule_Location_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Rule_LocationMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Rule_Location_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Rule_LocationMT] CHECK CONSTRAINT [FK_FW_Rule_Location_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_Rule_LocationMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Rule_LocationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Rule_LocationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Rule_ApplicationMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Rule_ApplicationMT
		IF OBJECT_ID('dbo.FW_Rule_ApplicationMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Rule_ApplicationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Rule_ApplicationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Rule_ApplicationMT]
(
	[RuleId]		UNIQUEIDENTIFIER	NOT NULL
,	[ApplicationId]	UNIQUEIDENTIFIER	NOT NULL
,	[TenantId]		INT					NOT NULL
,	CONSTRAINT [PK_FW_Rule_Application] PRIMARY KEY CLUSTERED
	(
		[RuleId]		ASC
	,	[ApplicationId]	ASC
	,	[TenantId]		ASC
	)
)

ALTER TABLE [dbo].[FW_Rule_ApplicationMT] ADD  CONSTRAINT [DF_FW_Rule_Application_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]
GO

IF OBJECT_ID('dbo.FW_Rule_ApplicationMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Rule_ApplicationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Rule_ApplicationMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


IF OBJECT_ID('dbo.FW_Group_RuleMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_Group_RuleMT
		IF OBJECT_ID('dbo.FW_Group_RuleMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_Group_RuleMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_Group_RuleMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_Group_RuleMT]
(
	[GroupId]		UNIQUEIDENTIFIER	NOT NULL
,	[RuleId]		UNIQUEIDENTIFIER	NOT NULL
,	[ChildIndex]	INT					NOT NULL
,	[TenantId]		INT					NOT NULL
,	CONSTRAINT [PK_FW_Group_Rule] PRIMARY KEY CLUSTERED
	(
		[GroupId]		ASC
	,	[RuleId]		ASC
	,	[ChildIndex]	ASC
	,	[TenantId]		ASC
	)
)

ALTER TABLE [dbo].[FW_Group_RuleMT] ADD  CONSTRAINT [DF_FW_Group_Rule_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_Group_RuleMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_Group_Rule_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_Group_RuleMT] CHECK CONSTRAINT [FK_FW_Group_Rule_OrionTenant]
GO

IF OBJECT_ID('dbo.FW_Group_RuleMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_Group_RuleMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_Group_RuleMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO

-- Add foreign keys
ALTER TABLE [dbo].[FW_ApplicationExecutableMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_ApplicationExecutable_FW_Application] FOREIGN KEY([ApplicationId], [TenantId])
REFERENCES [dbo].[FW_ApplicationMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_ApplicationExecutableMT] CHECK CONSTRAINT [FK_FW_ApplicationExecutable_FW_Application]
GO

ALTER TABLE [dbo].[FW_ApplicationExecutableMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_ApplicationExecutable_FW_Executable] FOREIGN KEY([ExecutableId], [TenantId])
REFERENCES [dbo].[FW_ExecutableMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_ApplicationExecutableMT] CHECK CONSTRAINT [FK_FW_ApplicationExecutable_FW_Executable]
GO

ALTER TABLE [dbo].[FW_NamedNetwork_HostsMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_NamedNetwork_Hosts_FW_NamedNetwork] FOREIGN KEY([NamedNetworkId], [TenantId])
REFERENCES [dbo].[FW_NamedNetworkMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_NamedNetwork_HostsMT] CHECK CONSTRAINT [FK_FW_NamedNetwork_Hosts_FW_NamedNetwork]
GO

ALTER TABLE [dbo].[FW_Location_DnsSuffixMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Location_DnsSuffix_FW_Location] FOREIGN KEY([LocationId], [TenantId])
REFERENCES [dbo].[FW_LocationMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Location_DnsSuffixMT] CHECK CONSTRAINT [FK_FW_Location_DnsSuffix_FW_Location]
GO

ALTER TABLE [dbo].[FW_Location_DomainReachableMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Location_DomainReachable_FW_Location] FOREIGN KEY([LocationId], [TenantId])
REFERENCES [dbo].[FW_LocationMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Location_DomainReachableMT] CHECK CONSTRAINT [FK_FW_Location_DomainReachable_FW_Location]
GO

ALTER TABLE [dbo].[FW_Location_DhcpServerMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Location_DhcpServer_FW_Location] FOREIGN KEY([LocationId], [TenantId])
REFERENCES [dbo].[FW_LocationMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Location_DhcpServerMT] CHECK CONSTRAINT [FK_FW_Location_DhcpServer_FW_Location]
GO

ALTER TABLE [dbo].[FW_Location_DnsServerMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Location_DnsServer_FW_Location] FOREIGN KEY([LocationId], [TenantId])
REFERENCES [dbo].[FW_LocationMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Location_DnsServerMT] CHECK CONSTRAINT [FK_FW_Location_DnsServer_FW_Location]
GO

ALTER TABLE [dbo].[FW_Location_DefaultGatewayMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Location_DefaultGateway_FW_Location] FOREIGN KEY([LocationId], [TenantId])
REFERENCES [dbo].[FW_LocationMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Location_DefaultGatewayMT] CHECK CONSTRAINT [FK_FW_Location_DefaultGateway_FW_Location]
GO

ALTER TABLE [dbo].[FW_Location_PrimaryWinsMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Location_PrimaryWins_FW_Location] FOREIGN KEY([LocationId], [TenantId])
REFERENCES [dbo].[FW_LocationMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Location_PrimaryWinsMT] CHECK CONSTRAINT [FK_FW_Location_PrimaryWins_FW_Location]
GO

ALTER TABLE [dbo].[FW_Location_SecondaryWinsMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Location_SecondaryWins_FW_Location] FOREIGN KEY([LocationId], [TenantId])
REFERENCES [dbo].[FW_LocationMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Location_SecondaryWinsMT] CHECK CONSTRAINT [FK_FW_Location_SecondaryWins_FW_Location]
GO

ALTER TABLE [dbo].[FW_Location_RegKeyMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Location_RegKey_FW_Location] FOREIGN KEY([LocationId], [TenantId])
REFERENCES [dbo].[FW_LocationMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Location_RegKeyMT] CHECK CONSTRAINT [FK_FW_Location_RegKey_FW_Location]
GO

ALTER TABLE [dbo].[FW_Rule_LocalNetworkMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Rule_LocalNetwork_FW_Rule] FOREIGN KEY([RuleId], [TenantId])
REFERENCES [dbo].[FW_RuleMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Rule_LocalNetworkMT] CHECK CONSTRAINT [FK_FW_Rule_LocalNetwork_FW_Rule]
GO

ALTER TABLE [dbo].[FW_Rule_LocalNetworkMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Rule_LocalNetwork_FW_NamedNetwork] FOREIGN KEY([NamedNetworkId], [TenantId])
REFERENCES [dbo].[FW_NamedNetworkMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Rule_LocalNetworkMT] CHECK CONSTRAINT [FK_FW_Rule_LocalNetwork_FW_NamedNetwork]
GO

ALTER TABLE [dbo].[FW_Rule_RemoteNetworkMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Rule_RemoteNetwork_FW_Rule] FOREIGN KEY([RuleId], [TenantId])
REFERENCES [dbo].[FW_RuleMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Rule_RemoteNetworkMT] CHECK CONSTRAINT [FK_FW_Rule_RemoteNetwork_FW_Rule]
GO

ALTER TABLE [dbo].[FW_Rule_RemoteNetworkMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Rule_RemoteNetwork_FW_NamedNetwork] FOREIGN KEY([NamedNetworkId], [TenantId])
REFERENCES [dbo].[FW_NamedNetworkMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Rule_RemoteNetworkMT] CHECK CONSTRAINT [FK_FW_Rule_RemoteNetwork_FW_NamedNetwork]
GO

ALTER TABLE [dbo].[FW_Rule_LocationMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Rule_Location_FW_Rule] FOREIGN KEY([RuleId], [TenantId])
REFERENCES [dbo].[FW_RuleMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Rule_LocationMT] CHECK CONSTRAINT [FK_FW_Rule_Location_FW_Rule]
GO

ALTER TABLE [dbo].[FW_Rule_LocationMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Rule_Location_FW_Location] FOREIGN KEY([LocationId], [TenantId])
REFERENCES [dbo].[FW_LocationMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Rule_LocationMT] CHECK CONSTRAINT [FK_FW_Rule_Location_FW_Location]
GO

ALTER TABLE [dbo].[FW_Rule_NetworkProtocolMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Rule_NetworkProtocol_FW_Rule] FOREIGN KEY([RuleId], [TenantId])
REFERENCES [dbo].[FW_RuleMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Rule_NetworkProtocolMT] CHECK CONSTRAINT [FK_FW_Rule_NetworkProtocol_FW_Rule]
GO

ALTER TABLE [dbo].[FW_Rule_ApplicationMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Rule_Application_FW_Rule] FOREIGN KEY([RuleId], [TenantId])
REFERENCES [dbo].[FW_RuleMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Rule_ApplicationMT] CHECK CONSTRAINT [FK_FW_Rule_Application_FW_Rule]
GO

ALTER TABLE [dbo].[FW_Rule_ApplicationMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Rule_Application_FW_Application] FOREIGN KEY([ApplicationId], [TenantId])
REFERENCES [dbo].[FW_ApplicationMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Rule_ApplicationMT] CHECK CONSTRAINT [FK_FW_Rule_Application_FW_Application]
GO

ALTER TABLE [dbo].[FW_Group_RuleMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Group_FW_Rule] FOREIGN KEY([GroupId], [TenantId])
REFERENCES [dbo].[FW_RuleMT] ([id], [TenantId])
	ON DELETE NO ACTION --Can't cascade both sides; I think this one is slightly less critical.  Hibernate should do the right thing anyway. -mw
GO
ALTER TABLE [dbo].[FW_Group_RuleMT] CHECK CONSTRAINT [FK_FW_Group_FW_Rule]
GO

ALTER TABLE [dbo].[FW_Group_RuleMT]  WITH CHECK ADD
CONSTRAINT [FK_FW_Group_FW_Rule2] FOREIGN KEY([RuleId], [TenantId])
REFERENCES [dbo].[FW_RuleMT] ([id], [TenantId])
	ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FW_Group_RuleMT] CHECK CONSTRAINT [FK_FW_Group_FW_Rule2]
GO

ALTER TABLE [dbo].[FW_RuleMT] ADD
CONSTRAINT [FK_FW_Rule_LeafNode] FOREIGN KEY([leafNodeId])
REFERENCES [dbo].[EPOLeafNode] ([AutoID])
	ON DELETE CASCADE  ON UPDATE CASCADE
GO
ALTER TABLE [dbo].[FW_RuleMT] CHECK CONSTRAINT [FK_FW_Rule_LeafNode]
GO



IF OBJECT_ID('dbo.FW_CustomPropsMT') IS NOT NULL
	BEGIN
		DROP TABLE dbo.FW_CustomPropsMT
		IF OBJECT_ID('dbo.FW_CustomPropsMT') IS NOT NULL
			PRINT '<<< FAILED DROPPING TABLE dbo.FW_CustomPropsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
		ELSE
			PRINT '<<< DROPPED TABLE dbo.FW_CustomPropsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
	END
GO

CREATE TABLE [dbo].[FW_CustomPropsMT]
(
	[AutoID]                        INT					NOT NULL	IDENTITY (1,1)
,	[AutoIDSP]						UNIQUEIDENTIFIER	NULL		CONSTRAINT DF_FW_CustomProperties_AutoIDSP	DEFAULT	(NEWSEQUENTIALID())
,	[ParentID]						INT					NOT NULL             -- Required for custom properties
,   [ComplianceStatus]				bit 				NOT NULL	CONSTRAINT DF_FW_CustomProperties_bComplianceStatus DEFAULT ((0))
,   [ComplianceReason]              INT         		NULL
,   [AdditionalComplianceReason]    [nvarchar](256)		NULL
,	[FWStatus]						bit         		NULL
,	[FWAdaptiveModeStatus]			bit         		NULL
,	[FWFault]				        bit         		NULL
,	[FWMode]				        INT         		NULL
,	[Hotfix]				        [nvarchar](128)		NULL
,	[Language]				        [nvarchar](128)		NULL
,	[LastPolicyEnforcement]		    [nvarchar](128) 	NULL
,	[LicenseStatus]				    bit         		NULL
,	[Patch]				            [nvarchar](128)		NULL
,	[PolicyNameClientUI]			[nvarchar](128)		NULL
,	[PolicyNameFwOptions]			[nvarchar](128)		NULL
,	[PolicyNameFwRules]				[nvarchar](128)		NULL
,	[PolicyNameTrustedAppList]		[nvarchar](128)		NULL
,	[PolicyNameTrustedNetworks]		[nvarchar](128)		NULL
,	[ProductVersion]				[nvarchar](128)		NULL
,	[RebootRequired]				bit         		NULL
,	[ServiceRunning]				bit         		NULL
,	[InstallDir32]					[nvarchar](128)		NULL
,	[InstallDir64]					[nvarchar](128)		NULL
,	[ProductVer]				    [nvarchar](128)		NULL
,	[TenantId]						INT					NOT NULL
,	CONSTRAINT	[PK_FW_CustomProps] PRIMARY KEY CLUSTERED
(
	[AutoID]	ASC
,	[TenantId]	ASC
) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO

ALTER TABLE [dbo].[FW_CustomPropsMT] ADD  CONSTRAINT [DF_FW_CustomProps_TenantId_NOTNULL]  DEFAULT ([dbo].[FN_Core_GetContextTenantId]()) FOR [TenantId]

ALTER TABLE [dbo].[FW_CustomPropsMT]  WITH CHECK ADD  CONSTRAINT [FK_FW_CustomProps_OrionTenant] FOREIGN KEY([TenantId])
REFERENCES [dbo].[OrionTenant] ([TenantId])
	ON DELETE CASCADE

ALTER TABLE [dbo].[FW_CustomPropsMT] CHECK CONSTRAINT [FK_FW_CustomProps_OrionTenant]
GO

CREATE UNIQUE NONCLUSTERED INDEX IX_FW_CustomPropsMT_ParentID ON [dbo].[FW_CustomPropsMT]([ParentId])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FW_CustomProps_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[FW_CustomProps]'))
BEGIN
ALTER TABLE [dbo].[FW_CustomPropsMT] ADD
	CONSTRAINT [FK_FW_CustomProps_EPOProductProperties] FOREIGN KEY (
		[ParentID]
	) REFERENCES [dbo].[EPOProductProperties] (
		[AutoID]
	) ON DELETE CASCADE ON UPDATE NO ACTION
END
GO

IF OBJECT_ID('dbo.FW_CustomPropsMT') IS NOT NULL
	PRINT '<<< CREATED TABLE dbo.FW_CustomPropsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE dbo.FW_CustomPropsMT ' + CONVERT(VARCHAR(100), GETDATE()) + ' >>>'
GO


-- Add Filtered Views and Triggers to MT tables

--FW_Application
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Application', 'Y'
GO

--FW_Executable
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Executable', 'Y'
GO

--FW_ApplicationExecutable
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_ApplicationExecutable', 'Y'
GO

--FW_Rule
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Rule' , 'Y'
GO

--FW_Group_Rule
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Group_Rule' , 'Y'
GO

--FW_Location
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location' , 'Y'
GO

--FW_NamedNetwork
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_NamedNetwork' , 'Y'
GO

--FW_Rule_Application
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Rule_Application' , 'Y'
GO

--FW_Rule_LocalNetwork
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Rule_LocalNetwork', 'Y'
GO

--FW_Rule_Location
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Rule_Location', 'Y'
GO

--FW_ServiceName
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_ServiceName', 'Y'
GO

--FW_Location_DefaultGateway
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_DefaultGateway' , 'Y'
GO

--FW_Location_DhcpServer
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_DhcpServer' , 'Y'
GO

--FW_Location_DnsServer
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_DnsServer' , 'Y'
GO

--FW_Location_DnsSuffix
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_DnsSuffix' , 'Y'
GO

--FW_Location_DomainReachable
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_DomainReachable' , 'Y'
GO

--FW_Location_PrimaryWins
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_PrimaryWins' , 'Y'
GO

--FW_Location_RegKey
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_RegKey' , 'Y'
GO

--FW_Location_SecondaryWins
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Location_SecondaryWins' , 'Y'
GO

--FW_NamedNetwork_Hosts
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_NamedNetwork_Hosts' , 'Y'
GO

--FW_Rule_NetworkProtocol
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Rule_NetworkProtocol' , 'Y'
GO

--FW_Rule_RemoteNetwork
EXEC [FWSP_CONVERT_TABLE_TO_FILTERED_VIEW] 'FW_Rule_RemoteNetwork' , 'Y'
GO

--FW_CustomProps
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FW_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[FW_CustomProps]
GO

CREATE VIEW [dbo].[FW_CustomProps] AS
    SELECT [FW_CustomPropsMT].*, [EPOProdPropsView_FIREWALL].[LeafNodeID]
    FROM [FW_CustomPropsMT]
    INNER JOIN [EPOProdPropsView_FIREWALL] ON [EPOProdPropsView_FIREWALL].[ProductPropertiesID] = [FW_CustomPropsMT].[ParentID]
        WHERE TenantId = 0
        OR TenantId = (select tid from FWFN_GetTenancyInfoTable())
GO

/*** Add Indexes for Performance  ***/
/*** Add Indexes for Performance  ***/

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[FW_ApplicationExecutableMT]') AND name = N'IX_FW_ApplicationExecutableMT_ApplicationId')
  BEGIN
    CREATE INDEX [IX_FW_ApplicationExecutableMT_ApplicationId] ON [dbo].[FW_ApplicationExecutableMT]
    ([ApplicationId])
    INCLUDE ([ExecutableId], [TenantId])
  END
GO

-- IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[FW_RuleMT]') AND name = N'IX_FW_RuleMT_name')
--   BEGIN
--     CREATE INDEX [IX_FW_RuleMT_name] ON [dbo].[FW_RuleMT]
--     ([name])
--     INCLUDE ([TenantId])
--   END
-- Go

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[FW_RuleMT]') AND name = N'IX_FW_RuleMT_DTYPE_TenantId')
  BEGIN
    CREATE INDEX [IX_FW_RuleMT_DTYPE_TenantId] ON [dbo].[FW_RuleMT]
    ([DTYPE], [TenantId])
    INCLUDE ([id], [version], [lastModifyingUsername], [lastModified], [name], [note], [enabled], [action], [direction], [mediaFlags], [tcpFlagsFlags], [transportProtocol], [localServiceList], [remoteServiceList], [intrusion], [trafficLogged], [schedule_start], [schedule_end], [schedule_offHours], [schedule_weekMask], [schedule_clickTimeout])
  END
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[FW_Group_RuleMT]') AND name = N'IX_FW_Group_RuleMT_RuleId')
  BEGIN
    CREATE INDEX [IX_FW_Group_RuleMT_RuleId] ON [dbo].[FW_Group_RuleMT]
    ([RuleId])
    INCLUDE ([GroupId], [TenantId])
  END
GO



