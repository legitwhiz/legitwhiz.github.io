-- upgrade-to-10.5.2.sql --

-- update [FW_CustomProps] view:  performance, join to EPOProductProperties rather than EPOProdPropView --
alter view [dbo].[FW_CustomProps] as
    select fw.*, pp.[ParentID] [LeafNodeID], pp.[ProductCode]
    from [FW_CustomPropsMT] fw
        inner join [EPOProductProperties_Fast] pp on fw.[ParentID] = pp.[AutoID]
    where fw.[TenantID] = convert(int, substring(CONTEXT_INFO(), 5, 4))
go

-- correct view permissions --
revoke select,insert,update,delete,references on [dbo].[FW_CustomProps] to [mcafeeSystem]
grant select,insert,update,delete on [dbo].[FW_CustomProps] to [mcafeeOps]
grant select,insert,update,delete on [dbo].[FW_CustomProps] to [mcafeeTenant]
go

-- update tech status: use new FW_CustomProps def, and make it read only
alter view [dbo].[FW_EndpointTechnologyStatus_View] as
    select pp.[AutoIDSP] [AutoID], pp.[LeafNodeID], 6 [TechnologyType], pp.[FWStatus] [Enabled], pp.[ProductCode]
    from [FW_CustomProps] pp with(nolock)
go

-- correct view permissions --
revoke select,insert,update,delete,references on [dbo].[FW_EndpointTechnologyStatus_View] to [mcafeeSystem]
grant select on [dbo].[FW_EndpointTechnologyStatus_View] to [mcafeeOps]
grant select on [dbo].[FW_EndpointTechnologyStatus_View] to [mcafeeTenant]
go

-- update tech status: use new FW_CustomProps def, and make it read only
alter view [dbo].[FWBladeTechView] as
    select pp.[AutoIDSP] [AutoID], pp.[LeafNodeID], 6 [TechnologyType], pp.[FWStatus] [Enabled], pp.[ProductCode]
    from [FW_CustomProps] pp with(nolock)
go

revoke select,insert,update,delete,references on [dbo].[FWBladeTechView] to [mcafeeSystem]
grant select on [dbo].[FWBladeTechView] to [mcafeeOps]
grant select on [dbo].[FWBladeTechView] to [mcafeeTenant]
go

-- rebuild the Tech Status view
exec [dbo].[GSRebuildTechnologyStatus_View]
go

-- remove unwanted indexes

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_FW_Rule_NetworkProtocol_RuleID' -- Index Name
		AND so.[Name] = N'FW_Rule_NetworkProtocolMT')
		DROP INDEX [IX_FW_Rule_NetworkProtocol_RuleID] ON dbo.[FW_Rule_NetworkProtocolMT];
GO

IF EXISTS(SELECT 1 FROM sysindexes si INNER JOIN sysobjects so ON so.id = si.id WHERE si.[Name] = N'IX_FW_RuleMT_name' -- Index Name
		AND so.[Name] = N'FW_RuleMT')
	DROP INDEX IX_FW_RuleMT_name ON FW_RuleMT;
GO

