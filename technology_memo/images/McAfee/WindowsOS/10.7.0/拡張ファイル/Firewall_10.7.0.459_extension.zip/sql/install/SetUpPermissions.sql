DECLARE	@multiTenant int;
SELECT	@multiTenant = ##MultiTenantMode##;
IF @multiTenant = 1
BEGIN
	-----------------
	-- install.sql
	-----------------

	-- the SQL scripts in this file create 3 tables containing the names for:
	--   1. tables
	--   2. views
	--   3. stored procedures
	-- these tables are used to grant permissions to multi-tenant roles for all
	--   ePO tables, views and stored procedures
	-- NOTE: these SQL scripts are ONLY executed in multi-tenant mode

	------------
	-- tables
	------------
	-- GrantSelect, GrantUpdate, GrantInsert & GrantDelete grant SELECT, UPDATE, INSERT & DELETE permissions
	--  respectively for each role (mcafeeTenant, mcafeeOps & mcafeeSystem) as follows:
	--
	--            Grant_______    mcafeeTenant    mcafeeOps         mcafeeSystem
	--              0
	--              1                                                                                                                                                                   X
	--              2                                 X
	--              3                                 X                    X
	--              4                   X                                                                                                                                                                                                                                                                                                                                                                                                                                                                S    U    I    D
	--              5                   X                                  X                                                                                                                                                                                                                                                                                                                                                       E    P    N    E
	--              6                   X              X                                                                                                                                                                                                                                                                                                                                                                                                    L    D    S    L
	--              7                   X              X                   X                                                                                                                                                                                                                                                                                                                                                       E    A    E    E
	--                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         C    T    R    T
	-- one row for each FW table                                                                                                                                                                                                                                                                     TABLE NAME                                                                                                                              T    E    T    E
	--                                                                                                                                                                                                                                                                                                                                                                                    ------------------------------------------------------------
	IF EXISTS (SELECT 1 FROM sysobjects where name = 'FWCloudPermTables' AND type = 'u')
	  BEGIN
		 DROP TABLE FWCloudPermTables
	  END

	CREATE TABLE [dbo].[FWCloudPermTables]
	(
		[AutoID] INT IDENTITY(1,1) NOT NULL,
		[TableName] [nvarchar](100) NOT NULL,
		[GrantSelect] [int] NOT NULL,
		[GrantUpdate] [int] NOT NULL,
		[GrantInsert] [int] NOT NULL,
		[GrantDelete] [int] NOT NULL,
		CONSTRAINT [PK_FWCloudPermTables]	PRIMARY KEY
			(
				[AutoID]
			)
	)


	INSERT INTO FWCloudPermTables
	Select name , 7,   7,   7,   7
	from sysobjects
	where type = 'u'
	and (name like 'FW_%')
	order by name


	-- loop through table, granting role permissions to each table
	DECLARE @name VARCHAR(200)
	DECLARE @select INT
	DECLARE @update INT
	DECLARE @insert INT
	DECLARE @delete INT
	DECLARE @idx CURSOR
	SET @idx = CURSOR FOR SELECT TableName,GrantSelect,GrantUpdate,GrantInsert,GrantDelete FROM [dbo].[FWCloudPermTables]
	OPEN @idx
	FETCH NEXT FROM @idx INTO @name,@select,@update,@insert,@delete
	WHILE @@FETCH_STATUS = 0
	BEGIN
				   IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @name)
				   BEGIN
								  IF (@select = 1) OR (@select = 3) OR (@select = 5) OR (@select = 7)
												 EXEC ('GRANT SELECT ON [dbo].['+ @name +'] TO mcafeeSystem')
								  IF (@select = 2) OR (@select = 3) OR (@select = 6) OR (@select = 7)
												 EXEC ('GRANT SELECT ON [dbo].['+ @name +'] TO mcafeeOps')
								  IF (@select = 4) OR (@select = 5) OR (@select = 6) OR (@select = 7)
												 EXEC ('GRANT SELECT ON [dbo].['+ @name +'] TO mcafeeTenant')

								  IF (@update = 1) OR (@update = 3) OR (@update = 5) OR (@update = 7)
												 EXEC ('GRANT UPDATE ON [dbo].['+ @name +'] TO mcafeeSystem')
								  IF (@update = 2) OR (@update = 3) OR (@update = 6) OR (@update = 7)
												 EXEC ('GRANT UPDATE ON [dbo].['+ @name +'] TO mcafeeOps')
								  IF (@update = 4) OR (@update = 5) OR (@update = 6) OR (@update = 7)
												 EXEC ('GRANT UPDATE ON [dbo].['+ @name +'] TO mcafeeTenant')

								  IF (@insert = 1) OR (@insert = 3) OR (@insert = 5) OR (@insert = 7)
												 EXEC ('GRANT INSERT ON [dbo].['+ @name +'] TO mcafeeSystem')
								  IF (@insert = 2) OR (@insert = 3) OR (@insert = 6) OR (@insert = 7)
												 EXEC ('GRANT INSERT ON [dbo].['+ @name +'] TO mcafeeOps')
								  IF (@insert = 4) OR (@insert = 5) OR (@insert = 6) OR (@insert = 7)
												 EXEC ('GRANT INSERT ON [dbo].['+ @name +'] TO mcafeeTenant')

								  IF (@delete = 1) OR (@delete = 3) OR (@delete = 5) OR (@delete = 7)
												 EXEC ('GRANT DELETE ON [dbo].['+ @name +'] TO mcafeeSystem')
								  IF (@delete = 2) OR (@delete = 3) OR (@delete = 6) OR (@delete = 7)
												 EXEC ('GRANT DELETE ON [dbo].['+ @name +'] TO mcafeeOps')
								  IF (@delete = 4) OR (@delete = 5) OR (@delete = 6) OR (@delete = 7)
												 EXEC ('GRANT DELETE ON [dbo].['+ @name +'] TO mcafeeTenant')
				   END
				   ELSE
								  PRINT 'Table, ' + @name + ', is not in the database.'

				   FETCH NEXT FROM @idx INTO @name,@select,@update,@insert,@delete
	END
	CLOSE @idx
	DEALLOCATE @idx

	IF EXISTS (SELECT 1 FROM sysobjects where name = 'FWCloudPermTables' AND type = 'u')
	  BEGIN
		 DROP TABLE FWCloudPermTables
	  END
	-----------
	-- views
	-----------
	IF EXISTS (SELECT 1 FROM sysobjects where name = 'FWCloudPermViews' AND type = 'u')
	  BEGIN
		 DROP TABLE FWCloudPermViews
	  END

	-- create table for ePO view names and role permissions
	CREATE TABLE [dbo].[FWCloudPermViews]
	(
		[AutoID] INT IDENTITY(1,1) NOT NULL,
		[ViewName] [nvarchar](100) NOT NULL,
		[GrantSelect] [int] NOT NULL,
		[GrantUpdate] [int] NOT NULL,
		[GrantInsert] [int] NOT NULL,
		[GrantDelete] [int] NOT NULL,
		CONSTRAINT [PK_FWCloudPermViews]	PRIMARY KEY
			(
				[AutoID]
			)
	)


	INSERT INTO FWCloudPermViews
	Select name , 7,   7,   7,   7
	from sysobjects
	where type = 'v'
	and (name like 'FW%' or name = 'FW_EndpointTechnologyStatus_View')
	order by name



	-- GrantSelect, GrantUpdate, GrantInsert & GrantDelete grant SELECT, UPDATE, INSERT & DELETE permissions
	--  respectively for each role (mcafeeTenant, mcafeeOps & mcafeeSystem) as follows:
	--
	--            Grant_______    mcafeeTenant    mcafeeOps         mcafeeSystem
	--                0
	--                1                                                                                                                                                                   X
	--                2                                                                                                                      X
	--                3                                                                                                                      X                                           X
	--                4                                                          X                                                                                                                                                                                                                                                                                                                                                                                                                                                 S    U    I    D
	--                5                                                          X                                                                                                       X                                                                                                                                                                                                                                                                                                                                        E    P    N    E
	--                6                                                          X                                                          X                                                                                                                                                                                                                                                                                                                                                                                     L    D    S    L
	--                7                                                          X                                                          X                                           X                                                                                                                                                                                                                                                                                                                                        E    A    E    E
	--                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          C    T    R    T
	-- one row for each ePO view                                                                                                                                                                                                                                                       VIEW NAME                                                                                                                                T    E    T    E
	--                                                                                                                                                                                                                                                                                                                                                                     ------------------------------------------------------------

	-- loop through table, granting role permissions to each view


	SET @idx = CURSOR FOR SELECT ViewName,GrantSelect,GrantUpdate,GrantInsert,GrantDelete FROM [dbo].[FWCloudPermViews]
	OPEN @idx
	FETCH NEXT FROM @idx INTO @name,@select,@update,@insert,@delete
	WHILE @@FETCH_STATUS = 0
	BEGIN
				   IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = @name)
				   BEGIN
								  IF (@select = 1) OR (@select = 3) OR (@select = 5) OR (@select = 7)
												 EXEC ('GRANT SELECT ON [dbo].['+ @name +'] TO mcafeeSystem')
								  IF (@select = 2) OR (@select = 3) OR (@select = 6) OR (@select = 7)
												 EXEC ('GRANT SELECT ON [dbo].['+ @name +'] TO mcafeeOps')
								  IF (@select = 4) OR (@select = 5) OR (@select = 6) OR (@select = 7)
												 EXEC ('GRANT SELECT ON [dbo].['+ @name +'] TO mcafeeTenant')

								  IF (@update = 1) OR (@update = 3) OR (@update = 5) OR (@update = 7)
												 EXEC ('GRANT UPDATE ON [dbo].['+ @name +'] TO mcafeeSystem')
								  IF (@update = 2) OR (@update = 3) OR (@update = 6) OR (@update = 7)
												 EXEC ('GRANT UPDATE ON [dbo].['+ @name +'] TO mcafeeOps')
								  IF (@update = 4) OR (@update = 5) OR (@update = 6) OR (@update = 7)
												 EXEC ('GRANT UPDATE ON [dbo].['+ @name +'] TO mcafeeTenant')

								  IF (@insert = 1) OR (@insert = 3) OR (@insert = 5) OR (@insert = 7)
												 EXEC ('GRANT INSERT ON [dbo].['+ @name +'] TO mcafeeSystem')
								  IF (@insert = 2) OR (@insert = 3) OR (@insert = 6) OR (@insert = 7)
												 EXEC ('GRANT INSERT ON [dbo].['+ @name +'] TO mcafeeOps')
								  IF (@insert = 4) OR (@insert = 5) OR (@insert = 6) OR (@insert = 7)
												 EXEC ('GRANT INSERT ON [dbo].['+ @name +'] TO mcafeeTenant')

								  IF (@delete = 1) OR (@delete = 3) OR (@delete = 5) OR (@delete = 7)
												 EXEC ('GRANT DELETE ON [dbo].['+ @name +'] TO mcafeeSystem')
								  IF (@delete = 2) OR (@delete = 3) OR (@delete = 6) OR (@delete = 7)
												 EXEC ('GRANT DELETE ON [dbo].['+ @name +'] TO mcafeeOps')
								  IF (@delete = 4) OR (@delete = 5) OR (@delete = 6) OR (@delete = 7)
												 EXEC ('GRANT DELETE ON [dbo].['+ @name +'] TO mcafeeTenant')
				   END
				   ELSE
								  PRINT 'View, ' + @name + ', is not in the database.'

				   FETCH NEXT FROM @idx INTO @name,@select,@update,@insert,@delete
	END
	CLOSE @idx
	DEALLOCATE @idx

	IF EXISTS (SELECT 1 FROM sysobjects where name = 'FWCloudPermViews' AND type = 'u')
	  BEGIN
		 DROP TABLE FWCloudPermViews
	  END

	-----------------------
	-- stored procedures
	-----------------------
	IF EXISTS (SELECT 1 FROM sysobjects where name = 'FWCloudPermProcs' AND type = 'u')
	  BEGIN
		 DROP TABLE FWCloudPermProcs
	  END

	-- create table for ePO stored procedure names and role permissions
	CREATE TABLE [dbo].[FWCloudPermProcs]
	(
		[AutoID] INT IDENTITY(1,1) NOT NULL,
		[ProcName] [nvarchar](100) NOT NULL,
		[GrantExecute] [int] NOT NULL,
		CONSTRAINT [PK_FWCloudPermProcs]	PRIMARY KEY
			(
				[AutoID]
			)
	)


	INSERT INTO FWCloudPermProcs
	Select name , 7
	from sysobjects
	where type = 'p'
	and (name like 'FW%')
	order by name

	-- GrantExecute grants EXECUTE permission for each role (mcafeeTenant, mcafeeOps & mcafeeSystem) as follows:
	--
	--            GrantExecute     mcafeeTenant    mcafeeOps         mcafeeSystem
	--                           0
	--                           1                                                                                                                                                                   X
	--                           2                                                                                                                      X
	--                           3                                                                                                                      X                                           X                                                                                                                                                                                                                                                                            E
	--                           4                                                          X                                                                                                                                                                                                                                                                                                                                                                                     X
	--                           5                                                          X                                                                                                       X                                                                                                                                                                                                                                                                            E
	--                           6                                                          X                                                          X                                                                                                                                                                                                                                                                                                                         C
	--                           7                                                          X                                                          X                                           X                                                                                                                                                                                                                                                                            U
	--                                                                                                                                                                                                                                                                                                                                                                                                                                                                              T
	-- one row for each ePO stored procedure                                                                                         STORED PROCEDURE NAME                                                                                                                                                 E
	--                                                                                                                                                                                                                                             -------------------------------------------------------------

	-- loop through table, granting role permissions to each stored procedure

	DECLARE @execute INT

	SET @idx = CURSOR FOR SELECT ProcName,GrantExecute FROM [dbo].[FWCloudPermProcs]
	OPEN @idx
	FETCH NEXT FROM @idx INTO @name,@execute
	WHILE @@FETCH_STATUS = 0
	BEGIN
				   IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE SPECIFIC_NAME = @name)
				   BEGIN
								  IF (@execute = 1) OR (@execute = 3) OR (@execute = 5) OR (@execute = 7)
												 EXEC ('GRANT EXECUTE ON [dbo].['+ @name +'] TO mcafeeSystem')
								  IF (@execute = 2) OR (@execute = 3) OR (@execute = 6) OR (@execute = 7)
												 EXEC ('GRANT EXECUTE ON [dbo].['+ @name +'] TO mcafeeOps')
								  IF (@execute = 4) OR (@execute = 5) OR (@execute = 6) OR (@execute = 7)
												 EXEC ('GRANT EXECUTE ON [dbo].['+ @name +'] TO mcafeeTenant')
				   END
				   ELSE
								  PRINT 'Stored procedure, ' + @name + ', is not in the database.'

				   FETCH NEXT FROM @idx INTO @name,@execute
	END
	CLOSE @idx
	DEALLOCATE @idx


	IF EXISTS (SELECT 1 FROM sysobjects where name = 'FWCloudPermProcs' AND type = 'u')
	  BEGIN
		 DROP TABLE FWCloudPermProcs
	  END
END
GO





