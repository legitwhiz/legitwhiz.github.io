
-- FW_GetPolicySettingValues --
if exists(select 1 from sys.objects where [object_id] = OBJECT_ID(N'[dbo].[FW_GetPolicySettingValues]') and [type] = N'P')
	drop procedure [dbo].[FW_GetPolicySettingValues]
go

create procedure [dbo].[FW_GetPolicySettingValues]
(
	@feature nvarchar(128),
	@category nvarchar(128),
	@searchSectionName nvarchar(128),
	@searchSettingName nvarchar(128),
	@searchSettingValue nvarchar(3072),
	@returnSectionName nvarchar(128),
	@returnSettingName nvarchar(128)
)
as
begin
	set nocount on;

	select distinct v2.[SettingValue]
		from [EPOPolicyTypes] t
			inner join [EPOPolicyObjects_Fast] p on t.[TypeID] = p.[TypeID]
			inner join [EPOPolicyObjectToSettings] o2s on p.[PolicyObjectID] = o2s.[PolicyObjectID]
			inner join [EPOPolicySettingValues] v on o2s.[PolicySettingsID] = v.[PolicySettingsID]
			inner join [EPOPolicySettingValues] v2 on v.[PolicySettingsID] = v2.[PolicySettingsID]
       where t.[FeatureTextID] = @feature
              and t.[CategoryTextID] = @category
              and v.[SectionName] = @searchSectionName
              and v.[SettingName] = @searchSettingName
              and v.[SettingValue] = @searchSettingValue
              and v2.[SectionName] = @returnSectionName
              and v2.[SettingName] = @returnSettingName
              and (p.[EditFlags] & 1) = 0
end
go

-- FW_FindPoliciesLike --
if exists(select 1 from sys.objects where [object_id] = OBJECT_ID(N'[dbo].[FW_FindPoliciesLike]') and [type] = N'P')
	drop procedure [dbo].[FW_FindPoliciesLike]
go

create procedure [dbo].[FW_FindPoliciesLike]
(
	@feature nvarchar(128),
	@category nvarchar(128),
	@searchSectionName nvarchar(128),
	@searchSettingName nvarchar(128),
	@searchSettingValues nvarchar(4000),
	@returnSectionName nvarchar(128),
	@returnSettingName nvarchar(128),
	@delim nchar(1) = N','
)
as
begin
	set nocount on;

	declare @values table([value] nvarchar(3072) not null)
	declare @len int = len(@searchSettingValues), @start int = 1, @i int

	-- parse the values
	while(@start < @len)
	begin
		set @i = charindex(@delim, @searchSettingValues, @start)
		set @i = case @i when 0 then @len + 1 else @i end
		insert into @values([value])
			select ltrim(rtrim(substring(@searchSettingValues, @start, @i - @start)))
		set @start = @i + 1
	end

	select distinct p.[PolicyObjectID],
			(select v2.[SettingValue]
				from [EPOPolicySettingValues] v2
				where v2.[PolicySettingsID] = v.[PolicySettingsID]
					and v2.[SectionName] = @returnSectionName
					and v2.[SettingName] = @returnSettingName
			) [SettingValue]
       from [EPOPolicyTypes] t
              inner join [EPOPolicyObjects_Fast] p on t.[TypeID] = p.[TypeID]
              inner join [EPOPolicyObjectToSettings] o2s on p.[PolicyObjectID] = o2s.[PolicyObjectID]
              inner join [EPOPolicySettingValues] v on o2s.[PolicySettingsID] = v.[PolicySettingsID]
			  inner join @values sv on v.[SettingValue] = sv.[value]
       where t.[FeatureTextID] = @feature
              and t.[CategoryTextID] = @category
              and v.[SectionName] = @searchSectionName
              and v.[SettingName] like @searchSettingName
              and (p.[EditFlags] & 1) = 0
end
go

---- Grant execute permission ----
-- FW_GetPolicySettingValues --
grant execute on [dbo].[FW_GetPolicySettingValues] to [mcafeeOps];
grant execute on [dbo].[FW_GetPolicySettingValues] to [mcafeeTenant];
-- FW_FindPoliciesLike --
grant execute on [dbo].[FW_FindPoliciesLike] to [mcafeeOps];
grant execute on [dbo].[FW_FindPoliciesLike] to [mcafeeTenant];
