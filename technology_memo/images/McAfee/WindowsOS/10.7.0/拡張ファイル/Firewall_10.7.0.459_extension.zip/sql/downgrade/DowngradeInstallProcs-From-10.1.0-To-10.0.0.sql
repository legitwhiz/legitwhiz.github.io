if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FWSP_CONVERT_TABLE_TO_VIEW]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
  BEGIN
    DROP PROCEDURE FWSP_CONVERT_TABLE_TO_VIEW
  END
GO

