
--FW_CustomProps
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FW_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[FW_CustomProps]
GO

CREATE VIEW [dbo].[FW_CustomProps] AS
    SELECT [FW_CustomPropsMT].*, [EPOProdPropsView_FIREWALL].[LeafNodeID]
    FROM [FW_CustomPropsMT]
    INNER JOIN [EPOProdPropsView_FIREWALL] ON [EPOProdPropsView_FIREWALL].[ProductPropertiesID] = [FW_CustomPropsMT].[ParentID]
GO


-- Add Views to MT tables

-- GSE extension upgrades all Tech Status views.
-- Make sure to update GSE extension if there are any changes to this view
IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_EndpointTechnologyStatus_View]') AND OBJECTPROPERTY(id, N'IsView') = 1)
BEGIN
	DROP VIEW	[dbo].[FW_EndpointTechnologyStatus_View]
END
GO

CREATE VIEW	[dbo].[FW_EndpointTechnologyStatus_View]
AS
SELECT
	fw.[AutoIDSP]	AS AutoID
,	pp.[LeafNodeID]	AS LeafNodeID
,	6				AS TechnologyType
,	fw.[FWStatus]	AS Enabled
,	pp.[ProductCode]
FROM	[FW_CustomProps]	fw
LEFT JOIN	[EPOProdPropsView_FIREWALL]	pp	ON	pp.[ProductPropertiesID] = fw.[ParentID]
GO

IF EXISTS	(SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FW_ClientRuleExecutableView]'))
BEGIN
	DROP VIEW	[dbo].[FW_ClientRuleExecutableView]
END
GO

CREATE VIEW [dbo].[FW_ClientRuleExecutableView]
AS
SELECT TOP 10000
	r.id				AS RuleId
,	r.name				AS RuleName
,	ra.ApplicationId	AS AppId
,	e.id				AS ExeId
,	e.name				AS ExeName
,	e.note				AS ExeNote
,	e.filename			AS ExeFilename
,	e.fingerprint		AS ExeFingerprint
,	e.signerName		AS ExeSignername
FROM	FW_Rule						r
JOIN	FW_Rule_Application			ra	ON r.id				= ra.RuleId
JOIN	FW_ApplicationExecutable	ae	ON ra.ApplicationId = ae.ApplicationId
JOIN	FW_Executable				e	ON ae.ExecutableId	= e.id
WHERE
	r.leafNodeId	IS NOT NULL
GO
-----------------------------------------------------------------
