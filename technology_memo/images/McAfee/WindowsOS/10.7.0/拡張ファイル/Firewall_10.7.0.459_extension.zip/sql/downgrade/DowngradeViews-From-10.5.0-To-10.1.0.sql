IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FWBladeTechView]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[FWBladeTechView]
  END
GO
