IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FWBladeTechView]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[FWBladeTechView]
  END
GO

CREATE VIEW [dbo].[FWBladeTechView] AS
  SELECT [cp].[AutoIDSP] AS AutoID, [ppv].[LeafNodeID], 6 AS TechnologyType, [cp].[FWStatus] AS Enabled, [ppv].[ProductCode]
  FROM  [FW_CustomProps] AS [cp]
    LEFT JOIN [EPOProdPropsView_FIREWALL] AS [ppv]
      ON [ppv].[ProductPropertiesID] = [cp].[ParentID]
GO