------------------------------------------------------------------
--Copyright (c) 2018 McAfee LLC - All Rights Reserved
------------------------------------------------------------------
-- insert 10.7.0 product technology data
if not exists(select [ProductCode] from [EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_WP_1070')
begin
	INSERT INTO [dbo].[EAMP.GSE.Blades]
	  ([ProductCode],
	  [DispName],
	  [TechnologyCount])
	  VALUES (
	  N'ENDP_WP_1070',
	  N'Endpoint Security Web Control',
	  1
	)
end
GO