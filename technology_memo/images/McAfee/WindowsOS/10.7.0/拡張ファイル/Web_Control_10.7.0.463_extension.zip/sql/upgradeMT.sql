
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[WP_CustomProps]
GO

CREATE VIEW [dbo].[WP_CustomProps] AS
    select wp.*, ppv.[LeafNodeID]
        from [WP_CustomPropsMT] wp
            inner join [EPOProdPropsView_WEBCONTROL] ppv on wp.[ParentID] = ppv.[ProductPropertiesID]
        where wp.[TenantId] = convert(int, substring(CONTEXT_INFO(), 5, 4))
GO

EXEC EPOCore_AddInsertTriggerToMTTable 'WP_CustomProps'
EXEC EPOCore_AddUpdateTriggerToMTTable 'WP_CustomProps'
EXEC EPOCore_AddDeleteTriggerToMTTable 'WP_CustomProps'
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[WP_CustomProps] TO mcafeeTenant
GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[WP_CustomProps] TO mcafeeSystem
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_EventInfo]') and OBJECTPROPERTY(id, N'IsView') = 1)
    DROP VIEW [dbo].[WP_EventInfo]
GO

CREATE VIEW [dbo].[WP_EventInfo] AS
    select wp.* from [WP_EventInfoMT] wp
    where wp.[TenantId] = convert(int, substring(CONTEXT_INFO(), 5, 4))

GO

EXEC EPOCore_AddInsertTriggerToMTTable 'WP_EventInfo'
EXEC EPOCore_AddUpdateTriggerToMTTable 'WP_EventInfo'
EXEC EPOCore_AddDeleteTriggerToMTTable 'WP_EventInfo'
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[WP_EventInfo] TO mcafeeTenant
GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[WP_EventInfo] TO mcafeeSystem
GO
