DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE ProductCode='ENDP_WP_1020'

INSERT INTO [dbo].[EAMP.GSE.Blades]
  ([ProductCode],
  [DispName],
  [TechnologyCount])
  VALUES (
  'ENDP_WP_1010',
  'Endpoint Security Web Control',
  1
)
GO