------------------------------------------------------------------
--Copyright (c) 2014 McAfee Inc. - All Rights Reserved
------------------------------------------------------------------
--FOR MULTI-TENANT ONLY

--WP_EventInfoMT
GRANT DELETE ON [dbo].[WP_EventInfoMT] TO mcafeeOps
GO

GRANT SELECT,UPDATE,INSERT,DELETE ON [dbo].[WP_EventInfoMT] TO mcafeeSystem
GO

--temporary workaround for event insertion bug in EPO #913667
GRANT INSERT ON [dbo].[WP_EventInfoMT] To mcafeeTenant
GO

--WP_EventInfo
GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[WP_EventInfo] TO mcafeeTenant
GO

GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[WP_EventInfo] TO mcafeeSystem
GO

--WP_CustomPropsMT
GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[WP_CustomPropsMT] TO mcafeeSystem
GO

GRANT DELETE ON [dbo].[WP_CustomPropsMT] To mcafeeOps
GO

--WP_CustomProps
GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[WP_CustomProps] TO mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[WP_CustomProps] TO mcafeeOps
GO

--WP_EndpointTechnologyStatus_View
GRANT SELECT ON [dbo].[WP_EndpointTechnologyStatus_View] TO mcafeeTenant
GRANT SELECT ON [dbo].[WP_EndpointTechnologyStatus_View] TO mcafeeOps
GO


--WP_ContentRiskGroups
GRANT SELECT ON [dbo].[WP_ContentRiskGroups] TO mcafeeTenant
GO

GRANT SELECT,UPDATE,INSERT,DELETE ON [dbo].[WP_ContentRiskGroups] TO mcafeeSystem
GO

--WP_ContentFuncGroups
GRANT SELECT ON [dbo].[WP_ContentFuncGroups] TO mcafeeTenant
GO

GRANT SELECT,UPDATE,INSERT,DELETE ON [dbo].[WP_ContentFuncGroups] TO mcafeeSystem
GO

--WP_ContentClassification
GRANT SELECT ON [dbo].[WP_ContentClassification] TO mcafeeTenant
GO

GRANT SELECT ON [dbo].[WP_ContentClassification] TO mcafeeOps
GO

GRANT SELECT,UPDATE,INSERT,DELETE ON [dbo].[WP_ContentClassification] TO mcafeeSystem
GO

--WCBladeTechView VIEW
GRANT SELECT ON WCBladeTechView To mcafeeTenant
GRANT SELECT ON WCBladeTechView To mcafeeOps