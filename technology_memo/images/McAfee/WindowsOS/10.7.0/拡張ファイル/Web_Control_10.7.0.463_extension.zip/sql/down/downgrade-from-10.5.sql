DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE ProductCode='ENDP_WP_1050'
GO

-- Add WP_CustomPropsMT.WCStatus column --
if exists(select [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'WP_CustomPropsMT' and [COLUMN_NAME] = N'LoadableSafari')
begin
	alter table [WP_CustomPropsMT]
		drop column [WCStatus]
end


INSERT INTO [dbo].[EAMP.GSE.Blades]
  ([ProductCode],
  [DispName],
  [TechnologyCount])
  VALUES (
  'ENDP_WP_1020',
  'Endpoint Security Web Control',
  1
)
GO


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[WCBladeTechView]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[WCBladeTechView]
  END
GO

