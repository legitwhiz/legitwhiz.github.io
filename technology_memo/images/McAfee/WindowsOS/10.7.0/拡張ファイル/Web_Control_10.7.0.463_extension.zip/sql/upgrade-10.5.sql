-- Add 10.5 product id
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_WP_1050'
if not exists(select [ProductCode] from [EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_WP_1050')
begin
	INSERT INTO [dbo].[EAMP.GSE.Blades]
	  ([ProductCode],
	  [DispName],
	  [TechnologyCount])
	  VALUES (
	  N'ENDP_WP_1050',
	  N'Endpoint Security Web Control',
	  1
	)
end
GO

IF NOT EXISTS(SELECT [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS WHERE [TABLE_NAME] = N'WP_CustomPropsMT' AND [COLUMN_NAME] = N'WCStatus')
  BEGIN
        ALTER TABLE [WP_CustomPropsMT]
            ADD [WCStatus] int NULL
  END
GO
