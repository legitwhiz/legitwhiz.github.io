-- upgrade-10.5.5.sql --

if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[WP_EventInfoMT]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
BEGIN
    IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'WP_EventInfoMT' AND COLUMN_NAME = 'URL' AND CHARACTER_MAXIMUM_LENGTH < 4000)
    BEGIN
         ALTER TABLE [dbo].[WP_EventInfoMT]
              ALTER COLUMN [URL] [nvarchar](4000) NULL;
	      
	 EXEC sp_refreshview 'WP_EventInfo';
    END
END
GO
