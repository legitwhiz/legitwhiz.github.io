
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[WP_CustomProps]
GO

CREATE VIEW [dbo].[WP_CustomProps] AS
    SELECT WP_CustomPropsMT.*, EPOProdPropsView_WEBCONTROL.LeafNodeID
    FROM WP_CustomPropsMT
    INNER JOIN [EPOProdPropsView_WEBCONTROL] ON [EPOProdPropsView_WEBCONTROL].[ProductPropertiesID] = [WP_CustomPropsMT].[ParentID]
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[WCBladeTechView]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[WCBladeTechView]
  END
GO

CREATE VIEW [dbo].[WCBladeTechView] AS
  SELECT [cp].[AutoIDWP] AS AutoID, [ppv].[LeafNodeID], 7 AS TechnologyType, [cp].[bWPEnabled] AS Enabled, [ppv].[ProductCode]
  FROM  [WP_CustomProps] AS [cp]
    LEFT JOIN [EPOProdPropsView_WEBCONTROL] AS [ppv]
      ON [ppv].[ProductPropertiesID] = [cp].[ParentID]
GO
