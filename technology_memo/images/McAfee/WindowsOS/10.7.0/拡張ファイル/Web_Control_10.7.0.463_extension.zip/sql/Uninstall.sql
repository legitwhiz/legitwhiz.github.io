------------------------------------------------------------------
--Copyright (c) 2014 McAfee Inc. - All Rights Reserved
------------------------------------------------------------------
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] IN (N'ENDP_WP_1000', N'ENDPM_WP1000', N'ENDP_WP_1010', N'ENDP_WP_1020', N'ENDP_WP_1050', N'ENDP_WP_1000MACX', N'ENDP_WP_1060', N'ENDP_WP_1070', N'ENDP_WP_1055MACX', N'ENDP_WP_1060MACX')
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO

-----------------------------------------Start WP_EventInfoMT Table and WP_EventInfo View-------------------------------------
--first drop the view
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_EventInfo]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[WP_EventInfo]
GO
--next delete the foreign key
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WP_EventInfoMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[WP_EventInfoMT]'))
ALTER TABLE [dbo].[WP_EventInfoMT] DROP CONSTRAINT [FK_WP_EventInfoMT_EPOEvents]
GO
--finally drop the table
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[WP_EventInfoMT]
GO
-----------------------------------------End WP_EventInfoMT Table and WP_EventInfo View-------------------------------------

-----------------------------------------Start WP_CustomPropsMT Table and WP_CustomProps View-------------------------------------
--first drop the view
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[WP_CustomProps]
GO
--next delete the foreign key
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WP_CustomPropsMT_EPOProductProperties]') AND parent_object_id = OBJECT_ID(N'[dbo].[WP_CustomPropsMT]'))
ALTER TABLE [dbo].[WP_CustomPropsMT] DROP CONSTRAINT [FK_WP_CustomPropsMT_EPOProductProperties]
GO
--finally drop the table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[WP_CustomPropsMT]') AND type in (N'U'))
DROP TABLE [dbo].[WP_CustomPropsMT]
GO
-----------------------------------------End WP_CustomPropsMT Table and WP_CustomProps View-------------------------------------

----------------------------------------------------
-- Drop Views
----------------------------------------------------
--Commented out due to bug 938475 and an e-mail discussion with Nivas of the client team
-- IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[WP_ClientPropertiesView]') AND OBJECTPROPERTY(id, N'IsView') = 1)
-- DROP VIEW [dbo].[WP_ClientPropertiesView]
-- GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AM_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[AM_EndpointTechnologyStatus_View]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[WP_EndpointTechnologyStatus_View]
GO

----------------------------------------------------
-- Drop WP_CF Tables
----------------------------------------------------
--first delete the foreign keys
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WP_ContentClassification_WP_ContentFuncGroups]') AND parent_object_id = OBJECT_ID(N'[dbo].[WP_ContentClassification]'))
ALTER TABLE [dbo].[WP_ContentClassification] DROP CONSTRAINT [FK_WP_ContentClassification_WP_ContentFuncGroups]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WP_ContentClassification_WP_ContentRiskGroups]') AND parent_object_id = OBJECT_ID(N'[dbo].[WP_ContentClassification]'))
ALTER TABLE [dbo].[WP_ContentClassification] DROP CONSTRAINT [FK_WP_ContentClassification_WP_ContentRiskGroups]
GO
--next delete the tables
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[WP_ContentClassification]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[WP_ContentClassification]
GO
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[WP_ContentFuncGroups]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[WP_ContentFuncGroups]
GO
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[WP_ContentRiskGroups]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[WP_ContentRiskGroups]
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[WCBladeTechView]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[WCBladeTechView]
  END
GO

--------- ePO Rollup Reporting ---------
if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ENSRollup_WP_EventInfo_Source]') and OBJECTPROPERTY([id], N'IsView') = 1)
	drop view [dbo].[ENSRollup_WP_EventInfo_Source]
go

if exists (select 1 from [sys].[foreign_keys] where [object_id] = OBJECT_ID(N'[FK_ENSRollup_WP_EventInfo_EPORollup_Events]') and [parent_object_id] = OBJECT_ID(N'[dbo].[ENSRollup_WP_EventInfo]'))
begin
	alter table [dbo].[ENSRollup_WP_EventInfo] drop constraint [FK_ENSRollup_WP_EventInfo_EPORollup_Events]
end
go

if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ENSRollup_WP_EventInfo]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
	drop table [dbo].[ENSRollup_WP_EventInfo]
end
go

if exists (select 1 from [sys].[foreign_keys] where [object_id] = OBJECT_ID(N'[FK_ENSRollup_WP_CustomProps_EPORollup_ProductProperties]') and [parent_object_id] = OBJECT_ID(N'[dbo].[ENSRollup_WP_CustomProps]'))
begin
	alter table [dbo].[ENSRollup_WP_CustomProps] drop constraint [FK_ENSRollup_WP_CustomProps_EPORollup_ProductProperties]
end
go

if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ENSRollup_WP_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
	drop table [dbo].[ENSRollup_WP_CustomProps]
end
go
