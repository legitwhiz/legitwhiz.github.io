------------------------------------------------------------------
--Copyright (c) 2014 McAfee Inc. - All Rights Reserved
------------------------------------------------------------------
-- Make sure there is only one installed blade record
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] IN (N'ENDP_WP_1000', N'ENDP_WP_1000MACX', N'ENDP_WP_1055MACX', N'ENDP_WP_1060MACX', N'ENDP_WP_1010', N'ENDP_WP_1020', N'ENDP_WP_1050', N'ENDP_WP_1060', N'ENDP_WP_1070')
GO

INSERT INTO [dbo].[EAMP.GSE.Blades] ([ProductCode], [DispName], [TechnologyCount]) VALUES
  (N'ENDP_WP_1000', N'Endpoint Security Web Control', 1), -- windows product
  (N'ENDP_WP_1000MACX', N'Endpoint Security Web Control', 1),  -- mac product
  (N'ENDP_WP_1055MACX', N'Endpoint Security Web Control', 1),  -- mac 10.5.5 product
  (N'ENDP_WP_1060MACX', N'Endpoint Security Web Control', 1),  -- mac 10.6 product
  (N'ENDP_WP_1010', N'Endpoint Security Web Control', 1),  -- windows 10.1 product
  (N'ENDP_WP_1020', N'Endpoint Security Web Control', 1),  -- windows 10.2 product
  (N'ENDP_WP_1050', N'Endpoint Security Web Control', 1),  -- windows 10.5 product
  (N'ENDP_WP_1060', N'Endpoint Security Web Control', 1),  -- windows 10.6 product
  (N'ENDP_WP_1070', N'Endpoint Security Web Control', 1)   -- windows 10.7 product
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- *************************************************
-- WP_ Table Additions/Modifications
-- *************************************************

-----------------------------------------Start WP_EventInfoMT Table and WP_EventInfo View-------------------------------------
----------------------------------------------------
-- Create Table WP_EventInfoMT
----------------------------------------------------
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	IF	EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'BIGINT' AND TABLE_NAME = 'EPOEventsMT' AND COLUMN_NAME = 'AutoID')
    BEGIN
    CREATE TABLE [dbo].[WP_EventInfoMT](
        [EventAutoID] [bigint] NOT NULL,
        [TenantId] [int] NOT NULL,
        [UserName] [nvarchar](128) NULL,
        [URL] [nvarchar](4000) NULL,
        [ListID] [int] NULL,
        [ReasonID] [int] NULL,
        [ObserverMode] [bit] NULL,
        [Count] [int] NULL CONSTRAINT [DF_WP_EventInfoMT_Count]  DEFAULT ((0)),
        [DomainName] [nvarchar](256) NULL,
        [ActionID] [int] NULL,
        [RatingID] [int] NULL,
        [ContentCategories] [nchar] (128) NULL DEFAULT '00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',
        [ContentID] [int] NULL DEFAULT 0,
        [PhishingRatingID] [int] NULL DEFAULT 6,
        [DownloadRatingID] [int] NULL DEFAULT 6,
        [SpamRatingID] [int] NULL DEFAULT 6,
        [PopupRatingID] [int] NULL DEFAULT 6,
        [BadLinkRatingID] [int] NULL DEFAULT 6,
        [ExploitRatingID] [int] NULL DEFAULT 6,
        CONSTRAINT [PK_WP_EventInfoMT] PRIMARY KEY NONCLUSTERED
        (
            [EventAutoID] ASC
        )
    )
	END
	ELSE
	BEGIN
		CREATE TABLE [dbo].[WP_EventInfoMT](
			[EventAutoID] [int] NOT NULL,
			[UserName] [nvarchar](128) NULL,
			[URL] [nvarchar](4000) NULL,
			[ListID] [int] NULL,
			[ReasonID] [int] NULL,
			[ObserverMode] [bit] NULL,
			[Count] [int] NULL CONSTRAINT [DF_WP_EventInfoMT_Count]  DEFAULT ((0)),
			[DomainName] [nvarchar](256) NULL,
			[ActionID] [int] NULL,
			[RatingID] [int] NULL,
			[ContentCategories] [nchar] (128) NULL DEFAULT '00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',
			[ContentID] [int] NULL DEFAULT 0,
			[PhishingRatingID] [int] NULL DEFAULT 6,
			[DownloadRatingID] [int] NULL DEFAULT 6,
			[SpamRatingID] [int] NULL DEFAULT 6,
			[PopupRatingID] [int] NULL DEFAULT 6,
			[BadLinkRatingID] [int] NULL DEFAULT 6,
			[ExploitRatingID] [int] NULL DEFAULT 6,
			CONSTRAINT [PK_WP_EventInfoMT] PRIMARY KEY NONCLUSTERED
			(
				[EventAutoID] ASC
			)
		)
	END
END
GO

IF NOT EXISTS(SELECT * FROM sysconstraints WHERE id=OBJECT_ID('WP_EventInfoMT') AND COL_NAME(id,colid)='TenantId' AND OBJECTPROPERTY(constid, N'IsDefaultCnst')=1)
BEGIN
ALTER TABLE [dbo].[WP_EventInfoMT]
  ADD CONSTRAINT [DF_WP_EventInfoMT_TenantId]
  DEFAULT dbo.FN_Core_GetContextTenantId() FOR TenantId
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WP_EventInfoMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[WP_EventInfoMT]'))
BEGIN
ALTER TABLE [dbo].[WP_EventInfoMT]  WITH CHECK ADD
    CONSTRAINT [FK_WP_EventInfoMT_EPOEvents] FOREIGN KEY
    (
        [EventAutoID]
    )
REFERENCES [dbo].[EPOEventsMT]
    (
        [AutoID]
    ) ON DELETE CASCADE ON UPDATE NO ACTION
END
GO

IF  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_1')
DROP INDEX [dbo].[WP_EventInfoMT].[IX_WP_EventInfoMT_1]
GO
CREATE CLUSTERED INDEX [IX_WP_EventInfoMT_1] ON [dbo].[WP_EventInfoMT]
(
    [TenantId] ASC,
    [EventAutoID] ASC
)
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_ListID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WP_EventInfoMT_ListID] ON [dbo].[WP_EventInfoMT]
(
    [ListID] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_ReasonID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WP_EventInfoMT_ReasonID] ON [dbo].[WP_EventInfoMT]
(
    [ReasonID] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_DomainName')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WP_EventInfoMT_DomainName] ON [dbo].[WP_EventInfoMT]
(
    [DomainName] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_ActionID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WP_EventInfoMT_ActionID] ON [dbo].[WP_EventInfoMT]
(
    [ActionID] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_RatingID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WP_EventInfoMT_RatingID] ON [dbo].[WP_EventInfoMT]
(
    [RatingID] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_ContentID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WP_EventInfoMT_ContentID] ON [dbo].[WP_EventInfoMT]
(
    [ContentID] ASC
)
END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_EventInfo]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[WP_EventInfo]
GO
CREATE VIEW [dbo].[WP_EventInfo] AS
    select wp.* from [WP_EventInfoMT] wp
    where wp.[TenantId] = convert(int, substring(CONTEXT_INFO(), 5, 4))

GO

EXEC EPOCore_AddInsertTriggerToMTTable 'WP_EventInfo'
GO

EXEC EPOCore_AddUpdateTriggerToMTTable 'WP_EventInfo'
GO

EXEC EPOCore_AddDeleteTriggerToMTTable 'WP_EventInfo'
GO

-----------------------------------------End WP_EventInfoMT Table and WP_EventInfo View-------------------------------------

--Commented out due to bug 938475 and an e-mail discussion with Nivas of the client team
----------------------------------------------------
-- Create View WP_ClientPropertiesView
----------------------------------------------------

--CREATE VIEW [dbo].WP_ClientPropertiesView
--AS
--SELECT
--      props.ParentID,
--      LoadableIE =
--            CASE WP_ClientLoadableIE.Value
--                  WHEN 1 THEN 1
--                  WHEN 2 THEN 2
--                  ELSE 0
--            END,
--      LoadableFF =
--            CASE WP_ClientLoadableFF.Value
--                  WHEN 1 THEN 1
--                  WHEN 2 THEN 2
--                  ELSE 0
--            END,
--	  LoadableCH =
--            CASE WP_ClientLoadableCH.Value
--                  WHEN 1 THEN 1
--                  WHEN 2 THEN 2
--                  ELSE 0
--            END,
--      ISNULL(WP_ClientUnloadableUserList.Value, '') AS UnloadableUserList,
--      WP_ClientLicenseState.Value as LicenseState,
--      WP_ClientLicenseEvalDays.Value as LicenseEvalDays,
--	  ProtectionStatus =
--            CASE ProtectionStatus.Value
--                  WHEN 0 THEN 0
--                  WHEN 1 THEN 1
--                  ELSE 0
--            END
--FROM
--    [dbo].EPOProductProperties AS props
--    INNER JOIN EPOLeafNode ON props.parentID = EPOLeafNode.AutoID
--    LEFT JOIN [dbo].EPOProductSettings AS WP_ClientLoadableIE ON (props.AutoID = WP_ClientLoadableIE.ParentID AND WP_ClientLoadableIE.SettingName = 'LoadableIE' AND WP_ClientLoadableIE.Value IS NOT NULL)
--    LEFT JOIN [dbo].EPOProductSettings AS WP_ClientLoadableFF ON (props.AutoID = WP_ClientLoadableFF.ParentID AND WP_ClientLoadableFF.SettingName = 'LoadableFF' AND WP_ClientLoadableFF.Value IS NOT NULL)
--	LEFT JOIN [dbo].EPOProductSettings AS WP_ClientLoadableCH ON (props.AutoID = WP_ClientLoadableCH.ParentID AND WP_ClientLoadableCH.SettingName = 'LoadableCH' AND WP_ClientLoadableCH.Value IS NOT NULL)
--    LEFT JOIN [dbo].EPOProductSettings AS WP_ClientUnloadableUserList ON (props.AutoID = WP_ClientUnloadableUserList.ParentID AND WP_ClientUnloadableUserList.SettingName = 'UnloadableUserList' AND WP_ClientUnloadableUserList.Value IS NOT NULL)
--    LEFT JOIN [dbo].EPOProductSettings AS WP_ClientLicenseState ON (props.AutoID = WP_ClientLicenseState.ParentID AND WP_ClientLicenseState.SettingName = 'LicenseState' AND WP_ClientLicenseState.Value IS NOT NULL)
--    LEFT JOIN [dbo].EPOProductSettings AS WP_ClientLicenseEvalDays ON (props.AutoID = WP_ClientLicenseEvalDays.ParentID AND WP_ClientLicenseEvalDays.SettingName = 'LicenseEvalDays' AND WP_ClientLicenseEvalDays.Value IS NOT NULL)
--	LEFT JOIN [dbo].EPOProductSettings AS ProtectionStatus ON (props.AutoID = ProtectionStatus.ParentID AND ProtectionStatus.SettingName = 'WP_Status' AND ProtectionStatus.Value IS NOT NULL)
--WHERE
--    props.ProductCode LIKE 'ENDP_WP_1000'
--    AND EPOLeafNode.TenantId = 0
--        OR EPOLeafNode.TenantId = CASE
--          WHEN dbo.FN_Core_IsSystemUserInContext() = 1
--            THEN EPOLeafNode.TenantId
--            ELSE dbo.FN_Core_GetContextTenantId()
--          END
--
--GO

-----------------------------------------Start WP_CustomPropsMT Table and WP_CustomProps View-------------------------------------
--CUSTOM PROPERTIES TABLE
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[WP_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[WP_CustomPropsMT](
    [AutoID]                                 [int] NOT NULL IDENTITY (1,1),
    [ParentID]                               [int] NOT NULL,             -- Required for custom properties
    [TenantId]                               [int] NOT NULL,
    [bWPEnabled]                             [bit] NOT NULL CONSTRAINT DF_WP_CustomPropsMT_bWPEnabled DEFAULT ((0)),
    [AutoIDWP]                               [uniqueidentifier] DEFAULT NEWSEQUENTIALID(),
    [WPbComplianceStatus]                    [bit] NOT NULL CONSTRAINT DF_WP_CustomPropsMT_WPbComplianceStatus DEFAULT ((0)),
    [WPComplianceStatus]                     [nvarchar] (256) NULL,
    [WPAdditionalComplianceStatus]           [nvarchar] (256) NULL,
    [Hotfixes]                               [nvarchar] (256) NULL,
    [Patch]                                  [nvarchar] (3000) NULL,
    [LicenseStatus]                          [nvarchar] (256) NULL,
    [Language]                               [nvarchar] (256) NULL,
    [LoadableCH]                             [tinyint] NULL,
    [LoadableFF]                             [tinyint] NULL,
    [LoadableIE]                             [tinyint] NULL,
	  [LoadableSafari]                         [tinyint] NULL,
	  [WCStatus]                               [int]     NULL
 CONSTRAINT [PK_WP_CustomPropsMT] PRIMARY KEY NONCLUSTERED
(
    [AutoID] ASC
)
)
END
GO

/****** Object:  Index [IX_WP_CustomPropsMT_TenantId_AutoID] ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[WP_CustomPropsMT]') AND name = N'IX_WP_CustomPropsMT_TenantId_AutoID')
	DROP INDEX [IX_WP_CustomPropsMT_TenantId_AutoID] ON [dbo].[WP_CustomPropsMT] WITH ( ONLINE = OFF )
GO

CREATE UNIQUE CLUSTERED INDEX [IX_WP_CustomPropsMT_TenantId_AutoID] ON [dbo].[WP_CustomPropsMT]
(
	[TenantId] ASC,	[AutoID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF,
		ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF NOT EXISTS(SELECT * FROM sysconstraints WHERE id=OBJECT_ID('WP_CustomPropsMT') AND COL_NAME(id,colid)='TenantId' AND OBJECTPROPERTY(constid, N'IsDefaultCnst')=1)
BEGIN
ALTER TABLE [dbo].[WP_CustomPropsMT]
  ADD CONSTRAINT [DF_WP_CustomPropsMT_TenantId]
  DEFAULT dbo.FN_Core_GetContextTenantId() FOR TenantId
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WP_CustomPropsMT_EPOProductProperties]') AND parent_object_id = OBJECT_ID(N'[dbo].[WP_CustomPropsMT]'))
BEGIN
ALTER TABLE [dbo].[WP_CustomPropsMT] ADD
    CONSTRAINT [FK_WP_CustomPropsMT_EPOProductProperties] FOREIGN KEY (
        [ParentID]
    ) REFERENCES [dbo].[EPOProductPropertiesMT] (
        [AutoID]
    ) ON DELETE CASCADE ON UPDATE NO ACTION
END
GO

--create unique index on the foreign key column
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_CustomPropsMT]') AND name = N'IX_WP_CustomPropsMT_ParentID')
BEGIN
CREATE UNIQUE NONCLUSTERED INDEX [IX_WP_CustomPropsMT_ParentID] ON [dbo].[WP_CustomPropsMT]
(
    [ParentID] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_CustomPropsMT]') AND name = N'IX_WP_CustomPropsMT_AutoIDWP')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WP_CustomPropsMT_AutoIDWP] ON [dbo].[WP_CustomPropsMT]
(
    [AutoIDWP] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_CustomPropsMT]') AND name = N'IX_WP_CustomPropsMT_WPbComplianceStatus')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WP_CustomPropsMT_WPbComplianceStatus] ON [dbo].[WP_CustomPropsMT]
(
    [WPbComplianceStatus] ASC
)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_CustomPropsMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_CustomPropsMT]') AND name = N'IX_WP_CustomPropsMT_Hotfixes')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WP_CustomPropsMT_Hotfixes] ON [dbo].[WP_CustomPropsMT]
(
    [Hotfixes] ASC
)
END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[WP_CustomProps]
GO
CREATE VIEW [dbo].[WP_CustomProps] AS
    select wp.*, pp.[ParentID] [LeafNodeID], pp.[ProductCode]
      from [WP_CustomPropsMT] wp
        inner join [EPOProductProperties_Fast] pp on wp.[ParentID] = pp.[AutoID]
      where wp.[TenantId] = convert(int, substring(CONTEXT_INFO(), 5, 4))
GO

EXEC EPOCore_AddInsertTriggerToMTTable 'WP_CustomProps'
GO

EXEC EPOCore_AddUpdateTriggerToMTTable 'WP_CustomProps'
GO

EXEC EPOCore_AddDeleteTriggerToMTTable 'WP_CustomProps'
GO
-----------------------------------------End WP_CustomPropsMT Table and WP_CustomProps View-------------------------------------

-- GSE extension upgrades all Tech Status views.
-- Make sure to update GSE extension if there are any changes to this view
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_EndpointTechnologyStatus_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[WP_EndpointTechnologyStatus_View]
GO
CREATE VIEW [dbo].[WP_EndpointTechnologyStatus_View] AS
  select pp.[AutoIDWP] [AutoID], pp.[LeafNodeID], 7 [TechnologyType], pp.[bWPEnabled] [Enabled], pp.[ProductCode]
    from [WP_CustomProps] pp with(nolock)
GO

-- *************************************************
-- CF - Content Filtering Tables
-- *************************************************
----------------------------------------------------
-- Create Table WP_ContentRiskGroups
----------------------------------------------------
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[WP_ContentRiskGroups]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE [dbo].[WP_ContentRiskGroups](
		[ID] [int] NOT NULL,
		[Name] [nvarchar](64) NOT NULL,
	 CONSTRAINT [PK_WP_ContentRiskGroups] PRIMARY KEY CLUSTERED
		(
			[ID] ASC
		)
	)
END
GO

INSERT INTO [dbo].[WP_ContentRiskGroups](ID, Name) VALUES (0, 'Uncategorized')
INSERT INTO [dbo].[WP_ContentRiskGroups](ID, Name) VALUES (1, 'Bandwidth')
INSERT INTO [dbo].[WP_ContentRiskGroups](ID, Name) VALUES (2, 'Communications')
INSERT INTO [dbo].[WP_ContentRiskGroups](ID, Name) VALUES (3, 'Information')
INSERT INTO [dbo].[WP_ContentRiskGroups](ID, Name) VALUES (4, 'Liability')
INSERT INTO [dbo].[WP_ContentRiskGroups](ID, Name) VALUES (5, 'Productivity')
INSERT INTO [dbo].[WP_ContentRiskGroups](ID, Name) VALUES (6, 'Propriety')
INSERT INTO [dbo].[WP_ContentRiskGroups](ID, Name) VALUES (7, 'Security')
INSERT INTO [dbo].[WP_ContentRiskGroups](ID, Name) VALUES (8, 'High Risk')
GO

----------------------------------------------------
-- Create Table WP_ContentFuncGroups
----------------------------------------------------
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[WP_ContentFuncGroups]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE [dbo].[WP_ContentFuncGroups](
		[ID] [int] NOT NULL,
		[Name] [nvarchar](64) NOT NULL,
	 CONSTRAINT [PK_WP_ContentFuncGroups] PRIMARY KEY CLUSTERED
		(
			[ID] ASC
		)
	)
END
GO

-- ============================================================================
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES ( 0, 'Uncategorized')
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES ( 1, 'Business/Services')
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES ( 2, 'Drugs')
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES ( 3, 'Entertainment/Culture')
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES ( 4, 'Games/Gambling')
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES ( 5, 'Information Technology')
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES ( 6, 'Information/Communication')
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES ( 7, 'Lifestyle')
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES ( 8, 'Mature/Violent')
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES ( 9, 'Pornography/Nudity')
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES (10, 'Purchasing')
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES (11, 'Risk/Fraud/Crime')
INSERT INTO [dbo].[WP_ContentFuncGroups](ID, Name) VALUES (12, 'Society/Education/Religion')

GO

----------------------------------------------------
-- Create Table WP_ContentClassification
----------------------------------------------------
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[WP_ContentClassification]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE [dbo].[WP_ContentClassification](
		[CatBitID] [int] NOT NULL,
		[CatCode] [int] NOT NULL,
		[CatShortName] [nvarchar](2) NOT NULL,
		[CatName] [nvarchar](64) NOT NULL,
		[CatRiskGroupID] [int] NOT NULL,
 		[CatFuncGroupID] [int] NOT NULL,
	 CONSTRAINT [PK_WP_ContentClassification] PRIMARY KEY CLUSTERED
		(
			[CatBitID] ASC
		)
	)
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WP_ContentClassification_WP_ContentFuncGroups]') AND parent_object_id = OBJECT_ID(N'[dbo].[WP_ContentClassification]'))
BEGIN
ALTER TABLE [dbo].[WP_ContentClassification]  WITH CHECK ADD
    CONSTRAINT [FK_WP_ContentClassification_WP_ContentFuncGroups] FOREIGN KEY
    (
        [CatFuncGroupID]
    )
REFERENCES [dbo].[WP_ContentFuncGroups]
    (
        [ID]
    ) ON DELETE CASCADE ON UPDATE NO ACTION
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WP_ContentClassification_WP_ContentRiskGroups]') AND parent_object_id = OBJECT_ID(N'[dbo].[WP_ContentClassification]'))
BEGIN
ALTER TABLE [dbo].[WP_ContentClassification]  WITH CHECK ADD
    CONSTRAINT [FK_WP_ContentClassification_WP_ContentRiskGroups] FOREIGN KEY
    (
        [CatRiskGroupID]
    )
REFERENCES [dbo].[WP_ContentRiskGroups]
    (
        [ID]
    ) ON DELETE CASCADE ON UPDATE NO ACTION
END
GO

-- Secure Computing: Trusted Source Web Database --
-- ============================================================================
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (0, 100, 'ac', 'Art/Culture/Heritage' ,3, 3)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (1, 101, 'al', 'Alcohol' ,6, 2)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (2, 102, 'an', 'Anonymizers' ,7, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (3, 104, 'au', 'Anonymizing Utilities' ,7, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (4, 105, 'bu', 'Business' ,3, 1)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (5, 106, 'ch', 'Chat' ,2, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (6, 108, 'cm', 'Public Information' ,3, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (7, 109, 'cs', 'Potential Criminal Activities' ,4, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (8, 110, 'dr', 'Drugs' ,6, 2)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (9, 111, 'ed', 'Education/Reference' ,3, 12)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (10, 112, 'et', 'Entertainment' ,5, 3)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (11, 113, 'ex', 'Extreme' ,6, 8)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (12, 114, 'fi', 'Finance/Banking' ,3, 1)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (13, 115, 'gb', 'Gambling' ,4, 4)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (14, 116, 'gm', 'Games' ,5, 4)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (15, 117, 'gv', 'Government/Military' ,3, 12)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (16, 118, 'hk', 'Potential Hacking/Computer Crime' ,8, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (17, 119, 'hl', 'Health' ,3, 12)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (18, 120, 'hm', 'Humor/Comics' ,5, 3)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (19, 121, 'hs', 'Discrimination' ,4, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (20, 122, 'im', 'Instant Messaging' ,2, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (21, 123, 'in', 'Stock Trading' ,5, 1)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (22, 124, 'ir', 'Internet Radio/TV' ,1, 3)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (23, 125, 'js', 'Job Search' ,5, 1)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (24, 126, 'io', 'Information Security' ,6, 5)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (25, 127, 'mm', 'Dating/Social Networking' ,6, 7)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (26, 128, 'mo', 'Mobile Phone' ,5, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (27, 129, 'mp', 'Media Downloads' ,1, 3)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (28, 130, 'ms', 'Malicious Sites' ,8, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (29, 131, 'na', 'Usenet News' ,2, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (30, 132, 'nd', 'Nudity' ,4, 9)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (31, 133, 'np', 'Non-Profit/Advocacy/NGO' ,3, 12)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (32, 134, 'nw', 'General News' ,3, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (33, 136, 'os', 'Online Shopping' ,5, 10)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (34, 137, 'pa', 'Provocative Attire' ,6, 9)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (35, 138, 'pn', 'P2P/File Sharing' ,7, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (36, 139, 'po', 'Politics/Opinion' ,5, 12)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (37, 140, 'pp', 'Personal Pages' ,5, 7)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (38, 141, 'ps', 'Portal Sites' ,3, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (39, 142, 'ra', 'Remote Access' ,7, 5)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (40, 143, 'rl', 'Religion/Ideology' ,5, 12)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (41, 144, 'rs', 'Resource Sharing' ,7, 5)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (42, 145, 'se', 'Search Engines' ,3, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (43, 146, 'sp', 'Sports' ,5, 7)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (44, 147, 'st', 'Streaming Media' ,1, 3)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (45, 148, 'sw', 'Shareware/Freeware' ,7, 5)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (46, 149, 'sx', 'Pornography' ,8, 9)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (47, 150, 'sy', 'Spyware/Adware/Keyloggers' ,8, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (48, 151, 'tb', 'Tobacco' ,6, 2)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (49, 152, 'tr', 'Travel' ,3, 7)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (50, 153, 'vi', 'Violence' ,6, 8)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (51, 154, 'wa', 'Web Ads' ,1, 5)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (52, 155, 'we', 'Weapons' ,6, 8)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (53, 156, 'wm', 'Web Mail' ,2, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (54, 157, 'wp', 'Web Phone' ,2, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (55, 158, 'eb', 'Auctions/Classifieds' ,5, 10)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (56, 159, 'mb', 'Forum/Bulletin Boards' ,2, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (57, 160, 'pr', 'Profanity' ,6, 8)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (58, 161, 'sc', 'School Cheating Information' ,6, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (59, 162, 'sm', 'Sexual Materials' ,6, 9)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (60, 163, 'tg', 'Gruesome Content' ,6, 8)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (61, 164, 'vs', 'Visual Search Engine' ,4, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (62, 165, 'tf', 'Technical/Business Forums' ,2, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (63, 166, 'gr', 'Gambling Related' ,6, 4)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (64, 167, 'mg', 'Messaging' ,2, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (65, 168, 'cv', 'Game/Cartoon Violence' ,6, 8)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (66, 169, 'ph', 'Phishing' ,8, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (67, 170, 'ns', 'Personal Network Storage' ,7, 5)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (68, 171, 'su', 'Spam URLs' ,7, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (69, 172, 'ia', 'Interactive Web Applications' ,7, 5)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (70, 174, 'fb', 'Fashion/Beauty' ,5, 10)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (71, 175, 'hw', 'Software/Hardware' ,3, 5)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (72, 176, 'il', 'Potential Illegal Software' ,4, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (73, 177, 'is', 'Content Server' ,3, 5)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (74, 178, 'it', 'Internet Services' ,3, 5)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (75, 179, 'md', 'Media Sharing' ,1, 3)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (76, 180, 'mn', 'Incidental Nudity' ,4, 9)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (77, 181, 'mk', 'Marketing/Merchandising' ,5, 10)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (78, 183, 'pd', 'Parked Domain' ,7, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (79, 184, 'pm', 'Pharmacy' ,5, 10)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (80, 185, 'rb', 'Restaurants' ,5, 7)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (81, 186, 're', 'Real Estate' ,5, 10)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (82, 187, 'rh', 'Recreation/Hobbies' ,5, 3)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (83, 188, 'bl', 'Blogs/Wiki' ,5, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (84, 189, 'dc', 'Digital Postcards' ,2, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (85, 190, 'hr', 'Historical Revisionism' ,4, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (86, 191, 'ti', 'Technical Information' ,3, 5)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (87, 192, 'dp', 'Dating/Personals' ,6, 7)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (88, 193, 'mv', 'Motor Vehicles' ,5, 10)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (89, 194, 'nt', 'Professional Networking' ,2, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (90, 195, 'sn', 'Social Networking' ,6, 7)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (91, 196, 'tt', 'Text Translators' ,2, 5)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (92, 197, 'wx', 'Web Meetings' ,2, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (93, 600, 'fk', 'For Kids' ,6, 12)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (94, 601, 'hi', 'History' ,3, 12)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (95, 602, 'mr', 'Moderated' ,6, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (96, 603, 'to', 'Text/Spoken Only' ,6, 6)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (97, 198, 'co', 'Controversial Opinions' ,6, 7)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (98, 199, 'pc', 'Residential IP Addresses' ,7, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (99, 200, 'be', 'Browser Exploits' ,8, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (100, 201, 'cp', 'Consumer Protection' ,5, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (101, 202, 'uk', 'Illegal UK' ,4, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (102, 203, 'rm', 'Major Global Religions' ,5, 12)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (103, 204, 'dl', 'Malicious Downloads' ,8, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (104, 205, 'pu', 'PUPs' ,7, 11)
INSERT INTO [dbo].[WP_ContentClassification](CatBitID, CatCode, CatShortName, CatName, CatRiskGroupID, CatFuncGroupID ) VALUES (128, 0, '', 'Uncategorized' ,0, 0)

GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[WCBladeTechView]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[WCBladeTechView]
  END
GO

CREATE VIEW [dbo].[WCBladeTechView] AS
  select pp.[AutoIDWP] [AutoID], pp.[LeafNodeID], 7 [TechnologyType], pp.[bWPEnabled] [Enabled], pp.[ProductCode]
    from [WP_CustomProps] pp with(nolock)
GO
