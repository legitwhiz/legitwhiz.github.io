-- upgradeMT-10.5.2.sql --

alter view [dbo].[WP_CustomProps] as
	select wp.*, pp.[ParentID] [LeafNodeID], pp.[ProductCode]
	from [WP_CustomPropsMT] wp
		inner join [EPOProductProperties_Fast] pp on wp.[ParentID] = pp.[AutoID]
	where wp.[TenantId] = convert(int, substring(CONTEXT_INFO(), 5, 4))
go

-- correct view permissions --
revoke select,insert,update,delete,references on [dbo].[GS_CustomProps] to [mcafeeSystem]
grant select,insert,update,delete on [dbo].[WP_CustomProps] to [mcafeeOps]
grant select,insert,update,delete on [dbo].[WP_CustomProps] to [mcafeeTenant]
go

alter view [dbo].[WP_EndpointTechnologyStatus_View] AS
	select pp.[AutoIDWP] [AutoID], pp.[LeafNodeID], 7 [TechnologyType], pp.[bWPEnabled] [Enabled], pp.[ProductCode]
	from [WP_CustomProps] pp with(nolock)
go

-- correct view permissions --
revoke select,insert,update,delete,references on [dbo].[WP_EndpointTechnologyStatus_View] to [mcafeeSystem]
grant select on [dbo].[WP_EndpointTechnologyStatus_View] to [mcafeeOps]
grant select on [dbo].[WP_EndpointTechnologyStatus_View] to [mcafeeTenant]
go

alter view [dbo].[WCBladeTechView] AS
	select pp.[AutoIDWP] [AutoID], pp.[LeafNodeID], 7 [TechnologyType], pp.[bWPEnabled] [Enabled], pp.[ProductCode]
	from [WP_CustomProps] pp with(nolock)
go

grant select ON [dbo].[WCBladeTechView] To [mcafeeTenant]
grant select ON [dbo].[WCBladeTechView] To [mcafeeOps]
go