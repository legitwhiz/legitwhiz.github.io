
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[WP_CustomProps]
GO

CREATE VIEW [dbo].[WP_CustomProps] AS
    SELECT WP_CustomPropsMT.*, EPOProdPropsView_WEBCONTROL.LeafNodeID
    FROM WP_CustomPropsMT
    INNER JOIN [EPOProdPropsView_WEBCONTROL] ON [EPOProdPropsView_WEBCONTROL].[ProductPropertiesID] = [WP_CustomPropsMT].[ParentID]
    WHERE TenantId IN (SELECT TOP(1) tid FROM [epofn_GetTenancyInfoTable]())
       OR    TenantId = 0
       OR    EXISTS (SELECT TOP(1) ops FROM [epofn_GetTenancyInfoTable]() WHERE ops = 1)
GO

EXEC EPOCore_AddInsertTriggerToMTTable 'WP_CustomProps'
EXEC EPOCore_AddUpdateTriggerToMTTable 'WP_CustomProps'
EXEC EPOCore_AddDeleteTriggerToMTTable 'WP_CustomProps'
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[WP_CustomProps] TO mcafeeTenant
GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[WP_CustomProps] TO mcafeeSystem
GO
