-- upgrade-10.5.2.sql --

-- upgrade views (performance)
alter view [dbo].[WP_CustomProps] as
	select wp.*, pp.[ParentID] [LeafNodeID], pp.[ProductCode], pp.[TheHiddenTimestamp] [timestamp]
    from [WP_CustomPropsMT] wp
        inner join [EPOProductProperties] pp on wp.[ParentID] = pp.[AutoID]
go

alter view [dbo].[WP_EndpointTechnologyStatus_View] AS
    select pp.[AutoIDWP] [AutoID], pp.[LeafNodeID], 7 [TechnologyType], pp.[bWPEnabled] [Enabled], pp.[ProductCode]
    from [WP_CustomProps] pp with(nolock)
go

alter view [dbo].[WCBladeTechView] AS
  select pp.[AutoIDWP] [AutoID], pp.[LeafNodeID], 7 [TechnologyType], pp.[bWPEnabled] [Enabled], pp.[ProductCode]
  from [WP_CustomProps] pp with(nolock)
go

--------- ePO Rollup Reporting ---------
-- WP_EventInfo rollup source --
if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ENSRollup_WP_EventInfo_Source]') and OBJECTPROPERTY([id], N'IsView') = 1)
	drop view [dbo].[ENSRollup_WP_EventInfo_Source]
go

create view [dbo].[ENSRollup_WP_EventInfo_Source] as
	select ex.*, e.[TheTimestamp] [timestamp]
		from [dbo].[WP_EventInfo] ex
			inner join [dbo].[EPOEvents] e on ex.[EventAutoID] = e.[AutoID]
go

-- WP_EventInfo rollup target --
if not exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ENSRollup_WP_EventInfo]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
	declare @idType nvarchar(128)
	select @idType = ISNULL([DATA_TYPE], N'bigint') FROM INFORMATION_SCHEMA.COLUMNS WHERE [TABLE_NAME] = 'EPORollup_Events' AND [COLUMN_NAME] = 'AutoID'

	declare @sql nvarchar(4000) =
N'create table [dbo].[ENSRollup_WP_EventInfo]
(
	[RegSvrId] [int] not null,
	[EventAutoID] [' + @idType + '] not null,
	[UserName] [nvarchar](128) null,
	[URL] [nvarchar](1024) null,
	[ListID] [int] null,
	[ReasonID] [int] null,
	[ObserverMode] [bit] null,
	[Count] [int] null,
	[DomainName] [nvarchar](256) null,
	[ActionID] [int] null,
	[RatingID] [int] null,
	[ContentCategories] [nchar] (128) null,
	[ContentID] [int] null,
	[PhishingRatingID] [int] null,
	[DownloadRatingID] [int] null,
	[SpamRatingID] [int] null,
	[PopupRatingID] [int] null,
	[BadLinkRatingID] [int] null,
	[ExploitRatingID] [int] null,
	constraint [PK_ENSRollup_WP_EventInfo] primary key clustered
	([RegSvrId] asc, [EventAutoID] asc)
)'
	exec(@sql)
end
go

-- EPORollup_Events -> ENSRollup_WP_EventInfo FK Constraint
if not exists (select 1 from [sys].[foreign_keys] where [object_id] = OBJECT_ID(N'[FK_ENSRollup_WP_EventInfo_EPORollup_Events]') and [parent_object_id] = OBJECT_ID(N'[dbo].[ENSRollup_WP_EventInfo]'))
begin
	alter table [dbo].[ENSRollup_WP_EventInfo]
	add constraint [FK_ENSRollup_WP_EventInfo_EPORollup_Events] foreign key
		([RegSvrId], [EventAutoID])
		references [dbo].[EPORollup_Events]
		([RegSvrId], [AutoID])
		on delete cascade on update no action
end
go

-- WP_CustomProps rollup target --
if not exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ENSRollup_WP_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
begin
	create table [dbo].[ENSRollup_WP_CustomProps]
	(
		[RegSvrId] [int] not null,
		[AutoID] [int] not null,
		[ParentID] [int] not null,
		[AutoIDWP]						[uniqueidentifier] null,
		[Hotfixes]						[nvarchar] (256) null,
		[Patch]							[nvarchar] (3000) null,
		[LicenseStatus]					[nvarchar] (256) null,
		[Language]						[nvarchar] (256) null,
		[WCStatus]						[int] null,
		[bWPEnabled]					[bit] null,
		[WPbComplianceStatus]			[bit] null,
		[WPComplianceStatus]			[nvarchar] (256) null,
		[WPAdditionalComplianceStatus]	[nvarchar] (256) null,
		[LoadableCH]					[tinyint] null,
		[LoadableFF]					[tinyint] null,
		[LoadableIE]					[tinyint] null,
		[LoadableSafari]				[tinyint] null,
		constraint [PK_ENSRollup_WP_CustomProps] primary key clustered
		([RegSvrId] asc, [AutoID] asc)
	)
end
go

if not exists (select 1 from [sys].[foreign_keys] where [object_id] = OBJECT_ID(N'[FK_ENSRollup_WP_CustomProps_EPORollup_ProductProperties]') and [parent_object_id] = OBJECT_ID(N'[dbo].[ENSRollup_WP_CustomProps]'))
begin
	alter table [dbo].[ENSRollup_WP_CustomProps] add
	constraint [FK_ENSRollup_WP_CustomProps_EPORollup_ProductProperties] foreign key
		([RegSvrId], [ParentID])
		references [dbo].[EPORollup_ProductProperties]
		([ServerId], [ExternalId])
		on delete cascade on update no action
end
go

--create unique index on the foreign key
if exists(select 1 from [dbo].[sysobjects] where [id] = OBJECT_ID(N'[dbo].[ENSRollup_WP_CustomProps]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
	and not exists(select 1 from [dbo].[sysindexes] where [id] = OBJECT_ID(N'[dbo].[ENSRollup_WP_CustomProps]') and [name] = N'IX_ENSRollup_WP_CustomProps_ParentID')
begin
	create unique nonclustered index [IX_ENSRollup_WP_CustomProps_ParentID] on [dbo].[ENSRollup_WP_CustomProps]
		([RegSvrId] asc, [ParentID] asc)
end
go
