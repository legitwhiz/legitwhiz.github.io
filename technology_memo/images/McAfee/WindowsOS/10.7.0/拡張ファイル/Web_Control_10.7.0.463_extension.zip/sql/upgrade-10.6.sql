DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_WP_1060'
if not exists(select [ProductCode] from [EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_WP_1060')
begin
	INSERT INTO [dbo].[EAMP.GSE.Blades]
	  ([ProductCode],
	  [DispName],
	  [TechnologyCount])
	  VALUES (
	  N'ENDP_WP_1060',
	  N'Endpoint Security Web Control',
	  1
	)
end
GO