-- upgrade-10.5.5OnPrem.sql --

if exists(select 1 from [dbo].[sysobjects] where [id] = object_id(N'[dbo].[ENSRollup_WP_EventInfo]') and OBJECTPROPERTY([id], N'IsUserTable') = 1)
BEGIN
    IF exists(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'ENSRollup_WP_EventInfo' AND COLUMN_NAME = 'URL' AND CHARACTER_MAXIMUM_LENGTH < 4000)
    BEGIN
         ALTER TABLE [dbo].[ENSRollup_WP_EventInfo]
              ALTER COLUMN [URL] [nvarchar](4000) NULL
    END
END
GO

-- Refresh views
EXEC sp_refreshview 'ENSRollup_WP_EventInfo_Source'
GO