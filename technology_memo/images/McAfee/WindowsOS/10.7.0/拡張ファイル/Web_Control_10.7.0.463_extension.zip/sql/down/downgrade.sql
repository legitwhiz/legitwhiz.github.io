-- Add WP_CustomPropsMT.LoadableSafari column --
if exists(select [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'WP_CustomPropsMT' and [COLUMN_NAME] = N'LoadableSafari')
begin
	alter table [WP_CustomPropsMT]
		drop column [LoadableSafari] --tinyint NULL
end

-- Add Mac tech
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDPM_WP1000'
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_WP_1000MACX'
GO

DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE ProductCode='ENDP_WP_1000'
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE ProductCode='ENDP_WP_1010'
GO

INSERT INTO [dbo].[EAMP.GSE.Blades]
  ([ProductCode],
  [DispName],
  [TechnologyCount])
  VALUES (
  'ENDP_WP_1000',
  'Endpoint Security Web Control',
  1
)
GO
