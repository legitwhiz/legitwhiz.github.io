--Dropping and creating view because of change in custom props table
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[WP_CustomProps]
GO

CREATE VIEW [dbo].[WP_CustomProps] AS
    select wp.*, ppv.[LeafNodeID]
        from [WP_CustomPropsMT] wp
            inner join [EPOProdPropsView_WEBCONTROL] ppv on wp.[ParentID] = ppv.[ProductPropertiesID]
        where wp.[TenantId] = convert(int, substring(CONTEXT_INFO(), 5, 4))
GO

EXEC EPOCore_AddInsertTriggerToMTTable 'WP_CustomProps'
EXEC EPOCore_AddUpdateTriggerToMTTable 'WP_CustomProps'
EXEC EPOCore_AddDeleteTriggerToMTTable 'WP_CustomProps'
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[WP_CustomProps] TO mcafeeTenant
GRANT SELECT, UPDATE, INSERT, DELETE ON [dbo].[WP_CustomProps] TO mcafeeSystem
GO
--------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[WCBladeTechView]') and OBJECTPROPERTY(id, N'IsView') = 1)
  BEGIN
    DROP VIEW[dbo].[WCBladeTechView]
  END
GO

CREATE VIEW [dbo].[WCBladeTechView] AS
  SELECT [cp].[AutoIDWP] AS AutoID, [ppv].[LeafNodeID], 7 AS TechnologyType, [cp].[bWPEnabled] AS Enabled, [ppv].[ProductCode]
  FROM  [WP_CustomProps] AS [cp]
    LEFT JOIN [EPOProdPropsView_WEBCONTROL] AS [ppv]
      ON [ppv].[ProductPropertiesID] = [cp].[ParentID]
GO

--WCBladeTechView VIEW
GRANT SELECT ON WCBladeTechView To mcafeeTenant
GRANT SELECT, INSERT, UPDATE, DELETE ON WCBladeTechView To mcafeeSystem
GO

