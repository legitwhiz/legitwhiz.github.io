DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_WP_1070'
GO

