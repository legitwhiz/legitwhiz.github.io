-- Add WP_CustomPropsMT.LoadableSafari column --
if not exists(select [COLUMN_NAME] from INFORMATION_SCHEMA.COLUMNS where [TABLE_NAME] = N'WP_CustomPropsMT' and [COLUMN_NAME] = N'LoadableSafari')
begin
	alter table [WP_CustomPropsMT]
		add [LoadableSafari] tinyint NULL
end

-- Add Mac tech
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDPM_WP1000'
if not exists(select [ProductCode] from [EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_WP_1000MACX')
begin
	INSERT INTO [dbo].[EAMP.GSE.Blades]
	  ([ProductCode],
	  [DispName],
	  [TechnologyCount])
	  VALUES (
	  N'ENDP_WP_1000MACX',
	  N'Endpoint Security Web Control',
	  1
	)
end
GO

-- Add 10.1 product id
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_WP_1010'
if not exists(select [ProductCode] from [EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_WP_1010')
begin
	INSERT INTO [dbo].[EAMP.GSE.Blades]
	  ([ProductCode],
	  [DispName],
	  [TechnologyCount])
	  VALUES (
	  N'ENDP_WP_1010',
	  N'Endpoint Security Web Control',
	  1
	)
end
GO

-- Add 10.2 product id
DELETE FROM [dbo].[EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_WP_1020'
if not exists(select [ProductCode] from [EAMP.GSE.Blades] WHERE [ProductCode] = N'ENDP_WP_1020')
begin
	INSERT INTO [dbo].[EAMP.GSE.Blades]
	  ([ProductCode],
	  [DispName],
	  [TechnologyCount])
	  VALUES (
	  N'ENDP_WP_1020',
	  N'Endpoint Security Web Control',
	  1
	)
end
GO


