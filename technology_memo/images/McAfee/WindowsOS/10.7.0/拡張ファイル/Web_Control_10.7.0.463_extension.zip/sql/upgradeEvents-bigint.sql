IF  EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'BIGINT' AND TABLE_NAME = 'EPOEventsMT' AND COLUMN_NAME = 'AutoID')
AND EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'INT' AND TABLE_NAME = 'WP_EventInfoMT' AND COLUMN_NAME = 'EventAutoID')
BEGIN

    -- Drop PK constraint
	IF EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WP_EventInfoMT_EPOEvents]') AND parent_object_id = OBJECT_ID(N'[dbo].[WP_EventInfoMT]'))
    BEGIN
      ALTER TABLE [dbo].[WP_EventInfoMT] DROP CONSTRAINT [FK_WP_EventInfoMT_EPOEvents]
    END
	
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[WP_EventInfoMT]') AND name = N'PK_WP_EventInfoMT')
    BEGIN
        ALTER TABLE [dbo].[WP_EventInfoMT] DROP CONSTRAINT [PK_WP_EventInfoMT]
    END

	-- Drop Indexes --
  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_ListID')
    BEGIN
      DROP INDEX [IX_WP_EventInfoMT_ListID] ON [dbo].[WP_EventInfoMT]
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_ReasonID')
    BEGIN
      DROP INDEX [IX_WP_EventInfoMT_ReasonID] ON [dbo].[WP_EventInfoMT]
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_DomainName')
    BEGIN
      DROP INDEX [IX_WP_EventInfoMT_DomainName] ON [dbo].[WP_EventInfoMT]
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_ActionID')
    BEGIN
      DROP INDEX [IX_WP_EventInfoMT_ActionID] ON [dbo].[WP_EventInfoMT]
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_RatingID')
    BEGIN
      DROP INDEX [IX_WP_EventInfoMT_RatingID] ON [dbo].[WP_EventInfoMT]
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
   AND  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_ContentID')
    BEGIN
      DROP INDEX [IX_WP_EventInfoMT_ContentID] ON [dbo].[WP_EventInfoMT]
    END
	
    -- Update the column to BIGINT
    --------------------------------------------------------------------------------
    ALTER TABLE [dbo].[WP_EventInfoMT] ALTER COLUMN EventAutoID BIGINT NOT NULL;
    --------------------------------------------------------------------------------

    -- Add PK
    ALTER TABLE [dbo].[WP_EventInfoMT] ADD CONSTRAINT [PK_WP_EventInfoMT] PRIMARY KEY NONCLUSTERED
    (
        [EventAutoID]    ASC
    );

    ALTER TABLE [dbo].[WP_EventInfoMT]
    WITH CHECK ADD CONSTRAINT [FK_WP_EventInfoMT_EPOEvents] FOREIGN KEY
    (
        [EventAutoID]
    )
    REFERENCES [dbo].[EPOEventsMT]
    (
        [AutoID]
    )
    ON UPDATE NO ACTION ON DELETE CASCADE;

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_ListID')
    BEGIN
      CREATE NONCLUSTERED INDEX [IX_WP_EventInfoMT_ListID] ON [dbo].[WP_EventInfoMT]
      (
          [ListID] ASC
      )
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_ReasonID')
    BEGIN
      CREATE NONCLUSTERED INDEX [IX_WP_EventInfoMT_ReasonID] ON [dbo].[WP_EventInfoMT]
      (
          [ReasonID] ASC
      )
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_DomainName')
    BEGIN
      CREATE NONCLUSTERED INDEX [IX_WP_EventInfoMT_DomainName] ON [dbo].[WP_EventInfoMT]
      (
          [DomainName] ASC
      )
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_ActionID')
    BEGIN
      CREATE NONCLUSTERED INDEX [IX_WP_EventInfoMT_ActionID] ON [dbo].[WP_EventInfoMT]
      (
          [ActionID] ASC
      )
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_RatingID')
    BEGIN
      CREATE NONCLUSTERED INDEX [IX_WP_EventInfoMT_RatingID] ON [dbo].[WP_EventInfoMT]
      (
          [RatingID] ASC
      )
    END

  IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
     AND NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[WP_EventInfoMT]') AND name = N'IX_WP_EventInfoMT_ContentID')
    BEGIN
      CREATE NONCLUSTERED INDEX [IX_WP_EventInfoMT_ContentID] ON [dbo].[WP_EventInfoMT]
      (
          [ContentID] ASC
      )
    END
	
END
GO