------------------------------------------------------------------
--Copyright (c) 2018 McAfee LLC - All Rights Reserved
------------------------------------------------------------------
-- insert 10.7.0 product technology data
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[WP_CustomProps]
GO
CREATE VIEW [dbo].[WP_CustomProps] AS
    select wp.*, pp.[ParentID] [LeafNodeID], pp.[ProductCode], pp.[TheHiddenTimestamp] [timestamp]
    from [WP_CustomPropsMT] wp
        inner join [EPOProductProperties] pp on wp.[ParentID] = pp.[AutoID]
GO
