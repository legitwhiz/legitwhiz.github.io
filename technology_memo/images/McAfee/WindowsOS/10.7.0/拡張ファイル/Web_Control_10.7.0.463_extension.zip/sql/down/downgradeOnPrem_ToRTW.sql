
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WP_CustomProps]') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[WP_CustomProps]
GO

CREATE VIEW [dbo].[WP_CustomProps] AS
    SELECT WP_CustomPropsMT.*, EPOProdPropsView_WEBCONTROL.LeafNodeID
    FROM WP_CustomPropsMT
    INNER JOIN [EPOProdPropsView_WEBCONTROL] ON [EPOProdPropsView_WEBCONTROL].[ProductPropertiesID] = [WP_CustomPropsMT].[ParentID]
GO
