var _SAEGatewayPolicyConst =
{
    MaxGatewayIPListLength:(15 + 1) * 1000,
    MaxGatewayIPLength:15,
    GatewayIPDelim: ',',
    v4addrRegEx: /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/
}

function isValidIPv4Or6(ip)
{
    var result= false;

    if (OrionValidate.isValidIPString(ip))
    {
        result = true;
    }

    //old local method for validating ip addresses. Using orion above as I feel more comfortable with it.
    /*try{

        var ipAddr = new IpAddress(ip);
        result=true;
    }
    catch(err){
        // alert(err.message)
        // not a valid IP Address of any kind
    }*/

    return result;
}

function validateGatewayIPList(landmarkGatewayIPs)
{
    landmarkGatewayIPs = trim(landmarkGatewayIPs);

    if (landmarkGatewayIPs.length >= _SAEGatewayPolicyConst.MaxGatewayIPListLength){
        return false;
    }
    var iPs = landmarkGatewayIPs.split(_SAEGatewayPolicyConst.GatewayIPDelim);
    var ip = "";

    for (var i = 0; i < iPs.length; ++i)
    {
        ip = trim(iPs[i]);
        if (ip == ""){
            continue;
        }
        if (!isValidIPv4Or6(ip)){
            return false;
        }
    }

    return true;
}

function validateAgumentIPList(agumentIPs)
{
    agumentIPs = trim(agumentIPs);

    if (agumentIPs.length >= _SAEGatewayPolicyConst.MaxGatewayIPListLength)
    {
        return false;
    }

    var iPs = agumentIPs.split(_SAEGatewayPolicyConst.GatewayIPDelim);
    var ip = "";

    for (var i = 0; i < iPs.length; ++i)
    {
        ip = trim(iPs[i]);
        if (ip == "") {
            continue;
        }

        if (isValidCIDR(ip)) {
            return true;
        }

        if (isValidIPRange(ip).valid == false) {
            return false;
        }

    }

    return true;
}

function isValidCIDR(strIPText)
{
    try {
        var subnet = OrionCore.trim(strIPText).split("/");
        var subnetIP = subnet[0];
        var subnetCIDR = subnet[1];
        return OrionValidate.isValidIpv4CidrSubnet(subnetIP, subnetCIDR) || OrionValidate.isValidIpv6CidrSubnet(subnetIP, subnetCIDR);
    }
    catch (err) {
        return false;
    }
}
function isValidIPRange(strIPText)
{
    try
    {
        if(isValidIPString(strIPText))
        {
            return {valid:true};
        }
        else
        {
            // Could be an IP Range.
            var isV6R = false, arrColons = strIPText.split(":"), iNumColons = arrColons.length;
            if(iNumColons > 0)
            {
                var sAdjColons = strIPText.match(/::/g), iNumAdjColons = (sAdjColons ? sAdjColons.length : 0);
                isV6R = ((iNumAdjColons > 0) || (iNumColons > 1));
            }
            if(!isV6R)
            {
                // Treat it as IP-V4 range;
                var arrDots = strIPText.split(".");
                if((!arrDots) || (arrDots.length != 4))
                {
                    return {valid:false};
                }
                var str4Lower = ipV4RangeToOctet(arrDots, false), str4Upper = ipV4RangeToOctet(arrDots, true);
                return ((isValidIPv4String(str4Lower) && isValidIPv4String(str4Upper)) ? {valid:true} : {valid:false});
            }
            else
            {
                // Treat it as IP-V6 range;
                var str6Lower = ipV6RangeToOctet(arrColons, false), str6Upper = ipV6RangeToOctet(arrColons, true);
                return ((isValidIPv6String(str6Lower) && isValidIPv6String(str6Upper)) ? {valid:true} : {valid:false});
            }
        }
    }
    catch(err)
    {
    }
    return {valid:false};
};

function isValidIPString(string)
{
    return isValidIPv4String(string) || isValidIPv6String(string);
};

function isValidIPv4String(string)
{
    try
    {
        if( !string )
        {
            return false;
        }
        string = string.trim();
        var octetPattern = '(?:25[0-5]|2[0-4]\\d|[01]?\\d\\d?)';
        var regExStr     = '^(?:' + octetPattern + '\\.){3}' + octetPattern + '$';
        var regEx = new RegExp( regExStr );
        return regEx.test( string );
    }
    catch( e )
    {
        return false;
    }
};

function isValidIPv6String(string)
{
    try
    {
        if( !string )
        {
            return false;
        }
        string = string.trim();
        var hex  = '[0-9A-Fa-f]{1,4}';
        var hc   = '(' + hex + ':)';
        var oct  = '(\\b((25[0-5])|(1\\d{2})|(2[0-4]\\d)|(\\d{1,2}))\\b)';
        var ipv4 = '(' + oct + '\\.){3}' + oct;
        var regExStr =  '^(' +

            '(' + hc  + '{7}'                      + hex + ')|' +
            '(' + hc  + '{6}' + ':'                + hex + ')|' +
            '(' + hc  + '{5}' + ':' + hc + '?'     + hex + ')|' +
            '(' + hc  + '{4}' + ':' + hc + '{0,2}' + hex + ')|' +
            '(' + hc  + '{3}' + ':' + hc + '{0,3}' + hex + ')|' +
            '(' + hc  + '{2}' + ':' + hc + '{0,4}' + hex + ')|' +

            '('   + hc  + '{6}'         + ipv4 + ')|' +
            '('   + hc  + '{0,5}' + ':' + ipv4 + ')|' +
            '(::' + hc  + '{0,5}'       + ipv4 + ')|' +

            '('   + hex + '::' + hc  + '{0,5}' + hex + ')|' +
            '(::'              + hc  + '{0,6}' + hex + ')|' +
            '('                + hc  + '{1,7}' + ':' + ')'  +

            ')$';

        //var regEx = /^((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))$/;
        var regEx = new RegExp( regExStr );
        return regEx.test(string);
    }
    catch( e )
    {
        return false;
    }
};

function ipV4RangeToOctet(arrDots, bUseUpper)
{
    var iIndex = 0;
    if(bUseUpper)
    {
        iIndex = 1;
    }
    var strV4Addr = "", arrTemp;
    for(var i = 0; i < 4; i++)
    {
        if(i !== 0)
            strV4Addr += ".";
        arrTemp = arrDots[i].split("-");
        if(arrTemp)
        {
            if(arrTemp.length == 2)
            {
                if(Number(arrTemp[0]) < Number(arrTemp[1]))
                  strV4Addr += arrTemp[iIndex];
                else
                  strV4Addr += "zzz";  // Make the Octet invalid because the first octet in range is greater than second.
            }
            else if (arrTemp.length == 1)
                strV4Addr += arrDots[i];
            else
                strV4Addr += "zzz";  // Make the Octet invalid because the range has more than two hyphens.
        }
        else
        {
            strV4Addr += "zzz";
            break;
        }
    }
    return strV4Addr;
};

function ipV6RangeToOctet(arrColons, bUseUpper)
{
    var iIndex = 0;
    if(bUseUpper)
    {
        iIndex = 1;
    }
    var strV6Addr = "", arrTemp;
    for(var i = 0; i < arrColons.length; i++)
    {
        if(i !== 0)
            strV6Addr += ":";
        arrTemp = arrColons[i].split("-");
        if(arrTemp)
        {
            if(arrTemp.length == 2)
            {
                if(Number(arrTemp[0]) < Number(arrTemp[1]))
                  strV6Addr += arrTemp[iIndex];
                else
                  strV6Addr += "zzz";  // Make the Octet invalid because the first octet in range is greater than second.
            }
            else if (arrTemp.length == 1)
                strV6Addr += arrColons[i];
            else
                strV6Addr += "zzzz";  // Make the Octet invalid because the range has more than two hyphens.
        }
        else
        {
            strV6Addr += "zzzz";
            break;
        }
    }
    return strV6Addr;
};

function validateDomainName(DomainName)
{
	try
	{
		//debugger;
        if(DomainName == null)
        {
            return false;
        }
        var domainRegEx = /^((([A-Z]|[a-z]){1}((([A-Z]|[a-z]|[0-9]|\-)+)?([A-Z]|[a-z]|[0-9]){1})?){1}|((([A-Z]|[a-z]){1}((([A-Z]|[a-z]|[0-9]|\-)+)?([A-Z]|[a-z]|[0-9]){1})?){1}((\.){1}([A-Z]|[a-z]){1}((([A-Z]|[a-z]|[0-9]|\-)+)?([A-Z]|[a-z]|[0-9]){1})?)+){1})$/i;
		return domainRegEx.test(DomainName);
	}
	catch(e)
	{
		return false;
	}
}

function isValidGatwayeInterlock()
{
    var valid = true;
    //alert($("landmarkGatewayIPs") + ":" + $("landmarkGatewayIPs").value)
    if ($("bStandDown").checked)
    {
        valid = ($("bGatewayPresenceValidate").checked ||
                ($("bGatewayLandmarkValidate").checked && ($("szGatewayLandmark").value.length > 0 && validateGatewayIPList($("internalLandmarkIPs").value)) &&  $("internalLandmarkIPs").value.length > 0) ||
                ($("bGatewayIPValidate").checked && validateGatewayIPList($("landmarkGatewayIPs").value)) )
    }
    return valid;
}

function parseUri(uriStr)
{
    // parseUri 1.2.2
    // (c) Steven Levithan <stevenlevithan.com>
    // MIT License
    //
    //    The MIT License (MIT)
    //
    //    Copyright (c) <year> <copyright holders>
    //
    //    Permission is hereby granted, free of charge, to any person obtaining a copy
    //    of this software and associated documentation files (the "Software"), to deal
    //    in the Software without restriction, including without limitation the rights
    //    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    //    copies of the Software, and to permit persons to whom the Software is
    //    furnished to do so, subject to the following conditions:
    //
    //    The above copyright notice and this permission notice shall be included in
    //    all copies or substantial portions of the Software.
    //
    //    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    //    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    //    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    //    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    //    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    //    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
    //    THE SOFTWARE.

    var	m   =  /^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/.exec(uriStr),
        uri = {},
        i   = 14,
        key = ["source","protocol","authority","userInfo","user","password","host","port","relative","path","directory","file","query","anchor"];

    while (i--) uri[key[i]] = m[i] || "";

    uri["queryKey"] = {};
    uri[key[12]].replace(/(?:^|&)([^&=]*)=?([^&]*)/g, function ($0, $1, $2) {
        if ($1) uri["queryKey"][$1] = $2;
    });

    return uri
}

function IsValidAddress(input)
{
    var szBadChars = ":\\\"`!@#$%^&*=;,<>?|";
    for (var i = 0; i < szBadChars.length; i++)
    {
        if (input.indexOf(szBadChars.charAt(i)) != -1)
        {
            return false;
        }
    }
    return true;
}

function isValidWebReporterURLConfig(uri)
{
	if ($("bInformWebReporter").checked)
	{
        try
        {
            var uriObj =  parseUri(uri);

            return (uriObj.protocol.length == 0 ||
                    ((uriObj.protocol.toLowerCase() == "http" || uriObj.protocol.toLowerCase() == "ftp" ||
                      uriObj.protocol.toLowerCase() == "https" || uriObj.protocol.toLowerCase() == "ftps") &&
                     uri.indexOf("://") > -1)) &&
                   (uriObj.host.length > 0 && OrionValidate.isValidHostNameOrIPAddress(uriObj.host)) &&
                   (uriObj.authority.indexOf(":") == -1 || OrionValidate.isValidPort(uriObj.port)) &&
                   IsValidAddress(uriObj.path);
        }
        catch(err)
        {
            return false;
        }
	}
	return true;
}


function isValidWebReporterPasswordConfig()
{
	var valid = false;
	var password = $("elPassword").value;
	var confPassword = $("elConfirmPassword").value;
	
	if(password.length > 0 && (password == confPassword))
	{
		valid = true;
	}
		
	return valid;
}

function togglePasswordFieldState(elUsername, elPassword, elConfirmPassword, enabled)
{
    var userName =elUsername.value;

    if (enabled && (userName != '' || userName.length > 0))
    {
        OrionCore.setEnabled(elPassword, true);
        OrionCore.setEnabled(elConfirmPassword, true);
    }
    else
    {
	    if (!enabled && (userName != '' || userName.length > 0))
	    {
	        OrionCore.setEnabled(elPassword, false);
	        OrionCore.setEnabled(elConfirmPassword, false);
	    }
	    else
	    {
	        elPassword.value = "";
	        elConfirmPassword.value = "";
	        OrionCore.setEnabled(elPassword, false);
	        OrionCore.setEnabled(elConfirmPassword, false);
	    }
	}

    return true;
}



function isValidWebReporterPasswordConfig()
{
	var valid = false;
	var password = $("elPassword").value;
	var confPassword = $("elConfirmPassword").value;
	
	if(password.length > 0 && (password == confPassword))
	{
		valid = true;
	}
		
	return valid;
}

function togglePasswordFieldState(elUsername, elPassword, elConfirmPassword, enabled)
{
    var userName =elUsername.value;

    if (enabled && (userName != '' || userName.length > 0))
    {
        OrionCore.setEnabled(elPassword, true);
        OrionCore.setEnabled(elConfirmPassword, true);
    }
    else
    {
	    if (!enabled && (userName != '' || userName.length > 0))
	    {
	        OrionCore.setEnabled(elPassword, false);
	        OrionCore.setEnabled(elConfirmPassword, false);
	    }
	    else
	    {
	        elPassword.value = "";
	        elConfirmPassword.value = "";
	        OrionCore.setEnabled(elPassword, false);
	        OrionCore.setEnabled(elConfirmPassword, false);
	    }
	}

    return true;
}