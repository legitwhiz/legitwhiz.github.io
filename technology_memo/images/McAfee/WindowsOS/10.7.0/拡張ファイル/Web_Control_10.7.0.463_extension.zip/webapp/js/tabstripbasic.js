function tsbCrtl()
{
    this.tabs = {};
    this.tabCBs = {};
    this.content = {};
    this.count = 0
    this.selKey = ""
    this.debug = false;
}
// contentDivId allows you to override the contentDiv that key controls.
// This is used in some policies to show the same contentFiltering as another key, but with a
// slightly different view.
tsbCrtl.prototype.addTab = function addTab(key, tabText, callback, contentDivId)
{
    if (contentDivId==undefined){
        contentDivId = null
    }
    this.tabs[key] = tabText;
    this.content[key] = contentDivId;
    this.tabCBs[key] = callback;
    this.count++;
    if ( this.count == 1)
    {
        this.selKey = key
        if (this.debug) alert("this.selKey=" + this.selKey)
    }
}
tsbCrtl.prototype.setTab = function setTab(key)
{
    if (this.debug) alert("setTab: " + key + " selkey:" + this.selKey)
    var newCur = key;
    var oldCur = this.selKey;
    var newCurContent = this.content[key] || key
    var oldCurContent = this.content[oldCur] || oldCur

    this.divShow(true, newCurContent)
    this.tabSelect(true, newCur)
    var contentKey

    for (var key in this.tabs)
    {
        contentKey = this.content[key] || key
        if ( contentKey != newCurContent){
            this.divShow(false, contentKey)
        }
        if ( key != newCur){
            this.tabSelect(false, key)
        }

    }

    this.selKey = newCur
    this.invokeCallback(this.selKey)
}

tsbCrtl.prototype.invokeCallback = function invokeCallback(key)
{
  if (this.tabCBs[key])
  {
     this.tabCBs[key]();
  }
}

tsbCrtl.prototype.divShow = function divShow(bShow, divId)
{
    if (this.debug) alert("divShow id:" + 'content' + divId)
    var oDiv = $('content' + divId);
    if (this.debug) alert("divShow divId:" + divId + " oDiv:" + oDiv + " bShow:" + bShow)
    if (oDiv !== undefined && oDiv.style !== undefined){
        oDiv.style.display = bShow ? "block" : "none";
    }
    return oDiv;
}
tsbCrtl.prototype.tabSelect = function tabSelect(bSel, tabId)
{
    var oTD = $('tab' + tabId);
    if (this.debug) alert("tabSelect id:" + 'tab' + tabId + " oTD:" + oTD)

    if (oTD !== undefined && oTD.style !== undefined){
        oTD.className = bSel ? "orionTabSelected" : "orionTab";
    }
    return oTD;
}
