var _SAEHardenPolicyConst =
{
    savePolicyDo: "SaveBrowserControl.do",
    minHardeningPassLen: 8,
    browsers:
    [
     "InternetExplorer",
     "Firefox",
     "GoogleChrome"
    ],
    unbrowsers:
    [
     "Opera",
     "Safari",
     "Netscape",
     "Maxthon",
     "Flock",
     "AvantBrowser",
     "DeepnetExplorer",
     "PhaseOut",
     "Edge"
    ]
}
var _SAEHardenPolicy =
{
    readOnlyMode:false
}

var repositoryListDirtyFlag = false;

function onFormStateChange(isDirty, isValid)
{
    if ((isDirty || repositoryListDirtyFlag) && isValid){
        epoEnableApplyButton();
    }
    else{
        epoDisableApplyButton();
    }
}



// This is the default funciton called by the save button on the UI
function epoApplyPolicySettings()
{
    // Save to EPO
    OrionCore.doAsyncFormAction(SAE.context + _SAEHardenPolicyConst.savePolicyDo, null, _epoApplyPolicySuccess, _epoApplyPolicyFailure);

    return false;
}

// Submit Success callback
function _epoApplyPolicySuccess()
{
    OrionCore.showPleaseWait( false );
    fnGoBack();
}

// Submit Failure callback
function _epoApplyPolicyFailure()
{
    alert(_STRINGS["policySave_fail"]);
    return false;
}








