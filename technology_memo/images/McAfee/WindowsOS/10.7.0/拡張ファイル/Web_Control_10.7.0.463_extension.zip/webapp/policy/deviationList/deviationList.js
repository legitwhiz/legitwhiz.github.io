
var ListMeta =
{
    tableName: '',
    editItemDo: '',
    updateItemDo: '',
    updateFilterDo: '',
    savePolicyDo: '',
    addItemTitle : "",
    editItemTitle : "",
    updateResult: _Result.Success,
    updateItem: null,
    onEpoApplyCallback: null,
    bShowModal: false,
    bListDirty: false,
    bAddMode: false,
    debug: false,
    effectivePolicyMode: false,
    searchModeFilter: "0",
    searchModeTest: "1",
    filterText:"",
    testText:"",
    manageHelpFile: null,
    testSitePatterns: null,
    advanceOptionHelpFile: null,
    addMultiHelpFile: null,
    currentHelpFile: null,
    jsonRuleList:null,
    _:0
};

function collectCommonParams(params)
{
    if (params == undefined)
        params = [];

    params.push("blockAllowListJson");
    params.push(ListMeta.jsonRuleList);

    return params;
}


function SiteEnfDeviation(id, siteName, siteNote, siteAction)
{
    this.id = id;
    this.siteName = siteName;
    this.siteNote = siteNote;
    this.siteAction = siteAction;
}

function setupActionAndHandlers()
{
    initActionButtons();
    OrionEvent.registerHandlerById("searchText", enterPressed, null, "keyup", true);
    //**OrionTable.setCheckboxHandler(ListMeta.tableName, _checkboxCallback);
    TableHelper.setChangeHandler(ListMeta.tableName, _checkboxCallback);

    OrionCore.setEnabledById("clearFilterButton", false);
}

function initActionButtons()
{
    setEnableActionButtons($('editItem'),false)
    setEnableActionButtons($('deleteItems'),false)
    setEnableActionButtons($('addItem'),true)
}

function AddItem(resultType)
{
    if(!resultType) resultType = _Result.Success;
    var params = [
            "epoPsoId", $('epoPsoId').value,
            "selected", "-1",
            "resultType", resultType
            ];
    if (ListMeta.debug) alert(SAECore.createQueryString(params))
    OrionCore.dialogBoxOkHandler = onOkButtonPressed_AddItem;
    OrionCore.setDialogBoxTitle( ListMeta.addItemTitle );

    var flags = OrionCore.DIALOG_OK_CANCEL;
    flags.width = 490;
    flags.height = 325;

    OrionCore.showAsyncDialogBox( true, SAE.context + ListMeta.editItemDo +"?" + SAECore.createQueryString(params), flags, onLoad_AddItemDialog );

    ListMeta.bShowModal = true;
    ListMeta.bAddMode = true;
}

function onLoad_AddItemDialog()
{
    if (ListMeta.debug) alert("onLoad_AddItemDialog: ListMeta.updateResult:" + ListMeta.updateResult);
}

function onOkButtonPressed_AddItem()
{
    if (ListMeta.debug) alert("onOkButtonPressed_AddItem");
    SubmitAddItem();
}

function SubmitAddItem()
{
    if (ListMeta.debug) alert("entering submitadditem");

    ListMeta.updateItem = new SiteEnfDeviation(-1, $("_szSiteName").value, $("_szNote").value, $("_szSiteAction").value);
    if (ListMeta.debug) alert(ListMeta.updateItem.siteName + ":" + ListMeta.updateItem.siteNote + ":" + ListMeta.updateItem.siteAction)
    var params =
        [
            "edittype", _EditType.Add,
            "selected",-1,
            "_szSiteName", ListMeta.updateItem.siteName,
            "_szNote", ListMeta.updateItem.siteNote,
            "_szSiteAction", ListMeta.updateItem.siteAction
        ];
    collectCommonParams(params);
    if (ListMeta.debug) alert("params:" + params);
    OrionCore.doAsyncFormAction(SAE.context + ListMeta.updateItemDo, params, onAddItemSuccess, onAddItemFail);
}

function onAddItemSuccess(response)
{
    if (ListMeta.debug) alert( "onAddItemSuccess:" + response)
    var result = false;
    if (response != "") {
        refreshTable();
        setListdirty(true);
        initJsonRules(response);
        result = true;
    }else{
        AddItem(_Result.Error);
    }

   return result;
}

function onAddItemFail(response)
{
    ListMeta.bShowModal = false;
    if (ListMeta.debug) alert("onAddItemFail");
    return false;
}

function EditItem(resultType)
{
    if(resultType==null) resultType = _Result.Success;
    //**var selectedIds = OrionTable.selected(ListMeta.tableName);
    var selectedIds = TableHelper.getSelectedItems(ListMeta.tableName);
    var lSelected = selectedIds.split(",", 1);  // limit to one

    if (lSelected.length == 1)
    {
        var params = [
                "epoPsoId", $('epoPsoId').value,
                "selected", lSelected[0],
                "resultType", resultType
                ];
        collectCommonParams(params);
        if (ListMeta.debug) alert(SAECore.createQueryString(params))
        OrionCore.dialogBoxOkHandler = onOkButtonPressed_EditItem;
        OrionCore.setDialogBoxTitle( ListMeta.editItemTitle );

        var flags = OrionCore.DIALOG_OK_CANCEL;
        flags.width = 500;
        flags.height = 220;

        OrionCore.showAsyncDialogBox( true, SAE.context + ListMeta.editItemDo +"?" + SAECore.createQueryString(params), flags, onLoad_EditItemDialog );
        ListMeta.bShowModal = true;
        ListMeta.bAddMode = false;
    }
    else{
         alert("debug err: no selected item")
    }

}
function onLoad_EditItemDialog()
{
    if (ListMeta.debug) alert("onLoad_EditItemDialog: ListMeta.updateResult");
}
function itemsCallback()
{

   OrionHelp.setHelpId(ListMeta.manageHelpFile)
   OrionCore.fireResizeEvent();
   return true
}

function testCallback()
{
   setSearchMode(ListMeta.searchModeTest)
   OrionCore.fireResizeEvent();
   return true
}

function searchButtonClicked()
{
    setSearchMode(ListMeta.searchModeFilter);
}

function testSitePatternButtonClicked()
{
    setSearchMode(ListMeta.searchModeTest)
}

function onOkButtonPressed_EditItem()
{
    if (ListMeta.debug) alert("onOkButtonPressed_EditItem");
    SubmitEditItem();
}

function SubmitEditItem()
{
    //**var selectedIds = OrionTable.selected(ListMeta.tableName);
    var selectedIds = TableHelper.getSelectedItems(ListMeta.tableName);
    var lSelected = selectedIds.split(",", 1);  // limit to one
    if (lSelected.length == 1){
        ListMeta.updateItem = new SiteEnfDeviation(lSelected[0], $("_szSiteName").value, $("_szNote").value, $("_szSiteAction").value);
    }
    else{
        alert("debug err: no selected item")
    }
    SubmitEditItemAction(ListMeta.updateItem)
}
function SubmitEditItemAction(sed)
{
    var params = [
            "edittype", _EditType.Edit,
            "selected", sed.id,
            "_szSiteName", sed.siteName,
            "_szNote", sed.siteNote,
            "_szSiteAction", sed.siteAction
        ]
    collectCommonParams(params);
    OrionCore.doAsyncFormAction(SAE.context + ListMeta.updateItemDo, params, onUpdateItemSuccess, onUpdateItemFailed);
}
function onUpdateItemSuccess(response)
{
    if (ListMeta.debug) alert( "onUpdateItemSuccess:" + response)
    var result = false;
    if (response != "") {
        refreshTable();
        setListdirty(true);
        setEnableActionButtons($('addItem'),true);
        setEnableActionButtons($('editItem'),false);
        setEnableActionButtons($('deleteItems'),false);
        initJsonRules(response);
        result = true;
    }else{
        AddItem(_Result.Error);
    }

   return result;
}

function onUpdateItemFailed(response)
{
    ListMeta.bShowModal = false;
    alert("Failed_UpdateItem");
    return false;
}

function RemoveItems()
{
    // Should we prompt for delete?
    SubmitRemoveItems()
}

function SubmitRemoveItems()
{
    //**var selectedIds = OrionTable.selected(ListMeta.tableName)
    var selectedIds = TableHelper.getSelectedItems(ListMeta.tableName);    
    var params =
        [
            "edittype", _EditType.Remove,
            "selected", selectedIds,
            "removeall", $('all_items_selected').value
        ]
    collectCommonParams(params);
    if (ListMeta.debug) alert( "SubmitRemoveItems:" + selectedIds);
    OrionCore.doAsyncFormAction(SAE.context + ListMeta.updateItemDo, params, onRemoveItemsSuccess, onRemoveItemsFail);
}

function onRemoveItemsSuccess(response)
{
    if (ListMeta.debug) alert( "onRemoveItemsSuccess:" + response)
    ListMeta.bShowModal = false;
    if (response != "") {
        refreshTable();
        setEnableActionButtons($('addItem'), true);
        setEnableActionButtons($('editItem'), false);
        setEnableActionButtons($('deleteItems'), false);
        setListdirty(true);
        initJsonRules(response);
    }else{
        AddItem(_Result.Error);
    }

    return true;
}

function onRemoveItemsFail(response)
{
    ListMeta.bShowModal = false;
    alert( "onRemoveItemsFail:" + response);
    return false;
}


function enterPressed(evt)
{
    var code;
    if (!evt) evt = window.event;
    if (evt.keyCode) code = evt.keyCode;
    else if (evt.which) code = evt.which;

    if (code == 13)
    {
        executeSEDFilter();
    }
}
function clearFilter()
{
    $('searchText').value = "";
    SAECore.toggleDivShow(true,'clearHint');
    SAECore.toggleDivShow(false,'searchHint');
    SAECore.toggleDivShow(false,'testHint');
    $('searchMode').value = "0";

    var params = collectCommonParams();
    OrionCore.doAsyncFormAction(SAE.context + ListMeta.updateFilterDo, params, Success_ExecuteFilter, null);
    OrionCore.setEnabledById("clearFilterButton", false);
}

function setSearchMode(searchMode)
{
    switch(searchMode)
    {
        case ListMeta.searchModeFilter:
            $('searchMode').value = "0";
            SAECore.toggleDivShow(true,'searchHint');
            SAECore.toggleDivShow(false,'clearHint');
            SAECore.toggleDivShow(false,'testHint');

            //**OrionTable.resizeTables(ListMeta.tableName);
            TableHelper.resizeTable(ListMeta.tableName)
            executeSEDFilter()
            break;

        case  ListMeta.searchModeTest:
            $('searchMode').value = "1";
            SAECore.toggleDivShow(true,'testHint');
            SAECore.toggleDivShow(false,'clearHint');
            SAECore.toggleDivShow(false,'searchHint');

            //**OrionTable.resizeTables(ListMeta.tableName);
            TableHelper.resizeTable(ListMeta.tableName)
            executeSEDFilter()
            break;

       default:
       		alert("error: unknown search mode")
       		break;
    }
}
function applySEDFilter()
{
    executeSEDFilter()
}
function executeSEDFilter()
{
    var params = collectCommonParams();
    OrionCore.doAsyncFormAction(SAE.context + ListMeta.updateFilterDo, params, Success_ExecuteFilter, null);
    if (trim($('searchText').value) != "")
    {
        OrionCore.setEnabledById("clearFilterButton", true);
    }
}

function Success_ExecuteFilter()
{

    initActionButtons();
    //**OrionTable.refresh(ListMeta.tableName ,null,OrionTable.tableParameters[ListMeta.tableName].visibleRows);
    TableHelper.refreshDeselect(ListMeta.tableName);
}


function trim(str){
    var result = str
    if (str != null && str !== undefined ){
        result =  str.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
    }
    return result
}
function setAllInAllPagesInput(selected)
{

    if (selected){
       $('all_items_selected').value = "1";
    }
    else{
       $('all_items_selected').value = "0";
    }

}
function refreshTable()
{
    ListMeta.bShowModal = false;
    if (ListMeta.debug) alert("RefreshTable")
    //**var selected = OrionTable.selected(ListMeta.tableName);
    //**OrionTable.refresh(ListMeta.tableName);
    TableHelper.refreshDeselect(ListMeta.tableName);
    //stateChangeHandler(true,OrionForm.isFormValid())
    ListMeta.updateItem = null;
    ListMeta.updateResult = _Result.Success;
    //**OrionTable.selectAll(ListMeta.tableName, false)
    return true
}
function refreshTableFilter()
{
    ListMeta.bShowModal = false;
    if (ListMeta.debug) alert("RefreshTable")
    //**var selected = OrionTable.selected(ListMeta.tableName);
    //**OrionTable.refresh(ListMeta.tableName);
    TableHelper.refreshDeselect(ListMeta.tableName);
    //stateChangeHandler(true,OrionForm.isFormValid())
    ListMeta.updateItem = null;
    ListMeta.updateResult = _Result.Success;

    return true
}

function _checkboxCallback(rowIndex, rowUID, checked)
{

    //**var selectedItems = OrionTable.selected(ListMeta.tableName);
    var selectedItems = TableHelper.getSelectedItems(ListMeta.tableName);
    //**var state = OrionTable.getSelectionType( ListMeta.tableName )
    //**var state = TableHelper.getSelectionType(ListMeta.tableName);
    var lItems = [];


    setAllInAllPagesInput(false);

    setEnableActionButtons($('addItem'),true)

    if  (selectedItems)
    {
        lItems = selectedItems.split(',')
    }
    if (lItems.length == 0)
    {
        setEnableActionButtons($('editItem'),false)
        setEnableActionButtons($('deleteItems'),false)
    }
    else if (lItems.length == 1)
    {
        setEnableActionButtons($('editItem'),true)
        setEnableActionButtons($('deleteItems'),true)
    }
    if (lItems.length > 1)
    {
        setEnableActionButtons($('editItem'),false)
        setEnableActionButtons($('deleteItems'),true)
    }
    //else if (state == OrionTable.SELECTION_ALLPAGES)   TableHelper.allRowSelected(ListMeta.tableName)
    else if (TableHelper.allRowSelected(ListMeta.tableName))
    {
        setEnableActionButtons($('editItem'),false)
        setEnableActionButtons($('deleteItems'),true)
        setAllInAllPagesInput(true);
    }
}
function setEnableActionButtons(obj, enabled)
{
    if (_Policy.readOnlyMode)
    {
        OrionCore.setEnabled(obj, false)
    }
    else
    {
        OrionCore.setEnabled(obj, enabled)
    }
}

function validateDeviations(pattern)
{
     if (ListMeta.bAddMode == false)
     {
         return validateSiteName(pattern)
     }
     else
     {
         return validateEnfDeviations(pattern)
     }
}

function validateSiteName(pattern)
{
    $('errorTextId').innerHTML = "";
    var valid = true
    if ("undefined" == typeof(pattern) || null == pattern){
        pattern = "";
    }
    else{
        pattern = trim(pattern)
    }

    if(pattern.match(_Validate.invalidChars))
    {
            $('errorTextId').innerHTML = $('invalidChars').innerHTML
            valid = false
    }
    else if(pattern.length < _Validate.minPatternSize)
    {
            $('errorTextId').innerHTML = $('minPatternSize').innerHTML
            valid = false
    }
    else if (ListMeta.updateItem != null && ListMeta.updateResult == _Result.NonUniqueError)
    {
        if (trim(pattern.toLocaleLowerCase()) == ListMeta.updateItem.siteName.toLocaleLowerCase()){
            $('errorTextId').innerHTML = $('notUnique').innerHTML
            valid = false;
        }
    }

    return valid
}

var repositoryListDirtyFlag = false;
function setListdirty(dirty)
{
    ListMeta.bListDirty = dirty;
    OrionForm.revalidate();
}
function onFormStateChange(isDirty, isValid)
{
    if (ListMeta.bShowModal){
        if (isValid){
             OrionCore.enableDialogBoxOkButton(true)
        }
        else{
            OrionCore.enableDialogBoxOkButton(false)
        }
    }
    else{
        if (isValid && (ListMeta.bListDirty || isDirty || dirtyReedit)){
            epoEnableApplyButton();
        }
        else{
            epoDisableApplyButton();
        }
    }
}

// Core Load handler for things to run when the page loads.
OrionCore.addLoadHandler(function()
{
    _setDefaults();
    checkEffectiveMode();
    OrionCore.fireResizeEvent();
     initJSP();

    repositoryListDirtyFlag = true;
    //OrionCore.addResizeHandler( onResizeHandler );
    OrionForm.setStateChangeHandler(onFormStateChange);
    //if (dirtyReedit){
        onFormStateChange(false, true)
    //}
});

function checkEffectiveMode()
{
    if(_Policy.effectivePolicyMode)
    {
        SAECore.toggleDivShow(false,"obID_Duplicate" )
        SAECore.toggleDivShow(false,"obID_Apply" )        
        SAECore.toggleDivShow(false,"actionFooter" )
    }

}

// This is the default funciton called by the save button on the UI
function epoApplyPolicySettings()
{
    OrionCore.showPleaseWait( true );
    if (ListMeta.onEpoApplyCallback)
    {
        ListMeta.onEpoApplyCallback();
    }
    var params = collectCommonParams();
    OrionCore.doAsyncFormAction(SAE.context + ListMeta.savePolicyDo, params, _epoApplyPolicySuccess, _epoApplyPolicyFailure);

    return false;
}

// Submit Success callback
function _epoApplyPolicySuccess()
{
    OrionCore.showPleaseWait( false );
    fnGoBack();
}
function _epoApplyPolicyFailure()
{
    alert(_STRINGS["policySave_fail"]);
    return false;
}

function popError(title, error)
{
    OrionCore.setDialogBoxTitle( title );
    OrionCore.showDialogBox( true, error, OrionCore.DIALOG_OK );
}


