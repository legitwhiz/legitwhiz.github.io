var _Result =
{
  Success: 0,
  NonUniqueError: 1,
  TooShort: 3,
  GeneralError: 4,

  _:0
}
var _EditType =
{
  Add: 0,
  Edit: 1,
  Remove: 2
}
var _Validate =
{
    minPatternSize: 3,
    invalidChars: /[* <>\\]/,
    _:0
}




function validatePattern(pattern, withInfo)
{
    $('errorTextId').innerHTML = "";
    var valid = true
    var htmlPattern;
    if ("undefined" == typeof(pattern) || null == pattern){
        pattern = "";
    }
    else{
        htmlPattern = trim(pattern)
    }
    htmlPattern = htmlPattern.replace(/</g, "&lt;")
    htmlPattern = htmlPattern.replace(/>/g, "&gt;")
    var lineSrc =  "\"" + htmlPattern + "\"" + "<br>"

    if(pattern.match(_Validate.invalidChars))
    {
            $('errorTextId').innerHTML = $('invalidChars').innerHTML
            valid = false
    }
    else if(pattern.length < _Validate.minPatternSize)
    {
            $('errorTextId').innerHTML = $('minPatternSize').innerHTML
            valid = false
    }
    if (!valid && withInfo){

        $('errorTextId').innerHTML = lineSrc + $('errorTextId').innerHTML
    }
    return valid;

}


function validateEnfDeviations(text)
{
    if (text == null){
        text = $('_szSiteName').value
    }
    var valid = false;
    if (text != null)
    {
        var list = text.split("\n");
        if (list != null)
        {
            for (var key in list)
            {
                //var line = list[key]
                var pattern = list[key]
                //CHANGE: removed the ability to have a space between urls. That was the old multi-add functionality
               // var ed = line.split( new RegExp( "[\\s+]{1}", "g" ),2 );
                //var pattern = ed[0];
                var validPattern = true;
                if (pattern !== undefined && trim(pattern) != "") {    //pattern  key
                    validPattern = validatePattern(pattern, true);     //pattern  key
                }
                if (!validPattern)
                {
                     return false;
                }
                //check the next

            }
            // all passed
            valid = true;
        }
    }
    return valid
}