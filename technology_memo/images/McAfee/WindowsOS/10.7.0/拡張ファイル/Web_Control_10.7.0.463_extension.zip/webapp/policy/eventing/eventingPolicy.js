var manageVisitOptionDependencies = function()
{
    _Eventing.manageUserNameCaptureInEvents()

    var visitsEnabled = $('bEnableVisitEvents').checked;
    var ele = $('visitGreenCatDependent')
    if (ele && typeof(ele) == "object")
    {
       OrionCore.toggleEnabled(visitsEnabled, 'visitGreenCatDependent');    
    }
    OrionCore.toggleEnabled(visitsEnabled, 'visitEventTrackingDependent');
}
var manageHitOptionDependencies = function()
{
    _Eventing.manageUserNameCaptureInEvents()
    
    var ele = $('bEnableHitEvents')
    if (ele && typeof(ele) == "object")
    {
        var hitsEnabled = $('bEnableHitEvents').checked
        OrionCore.toggleEnabled(hitsEnabled, 'hitEventTrackingDependent');
        OrionCore.toggleEnabled(hitsEnabled, 'webReporterDiv');       
    }
}

 var manageUserNameCaptureInEvents = function()
 {
    var ele1 = $('bEnableHitEvents')
    var ele2 = $('bEnableVisitEvents')

    var bUserEnable = false;

    if( ele1 && typeof(ele1) == "object")
    {
       bUserEnable = $('bEnableHitEvents').checked
       OrionCore.toggleEnabled(bUserEnable, 'userCaptureDependent');
    }

    if( ele2 && typeof(ele2) == "object" )
    {
        if( !bUserEnable )
        {
            bUserEnable = $('bEnableVisitEvents').checked
            OrionCore.toggleEnabled(bUserEnable, 'userCaptureDependent');
        }
    }
 }

var _Eventing =
{
    savePolicyDo: "SaveEventingPolicy.do",
    manageVisitOptionDependencies: manageVisitOptionDependencies,
    manageHitOptionDependencies: manageHitOptionDependencies,
    manageUserNameCaptureInEvents: manageUserNameCaptureInEvents,
    privateIPNever:  "0",
    privateIPOffNet: "1",
    privateIPAlways: "2",
    _:0
}
var _Policy =
{
    readOnlyMode:false,

    _:0
}

var repositoryListDirtyFlag = false;

function onFormStateChange(isDirty, isValid)
{
    if ((isDirty || repositoryListDirtyFlag) && isValid){
        epoEnableApplyButton();
    }
    else{
        epoDisableApplyButton();
    }
}

// Core Load handler for things to run when the page loads.
OrionCore.addLoadHandler(function()
{
    _setDefaults();
    _setTabStrip();
    repositoryListDirtyFlag = false;
    OrionForm.setStateChangeHandler(onFormStateChange);
    //onFormStateChange(true, true);
});


// This is the default funciton called by the save button on the UI
function epoApplyPolicySettings()
{
    // Save to EPO

    OrionCore.doAsyncFormAction(SAE.context + _Eventing.savePolicyDo, null, _epoApplyPolicySuccess, _epoApplyPolicyFailure);

    return false;
}

// Submit Success callback
function _epoApplyPolicySuccess()
{
    OrionCore.showPleaseWait( false );
    fnGoBack();
}

// Submit Failure callback
function _epoApplyPolicyFailure()
{
    alert(_STRINGS["policySave_fail"]);
    return false;
}

// This function runs on page load. It runs through various properties on the UI
// and sets defaults (Checkboxes, AddWidgets, etc.)
function _setDefaults()
{

    OrionHelp.setHelpId("ewc_1050/source/pageref/sae_ref_events.html")
    _Eventing.manageVisitOptionDependencies()
    _Eventing.manageHitOptionDependencies()
    _Eventing.manageUserNameCaptureInEvents()
    _Policy.readOnlyMode = eval(_VALUES["readOnlyMode"])

    setPrivateIPEventMode(_VALUES["uiPrivateIPEventingMode"], "visits")
    setPrivateIPEventMode(_VALUES["uiPrivateIPEventingHitsMode"], "hits")

    if (_Policy.readOnlyMode){
        OrionCore.toggleEnabled(false, 'eventingDiv');
    }

    OrionForm.rescan();
}

function setPrivateIPEventMode(mode, radioPrefix)
{
    var ele = $(radioPrefix + 'privateIPNever');
    if (ele && typeof(ele) == "object")
    {
        switch(mode)
        {
            case _Eventing.privateIPNever:
                $(radioPrefix + 'privateIPNever').checked = true;
                break;

            case _Eventing.privateIPAlways:
                $(radioPrefix + 'privateIPAlways').checked = true;
                break;

            case _Eventing.privateIPOffNet:
            default:
                $(radioPrefix + 'privateIPOffNet').checked = true;
                break;
        }
    }
    var ss = $(radioPrefix + 'privateIPNever')
}
// This instantiates the swappable tabstrip
function _setTabStrip()
{

}
function confirmWebreporterPassword()
{
    return $("szWebreporterPassword").value == $("szWebreporterPassword2").value;
}




