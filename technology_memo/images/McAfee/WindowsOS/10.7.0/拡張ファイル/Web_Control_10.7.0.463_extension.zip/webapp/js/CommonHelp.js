OrionHelp.showHelp = function() {
    var topPosition = (screen.availHeight-600)/2;
    var leftPosition = (screen.availWidth-800)/2;
    var c=window.open("https://docs.mcafee.com","helpwindow" ,"width=800,height=600,top="+topPosition+",left="+leftPosition+
                            ",scrollbars=no,status=no,resizable=yes,toolbar=no");
    c.focus();
}