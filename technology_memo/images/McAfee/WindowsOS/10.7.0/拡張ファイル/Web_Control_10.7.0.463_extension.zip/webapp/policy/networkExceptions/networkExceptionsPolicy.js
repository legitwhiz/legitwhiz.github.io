var _NetExceptions =
{
    savePolicyDo: "SaveNetworkExceptionsPolicy.do",
    _:0
}
var _Policy =
{
    readOnlyMode:false,

    _:0
}

var repositoryListDirtyFlag = false;

function onFormStateChange(isDirty, isValid)
{
    if ((isDirty || repositoryListDirtyFlag) && isValid){
        epoEnableApplyButton();
    }
    else{
        epoDisableApplyButton();
    }
}

// Core Load handler for things to run when the page loads.
OrionCore.addLoadHandler(function()
{
    _setDefaults();
    _setTabStrip();
    repositoryListDirtyFlag = false;
    OrionForm.setStateChangeHandler(onFormStateChange);
    //onFormStateChange(true, true);
});


// This is the default funciton called by the save button on the UI
function epoApplyPolicySettings()
{
    // Save to EPO

    OrionCore.doAsyncFormAction(SAE.context + _NetExceptions.savePolicyDo, null, _epoApplyPolicySuccess, _epoApplyPolicyFailure);

    return false;
}

// Submit Success callback
function _epoApplyPolicySuccess()
{
    OrionCore.showPleaseWait( false );
    fnGoBack();
}

// Submit Failure callback
function _epoApplyPolicyFailure()
{
    alert(_STRINGS["policySave_fail"]);
    return false;
}

// This function runs on page load. It runs through various properties on the UI
// and sets defaults (Checkboxes, AddWidgets, etc.)
function _setDefaults()
{
    OrionHelp.setHelpId("ewc_1050/source/pageref/sae_ref_enable_disable_pol.html")


    _Policy.readOnlyMode = eval(_VALUES["readOnlyMode"])

    if (_Policy.readOnlyMode){
        OrionCore.toggleEnabled(false, 'netExceptionsDiv');
    }

    OrionForm.rescan();
}

function tunePermitUIOptions()
{
    var permit = $('bEnableDSSLookupPrivateIP').checked;
    OrionCore.toggleEnabled(permit,"permitClientDiv");
    tuneClientUIOptions(_FS.clientEnabledMode)
}

// This instantiates the swappable tabstrip
function _setTabStrip()
{

}




