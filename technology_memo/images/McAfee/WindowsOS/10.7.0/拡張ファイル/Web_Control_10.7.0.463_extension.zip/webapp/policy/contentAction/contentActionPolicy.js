var _PolicyConst =
{
    savePolicyDo: "SaveContentFilteringPolicy.do",
    enforceBasic: "0",
    enforceAdvanced: "1",
    actionType: {allow:"0",warn:"1",block:"2"},
    lActions: ["Allow", "Warn", "Block"],
    lRatings: ["Yellow", "Red", "Unrated"],
    downgradeRatings: ["Red", "Yellow"],
    facetNames: ["Phishing", "Downloads", "Spam", "Popups", "Badlinker", "Exploit"],

    _:0
}

var _Policy =
{
    siteEnforceMode: "0",
    bSiteObserve: false,
    bSiteResourceObserve: false,
    effectivePolicyMode: false,
    readOnlyMode: false,
    lastEnforcementMode: 0,

    _:0
}

var repositoryListDirtyFlag = false;

function onFormStateChange(isDirty, isValid)
{
    if ((isDirty || repositoryListDirtyFlag) && isValid){
        epoEnableApplyButton();
    }
    else{
        epoDisableApplyButton();
    }
}

// Core Load handler for things to run when the page loads.
OrionCore.addLoadHandler(function()
{
    _setDefaults();
    repositoryListDirtyFlag = false;
    setPageState("${pageState}");
    OrionForm.rescan();
    OrionForm.setStateChangeHandler(onFormStateChange);
    OrionForm.revalidate();
});

function getSelectInputName(name)
{
    return "_" + name;
}

function _syncSelectHiddenInputs(actionMeta)
{
    for(var actionId in actionMeta)
    {
        //alert("actionId:" + actionId + " actionMeta[actionId]:" + actionMeta[actionId])
        setSelectHiddenInput(actionId, actionMeta[actionId])
    }
}


function setSelectHiddenInput(selectId, lActions)
{
    var rSel, rating;

    for (var i = 0; i < _PolicyConst.lRatings.length; i++)
    {
        rating = _PolicyConst.lRatings[i]
        rSel = $(getSelectInputName(selectId + rating))
        if (rSel)
        {
            var inp = $(selectId + rating)
            inp.value = rSel.options[rSel.selectedIndex].value
        }
    }
}
// This is the default function called by the save button on the UI
function epoApplyPolicySettings()
{
    // Save to EPO
    _syncSelectHiddenInputs(ActionMeta);
    setWebCategoryActions();
    OrionCore.doAsyncFormAction(SAE.context + _PolicyConst.savePolicyDo, null, _epoApplyPolicySuccess, _epoApplyPolicyFailure);

    return false;
}

// Submit Success callback
function _epoApplyPolicySuccess()
{
    OrionCore.showPleaseWait( false );
    fnGoBack();
}

// Submit Failure callback
function _epoApplyPolicyFailure()
{
    alert(_STRINGS["policySave_fail"]);
    return false;
}

function setRatingActionsSelections(actionMeta)
{
    for(var actionId in actionMeta)
    {
        //alert("actionId:" + actionId + " actionMeta[actionId]:" + actionMeta[actionId])
        setRatingActionsSelection(actionId, actionMeta[actionId])
    }
}

function setRatingActionsSelection(selectId, lActions)
{
    var rSel;

    for (var i in _PolicyConst.lRatings)
    {
        rating = _PolicyConst.lRatings[i];
        rSel = $(getSelectInputName(selectId + rating))
        //alert("selectId:" + selectId + " rating:" + rating + " rSel:" + rSel)
        if (rSel)
        {
            //alert("i:" + i + "  lActions[i++]:" +lActions[(i+1)])
            for (var j = 0; j <  lActions.length; j++)
            {
                if (rSel.options[j].value == lActions[i])
                    rSel.selectedIndex = j;
            }
            //rSel.selectedIndex = lActions[i++]
            //alert("rSel.selectedIndex:" + rSel.selectedIndex)
        }
    }
}

// This function runs on page load. It runs through various properties on the UI
// and sets defaults (Checkboxes, AddWidgets, etc.)
function _setDefaults()
{
    checkEffectiveMode();
    _Policy.readOnlyMode = eval(_VALUES["readOnlyMode"])
    setRatingActionsSelections(ActionMeta);

    if (_Policy.readOnlyMode)
    {
        OrionCore.setEnabled($("_uiOverallRed"), false);
        OrionCore.setEnabled($("_uiOverallYellow"), false);
        OrionCore.setEnabled($("_uiOverallUnrated"), false);
        OrionCore.setEnabled($("_uiSiteResourceFileDownloadRed"), false);
        OrionCore.setEnabled($("_uiSiteResourceFileDownloadYellow"), false);
        OrionCore.setEnabled($("_uiSiteResourceFileDownloadUnrated"), false);

        OrionCore.setEnabled($("enableWebCategory"), false);
        OrionCore.setEnabled($("blockAllWebCategoriesButton"), false);
        OrionCore.setEnabled($("unBlockAllWebCategoriesButton"), false);
    }
    OrionForm.rescan();
}

function checkEffectiveMode()
{

    if (_Policy.effectivePolicyMode)
    {
        // hide share button
        var btnShare = $("obID_Share");
        if (btnShare != null)
        {
            SAECore.toggleDivShow(false, 'obID_Share');
        }

        // hide save button
        var btnSave= $("obID_Apply");
        if (btnSave != null)
        {
            SAECore.toggleDivShow(false, 'obID_Apply');
        }

        // hide duplicate button
        var btnDuplicate = $("obID_Duplicate");
        if (btnDuplicate != null)
        {
            SAECore.toggleDivShow(false, 'obID_Duplicate');
        }

        // hide action footer button
        var btnActionFooter = $("actionFooter");
        if (btnActionFooter != null)
        {
            SAECore.toggleDivShow(false, 'actionFooter');
        }

        var btnCancel = $("obID_Cancel");
        if(btnCancel)
        {
            var oDiv = $('obID_Cancel');
            if (oDiv !== undefined && oDiv.onclick !== undefined)
            {
                oDiv.onclick =  fnOverrideCancel;
            }
        }
    }
}

function fnOverrideCancel()
{
    OrionCore.doAction("/PolicyMgmt/EpoGoBackToEditAssignment.do");
}

/* Disables all web categories check boxes*/
function disableWebCategories(){
    for (var i = 1; i <=  wcDataList.length; i++){
        var rowID = "webCategoryTableDiv_lwrow_" + i;
        var checkboxID;
        var ruleItem = g_webCategoryListWidget.getItem(rowID);
        if(typeof ruleItem == 'undefined'){
            continue;
        }
        checkboxID = rowID + "_checkbox0";
        $(checkboxID).disabled = true;
    }
}

//******************* Web Category Blocking Functions ****************************
WebCategoryActionData = function(obj)
{
    var name = "";
    var id = "";
    var code = "";
    var action = 0;
}

/* prepares and sets web category actions to be sent to ePO server.*/
function setWebCategoryActions(){
    var wcActions = '';
    var wcMap = new Object();
    var uncategorizedWCIndex;

    for (var i = 1; i <=  wcDataList.length; i++){
        var rowID = "webCategoryTableDiv_lwrow_" + i;
        var checkboxID = rowID + "_checkbox0";
        if($(checkboxID) != null){
            var ruleItem = g_webCategoryListWidget.getItem(rowID);
            var index = rowID.substr(26) - 1;
            if($(checkboxID).checked){
                wcDataList[index].action = 2;
            }else{
                wcDataList[index].action = 0;
            }
            wcMap[wcDataList[index].code] = wcDataList[index];

            if (wcDataList[index].id == uncategorizedWCId)
            {
                uncategorizedWCIndex = index;
            }
        }
    }

    for (var idx in policyBitCodes){
        if(wcMap[policyBitCodes[idx]].action == "2"){
            wcActions = wcActions + '2';
        }else{
            wcActions = wcActions + '0';
        }
    }

    $("uiWcActions").value = wcActions;

    if (wcDataList[uncategorizedWCIndex].action == 2)
        $("uiUncategorisedBlocked").value = 2;
    else
        $("uiUncategorisedBlocked").value = 0;
}

function prepareWCBean(){
    for(var j = 0; j < wcBitIds.length; ++j)
    {
        var wcData = new WebCategoryActionData();
        wcData.name = wcNames[j];
        wcData.id = wcBitIds[j];
        wcData.code = wcBitCodes[j];
        wcData.action = wcActions[j];

        wcDataList[j] = wcData;
    }
}

function _webCategoryListsInit(){
    g_webCategoryListWidget = new VSE.ListWidget({
        container: "webCategoryTableDiv",
        readonly: "false",
        includeCheckbox: "true",
        objectName: "g_webCategoryListWidget",
        width: "483",
        height: "318",
        checkboxCount: 1,
        addCallback: webCategoryListAddCallBack,
        checkboxCallback: webCategoryListCheckboxOnClickCallback,
        onchangeSelectionCallback: webCategoryList_onSelectionChange,
        showZebra: true
    });
}

function initWebCategoryData(){
    g_webCategoryListWidget.clearList();

    for (var idx in wcDataList)
    {
        var item = new VSE.ListItem();
        item.displayText = wcDataList[idx].name;
        item.itemData = wcDataList[idx];
        g_webCategoryListWidget.add(item);
    }
}

/* Function to block and unblock all web categories*/
function blockAllWebCategories(isBlock){

    repositoryListDirtyFlag = true;
    for (var i = 1; i <=  wcDataList.length; i++)
    {
        var rowID = "webCategoryTableDiv_lwrow_" + i;
        var checkboxID;
        var ruleItem = g_webCategoryListWidget.getItem(rowID);
        if(typeof ruleItem == 'undefined'){
            continue;
        }
        if (isBlock)
        {
            checkboxID = rowID + "_checkbox0";
            $(checkboxID).checked = true;
        }
        else
        {
            checkboxID = rowID + "_checkbox0";
            $(checkboxID).checked = false;
        }
    }
    onFormStateChange(true, true);
}

function toggleWebCategoryBlockingSection(checkBoxStatus)
{
    if(checkBoxStatus)
    {
        $("enableWebCategory").value = 'on';
        $("webCategoryBlockingSection").style.display = '';
    }
    else
    {
        $("enableWebCategory").value = 'off';
        $("webCategoryBlockingSection").style.display = 'none';
        onFormStateChange(true, true);
    }
}

/* sets the web categories check boxes based on the actions received from server.*/
function setWCCheckBoxes()
{
    for (var i = 1; i <=  wcDataList.length; i++)
    {
        var rowID = "webCategoryTableDiv_lwrow_" + i;
        var checkboxID = rowID + "_checkbox0";
        var ruleItem = g_webCategoryListWidget.getItem(rowID);

        if(typeof ruleItem == 'undefined')
        {
            continue;
        }

        if(wcDataList[i - 1].action == "2")
        {
            $(checkboxID).checked = true;
        }
        else
        {
            $(checkboxID).checked = false;
        }

    }
}

function webCategoryListCheckboxOnClickCallback(evt)
{
    var checkboxID = "";
    var rowID = "";

    repositoryListDirtyFlag = true;
    if(evt != null)
    {
        checkboxID = evt.target.id;
    }
    else
    {
        checkboxID =  window.event.srcElement.id;
    }

    rowID = $(checkboxID).parentNode.parentNode.id;

    if(rowID != "")
    {
        var ruleItem = g_webCategoryListWidget.getItem(rowID);
        if(ruleItem != null)
        {
            var checkboxNum = checkboxID.replace(rowID + "_", "");
            var index = rowID.substr(26) - 1;//26 is the length of the check box ids prefix

            ruleItem.itemData.blocked = $(checkboxID).checked;
            if(ruleItem.itemData.blocked)
                wcDataList[index].action = 2;
            else
                wcDataList[index].action = 0;
        }
    }
}

function webCategoryList_onSelectionChange()
{
    onFormStateChange(true, true);
}

function webCategoryListAddCallBack()
{
    //not needed as of now.
}