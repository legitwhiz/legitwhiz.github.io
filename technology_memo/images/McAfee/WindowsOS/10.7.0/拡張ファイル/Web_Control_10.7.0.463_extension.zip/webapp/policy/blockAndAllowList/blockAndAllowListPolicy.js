//ListMeta defined in deviationList.js
ListMeta.tableName= 'blockAndAllowList'
ListMeta.editItemDo= 'EditBlockAndAllowItem.do'
ListMeta.updateItemDo= 'UpdateBlockAndAllowItem.do'
ListMeta.updateFilterDo= 'UpdateBlockAndAllowListFilters.do'
ListMeta.savePolicyDo= 'SaveBlockAndAllowListPolicy.do'
ListMeta.addItemTitle= "[addItemTitle]"
ListMeta.editItemTitle= "[editItemTitle]"
ListMeta.onEpoApplyCallback= fnOnEpoApplyCallback

ListMeta.manageHelpFile="ewc_1050/source/pageref/GUID-DCC79149-46BF-41D3-92F8-AD5D6F178CEB.html";
ListMeta.advanceOptionHelpFile="ewc_1050/source/pageref/GUID-EDDCE457-0A6A-4AE7-9D63-3A0D2FF8C49B.html";


 function fnOverrideCancel()
  {
       OrionCore.doAction("/PolicyMgmt/EpoGoBackToEditAssignment.do");
  }

function fnOnEpoApplyCallback()
{
    if (!_Policy.effectivePolicyMode)
    {
        _syncSelectHiddenInputs(ActionMeta);
    }
}

function getSelectInputName(name)
{
    return "_" + name;
}

var _RatingAction =
{
    enforceBasic:"0",
    enforceAdvanced:"1",
    actionType:{allow:"0",warn:"1",block:"2"},
    lActions: ["Allow", "Warn", "Block"],
    lRatings: ["Yellow", "Red", "Unrated"],

    _:0
}

function _syncSelectHiddenInputs(actionMeta)
{
    for(var actionId in actionMeta)
    {
            //alert("actionId:" + actionId + " actionMeta[actionId]:" + actionMeta[actionId])
        setSelectHiddenInput(actionId, actionMeta[actionId])
    }
}

function setSelectHiddenInput(selectId, lActions)
{
    var rSel, rating

    for (var i=0; i <  _RatingAction.lRatings.length; i++)
    {
        rating = _RatingAction.lRatings[i]
        rSel = $(getSelectInputName(selectId + rating))
        if (rSel)
        {
           var inp = $(selectId + rating)
           inp.value = rSel.options[rSel.selectedIndex].value
        }
    }
}
function setRatingActionsSelections(actionMeta)
{
    for(var actionId in actionMeta)
    {
            //alert("actionId:" + actionId + " actionMeta[actionId]:" + actionMeta[actionId])
        setRatingActionsSelection(actionId, actionMeta[actionId])
    }
}
function setRatingActionsSelection(selectId, lActions)
{
    var rSel;

    for (var i in  _RatingAction.lRatings)
    {
        rating =  _RatingAction.lRatings[i];
        rSel = $(getSelectInputName(selectId + rating))
            //alert("selectId:" + selectId + " rating:" + rating + " rSel:" + rSel)
        if (rSel)
        {
            //alert("i:" + i + "  lActions[i++]:" +lActions[(i+1)])
            for (var j=0; j <  _RatingAction.lActions.length; j++)
            {
                if (rSel.options[j].value == lActions[i])
                    rSel.selectedIndex = j;
            }
            //rSel.selectedIndex = lActions[i++]
            i++;
            //alert("rSel.selectedIndex:" + rSel.selectedIndex)
        }
    }
}


// Submit Failure callback
function _epoApplyPolicyFailure()
{
    alert(_STRINGS["policySave_fail"]);
    return false;
}

// This function runs on page load. It runs through various properties on the UI
// and sets defaults (Checkboxes, AddWidgets, etc.)
function _setDefaults()
{
    OrionForm.enableFormProcessing = false;
    if (_Policy.readOnlyMode){
        if ( $('contentAuthOptions') )
        {
            //OrionCore.setEnabled($('contentAuthOptions'), false)
            OrionCore.setEnabled($('bTrack'), false)
            OrionCore.setEnabled($('_uiSiteResourceFileDownloadRed'), false)
            OrionCore.setEnabled($('_uiSiteResourceFileDownloadYellow'), false)
            OrionCore.setEnabled($('_uiSiteResourceFileDownloadUnrated'), false)
            OrionCore.setEnabled($('bPrecedenceOverProhibitLists'), false)
        }
    }
    if (_Policy.effectivePolicyMode) 
    {
        // hide share button
        var btnShare = $("obID_Share");
        if (btnShare != null){
            SAECore.toggleDivShow(false, 'obID_Share');
        }

        var btnCancel = $("obID_Cancel");
        if(btnCancel)
        {
            var oDiv = $('obID_Cancel');
            if (oDiv !== undefined && oDiv.onclick !== undefined)
            {
                oDiv.onclick =  fnOverrideCancel;
           }
        }

    }
    //OrionCore.toggleEnabled(false, 'greenAllowDownload');
    manageDSSOptionDependencies($('bTrack'));
    setRatingActionsSelections(ActionMeta);
    OrionForm.enableFormProcessing = true;
    OrionForm.rescan();

}

function manageDSSOptionDependencies(oCb)
{
    if(oCb && _Policy.readOnlyMode == false)
    {
       OrionCore.toggleEnabled(oCb.checked, 'downloadSelectionsDiv');
    }
}




