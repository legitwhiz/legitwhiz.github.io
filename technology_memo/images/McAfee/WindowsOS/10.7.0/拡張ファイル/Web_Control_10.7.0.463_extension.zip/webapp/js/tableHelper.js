// Helper function to abstract MFS1 tables and MFS2 tables

function TableHelper(){}
new TableHelper();

TableHelper.tableRef = function(id)
{
    if (typeof(MFSTable) == 'undefined') return null;
    return MFSTable.get( id )
}

TableHelper.setChangeHandler = function(id, fnCallback)
{
    table = TableHelper.tableRef(id, fnCallback)
    if (table)
    {
        table.setOnStateChange(fnCallback)
    }
    else
    {
        OrionTable.setCheckboxHandler(id, fnCallback);
    }
}
TableHelper.getSelectedItems = function(id)
{
    var table = TableHelper.tableRef(id);
    var selectedIds
    if (table){
        selectedIds = table.getSelected();
    }
    else{
        selectedIds = OrionTable.selected(id)
    }
    return  selectedIds
}

TableHelper.getSelectionType = function(id)
{
    var table = TableHelper.tableRef(id)
    var state
    if (table)
    {
        state = table.getSelectionType();
    }
    else
    {
        state = OrionTable.getSelectionType(id)
    }
    return state
}

TableHelper.refreshDeselect = function(id)
{
    var table = TableHelper.tableRef(id)
    if (table)
    {
        table.refresh();
        var selectedItems = TableHelper.getSelectedItems(id)
        lItems = selectedItems.split(',')
        table.setSelected(lItems, false);
        table.setSelectAll(false)
       
    }
    else
    {
        //***what**
        //OrionTable.refresh(PolicyMeta.tableName ,null,OrionTable.tableParameters[PolicyMeta.tableName].visibleRows);
        OrionTable.refresh(id)
        var selectedItems = TableHelper.getSelectedItems(id)
        lItems = selectedItems.split(',')
        OrionTable.setSelected(id, lItems, false);
        OrionTable.selectAll(id, false)
    }

}
TableHelper.allRowSelected = function(id)
{
    var result = false;
    var table = TableHelper.tableRef(id)
    var state = TableHelper.getSelectionType(id)
    if (table){
        result = (state == MFSTable.SELECTION_ALL)
    }
    else{
        result = (state == OrionTable.SELECTION_ALLPAGES)
    }
    return result;
}
TableHelper.resizeTable = function(id)
{
    var result = false;
    var table = TableHelper.tableRef(id)
    if (table){
        //** TBD - may not be needed.
    }
    else{
        OrionTable.resizeTables(id);
    }
    return result;
}
