#include <dcmpsvr.h>

main () 
{
      dc_mcf_svstart ();
}
