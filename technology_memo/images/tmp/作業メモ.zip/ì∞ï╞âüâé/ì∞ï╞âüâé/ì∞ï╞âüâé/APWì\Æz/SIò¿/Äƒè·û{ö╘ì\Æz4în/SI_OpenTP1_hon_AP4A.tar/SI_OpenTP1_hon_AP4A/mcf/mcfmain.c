#include <dcmtcp.h>

main () 
{
      dc_mcf_svstart ();
}
