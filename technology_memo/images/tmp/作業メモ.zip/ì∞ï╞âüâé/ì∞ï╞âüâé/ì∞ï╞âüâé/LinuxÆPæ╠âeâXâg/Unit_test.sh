####### 01.ユーザ・グループ #####
ls -l /etc/passwd
cat /etc/passwd
#################################
ls -l /etc/shadow
cat /etc/shadow
#################################
ls -l /etc/group
cat /etc/group

####### 02.プロファイル定義 #####
ls -l /etc/profile
cat /etc/profile
#################################
ls -l /etc/bashrc
cat /etc/bashrc
#################################
ls -l /root/.bashrc
cat /root/.bashrc
#################################
ls -l /home/PPadm/.bashrc
cat /home/PPadm/.bashrc
#################################
ls -l /home/PPadm2/.bashrc
cat /home/PPadm2/.bashrc
#################################
ls -l /home/IBoprt/.bashrc
cat /home/IBoprt/.bashrc
#################################
ls -l /home/PPadm/.rhosts
cat /home/PPadm/.rhosts
#################################
ls -l /home/PPadm2/.vimrc
cat /home/PPadm2/.vimrc

####### 03.ネットワーク定義 #####
ls -l /etc/hosts
cat /etc/hosts
#################################
ls -l /etc/sysconfig/network
cat /etc/sysconfig/network
#################################
ls -l /etc/modprobe.conf
cat /etc/modprobe.conf
#################################
ls -l /etc/sysconfig/network-scripts/ifcfg-hbond0
cat /etc/sysconfig/network-scripts/ifcfg-hbond0
#################################
ls -l /etc/sysconfig/network-scripts/ifcfg-hbond1
cat /etc/sysconfig/network-scripts/ifcfg-hbond1
#################################
ls -l /etc/sysconfig/network-scripts/ifcfg-eth0
cat /etc/sysconfig/network-scripts/ifcfg-eth0
#################################
ls -l /etc/sysconfig/network-scripts/ifcfg-eth1
cat /etc/sysconfig/network-scripts/ifcfg-eth1
#################################
ls -l /etc/sysconfig/network-scripts/ifcfg-eth2
cat /etc/sysconfig/network-scripts/ifcfg-eth2
#################################
ls -l /etc/sysconfig/network-scripts/ifcfg-eth3
cat/etc/sysconfig/network-scripts/ifcfg-eth3
#################################
ls -l /etc/sysconfig/network-scripts/ifcfg-eth4
cat /etc/sysconfig/network-scripts/ifcfg-eth4
#################################
ls -l /etc/sysconfig/network-scripts/ifcfg-eth5
cat /etc/sysconfig/network-scripts/ifcfg-eth5
#################################
ls -l /etc/sysconfig/network-scripts/ifcfg-eth6
cat /etc/sysconfig/network-scripts/ifcfg-eth6
#################################
ls- l /etc/sysconfig/network-scripts/ifcfg-eth7
cat /etc/sysconfig/network-scripts/ifcfg-eth7
#################################
ifconfig -a
#################################
netstat -r

####### 04.lvol、マウント設定 #####
fdisk -l
#################################
pvdisplay -C
#################################
vgdisplay -C
#################################
lvdisplay -C
#################################
df
#################################
ls -l /etc/fstab
cat /etc/fstab


####### 05.システムログ定義 #####
ls -l /etc/syslog.conf
cat /etc/syslog.conf
#################################
ls -l /etc/logrotate.conf
cat /etc/logrotate.conf
#################################
ls -l /etc/logrotate.d/syslog
cat /etc/logrotate.d/syslog


####### 06.時刻同期定義 #####
ls -l /etc/ntp.conf
cat /etc/ntp.conf
#################################
ls -l /etc/sysconfig/ntpd
cat /etc/sysconfig/ntpd

####### 07.カーネルパラメータ #####
ls -l /etc/sysctl.conf
cat /etc/sysctl.conf
#################################
ls -l /etc/security/limits.conf
cat /etc/security/limits.conf
#################################
sysctl -a


####### 08.使用ポート一覧 #####
ls -l /etc/services
cat /etc/serices

####### 09.インストールパッケージ #####
rpm -qa

####### 10.サービス一覧 #####
chkconfig --list

####### 11.追加パッケージ #####
#09.インストールパッケージの内容に含む

####### 12.SSH定義 #####
ls -l /etc/ssh/sshd_config
cat /etc/ssh/sshd_config

####### 13.その他 #####
ls -l /etc/sysconfig/i18n
cat /etc/sysconfig/i18n
#################################
ls -l /etc/kdump.conf
cat /etc/kdump.conf
#################################
ls -l /etc/sysconfig/syslog
cat /etc/sysconfig/syslog
#################################
ls -l /etc/sysconfig/clock
cat /etc/sysconfig/clock
#################################
ls -l /etc/selinux/config
cat /etc/selinux/config
#################################
ls -l /boot/grub/grub.conf
cat /boot/grub/grub.conf
#################################
ls -l /etc/inittab
cat /etc/inittab
#################################
ls -l /etc/securetty
cat /etc/securetty
#################################
ls -l /etc/sudoers
cat /etc/sudoers
#################################
ls -l /etc/xinetd.conf
cat /etc/xinetd.conf
#################################
ls -l /etc/pam.d/system-auth-ac
cat /etc/pam.d/system-auth-ac
#################################
ls -l /etc/sysconfig/kdump
cat /etc/sysconfig/kdump
#################################
ls -l /etc/pam.d/rsh
cat /etc/pam.d/rsh


####### 14.ディレクトリ構成 #####
find / -type d -print | xargs ls -ld

####### 15.HA Network Driver #####
# 03.ネットワーク定義に含む

####### 16.LinuxToughDump #####
ls -l /opt/hitachi/KToolkit/LTD/conf/ltd.conf
cat /opt/hitachi/KToolkit/LTD/conf/ltd.conf

####### 17.RASLOG #####
ls -l /etc/sysconfig/hraslog
cat /etc/sysconfig/hraslog

