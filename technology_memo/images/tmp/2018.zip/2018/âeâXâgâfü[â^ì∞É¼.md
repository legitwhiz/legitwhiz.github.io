
## ddコマンドでnullデータ生成

```
# time dd if=/dev/zero of=/tmp/01GBfile bs=1024 count=$((1024 * 1024))
1048576+0 レコード入力
1048576+0 レコード出力
1073741824 バイト (1.1 GB) コピーされました、 11.1294 秒、 96.5 MB/秒

real    0m11.223s
user    0m1.192s
sys     0m5.534s
```


## ddコマンドでランダムデータの生成
```
# time dd if=/dev/urandom of=/tmp/01GBfile bs=1024 count=$((1024 * 1024))
1048576+0 レコード入力
1048576+0 レコード出力
1073741824 バイト (1.1 GB) コピーされました、 11.5507 秒、 93.0 MB/秒

real    0m11.554s
user    0m1.033s
sys     0m10.291s
```


## headコマンドでnullデータ生成

```
# time head -c 1073741824 /dev/zero > /tmp/01GBfile
real    0m7.120s
user    0m0.279s
sys     0m1.962s
```

## headコマンドでランダムデータの生成
```
# time head -c 1073741824 /dev/urandom > /tmp/01GBfile
real    0m7.823s
user    0m0.219s
sys     0m7.251s
```

## headコマンドでnullデータ生成(テキストデータ)

headコマンドそのままだと、バイナリデータなので本当にランダムデータを証明するのは難しいので、base64でエンコードすることでテキスト化することができます。

```
# time head -c 1073741824 /dev/zero | base64 > /tmp/01GBfile
real    0m10.730s
user    0m3.427s
sys     0m3.846s
```


## headコマンドでランダムデータ生成(テキストデータ)

```
# time head -c 1073741824 /dev/urandom | base64 > /tmp/01GBfile
real    0m11.292s
user    0m2.627s
sys     0m8.372s
```


## fallocateコマンドでランダムデータ生成(テキストデータ)
```

time /bin/fallocate -l 1GB /tmp/01GBfile
real    0m0.003s
user    0m0.000s
sys     0m0.002s
```

```
time truncate -s 1073741824 /tmp/01GBfile
real    0m0.003s
user    0m0.002s
sys     0m0.000s
```

## sslコマンドでランダムデータ作成
ちなみにsslコマンドでランダムデータを作成してみましたが
ddコマンドより更に遅い結果となりました。

```
time openssl rand 1073741824 > /tmp/01GBfile
real    0m41.208s
user    0m39.349s
sys     0m1.448s
```


## ※一応、各データ作成前にはキャッシュクリアしてから測定しています。
ファイルを削除しキャッシュクリアしてから測定しています。

```
rm /tmp/01GBfile
sync
echo 3 > /proc/sys/vm/drop_caches
free
```

