# Linux脆弱性アセスメント(評価)ツールの使い方

## はじめに

アセスメント(評価)は、情報収集ツールを使用することから始まります。
ネットワーク全体を評価する際は、最初にレイアウトを描いて
実行されているホストを把握します。

ホストの場所を確認したら、それぞれのホストを個別に検査し、
これらのホストにフォーカスするには別のツールセットが必要になります。
どのツールを使用すべきかを知っておくことは、
脆弱性の発見において最も重要なステップです。

## 情報収集ツール

### 1. Nmapを使用したホストのポートスキャン 
    Nmap とは、オープンソースで開発されている高機能なポートスキャンツールです。

nmap - Wikipedi
https://ja.wikipedia.org/wiki/Nmap

Nmap: the Network Mapper - Free Security Scanner
https://nmap.org/

このnmapを使うことで、
あるIPアドレスのコンピューターの使用中のポートを調べたり、
ローカルネットワークに繋がっている
コンピューターの一覧を作ったりすることができます。

#### 1.1. install


```console:nmap install
# yum install nmap 
```


#### 1.2. 使い方

### 2. Nessusを使用した完全サービス型のセキュリティスキャナー

#### 2.1. install

#### 2.2. 使い方

### 3. OpenVASを使用した脆弱性および包括的な脆弱性管理のスキャン

#### 3.1. install

#### 3.2. 使い方

### 4. ウェブサイトの脆弱性を確認するNikto

nikto はオープンソース(GPL)のウェブサーバ・スキャナで、Perl で書かれています。
ウェブサーバに対し包括的なテストを行い、3500を超える潜在的な危険性のあるファイルやCGIをスキャンします。
スキャン項目やプラグインは頻繁に更新され、自動的に更新することができます。



#### 4.1. install
ホームページのトップにDownloadリンクがありますので、そこからソースを取得します。
```
# wget http://www.cirt.net/nikto/nikto-current.tar.gz
tar xzf nikto-current.tar.gz
```


#### 4.2. 使い方

```
$ cd nikto
$ perl nikto.pl
- Nikto v2.03/2.04
---------------------------------------------------------------------------
+ ERROR: No host specified
+ ERROR: No host specified
 
   -Cgidirs+    scan these CGI dirs: 'none', 'all', or values like "/cgi/ /cgi-a/"
   -dbcheck     check database and other key files for syntax errors (cannot be 
abbreviated)
   -evasion+    ids evasion technique
   -Format+     save file (-o) format
   -host+       target host
   -Help        Extended help information
   -id+         host authentication to use, format is userid:password
   -mutate+     Guess additional file names
   -output+     write output to this file
   -port+       port to use (default 80)
   -Display+    turn on/off display outputs
   -ssl         force ssl mode on port
   -Single      Single request mode
   -timeout+    timeout (default 2 seconds)
   -Tuning+     scan tuning
   -update      update databases and plugins from cirt.net (cannot be abbreviated)
   -Version     print plugin and database versions
   -vhost+      virtual host (for Host header)
 + requires a value
```

‘Help’オプションでより詳細な情報を確認できます。

スキャンを開始する前に、スキャン項目やプラグインのアップデートを行います。
```
# perl nikto.pl -update
+ Retrieving 'db_tests'
+ Retrieving 'db_outdated'
+ www.cirt.net message: Please submit your bugs!!
‘db_tests’と’db_outdated’が更新されました。
```

パッケージのアップデートを行っていないウェブサーバを用意しました。
早速80番ポートに対しスキャンしてみましょう。

```
# perl nikto.pl -host <hostname>
- Nikto v2.03/2.04
---------------------------------------------------------------------------
+ Target IP:          127.0.0.1
+ Target Hostname:    <hostname>
+ Target Port:        80
+ Start Time:         2009-07-31 15:02:54
---------------------------------------------------------------------------
+ Server: Apache/2.2.3 (CentOS)
- Allowed HTTP Methods: GET, HEAD, POST, OPTIONS, TRACE
+ OSVDB-877: HTTP method ('Allow' Header): 'TRACE' is typically only used for debugging and should be disabled. This message does not mean it is vulnerable to XST.
+ Apache/2.2.3 appears to be outdated (current is at least Apache/2.2.11). Apache 1.3.41 and 2.0.63 are also current.
+ OSVDB-877: TRACE / : TRACE option appears to allow XSS or credential theft. See http://www.cgisecurity.com/whitehat-mirror/WhitePaper_screen.pdf for details
+ OSVDB-3268: GET /icons/ : Directory indexing is enabled: /icons
+ OSVDB-3233: GET /icons/README : Apache default file found.
+ 3577 items checked: 6 item(s) reported on remote host
+ End Time:        2009-07-31 15:03:18 (24 seconds)
---------------------------------------------------------------------------
+ 1 host(s) tested
 
Test Options: -host kicco.zoo.tricorn.co.jp
---------------------------------------------------------------------------
```

以下の項目が指摘されてます。
1) TRACEメソッドが有効になっている
2) Apacheが最新版(2.2.11)ではない
3) ‘/icons/’のディレクトリ・インデックスが有効になっている
4) ‘/icons/README’ファイルが参照できる

指摘項目に対し以下の対応を行いました。
1) TRACEメソッドを無効化
2) Apacheを最新版(2.2.11)にアップデート
3) ‘/icons/’のディレクトリ・インデックスを無効化
4) ‘/icons/README’ファイルを削除
もう一度スキャンしてみます。

```

- Nikto v2.03/2.04
---------------------------------------------------------------------------
+ Target IP:          127.0.0.1
+ Target Hostname:    kicco.zoo.tricorn.co.jp
+ Target Port:        80
+ Start Time:         2009-07-31 21:05:25
---------------------------------------------------------------------------
+ Server: Apache/2.2.11 (Fedora)
- Allowed HTTP Methods: GET, HEAD, POST, OPTIONS 
+ 3577 items checked: 1 item(s) reported on remote host
+ End Time:        2009-07-31 21:05:35 (10 seconds)
---------------------------------------------------------------------------
+ 1 host(s) tested
 
Test Options: -host kicco.zoo.tricorn.co.jp
```

今度は何も指摘されません。
前回指摘された脆弱性が解消されたことを確認できました。





SSL サイトの診断方法
SSLのサイトを診断するには、以下のパッケージが必要になる（CentOS6)

```
＃ yum install openssl-devel perl perl-Net-SSLeay perl-Crypt-SSLeay
```

診断するコマンドは同様
```
＃　perl ./nikto.pl -h https://127.0.0.1
```


