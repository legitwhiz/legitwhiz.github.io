#!/bin/sh
###################################################################
#
# 1. スクリプト名			：論理JP1停止処理
# 2. ファイル名				：ha_jp1_stop.sh
# 3. 機能				：論理サーバで稼働するJP1を停止する。
# 4. 使用方法				：ha_jp1_stop.sh
# 5. 論理/物理起動			：論理起動
# 6. 記述言語				：sh
# 7. 実行ユーザ				：root
# 8. パーミッション			：755
# 9. 入力パラメータ			：なし
#10. 終了コード				：0   正常終了
#					：40  警告終了
#					：255 異常終了
#11. 入力ファイル			：なし
#12. 出力ファイル			：なし
#13. ログファイル			：/etc/cmcluster/skspkg01/ha_jp1_stop.log
#14. 設計者				：坂本 大輔
#15. 更新履歴				：1.0  2014/03/18 坂本 大輔 新規作成
#							：1.1  2014/05/02 坂本 大輔 NNMi,SSO削除
#
###################################################################

#==================================================================
# 変数設定
#==================================================================
. /pps.env 

PATH="/sbin:/usr/bin:/usr/sbin:/etc:/bin:${PATH}"

# 処理名設定
 JOB_NAME=ha_jp1_stop

# ログディレクトリ
 LOG_DIR=/etc/cmcluster/skspkg01

# ログファイル
 LogFile=${LOG_DIR}/${JOB_NAME}.log

# コマンド実行ユーザ
 ope_username=root

# 実行ユーザー名
 username=`whoami`

# 正常終了戻り値
 normal_end=0

# 警告終了戻り値
 warning_end=40

# 異常終了戻り値
 err_end=255

# コマンド戻り値
 rt_code=0

#==================================================================
# 関数設定
#==================================================================
# 出力メッセージ
 outmessage() {
   sw=$1
   case $sw in
       #処理開始
    1) wk_msg="HASTP101-I Begin to Stop JP1/Base(HA).";;
    
       #処理完了
    2) wk_msg="HASTP102-I Completion to Stop JP1(HA).";;

       #実行ユーザ確認エラー
    3) wk_msg="HASTP103-E ABEND - Check User Failed.";;
    
       #JP1/BASEが停止状態の場合、停止済みメッセージ出力
    4) wk_msg="HASTP104-I JP1/Base is stopping.";;

	   #JP1/Baseの停止に失敗しました。
	5) wk_msg="HASTP104-E ABEND - Stop JP1/Base Failed.";;
	
       #JP1/IMが停止状態の場合、停止済みメッセージ出力
    6) wk_msg="HASTP106-I JP1/IM is stopping.";;

	   #JP1/IMの停止に失敗しました。
	7) wk_msg="HASTP107-E ABEND - Stop JP1/IM Failed.";;
	
   esac
   echo "`date +%Y/%m/%d_%H:%M:%S` ${wk_msg}"
   echo "`date +%Y/%m/%d_%H:%M:%S` ${wk_msg}" >> ${LogFile}
 }

#==================================================================
# 論理ホスト名、実行コマンド設定
#==================================================================
# 論理ホスト名設定関数
 vhostname="SSV"

# JP1/Base 停止コマンド(論理)
 base_stop_cmd="/etc/opt/jp1base/jbs_stop.cluster ${vhostname}"

# JP1/Base 強制停止コマンド(論理)
 base_forcestop_cmd="/etc/opt/jp1base/jbs_killall.cluster ${vhostname}"
 
# JP1/Base ステータス確認コマンド(論理)
 base_check_cmd="/opt/jp1base/bin/jbs_spmd_status -h ${vhostname}"

# JP1/Base ステータス確認コマンド(イベントサービス)
 base_check_cmd2="/opt/jp1base/bin/jevstat ${vhostname}"

# JP1/IM 停止コマンド(論理)
 im_stop_cmd="/etc/opt/jp1cons/jco_stop.cluster ${vhostname}"

# JP1/IM 強制停止コマンド(論理)
 im_forcestop_cmd="/etc/opt/jp1cons/jco_killall.cluster ${vhostname}"
 
# JP1/IM ステータス確認コマンド(論理)
 im_check_cmd="/opt/jp1cons/bin/jco_spmd_status -h ${vhostname

#==================================================================
# ログファイル初期処理
#==================================================================
 if [ -f ${LogFile} ]; then
	 rm -f ${LogFile} > /dev/null 2>&1
	 rt_code=$?
	 if [ ${rt_code} -ne "0" ]; then
		echo "HASTP101-E ABEND - Delete Log File Failed.(${LogFile})"
		exit ${err_end}
	 fi
 fi

#==================================================================
# 処理開始メッセージ出力
#==================================================================
 outmessage 1

#==================================================================
# 実行ユーザ確認
#==================================================================
 echo ${ope_username} | grep ${username} >/dev/null 2>&1
 rt_code=$?
 if [ ${rt_code} -ne 0 ]; then
     outmessage 4
     exit ${err_end}
 fi

#==================================================================
# JP1/IM停止
#==================================================================
 ${im_check_cmd} >> ${LogFile}
 rt_code=$?
 if [ ${rt_code} -eq 8 ]; then
     #JP1/IMが停止状態の場合、停止済みメッセージ出力
     outmessage 6
 else
     #JP1/IMを停止する
     ${im_stop_cmd} >> ${LogFile}
     ${im_check_cmd} >> ${LogFile}
     rt_code=$?
     if [ ${rt_code} -ne 8 ]; then
         ${im_forcestop_cmd} >> ${LogFile}
         ${im_check_cmd} >> ${LogFile}
         rt_code=$?
         if [ ${rt_code} -ne 8 ]; then
			outmessage 7
			exit ${err_end}
         fi
     fi
 fi

#==================================================================
# JP1/Base停止
#==================================================================
 ${base_check_cmd} >> ${LogFile}
 rt_code=$?
 if [ ${rt_code} -eq 8 ]; then
     #JP1/Baseが停止状態の場合、停止済みメッセージ出力
     outmessage 4
 else
     #JP1/Baseを停止する
     ${base_stop_cmd} >> ${LogFile} 2>&1
     ${base_check_cmd} >> ${LogFile}
     rt_code=$?
     if [ ${rt_code} -ne 8 ]; then
         ${base_forcestop_cmd} >> ${LogFile} 2>&1
         ${base_check_cmd} >> ${LogFile}
         rt_code=$?
         if [ ${rt_code} -ne 8 ]; then
			outmessage 5
			exit ${err_end}
         fi
     fi
 fi

 ${base_check_cmd2} >> ${LogFile}
 rt_code=$?
 if [ ${rt_code} -eq 0 ]; then
     #JP1/Base(イベントサービス)を停止する
     ${base_stop_cmd} >> ${LogFile} 2>&1
     ${base_check_cmd2} >> ${LogFile}
     rt_code=$?
     if [ ${rt_code} -ne 8 ]; then
         ${base_forcestop_cmd} >> ${LogFile} 2>&1
         ${base_check_cmd2} >> ${LogFile}
         rt_code=$?
         if [ ${rt_code} -ne 8 ]; then
			outmessage 5
			exit ${err_end}
         fi
     fi
 fi

#==================================================================
# 処理終了メッセージ出力
#==================================================================
 outmessage 2
 exit ${normal_end}
