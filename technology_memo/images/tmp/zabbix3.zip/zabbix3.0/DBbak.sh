#!/bin/bash
##############################################################################
# ファイル名 | @(#) DBbak.sh
#------------+----------------------------------------------------------------
# 名称       | 統合認証Zabbixサーバ(isso-zabbix) DBデータバックアップスクリプト
#------------+----------------------------------------------------------------
# 機能概要   | 統合認証ZabbixサーバにおけるMariaDBのデータをdump、tgz形式で圧縮してローカル保存し、
#                  統合DBサーバ(issodbdev/133.127.89.75)上にscpで送付する。
#              また、ローカル・リモート先のバックアップファイルのローテーションも実施する。
#------------+----------------------------------------------------------------
# 改定履歴   | 1.00 : 新規作成                          2018/09/10 MT
#------------+----------------------------------------------------------------
##############################################################################

#-------------------------------------------------------------------------------
# 変数定義
#-------------------------------------------------------------------------------

#ホームディレクトリ
homeDir="/opt/tools/dbbak/"

#バックアップファイル保管ディレクトリ
bkfileDir="${homeDir}bkfile/"

#一時ファイル配置先
tmpDir="${homeDir}tmp/"

#リモート先のホストのIPアドレス
remoteHost="133.127.89.75" #統合DBサーバ

#リモート先ホストのユーザ
remoteUser="radmin"

#リモート先ホストのパスワード
remotePasswd="powergames"

#リモート先のバックアップファイル保管ディレクトリ
remoteBkfileDir="/backup/zabbixdb/"

#リモートコマンド実施用スクリプト
remoteCommand="${homeDir}sshremote.sh"

#現在の日付
NowDate=`/usr/bin/date +%Y%m%d`

#バックアップファイル名につける日付
#(日付が替わった際に実施するので処理実施の前日を設定)
bkDate=`/usr/bin/date +%Y%m%d%H%M%S -d "1 days ago"`

#スクリプトのログファイル
logFile="/log/dbbak/dbbak.log"

#ログファイル・メール用の一時ファイル
logFileTmp="${tmpDir}logFileTmp.txt"

#削除対象のバックアップファイルが存在した場合、
#このファイルにフルパスが記載される。
delfileTmp="${tmpDir}delFileTmp.txt"

#削除対象となる閾値日数(ローカル)
delDayLocal="90"

#削除対象となる閾値日数(リモート)
delDayRemote="360"

#処理結果通知先メールアドレス
mailAddr="tsuzuki@sis1.nic.nhk.or.jp"

#SMTPサーバ
smtpServ="nhksmtp.nhk.or.jp"

#ロックファイル名
lockFile="${homeDir}DBbak_lock${NowDate}.txt"

#-------------------------------------------------------------------------------
# 関数定義
#-------------------------------------------------------------------------------

#@@@@@@@@@@@@@@@@@@@@
# 関数名：log_writer
# 機能   ：引数に取ったメッセージを一時ファイルに記述する。
# 引数   ：$1=記述するメッセージ内容
#@@@@@@@@@@@@@@@@@@@@
function log_writer () {
	/usr/bin/echo "[ ${NowDate}_`date +%H%M%S` ] $1" >> ${logFileTmp}
}

#@@@@@@@@@@@@@@@@@@@@
# 関数名：last_exec
# 機能   ：本スクリプトの正常終了・異常終了を判定し、
#             ログファイルへの記述やメール送信等最終処理を実行する
# 引数   ：$1=0：スクリプトを正常終了と判定
#                 =1：スクリプトを異常終了と判定
#@@@@@@@@@@@@@@@@@@@@
function last_exec () {
	if [ $1 -eq "0" ]; then
		/usr/bin/echo "====================" >> ${logFileTmp}
		/usr/bin/echo "DBbak.sh 正常終了" >> ${logFileTmp}
		/usr/bin/echo "====================" >> ${logFileTmp}
		/usr/bin/echo "" >> ${logFileTmp}
		
		/usr/bin/cat "${logFileTmp}" >> ${logFile}
		/usr/bin/cat "${logFileTmp}" | mail -s "Zabbix DBバックアップ 正常終了" -S "smtp=smtp://${smtpServ}:25" -r isso-zabbix@sis1.nic.nhk.or.jp ${mailAddr}
		/usr/bin/rm "${logFileTmp}"
		/usr/bin/rm "${delfileTmp}"
		/usr/bin/rm "${lockFile}"
		
		exit 0
	else
		/usr/bin/echo "====================" >> ${logFileTmp}
		/usr/bin/echo "DBbak.sh 異常終了" >> ${logFileTmp}
		/usr/bin/echo "====================" >> ${logFileTmp}
		/usr/bin/echo "" >> ${logFileTmp}
		
		/usr/bin/cat ${logFileTmp} >> ${logFile}
		/usr/bin/cat ${logFileTmp} | mail -s "Zabbix DBバックアップ 異常終了" -S "smtp=smtp://${smtpServ}:25" -r isso-zabbix@sis1.nic.nhk.or.jp ${mailAddr}
		/usr/bin/rm "${logFileTmp}"
		/usr/bin/rm "${delfileTmp}"
		/usr/bin/rm "${lockFile}"
		
		#異常終了の場合はバックアップファイルを残さない。
		if [ -f "${nowBkfileTar}" ] ; then
			/usr/bin/rm ${nowBkfileTar}
		fi
		if [ -f "${nowBkfile}" ] ; then
			/usr/bin/rm ${nowBkfile}
		fi
		exit 1
	fi
}

#-------------------------------------------------------------------------------
# 1. 処理開始
#-------------------------------------------------------------------------------

#ホームディレクトリへ移動
/usr/bin/cd ${homeDir}

#ログ用一時ファイル作成（過去ファイルが残っていたら削除）
if [ -f "${logFileTmp}" ] ; then
	/usr/bin/rm "${logFileTmp}"
fi
/usr/bin/touch "${logFileTmp}"

/usr/bin/echo "====================" >> ${logFileTmp}
/usr/bin/echo "DBbak.sh Start" >> ${logFileTmp}
/usr/bin/echo "====================" >> ${logFileTmp}
log_writer "DBバックアップ処理を開始。"
/usr/bin/echo "" >> ${logFileTmp}

#ロックファイルの確認(あれば異常終了、なければ作成して処理続行)
if [ -f "${lockFile}" ] ; then
	log_writer "Error：ロックファイルが存在します。同時実行は禁止です。"
	/usr/bin/echo "" >> ${logFileTmp}
	/usr/bin/echo "====================" >> ${logFileTmp}
	/usr/bin/echo "DBbak.sh 異常終了" >> ${logFileTmp}
	/usr/bin/echo "====================" >> ${logFileTmp}
	/usr/bin/echo "" >> ${logFileTmp}
	/usr/bin/cat ${logFileTmp} >> ${logFile}
	/usr/bin/cat ${logFileTmp} | mail -s "Zabbix DBバックアップ 異常終了" -S "smtp=smtp://${smtpServ}:25" -r isso-zabbix@sis1.nic.nhk.or.jp ${mailAddr}
	exit 1
else
	/usr/bin/touch "${lockFile}"
fi

# 格納ディレクトリのチェック
if [ ! -d "${bkfileDir}" ] ; then
	log_writer "Error：${bkfileDir}がありません。"
	/usr/bin/echo "" >> ${logFileTmp}
	last_exec 1
fi

log_writer "Info：ディレクトリチェック完了。"
/usr/bin/echo "" >> ${logFileTmp}

#-------------------------------------------------------------------------------
# 2. DBのdump・ファイル圧縮
#-------------------------------------------------------------------------------

#mysqldumpでデータをバックアップ
bkfileName="dbbak_zabbix_${bkDate}.sql"
nowBkfile="${tmpDir}${bkfileName}"
/usr/bin/mysqldump -u root --password=issozabbix zabbix > ${nowBkfile}
if [ $? -ne 0 ] ; then
	log_writer "Error：DBのバックアップに失敗しました。"
	last_exec 1
fi

#パーミッションを変更
/usr/bin/chmod 644 ${nowBkfile}

# ファイルをtgz形式で圧縮
nowBkfileTarName="${bkfileName}.tgz"
nowBkfileTar="${bkfileDir}${nowBkfileTarName}"
/usr/bin/cd "${tmpDir}"
/usr/bin/tar czvf ${nowBkfileTar} --directory "${tmpDir}" ./${bkfileName} &>/dev/null
if [ $? -ne 0 ] ; then
	log_writer "Error：バックアップファイルの圧縮に失敗しました。"
	last_exec 1
fi
/usr/bin/cd ${homeDir}

# 圧縮前のファイルを削除
/usr/bin/rm ${nowBkfile}

log_writer "Info：DBバックアップ・ファイル圧縮処理完了。"
/usr/bin/echo "" >> ${logFileTmp}

#-------------------------------------------------------------------------------
# 3. バックアップファイルコピー
#-------------------------------------------------------------------------------

# リモート先バックアップ用ディレクトリのチェック
echo "${remotePasswd}" | ${remoteCommand} ssh ${remoteUser}@${remoteHost} "/usr/bin/test -d ${remoteBkfileDir}"
if [ $? -ne 0 ] ; then
	log_writer "Error：リモート先にバックアップ用ディレクトリがありません。"
	last_exec 1
fi

#圧縮したバックアップファイルをリモートの保存先にscpで送る。
echo "${remotePasswd}" | ${remoteCommand} scp -p "${nowBkfileTar}" ${remoteUser}@${remoteHost}:${remoteBkfileDir}
if [ $? -ne 0 ] ; then
	log_writer "Error：バックアップファイルの送付に失敗しました。"
	last_exec 1
fi

log_writer "Info：リモート先へのファイル送付処理完了。"
/usr/bin/echo "" >> ${logFileTmp}

#-------------------------------------------------------------------------------
# 4. ローテーション処理(ローカル)
#-------------------------------------------------------------------------------

#ローカルで作成日から閾値の日数以上経過したバックアップファイルを検索、存在する場合は削除する。
find ${bkfileDir} -name "dbbak_zabbix_*.tgz" -mtime +${delDayLocal} > "${delfileTmp}"
fileResult=`cat ${delfileTmp}`
if [ "${fileResult}" = "" ] ; then
	log_writer "Info：ローテーション対象ファイルなし。(ローカル)"
	/usr/bin/echo "" >> ${logFileTmp}
else
	find ${bkfileDir} -name "dbbak_zabbix_*.tgz" -mtime +${delDayLocal} -exec rm {} \;
	delCheckNum="0"
	for file in `cat ${delfileTmp}`; do
		/usr/bin/test -f ${file}
		if [ $? -eq 0 ]; then
			delCheckNum="1"
		fi
	done
	if [ "${delCheckNum}" -ne 0 ]; then
		log_writer "Error：バックアップのローテーションに失敗しました。(ローカル)"
		last_exec 1
	fi
	log_writer "Info：ローテーション処理完了。(ローカル)"
	/usr/bin/echo "" >> ${logFileTmp}
fi

#-------------------------------------------------------------------------------
# 5. ローテーション処理(リモート)
#-------------------------------------------------------------------------------

#リモート先で作成日から閾値の日数以上経過したバックアップファイルを検索、存在する場合は削除する。
echo "${remotePasswd}" | ${remoteCommand} ssh ${remoteUser}@${remoteHost} "find ${remoteBkfileDir} -name "dbbak_zabbix_*.tgz" -mtime +${delDayRemote}" > "${delfileTmp}"
fileResult=`cat ${delfileTmp}`
if [ "${fileResult}" = "" ] ; then
	log_writer "Info：ローテーション対象ファイルなし。(リモート)"
	/usr/bin/echo "" >> ${logFileTmp}

else
	echo "${remotePasswd}" | ${remoteCommand} ssh ${remoteUser}@${remoteHost} "find ${remoteBkfileDir} -name "dbbak_zabbix_*.tgz" -mtime +${delDayRemote} -exec rm {} \;"
	delCheckNum="0"
	for file in `cat ${delfileTmp}`; do
		echo "${remotePasswd}" | ${remoteCommand} ssh ${remoteUser}@${remoteHost} "/usr/bin/test -f ${file}"
		if [ $? -eq 0 ]; then
			delCheckNum="1"
		fi
	done
	if [ "${delCheckNum}" -ne 0 ]; then
		log_writer "Error：バックアップのローテーションに失敗しました。(リモート)"
		last_exec 1
	fi
	log_writer "Info：ローテーション処理完了。(リモート)"
	/usr/bin/echo "" >> ${logFileTmp}
fi

#-------------------------------------------------------------------------------
# 6. 処理終了
#-------------------------------------------------------------------------------

#最後まで処理が完了したら正常終了と判断。
last_exec 0

exit 1

### End of Script ##################################################################
