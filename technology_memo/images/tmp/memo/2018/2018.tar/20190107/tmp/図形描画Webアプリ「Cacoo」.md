図形描画Webアプリ「Cacoo」

Chromeアプリとして見つけた図形描画Webアプリ「[Cacoo](https://chrome.google.com/webstore/detail/pcflmbddgcmomcfngehfhlajjapabojh?hl=ja#)」です。


Google 図形描画も使ったことありますが、
