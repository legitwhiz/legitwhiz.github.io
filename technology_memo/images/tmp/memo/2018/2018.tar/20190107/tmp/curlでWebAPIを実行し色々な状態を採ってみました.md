
# curlでWebAPIを実行し色々な状態を採ってみました。

curlでWebAPIを実行できるのならShellに組み込むこともできるので運用が楽になるかな!?
正直、色々なシステムで別々の管理システムがあって面倒なので一発で取得するShellを作るため各APIを調べてみました。




## BIG-IPの状態取得API

### HA(High Availability)構成時の状態取得API

```
curl -sk -H "Authorization: Basic ${BIGIP_Base64}" -H "Content-Type: application/json" -X GET https://${BIG_VIP}/mgmt/tm/cm/device | python -mjson.tool
```

### Syncの状態取得API

```
curl -sk -H "Authorization: Basic ${BIGIP_Base64}" -H "Content-Type: application/json" -X GET https://${BIG_VIP}/mgmt/tm/cm/sync-status | python -mjson.tool
```

### SSL証明書 更新日チェック

```
curl -sk -H "Authorization: Basic ${BIGIP_Base64}" -H "Content-Type: application/json" -X GET https://${BIG_VIP}/mgmt/tm/sys/crypto/cert/${BIGIP_CertFileName} | python -mjson.tool
```

### Pool List

```
curl -sk -H "Authorization: Basic ${BIGIP_Base64}" -H "Content-Type: application/json" -X GET https://${BIG_VIP}/mgmt/tm/ltm/pool/${Pool_Name}/members/stats | python -mjson.tool
```

### CPU Usage

```
curl -sk -H "Authorization: Basic ${BIGIP_Base64}" -H "Content-Type: application/json" -X GET https://${BIG_VIP}/mgmt/tm/sys/cpu | python -mjson.tool
```

### Memory Usage

```
curl -sk -H "Authorization: Basic ${BIGIP_Base64}" -H "Content-Type: application/json" -X GET https://${BIG_VIP}/mgmt/tm/sys/memory | python -mjson.tool
```

### Interface Status

```
curl -sk -H "Authorization: Basic ${BIGIP_Base64}" -H "Content-Type: application/json" -X GET https://${BIG_VIP}/mgmt/tm/net/interface/stats | python -mjson.tool
```

## Zabbix Server 状態取得API

### Session_ID取得

```
curl -s -d '{"auth": null,"method": "user.login","id": "null","params": {"password": "'${Zabbix_Password}'","user": "'${Zabbix_UserName}'"},"jsonrpc": "2.0"}' -H "Accept: application/json" -H "Content-Type: application/json-rpc" ${Zabbix_URL} | python -mjson.tool
```

### アラート情報取得API

```
curl -s -d '{"auth": "'${Session_ID}'","method": "alert.get","id": 1,"params": {"output": "extend","time_from": "'"${from_time}"'"},"jsonrpc": "2.0"}' -H "Content-Type: application/json-rpc" ${Zabbix_URL} | python -mjson.tool
```

## Nutanix Prismの状態取得API

### Prism Leader Status

```
curl -s -k -H 'Accept: application/json' -X GET ${Prism_LeaderURL}/prism/leader
```

### Virtual Machine UUIDを全て取得

```
curl -s -k -H "Authorization: Basic ${Prism_Base64}" -H 'Accept: application/json' -X GET "${Prism_URL}/api/nutanix/v2.0/vms/" | python -mjson.tool
```

### Virtual_Machine_UUIDから各仮想マシンの状態を取得

```
curl -s -k -H "Authorization: Basic ${Prism_Base64}" -H 'Accept: application/json' -X GET "${Prism_URL}/PrismGateway/services/rest/v2.0/vms/${Virtual_Machine_UUID}" | python -mjson.tool
```

### Prism Alert Status

```
curl -sk -H "Authorization: Basic ${Prism_Base64}" -H 'Accept: application/json' -X GET ${Prism_URL}/PrismGateway/services/rest/v2.0/alerts/?severity=WARNING,CRITICAL\&resolved=false | python -mjson.tool
```

### ESXi CPU Memory Usage

```
curl -s -k -H "Authorization: Basic ${Prism_Base64}" -H 'Accept: application/json' -X GET "${Prism_URL}/PrismGateway/services/rest/v2.0/hosts/" | python -mjson.tool
```

### Virtual Machine CPU Memory Usage

```
curl -s -k -H "Authorization: Basic ${Prism_Base64}" -H 'Accept: application/json' -X GET "${Prism_URL}/PrismGateway/services/rest/v1/vms" | python -mjson.tool
```

## Dell iDrac状態取得API

### System Summary Status

```
curl -sk -H "Authorization: Basic ${iDrac_Base64}" -H 'Accept: application/json' -X GET ${iDrac_URL}/redfish/v1/Systems/System.Embedded.1 | python -mjson.tool
```

### PowerSupply

```
curl -sk -H "Authorization: Basic ${iDrac_Base64}" -H 'Accept: application/json' -X GET ${iDrac_URL}/redfish/v1/Chassis/System.Embedded.1/Power/PowerSupplies/PSU.Slot.${PSID} | python -mjson.tool
```

### fan and voltage

```
curl -sk -H "Authorization: Basic ${iDrac_Base64}" -H 'Accept: application/json' -X GET ${iDrac_URL}/redfish/v1/Chassis/System.Embedded.1/Thermal | python -mjson.tool
```

### System Board Intrusion

```
curl -sk -H "Authorization: Basic ${iDrac_Base64}" -H 'Accept: application/json' -X GET ${iDrac_URL}/redfish/v1/Chassis/System.Embedded.1 | python -mjson.tool
```

## HP Proliant iLO状態取得API

### iLO_Summary_Status

```
curl -sk -H "Authorization: Basic ${iLO_Base64}" -H 'Accept: application/json' -X GET https://${iLO_Address}/rest/v1/systems/1 --insecure -L | python -mjson.tool
```

### Network_Interface1

```
curl -sk -H "Authorization: Basic ${iLO_Base64}" -H 'Accept: application/json' -X GET https://${iLO_Address}/rest/v1/Systems/1/EthernetInterfaces/${IFID} --insecure -L | python -mjson.tool
```

## vCenter API

### Session ID

```
curl -s -k -H "Authorization: Basic ${vCenter_Base64}" -H 'Accept: application/json' -H "vmware-api-session-id: null" -X POST "${vCenter_URL}/rest/com/vmware/cis/session" | python -mjson.tool
```

### ESXi info

```
curl -s -k -H "Authorization: Basic ${vCenter_Base64}" -H 'Accept: application/json' -H  "vmware-api-session-id: ${Session_ID}" "${vCenter_URL}/rest/vcenter/host" | python -mjson.tool
```

### vm info

```
curl -s -k -H "Authorization: Basic ${vCenter_Base64}" -H 'Accept: application/json' -H  "vmware-api-session-id: ${Session_ID}" "${vCenter_URL}/rest/vcenter/vm" | python -mjson.tool
```

### virtual machine power on

```
curl -s -k -H "Authorization: Basic ${vCenter_Base64}" -H 'Accept: application/json' -H  "vmware-api-session-id: ${Session_ID}" -X POST "${vCenter_URL}/rest/vcenter/vm/${vmid}/power/start" | python -mjson.tool
```

### virtual machine power off

```
curl -s -k -H "Authorization: Basic ${vCenter_Base64}" -H 'Accept: application/json' -H  "vmware-api-session-id: ${Session_ID}" -X POST "${vCenter_URL}/rest/vcenter/vm/${vmid}/power/stop"
```

### Session ID Delete

```
curl -s -k -H "Authorization: Basic ${vCenter_Base64}" -H 'Accept: application/json' -H "vmware-api-session-id: ${Session_ID}" -X DELETE "${vCenter_URL}/rest/com/vmware/cis/session"
```
