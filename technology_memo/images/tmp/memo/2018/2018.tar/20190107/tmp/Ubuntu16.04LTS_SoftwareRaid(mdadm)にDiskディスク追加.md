# Ubuntu16.04LTSのSoftwareRaid(mdadm)にDiskディスク追加した時のメモ

vSphere5.5上に仮想マシン(Ubuntu16.04LTS)構成し
システムディスク用に500GBのHDDを１つ。

ファイルサーバ用領域として2TBのHDDを4本を
仮想マシン(Ubuntu16.04LTS)上でソフトウェアRaid(mdadm)にて
Raid5構成にしている環境にディスクを1本追加してみました。
※マザーボード上のRaidボードで構成しないのは、
vSphere5.5では認識しなかったため


## 仮想ディスクを追加

まず、仮想マシン、vSphereをシャットダウンし物理的にHDDを追加。
仮想ディスクを仮想マシン(Ubuntu)に追加し、OS起動

## OSよりディスク認識からパーティション作成


```console:ディスク認識を確認
sudo fdisk -l
```

sdb1,sdc1,sdd1,sde1でmd0が構成され/dev/sdfが
追加ディスクで認識している状態を確認。

まずはfdiskで[Linux raid 自動検出]でパーティション作成

```
sudo fdisk /dev/sdf

コマンド (m でヘルプ): n
コマンドアクション
   e   拡張
   p   基本領域 (1-4)
p
領域番号 (1-4): 1
最初 シリンダ (1-243201, 初期値 1):
初期値 1 を使います
Last シリンダ, +シリンダ数 or +size{K,M,G} (1-243201, 初期値 243201):
初期値 243201 を使います

コマンド (m でヘルプ): t
選択した領域 1
16進数コード (L コマンドでコードリスト表示): fd
領域のシステムタイプを 1 から fd (Linux raid 自動検出) に変更しました

sudo fdisk -l /dev/sdf
```

## SoftwareRaid(mdadm)にディスク追加

```console:Raidの状態確認
sudo mdadm --misc --detail /dev/md0

  Raid Devices : 4
  Total Devices : 4
    Number   Major   Minor   RaidDevice State
       0       8       17        0      active sync   /dev/sdb1
       1       8       33        1      active sync   /dev/sdc1
       2       8       49        2      active sync   /dev/sdd1
       3       8       65        3      active sync   /dev/sde1
```

```console:Raidにsdf1を追加
sudo mdadm --manage /dev/md0 --add /dev/sdf1
```

```console:Raidの状態確認(sdfはスペアディスクとして構成)
sudo mdadm --misc --detail /dev/md0

  Raid Devices : 4
  Total Devices : 5
  Spare Devices : 1
    Number   Major   Minor   RaidDevice State
       0       8       17        0      active sync   /dev/sdb1
       1       8       33        1      active sync   /dev/sdc1
       2       8       49        2      active sync   /dev/sdd1
       3       8       65        3      active sync   /dev/sde1
       4       8       81        -      spare   /dev/sdf1
```

```console:/dev/md0をOSからアンマウント
sudo umount /share
```

```console:現状がディスク４本構成されているので５本構成になるように指定
sudo mdadm --grow /dev/md0 --raid-disks=5
```

```console:Raidが５本構成になったことを確認
sudo mdadm --misc --detail /dev/md0
 Active Devices : 5
 Working Devices : 5
```

## SoftwareRaid(mdadm)リビルド

```console:Raidにディスク追加するとリビルドが走るので状況確認
sudo cat /proc/mdstat

Personalities : [linear] [multipath] [raid0] [raid1] [raid6] [raid5] [raid4] [raid10] 
md0 : active raid5 sdf1[4] sdc1[1] sdb1[0] sdd1[2] sde1[3]
      5830020096 blocks super 1.2 level 5, 512k chunk, algorithm 2 [5/5] [UUUUU]
      [>....................]  reshape =  0.5% (10756620/1943340032) finish=3728.4min speed=8638K/sec
      
unused devices: <none>
```

う〜ん遅いと思ったらリビルドレートを先に変えるべきだった．．．。
リビルド実行後には変更出来ないみたいで結局2TBｘ4→2TBｘ5にすると３日程リビルドにかかった．．．。

本来は、先に変更すべきだそうです・・・。
(defaultは、/proc/sys/dev/raid/speed_limit_maxが10000で単位がKB/secだそうです。)
ちなみに後から変更してもカーネルパラメータは変更することが出来ますが、
リビルドレートには反映されませんでした。(強制停止は怖いので放置した結果)

```
echo 800000 > /proc/sys/dev/raid/speed_limit_max
echo 200000 > /proc/sys/dev/raid/speed_limit_min
```

リビルドが終わったらfsckしてリサイズしマウントすればOK。

```
sudo e2fsck -f /dev/md0
sudo resize2fs /dev/md0
sudo mount /share
```


