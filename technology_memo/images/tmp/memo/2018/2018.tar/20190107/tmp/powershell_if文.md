# PowerShellのif文

今更ながらpowershellでスクリプトを作成しなければならないことと


## if文

## if/elseif/else

if文は、条件分岐をする上で欠かせない構文です。構文は次の通りです。

```
if (<条件>)
{
  <ifの条件が満たされた場合に実行されるコードブロック>
}
elseif (<条件>)
{
  <elseifの条件が満たされた場合に実行されるコードブロック>
}
else
{
  <前の条件がいずれも満たされない場合に実行されるコードブロック>
}
```
elseifはいくつでも記述することができますが、elseは1つまでです。どちらも省略することができます。



## PowerShellの比較演算子

### 比較演算子一覧

下表に記す文字列により、数値比較ができます。

|記号|比較内容|備考|
|:----|:--------------------------------|:-----------|
|-eq|等しいかをチェック 数値 = 数値|equal|
|-ne|異なるかをチェック 数値 ≠ 数値|not equal|
|-lt|数値 < 数値をチェック|less than|
|-le|数値 ≦ 数値をチェック|less than or equal|
|-gt|数値 > 数値をチェック|greater than|
|-ge|数値 ≧ 数値をチェック|greater than or equal|
|-like|ワイルドカードと等しい|N/A|
|-notlike|ワイルドカードと等しくない|N/A|
|-match|正規表現と等しい|N/A|
|-notmatch|正規表現と等しくない|N/A|

### ワイルドカードパターン
|ワイルドカード|説明|
|:-------------|:--------------------------------------|
|*|0個以上の任意の文字に一致|
|?|任意の1文字に一致|
|[a-z]|連続する文字に一致(左の例の場合はa-zの中の1文字)|
|[abc]|abcのうち1文字に一致|

## ファイルやフォルダが存在するかを確認する方法

PowerShell でファイルやフォルダが存在するかを確認するには、 Test-Path コマンドレットを使用します。ファイルやフォルダのパスにはワイルドカードを使用することも可能です。

```console:PowerShell（書式）
Test-Path "対象のファイルやフォルダのパス" 
```

### ファイルやフォルダを個別に確認する
下のサンプルコードでは、 d:\temp\test.txt の存在を確認しています。

```console:PowerShell（実行可能なサンプルコード）
# d:\temp\test.txt が存在するかを確認
$result = (Test-Path "d:\temp\test.txt")
 
if($result){
    #ファイルが存在する場合はこちらが実行されます。
    Write-Host "ファイルは存在します。"
}else{
    #ファイルが存在しない場合はこちらが実行されます。
    Write-Host "ファイルは存在しません。"
} 
```

フォルダを指定した場合も同じように動作します。

```console:PowerShell（実行可能なサンプルコード）
# d:\temp\test フォルダが存在するかを確認
if(Test-Path "d:\temp\test"){
    #フォルダが存在する場合はこちらが実行されます。
    Write-Host "ファイルは存在します。"
}else{
    #フォルダが存在しない場合はこちらが実行されます。
    Write-Host "ファイルは存在しません。"
} 
```

パスにワイルドカードを指定して確認する
Test-Path はパスに * を使用することで、ワイルドカード指定することもできます。以下のサンプルコードでは、 d:\temp フォルダ内に .txt の拡張子をもつファイルがあるかを確認しています。

```console:PowerShell（実行可能なサンプルコード）
# d:\temp\test フォルダに 拡張子 txt のファイルが存在するかを確認
if(Test-Path "d:\temp\*.txt"){
    #ファイルが存在する場合はこちらが実行されます。
    Write-Host "ファイルは存在します。"
}else{
    #ファイルが存在しない場合はこちらが実行されます。
    Write-Host "ファイルは存在しません。"
}
```

否定の場合(ファイルやディレクトリが存在しない場合の処理)
```console:PowerShell（書式）※ディレクトリが存在しなければ
if(!(Test-Path $ScriptLog_Dir)){
    New-Item $ScriptLog_Dir -ItemType Directory
}
```

## 引数チェックするには
```
if ($args.length -eq 0) {
    usage
}
```

## PowerShellのif文でand,or,xor,notを記述する方法

### if文で使用するAnd, Or, Xor, Notの演算子

PowerShellのAnd, Or, Xor, Notの演算子は以下のように記述できます。

|論理演算子|PowerShell記述法|
|:---------|:---------------|
|AND論理積|-And|
|OR論理和|-Or|
|XOR排他的論理和|-Xor|
|NOT否定|-Not または !|


### 論理演算子を使ってみる

#### And

```
if (($a -eq $null) -And ($b -eq $null)) {
  Write-Output "TRUE"
} else {
  Write-Output "FALSE"
}
```

#### Or

```
if (($a -eq $null) -Or ($b -eq $null)) {
  Write-Output "TRUE"
} else {
  Write-Output "FALSE"
}
```

#### Xor

```
if (($a -eq $null) -Xor ($b -eq $null)) {
  Write-Output "TRUE"
} else {
  Write-Output "FALSE"
}
```


#### Not

```
if (!($a -eq $null)) {
  Write-Output "TRUE"
} else {
  Write-Output "FALSE"
}
```

```
if (-Not($a -eq $null)) {
  Write-Output "TRUE"
} else {
  Write-Output "FALSE"
}
```

