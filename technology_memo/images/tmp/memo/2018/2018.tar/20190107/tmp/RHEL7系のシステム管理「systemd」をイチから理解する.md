# systemdによるRHEL 7の管理

## RHEL 7のシステム管理基礎
Linuxの起動処理は、これまでinit/upstartと呼ばれる仕組みで行われていました。
RHEL 7系では、これが、systemdと呼ばれるまったく新しい仕組みに置き換わります。

### Unitによる管理
systemdでは、「Unit」という単位で処理を管理します。
これまで、rc.sysinitやサービス起動スクリプトが実施していた処理の内容は、
すべて、Unitとして定義されます。

Unitは、「target」「mount」「service」「device」など、
役割によってタイプがわかれています。
それぞれのUnitは、依存関係が定義されており、
PID=1の最初のプロセスとしてsystemdが起動すると、
「default.target」というUnitを頂点とする、
依存関係のツリーを構築した後、依存するUnitを起動していきます。

この時、それぞれのUnitは、依存関係（AはBが必要）の情報とは別に、
起動順序（AはBの後に起動）についての設定が与えられます。
起動順序の指定がない場合、依存関係のあるUnitについても並列に起動処理が行われます。
systemdは、順序関係の情報をもとにして、複数のUnitをできるかぎり並列に起動していきます。



## ランレベル

### ランレベルの廃止
RHEL 6系とRHEL 7系で大きく異なるのは、ランレベルの考え方です。RHEL 7では、ランレベルという概念が廃止され、「ターゲット」と呼ばれる概念が導入されています。

RHEL 6系では、/etc/inittabファイルの記述によってOS起動時のデフォルトのランレベルを変更し、runlevelコマンドによって現在稼働中のランレベルを表示していました。一方、RHEL 7においてデフォルトで設定されている状況を確認するには、systemctlコマンドを使います。

```
# systemctl get-default
multi-user.target
```

利用可能なターゲットは、以下コマンドで確認できる。

```
# systemctl list-units --type=target --all --no-pager
```

### OS起動時のターゲットを変更

#### X Windowが起動していないマルチユーザーモード(RHEL 6系のランレベル3に相当)
```
# systemctl set-default multi-user.target
rm '/etc/systemd/system/default.target'
ln -s '/usr/lib/systemd/system/multi-user.target' '/etc/systemd/system/default.target'

# systemctl get-default
multi-user.target
```

#### X Windowが起動するマルチユーザーモード(RHEL 6系のランレベル5に相当)

```
# systemctl set-default graphical.target
rm '/etc/systemd/system/default.target'
ln -s '/usr/lib/systemd/system/graphical.target' '/etc/systemd/system/default.target'

# systemctl get-default
graphical.target
```


### OS再起動無しでターゲットを切り替える

#### X Windowが起動していないマルチユーザーモード(RHEL 6系のランレベル3に相当)

```
# systemctl isolate multi-user.target
```

#### X Windowが起動するマルチユーザーモード(RHEL 6系のランレベル5に相当)

```
# systemctl isolate graphical.target
```

### RHEL 7におけるシングルユーザーモードと緊急モード

システムに不具合やシステムの継続稼働が困難になった場合に、
シングルユーザーモードや緊急モードに移行する必要がでてきます。

RHEL 6系では、telinit 1などによりランレベル1になり
シングルユーザーモードになっていましたが、
RHEL 7では、systemdを使ってレスキューターゲットや
エマージェンシーターゲットを指定することで状態を切り替えることができます。
以下では、シングルユーザーモードと緊急モードへの切り替えと
その場合のメンテナンスの基本を説明します。

シングルユーザーモードになると、ネットワーク通信機能が切断されてしまいますので、
telnet等の仮想端末で遠隔から操作している場合には、
ローカルマシンでの作業に切り替える必要があります。

#### シングルユーザーモード
```
# systemctl isolate rescue.target
```
#### 緊急モード
```
# systemctl isolate emergency.target
```

## systemdの仕組み
RHEL6系では、chkconfigコマンドによるサービスの有効化、無効化の切り替え、
/etc/init.dディレクトリ配下のスクリプトに対してstart/stop/status等の
パラメータを与えることで、様々なサービスの制御を行っていました。

RHEL7においては、サービスの制御をsystemdによって行います。
具体的には、管理者は、systemctlコマンドを使ってサービスの
起動、停止、状態確認等を行います。

RHEL 6までは、デーモンと起動スクリプトの集合体でサービスを管理していましたが、
RHEL 7のsystemdでは、「ユニット」と呼ばれる単位で管理を行います。
RHEL 5のSysVinitやRHEL 6のUpstartにおける起動スクリプトを使った処理が、
RHEL 7では、複数の「ユニット」に分割されて、並列実行を行うことにより、
OSの起動速度の高速化を実現しています。

また、従来のデーモンと複雑な起動スクリプトの集合体では、
スクリプトの記述がサービス毎に異なっており、管理が複雑化していましたが、
systemdにより記述が標準化されており、複雑なスクリプト群をできるだけ
排除する設計が見られます。

systemdの管理の単位となるユニットには、以下に示す幾つかのタイプが存在します。

|type|内容|
|:-------|:----------------------------------------------------------------------------|
|service|各種デーモンやサービスの起動|
|target|従来のランレベルに相当する起動プロセスをまとめたユニット群の処理に使用|
|mount|ファイルシステムのマウントポイント制御|
|device|ディスクデバイス|
|socket|FIFO、UNIXドメインソケット、ポート番号等に関する通信資源|

### ユニットの依存関係
systemdが管理するユニットには、依存関係が存在します。
ユニットの依存関係は、あるユニットを有効にするために、
他のユニットも有効にしないとうまく稼働しない場合、
それらの複数のユニット間に依存関係があると判断します。

ユニットに依存関係がない場合、それらのユニットは、
個別に同時並列的に起動されることになり、
RHEL 7のOS起動の高速化に貢献します。

ユニットの依存関係は、RHEL 7で定義されているターゲットの
設定ファイルの中身を見ると理解が深まります。

例えば、graphical.targetファイルの中身を確認します。

```
# pwd
/usr/lib/systemd/system
# cat multi-user.target
...
Requires=basic.target
...
```

上記の「Requires=multi-user.target」は、graphical.targetを起動するためには、
multi-user.targetが必要であるという依存関係を示しています。

さらに、「Wants=display-manager.service」も依存関係を示しています。
従来のランレベル5に相当するgraphical.targetは、従来のランレベル3に
相当するmulti-user.targetに依存していることになります。


### ユニットの起動順序
ユニットには、依存関係の他に、起動順序の概念が存在します。

例として、sshdサービスをあげます。
sshdサービスの起動に関する設定ファイルは、
/usr/lib/systemd/system/sshd.serviceです。

```
# pwd
/usr/lib/systemd/system

# cat sshd.service
...
After=syslog.target network.target auditd.service
...
```

上記設定ファイルに「After=syslog.target network.target auditd.service」
と記述されています。
これは、syslog.target、network.target、auditd.serviceの後に
sshd.serviceが起動することを意味します。

### ユニットの起動設定
RHEL 6系では、chkconfigで設定を実施していたが
HRLE 7系で、systemctlにて設定するがランレベルではなく、


定義されているサービスの一覧
systemctl list-unit-files --type=service

サーバ起動時の自動起動の有効化/無効化(multi-user.target)
```
# systemctl disable sshd
rm '/etc/systemd/system/multi-user.target.wants/sshd.service'

# systemctl enable sshd
ln -s '/usr/lib/systemd/system/sshd.service' '/etc/systemd/system/multi-user.target.wants/sshd.service'

# systemctl is-enabled sshd
enabled
```

現在のサービスの状態の確認
```
# systemctl status sshd.service

```

pwd;find /usr/lib/systemd/system/sysinit.target.wants | sort | sed '1d;s/^\.//;s/\/\([^/]*\)$/|--\1/;s/\/[^/|]*/|  /g'


cd /usr/lib/systemd/system/sysinit.target.wants;pwd;find . | sort | sed '1d;s/^\.//;s/\/\([^/]*\)$/|--\1/;s/\/[^/|]*/|  /g'

cd /etc/systemd/system/multi-user.target.wants;pwd;find . | sort | sed '1d;s/^\.//;s/\/\([^/]*\)$/|--\1/;s/\/[^/|]*/|  /g'

