# Data Domain その特徴とは

Data Domain(データドメイン)、略称はDD(ディーディー)

DDの代表的な機能は、「重複排除」、「レプリケーション」です。
よくバックアップ専用ストレージとして紹介されていますが、
厳密には、バックアップではなく「
アーカイブ専用重複排除アプライアンスストレージ」です。

バックアップとアーカイブは、目的が違います。
有事の際のデータ消失、破損に「備える」のが「バックアップ」で
大量のデータを安全かつ長期的に「保管する」のが「アーカイブ」です。

もちろん、「アーカイブ」を得意として作られているだけで
「バックアップ」として使用することも可能ではあります。

特に仮想テープ(VTL)見られる「リテンション ロック」はアーカイブを
意識した機能と言えるでしょう。

DataDomainは、重複排除機能前提で設計されておりデータは、
平均1/10から1/30ものデータを削減することが可能です。
また、「レプリケーション」は別サイトに
保管することができ、遠隔地保管や災害復旧対策等の用途で使用できます。

重複排除とは、データのサイズを小さくする機能です。
データを保存すると、重複排除という技術で書込みデータ
を小さくしてから書き込みます。(一度ディスクに書き込んでから
圧縮とは違うので一時領域も必要ありません。
全てキャッシュ内で処理してから書き込み)

レプリケーション構成は、非常に手軽に設定でき、また1対1、N対1、1対Nの
レプリケーションなど柔軟な構成が可能です。
保管した重複排除データをレプリケーションする際にさらに重複排除してから転送するためレプリケーション間の回線にかかる転送量を極小化できるため回線にかかるコストパフォーマンス)

DataDomainへの接続方式もNFS、CIFS、FC(ブロックストレージ)、
FC(仮想テープライブラリ装置)と多才です。

ですが、あくまでも「アーカイブ」を目的にしたストレージなので
データを取り出すには重複排除の関係上時間がとてもかかります。

なので、NASとして使用してはいけません。

## モードの変更

Data Domainには3つのモードがありますが、SEモードやbashモードは、
推奨されていないコマンドも多数ありますのでモード変更する際は
注意する必要があります。。

system admin mode(管理者モード)
→system engineer mode(SEモード)
→system engineer bash mode(bashモード)
と遷移出来ます。通常はsystem admin modeになります。

system engineer modeにするためにシリアル番号の入力が必要になるため、
予め確認します。

```console:シリアル番号確認方法
# system show serialno
```

system engineer modeにします。
ここで入力を求められるパスワードはsysadminのパスワードではなく
機器のシリアル番号になります。

```
# priv set se
```

system engineer bash modeにします。
system engineer modeで、以下のように実行します。コマンド実行する
順番間違えるとbash modeに変わりません。

```
# uname
# filesys status
# df
# <ctrl>+C
# <Ctrl>+C
# <Ctrl>+C
# shell-escape
```



## DataDomain 初期セットアップ

DataDomain2500は、初期のネットワーク設定がされていないため
シリアルケーブルを端末と接続し初期セットアップが必要となります。

|設定項目|設定値|
|:--|:--|
|Baud rate|9600|
|Data bits|8|
|Stop bits|1|
|Parity|None|
|Flow control|None|
|Emulation|VT-100|

※DHCPや仮のIPアドレスが設定されていれば、
わざわざシリアル接続なんて必要ないのだが・・・。


localhost.localdomain login: sysadmin
Password: <system_serial_number>

Press any key then hit enter to acknowledge the receipt of EULA
information: 


Run the configuration wizard
# config setup

Do you want to configure system using GUI wizard (yes|no) [no]
: yes
Change the 'sysadmin' password at this time? (yes|no):
Network Configuration
Configure Network at this time (yes|no)
[no]: yes
Use DHCP
Use DHCP for hostname, domainname, default gateway and
DNS servers? (At least one interface needs to be configured
using DHCP) (yes|no|?)Enter the hostname for this system (fully-qualified domain name)[]:
Domainname
Enter your DNS domainname []:

Ethernet port eth0a
Enable Ethernet port eth0a (yes|no|?) [yes]: no
Ethernet port eth0b
Enable Ethernet port eth0b (yes|no|?) [no]: yes
Use DHCP on Ethernet port eth0b (yes|no|?) [no]:
Enter the IP address for eth0b
[192.168.10.185]:
Enter the netmask for eth0b
[255.255.255.0]:

Default Gateway
Enter the default gateway IP address
: 192.168.10.1

IPV6 Default Gateway
Enter the ipv6 default gateway IP address
:


DNS Servers
Enter the DNS Server list (zero, one, two or three IP addresses)
: 192.168.10.1


Pending Network Settings
Hostname ddbeta1.dallasrdc.com
Domain name dallasrdc.com
Default Gateway 192.168.10.1
DNS Server List 192.168.10.1
Port Enabled Cable DHCP IP Address Netmask or Prefix Length
----- ------- ----- ---- -------------- ------------------------
eth0a no no n/a n/a n/a
eth0b no no n/a n/a n/a
eth0c no no n/a n/a n/a
eth0d no no n/a n/a n/a 
ethMa yes yes no 192.168.10.181 255.255.255.0
ethMb no no n/a n/a n/a
ethMc no no n/a n/a n/a
ethMd no no n/a n/a n/a
ethMe no no n/a n/a n/a
ethMf no no n/a n/a n/a
----- ------- ----- ---- -------------- ------------------------
Do you want to save these settings (Save|Cancel|Retry): Save


To complete this configuration in the Enterprise Manager, please set
your web browser address to http://<hostname_or_IP>/
then go to Maintenance -> More Tasks -> Launch Configuration Wizard.





・シリアルナンバー確認
```
system show serialno
```

・ホスト名確認
```
net show hostname
```

・ホスト名設定
```
net set hostname <hostname>
```

・ドメイン名確認
```
net show domainname
```

・DDOSバージョン確認
```
uname
```

・ロケーション確認
```
config show location
```

・config set location <location>

・ファイルシステム空き確認
```
filesys show space
```

・ネットワーク設定確認
```
net show settings
```

・NIC設定確認
```
net show hardware
```

・ネットワーク設定状態確認
```
net show config
```

・ネットワーク設定
```
net set config ethMa <IP address> netmask <mask> speed <speed> duplex <duplex> up
```

・メモリ
```
system show meminfo
```

・SEモード変更(シリアルNOがパスワード)
```
priv set se
```

・windowサイズ変更
```
net option set net.ipv4.tcp.rmem "4096 2097152 16777216"
net option set net.ipv4.tcp.wmem "4096 2097152 16777216"
```

・windowサイズ確認
```
net option show
```

・ゲートウェイ設定確認
```
route show gateway
```

・ゲートウェイ設定
```
route set gateway <IP address>
```

・ルーティングテーブル確認
```
route show table
```

・NTPサーバ設定
```
ntp add timeserver <IP address>,<IP address>
```

・NTPサーバ設定確認
```
ntp show config
```

・NTPステータス確認
```
ntp show status
```

・autosupport設定確認
```
autosupport show all
```

・autosupport送信設定
```
autosupport notification disable all
```

・autosupportスケジュール変更
```
autosupport set schedule asup-detailed daily 1500
```

・alertレベル確認
```
alerts notify-list show
```

・アドミンアクセス設定確認
```
adminaccess show
```

・http,scp無効
```
adminaccess disable http
adminaccess disable scp
```

・クリーニングスケジュール確認
```
filesys clean show schedule
```

・クリーニングスケジュール設定変更
```
filesys clean set schedule "Wed 0800"
```

・クリーニングスロットル設定確認
```
filesys clean show throttle
```

・圧縮タイプ確認
```
filesys option show local-compression-type
```

・ライセンス確認
```
licence show
```

・タイムゾーン
```
config show timezone
```

・ユーザリスト
```
user show list
```

・ユーザ追加(パスワード有効期限　最少0日最大300日　７日前から変更を促すメッセージ出力)
```
user add <username> role <role> min-days-between-change 0 max-days-between-change 300 warn-days-before-expire 7
```

・パスワード有効期限設定確認
```
user password aging show
```

・role追加
```
user add secadmin role security
```

・Mtree作成
```
mtree create /data/col1/<Mtree Name>
```

・Quotaサービスenable
```
quota capacity enable
```

・Quotaサービス状態確認
```
quota status
```

・Quota設定
```
quota set mtrees /data/col1/<Mtree Name> hard-limit xxx MiB soft-limit xxx MiB
```

・Quota設定確認
```
quota show all
```

・nfsクライアント追加
```
nfs add /data/col1/<Mtree Name>/<Directory> <IP address>
```

・nfsクライアント確認
```
nfs show clients
```

・nfsサービス確認
```
nfs status
```

・cifs共有設定
```
cifs share create /data/col1/<Mtree Name>/<Directory> clients <IP address>
```

・cif共有設定確認
```
cifs share show
```

・cifs 設定変更
```
cifs share modify <共有名> clients <IP address>
```

・cifs設定確認
```
cifs show config
```

・hosts追加
```
net hosts add <IP address> <hostname1> <hostname2>
```

・hosts確認
```
net hosts show
```

・vtlサービス確認
```
vtl status
```

・vtlサービスenable
```
vtl enable
```

・VTL LIB追加
```
vtl add <LIB名> model <model name> slots <slot count> caps <caps count>
```

・VTLドライブ追加
```
vtl drive add <LIB名> count <drive count> model <model name>
```

・VTL設定確認

・イニシエータ追加
```
vtl initiator add <alias name> ???
```

・イニシエータ設定確認
???

・VTLグループ追加
```
vtl group create <group name>
```

・VTLグループにLIB追加
```
vtl group add <group name> vtl <LIB name> all primary-port
```

・VTLグループにイニシエータ追加
```
vtl group add <group name> initiator ???
```

・VTLグループ設定確認
```
vtl group show <group name>
```

・VTL pool追加
```
vtl pool add <Pool name>
```

・VTL Tape 追加
```
vtl tape add <tape barcode> capacity <capacity> count <tape count> pool <Pool name>
```

・VTL tape確認
```
vtl tape show all
```

・VTL tape 装填
```
vtl import <LIB name> barcode <barcode> count <tape count> pool <Pool name> element address <slot address>
```

・snmp trap-host設定
```
snmp add trap-host <IP address> version v2c community <RW community name>
```

・snmp コミュニティ名追加
```
snmp add rw-community <RW community name> hosts <IP address>
snmp add ro-community <RO community name> hosts <IP address>
```

・snmp設定確認
```
snmp show config
```

・暗号化セキュリティオフィサー設定
```
authorization polisy set security-officer enable
```

・暗号化ポリシー状態確認
```
authorization policy show
```

・ファイルシステム暗号化enable
```
filesys encryption enable
```

・ファイルシステム暗号化状態確認
```
filesys encryption show
```

・ファイルシステム再起動
```
filesys restart
```

・ファイルシステムdisable
```
filesys disable
```

・ファイルシステム暗号化ロック
```
filesys encrption lock
```

・ファイルシステム暗号化アンロック
```
filesys encrption unlock
```

・ファイルシステムenable
```
filesys enable
```

・レプリケーション設定追加
```
replication add source mtree://<source hostname>.<domain name>/data/col1/<Mtree name> destination mtree://<destination hostname>.<domain name>/data/col1/<Mtree name>
```

・レプリケーション設定確認
```
replication show config 
```

・レプリケーションenable
```
replication enable mtree://<destination hostname>.<domain name>/data/col1/<Mtree name>
```

・レプリケーション初期転送
```
replication initialise mtree://<destination hostname>.<domain name>/data/col1/<Mtree name>
```

・レプリケーション帯域制御設定(byte)
```
replication throttle add destination mtree://<destination hostname>.<domain name>/data/col1/<Mtree name> <曜日> <時間> 100000000
```

・レプリケーション帯域制御設定確認
```
replication throttle show
```

・リテンションロックポリシー追加
```
mtree retention-lock set min-retention-period 720min mtree /data/col1/<Mtree name>
mtree retention-lock set max-retention-period 1827days mtree /data/col1/<Mtree name>
```

・リテンションロックポリシー追加確認
```
mtree retention-lock status mtree /data/col1/<Mtree name>
```

・リテンションロックガバナンスモードenable
```
mtree retention-lock enable mode gavanance mtree /data/col1/<Mtree name>
```

・レプリケーション 帯域制御状態
```
replication throttle show performance all interval 1
```

・パスワード更新
```
passwd
```

・シャットダウン
```
poweroff
```
