# Red Hat Linux on EC2

## ライセンス購入方法

ライセンスの購入方法は2種類ある．

1. Red Hat Cloud AccessをRedHat.inc.から購入

   Red Hat社のグローバルサポートを直に受けられる．

2. Amazon MarketplaceでRed HatのAmazon Machine Image(AMI)を購入する.

   EC2インスタンスの料金にRed Hat社のサブスクリプション料金も含まれる．

   ※ただし，選べるインスタンスタイプに限りがある可能性．

## サポートバージョン

Amazon Marketplaceで購入できるRed Hat Linuxのバージョンは現時点で__5.11, 6.7, 7.2__ .

詳細は[Amazon Marketplace](https://aws.amazon.com/marketplace/b/2649367011?page=1&filters=VendorId%2CAmi::OperatingSystem%2CRegion&VendorId=e6a5002c-6dd0-4d1e-8196-0a1d1857229b&Ami::OperatingSystem=Rhel&Region=ap-northeast-1&searchTerms=&category=c3bc6a75-0c3a-46ce-8fdd-498b6fd88577)を参照.



## 要確認事項

* AWS上のYUMレポジトリ

## Reference

[ストラテジックアライアンス: RED HAT と AMAZON WEB SERVICES](https://www.redhat.com/ja/パートナー/ストラテジック・アライアンス/amazon-web-services)

