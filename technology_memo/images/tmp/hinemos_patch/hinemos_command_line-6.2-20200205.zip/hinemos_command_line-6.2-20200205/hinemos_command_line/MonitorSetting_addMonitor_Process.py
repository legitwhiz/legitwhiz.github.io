#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
プロセス監視の監視設定を登録する

<概要>
プロセス監視の監視設定を登録します。

<使用例>
[command]
    $ python MonitorSetting_addMonitor_Process.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I PROC1 -A MYAPP -F SCOPE001 -X java

[result]
    http://192.168.1.2:8080/HinemosWS/, addMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {
        'infoLowerThreshold': '1',
        'infoUpperThreshold': '99',
        'warnLowerThreshold': '99',
        'warnUpperThreshold': '99'
    }
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_add_args_parser(help_default_info)
    psr.add_option('-X', '--checkCommand', action='store', type='string',
                   metavar='STRING', dest='check_command',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='command')
    psr.add_option('-G', '--checkArgument', action='store', type='string',
                   metavar='STRING', dest='check_argument',
                   default=None, help='argument (RegEx e.g. ".*")')
    psr.add_option('-S', '--checkCaseSensitive', action='store', type='string',
                   metavar='BOOL', dest='check_case_sensitive_raw',
                   converter=SettingUtil.convert2nbool,
                   default=None, help='checkCaseSensitive (default: no)')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)
        endpoint.add_monitor_proc(vars(opts))

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
