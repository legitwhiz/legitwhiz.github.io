#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
文字列監視もしくはSNMPTRAP監視またはログ件数監視の監視情報を取得する

<概要>
文字列監視もしくはSNMPTRAP監視またはログ件数監視の監視情報を取得します。

<使用例>
[command]
    $ python MonitorSetting_getMonitorListForLogcount.py

[result]

    http://192.168.1.2:8080/HinemosWS/, getMonitorListForLogcount succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
from hinemos.api.monitorsetting import MonitorSettingEndpoint


def parse_args(args):
    psr = MyOptionParser()
    psr.add_option('-F', '--facilityId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='facilityId',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='facility id')
    psr.add_option('-R', '--ownerRoleId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='ownerRoleId',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='owner role id')
    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    ### login ###
    endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

    try:
        result = endpoint.call('getMonitorListForLogcount',
                               opts.facilityId, opts.ownerRoleId)
        return_code = ResultPrinter.success(
            result, opts.mgr_url, 'getMonitorListForLogcount')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
