#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定された条件に一致するステータス情報一覧を取得する

<概要>
引数で指定された条件に一致するステータス情報一覧を取得して表示します。

<使用例>
[command]
    $ python Monitor_getStatusList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_NODE -A agent01

[result]
    [(statusDataInfo){
       application = "agent01"
       facilityId = "TEST_NODE"
       facilityPath = "TEST_NODE"
       generationDate = "2017/03/08 11:36:45"
       message = "$[MESSAGE_AGENT_IS_AVAILABLE]"
       monitorDetailId = None
       monitorId = "AGENT01"
       outputDate = "2017/03/08 11:44:45.234"
       ownerRoleId = "ALL_USERS"
       pluginId = "MON_AGT_B"
       priority = 3
     }]
    http://192.168.1.2:8080/HinemosWS/, getStatusList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitor import MonitorEndpoint
from hinemos.util.notify import NotifyUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='Facility ID')

    psr.add_option('-P', '--priorities', action='store_split', type='string', metavar='STRING', dest='priorities_raw',
                    default=None, help='Priorities [INFO|WARN|CRITICAL|UNKNOWN]. Download all by default.')

    psr.add_option('-o', '--outputDateFrom', action='store', type='string', metavar='DATETIME', dest='output_date_from',
                    default=None, help='Output date from [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-O', '--outputDateTo', action='store', type='string', metavar='DATETIME', dest='output_date_to',
                    default=None, help='Output date to [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-g', '--createdDateFrom', action='store', type='string', metavar='DATETIME', dest='generation_date_from',
                    default=None, help='Created date from [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-G', '--createdDateTo', action='store', type='string', metavar='DATETIME', dest='generation_date_to',
                    default=None, help='Created date to [yyyy/mm/dd HH:MM:SS]')

    #TODO Monitor ID
    #TODO Monitor Detail ID

    psr.add_option('-T', '--facilityType', action='store', type='int', metavar='INT', dest='facility_type',
                    default=1, help='Facility type = 0(Sub-scope Facilities Only) or 1(ALL Facilities)')
    psr.add_option('-A', '--application', action='store', type='string', metavar='STRING', dest='application',
                    default=None, help='Application')
    psr.add_option('-M', '--message', action='store', type='string', metavar='STRING', dest='message',
                    default=None, help='Message')

    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=None, help='Owner Role ID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorEndpoint(opts.mgr_url, opts.user, opts.passwd)

        if opts.generation_date_from is not None:
            opts.generation_date_from = DateConvert.get_epochtime_from_datetime(opts.generation_date_from)
        if opts.generation_date_to is not None:
            opts.generation_date_to = DateConvert.get_epochtime_from_datetime(opts.generation_date_to)
        if opts.output_date_from is not None:
            opts.output_date_from = DateConvert.get_epochtime_from_datetime(opts.output_date_from)
        if opts.output_date_to is not None:
            opts.output_date_to = DateConvert.get_epochtime_from_datetime(opts.output_date_to)

        ### method edit###
        statusFilterInfo = endpoint.create_object('statusFilterInfo')
        if opts.application is not None:
            statusFilterInfo.application=opts.application
        if opts.facility_type is not None:
            statusFilterInfo.facilityType = opts.facility_type
        if opts.generation_date_from is not None:
            statusFilterInfo.generationDateFrom=opts.generation_date_from
        if opts.generation_date_to is not None:
            statusFilterInfo.generationDateTo=opts.generation_date_to
        if opts.message is not None:
            statusFilterInfo.message=opts.message
        if opts.output_date_from is not None:
            statusFilterInfo.outputDateFrom=opts.output_date_from
        if opts.output_date_to is not None:
            statusFilterInfo.outputDateTo=opts.output_date_to
        if opts.priorities is None:
            opts.priorities = ['INFO','WARN','CRITICAL','UNKNOWN']
        statusFilterInfo.priorityList=tuple(NotifyUtil.convert2priority(a) for a in opts.priorities)
        if opts.owner_role_id is not None:
            statusFilterInfo.ownerRoleId = opts.owner_role_id

        result = endpoint.getStatusList(opts.facility_id, statusFilterInfo)
        if result is not None:
            for i in range(len(result)):
                result[i].generationDate = DateConvert.get_datetime_from_epochtime(result[i].generationDate)
                result[i].outputDate = DateConvert.get_datetime_from_epochtime(result[i].outputDate)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getStatusList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
