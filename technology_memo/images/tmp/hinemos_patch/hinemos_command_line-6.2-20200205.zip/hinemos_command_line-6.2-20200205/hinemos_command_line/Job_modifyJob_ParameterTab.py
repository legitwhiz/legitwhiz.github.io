#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
「ジョブ変数」タブの情報を変更する

<概要>
「ジョブ変数」タブの情報を変更します。

<使用例>
- ジョブ変数タブのジョブ変数を追加します。
[command]
    $ python Job_modifyJob_ParameterTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001 -I NEWPARAM1 -A ADD -V "1234" -D "test"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- ジョブ変数タブのジョブ変数を変更します。
[command]
    $ python Job_modifyJob_ParameterTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001 -I NEWPARAM1 -A MOD -V 4321 -D "test!"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- ジョブ変数タブのジョブ変数を削除します。
[command]
    $ python Job_modifyJob_ParameterTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001 -I NEWPARAM1 -A DEL

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil
from hinemos.util.common import ResultPrinter

def main():

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='jobunit_id',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID"')

    ### ジョブ変数タブ設定項目 ###
    psr.add_option('-A', '--action', action='store', type='string', metavar='STRING', dest='action',
                    default=(None, 'REQUIRED', {'INLIST':['ADD','MOD','DEL']}), help='add a parameter = ADD, modify parameter value = MOD, delete a parameter = DEL')
    psr.add_option('-I', '--parameterID',  action='store', type='string', metavar='ID', dest='parameter_id',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='parameterID(job parameter tab): parameter ID')
    psr.add_option('-V', '--parameterValue', action='store', type='string', metavar='STRING', dest='parameter_value',
                    default=(None, 'NOTBLANK', {'WHEN':{'action':'ADD'}, 'DO':('REQUIRED')}), help='parameterValue(job parameter tab)')
    psr.add_option('-D', '--parameterDescription', action='store', type='string', metavar='STRING', dest='parameter_description',
                    default=None, help='parameterDescription(job parameter tab)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, opts.jobunit_id)
        del job_tree_full

        job_info_full = endpoint.getJobFull(endpoint.create_job_info_minimal(opts.jobunit_id, opts.jobunit_id))

        if opts.action == 'ADD':
            if not hasattr(job_info_full, 'param'):
                setattr(job_info_full, 'param', [])
            job_info_full.param.append(endpoint.create_job_parameter_info(\
                        JobUtil.convert2job_param_type('USER'), opts.parameter_id, opts.parameter_description, opts.parameter_value))
        elif opts.action == 'MOD':
            not_found = True
            if hasattr(job_info_full, 'param'):
                for x in job_info_full.param:
                    if x.paramId == opts.parameter_id:
                        not_found = False
                        x.description = opts.parameter_description
                        if opts.parameter_value is not None:
                            x.value = opts.parameter_value
            if not_found:
                raise ErrorHandler.ObjectNotFoundError('Parameter %s does not exist!' % opts.parameter_id)

        elif opts.action == 'DEL':
            not_found = True
            if hasattr(job_info_full, 'param'):
                for i, v in enumerate(job_info_full.param):
                    if v.paramId == opts.parameter_id:
                        not_found = False
                        del job_info_full.param[i]
            if not_found:
                raise ErrorHandler.ObjectNotFoundError('Parameter %s does not exist!' % opts.parameter_id)

        JobUtil.replace_job_info(job_tree, job_info_full)

        # Clean up and replace none with blank
        JobUtil.cleanup_and_fixnone(job_tree)

        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJob')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
