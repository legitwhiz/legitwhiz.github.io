#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
指定した監視ID、ファシリティIDに対する性能実績のデータファイルをダウンロードする

<概要>
指定した監視ID、ファシリティIDに対する性能実績のデータファイルをダウンロードします。

<使用例>
[command]
    $ python Collect_downloadPerfFile.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F SCOPE01,SCOPE001,NODE001 -T AVG_HOUR -D /tmp  -M PING001,CPU001

[result]
    download Average Hours_20170321153536.zip...
    download Average Hours_20170321153536.zip...
    download Average Hours_20170321153536.zip...
    output to C:\tmp\Average Hours_20170321153536.zip...
    http://192.168.1.2:8080/HinemosWS/, downloadPerfFile succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs, locale
import logging
from logging.config import fileConfig

import base64
import time
from hinemos.util.opt import MyOptionParser
from hinemos.util.collect import CollectUtil
from hinemos.util.repository import FacilityTree
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.collect import CollectEndpoint
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.common import ResultPrinter
from datetime import datetime


def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-F', '--facilityIDs', action='store_split', type='string', metavar='STRING', dest='facilityIDs_raw',
                    default=(None, 'REQUIRED','NOTBLANK'), help='Facility ID or scope ID list. Use a comma to separate multiple IDs')
    psr.add_option('-M', '--monitorIDs', action='store_split', type='string', metavar='STRING', dest='monitorIDs_raw',
                    default=(None, 'REQUIRED','NOTBLANK'), help='Monitor ID list. Use a comma to separate multiple IDs')
    psr.add_option('-T', '--summaryType', action='store', type='string', metavar='STRING', dest='summaryType_raw', converter=CollectUtil.convert2summary_type,
                    default=(None, 'REQUIRED', {'INLIST':CollectUtil._summary_type_}), help='Summary type (' + ', '.join(CollectUtil._summary_type_)+ ')')
    psr.add_option('-L', '--locale', action='store', type='string', metavar='STRING', dest='locale',
                    default=('en', 'NOTBLANK'), help='Locale. e.g. "en", "ja"')
    psr.add_option('-S', '--showHeader', action='store_true', dest='showHeader', default=False, help='Show header')
    psr.add_option('-D', '--outputDirectory', action='store', type='string', metavar='STRING', dest='outputDirectory',
                    default=(None, 'REQUIRED','NOTBLANK'), help='Output directory')
    psr.add_option('-W', '--maxWaitTime', action='store', type='int', metavar='INT', dest='maxWaitTime',
                    default=(10, 'REQUIRED'), help='Maximum wait time (minute)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### argument check ###
        directory = opts.outputDirectory.rstrip('\'')
        if not os.path.isdir(directory):
            raise ErrorHandler.ArgumentError('%s does not exists' % directory )

        ### login ###
        endpoint = CollectEndpoint(opts.mgr_url, opts.user, opts.passwd)
        repo_endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)
        monset_endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        maxWaitSec = int(opts.maxWaitTime) * 60

        # facilities
        id_name_map = {}
        for f_id in opts.facilityIDs:
            ftree = repo_endpoint.getExecTargetFacilityTreeByFacilityId(f_id, '')
            for k, v in FacilityTree.to_id_name_map(ftree).items():
                if k not in id_name_map:
                    id_name_map[k] = v

        # @see com.clustercontrol.ws.collect.CollectEndpoint#createPerfFile()
        #for monitor_id in opts.monitorIDs:
        #    map1 = endpoint.getCollectId(String itemName, String displayName, monitor_id, facility_ids) 
        map1 = endpoint._client.factory.create('hashMapInfo')
        for k, v in id_name_map.items():
            #map6 = endpoint._client.factory.create('map6')
            entry = {'key': k, 'value': v}
            map1.map6.entry.append(entry)

        #map1 = None
        #for a in collect_keys:
        #    map1_part = endpoint.getCollectId(a.itemName, a.displayName, a.monitorId, [a.facilityid])
        #    if map1:
        #        
        #    else:
        #        map1 = map1_part
        #LOGGER.debug(map1)
        # TODO Use getCollectId(opts.itemName, opts.displayName, opts.monitorId, opts.facilityIdList)

        collect_key_info_lst = []
        for a in endpoint.getItemCodeList(id_name_map.keys()):
            if a.monitorId in opts.monitorIDs:
                is_found = False
                for b in collect_key_info_lst:
                    if b.monitorId == a.monitorId and b.itemName == a.itemName:
                        is_found = True
                        break
                # HC
                if a.displayName is None:
                    a.displayName = ''
                a.facilityid = None
                collect_key_info_lst.append(a)

        # @see monset_endpoint.getItemCodeMap()
        # @see monset_endpoint.getAvailableCollectorItemList(facilityId)
        # TODO collect_keys = endpoint.getItemCodeList(id_name_map.keys())
        #LOGGER.debug(collect_keys)

        ''' Generate date str
        @see com.clustercontrol.collect.dialog.ExportDialog
            // 対象ファイル名に含めるID(日付)を生成
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            // クライアントで出力するファイル名の日時情報はクライアントのタイムゾーンの現在時刻とする(マネージャのタイムゾーン時刻に補正しない)
            String defaultDateStr = sdf.format(new Date(System.ppp()));
        '''
        default_date_str = datetime.now().strftime("%Y%m%d%H%M%S")

        filename_list = endpoint.createPerfFile(map1, collect_key_info_lst, id_name_map.keys(), opts.summaryType, opts.locale, opts.showHeader, default_date_str)
        if 0 == len(filename_list):
            raise ErrorHandler.BadResultError('No data!')

        for exFileName in filename_list:
            result = None
            time1 = time.time()
            while result is None:
                time.sleep(1)
                waitingTime = time.time() - time1
                if int(waitingTime) >= int(maxWaitSec):
                    raise RuntimeError('downloadPerfFile failed. The download operation has timed out.')
                LOGGER.info('download %s...', exFileName)
                result = endpoint.downloadPerfFile(exFileName)
            file_path = os.path.abspath(os.path.join(directory, exFileName))

            with open(file_path, 'wb') as f:
                LOGGER.info('output to %s...', file_path)
                f.write(base64.b64decode(result))

        endpoint.deletePerfFile(filename_list)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'downloadPerfFile')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)

    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
