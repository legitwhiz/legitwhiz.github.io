#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
Hinemosプロパティを削除する

<概要>
Hinemosプロパティを削除します。

<使用例>
[command]
    $ python HinemosProperty_deleteHinemosProperty.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -K my.new.property

[result]
    http://192.168.1.2:8080/HinemosWS/, deleteHinemosProperty succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.hinemosproperty import HinemosPropertyEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-K', '--key', action='store', type='string', metavar='STRING', dest='key',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='key')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = HinemosPropertyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        endpoint.deleteHinemosProperty(opts.key)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'deleteHinemosProperty')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
