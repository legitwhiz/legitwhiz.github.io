#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したメンテナンス情報を削除する

<概要>
引数で指定したメンテナンス情報を削除します。

<使用例>
[command]
    $ python Maintenance_deleteMaintenance.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_MA

[result]
    http://192.168.1.2:8080/HinemosWS/, deleteMaintenance succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.maintenance import MaintenanceEndpoint
from hinemos.util.common import ResultPrinter

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--maintenanceID',  action='store', type='string', metavar='ID', dest='maintenance_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='maintenanceID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MaintenanceEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        endpoint.deleteMaintenance(opts.maintenance_id)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'deleteMaintenance')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
