#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
カレンダ(基本)情報を登録する

<概要>
指定したカレンダを登録します。

<使用例>
[command]
    $ python Calendar_addCalendar.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_CAL -N TEST_CAL -F "2017/01/01 00:00:00" -T "2017/12/31 00:00:00"

[result]
    http://192.168.1.2:8080/HinemosWS/, addCalendar succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.calendar import CalendarEndpoint
from hinemos.util.calendar import CalendarUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='calendar ID')
    psr.add_option('-N', '--calendarName', action='store', type='string', metavar='STRING', dest='calendar_name',
                    default=(None, 'REQUIRED','NOTBLANK'), help='calendar Name')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='description')

    psr.add_option('-F', '--validTimeFrom', action='store', type='string', metavar='STRING', dest='valid_time_from_raw', converter=DateConvert.get_epochtime_from_datetime,
                   default=(None, 'REQUIRED', {'REGEXP':[r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}),
                   help='valid period from = \'yyyy/MM/dd HH:mm:ss\'')
    psr.add_option('-T', '--validTimeTo', action='store', type='string', metavar='STRING', dest='valid_time_to_raw', converter=DateConvert.get_epochtime_from_datetime,
                   default=(None, 'REQUIRED', {'REGEXP':[r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}),
                   help='valid period fo = \'yyyy/MM/dd HH:mm:ss\'')   

    psr.add_option('-d', '--detailDescription', action='store', type='string', metavar='STRING', dest='detail_description',
                   help='detailDescription')
    psr.add_option('-e', '--detail', action='store', type='string', metavar='STRING', dest='detail',
                    default=(None, 'NOTBLANK', {'REGEXP':[r'(Yearly|\d{4})[/ ](Monthly|\w+)[ /](Daily|\d{1,2}|Every-\w+|[1-5]-\w+|Pattern [^\s]+)$', 'format incorrect!']}, {'WHEN':{'action':'ADD'}, 'DO':('REQUIRED')}),
                    help='format : "$YEAR $MONTH $DAY/$PATTERN". e.g. "Yearly Monthly Daily", "1998/12 Daily", "Yearly 01 Pattern holiday2013-2020", "2015 Monthly 30", "2015/02/28", "2015/12 Every-Sun", "2015/12 1-Sun"')
# Detail examples:
#     "Yearly Monthly Daily"
#     "1998/12 Daily"
#     "Yearly 01 Pattern holiday2013-2020"
#     "2015 Monthly 30"
#     "2015/02/28"
#     "2015/12 Every-Sun"
#     "2015/12 1-Sun"

    psr.add_option('-p', '--dayAfter', action='store', type='int', metavar='INT', dest='afterday',
                   default=None, help='day after. A negative (\'-\') integer means day(s) before (default: 0)')

    
    psr.add_option('-f', '--substituteFlg', action='store', type='string', metavar='BOOL', dest='substitute_flg_raw', converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='substituteFlg =true, non-substituteFlg = no (default: no)')
    psr.add_option('-l', '--substituteLimit', action='store', type='int', metavar='INT', dest='substitute_limit',
                    default=None, help='substituteLimit = integer (default: 10)')
    psr.add_option('-m', '--substituteTime', action='store', type='int', metavar='INT', dest='substitute_time',
                    default=None, help='substituteTime = integer (default: 24)')
    psr.add_option('-s', '--timeFrom', action='store', type='string', metavar='STRING', dest='time_from_raw', converter=DateConvert.get_epochtime_from_time,
                    default=(None,{'REGEXP':[r'^\d\d:\d\d:\d\d$', 'format must be HH:MM:SS']}), help='time from =  HH:mm:ss (default: 00:00:00)')
    psr.add_option('-t', '--timeTo', action='store', type='string', metavar='STRING', dest='time_to_raw', converter=DateConvert.get_epochtime_from_time,
                    default=(None, {'REGEXP':[r'^\d\d:\d\d:\d\d$', 'format must be HH:MM:SS']}), help='time to = HH:mm:ss (default: 24:00:00)')
    psr.add_option('-o', '--operational', action='store', type='string', metavar='BOOL', dest='operational_raw', converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='operational =true, non-operational = no (default: true)')

    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=None, help='ownerRoleID (default: ALL_USERS)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = CalendarEndpoint(opts.mgr_url, opts.user, opts.passwd)

        if opts.detail:
            subelem = endpoint.create_calendar_detail_info(opts.detail_description, opts.afterday, opts.substitute_flg, opts.substitute_limit, opts.substitute_time, opts.time_from, opts.time_to, opts.operational)
            CalendarUtil.set_calendar_ymddetail(subelem, opts.detail)
            calendar_detail_info_list = [ subelem ]
        else:
            calendar_detail_info_list = None

        ###  calendar_info parameter ###
        calendar_info = endpoint.create_calendar_info(calendar_id=opts.calendar_id, name=opts.calendar_name, description=opts.description, owner_role_id=opts.owner_role_id, valid_time_from=opts.valid_time_from, valid_time_to=opts.valid_time_to, calendar_detail_info_list=calendar_detail_info_list)

        endpoint.addCalendar(calendar_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addCalendar')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
