#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
環境構築ファイルをダウンロードする

<概要>
環境構築ファイルをダウンロードします。

<使用例>
[command]
    $ python Infra_downloadInfraFile.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I "HINEMOS_AGENT_LINUX"

[result]
    Download hinemos-6.0-agent-6.0.0-1.el.noarch.rpm(HINEMOS_AGENT_LINUX) to ./hinemos-6.0-agent-6.0.0-1.el.noarch.rpm
    http://192.168.1.2:8080/HinemosWS/, downloadInfraFile succeeded.
"""

import sys
import codecs, locale, os, base64
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.infra import InfraEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--fileID',  action='store', type='string', metavar='ID', dest='file_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='file id')
    psr.add_option('-o', '--outputPath', action='store', type='string', metavar='STRING', dest='output_path',
                    default=None, help='output path')
    psr.add_option('-f', '--force', action='store_true', dest='force',
                    default=None, help='force overwrite when file existed')
    opts = psr.parse_opts(sys.argv)
    del psr



    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### check argument ###
        file_dir = None
        file_name = None
        if opts.output_path is not None:
            file_dir = opts.output_path
            if file_dir.endswith(os.path.sep):
                pass
            elif os.path.isdir(file_dir):
                if file_dir.endswith(os.path.sep):
                    file_dir += os.path.sep
            else:
                file_name = os.path.basename(file_dir)
                file_dir = os.path.dirname(file_dir) + os.path.sep
        else:
            file_dir = '.' + os.path.sep

        ### login ###
        endpoint = InfraEndpoint(opts.mgr_url, opts.user, opts.passwd)

        file_info = endpoint.get_infra_file(opts.file_id)

        print "###########", file_info

        if file_name is None:
            file_name = file_info.fileName

        # Check if file exists
        if not opts.force and os.path.exists(file_dir + file_name):
            raise ErrorHandler.PortingExportError('Destination file already existed! Use -f to force overwrite.')

        print 'Download', file_info.fileName + '(' + file_info.fileId + ') to', file_dir + file_name, '...'
        file_content = endpoint.downloadInfraFile(opts.file_id, file_info.fileName)
        with open(file_dir + file_name, 'wb') as fp:
            fp.write(base64.b64decode(file_content))
        return_code = ResultPrinter.success(None, opts.mgr_url, 'downloadInfraFile')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
