#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブキュー(同時実行制御キュー)の活動状況を一覧表示するビューのための情報を返す

<概要>
ジョブキュー(同時実行制御キュー)の活動状況を一覧表示するビューのための情報を返します。

<使用例>
[command]
    $ python Job_getJobQueueActivityViewInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    (jobQueueActivityViewInfo){
      items[] =
        (jobQueueActivityViewInfoListItem){
           activeCount = 4
           concurrency = 4
           count = 10
           name = "TestQueue"
           ownerRoleId = "ALL_USERS"
           queueId = "TESTQ01"
           regDate = "2019/03/20 19:31:06.794"
           regUser = "hinemos"
           updateDate = "2019/03/20 19:31:06.794"
           updateUser = "hinemos"
        },
    }
    http://127.0.0.1:8080/HinemosWS/, getJobQueueActivityViewInfo succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
from hinemos.api.job import JobEndpoint
from hinemos.util.modifier import ObjectModifier


def main():

    psr = MyOptionParser()
    psr.add_option('--jobCountFrom', action='store', type='int', metavar='INT', dest='job_count_from',
                   default=(None, 'INTEGER'), help='Active Job Count Minimum Value')
    psr.add_option('--jobCountTo', action='store', type='int', metavar='INT', dest='job_count_to',
                   default=(None, 'INTEGER'), help='Active Job Count Maximum Value')
    psr.add_option('-I', '--queueId', action='store', type='string', metavar='ID', dest='queue_id',
                   default=(None, 'NOTBLANK'), help='Job Queue ID')
    psr.add_option('-N', '--queueName', action='store', type='string', metavar='STRING', dest='queue_name',
                   default=(None, 'NOTBLANK'), help='Job Queue name')
    psr.add_option('--concurrencyFrom', action='store', type='int', metavar='INT', dest='concurrency_from',
                   default=(None, 'INTEGER'), help='Concurrency Minimum Value')
    psr.add_option('--concurrencyTo', action='store', type='int', metavar='INT', dest='concurrency_to',
                   default=(None, 'INTEGER'), help='Concurrency Maximum Value')
    psr.add_option('-R', '--ownerRoleID', action='store', type='string', metavar='STRING', dest='owner_role_id',
                   default=('ALL_USERS', 'NOTBLANK'), help='Owner role ID (default: ALL_USERS)')
    psr.add_option('--regUser', action='store', type='string', metavar='STRING', dest='reg_user',
                   default=(None, 'NOTBLANK'), help='Job Queue Creation User')
    psr.add_option('--regDateFrom', action='store', type='string', metavar='STRING', dest='reg_date_from',
                   default=(None, {'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}),
                   help='Datetime format: "yyyy/mm/dd HH:MM:SS"')
    psr.add_option('--regDateTo', action='store', type='string', metavar='STRING', dest='reg_date_to',
                   default=(None, {'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}),
                   help='Datetime format: "yyyy/mm/dd HH:MM:SS"')
    psr.add_option('--updateUser', action='store', type='string', metavar='STRING', dest='update_user',
                   default=(None, 'NOTBLANK'), help='Job Queue Updated User')
    psr.add_option('--updateDateFrom', action='store', type='string', metavar='STRING', dest='update_date_from',
                   default=(None, {'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}),
                   help='Datetime format: "yyyy/mm/dd HH:MM:SS"')
    psr.add_option('--updateDateTo', action='store', type='string', metavar='STRING', dest='update_date_to',
                   default=(None, {'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}),
                   help='Datetime format: "yyyy/mm/dd HH:MM:SS"')

    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        filter_obj = endpoint.create_object('jobQueueActivityViewFilter')
        ObjectModifier.replace_if_not_none(
            filter_obj,
            jobCountFrom=opts.job_count_from,
            jobCountTo=opts.job_count_to,
            queueId=opts.queue_id,
            queueName=opts.queue_name,
            concurrencyFrom=opts.concurrency_from,
            concurrencyTo=opts.concurrency_to,
            ownerRoleId=opts.owner_role_id,
            regUser=opts.reg_user,
            regDateFrom=DateConvert.get_epochtime_from_datetime(opts.reg_date_from),
            regDateTo=DateConvert.get_epochtime_from_datetime(opts.reg_date_to),
            updateUser=opts.update_user,
            updateDateFrom=DateConvert.get_epochtime_from_datetime(opts.update_date_from),
            updateDateTo=DateConvert.get_epochtime_from_datetime(opts.update_date_to))

        result = endpoint.getJobQueueActivityViewInfo(filter_obj)

        if result is not None and hasattr(result, 'items'):
            for item in result.items:
                if 'regDate' in item:
                    item.regDate = DateConvert.get_datetime_from_epochtime(item.regDate)
                if 'updateDate' in item:
                    item.updateDate = DateConvert.get_datetime_from_epochtime(item.updateDate)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getJobQueueActivityViewInfo')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
