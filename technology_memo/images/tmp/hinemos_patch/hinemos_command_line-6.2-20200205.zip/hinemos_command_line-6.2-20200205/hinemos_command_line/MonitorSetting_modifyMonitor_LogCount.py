#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ログ件数監視の監視設定情報を変更する

<概要>
ログ件数監視の監視設定情報を変更します。

<使用例>
[command]
    $ python MonitorSetting_modifuMonitor_LogCount

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder
from hinemos.util.monitorsetting import MonitorSettingUtil as util


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_modify_args_parser(help_default_info)

    psr.add_option('--targetMonitorId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='targetMonitorId',
                   default=None,
                   help='target monitor id')
    psr.add_option('--keyword',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='keyword',
                   default=None,
                   help='keyword')
    psr.add_option('--isAnd',
                   action='store',
                   type='string',
                   metavar='BOOL',
                   dest='isAnd_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='AND=true, OR=false')
    psr.add_option('--countMethod',
                   action='store',
                   type='string',
                   metavar='STING',
                   dest='tag_raw',
                   converter=util.converter2logCountMethod,
                   default=None,
                   help='count method: %s'
                   % str(util._log_count_method_.keys()))

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    ### login ###
    endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

    try:
        endpoint.modify_monitor_log_count(vars(opts))
        return_code = ResultPrinter.success(
            None, opts.mgr_url, 'modifyMonitor')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    # sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    # sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
