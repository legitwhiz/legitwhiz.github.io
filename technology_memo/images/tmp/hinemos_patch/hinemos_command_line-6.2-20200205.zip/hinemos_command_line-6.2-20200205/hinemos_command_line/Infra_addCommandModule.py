#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
コマンドモジュールを作成する

<概要>
コマンドモジュールを作成します。

<使用例>
[command]
    $ python Infra_addCommandModule.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -M MAN001 -I CMOD001 -N "Delete module" -A SSH -P true -S true -C "ls /__path__/" -E "rm -rf /__path__/" -e true

[result]
    http://192.168.1.2:8080/HinemosWS/, addCommandModule succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.infra import InfraEndpoint
from hinemos.util.infra import InfraUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-M', '--managementID',  action='store', type='string', metavar='ID', dest='management_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='infra management ID')
    psr.add_option('-I', '--moduleID',  action='store', type='string', metavar='ID', dest='module_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='module ID')
    psr.add_option('-N', '--name', action='store', type='string', metavar='STRING', dest='name',
                   default=(None, 'REQUIRED','NOTBLANK'), help='name')
    psr.add_option('-A', '--accessMethod', action='store', type='string', metavar='STRING', dest='access_method',
                   default=(None, 'REQUIRED',{'INLIST':['SSH', 'WinRM']}), help='use SSH or WinRM')
    psr.add_option('-P', '--precheck', action='store', type='string', metavar='BOOL', dest='precheck_raw', converter=SettingUtil.convert2nbool,
                   default=(None, 'REQUIRED',{'INLIST':['true','false']}), help='run pre-check before running')
    psr.add_option('-S', '--stopIfFail', action='store', type='string', metavar='BOOL', dest='stopIfFail_raw', converter=SettingUtil.convert2nbool,
                   default=(None, 'REQUIRED',{'INLIST':['true','false']}), help='stop when there is any module failed')
    psr.add_option('-C', '--checkCommand', action='store', type='string', metavar='STRING', dest='check_command',
                   default=(None, 'REQUIRED','NOTBLANK'), help='pre-check command')
    psr.add_option('-E', '--execCommand', action='store', type='string', metavar='STRING', dest='exec_command',
                   default=(None, 'REQUIRED','NOTBLANK'), help='execution command')
    psr.add_option('-e', '--enable', action='store', type='string', metavar='BOOL', dest='enable_raw', converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false (default: true)')
    opts = psr.parse_opts(sys.argv)
    del psr

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = InfraEndpoint(opts.mgr_url, opts.user, opts.passwd)

        access_method_type = InfraUtil.convert2access_method_type(opts.access_method)

        endpoint.add_command_module(opts.management_id, opts.module_id, opts.name, \
                                    access_method_type, opts.precheck, opts.stopIfFail, opts.check_command, opts.exec_command, \
                                    opts.enable)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addCommandModule')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
