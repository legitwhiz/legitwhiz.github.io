#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したジョブのジョブ操作を行う

<概要>
引数で指定したジョブのジョブ操作を行います。

開始[即時]:TYPE_START_AT_ONCE,開始[中断解除]:TYPE_START_SUSPEND,開始[スキップ解除]:TYPE_START_SKIP,開始[保留解除]:TYPE_START_WAIT

停止[コマンド]:TYPE_STOP_AT_ONCE,停止[中断]:TYPE_STOP_SUSPEND,停止[スキップ]:TYPE_STOP_SKIP,停止[保留]:TYPE_STOP_WAIT,停止[状態変更]:TYPE_STOP_MAINTENANCE,停止[状態指定]:TYPE_STOP_SET_END_VALUE,停止[強制]:TYPE_STOP_FORCE


<使用例>
[command]
    $ python Job_operationJob.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J TEST_JOBU -I TEST_JOB -C 8 -s 0 -v 0 -S  20170307102729-000

[result]
    http://192.168.1.2:8080/HinemosWS/, operationJob succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.common import ResultPrinter

def main():

    psr = MyOptionParser()
    psr.add_option('-S', '--sessionID',  action='store', type='string', metavar='ID', dest='session_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='sessionID')
    psr.add_option('-J', '--jobunitID',  action='store', type='string', metavar='ID', dest='jobunit_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='jobunit ID')
    psr.add_option('-I', '--jobID',  action='store', type='string', metavar='ID', dest='job_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='job ID')
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default='', help='facilityID')
    psr.add_option('-C', '--control', action='store', type='int', metavar='INT', dest='control',
                    default=(None, 'REQUIRED',{'INLIST':[0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 11]}), help='control: TYPE_START_AT_ONCE = 1, TYPE_START_SUSPEND = 3, TYPE_START_SKIP = 5, TYPE_START_WAIT = 7, TYPE_STOP_AT_ONCE = 0, TYPE_STOP_SUSPEND = 2, TYPE_STOP_SKIP = 4, TYPE_STOP_WAIT = 6, TYPE_STOP_MAINTENANCE = 8, TYPE_STOP_SET_END_VALUE = 10, TYPE_STOP_FORCE = 11')
    psr.add_option('-s', '--endStatus', action='store', type='int', metavar='INT', dest='end_status',
                    default=(None, 'REQUIRED',{'INLIST':[0, 1, 2]}), help='endStatus: Normal = 0, Warning = 1, Error = 2')
    psr.add_option('-v', '--endValue', action='store', type='string', metavar='STRING', dest='end_value',
                    default='', help='endValue')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        ### OperationInfo Parameter ###
        OperationInfo = endpoint.create_object('jobOperationInfo')
        OperationInfo.sessionId = opts.session_id
        OperationInfo.jobunitId = opts.jobunit_id
        OperationInfo.jobId = opts.job_id
        OperationInfo.facilityId = opts.facility_id
        OperationInfo.control = opts.control
        OperationInfo.endStatus = opts.end_status
        OperationInfo.endValue = opts.end_value

        endpoint.operationJob(OperationInfo)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'operationJob')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
