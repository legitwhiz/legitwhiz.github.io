#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定されたイベント情報のコメント、確認、性能グラフ用フラグ、ユーザ拡張イベント項目を変更する

<概要>
引数で指定されたイベント情報のコメント、確認、性能グラフ用フラグ、ユーザ拡張イベント項目を変更します。
上記以外の項目は変更されません。
監視項目ID、監視詳細、プラグインID、ファシリティID、受信日時は必須項目です。

<使用例>
[command]
    $ python Monitor_modifyEventInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos  -I TEST_PING  -D ""
    -P MON_PNG_N -F TEST_NODE -O "2019/04/24 20:33:01.055" -C "Test Comment" --userItem02 "Test Value"

[result]
    http://127.0.0.1:8080/HinemosWS/, modifyEventInfo succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.monitor import MonitorEndpoint
from hinemos.util.common import SettingUtil, DateConvert, ResultPrinter
from hinemos.util.notify import NotifyUtil
from hinemos.util.modifier import ObjectModifier


def main():

    psr = MyOptionParser()

    psr.add_option('-I', '--monitorID', action='store', type='string', metavar='ID', dest='monitor_id',
                   default=(None, 'REQUIRED'), help='Monitor ID')
    psr.add_option('-D', '--monitorDetailID', action='store', type='string', metavar='ID', dest='monitor_detail_id',
                   default=(None, 'REQUIRED'), help='Monitor Detail ID')
    psr.add_option('-P', '--pluginID', action='store', type='string', metavar='ID', dest='plugin_id',
                   default=(None, 'REQUIRED'), help='Plugin ID')
    psr.add_option('-F', '--facilityID', action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None, 'REQUIRED'), help='Facility ID')
    psr.add_option('-O', '--outputDate', action='store', type='string', metavar='DATE', dest='output_date_raw',
                   converter=DateConvert.get_epochtime_from_datetime,
                   default=(None, 'REQUIRED', {'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d.\d\d\d$',
                                                          ' must be in [yyyy/mm/dd HH:MM:SS.sss] format']}),
                   help='Output date [yyyy/mm/dd HH:MM:SS.sss]')

    psr.add_option('-C', '--comment', action='store', type='string', metavar='STRING', dest='comment',
                   default=None, help='Comment')
    psr.add_option('-K', '--confirmFlg', action='store', type='string', metavar='STRING', dest='confirm_flg_raw',
                   converter=NotifyUtil.convert2confirm_flg,
                   default=(None, {'INLIST': ['UNCONFIRMED', 'CONFIRMED', 'CONFIRMING']}),
                   help='Confirm Flag= UNCONFIRMED, CONFIRMED, CONFIRMING')
    psr.add_option('-G', '--collectGraphFlg', action='store', type='string', metavar='BOOL',
                   dest='collect_graph_flg_raw', converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['on', 'off']}), help='Performance Graph Flag(on or off)')

    # User Item
    psr.add_option('--userItem01', action='store', type='string', metavar='STRING', dest='user_item_01',
                   default=None, help='User item01')

    psr.add_option('--userItem02', action='store', type='string', metavar='STRING', dest='user_item_02',
                   default=None, help='User item02')

    psr.add_option('--userItem03', action='store', type='string', metavar='STRING', dest='user_item_03',
                   default=None, help='User item03')

    psr.add_option('--userItem04', action='store', type='string', metavar='STRING', dest='user_item_04',
                   default=None, help='User item04')

    psr.add_option('--userItem05', action='store', type='string', metavar='STRING', dest='user_item_05',
                   default=None, help='User item05')

    psr.add_option('--userItem06', action='store', type='string', metavar='STRING', dest='user_item_06',
                   default=None, help='User item06')

    psr.add_option('--userItem07', action='store', type='string', metavar='STRING', dest='user_item_07',
                   default=None, help='User item07')

    psr.add_option('--userItem08', action='store', type='string', metavar='STRING', dest='user_item_08',
                   default=None, help='User item08')

    psr.add_option('--userItem09', action='store', type='string', metavar='STRING', dest='user_item_09',
                   default=None, help='User item09')

    psr.add_option('--userItem10', action='store', type='string', metavar='STRING', dest='user_item_10',
                   default=None, help='User item10')

    psr.add_option('--userItem11', action='store', type='string', metavar='STRING', dest='user_item_11',
                   default=None, help='User item11')

    psr.add_option('--userItem12', action='store', type='string', metavar='STRING', dest='user_item_12',
                   default=None, help='User item12')

    psr.add_option('--userItem13', action='store', type='string', metavar='STRING', dest='user_item_13',
                   default=None, help='User item13')

    psr.add_option('--userItem14', action='store', type='string', metavar='STRING', dest='user_item_14',
                   default=None, help='User item14')

    psr.add_option('--userItem15', action='store', type='string', metavar='STRING', dest='user_item_15',
                   default=None, help='User item15')

    psr.add_option('--userItem16', action='store', type='string', metavar='STRING', dest='user_item_16',
                   default=None, help='User item16')

    psr.add_option('--userItem17', action='store', type='string', metavar='STRING', dest='user_item_17',
                   default=None, help='User item17')

    psr.add_option('--userItem18', action='store', type='string', metavar='STRING', dest='user_item_18',
                   default=None, help='User item18')

    psr.add_option('--userItem19', action='store', type='string', metavar='STRING', dest='user_item_19',
                   default=None, help='User item19')

    psr.add_option('--userItem20', action='store', type='string', metavar='STRING', dest='user_item_20',
                   default=None, help='User item20')

    psr.add_option('--userItem21', action='store', type='string', metavar='STRING', dest='user_item_21',
                   default=None, help='User item21')

    psr.add_option('--userItem22', action='store', type='string', metavar='STRING', dest='user_item_22',
                   default=None, help='User item22')

    psr.add_option('--userItem23', action='store', type='string', metavar='STRING', dest='user_item_23',
                   default=None, help='User item23')

    psr.add_option('--userItem24', action='store', type='string', metavar='STRING', dest='user_item_24',
                   default=None, help='User item24')

    psr.add_option('--userItem25', action='store', type='string', metavar='STRING', dest='user_item_25',
                   default=None, help='User item25')

    psr.add_option('--userItem26', action='store', type='string', metavar='STRING', dest='user_item_26',
                   default=None, help='User item26')

    psr.add_option('--userItem27', action='store', type='string', metavar='STRING', dest='user_item_27',
                   default=None, help='User item27')

    psr.add_option('--userItem28', action='store', type='string', metavar='STRING', dest='user_item_28',
                   default=None, help='User item28')

    psr.add_option('--userItem29', action='store', type='string', metavar='STRING', dest='user_item_29',
                   default=None, help='User item29')

    psr.add_option('--userItem30', action='store', type='string', metavar='STRING', dest='user_item_30',
                   default=None, help='User item30')

    psr.add_option('--userItem31', action='store', type='string', metavar='STRING', dest='user_item_31',
                   default=None, help='User item31')

    psr.add_option('--userItem32', action='store', type='string', metavar='STRING', dest='user_item_32',
                   default=None, help='User item32')

    psr.add_option('--userItem33', action='store', type='string', metavar='STRING', dest='user_item_33',
                   default=None, help='User item33')

    psr.add_option('--userItem34', action='store', type='string', metavar='STRING', dest='user_item_34',
                   default=None, help='User item34')

    psr.add_option('--userItem35', action='store', type='string', metavar='STRING', dest='user_item_35',
                   default=None, help='User item35')

    psr.add_option('--userItem36', action='store', type='string', metavar='STRING', dest='user_item_36',
                   default=None, help='User item36')

    psr.add_option('--userItem37', action='store', type='string', metavar='STRING', dest='user_item_37',
                   default=None, help='User item37')

    psr.add_option('--userItem38', action='store', type='string', metavar='STRING', dest='user_item_38',
                   default=None, help='User item38')

    psr.add_option('--userItem39', action='store', type='string', metavar='STRING', dest='user_item_39',
                   default=None, help='User item39')

    psr.add_option('--userItem40', action='store', type='string', metavar='STRING', dest='user_item_40',
                   default=None, help='User item40')

    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = MonitorEndpoint(opts.mgr_url, opts.user, opts.passwd)

        event_data_info = endpoint.create_object('eventDataInfo')

        ObjectModifier.replace_if_not_none(
            event_data_info,
            comment=opts.comment,
            confirmed=opts.confirm_flg,
            collectGraphFlg=opts.collect_graph_flg,
            monitorId=opts.monitor_id,
            monitorDetailId=opts.monitor_detail_id,
            pluginId=opts.plugin_id,
            facilityId=opts.facility_id,
            outputDate=opts.output_date,
            userItem01=opts.user_item_01,
            userItem02=opts.user_item_02,
            userItem03=opts.user_item_03,
            userItem04=opts.user_item_04,
            userItem05=opts.user_item_05,
            userItem06=opts.user_item_06,
            userItem07=opts.user_item_07,
            userItem08=opts.user_item_08,
            userItem09=opts.user_item_09,
            userItem10=opts.user_item_10,
            userItem11=opts.user_item_11,
            userItem12=opts.user_item_12,
            userItem13=opts.user_item_13,
            userItem14=opts.user_item_14,
            userItem15=opts.user_item_15,
            userItem16=opts.user_item_16,
            userItem17=opts.user_item_17,
            userItem18=opts.user_item_18,
            userItem19=opts.user_item_19,
            userItem20=opts.user_item_20,
            userItem21=opts.user_item_21,
            userItem22=opts.user_item_22,
            userItem23=opts.user_item_23,
            userItem24=opts.user_item_24,
            userItem25=opts.user_item_25,
            userItem26=opts.user_item_26,
            userItem27=opts.user_item_27,
            userItem28=opts.user_item_28,
            userItem29=opts.user_item_29,
            userItem30=opts.user_item_30,
            userItem31=opts.user_item_31,
            userItem32=opts.user_item_32,
            userItem33=opts.user_item_33,
            userItem34=opts.user_item_34,
            userItem35=opts.user_item_35,
            userItem36=opts.user_item_36,
            userItem37=opts.user_item_37,
            userItem38=opts.user_item_38,
            userItem39=opts.user_item_39,
            userItem40=opts.user_item_40
        )
        endpoint.modifyEventInfo(event_data_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyEventInfo')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
