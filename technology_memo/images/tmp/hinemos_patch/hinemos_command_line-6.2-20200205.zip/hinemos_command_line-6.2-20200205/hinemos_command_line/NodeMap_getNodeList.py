#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
対象日時時点のノード一覧を取得する

<概要>
対象日時時点のノード一覧を取得します。

<使用例>
対象日時を指定した場合、対象日時まで追加したノード一覧を取得して表示されます。対象日時を指定しない場合、最新ノード一覧を取得して表示されます。
[command]
    $ python NodeMap_getNodeList.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -I OS -T "2019/06/26 00:00:00" -A true -S "[{\"nodeConfigSettingItemName\" : \"HOSTNAME\",\"exists\" : \"true\", \"itemList\" :[{  \"itemName\" : \"HOSTNAME\",  \"method\" : \"=\",  \"itemValue\" : \"hinemos\"}]}]"

[result]
    [(NodeInfo){
       facilityId = "hinemos_agent1"
       facilityName = "hinemos_agent1"
       platformFamily = "LINUX"
       ownerRoleId = "ALL_USERS"
       createDatetime = "2019/06/14 14:37:50.701"
       modifyDatetime = "2019/06/18 04:05:40.017"
     }, (NodeInfo){
       facilityId = "hinemos_agent2"
       facilityName = "hinemos_agent2"
       platformFamily = "LINUX"
       ownerRoleId = "ALL_USERS"
       createDatetime = "2019/06/10 10:23:46.888"
       modifyDatetime = "2019/06/18 14:23:51.568"
     }]

    http://127.0.0.1:8080/HinemosWS/, getNodeList succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale
import json
import re
from zeep import xsd
from hinemos.util.opt import MyOptionParser
from hinemos.api.nodemap import NodeMapEndpoint
from hinemos.util.common import DateConvert, ResultPrinter, SettingUtil
from hinemos.util.modifier import ObjectModifier
from hinemos.util.nodemap import ResultSet


def main():
    psr = MyOptionParser()
    psr.add_option('-I', '--facilityID', action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Facility ID')
    psr.add_option('-T', '--targetDateTime', action='store', type='string', metavar='DATE', dest='target_date_time_raw',
                   converter=DateConvert.get_epochtime_from_datetime,
                   default=(None, {'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$',
                                              'must be in [yyyy/mm/dd HH:MM:SS] format']}),
                   help='Target Date Time [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-A', '--and', action='store', type='string', metavar='BOOL', dest='filter_is_and_raw',converter=SettingUtil.convert2nbool,
                    default=('true', {'INLIST':['true','false']}), help='Search Condition And=true, Or=false')
    psr.add_option('-S', '--searchConditionJson', action='store', type='string', metavar='STRING', dest='search_j',
                   default=None, help='Add Search Condition. Please specify in JSON.')
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = NodeMapEndpoint(opts.mgr_url, opts.user, opts.passwd)

        node_info = endpoint.get_obj('ns0', 'nodeInfo')

        ObjectModifier.replace_if_not_none(
            node_info,
            nodeConfigTargetDatetime=opts.target_date_time)
        
        ObjectModifier.replace_if_not_none(
            node_info,
            nodeConfigFilterIsAnd=opts.filter_is_and)
        
        if opts.search_j is not None:
            json_obj = json.loads(opts.search_j.encode(locale.getdefaultlocale()[1]))
            for item in json_obj:
                for itemList in item["itemList"]:
                    if isinstance(itemList["itemValue"], int):
                        itemList["itemValue"] = xsd.AnyObject(xsd.Int(), itemList["itemValue"])
                    
                    if isinstance(itemList["itemValue"], str) or isinstance(itemList["itemValue"], unicode):
                        if isDateStr(item["nodeConfigSettingItemName"], itemList["itemName"]) :
                            pattern = '^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$'
                            regret = re.match(pattern, itemList["itemValue"])
                            if regret:
                                itemList["itemValue"] = xsd.AnyObject(xsd.Long(), DateConvert.get_epochtime_from_datetime(itemList["itemValue"]))
                            else:
                                itemList["itemValue"] = xsd.AnyObject(xsd.String(), itemList["itemValue"])
                        else:
                            itemList["itemValue"] = xsd.AnyObject(xsd.String(), itemList["itemValue"])
                    
                node_info.nodeConfigFilterList.append(item)
            
        result = endpoint.getNodeList(opts.facility_id, node_info)

        node_list = []
        if result is not None:
            node_list = ResultSet.format_node_list_info(result)

        return_code = ResultPrinter.success(node_list, opts.mgr_url, 'getNodeList')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code

def isDateStr(nodeConfigSttingItemName, itemName):
    if (nodeConfigSttingItemName == "OS" and itemName == "OS_STARTUP_DATE_TIME") \
    or (nodeConfigSttingItemName == "PROCESS" and itemName == "PROCESS_STARTUP_DATE_TIME") \
    or (nodeConfigSttingItemName == "PACKAGE" and itemName == "PACKAGE_INSTALL_DATE") \
    or (nodeConfigSttingItemName == "LICENSE" and itemName == "LICENSE_EXPIRATION_DATE"):
        return True
    else:
        return False
    
if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
