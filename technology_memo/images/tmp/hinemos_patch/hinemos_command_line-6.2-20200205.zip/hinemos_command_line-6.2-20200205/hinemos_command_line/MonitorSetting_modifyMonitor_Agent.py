#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
Hinemosエージェント監視の監視設定情報を変更する

<概要>
Hinemosエージェント監視の監視設定情報を変更します。

<使用例>
[command]
    $ python MonitorSetting_modifyMonitor_Agent.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I AGT001 -A MYAPP -F SCOPE001

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.notify import NotifyUtil
from hinemos.util.modifier import ObjectModifier
from hinemos.util.argsparserbuilder import MonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = MonitorSettingArgsParserBuilder()\
        .build_monitor_setting_modify_args_parser(help_default_info,
                                                  exclude=['collect'])

    psr.add_option('-O', '--okPriority', action='store', type='string',
                   metavar='STRING', dest='ok_priority_raw',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                       'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']
                   }),
                   help='okPriority = INFO or WARN or CRITICAL or UNKNOWN')
    psr.add_option('-G', '--ngPriority', action='store', type='string',
                   metavar='STRING', dest='ng_priority_raw',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                       'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']
                   }),
                   help='ngPriority = INFO or WARN or CRITICAL or UNKNOWN')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ###  monitor_info parameter ###
        monitor_info = endpoint.getMonitor(opts.monitor_id)

        # Modification
        with ObjectModifier(monitor_info) as modifier:
            modifier.set_if_first_not_none('application', opts.application)
            modifier.set_if_first_not_none('calendarId', opts.calendar_id)
            modifier.set_if_first_not_none('description', opts.description)
            modifier.set_if_first_not_none(
                'facilityId', opts.facility_id, scope=' ')
            modifier.set_if_first_not_none(
                'monitorFlg', opts.monitor)

            modifier.set_if_first_not_none('runInterval', opts.run_interval)

            modifier.change_ptr('truthValueInfo')
            modifier.replace_if_not_none(modifier.select(truthValue=1),
                                         priority=opts.ok_priority)
            modifier.replace_if_not_none(modifier.select(truthValue=0),
                                         priority=opts.ng_priority)

        # Notify
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)
        if opts.add_notify_ids_converted is not None:
            if not hasattr(monitor_info, 'notifyRelationList'):
                setattr(monitor_info, 'notifyRelationList', [])

            # Check if notification already exists
            ids = set(opts.add_notify_ids_converted)
            existed_ids = tuple(
                [x.notifyId for x in monitor_info.notifyRelationList])

            # Then add
            for x in filter((lambda x: x not in existed_ids), ids):
                monitor_info.notifyRelationList.append(
                    endpoint.create_notify_relation_info(notify_endpoint.getNotify(x),
                                                         monitor_info.monitorTypeId, monitor_info.monitorId))

        if opts.del_notify_ids_converted is not None and hasattr(monitor_info, 'notifyRelationList') and 0 < len(monitor_info.notifyRelationList):
            ids = set(opts.del_notify_ids_converted)
            for i in reversed(xrange(len(monitor_info.notifyRelationList))):
                if monitor_info.notifyRelationList[i].notifyId in ids:
                    del monitor_info.notifyRelationList[i]

        endpoint.modifyMonitor(monitor_info)
        return_code = ResultPrinter.success(
            None, opts.mgr_url, 'modifyMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
