#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
オーナーロールIDを条件として受け渡し設定一覧を取得する

<概要>
オーナーロールIDを条件として受け渡し設定一覧を取得して表示します。

<使用例>
[command]
    $ python getTransferInfoListByOwnerRole.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -O TEST01

[result]
    [(transferInfo){
       ownerRoleId = "TEST01"
       calendarId = None
       dataType = "numeric"
       description = None
       destProps[] =
          (transferDestProp){
             name = "fluentd.url"
             value = "http://127.0.0.1:8888/"
          },
          (transferDestProp){
             name = "fluentd.request_timeout"
             value = "60000"
          },
          (transferDestProp){
             name = "fluentd.connect_timeout"
             value = "10000"
          },
       destTypeId = "fluentd"
       interval = 90
       regDate = 1490948550627
       regUser = "hinemos"
       transType = "delay"
       transferId = "TRAN004"
       updateDate = 1490948550627
       updateUser = "hinemos"
       validFlg = True
     }]
    http://192.168.1.2:8080/HinemosWS/, getTransferInfoListByOwnerRole succeeded.
"""
import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
from hinemos.util.common import ResultPrinter
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.hub import HubEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-O', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='OwnerRole ID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = HubEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getTransferInfoListByOwnerRole(opts.owner_role_id)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getTransferInfoListByOwnerRole')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
