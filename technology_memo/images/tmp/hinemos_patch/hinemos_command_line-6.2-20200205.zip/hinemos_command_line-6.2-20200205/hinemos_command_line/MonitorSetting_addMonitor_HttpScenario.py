#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
HTTP監視(シナリオ)の監視設定を登録する

<概要>
HTTP監視(シナリオ)の監視設定を登録します。

<使用例>
[command]
    $ python MonitorSetting_addMonitor_HttpScenario.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I HTTP-SCN-1 -F SCOPE001 -l http://127.0.0.1/index.php -M message -P ".*pattern.*" -A MYAPP

[result]
    http://192.168.1.2:8080/HinemosWS/, addMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.notify import NotifyUtil
from hinemos.util.argsparserbuilder import MonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = MonitorSettingArgsParserBuilder()\
        .build_monitor_setting_add_args_parser(help_default_info)

    psr.add_option('-i', '--itemName', action='store', type='string',
                   metavar='STRING', dest='item_name',
                   default=(None, 'NOTBLANK'), help='collector item name')
    psr.add_option('-u', '--unit', action='store', type='string',
                   metavar='STRING', dest='unit',
                   default=(None, 'NOTBLANK'), help='collector unit')

    # httpScenarioCheckInfo
    psr.add_option('-T', '--connectTimeout', action='store', type='int',
                   metavar='INT', dest='connect_timeout',
                   default=None, help='connect timeout (default: 5000[msec])')
    psr.add_option('-E', '--requestTimeout', action='store', type='int',
                   metavar='INT', dest='request_timeout',
                   default=None, help='request timeout (default: 5000[msec])')
    psr.add_option('-G', '--userAgent', action='store', type='string',
                   metavar='STRING', dest='user_agent',
                   default=(None, 'NOTBLANK'),
                   help='user agent (default: Internet Explorer 11.0)')
    psr.add_option('-L', '--authType', action='store', type='string',
                   metavar='STRING', dest='auth_type',
                   default=(None, {'INLIST': ['', 'BASIC', 'DIGEST', 'NTLM']}),
                   help='authType = "" or BASIC or DIGEST or NTLM')
    psr.add_option('-O', '--authUser', action='store', type='string',
                   metavar='STRING', dest='auth_user',
                   default=(None, {
                       'WHEN': ({'auth_type': 'BASIC'},
                                {'auth_type': 'DIGEST'},
                                {'auth_type': 'NTLM'}),
                       'DO': ('REQUIRED')}),
                   help='authentication user')
    psr.add_option('-W', '--authPassword', action='store', type='string',
                   metavar='STRING', dest='auth_password',
                   default=(None, {
                       'WHEN': ({'auth_type': 'BASIC'},
                                {'auth_type': 'DIGEST'},
                                {'auth_type': 'NTLM'}),
                       'DO': ('REQUIRED')}),
                   help='authentication password')
    psr.add_option('-Q', '--monitorPerPage', action='store', type='string',
                   metavar='BOOL', dest='monitor_per_page_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='monitorPerPage')
    psr.add_option('-J', '--useProxy', action='store', type='string',
                   metavar='BOOL', dest='use_proxy_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='useProxy')
    psr.add_option('-K', '--proxyURL', action='store', type='string',
                   metavar='STRING', dest='proxy_url',
                   default=(None, 'NOTBLANK'), help='proxy URL')
    psr.add_option('-k', '--proxyPort', action='store', type='int',
                   metavar='INT', dest='proxy_port',
                   default=None, help='proxy port (default: 8080)')
    psr.add_option('-f', '--proxyUser', action='store', type='string',
                   metavar='STRING', dest='proxy_user',
                   default=None, help='proxy user')
    psr.add_option('-g', '--proxyPassword', action='store', type='string',
                   metavar='STRING', dest='proxy_password',
                   default=None, help='proxy password')

    # page # TODO Presently only one can be added at creating
    psr.add_option('-l', '--pageURL', action='store', type='string',
                   metavar='STRING', dest='page_url',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='page URL')
    psr.add_option('-o', '--pagePOST', action='store', type='string',
                   metavar='STRING', dest='page_post',
                   default=None, help='page POST data')
    psr.add_option('-q', '--pageStatusCode', action='store', type='string',
                   metavar='STRING', dest='page_status_code',
                   default=(None, 'NOTBLANK'),
                   help='page status code (default: 200)')
    psr.add_option('-r', '--pageDescription', action='store', type='string',
                   metavar='STRING', dest='page_description',
                   default=None, help='page description')
    psr.add_option('-j', '--pagePriority', action='store', type='string',
                   metavar='STRING', dest='page_priority_raw',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                       'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']}),
                   help='pagePriority = INFO or WARN or CRITICAL or '
                   'UNKNOWN (default: CRITICAL)')
    psr.add_option('-M', '--pageMessage', action='store', type='string',
                   metavar='STRING', dest='page_message',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='page message')

    # pattern # TODO Presently only one can be added at creating
    psr.add_option('-P', '--pattern', action='store', type='string',
                   metavar='STRING', dest='pattern',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='pattern')
    psr.add_option('-t', '--patternProcessType', action='store',
                   type='string', metavar='STRING',
                   dest='pattern_process_type_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='process when matching =true, or process when'
                   ' not matching =false')
    psr.add_option('-S', '--patternCaseSensitive', action='store',
                   type='string', metavar='BOOL',
                   dest='pattern_case_sensitive_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='patternCaseSensitive')
    psr.add_option('-s', '--patternDescription', action='store', type='string',
                   metavar='STRING', dest='pattern_description',
                   default=None, help='pattern description')
    psr.add_option('-e', '--patternEnable', action='store', type='string',
                   metavar='BOOL', dest='pattern_enable_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='enable=true, disable=false')

    # variable # TODO Presently only one can be added at creating
    psr.add_option('-X', '--varName', action='store', type='string',
                   metavar='STRING', dest='val_name',
                   default=(None, 'NOTBLANK'), help='variable name')
    psr.add_option('-Y', '--varValue', action='store', type='string',
                   metavar='STRING', dest='val_value',
                   default=(None, 'NOTBLANK'), help='variable value')
    psr.add_option('-Z', '--varMatchingWithResponse', action='store',
                   type='string', metavar='BOOL',
                   dest='var_matching_with_response_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='matching with response =true, otherwise =false')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Notifications
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)
        notify_infos = []
        if opts.notify_ids is not None:
            notify_id_lst = opts.notify_ids.split(',')
            for a in notify_endpoint.getNotifyList():
                if a.notifyId in notify_id_lst:
                    notify_infos.append(a)
                    notify_id_lst.remove(a.notifyId)
            if 0 < len(notify_id_lst):
                ResultPrinter.warning(
                    'Notify ' + (', '.join(notify_id_lst)) + ' will be ignored!')

        pattern = endpoint.create_pattern(opts.pattern, opts.pattern_description,
                                          opts.pattern_case_sensitive, opts.pattern_process_type, opts.pattern_enable)
        variables = []
        if opts.val_name and opts.val_value:
            variables.append(endpoint.create_variable(
                opts.val_name, opts.val_value, opts.var_matching_with_response))

        page = endpoint.create_page(opts.monitor_id, 0, opts.page_url, opts.page_message, [
                                    pattern], opts.page_description, opts.page_priority, opts.page_post, opts.page_status_code, variables)

        endpoint.add_monitor_http_sce(
            opts.monitor_id,
            opts.facility_id,
            opts.run_interval,
            opts.calendar_id,
            opts.application,
            [page],
            opts.description,
            opts.owner_role_id,
            opts.monitor,
            notify_infos,
            opts.collect,
            opts.item_name,
            opts.unit,
            opts.auth_type, opts.auth_user, opts.auth_password,
            opts.use_proxy, opts.proxy_url, opts.proxy_port, opts.proxy_user, opts.proxy_password,
            opts.monitor_per_page,
            opts.user_agent,
            opts.connect_timeout,
            opts.request_timeout)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
