#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したセッションIDのジョブ詳細一覧情報を取得する

<概要>
引数で指定したセッションIDのジョブ詳細一覧情報を取得して表示します。

<使用例>
[command]
    $ python Job_getJobDetailList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -S 20170307102729-000

[result]
    (jobTreeItem){
       children[] =
          (jobTreeItem){
             data =
                (jobInfo){
                   abnormalPriority = 0
                   approvalReqMailBody = None
                   approvalReqMailTitle = None
                   approvalReqRoleId = None
                   approvalReqSentence = None
                   approvalReqUserId = None
                   beginPriority = 0
                   description = "test"
                   id = "TEST_JOB"
                   jobunitId = "TEST_JOBU"
                   name = "TEST_JOB"
                   normalPriority = 0
                   ownerRoleId = None
                   propertyFull = False
                   referJobSelectType = 0
                   registeredModule = True
                   type = 2
                   useApprovalReqSentence = False
                   waitRule =
                      (jobWaitRuleInfo){
                         calendar = False
                         calendarEndStatus = 2
                         calendarEndValue = 0
                         condition = 0
                         endCondition = True
                         endStatus = 2
                         endValue = -1
                         end_delay = False
                         end_delay_condition_type = 0
                         end_delay_job = False
                         end_delay_job_value = 1
                         end_delay_notify = False
                         end_delay_notify_priority = 0
                         end_delay_operation = False
                         end_delay_operation_end_status = 2
                         end_delay_operation_end_value = -1
                         end_delay_operation_type = 0
                         end_delay_session = False
                         end_delay_session_value = 1
                         end_delay_time = False
                         multiplicityEndValue = -1
                         multiplicityNotify = True
                         multiplicityNotifyPriority = 2
                         multiplicityOperation = 0
                         queueFlg = True
                         queueId = "TESTQ01"
                         skip = False
                         skipEndStatus = 2
                         skipEndValue = 0
                         start_delay = False
                         start_delay_condition_type = 0
                         start_delay_notify = False
                         start_delay_notify_priority = 0
                         start_delay_operation = False
                         start_delay_operation_end_status = 2
                         start_delay_operation_end_value = -1
                         start_delay_operation_type = 4
                         start_delay_session = False
                         start_delay_session_value = 1
                         start_delay_time = False
                         start_delay_time_value = "09:00:00"
                         suspend = False
                      }
                   warnPriority = 0
                }
             detail =
                (jobDetailInfo){
                   endDate = "2017/03/07 10:27:45.893"
                   endStatus = 0
                   endValue = 0
                   facilityId = "hinemos60_rhel7"
                   scope = "hinemos60_rhel7"
                   startDate = "2017/03/07 10:27:33.003"
                   status = 300
                }
          },
     }
    http://192.168.1.2:8080/HinemosWS/, getJobDetailList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.repository import FacilityTree
from hinemos.util.common import ResultPrinter

def main():

    psr = MyOptionParser()
    psr.add_option('-S', '--sessionID',  action='store', type='string', metavar='ID', dest='session_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='sessionID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)
        result = endpoint.getJobDetailList(opts.session_id)

        FacilityTree.convert_datetime(result)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getJobDetailList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
