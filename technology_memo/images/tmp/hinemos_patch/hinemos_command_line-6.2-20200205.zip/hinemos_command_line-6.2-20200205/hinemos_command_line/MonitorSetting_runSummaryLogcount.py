#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ログ件数監視の過去分集計をする

<概要>
ログ件数監視の過去分集計を行う。

<使用例>
[command]
    $ python MonitorSetting_runSummaryLogcount.py

[result]

    http://192.168.1.2:8080/HinemosWS/, runSummaryLogcount succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import DateConvert, ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
from hinemos.api.monitorsetting import MonitorSettingEndpoint


def parse_args(args):
    psr = MyOptionParser()
    psr.add_option('-I', '--monitorId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='monitorId',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='log count monitor id')
    psr.add_option('--startDate',
                   action='store',
                   type='string',
                   metavar='DATETIME',
                   converter=DateConvert.get_epochtime_from_datetime,
                   dest='startDate_raw',
                   default=(None, 'REQUIRED', 'NOTBLANK', {
                       'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$',
                                  'must be in datetime format']
                   }),
                   help='start date [yyyy/mm/dd HH:MM:SS]')
    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    ### login ###
    endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

    try:
        result = endpoint.call('runSummaryLogcount',
                               opts.monitorId, opts.startDate)
        return_code = ResultPrinter.success(
            result, opts.mgr_url, 'runSummaryLogcount')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    # sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    # sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
