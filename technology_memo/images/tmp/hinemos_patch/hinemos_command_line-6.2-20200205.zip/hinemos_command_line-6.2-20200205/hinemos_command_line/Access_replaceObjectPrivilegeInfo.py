#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
オブジェクト種別、オブジェクトIDに紐づくオブジェクト権限情報を差し替える

<概要>
オブジェクト種別、オブジェクトIDに紐づくオブジェクト権限情報の差し替えを実施します。

<使用例>
[command]
    $ python Access_replaceObjectPrivilegeInfo.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -O NODE001 -T PLT_REP -P READ -R TEST01

[result]
    http://192.168.1.2:8080/HinemosWS/, replaceObjectPrivilegeInfo succeeded.

複数ロールに対して、複数のオブジェクト権限を差し替える場合は、以下のように記述して実行します。

[command]
    $ python Access_replaceObjectPrivilegeInfo.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -O NODE001 -T PLT_REP -P READ,MODIFY,READ -R TEST01,TEST01,TEST02

[result]
    http://192.168.1.2:8080/HinemosWS/, replaceObjectPrivilegeInfo succeeded.

上記のように、-Pと-Rについて、カンマで区切った場合、権限の1番目はロールの1番目、権限の2番目は
ロールの2番目というように対応させることができます。

この場合、TEST01ロールがREAD権限、TEST01ロールがMODIFY権限、TEST02ロールがREAD権限にそれぞれ対応します。
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.access import AccessEndpoint
from hinemos.util.common import ResultPrinter
from hinemos.util.access import AccessUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-O', '--objectID',  action='store', type='string', metavar='ID', dest='object_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='objectID')
    # @see com.clustercontrol.bean.HinemosModuleConstant HUB_LOGFORMAT, HUB_TRANSFER, PRF...
    psr.add_option('-T', '--objectType', action='store', type='string', metavar='STRING', dest='object_type',
                    default=(None, 'REQUIRED','NOTBLANK'), help='objectType')
    psr.add_option('-P', '--objectPrivilege', action='store_split', type='string', metavar='STRING', dest='object_privileges_raw',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='objectPrivilege = objectPrivilege1,objectPrivilege2,...,objectPrivilegeN (objectPrivilege = READ or MODIFY or EXEC)')
    psr.add_option('-R', '--ownerRoleIDs', action='store_split', type='string', metavar='STRING', dest='owner_role_ids_raw',
                    default=(None, 'REQUIRED','NOTBLANK'), help='ownerRoleIDs = ownerRoleID1,ownerRoleID2,...,ownerRoleIDN')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = AccessEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##

        if len(opts.owner_role_ids) != len(opts.object_privileges):
            raise ErrorHandler.ArgumentError('The number of OBJECTPRIVILEGES does not equal to ROLEIDS\'s')

        for a in opts.object_privileges:
            if not a in AccessUtil._obj_privilege_type_:
                raise ErrorHandler.ArgumentError('Invalid ObjectPrivilege - %s.' % a)

        object_privilege_info_list = []
        for i in xrange(len(opts.owner_role_ids)):
            object_privilege_info_list.append(endpoint.create_object_privilege_info(opts.owner_role_ids[i], opts.object_privileges[i]))

        endpoint.replaceObjectPrivilegeInfo(opts.object_type, opts.object_id, object_privilege_info_list)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'replaceObjectPrivilegeInfo')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
