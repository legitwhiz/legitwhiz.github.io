#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
「待ち条件」タブの情報を変更する

<概要>
「待ち条件」タブの情報を変更します。

<使用例>
- 待ち条件タブの情報を終了状態、終了値を変更します。
[command]
    $ python Job_modifyJob_WaitruleTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB1 -C OR -E false -S NORMAL -V 1

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- 待ち条件タブの判定条件を追加します。
[command]
    $ python Job_modifyJob_WaitruleTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB1 -A ADD -T JOB_END_STATUS -s WARNING -I JN001

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


[command]
    $ python Job_modifyJob_WaitruleTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB1 -A ADD -T JOB_END_CODE -e 0 -I JN001

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


[command]
    $ python Job_modifyJob_WaitruleTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB1 -A ADD -T MINUTE_AFTER_STARTED -m 10

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


[command]
    $ python Job_modifyJob_WaitruleTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB1 -A ADD -T TIME -t 25:00:00

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


[command]
    $ python Job_modifyJob_WaitruleTab.py  -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J "JU001/JOB1" -A ADD -T JOB_PARAM -X var1 -Y NOT_EQUAL_STRING -Z var2 

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- 待ち条件タブの判定条件を変更します。
[command]
    $ python Job_modifyJob_WaitruleTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB1 -A MOD -i 4 -T TIME -t 12:00:00

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- 待ち条件タブの判定条件を削除します。
[command]
    $ python Job_modifyJob_WaitruleTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB1 -A DEL -i 3

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil
from hinemos.util.common import ResultPrinter, SettingUtil, DateConvert
from hinemos.util.modifier import ObjectModifier

def main():

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    ### 待ち条件タブ設定項目 ###
    psr.add_option('-C', '--condition', action='store', type='string', metavar='STRING', dest='condition_raw',converter=JobUtil.convert2condition,
                    default=(None, {'INLIST':JobUtil._condition_}), help='condition: AND or OR')
    psr.add_option('-E', '--endCondition', action='store', type='string', metavar='STRING', dest='end_condition_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='endCondition: enable=true, disable=false' )
    psr.add_option('-S', '--endStatus', action='store', type='string', metavar='STRING', dest='end_status_raw',converter=JobUtil.convert2end_status,
                    default=(None, {'INLIST':JobUtil._end_status_}), help='endStatus: ' + ' or '.join(JobUtil._end_status_))
    psr.add_option('-V', '--endValue', action='store', type='int', metavar='INT', dest='end_value',
                    default=None, help='endValue= integer ')

    psr.add_option('-A', '--action', action='store', type='string', metavar='STRING', dest='action',
                    default=(None, {'INLIST':['ADD','MOD','DEL']}), help='add a waitrule = ADD, modify waitrule value = MOD, delete a waitrule = DEL')
    psr.add_option('-i', '--waitruleNo', action='store', type='int', metavar='INT', dest='waitrule_no',
                    default=(None, {'WHEN':[{'action':'DEL'}], 'DO':('REQUIRED')}), help='waitrule no.')
    psr.add_option('-T', '--waitruleType', action='store', type='string', metavar='STRING', dest='waitrule_type_raw',converter=JobUtil.convert2wait_rule_object_type,\
                    default=(None, {'INLIST':JobUtil._wait_rule_object_type_}, {'WHEN':{'action':'ADD'}, 'DO':('REQUIRED')}), help='waitruleType(job waitrule tab) = ' + ' or '.join(JobUtil._wait_rule_object_type_))
    psr.add_option('-I', '--waitruleJobID',  action='store', type='string', metavar='ID', dest='waitrule_job_id',
                    default=(None, 'NOTBLANK'), help='waitrule JobID: waitrule job ID')
    psr.add_option('-s', '--waitruleEndStatus', action='store', type='string', metavar='STRING', dest='waitrule_value_status_raw', converter=JobUtil.convert2end_status, 
                    default=(None, {'INLIST':JobUtil._end_status_wait_}, {'WHEN':{'waitrule_type_raw':'JOB_END_STATUS'}, 'DO':('REQUIRED')}), help='waitruleEndStatus = ' + ' or '.join(JobUtil._end_status_wait_))
    psr.add_option('-e', '--waitruleEndCode', action='store', type='int', metavar='INT', dest='waitrule_value_code',
                    default=None, help='waitruleEndCode = integer')
    psr.add_option('-m', '--waitruleMinute', action='store', type='int', metavar='INT', dest='waitrule_value_minute',
                    default=None, help='waitruleMinute = integer [min]')
    psr.add_option('-t', '--waitruleTime', action='store', type='string', metavar='STRING', dest='waitrule_value_time',
                    default=(None, 'NOTBLANK', {'REGEXP':[r'\d{1,2}:\d{1,2}:\d{1,2}$', 'must be in the format HH:MM:SS']}), help='waitrule Time: HH:MM:SS')

    psr.add_option('-X', '--jobParamValue1', action='store', type='string', metavar='STRING', dest='jobParamValue1',
                    default=(None, {'WHEN':{'waitrule_type_raw':'JOB_PARAM'}, 'DO':('REQUIRED')}), help='Job parameter value1')
    psr.add_option('-Y', '--jobParamComparator', action='store', type='string', metavar='STRING', dest='jobParamComparator_raw', converter=JobUtil.convert2dicision_comparator,
                   default=(None, {'WHEN':{'waitrule_type_raw':'JOB_PARAM'}, 'DO':('REQUIRED', {'INLIST':JobUtil.enum_decision_comparators()})}),
                   help='Job parameter comparator: %s' % ' or '.join(JobUtil.enum_decision_comparators()))
    psr.add_option('-Z', '--jobParamValue2', action='store', type='string', metavar='STRING', dest='jobParamValue2',
                    default=(None, {'WHEN':{'waitrule_type_raw':'JOB_PARAM'}, 'DO':('REQUIRED')}), help='Job parameter value2')

    psr.add_option('-d', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='Description')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Additional argument check
        if opts.action is not None:
            if opts.action == 'ADD':
                if opts.waitrule_type == JobUtil.convert2wait_rule_object_type('JOB_END_STATUS'):
                    if opts.waitrule_value_status_raw is None:
                        raise ErrorHandler.ArgumentError('waitruleEndStatus is required!')
                    if opts.waitrule_job_id is None:
                        raise ErrorHandler.ArgumentError('waitruleJobID is required!')
                elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('JOB_END_CODE'):
                    if opts.waitrule_value_code is None:
                        raise ErrorHandler.ArgumentError('waitruleEndCode is required!')
                    if opts.waitrule_job_id is None:
                        raise ErrorHandler.ArgumentError('waitruleJobID is required!')
                elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('TIME'):
                    if opts.waitrule_value_time is None:
                        raise ErrorHandler.ArgumentError('waitruleMinute is required!')
                elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('MINUTE_AFTER_STARTED'):
                    if opts.waitrule_value_minute is None:
                        raise ErrorHandler.ArgumentError('waitruleMinute is required!')
                elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('JOB_PARAM'):
                    if opts.jobParamComparator is None:
                        raise ErrorHandler.ArgumentError('jobParamComparator is required!')
                    if opts.jobParamValue1 is None:
                        raise ErrorHandler.ArgumentError('jobParamValue1 is required!')
                    if opts.jobParamValue2 is None:
                        raise ErrorHandler.ArgumentError('jobParamValue2 is required!')

            elif opts.action == 'MOD':
                #If there is a wait condition value specification, the target line must be specified
                if opts.waitrule_type is None :
                    if opts.waitrule_value_status_raw is not None or opts.waitrule_value_code is not None or opts.waitrule_value_time is not None or opts.waitrule_value_minute is not None or opts.jobParamComparator is not None or opts.jobParamValue1 is not None or opts.jobParamValue2 is not None :
                        raise ErrorHandler.ArgumentError('waitruleType is required!')
                #If there is a waiting rule or a description, the target line must be specified
                if opts.waitrule_no is None:
                    if opts.waitrule_type is not None or opts.description is not None :
                        raise ErrorHandler.ArgumentError('waitruleNo is required!.')
                if opts.waitrule_type == JobUtil.convert2wait_rule_object_type('JOB_END_STATUS'):
                    if opts.waitrule_value_status_raw is None and opts.waitrule_job_id is None:
                        raise ErrorHandler.ArgumentError('waitruleJobID / waitruleEndStatus is required!')
                elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('JOB_END_CODE'):
                    if opts.waitrule_value_code is None and opts.waitrule_job_id is None:
                        raise ErrorHandler.ArgumentError('waitruleJobID / waitruleEndCode is required!')
                elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('TIME'):
                    if opts.waitrule_value_time is None:
                        raise ErrorHandler.ArgumentError('waitruleMinute is required!')
                elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('MINUTE_AFTER_STARTED'):
                    if opts.waitrule_value_minute is None:
                        raise ErrorHandler.ArgumentError('waitruleMinute is required!')
                elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('JOB_PARAM'):
                    if opts.jobParamComparator is None and opts.jobParamValue1 is None and opts.jobParamValue2 is None:
                        raise ErrorHandler.ArgumentError('jobParamComparator / jobParamValue1 / jobParamValue2 is required!')

            elif opts.action == 'DEL':
                if opts.waitrule_no is None:
                    raise ErrorHandler.ArgumentError('waitruleNo is required!')

        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job)
        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, job_map['jobunitId'])
        del job_tree_full

        job_info = JobUtil.find_job_info(job_tree, job_map['jobId'])
        if job_info is None:
            raise ErrorHandler.ArgumentError('Job {:s} not found!'.format(job_map['jobId']))

        job_type_label = JobUtil.convert2job_type_label(job_info.type)
        if job_type_label in ('JOBUNIT',):
            raise ErrorHandler.ArgumentError('This operation is not available for %s!' % job_type_label)

        new_job_info = endpoint.getJobFull(endpoint.create_job_info_minimal(job_map['jobunitId'], job_map['jobId']))
        with ObjectModifier(new_job_info) as modifier:
            modifier.change_ptr('waitRule')
            modifier.set_if_first_not_none('condition', opts.condition)
            modifier.set_if_first_not_none('endCondition', opts.end_condition)
            modifier.set_if_first_not_none('endStatus', opts.end_status)
            modifier.set_if_first_not_none('endValue', opts.end_value)

        if opts.action == 'ADD':
            if not hasattr(new_job_info.waitRule, 'object'):
                setattr(new_job_info.waitRule, 'object', [])

            if opts.waitrule_type == JobUtil.convert2wait_rule_object_type('JOB_END_STATUS'):
                new_job_info.waitRule.object.append(endpoint.create_job_object_info(opts.waitrule_type, opts.waitrule_job_id, opts.waitrule_value_status, None, None, None, None, None, opts.description))
            elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('JOB_END_CODE'):
                new_job_info.waitRule.object.append(endpoint.create_job_object_info(opts.waitrule_type, opts.waitrule_job_id, opts.waitrule_value_code, None, None, None, None, None, opts.description))
            elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('TIME'):
                new_job_info.waitRule.object.append(endpoint.create_job_object_info(opts.waitrule_type, None, None, DateConvert.get_epochtime_from_time(opts.waitrule_value_time), None, None, None, None, opts.description))
            elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('MINUTE_AFTER_STARTED'):
                new_job_info.waitRule.object.append(endpoint.create_job_object_info(opts.waitrule_type, None, None, None, opts.waitrule_value_minute, None, None, None, opts.description))
            elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('JOB_PARAM'):
                subinfo = endpoint.create_job_object_info(opts.waitrule_type, None, None, None, None, opts.jobParamComparator, opts.jobParamValue1, opts.jobParamValue2, opts.description)
                new_job_info.waitRule.object.append(subinfo)

        elif opts.action == 'MOD':
            #If the target row is specified, check for existence
            if opts.waitrule_no is not None:
                if not hasattr(new_job_info.waitRule, 'object') or opts.waitrule_no < 1 or opts.waitrule_no > len(new_job_info.waitRule.object):
                    raise ErrorHandler.ObjectNotFoundError('Waitrule object(no=%d) does not exist!' % opts.waitrule_no)

            #If a waiting rule is specified, it must match the setting of the target line
            if opts.waitrule_type is not None :
                if new_job_info.waitRule.object[opts.waitrule_no-1].type != opts.waitrule_type :
                    raise ErrorHandler.ObjectNotFoundError('Waitruletype of Waitrule object(no=%d) does not match the argument!' %  opts.waitrule_no)

            if opts.waitrule_type == JobUtil.convert2wait_rule_object_type('JOB_END_STATUS'):
                new_job_info.waitRule.object[opts.waitrule_no-1].value = opts.waitrule_value_status
            elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('JOB_END_CODE'):
                new_job_info.waitRule.object[opts.waitrule_no-1].value = opts.waitrule_value_code
            elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('TIME'):
                print new_job_info.waitRule.object[opts.waitrule_no-1]
                new_job_info.waitRule.object[opts.waitrule_no-1].time = DateConvert.get_epochtime_from_time(opts.waitrule_value_time)
                print new_job_info.waitRule.object[opts.waitrule_no-1]
            elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('MINUTE_AFTER_STARTED'):
                new_job_info.waitRule.object[opts.waitrule_no-1].startMinute = opts.waitrule_value_minute
            elif opts.waitrule_type == JobUtil.convert2wait_rule_object_type('JOB_PARAM'):
                if opts.jobParamComparator is not None:
                    new_job_info.waitRule.object[opts.waitrule_no-1].decisionCondition = opts.jobParamComparator
                if opts.jobParamValue1 is not None:
                    new_job_info.waitRule.object[opts.waitrule_no-1].decisionValue01 = opts.jobParamValue1
                if opts.jobParamValue2 is not None:
                    new_job_info.waitRule.object[opts.waitrule_no-1].decisionValue02 = opts.jobParamValue2

            if opts.description is not None:
                new_job_info.waitRule.object[opts.waitrule_no-1].description = opts.description
        elif opts.action == 'DEL':
            if not hasattr(new_job_info.waitRule, 'object') or opts.waitrule_no < 1 or opts.waitrule_no > len(new_job_info.waitRule.object):
                raise ErrorHandler.ObjectNotFoundError('Waitrule object(no=%d) does not exist!' % opts.waitrule_no)
            del new_job_info.waitRule.object[opts.waitrule_no-1]

        JobUtil.replace_job_info(job_tree, new_job_info)

        # Clean up and replace none with blank
        JobUtil.cleanup_and_fixnone(job_tree)

        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJob')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
