#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
構成情報取得設定の収集フラグを有効化/無効化する

<概要>
構成情報取得設定の収集フラグを有効化/無効化します。

<使用例>
[command]
    $ python Repository_setStatusNodeConfigSetting.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING -v false

[result]

    http://127.0.0.1:8080/HinemosWS/, setStatusNodeConfigSetting succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.common import ResultPrinter, SettingUtil


def main():
    psr = MyOptionParser()

    psr.add_option('-I', '--settingId', action='store', type='string', metavar='STRING', dest='setting_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Node Configuration Setting ID')
    psr.add_option('-v', '--validFlg', action='store', type='string', metavar='BOOL', dest='valid_flg_raw',
                   converter=SettingUtil.convert2nbool, default=(None, 'REQUIRED', {'INLIST': ['true', 'false']}),
                   help='Enable Setting=true, Disable Setting=false')

    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)
        endpoint.setStatusNodeConfigSetting(opts.setting_id, opts.valid_flg)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'setStatusNodeConfigSetting')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
