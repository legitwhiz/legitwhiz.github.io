#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
カレンダパターン情報を変更する

<概要>
カレンダパターン情報を変更します。

<使用例>
- カレンダパターンを追加します。
[command]
    $ python Calendar_modifyCalendarPattern.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -C TEST_CP -A "2017/03/01,2017/03/02"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyCalendarPattern succeeded.


- カレンダパターンを削除します。
[command]
    $ python Calendar_modifyCalendarPattern.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -C TEST_CP -D "2017/03/02,2017/03/03"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyCalendarPattern succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.calendar import CalendarEndpoint
from hinemos.util.common import ResultPrinter

def main():

    psr = MyOptionParser()
    psr.add_option('-C', '--calendarPatternID',  action='store', type='string', metavar='ID', dest='calendar_pattern_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='ID')
    psr.add_option('-N', '--Name', action='store', type='string', metavar='STRING', dest='name',
                    default=None, help='name')
    psr.add_option('-A', '--addymd', action='store', type='string', metavar='STRING', dest='add_ymds',
                    default=None, help='add ymd: yyyy/mm/dd,yyyy/mm/dd,...')
    psr.add_option('-D', '--deleteymd', action='store', type='string', metavar='STRING', dest='delete_ymds',
                    default=None, help='delete ymd: yyyy/mm/dd,yyyy/mm/dd,...')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    ### login ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = CalendarEndpoint(opts.mgr_url, opts.user, opts.passwd)

        endpoint.modify_calendar_pattern_x(opts.calendar_pattern_id, name=opts.name, add_ymds=opts.add_ymds, delete_ymds=opts.delete_ymds)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyCalendarPattern')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
