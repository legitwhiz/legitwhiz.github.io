#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
Hinemosプロパティの一覧を取得する

<概要>
Hinemosプロパティの一覧を取得して表示します。

<使用例>
[command]
    $ python HinemosProperty_getHinemosPropertyList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    [(hinemosPropertyInfo){
       createDatetime = "2017/02/09 15:10:33.012"
       createUserId = "hinemos"
       description = "[You need to restart Hinemos Manager] offset value from the current time [msec]"
       key = "common.time.offset"
       modifyDatetime = "2017/02/09 15:10:33.012"
       modifyUserId = "hinemos"
       ownerRoleId = "ADMINISTRATORS"
       valueNumeric = 0
       valueType = 2
     }, (hinemosPropertyInfo){
       createDatetime = "2017/02/09 15:10:33.436"
       createUserId = "hinemos"
       description = "[You need to restart Hinemos Manager] offset value from the UTC [msec]"
       key = "common.timezone"
       modifyDatetime = "2017/02/09 15:10:33.436"
       modifyUserId = "hinemos"
       ownerRoleId = "ADMINISTRATORS"
       valueNumeric = 32400000
       valueType = 2
    ... 中略 ...
    }, (hinemosPropertyInfo){
      createDatetime = "2017/02/09 15:10:38.714"
      createUserId = "hinemos"
      description = "[You need to restart Hinemos Manager]Type of keystore"
      key = "ws.https.keystore.type"
      modifyDatetime = "2017/02/09 15:10:38.714"
      modifyUserId = "hinemos"
      ownerRoleId = "ADMINISTRATORS"
      valueString = "PKCS12"
      valueType = 1
    }, (hinemosPropertyInfo){
      createDatetime = "2017/02/09 15:10:38.746"
      createUserId = "hinemos"
      description = "[You need to restart Hinemos Manager]Secure protocol of HTTPS"
      key = "ws.https.protocol"
      modifyDatetime = "2017/02/09 15:10:38.746"
      modifyUserId = "hinemos"
      ownerRoleId = "ADMINISTRATORS"
      valueString = "TLS"
      valueType = 1
    }]
    http://192.168.1.2:8080/HinemosWS/, getHinemosPropertyList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter, DateConvert
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.hinemosproperty import HinemosPropertyEndpoint

def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = HinemosPropertyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getHinemosPropertyList()
        if result is not None:
            for one in result:
                one.createDatetime = DateConvert.get_datetime_from_epochtime(one.createDatetime)
                one.modifyDatetime = DateConvert.get_datetime_from_epochtime(one.modifyDatetime)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getHinemosPropertyList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
