#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定されたステータス情報を削除する

<概要>
引数で指定されたステータス情報を削除します。

<使用例>
[command]
    $ python Monitor_deleteStatus.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -M TEST_PNG2 -P MON_PNG -F TEST_NODE -m TEST_SUBKEY

[result]
    http://192.168.1.2:8080/HinemosWS/, deleteStatus succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitor import MonitorEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-M', '--monitorID',  action='store', type='string', metavar='ID', dest='monitor_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='monitorID')
    psr.add_option('-m', '--monitorDetailID',  action='store', type='string', metavar='ID', dest='monitor_detail_id',
                    default=None, help='monitorDetailID')
    psr.add_option('-P', '--pluginID',  action='store', type='string', metavar='ID', dest='plugin_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='pluginID')
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='facilityID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit###
        status_data_info = endpoint.create_object('statusDataInfo')
        status_data_info.monitorId = opts.monitor_id

        if opts.monitor_detail_id is None:
            status_data_info.monitorDetailId = ""
        else:
            status_data_info.monitorDetailId = opts.monitor_detail_id

        status_data_info.pluginId = opts.plugin_id
        status_data_info.facilityId = opts.facility_id

        result = endpoint.deleteStatus(status_data_info)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'deleteStatus')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
