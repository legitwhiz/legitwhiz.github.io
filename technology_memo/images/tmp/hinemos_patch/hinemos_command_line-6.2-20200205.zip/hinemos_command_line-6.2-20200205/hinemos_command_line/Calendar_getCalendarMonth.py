#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
月間予定を表示する

<概要>
引数で指定された年月の稼働状況を取得し、月間予定のカレンダを表示する。
(O:終日稼働; P:一部稼働/非稼働; X: 終日日稼働)

<使用例>
[command]
    $ python Calendar_getCalendarMonth.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -C TEST_CAL02 -Y 2017 -M 3

[result]
    [1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1]
    http://192.168.1.2:8080/HinemosWS/, getCalendarMonth succeeded.
"""

import os
import sys
import codecs, locale
import calendar
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser

import hinemos.api.exceptions as ErrorHandler
from hinemos.api.calendar import CalendarEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='calendarID')
    psr.add_option('-Y', '--year', action='store', type='int', metavar='INT', dest='year',
                    default=(None, 'REQUIRED', {'RANGE':[1700,9999]}), help='year = yyyy')
    psr.add_option('-M', '--month', action='store', type='int', metavar='INT', dest='month',
                    default=(None, 'REQUIRED',{'RANGE':[1,12]}), help='month = 1-12')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = CalendarEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        # 引数で指定された、年月の1日から順番に、○、△、×を詰めたArrayListを返します
        result = endpoint.getCalendarMonth(opts.calendar_id, opts.year, opts.month)
        operation_map = ('O', 'P', 'X')
        cal_str = ''
        if result:
            cal_str += ('%d %s' % (opts.year, calendar.month_name[12])).center(35) + os.linesep
            cal_str += calendar.weekheader(3).replace(' ', '  ').center(35) + os.linesep
            cal_str += '-' * 35 + os.linesep
            print result
            for lst in calendar.Calendar(calendar.SUNDAY).monthdatescalendar(opts.year, opts.month):
                for d in lst:
                    if d.month == opts.month:
                        cal_str += '%3d|%s' % (d.day, operation_map[result[d.day-1]])
                    else:
                        cal_str += '     '
                cal_str += os.linesep

        return_code = ResultPrinter.success(cal_str, opts.mgr_url, 'getCalendarMonth')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
