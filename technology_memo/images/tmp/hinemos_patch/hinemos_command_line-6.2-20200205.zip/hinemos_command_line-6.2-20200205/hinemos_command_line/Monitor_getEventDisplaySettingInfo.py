#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
イベントの画面表示設定を取得する

<概要>
イベントの画面表示設定を取得します。

<使用例>
[command]
    $ python Monitor_getEventDisplaySettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    (eventDisplaySettingInfo){
       eventNoInfo =
          (eventNoDisplayInfo){
             displayEnable = False
             exportEnable = False
          }
       userItemInfoMap =
          (userItemInfoMap){
             entry[] =
                (entry){
                   key = 1
                   value =
                      (eventUserExtensionItemInfo){
                         displayEnable = True
                         displayName = "user_item_1"
                         exportEnable = False
                         modifyClientEnable = True
                         modifyFormat = None
                         modifyRequired = False
                         modifyValidation = None
                         registInitValue = None
                      }
                },

            ...中略...

             (entry){
                   key = 40
                   value =
                      (eventUserExtensionItemInfo){
                         displayEnable = False
                         displayName = None
                         exportEnable = False
                         modifyClientEnable = False
                         modifyFormat = None
                         modifyRequired = False
                         modifyValidation = None
                         registInitValue = None
                      }
                },
          }
    }

    http://127.0.0.1:8080/HinemosWS/, getEventDisplaySettingInfo succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.monitor import MonitorEndpoint
from hinemos.util.common import ResultPrinter


def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = MonitorEndpoint(opts.mgr_url, opts.user, opts.passwd)
        result = endpoint.getEventDisplaySettingInfo()
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getEventDisplaySettingInfo')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
