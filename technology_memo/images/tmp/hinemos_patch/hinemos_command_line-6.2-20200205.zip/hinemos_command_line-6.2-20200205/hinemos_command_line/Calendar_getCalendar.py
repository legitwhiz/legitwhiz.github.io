#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したカレンダIDに対応するカレンダ情報を取得する

<概要>
引数で指定したカレンダIDに対応カレンダ情報を取得して表示します。

<使用例>
[command]
    $ python Calendar_getCalendar.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_CAL02

[result]
    (calendarInfo){
       ownerRoleId = "ALL_USERS"
       calendarDetailList[] =
          (calendarDetailInfo){
             afterday = 0
             calendarId = "TEST_CAL02"
             date = 20
             dayType = 2
             month = 3
             operateFlg = False
             substituteFlg = False
             substituteLimit = 10
             substituteTime = 24
             timeFrom = "00:00:00"
             timeTo = "24:00:00"
             year = 2017
          },
       calendarId = "TEST_CAL02"
       calendarName = "TEST_CAL02"
       description = None
       regDate = "2017/03/03 14:16:09.544"
       regUser = "hinemos"
       updateDate = "2017/03/03 14:19:53.250"
       updateUser = "hinemos"
       validTimeFrom = "2017/03/01 00:00:00"
       validTimeTo = "2017/03/31 23:59:59"
     }
    http://192.168.1.2:8080/HinemosWS/, getCalendar succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser

import hinemos.api.exceptions as ErrorHandler
from hinemos.api.calendar import CalendarEndpoint
from hinemos.api.helper.calendar import result_formatter

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='calendarID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        endpoint = CalendarEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getCalendar(opts.calendar_id)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getCalendar', result_formatter)
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
