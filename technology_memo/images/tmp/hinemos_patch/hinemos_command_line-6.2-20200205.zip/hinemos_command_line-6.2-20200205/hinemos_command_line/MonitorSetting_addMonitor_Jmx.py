#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
JMX監視の監視設定を登録する

<概要>
JMX監視の監視設定を登録します。

<使用例>
[command]
    $ python MonitorSetting_addMonitor_Jmx.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I JMX1 -A MYAPP -F SCOPE001 -M JMX_CLASS_LOADING_LOADED_CLASS_COUNT -x 1234 -c true

[result]
    http://192.168.1.2:8080/HinemosWS/, addMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
import os
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.api.jmxmaster import JmxMasterEndpoint


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_add_args_parser(help_default_info)

    psr.add_option('-M', '--monitorItem', action='store', type='string',
                   metavar='STRING', dest='master_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='monitor item. (e.g. JMX_CLASS_LOADING_LOADED_CLASS_COUNT,'
                   ' JMX_CLASS_LOADING_TOTAL_LOADED_CLASS_COUNT, etc.)')
    psr.add_option('-x', '--jmxPort', action='store', type='int', metavar='INT',
                   dest='port', default=(None, 'REQUIRED'), help='JMX port')
    psr.add_option('-j', '--authUser', action='store', type='string',
                   metavar='STRING', dest='auth_user',
                   default=None, help='authentication username')
    psr.add_option('-k', '--authPassword', action='store', type='string',
                   metavar='STRING', dest='auth_password',
                   default=None, help='authentication password')
    psr.add_option('-d', '--calculateDiff', action='store', type='string',
                   metavar='STRING', dest='convert_flg_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='calculate difference from previous result =true,'
                   'do nothing = no (default: no)')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Check JMX master list at first
        endpoint = JmxMasterEndpoint(opts.mgr_url, opts.user, opts.passwd)
        jmx_master_info_list = endpoint.get_jmx_master_info_list()
        for x in jmx_master_info_list:
            if x.id == opts.master_id:
                break
        else:
            print 'monitorItem must be one of: ' + os.linesep + os.linesep.join(('\t%s (%s)' % (x.id, x.name)) for x in jmx_master_info_list)
            raise ErrorHandler.ObjectNotFoundError(
                'the specified monitorItem(%s) does not existed!' % opts.master_id)

        # Login
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        args = vars(opts)
        args['jmx_master_info_list'] = jmx_master_info_list
        endpoint.add_monitor_jmx(args)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
