#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
SNMP監視(文字列)の監視設定を登録する

<概要>
SNMP監視(文字列)の監視設定を登録します。

<使用例>
[command]
    $ python MonitorSetting_addMonitor_SnmpS.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I SNMPS1 -A MYAPP -F SCOPE001 -O 1.2.3 -P ".*test.*" -E message

[result]
    http://192.168.1.2:8080/HinemosWS/, addMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.util.notify import NotifyUtil
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.argsparserbuilder import MonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = MonitorSettingArgsParserBuilder()\
        .build_monitor_setting_add_args_parser(help_default_info)

    psr.add_option('-O', '--snmpOID',  action='store', type='string',
                   metavar='ID', dest='snmp_oid',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='snmp OID')

    psr.add_option('-l', '--logformatID',  action='store', type='string',
                   metavar='ID', dest='logformat_id',
                   default=(None, {
                       'WHEN': {'collect': 1},
                       'DO': ('REQUIRED', 'NOTBLANK')}),
                   help='Log format ID')

    # TODO Only one pattern can be added at the first
    psr.add_option('-P', '--pattern', action='store', type='string',
                   metavar='STRING', dest='pattern',
                   default=(None, 'NOTBLANK'), help='pattern')
    psr.add_option('-s', '--patternDescription', action='store', type='string',
                   metavar='STRING', dest='pattern_description',
                   default=None, help='pattern description')
    psr.add_option('-t', '--patternProcessType', action='store', type='string',
                   metavar='STRING', dest='pattern_process_type_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='process when matching =true, or process when not'
                   ' matching =false')
    psr.add_option('-S', '--patternCaseSensitive', action='store',
                   type='string', metavar='BOOL',
                   dest='pattern_case_sensitive_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='patternCaseSensitive')
    psr.add_option('-i', '--patternPriority', action='store', type='string',
                   metavar='STRING', dest='pattern_priority_raw',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                       'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']}),
                   help='pattern_priority = INFO or WARN or CRITICAL '
                   'or UNKNOWN')
    psr.add_option('-E', '--patternMessage', action='store', type='string',
                   metavar='STRING', dest='pattern_message',
                   default=(None, 'NOTBLANK', {
                       'WHEN': {'pattern!=': None},
                       'DO': ('REQUIRED')}),
                   help='pattern message')
    psr.add_option('-e', '--patternEnable', action='store', type='string',
                   metavar='BOOL', dest='pattern_enable_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='enable=true, disable=false')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Notifications
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)
        notify_infos = []
        if opts.notify_ids is not None:
            notify_id_lst = opts.notify_ids.split(',')
            for a in notify_endpoint.getNotifyList():
                if a.notifyId in notify_id_lst:
                    notify_infos.append(a)
                    notify_id_lst.remove(a.notifyId)
            if 0 < len(notify_id_lst):
                ResultPrinter.warning(
                    'Notify ' + (', '.join(notify_id_lst)) + ' will be ignored!')

        # String patterns
        string_value_infos = []
        if opts.pattern is not None:
            string_value_infos.append(endpoint.create_monitor_string_value_info(
                opts.monitor_id,
                opts.pattern,
                opts.pattern_description,
                opts.pattern_case_sensitive,
                opts.pattern_process_type,
                opts.pattern_priority,
                opts.pattern_message,
                opts.pattern_enable))

        endpoint.add_monitor_snmp_s(
            opts.monitor_id,
            opts.facility_id,
            opts.application,
            string_value_infos,
            opts.snmp_oid,
            opts.collect,
            opts.logformat_id,
            opts.run_interval,
            opts.description,
            opts.calendar_id,
            opts.owner_role_id,
            opts.monitor,
            notify_infos)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
