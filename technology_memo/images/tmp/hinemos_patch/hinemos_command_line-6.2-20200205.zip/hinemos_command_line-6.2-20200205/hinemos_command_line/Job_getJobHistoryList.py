#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
フィルタ処理したジョブ履歴一覧情報を取得する

<概要>
フィルタ処理したジョブ履歴一覧情報を取得して表示します。

<使用例>
[command]
    $ python Job_getJobHistoryList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -s "2017/03/07 00:00:00" -S "2017/03/07 11:30:00"

[result]
    (jobHistoryList){
       list[] =
          (jobHistory){
             endDate = "2017/03/07 10:54:44.674"
             endStatus = 0
             endValue = 0
             jobId = "FJOB01"
             jobName = "FJOB001"
             jobTriggerType = 2
             jobType = 3
             jobunitId = "JU04"
             ownerRoleId = "ALL_USERS"
             scheduleDate = "2017/03/07 10:54:31.224"
             sessionId = "20170307105430-000"
             startDate = "2017/03/07 10:54:32.275"
             status = 300
             triggerInfo = "Hinemos Administrator(hinemos)"
          },
            ...中略...
          (jobHistory){
             endDate = "2017/03/07 00:11:00.011"
             endStatus = 2
             endValue = -1
             facilityId = "hinemos60_rhel7"
             jobId = "JOB01"
             jobName = "JOB01"
             jobTriggerType = 1
             jobType = 2
             jobunitId = "JU01"
             ownerRoleId = "ALL_USERS"
             scheduleDate = "2017/03/07 00:00:01.030"
             scope = "hinemos60_rhel7"
             sessionId = "20170307000000-000"
             startDate = "2017/03/07 00:00:01.275"
             status = 300
             triggerInfo = "SJOB01(SJOB01)"
          },
       total = 13
     }
    http://192.168.1.2:8080/HinemosWS/, getJobHistoryList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-d', '--displayed', action='store', type='int', metavar='INT', dest='displayed',
                    default=None, help='display number')
    psr.add_option('-s', '--startFrom', action='store', type='string', metavar='STRING', dest='start_from_date',
                    default='', help='start from date = \'yyyy/mm/dd HH:mm:ss\'')
    psr.add_option('-S', '--startTo', action='store', type='string', metavar='STRING', dest='start_to_date',
                    default='', help='start to date = \'yyyy/mm/dd HH:mm:ss\'')
    psr.add_option('-e', '--endFrom', action='store', type='string', metavar='STRING', dest='end_from_date',
                    default='', help='end from date= \'yyyy/mm/dd HH:mm:ss\'')
    psr.add_option('-E', '--endTo', action='store', type='string', metavar='STRING', dest='end_to_date',
                    default='', help='end to date= \'yyyy/mm/dd HH:mm:ss\'')
    psr.add_option('-I', '--jobID',  action='store', type='string', metavar='ID', dest='job_id',
                    default='', help='job ID')
    psr.add_option('-T', '--status', action='store', type='string', metavar='STRING', dest='status',
                    default='', help='status: TYPE_WAIT = 0,TYPE_RESERVING = 1,TYPE_SKIP = 2,TYPE_RUNNING = 100,TYPE_STOPPING = 101,TYPE_SUSPEND = 200,TYPE_STOP = 201,TYPE_END = 300,TYPE_MODIFIED = 301,TYPE_END_UNMATCH = 302,TYPE_END_CALENDAR = 303,RTYPE_END_SKIP = 304,TYPE_END_START_DELAY = 305,TYPE_END_END_DELAY = 306,TYPE_ERROR = 400' )
    psr.add_option('-i', '--trginfo', action='store', type='string', metavar='STRING', dest='trigger_info',
                    default='', help='trigger information')
    psr.add_option('-t', '--trgtype', action='store', type='int', metavar='INT', dest='trigger_type',
                    default=(None, {'RANGE':[1,4]}), help='trigger type SCHEDULE = 1, MANUAL = 2, MONITOR = 3, FILE CHECK = 4')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default='', help='owerRoleID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        if opts.start_from_date != '':
            opts.start_from_date = DateConvert.get_epochtime_from_datetime(opts.start_from_date)
        if opts.start_to_date != '':
            opts.start_to_date = DateConvert.get_epochtime_from_datetime(opts.start_to_date)
        if opts.end_from_date != '':
            opts.end_from_date = DateConvert.get_epochtime_from_datetime(opts.end_from_date)
        if opts.end_to_date != '':
            opts.end_to_date = DateConvert.get_epochtime_from_datetime(opts.end_to_date)

        ### jobHistoryFilter Parameter ###
        jobHistoryFilter = endpoint.create_object('jobHistoryFilter')
        if opts.start_from_date != '':
            jobHistoryFilter.startFromDate=opts.start_from_date
        if opts.start_to_date != '':
            jobHistoryFilter.startToDate=opts.start_to_date
        if opts.end_from_date != '':
            jobHistoryFilter.endFromDate=opts.end_from_date
        if opts.end_to_date != '':
            jobHistoryFilter.endToDate=opts.end_to_date
        if opts.job_id != '':
            jobHistoryFilter.jobId=opts.job_id
        if opts.status != '':
            jobHistoryFilter.status=opts.status
        if opts.trigger_info != '':
            jobHistoryFilter.triggerInfo=opts.trigger_info
        if opts.trigger_type != '':
            jobHistoryFilter.triggerType=opts.trigger_type
        if opts.owner_role_id != '':
            jobHistoryFilter.ownerRoleId=opts.owner_role_id

        result = endpoint.getJobHistoryList(jobHistoryFilter, opts.displayed)
        if result.total != 0:
            for i in range(len(result.list)):
                if 'endDate' in result.list[i]:
                    result.list[i].endDate = DateConvert.get_datetime_from_epochtime(result.list[i].endDate)
                if 'scheduleDate' in result.list[i]:
                    result.list[i].scheduleDate = DateConvert.get_datetime_from_epochtime(result.list[i].scheduleDate)
                if 'startDate' in result.list[i]:
                    result.list[i].startDate = DateConvert.get_datetime_from_epochtime(result.list[i].startDate)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getJobHistoryList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
