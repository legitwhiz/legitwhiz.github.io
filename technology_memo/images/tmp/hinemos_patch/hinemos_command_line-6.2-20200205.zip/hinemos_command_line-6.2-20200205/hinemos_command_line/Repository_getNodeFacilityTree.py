#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ファシリティツリー(ノードツリー)を取得する

<概要>
ファシリティツリー(ノードツリー)を取得して表示します。

<使用例>
[command]
    $ python Repository_getNodeFacilityTree.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -R ADMINISTRATOR

[result]
    (facilityTreeItem){
       data =
          (facilityInfo){
             ownerRoleId = None
             facilityId = "_ROOT_"
             facilityName = "$[ROOT]"
             facilityType = 2
             description = None
             iconImage = None
             displaySortOrder = 100
             valid = True
          }
     }
    http://192.168.1.2:8080/HinemosWS/, getNodeFacilityTree succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.repository import FacilityTree
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.repository import ResultSet

def main():

    psr = MyOptionParser()
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default='ALL_USERS', help='ownerRoleID (default: ALL_USERS)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit###
        result = endpoint.getNodeFacilityTree(opts.owner_role_id)
        ResultSet.facilityTree(result)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getNodeFacilityTree')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
