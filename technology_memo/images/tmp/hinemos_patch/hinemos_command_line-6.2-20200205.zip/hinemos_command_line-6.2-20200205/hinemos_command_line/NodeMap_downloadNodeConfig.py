#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
検索条件に一致したノードの構成情報ファイルをダウンロードする

<概要>
検索条件に一致したノードの構成情報ファイル（CSV）をダウンロードします。

<使用例>
[command]
    $ python NodeMap_downloadNodeConfig.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -I LINUX -T "2019/06/26 00:00:00" -L ja -i OS,PROCESS,HW_FILESYSTEM -A true -S "[{\"nodeConfigSettingItemName\" : \"HOSTNAME\",\"exists\" : \"true\",\"itemList\" :[{  \"itemName\" : \"HOSTNAME\",  \"method\" : \"=\",  \"itemValue\" : \"hinemos\"}]}]"

[result]

    http://127.0.0.1:8080/HinemosWS/, downloadNodeConfig succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale
import json
import re
from zeep import xsd
from datetime import datetime
from hinemos.util.opt import MyOptionParser
from hinemos.api.nodemap import NodeMapEndpoint
from hinemos.api.hinemosproperty import HinemosPropertyEndpoint
from hinemos.util.common import DateConvert, ResultPrinter, SettingUtil
from hinemos.util.modifier import ObjectModifier


def main():
    psr = MyOptionParser()
    psr.add_option('-I', '--facilityID', action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Scope Facility ID')
    psr.add_option('-T', '--targetDateTime', action='store', type='string', metavar='DATE', dest='target_date_time_raw',
                   converter=DateConvert.get_epochtime_from_datetime,
                   default=(None, {'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$',
                                              'must be in [yyyy/mm/dd HH:MM:SS] format']}),
                   help='Target Date Time [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-L', '--language', action='store', type='string', metavar='STRING', dest='language_code',
                   default=('ja', {'INLIST': ['ja', 'en']}),
                   help='language_code = en or ja, default=ja')
    psr.add_option('-i', '--settingItemIds', action='store_split', type='string', metavar='STRING',
                   dest='setting_item_ids', default=None,
                   help='Add Configuration Setting IDs (Comma Separated). SettingItemIds = '
                        'HOSTNAME,OS,HW_CPU,HW_MEMORY,HW_NIC,HW_DISK,HW_FILESYSTEM,NODE_VARIABLE,NETSTAT,PROCESS,'
                        'PACKAGE,PRODUCT,LICENSE,CUSTOM')
    psr.add_option('-A', '--and', action='store', type='string', metavar='BOOL', dest='filter_is_and_raw',converter=SettingUtil.convert2nbool,
                    default=('true', {'INLIST':['true','false']}), help='Search Condition And=true, Or=false')
    psr.add_option('-S', '--searchConditionJson', action='store', type='string', metavar='STRING', dest='search_j',
                   default=None, help='Add Search Condition. Please specify in JSON.')
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        node_map_endpoint = NodeMapEndpoint(opts.mgr_url, opts.user, opts.passwd)
        hinemos_property_endpoint = HinemosPropertyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # 検索条件設定
        node_info = node_map_endpoint.get_obj('ns0', 'nodeInfo')
        ObjectModifier.replace_if_not_none(
            node_info,
            nodeConfigTargetDatetime=opts.target_date_time)
        
        ObjectModifier.replace_if_not_none(
            node_info,
            nodeConfigFilterIsAnd=opts.filter_is_and)
        
        if opts.search_j is not None:
            json_obj = json.loads(opts.search_j.encode(locale.getdefaultlocale()[1]))
            for item in json_obj:
                for itemList in item["itemList"]:
                    if isinstance(itemList["itemValue"], int):
                        itemList["itemValue"] = xsd.AnyObject(xsd.Int(), itemList["itemValue"])
                    
                    if isinstance(itemList["itemValue"], str) or isinstance(itemList["itemValue"], unicode):
                        if isDateStr(item["nodeConfigSettingItemName"], itemList["itemName"]) :
                            pattern = '^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$'
                            regret = re.match(pattern, itemList["itemValue"])
                            if regret:
                                itemList["itemValue"] = xsd.AnyObject(xsd.Long(), DateConvert.get_epochtime_from_datetime(itemList["itemValue"]))
                            else:
                                itemList["itemValue"] = xsd.AnyObject(xsd.String(), itemList["itemValue"])
                        else:
                            itemList["itemValue"] = xsd.AnyObject(xsd.String(), itemList["itemValue"])
                    
                node_info.nodeConfigFilterList.append(item)
                
        # 共通設定取得又は作成
        # 1. 構成情報ファイルの一時ファイルIDを取得する
        file_id = node_map_endpoint.getNodeConfigFileId()

        # 2. 一度取得できる情報のノード数を取得する
        download_node_count = node_map_endpoint.getDownloadNodeConfigCount()

        # 3. ダウンロードしたい構成情報リストを取得する
        item_list = []
        if opts.setting_item_ids_converted is not None:
            item_list = opts.setting_item_ids_converted

        # 4. 対象ダウンロード情報のノード一覧を取得する
        facility_id_list = []
        node_list = node_map_endpoint.getNodeList(opts.facility_id, node_info)
        if node_list is not None:
            for nodeInfo in node_list:
                facility_id_list.append(nodeInfo.facilityId)

        # 5. その他
        language_code = opts.language_code
        hinemos_time = hinemos_property_endpoint.getHinemosTime()
        current_datetime = datetime.fromtimestamp(hinemos_time/1000).replace(
            microsecond=(hinemos_time % 1000) * 1000).strftime('%Y%m%d%H%M%S%f')[:-3]
        manager_file_name = 'NodeConfiguration_' + current_datetime + ".csv" + "." + file_id
        manager_name = "HINEMOS_MANAGER"

        # ヘッダーデータをダウンロードする
        # 検索条件により「condition_str」が作成されます。
        condition_json = {}
        if opts.target_date_time is not None:
            condition_json['targetDateTime'] = opts.target_date_time_raw
            
        if opts.filter_is_and is not None:
            condition_json['filterIsAnd'] = opts.filter_is_and
            
        if opts.search_j is not None:
            condition_json['searchConditionJson'] = json.loads(opts.search_j.encode(locale.getdefaultlocale()[1]))
        
        condition_str = "\"" + json.dumps(condition_json).replace("\"", "\"\"") + "\""
        
        header_file_name = manager_file_name + ".header"
        header_file_handler = node_map_endpoint.downloadNodeConfigFileHeader(condition_str, header_file_name, language_code)

        # 構成情報データをダウンロードする
        file_index = 0
        start = 0
        end = download_node_count
        facility_id_list_len = len(facility_id_list)
        node_config_file_content_list = []
        while facility_id_list_len > download_node_count:
            node_config_file_name = manager_file_name + "." + str(file_index)
            facility_id_list_len = facility_id_list_len - download_node_count
            node_config_file_handler = node_map_endpoint.downloadNodeConfigFile(
                facility_id_list[start:end], opts.target_date_time, node_config_file_name, language_code, manager_name,
                item_list)
            node_config_file_content_list.append(node_config_file_handler)
            start = end
            end = start + download_node_count
            file_index = file_index + 1

        if (facility_id_list_len > 0) and (facility_id_list_len <= download_node_count):
            node_config_file_name = manager_file_name + "." + str(file_index)
            node_config_file_handler = node_map_endpoint.downloadNodeConfigFile(
                facility_id_list[start:], opts.target_date_time, node_config_file_name,
                language_code, manager_name, item_list)
            node_config_file_content_list.append(node_config_file_handler)

        # ダウンロードされたデータに関する、ロカール環境にファイルを作成する
        downloaded_file_name = 'NodeConfiguration_' + current_datetime + ".csv"
        with open(downloaded_file_name, "wb") as handler:
            handler.write(header_file_handler)
            for file_content in node_config_file_content_list:
                if file_content is None:
                    continue
                handler.write(file_content)

        # ダウンロードされた一時ファイルをマネージャ側から削除する
        node_map_endpoint.deleteNodeConfigFile(manager_file_name)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'downloadNodeConfig')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code

def isDateStr(nodeConfigSttingItemName, itemName):
    if (nodeConfigSttingItemName == "OS" and itemName == "OS_STARTUP_DATE_TIME") \
    or (nodeConfigSttingItemName == "PROCESS" and itemName == "PROCESS_STARTUP_DATE_TIME") \
    or (nodeConfigSttingItemName == "PACKAGE" and itemName == "PACKAGE_INSTALL_DATE") \
    or (nodeConfigSttingItemName == "LICENSE" and itemName == "LICENSE_EXPIRATION_DATE"):
        return True
    else:
        return False
    
if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
