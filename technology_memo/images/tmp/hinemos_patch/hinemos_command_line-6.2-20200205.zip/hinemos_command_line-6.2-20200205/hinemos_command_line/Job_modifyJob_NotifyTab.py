#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
「通知先の指定」タブの情報を変更する

<概要>
「通知先の指定」タブの情報を変更します。

<使用例>
- 通知の重要度を変更します。
[command]
    $ python Job_modifyJob_NotifyTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001 -B WARNING -C WARNING -D WARNING -E WARNING

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- 通知IDを設定します。
[command]
    $ python Job_modifyJob_NotifyTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB2 -a STATUS_FOR_POLLING,EVENT_FOR_POLLING -d TEST_STATUS

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil
from hinemos.util.common import ResultPrinter
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.notify import NotifyUtil
from hinemos.util.modifier import ObjectModifier

def main():

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    ### 通知先の指定タブ設定項目 ###
    psr.add_option('-B', '--priorityBegin', action='store', type='string', metavar='STRING', dest='priority_begin_raw',converter=NotifyUtil.convert2priority,
                    default=(None, {'INLIST':['', 'INFO','WARN','CRITICAL','UNKNOWN']}), help='priority_begin(notifications tab) = INFO or WARN or CRITICAL or UNKNOWN')
    psr.add_option('-C', '--priorityNormal', action='store', type='string', metavar='STRING', dest='priority_normal_raw',converter=NotifyUtil.convert2priority,
                    default=(None, {'INLIST':['', 'INFO','WARN','CRITICAL','UNKNOWN']}), help='priority_normal(notifications tab) = INFO or WARN or CRITICAL or UNKNOWN')
    psr.add_option('-D', '--priorityWarn', action='store', type='string', metavar='STRING', dest='priority_warn_raw',converter=NotifyUtil.convert2priority,
                    default=(None, {'INLIST':['', 'INFO','WARN','CRITICAL','UNKNOWN']}), help='priority_warn(notifications tab) = INFO or WARN or CRITICAL or UNKNOWN')
    psr.add_option('-E', '--priorityAbnormal', action='store', type='string', metavar='STRING', dest='priority_abnormal_raw',converter=NotifyUtil.convert2priority,
                    default=(None, {'INLIST':['', 'INFO','WARN','CRITICAL','UNKNOWN']}), help='priority_abnormal(notifications tab) = INFO or WARN or CRITICAL or UNKNOWN')

    psr.add_option('-a', '--addNotifyIDs', action='store_split', type='string', metavar='STRING', dest='add_notify_ids_raw',
                    default=None, help='add notifications. addNotifyIDs = notifyID1,notifyID2,...,notifyIDN')
    psr.add_option('-d', '--deleteNotifyIDs', action='store_split', type='string', metavar='STRING', dest='del_notify_ids_raw',
                    default=None, help='delete notifications. deleteNotifyIDs = notifyID1,notifyID2,...,notifyIDN')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job)
        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, job_map['jobunitId'])
        del job_tree_full

        job_info = JobUtil.find_job_info(job_tree, job_map['jobId'])
        if job_info is None:
            raise ErrorHandler.ArgumentError('Job {:s} not found!'.format(job_map['jobId']))

        job_type_label = JobUtil.convert2job_type_label(job_info.type)
        if job_type_label in ('REFERJOB', 'REFERJOBNET'): # TODO Do not use exclusion condition
            raise ErrorHandler.ArgumentError('This operation is not available for %s!' % job_type_label)

        new_job_info = endpoint.getJobFull(endpoint.create_job_info_minimal(job_map['jobunitId'], job_map['jobId']))
        with ObjectModifier(new_job_info) as modifier:
            modifier.set_if_first_not_none('beginPriority', opts.priority_begin)
            modifier.set_if_first_not_none('normalPriority', opts.priority_normal)
            modifier.set_if_first_not_none('warnPriority', opts.priority_warn)
            modifier.set_if_first_not_none('abnormalPriority', opts.priority_abnormal)

        # Notify
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)
        if opts.add_notify_ids is not None:
            if not hasattr(new_job_info, 'notifyRelationInfos'):
                setattr(new_job_info, 'notifyRelationInfos', [])

            # Check if notification already exists
            ids = set(opts.add_notify_ids)
            existed_ids = tuple([x.notifyId for x in new_job_info.notifyRelationInfos])

            # Then add
            for x in filter((lambda x: x not in existed_ids), ids):
                new_job_info.notifyRelationInfos.append(\
                    endpoint.create_notify_relation_info(notify_endpoint.getNotify(x), job_map['jobunitId'], job_map['jobId']))

        if opts.del_notify_ids is not None and hasattr(new_job_info, 'notifyRelationInfos') and 0 < len(new_job_info.notifyRelationInfos):
            ids = set(opts.del_notify_ids)
            for i in reversed(xrange(len(new_job_info.notifyRelationInfos))):
                if new_job_info.notifyRelationInfos[i].notifyId in ids:
                    del new_job_info.notifyRelationInfos[i]

        JobUtil.replace_job_info(job_tree, new_job_info)

        # Clean up and replace none with blank
        JobUtil.cleanup_and_fixnone(job_tree)

        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJob')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
