#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
環境構築設定、またはモジュールのチェックを実行する

<概要>
環境構築設定、またはモジュールのチェックを実行し、チェック結果を表示します。

<使用例>
- ログイン情報(-O, -P)を入力して環境構築設定をチェックします。
[command]
    $ python Infra_checkInfraModule.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I AGENT_INSTALL_LINUX -O my_login_user -P my_common_password -f

[result]
    Session(sessionID=INFRA_20170306183459-000) created.
    
    ##############################
    #   Result of RPM_TRANSFER   #
    ##############################
    ------------------------------
    NodeID=NODE001 (statusCode=0)
    ------------------------------
    MD5s are same
    
    #########################
    #   Result of INSTALL   #
    #########################
    -------------------------
    NodeID=NODE001 (statusCode=0)
    -------------------------
    command=rpm -q hinemos-6.0-agent
    exitCode=0
    out=hinemos-6.0-agent-6.0.0-1.el.noarch
    err=
    
    #######################
    #   Result of START   #
    #######################
    -----------------------
    NodeID=NODE001 (statusCode=0)
    -----------------------
    command=service hinemos_agent status
    exitCode=0
    out=Hinemos Agent (PID 10396) is running...
    err=
    http://192.168.1.2:8080/HinemosWS/, checkInfraModule succeeded.


- 環境構築設定のチェック時に、ノードに接続する際ノードプロパティの設定値(SSH/WinRM)を利用して接続します(--useNodeProperty)。
[command]
    $ python Infra_checkInfraModule.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I AGENT_INSTALL_LINUX -M INSTALL -f --useNodeProperty

[result]
    Session(sessionID=INFRA_20170306183748-000) created.
    
    #########################
    #   Result of INSTALL   #
    #########################
    -------------------------
    NodeID=NODE001 (statusCode=0)
    -------------------------
    command=rpm -q hinemos-6.0-agent
    exitCode=0
    out=hinemos-6.0-agent-6.0.0-1.el.noarch
    err=
    http://192.168.1.2:8080/HinemosWS/, checkInfraModule succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
from hinemos.api.infra import InfraEndpoint
from hinemos.api.exceptions import ObjectNotFoundError, ArgumentError,\
    BadResultError
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.infra import InfraUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--managementID',  action='store', type='string', metavar='ID', dest='management_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='infra management ID')
    psr.add_option('-M', '--moduleIDs', action='store_split', type='string', metavar='STRING', dest='module_ids',
                   default=(None, 'NOTBLANK'), help='moduleIDs = moduleID1,moduleID2,...,moduleIDN. All modules will be check if this field is left blank')

    psr.add_option('-n', '--useNodeProperty', action='store_true',
                    dest='use_node_property',
                   default=False, help='use login info set in node properties')
    psr.add_option('-p', '--useInfraProperty', action='store_true',
                    dest='use_infra_property',
                   default=False, help='use login info set in infra management properties')
    psr.add_option('-f', '--force', action='store_true', dest='force',
                    default=None, help='force continuing even on errors')
    psr.add_option('-v', '--verbose', action='store_true', dest='verbose',
                   default=None, help='verbose mode')

    psr.add_option('-O', '--commonUser', action='store', type='string', metavar='STRING', dest='access_user',
                   default=None, help='common SSH/WinRM login user name')
    psr.add_option('-P', '--commonPassword', action='store', type='string', metavar='STRING', dest='access_password',
                   default='', help='common SSH/WinRM login password')

    psr.add_option('-R', '--commonSSHPrivateKeyFilepaths', action='store', type='string', metavar='STRING', dest='ssh_private_key_filepath',
                   default=None, help='common SSH private key file path')
    psr.add_option('-S', '--commonSSHPrivateKeyPassphrase', action='store', type='string', metavar='STRING', dest='ssh_private_key_passphrase',
                   default=None, help='common SSH private key passphrase')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1
    session_id = None

    # pylint: disable=W0703
    try:
        # Additional check
        auth_type = InfraUtil.convert2auth_type('DIALOG')
        if opts.use_node_property:
            auth_type = InfraUtil.convert2auth_type('NODE_PARAM')
        elif opts.use_infra_property:
            auth_type = InfraUtil.convert2auth_type('INFRA_PARAM')
        if auth_type == InfraUtil.convert2auth_type('DIALOG') and not opts.access_user:
            raise ArgumentError('please specify SSH/WinRM login information!')

        ### login ###
        endpoint = InfraEndpoint(opts.mgr_url, opts.user, opts.passwd)
        repository_endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Prepare modules
        management_info = endpoint.getInfraManagement(opts.management_id)
        if opts.module_ids is None:
            if hasattr(management_info, 'moduleList'):
                module_id_list = [x.moduleId for x in management_info.moduleList]
            else:
                raise ObjectNotFoundError('no module to check!')
        else:
            module_id_list = opts.module_ids

        # AccessInfo
        access_info_list = []
        if auth_type == InfraUtil.convert2auth_type('DIALOG'):
            for x in repository_endpoint.getExecTargetFacilityIdList(management_info.facilityId, management_info.ownerRoleId):
                access_info = endpoint.create_access_info(x)
                access_info.moduleId = '' # HC: Cannot be none

                node_platform = repository_endpoint.getNode(x).platformFamily

                if node_platform.startswith('WIN'): 
                    if opts.access_user is not None:
                        access_info.winRmUser = opts.access_user
                    if opts.access_password is not None:
                        access_info.winRmPassword = opts.access_password
                else:
                    if opts.access_user is not None:
                        access_info.sshUser = opts.access_user
                    if opts.access_password is not None:
                        access_info.sshPassword = opts.access_password
    
                    if opts.ssh_private_key_filepath is not None:
                        access_info.sshPrivateKeyFilepath = opts.ssh_private_key_filepath
    
                    if opts.ssh_private_key_passphrase is not None:
                        access_info.sshPrivateKeyPassphrase = opts.ssh_private_key_passphrase

            access_info_list.append(access_info)

        # Create session
        session_id = endpoint.createSession(opts.management_id, module_id_list, auth_type, access_info_list)
        print 'Session(sessionID=%s) created.' % session_id
        print

        while True:
            module_result = endpoint.checkInfraModule(session_id, opts.verbose)
            title = '#   Result of %s   #' % module_result.moduleId
            sepsize = len(title)
            print '#' * sepsize
            print title
            print '#' * sepsize

            if 'moduleNodeResultList' in module_result:
                for x in module_result.moduleNodeResultList:
                    print '-' * sepsize
                    print 'NodeID=%s (statusCode=%d)' % (x.facilityId, x.statusCode)
                    print '-' * sepsize
                    print x.message
                    print

                    if not opts.force and x.result == 0:
                        raise BadResultError('check failed!')
            else:
                print 'No result'

            if not module_result.hasNext:
                break

        return_code = ResultPrinter.success(None, opts.mgr_url, 'checkInfraModule')
        session_id = None
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    finally:
        if session_id:
            print
            print 'deleteSession(sessionID=%s)' % session_id, '...',
            print endpoint.deleteSession(session_id)
            print
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
