#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
マネージャ上のメールテンプレート情報を変更する

<概要>
マネージャ上のメールテンプレート情報を変更します。

<使用例>
[command]
    $ python MailTemplate_modifyMailTemplate.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -M TEST_MT -S "Modify TEST SUBJECT"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyMailTemplate succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.mailtemplate import MailTemplateEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--mailTemplateID',  action='store', type='string', metavar='ID', dest='mail_template_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='mailTemplateID')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description', default=None, help='description')
    psr.add_option('-S', '--subject', action='store', type='string', metavar='STRING', dest='subject', help='mail subject')
    psr.add_option('-B', '--body', action='store', type='string', metavar='STRING', dest='body', help='mail body')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MailTemplateEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ###  mailTemplateInfo parameter ###
        mailTemplateInfo = endpoint.getMailTemplateInfo(opts.mail_template_id)
        if opts.description is not None:
            mailTemplateInfo.description = opts.description
        if opts.subject is not None:
            mailTemplateInfo.subject = opts.subject
        if opts.body is not None:
            mailTemplateInfo.body = opts.body

        endpoint.modifyMailTemplate(mailTemplateInfo)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyMailTemplate')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
