#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ファシリティツリー(スコープツリー)を取得する

<概要>
ファシリティツリー(スコープツリー)を取得して表示します。

取得したファシリティツリーには割り当てられたノードを含みます。

<使用例>
[command]
    $ python Repository_getFacilityTree.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    (facilityTreeItem){
       children[] =
          (facilityTreeItem){
             authorizedRoleIdSet[] =
                "HINEMOS_MODULE",
                "INTERNAL",
                "ADMINISTRATORS",
                "ALL_USERS",
             data =
                (facilityInfo){
                   ownerRoleId = "INTERNAL"
                   facilityId = "INTERNAL"
                   facilityName = "$[HINEMOS_INTERNAL]"
                   facilityType = 0
                   description = "The Scope that Hinemos internal messages is stored"
                   iconImage = None
                   displaySortOrder = 11000
                   valid = True
                }
          },
        ... 中略 ...
       data =
          (facilityInfo){
             ownerRoleId = None
             facilityId = "_ROOT_"
             facilityName = "$[ROOT]"
             facilityType = 2
             description = None
             iconImage = None
             valid = True
          }
     }
    http://192.168.1.2:8080/HinemosWS/, getFacilityTree succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.repository import ResultSet

def main():

    psr = MyOptionParser()
    # TODO Check
    #psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
    #                default='', help='ownerRoleID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit###
        #result = endpoint.get_facility_tree(opts.owner_role_id)
        result = endpoint.getFacilityTree('')
        if result is not None:
            ResultSet.facilityTree(result)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getFacilityTree')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
