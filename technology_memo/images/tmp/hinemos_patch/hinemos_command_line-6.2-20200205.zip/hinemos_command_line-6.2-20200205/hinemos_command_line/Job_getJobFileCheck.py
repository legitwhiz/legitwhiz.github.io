#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定した実行契機IDと一致したファイルチェック実行契機情報を取得する

<概要>
引数で指定した実行契機IDと一致したファイルチェック実行契機情報を取得して表示します。

<使用例>
[command]
    $ python Job_getJobFileCheck.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_FC

[result]
    (jobFileCheck){
       createTime = "2017/02/27 20:04:27.951"
       createUser = "hinemos"
       id = "TEST_FC"
       jobId = "TEST_JOB"
       jobName = "TEST_NAME"
       jobunitId = "TEST_JOBU"
       name = "TEST_FC"
       ownerRoleId = "ALL_USERS"
       type = 1
       updateTime = "2017/03/07 10:24:42.212"
       updateUser = "hinemos"
       valid = False
       directory = "/tmp/"
       eventType = 0
       facilityId = "TEST_SCOPE"
       fileName = "test.txt"
       scope = "TEST_SCOPE>"
     }
    http://192.168.1.2:8080/HinemosWS/, getJobFileCheck succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--filecheckID',  action='store', type='string', metavar='ID', dest='filecheck_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='filecheck ID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = endpoint.getJobFileCheck(opts.filecheck_id)
        if result is not None:
            result.createTime = DateConvert.get_datetime_from_epochtime(result.createTime)
            result.updateTime = DateConvert.get_datetime_from_epochtime(result.updateTime)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getJobFileCheck')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
