#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
「コマンド」タブの情報を変更する

<概要>
「コマンド」タブの情報を変更します。

<使用例>
- 「コマンド」タブの情報を変更します。
[command]
    $ python Job_modifyJob_CommandTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB1 -M 1 -F WINDOWS -C "cmd /c \"myscript.bat\"" -T 0 -S "dir D:\"" -X true -Y user1

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- ジョブ終了時の変数を追加します。
[command]
    $ python Job_modifyJob_CommandTab.py -w hinemos -J JU001/JOB1 --resultExtractorNames var1 var2 var3 --resultExtractorValues value1 value2 value3 --resultExtractorFromStdouts true false false

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.

- ジョブ終了時の変数を削除します。
[command]
    $ python Job_modifyJob_CommandTab.py -w hinemos -J JU001/JOB1 --delResultExtractorNames var1 var2

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- 環境変数を追加します。
[command]
    $ python Job_modifyJob_CommandTab.py -w hinemos -J JU001/JOB1 --envVarNames env1 env2 env3 --envVarValues value1 value2 value3 --envVarDescs desc1 ""

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.

- 環境変数を削除します。
[command]
    $ python Job_modifyJob_CommandTab.py -w hinemos -J JU001/JOB1 --delEnvVarNames env1 env3

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.
"""

import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil, TabInfo
from hinemos.util.common import ResultPrinter, SettingUtil

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                   default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    ### コマンドタブ設定項目 ###
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None, 'NOTBLANK'), help='facilityID: jobParameter = \'#[FACILITY_ID]\', fixed value = facility ID')
    psr.add_option('-M', '--processingMethod', action='store', type='int', metavar='INT', dest='processingMethod',
                   default=None, help='Processing method: all nodes = 0, try one by one = 1')
    psr.add_option('-D', '--managerDistribute', action='store', type='string', metavar='BOOL', dest='managerDistribute_raw', converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST':['true','false']}), help='managerDistribute = true or false')
    psr.add_option('-N', '--scriptName', action='store', type='string', metavar='STRING', dest='scriptName',
                    default=(None, 'NOTBLANK'), help='Script name')
    psr.add_option('-E', '--scriptEncoding', action='store', type='string', metavar='STRING', dest='scriptEncoding',
                    default=(None, 'NOTBLANK'), help='Script encoding')
    psr.add_option('-O', '--scriptContent', action='store', type='string', metavar='STRING', dest='scriptContent',
                    default=None, help='Script content')
    psr.add_option('-C', '--startCommand', action='store', type='string', metavar='STRING', dest='start_command',
                    default=(None, 'NOTBLANK'), help='Start command')
    psr.add_option('-T', '--stopType', action='store', type='int', metavar='INT', dest='stop_type',
                    default=None, help='Set stopType: end process = 1, stop command = 0')
    psr.add_option('-S', '--stopCommand', action='store', type='string', metavar='STRING', dest='stop_command',
                    default=(None, 'NOTBLANK', {'WHEN':{'stop_type':0}, 'DO':('REQUIRED')}), help='Stop command')
    psr.add_option('-X', '--specifyUser', action='store', type='string', metavar='BOOL', dest='specify_user_raw', converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST':['true','false']}), help='Set specifyUser = true or false')
    psr.add_option('-Y', '--execUser', action='store', type='string', metavar='STRING', dest='execUser',
                    default=(None, 'NOTBLANK', {'WHEN':{'specify_user':1}, 'DO':('REQUIRED')}), help='Execution user')

    psr.add_option('--resultExtractorNames', action='my_x_append', type='string', metavar='STRING', dest='resultExtractorNames',
                   default=None, help='Result extractor names')
    psr.add_option('--resultExtractorValues', action='my_x_append', type='string', metavar='STRING', dest='resultExtractorValues',
                   default=None, help='Result extractor values')
    psr.add_option('--resultExtractorFromStdouts', action='my_x_append', type='string', metavar='STRING', dest='resultExtractorFromStdouts',
                   default=None, help='Result extractor read from stdout = true or false')

    psr.add_option('--delResultExtractorNames', action='my_x_append', type='string', metavar='STRING', dest='delResultExtractorNames',
                   default=None, help='Result extractor names to delete')

    psr.add_option('--envVarNames', action='my_x_append', type='string', metavar='STRING', dest='envVarNames',
                   default=None, help='Environment variable names')
    psr.add_option('--envVarValues', action='my_x_append', type='string', metavar='STRING', dest='envVarValues',
                   default=None, help='Environment variable values')
    psr.add_option('--envVarDescs', action='my_x_append', type='string', metavar='STRING', dest='envVarDescs',
                   default=None, help='Environment variable values')

    psr.add_option('--delEnvVarNames', action='my_x_append', type='string', metavar='STRING', dest='delEnvVarNames',
                   default=None, help='Environment variable names to delete')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job)
        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, job_map['jobunitId'])
        del job_tree_full

        LOGGER.debug(job_tree)

        job_info = JobUtil.find_job_info(job_tree, job_map['jobId'])
        if job_info is None:
            raise ErrorHandler.ArgumentError('Job {:s} not found!'.format(job_map['jobId']))

        job_type_label = JobUtil.convert2job_type_label(job_info.type)
        if job_type_label not in ('JOB',):
            raise ErrorHandler.ArgumentError('This operation is not available for %s!' % job_type_label)

        new_job_info = endpoint.getJobFull(endpoint.create_job_info_minimal(job_map['jobunitId'], job_map['jobId']))

        TabInfo.set_command_tab(
            new_job_info,
            opts.facility_id,
            opts.processingMethod,
            opts.managerDistribute, opts.scriptName, opts.scriptEncoding, opts.scriptContent,
            opts.start_command,
            opts.stop_type, opts.stop_command,
            opts.specify_user, opts.execUser)

        # Set jobCommandParamList
        if opts.resultExtractorNames:
            # Format
            length = len(opts.resultExtractorNames) - len(opts.resultExtractorValues)
            if length > 0:
                opts.resultExtractorValues += [None] * length

            if opts.resultExtractorFromStdouts is None:
                opts.resultExtractorFromStdouts = []
            for i, a in enumerate(opts.resultExtractorFromStdouts):
                opts.resultExtractorFromStdouts[i] = SettingUtil.convert2nbool(a)
            length = len(opts.resultExtractorNames) - len(opts.resultExtractorFromStdouts)
            if length > 0:
                opts.resultExtractorFromStdouts += [False] * length

            if 'jobCommandParamList' not in new_job_info.command:
                setattr(new_job_info.command, 'jobCommandParamList', [])

            for i, a in enumerate(opts.resultExtractorNames):
                # Replace if exists
                for b in new_job_info.command.jobCommandParamList:
                    if b.paramId == a:
                        if opts.resultExtractorValues[i] is not None:
                            b.value = opts.resultExtractorValues[i]
                        if opts.resultExtractorFromStdouts[i] is not None:
                            b.jobStandardOutputFlg = opts.resultExtractorFromStdouts[i]
                        LOGGER.debug('Modify jobCommandParam. %s', b)
                        break
                else:
                    subinfo = endpoint.create_job_command_param(a, opts.resultExtractorValues[i], opts.resultExtractorFromStdouts[i])
                    LOGGER.debug('Add jobCommandParam. %s', subinfo)
                    new_job_info.command.jobCommandParamList.append(subinfo)

        if opts.delResultExtractorNames:
            if 'jobCommandParamList' not in new_job_info.command:
                LOGGER.warning('Empty jobCommandParamList!')
            else:
                #new_job_info.command.jobCommandParamList[:] = [a for a in new_job_info.command.jobCommandParamList if not a.paramId in opts.delResultExtractorNames]
                new_list = []
                for a in new_job_info.command.jobCommandParamList:
                    if not a.paramId in opts.delResultExtractorNames:
                        new_list.append(a)
                    else:
                        LOGGER.debug('Delete jobCommandParam: %s', a)
                        opts.delResultExtractorNames.remove(a.paramId)
                new_job_info.command.jobCommandParamList = new_list
                for a in opts.delResultExtractorNames:
                    LOGGER.warning('jobCommandParam not found: %s', a)

        # Set envVariableInfo
        if opts.envVarNames:
            # Format
            if opts.envVarValues is None:
                opts.envVarValues = []
            length = len(opts.envVarNames) - len(opts.envVarValues)
            if length > 0:
                opts.envVarValues += [None] * length

            if opts.envVarDescs is None:
                opts.envVarDescs = []
            length = len(opts.envVarNames) - len(opts.envVarDescs)
            if length > 0:
                opts.envVarDescs += [''] * length

            if 'envVariableInfo' not in new_job_info.command:
                setattr(new_job_info.command, 'envVariableInfo', [])

            for i, a in enumerate(opts.envVarNames):
                # Replace if exists
                for b in new_job_info.command.envVariableInfo:
                    if b.envVariableId == a:
                        if opts.envVarValues[i] is not None:
                            b.value = opts.envVarValues[i]
                        if opts.envVarDescs[i] is not None:
                            b.description = opts.envVarDescs[i]
                        LOGGER.debug('Modify envVariableInfo. %s', b)
                        break
                else:
                    subinfo = endpoint.create_job_env_variable_info(a, opts.envVarValues[i], opts.envVarDescs[i])
                    LOGGER.debug('Add envVariableInfo. %s', subinfo)
                    new_job_info.command.envVariableInfo.append(subinfo)

        if opts.delEnvVarNames:
            if 'envVariableInfo' not in new_job_info.command:
                LOGGER.warning('Empty envVariableInfo!')
            else:
                #new_job_info.command.envVariableInfo[:] = [a for a in new_job_info.command.envVariableInfo if not a.envVariableId in opts.delEnvVarNames]
                new_list = []
                for a in new_job_info.command.envVariableInfo:
                    if not a.envVariableId in opts.delEnvVarNames:
                        new_list.append(a)
                    else:
                        LOGGER.debug('Delete envVariableInfo: %s', a)
                        opts.delEnvVarNames.remove(a.envVariableId)
                new_job_info.command.envVariableInfo = new_list
                for a in opts.delEnvVarNames:
                    LOGGER.warning('envVariableInfo not found: %s', a)

        JobUtil.replace_job_info(job_tree, new_job_info)

        # Clean up and replace none with blank
        JobUtil.cleanup_and_fixnone(job_tree)

        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJob')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
