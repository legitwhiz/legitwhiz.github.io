#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
カスタム監視(数値)の監視設定を登録する

<概要>
カスタム監視(数値)の監視設定を登録します。

<使用例>
[command]
    $ python MonitorSetting_addMonitor_CustomI.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I CUSTOMN1 -A MYAPP -F SCOPE001 -o command1

[result]
    http://192.168.1.2:8080/HinemosWS/, addMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_add_args_parser(help_default_info)
    psr.add_option('-t', '--commandExecType', action='store', type='string',
                   metavar='STRING', dest='command_exec_type',
                   default=(None, {'INLIST': ['INDIVIDUAL', 'SELECTED']}),
                   help='commandExecType = INDIVIDUAL or SELECTED (default: INDIVIDUAL)')
    psr.add_option('-f', '--selectedFacilityId', action='store', type='string',
                   metavar='STRING', dest='selected_facility_id',
                   default=(None, 'NOTBLANK', {
                            'WHEN': {'command_exec_type': 'SELECTED'},
                            'DO': ('REQUIRED')}),
                   help='facility ID for running command')
    psr.add_option('-s', '--specifyRunUser', action='store', type='string',
                   metavar='STRING', dest='specify_user',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='specifyRunUser')
    psr.add_option('-e', '--execUser', action='store', type='string',
                   metavar='STRING', dest='run_user',
                   default=None, help='run command as user')
    psr.add_option('-o', '--command', action='store', type='string',
                   metavar='STRING', dest='command',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='command')
    psr.add_option('-O', '--timeout', action='store', type='int',
                   metavar='INT', dest='timeout', default=None,
                   help='run command with time limit (default: 15000[msec])')
    psr.add_option('-d', '--calculateDiff', action='store', type='string',
                   metavar='STRING', dest='convert_flg_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='calculate difference from previous result =true,'
                   'do nothing = no (default: no)')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)
        endpoint.add_monitor_custom_n(vars(opts))

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
