#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
SNMPTRAP監視の監視設定情報を変更する

<概要>
SNMPTRAP監視の監視設定情報を変更します。

<使用例>
[command]
    $ python MonitorSetting_modifyMonitor_Trap.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TRAP1 -A MYAPP -F SCOPE001

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.modifier import ObjectModifier
from hinemos.util.notify import NotifyUtil
from hinemos.api.exceptions import ObjectNotFoundError
from hinemos.util.argsparserbuilder import MonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = MonitorSettingArgsParserBuilder()\
        .build_monitor_setting_modify_args_parser(help_default_info)

    psr.add_option('-g', '--logFormatID',  action='store', type='string',
                   metavar='ID', dest='logformat_id',
                   default=(None, {
                       'WHEN': {'collect': 1},
                       'DO': ('REQUIRED', 'NOTBLANK')}),
                   help='Log format ID')

    psr.add_option('-O', '--checkCommunityCheck', action='store',
                   type='string', metavar='STRING',
                   dest='check_community_check',
                   default=None, help='not check =0, check =1')
    psr.add_option('-o', '--checkCommunityName', action='store', type='string',
                   metavar='STRING', dest='check_community_name',
                   default=None, help='community name')
    psr.add_option('-S', '--checkCharsetConvert', action='store',
                   type='string', metavar='STRING',
                   dest='check_charset_convert',
                   default=None, help='not convert =0, convert =1')
    psr.add_option('-s', '--checkCharsetName', action='store', type='string',
                   metavar='STRING', dest='check_charset_name',
                   default=None, help='charset name')
    psr.add_option('-J', '--notifyUnspecified', action='store', type='string',
                   metavar='BOOL', dest='notify_unspecified_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='notify when an unspecified trap received')
    psr.add_option('-j', '--notifyUnspecifiedPriority', action='store',
                   type='string', metavar='STRING',
                   dest='notify_unspecified_priority_raw',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                        'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']}),
                   help='notifyUnspecifiedPriority = INFO or WARN or '
                   'CRITICAL or UNKNOWN')

    psr.add_option('-t', '--trapAction', action='store', type='string',
                   metavar='MODE', dest='trap_action',
                   default=(None, {'INLIST': ['ADD', 'MOD', 'DEL']}),
                   help='add a trap definition = ADD, modify a trap definition'
                   ' = MOD, delete a trap definition = DEL')
    psr.add_option('-b', '--trapMIB', action='store', type='string',
                   metavar='STRING', dest='trap_mib',
                   default=(None, 'NOTBLANK', {
                       'WHEN': {'trap_action!=': None},
                       'DO': ('REQUIRED')},
                       {'WHEN': {'pattern_action!=': None},
                        'DO': ('REQUIRED')}),
                   help='MIB')
    psr.add_option('-u', '--trapUEI', action='store', type='string',
                   metavar='STRING', dest='trap_uei',
                   default=(None, 'NOTBLANK'), help='trap name(uei)')
    psr.add_option('-v', '--trapVersion', action='store', type='string',
                   metavar='STRING', dest='trap_ver',
                   default=(None, {'INLIST': ['1', '2c/3']}),
                   help='trap version = 1 or 2c/3')
    psr.add_option('-i', '--trapOID',  action='store', type='string',
                   metavar='ID', dest='trap_oid',
                   default=(None, 'NOTBLANK', {
                       'WHEN': {'trap_action!=': None},
                       'DO': ('REQUIRED')},
                       {'WHEN': {'pattern_action!=': None},
                        'DO': ('REQUIRED')}),
                   help='OID')
    psr.add_option('-G', '--trapGenericID', action='store', type='int',
                   metavar='INT', dest='trap_generic_id',
                   default=(None, 'NOTBLANK'), help='generic ID')
    psr.add_option('-P', '--trapSpecificID', action='store', type='int',
                   metavar='INT', dest='trap_specific_id',
                   default=(None, 'NOTBLANK'), help='specific ID')
    psr.add_option('-M', '--trapMsg', action='store', type='string',
                   metavar='STRING', dest='trap_msg',
                   default=(None, 'NOTBLANK'), help='message')
    psr.add_option('-l', '--trapDetail', action='store', type='string',
                   metavar='STRING', dest='trap_detail',
                   default=(None, 'NOTBLANK'), help='detail')
    psr.add_option('-T', '--trapProcessType', action='store', type='string',
                   metavar='STRING', dest='trap_process_type',
                   default=(None, {'INLIST': ['ANY', 'MATCH']}),
                   help='processing type = ANY(notify regardless of the'
                   ' varbind) or MATCH(notify only if the varbind matched)')
    psr.add_option('-q', '--trapPriority', action='store', type='string',
                   metavar='STRING', dest='trap_priority_raw',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                       'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']}),
                   help='trapPriority = INFO or WARN or CRITICAL or UNKNOWN')
    psr.add_option('-f', '--varbindFormat', action='store', type='string',
                   metavar='STRING', dest='varbind_format',
                   default=(None, 'NOTBLANK'), help='varbind format')
    psr.add_option('-E', '--trapEnable', action='store', type='string',
                   metavar='BOOL', dest='trap_enable',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='enable=true, disable=false')

    psr.add_option('-p', '--patternAction', action='store', type='string',
                   metavar='MODE', dest='pattern_action',
                   default=(None, {'INLIST': ['ADD', 'MOD', 'DEL']}),
                   help='add a pattern = ADD, modify a pattern = MOD, '
                   'delete a pattern = DEL')
    psr.add_option('-z', '--patternNo', action='store', type='int',
                   metavar='INT', dest='pattern_n',
                   default=(None, {
                       'WHEN': [{'pattern_action': 'MOD'},
                                {'pattern_action': 'DEL'}],
                       'DO': ('REQUIRED')}),
                   help='pattern orderNo')
    psr.add_option('-y', '--patternNewNo', action='store', type='int',
                   metavar='INT', dest='pattern_n_new',
                   default=None, help='change pattern order to patternNewNo')
    psr.add_option('-W', '--varbindPattern', action='store', type='string',
                   metavar='STRING', dest='varbind_pattern',
                   default=(None, {
                       'WHEN': {'pattern_action': 'ADD'},
                       'DO': ('REQUIRED')}),
                   help='match pattern (RegEx)')
    psr.add_option('-X', '--varbindPatternDesc', action='store', type='string',
                   metavar='STRING', dest='varbind_pattern_desc',
                   default=None, help='description')
    psr.add_option('-Y', '--varbindPatternCaseSensitive', action='store',
                   type='string', metavar='BOOL',
                   dest='varbind_pattern_case_sensitive_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='varbindPatternCaseSensitive')
    psr.add_option('-Z', '--varbindPatternProcessType', action='store',
                   type='string', metavar='STRING',
                   dest='varbind_pattern_process_type_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='process when matching =true, or process when not'
                   ' matching =false')
    psr.add_option('-r', '--varbindPatternPriority', action='store',
                   type='string', metavar='STRING',
                   dest='varbind_pattern_priority',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                        'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']}),
                   help='varbindPatternPriority = INFO or WARN or CRITICAL'
                   ' or UNKNOWN')
    psr.add_option('-e', '--patternEnable', action='store', type='string',
                   metavar='BOOL', dest='pattern_enable_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='enable=true, disable=false')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ###  monitorInfo parameter ###
        monitor_info = endpoint.getMonitor(opts.monitor_id)

        # Modification
        with ObjectModifier(monitor_info) as modifier:
            modifier.set_if_first_not_none('application', opts.application)
            modifier.set_if_first_not_none('calendarId', opts.calendar_id)
            modifier.set_if_first_not_none('description', opts.description)
            modifier.set_if_first_not_none(
                'facilityId', opts.facility_id, scope=' ')
            modifier.set_if_first_not_none(
                'monitorFlg', opts.monitor)
            modifier.set_if_first_not_none(
                'collectorFlg', opts.collect)
            modifier.set_if_first_not_none('logFormatId', opts.logformat_id)

            modifier.change_ptr('trapCheckInfo')
            modifier.set_if_first_not_none(
                'charsetConvert', opts.check_charset_convert)
            modifier.set_if_first_not_none(
                'charsetName', opts.check_charset_name)
            modifier.set_if_first_not_none(
                'communityCheck', opts.check_community_check)
            modifier.set_if_first_not_none(
                'communityName', opts.check_community_name)
            modifier.set_if_first_not_none(
                'notifyofReceivingUnspecifiedFlg', opts.notify_unspecified)
            modifier.set_if_first_not_none(
                'priorityUnspecified', opts.notify_unspecified_priority)

            if opts.trap_action is not None:
                if 'trapValueInfos' not in monitor_info.trapCheckInfo:
                    setattr(monitor_info.trapCheckInfo, 'trapValueInfos', [])
                modifier.change_ptr('trapCheckInfo.trapValueInfos')

                trap_process_type = None
                if opts.trap_process_type == 'ANY':
                    trap_process_type = 0
                elif opts.trap_process_type == 'MATCH':
                    trap_process_type = 1

                if opts.trap_action == 'ADD':
                    var_bind_patterns = []
                    if opts.varbind_pattern is not None:
                        var_bind_patterns.append(endpoint.create_var_bind_pattern(
                            opts.varbind_pattern,
                            opts.varbind_pattern_desc,
                            opts.varbind_pattern_case_sensitive,
                            opts.varbind_pattern_process_type,
                            opts.varbind_pattern_priority_converted,
                            opts.pattern_enable))
                    monitor_info.trapCheckInfo.trapValueInfos.append(endpoint.create_trap_value_info(
                        opts.trap_mib,
                        opts.trap_uei,
                        opts.trap_oid,
                        opts.trap_msg,
                        opts.trap_detail,
                        opts.trap_ver,
                        opts.trap_generic_id,
                        opts.trap_specific_id,
                        trap_process_type,
                        opts.trap_priority,
                        opts.varbind_format,
                        var_bind_patterns,
                        opts.trap_enable_converted))

                elif opts.trap_action == 'MOD':
                    if opts.trap_generic_id is None:
                        opts.trap_generic_id = 0
                    if opts.trap_specific_id is None:
                        opts.trap_specific_id = 0

                    trap_process_type = None
                    if opts.trap_process_type == 'ANY':
                        trap_process_type = 0
                    elif opts.trap_process_type == 'MATCH':
                        trap_process_type = 1

                    modifier.replace_if_not_none(modifier.select(mib=opts.trap_mib, trapOid=opts.trap_oid, genericId=opts.trap_generic_id, specificId=opts.trap_specific_id),\
                                                 #mib = opts.trap_mib,\
                                                 #trapOid = opts.trap_oid,\
                                                 #genericId = opts.trap_generic_id,\
                                                 #specificId = opts.trap_specific_id,\
                                                 uei=opts.trap_uei,\
                                                 logmsg=opts.trap_msg,\
                                                 description=opts.trap_detail,\
                                                 version=opts.trap_ver,\
                                                 processingVarbindType=trap_process_type,\
                                                 priorityAnyVarbind=opts.trap_priority,\
                                                 formatVarBinds=opts.varbind_format,\
                                                 #varBindPattern = var_bind_patterns,\
                                                 validFlg=opts.trap_enable_converted)

                elif opts.trap_action == 'DEL':
                    if opts.trap_generic_id is None:
                        opts.trap_generic_id = 0
                    if opts.trap_specific_id is None:
                        opts.trap_specific_id = 0
                    modifier.remove(mib=opts.trap_mib, trapOid=opts.trap_oid,
                                    genericId=opts.trap_generic_id, specificId=opts.trap_specific_id)

            if opts.pattern_action is not None:
                if 'trapValueInfos' not in monitor_info:
                    setattr(monitor_info.trapCheckInfo, 'trapValueInfos', [])

                modifier.change_ptr('trapCheckInfo.trapValueInfos')
                if opts.trap_generic_id is None:
                    opts.trap_generic_id = 0
                if opts.trap_specific_id is None:
                    opts.trap_specific_id = 0

                trap_value_info = modifier.select(
                    mib=opts.trap_mib, trapOid=opts.trap_oid, genericId=opts.trap_generic_id, specificId=opts.trap_specific_id)
                if opts.pattern_action == 'ADD':
                    if not hasattr(trap_value_info, 'varBindPatterns'):
                        setattr(trap_value_info, 'varBindPatterns', [])

                    pattern = endpoint.create_var_bind_pattern(
                        opts.varbind_pattern,
                        opts.varbind_pattern_desc,
                        opts.varbind_pattern_case_sensitive,
                        opts.varbind_pattern_process_type,
                        opts.varbind_pattern_priority_converted,
                        opts.pattern_enable)
                    if opts.pattern_n is None:
                        trap_value_info.varBindPatterns.append(pattern)
                    else:
                        trap_value_info.varBindPatterns.insert(
                            opts.pattern_n - 1, pattern)
                elif opts.pattern_action == 'MOD':
                    if not hasattr(trap_value_info, 'varBindPatterns') or opts.pattern_n < 1 or opts.pattern_n > len(trap_value_info.varBindPatterns):
                        raise ObjectNotFoundError(
                            'Pattern(no=%d) does not exist!' % opts.pattern_n)
                    else:
                        pattern_info = trap_value_info.varBindPatterns[opts.pattern_n - 1]
                        ObjectModifier.replace_if_not_none(pattern_info,
                                                           pattern=opts.varbind_pattern,
                                                           description=opts.varbind_pattern_desc,
                                                           caseSensitivityFlg=opts.varbind_pattern_case_sensitive,
                                                           processType=opts.varbind_pattern_process_type,
                                                           priority=opts.varbind_pattern_priority_converted,
                                                           validFlg=opts.pattern_enable)
                        # Change order
                        if opts.pattern_n_new is not None:
                            trap_value_info.varBindPatterns.insert(
                                opts.pattern_n_new - 1, trap_value_info.varBindPatterns.pop(opts.pattern_n - 1))

                elif opts.pattern_action == 'DEL':
                    if opts.pattern_n < 1 or opts.pattern_n > len(trap_value_info.varBindPatterns):
                        raise ObjectNotFoundError(
                            'Pattern(no=%d) does not exist!' % opts.pattern_n)
                    else:
                        del trap_value_info.varBindPatterns[opts.pattern_n - 1]

        # Notify
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)
        if opts.add_notify_ids_converted is not None:
            if not hasattr(monitor_info, 'notifyRelationList'):
                setattr(monitor_info, 'notifyRelationList', [])

            # Check if notification already exists
            ids = set(opts.add_notify_ids_converted)
            existed_ids = tuple(
                [x.notifyId for x in monitor_info.notifyRelationList])

            # Then add
            for x in filter((lambda x: x not in existed_ids), ids):
                monitor_info.notifyRelationList.append(
                    endpoint.create_notify_relation_info(notify_endpoint.getNotify(x),
                                                         monitor_info.monitorTypeId, monitor_info.monitorId))

        if opts.del_notify_ids_converted is not None and hasattr(monitor_info, 'notifyRelationList') and 0 < len(monitor_info.notifyRelationList):
            ids = set(opts.del_notify_ids_converted)
            for i in reversed(xrange(len(monitor_info.notifyRelationList))):
                if monitor_info.notifyRelationList[i].notifyId in ids:
                    del monitor_info.notifyRelationList[i]

        endpoint.modifyMonitor(monitor_info)
        return_code = ResultPrinter.success(
            None, opts.mgr_url, 'modifyMonitor')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
