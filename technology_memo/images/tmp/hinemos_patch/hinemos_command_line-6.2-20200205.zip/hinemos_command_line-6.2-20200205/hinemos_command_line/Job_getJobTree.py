#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブツリー情報を取得する

<概要>
ジョブツリー情報を取得して表示します。

<使用例>
[command]
    $ python Job_getJobTree.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    (jobTreeItem){
       children[] =
          (jobTreeItem){
             children[] =
                (jobTreeItem){
                   children[] =
                      (jobTreeItem){
                         data =
                            (jobInfo){
                               abnormalPriority = 0
                               approvalReqMailBody = None
                               approvalReqMailTitle = None
                               approvalReqRoleId = None
                               approvalReqSentence = None
                               approvalReqUserId = None
                               beginPriority = 0
                               description = None
                               id = "APJOB01"
                               jobunitId = "JU01"
                               name = "APJOB01"
                               normalPriority = 0
                               ownerRoleId = None
                               propertyFull = False
                               referJobSelectType = 0
                               registeredModule = False
                               type = 8
                               useApprovalReqSentence = False
                               warnPriority = 0
                            }
                      },
        ...中略...
       data =
          (jobInfo){
             abnormalPriority = 0
             approvalReqMailBody = None
             approvalReqMailTitle = None
             approvalReqRoleId = None
             approvalReqSentence = None
             approvalReqUserId = None
             beginPriority = 0
             description = None
             id = None
             jobunitId = None
             name = None
             normalPriority = 0
             ownerRoleId = None
             propertyFull = False
             referJobSelectType = 0
             registeredModule = False
             type = -1
             useApprovalReqSentence = False
             warnPriority = 0
          }
     }
    http://192.168.1.2:8080/HinemosWS/, getJobTree succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-T', '--treeOnly', action='store', type='string', metavar='BOOL', dest='tree_only_raw',converter=SettingUtil.convert2nbool,
                    default=('true', {'INLIST':['true','false']}), help='treeOnly')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=None, help='ownerRoleID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit ###
        result = endpoint.getJobTree(opts.owner_role_id, opts.tree_only)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getJobTree')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
