#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定されたコマンドNoのコマンドを指定されたイベント情報に対して実行する

<概要>
引数で指定されたコマンドNoのコマンドを指定されたイベント情報に対して実行します。

<使用例>
[command]
    $ python Monitor_execEventCustomCommand.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -I 1 -M SYS
    -P MNG -F INTERNAL -D "2019/04/22 11:36:20.510"

[result]
    1b4620a4-f90f-4c51-8175-84e66259741f

    http://127.0.0.1:8080/HinemosWS/, execEventCustomCommand succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.monitor import MonitorEndpoint
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.modifier import ObjectModifier


def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--commandNo',  action='store', type='string', metavar='ID', dest='command_no',
                   default=(None, 'REQUIRED', 'INTEGER'), help='Custom Command Number')
    psr.add_option('-M', '--monitorID',  action='store', type='string', metavar='ID', dest='monitor_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Monitor ID')
    psr.add_option('-m', '--monitorDetailID',  action='store', type='string', metavar='ID', dest='monitor_detail_id',
                   default='', help='Monitor Detail ID')
    psr.add_option('-P', '--pluginID',  action='store', type='string', metavar='ID', dest='plugin_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Plugin ID')
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Facility ID')
    psr.add_option('-D', '--outputDate',  action='store', type='string', metavar='STRING',
                   converter=DateConvert.get_epochtime_from_datetime, dest='output_date_raw',
                   default=(None, 'REQUIRED', {'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d.\d\d\d$',
                                                          ' must be in [yyyy/mm/dd HH:MM:SS.sss] format']}),
                   help='Output Date [yyyy/mm/dd HH:MM:SS.sss]')

    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = MonitorEndpoint(opts.mgr_url, opts.user, opts.passwd)

        event_data_info = endpoint.create_object('eventDataInfo')
        ObjectModifier.replace_if_not_none(
            event_data_info,
            monitorId=opts.monitor_id,
            monitorDetailId=opts.monitor_detail_id,
            pluginId=opts.plugin_id,
            facilityId=opts.facility_id,
            outputDate=opts.output_date)

        result = endpoint.execEventCustomCommand(opts.command_no, event_data_info)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'execEventCustomCommand')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
