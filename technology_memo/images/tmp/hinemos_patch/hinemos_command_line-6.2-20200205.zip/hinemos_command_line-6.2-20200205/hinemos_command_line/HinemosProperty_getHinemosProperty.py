#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
Hinemosプロパティの情報を取得する

<概要>
Hinemosプロパティの情報を取得して表示します。

<使用例>
[command]
    $ python HinemosProperty_getHinemosProperty.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -K infra.transfer.winrm.url

[result]
    (hinemosPropertyInfo){
       createDatetime = "2017/02/09 15:10:33.584"
       createUserId = "hinemos"
       description = "Hinemos Manager URL for Infra File Transfer Module (WinRM)"
       key = "infra.transfer.winrm.url"
       modifyDatetime = "2017/02/09 15:10:33.584"
       modifyUserId = "hinemos"
       ownerRoleId = "ADMINISTRATORS"
       valueString = "http://hinemos_manager_60:8080/"
       valueType = 1
     }
    http://192.168.1.2:8080/HinemosWS/, getHinemosProperty succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter, DateConvert
from hinemos.util.opt import MyOptionParser

import hinemos.api.exceptions as ErrorHandler
from hinemos.api.hinemosproperty import HinemosPropertyEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-K', '--key', action='store', type='string', metavar='STRING', dest='key',
                    default=(None, 'REQUIRED','NOTBLANK'), help='property key')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        endpoint = HinemosPropertyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getHinemosProperty(opts.key)
        if result is not None:
            result.createDatetime = DateConvert.get_datetime_from_epochtime(result.createDatetime)
            result.modifyDatetime = DateConvert.get_datetime_from_epochtime(result.modifyDatetime)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getHinemosProperty')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
