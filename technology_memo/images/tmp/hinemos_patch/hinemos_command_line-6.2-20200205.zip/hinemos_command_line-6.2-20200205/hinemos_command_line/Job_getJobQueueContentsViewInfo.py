#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブキュー(同時実行制御キュー)の内部状況を表示するビューのための情報を返す

<概要>
ジョブキュー(同時実行制御キュー)の内部状況を表示するビューのための情報を返します。

<使用例>
[command]
    $ python Job_getJobQueueContentsViewInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -I TESTQ01

[result]
    (jobQueueContentsViewInfo){
       activeCount = 1
       concurrency = 4
       count = 1
       items[] =
          (jobQueueContentsViewInfoListItem){
             jobTreeItem =
                (jobTreeItem){
                   data =
                      (jobInfo){
                         abnormalPriority = 0
                         approvalReqMailBody = None
                         approvalReqMailTitle = None
                         approvalReqRoleId = None
                         approvalReqSentence = None
                         approvalReqUserId = None
                         beginPriority = 0
                         description = "Test Job with Queue"
                         id = "CMD_JOB"
                         jobunitId = "TEST"
                         name = "CMD_JOB"
                         normalPriority = 0
                         ownerRoleId = None
                         propertyFull = False
                         referJobSelectType = 0
                         registeredModule = False
                         type = 2
                         useApprovalReqSentence = False
                         waitRule =
                            (jobWaitRuleInfo){
                               calendar = False
                               calendarEndStatus = 2
                               calendarEndValue = 0
                               condition = 0
                               endCondition = True
                               endStatus = 2
                               endValue = -1
                               end_delay = False
                               end_delay_change_mount = False
                               end_delay_change_mount_value = 1.0
                               end_delay_condition_type = 0
                               end_delay_job = False
                               end_delay_job_value = 1
                               end_delay_notify = False
                               end_delay_notify_priority = 0
                               end_delay_operation = False
                               end_delay_operation_end_status = 2
                               end_delay_operation_end_value = -1
                               end_delay_operation_type = 0
                               end_delay_session = False
                               end_delay_session_value = 1
                               end_delay_time = False
                               exclusiveBranch = False
                               exclusiveBranchEndStatus = 0
                               exclusiveBranchEndValue = 0
                               jobRetry = 10
                               jobRetryFlg = False
                               multiplicityEndValue = -1
                               multiplicityNotify = True
                               multiplicityNotifyPriority = 2
                               multiplicityOperation = 0
                               queueFlg = True
                               queueId = "TESTQ01"
                               skip = False
                               skipEndStatus = 2
                               skipEndValue = 0
                               start_delay = False
                               start_delay_condition_type = 0
                               start_delay_notify = False
                               start_delay_notify_priority = 0
                               start_delay_operation = False
                               start_delay_operation_end_status = 2
                               start_delay_operation_end_value = -1
                               start_delay_operation_type = 0
                               start_delay_session = False
                               start_delay_session_value = 1
                               start_delay_time = False
                               start_delay_time_value = "09:00:00"
                               suspend = False
                            }
                         warnPriority = 0
                      }
                   detail =
                      (jobDetailInfo){
                         facilityId = "LINUX"
                         runCount = 1
                         scope = "$[OS_SCOPE]>Linux>"
                         startDate = "2019/03/29 16:32:38.078"
                         status = 100
                      }
                }
             regDate = "2019/03/29 16:32:38.063"
             sessionId = "20190329163238-000"
          },
       queueId = "TESTQ01"
       queueName = "TestQueue"
     }

    http://127.0.0.1:8080/HinemosWS/, getJobQueueContentsViewInfo succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
from hinemos.api.job import JobEndpoint
from hinemos.util.repository import FacilityTree


def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--queueId', action='store', type='string', metavar='ID', dest='queue_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Job Queue ID')
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)
        result = endpoint.getJobQueueContentsViewInfo(opts.queue_id)

        if result is not None and hasattr(result, 'items'):
            for item in result.items:
                if 'regDate' in item:
                    item.regDate = DateConvert.get_datetime_from_epochtime(item.regDate)
                if 'jobTreeItem' in item:
                    FacilityTree.convert_datetime(item.jobTreeItem)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getJobQueueContentsViewInfo')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
