#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブキュー(同時実行制御キュー)の設定を削除する

<概要>
ジョブキュー(同時実行制御キュー)の設定を削除します。

<使用例>
[command]
    $ python Job_deleteJobQueue.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -I TESTQ01

[result]
    http://127.0.0.1:8080/HinemosWS/, deleteJobQueue succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.job import JobEndpoint
from hinemos.util.common import ResultPrinter


def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--queueId',  action='store', type='string', metavar='ID', dest='queue_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Job Queue ID')
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)
        endpoint.deleteJobQueue(opts.queue_id)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'deleteJobQueue')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
