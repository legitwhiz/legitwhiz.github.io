#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
アクセス情報を作成する

<概要>
アクセス情報を作成します。

<使用例>
[command]
    $ python Infra_createAccessInfoListForDialog.py
[result]
    http://192.168.1.2:8080/HinemosWS/, createAccessInfoListForDialog succeeded.
"""

import sys
import codecs
import locale
import os
import base64
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.infra import InfraEndpoint


def parse_args(args):
    psr = MyOptionParser()
    psr.add_option('-I', '--managementID',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='managementId',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='infra management ID')
    psr.add_option('-M', '--moduleIdList',
                   action='store_split',
                   type='string',
                   metavar='STRING',
                   dest='moduleIdList',
                   default=None,
                   help='module id list: "id1,id2,...,idn"')
    return psr.parse_opts(args)


def main():
    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    ### login ###
    endpoint = InfraEndpoint(opts.mgr_url, opts.user, opts.passwd)
    if opts.moduleIdList is None:
        opts.moduleIdList = []
    try:
        res = endpoint.call('createAccessInfoListForDialog',
                            opts.managementId, opts.moduleIdList)
        return_code = ResultPrinter.success(
            res, opts.mgr_url, 'createAccessInfoListForDialog')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    # sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    # sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
