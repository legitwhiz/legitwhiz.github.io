#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
フィルタ処理した、ジョブスケジュール予定の一覧情報を取得する

<概要>
フィルタ処理した、ジョブスケジュール予定の一覧情報を取得して表示します。

<使用例>
[command]
    $ python Job_getPlanList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -K TEST_SC -P 3

[result]
    [(jobPlan){
       date = "2017/03/07 14:00:00"
       jobId = "JOB01"
       jobKickId = "TEST_SC"
       jobKickName = "TEST_SC"
       jobName = "JOB01"
       jobunitId = "JU01"
     }, (jobPlan){
       date = "2017/03/07 15:00:00"
       jobId = "JOB01"
       jobKickId = "TEST_SC"
       jobKickName = "TEST_SC"
       jobName = "JOB01"
       jobunitId = "JU01"
     }, (jobPlan){
       date = "2017/03/07 16:00:00"
       jobId = "JOB01"
       jobKickId = "TEST_SC"
       jobKickName = "TEST_SC"
       jobName = "JOB01"
       jobunitId = "JU01"
     }]
    http://192.168.1.2:8080/HinemosWS/, getPlanList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-K', '--jobKickID',  action='store', type='string', metavar='ID', dest='job_kick_id',
                    default=(None, 'NOTBLANK'), help='jobkick ID')
    psr.add_option('-F', '--fromDate', action='store', type='string', metavar='STRING', dest='from_date',
                    default=(None, {'REGEXP':[r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}), help='from Date: \'yyyy/mm/dd HH:MM:SS\'')
    psr.add_option('-T', '--toDate', action='store', type='string', metavar='STRING', dest='to_date',
                    default=(None, {'REGEXP':[r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}), help='toDate: \'yyyy/mm/dd HH:MM:SS\'')
    psr.add_option('-P', '--plans', action='store', type='int', metavar='INT', dest='plans',
                    default=(100), help='input a number')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        if opts.from_date != '':
            opts.from_date = DateConvert.get_epochtime_from_datetime(opts.from_date)
        if opts.to_date != '':
            opts.to_date = DateConvert.get_epochtime_from_datetime(opts.to_date)
        jobPlanFilter = endpoint.create_job_plan_filter(opts.job_kick_id, opts.from_date, opts.to_date)

        result = endpoint.getPlanList(jobPlanFilter, opts.plans)
        if result is not None:
            for a in result:
                a.date = DateConvert.get_datetime_from_epochtime(a.date)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getPlanList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
