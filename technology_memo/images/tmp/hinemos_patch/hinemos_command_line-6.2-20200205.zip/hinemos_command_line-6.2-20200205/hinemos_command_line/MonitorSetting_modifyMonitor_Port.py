#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
サービス・ポート監視の監視設定情報を変更する

<概要>
サービス・ポート監視の監視設定情報を変更します。

<使用例>
[command]
    $ python MonitorSetting_modifyMonitor_Port.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I PORT1 -A MYAPP -F SCOPE001 -o 1235

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.util.notify import NotifyUtil
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.monitorsetting import MonitorSettingUtil
from hinemos.util.modifier import ObjectModifier
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_modify_args_parser(help_default_info)
    psr.add_option('-S', '--checkServiceName', action='store', type='string',
                   metavar='STRING', dest='check_service_name',
                   default=(None, 'NOTBLANK', {
                            'INLIST': MonitorSettingUtil._port_protocol_type_.keys()}),
                   help='service = ' + ' or '.join(sorted(MonitorSettingUtil._port_protocol_type_.keys())))
    psr.add_option('-o', '--checkPort', action='store', type='int',
                   metavar='INT', dest='check_port', default=None, help='port')
    psr.add_option('-t', '--checkRunCount', action='store', type='int',
                   metavar='INT', dest='check_run_count',
                   default=(None, {'RANGE': [1, 9]}), help='run count = 1 to 9')
    psr.add_option('-r', '--checkRunInterval', action='store', type='string',
                   metavar='STRING', dest='check_run_interval',
                   default=None, help='run interval = 1 to 5000 [msec]')
    psr.add_option('-O', '--checkTimeout', action='store', type='int',
                   metavar='INT', dest='check_timeout', default=None,
                   help='timeout')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)


    ### execute ###
    return_code = -1

    try:
        # login
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Get monitorInfo
        monitor_info = endpoint.getMonitor(opts.monitor_id)

        # Modification
        with ObjectModifier(monitor_info) as modifier:
            endpoint.update_common_infos(modifier, vars(opts))
            endpoint.update_collect_infos(modifier, vars(opts))
            endpoint.update_prediction_info(modifier, vars(opts))
            endpoint.update_change_info(modifier, vars(opts))
            endpoint.updete_judgement_tresholds(modifier, vars(opts))

            modifier.change_ptr('portCheckInfo')
            modifier.set_if_first_not_none('portNo', opts.check_port)
            modifier.set_if_first_not_none('runCount', opts.check_run_count)
            modifier.set_if_first_not_none(
                'runInterval', opts.check_run_interval)
            if opts.check_service_name is not None:
                modifier.set_if_first_not_none(
                    'serviceId', MonitorSettingUtil.convert2port_protocol_code(opts.check_service_name))
            modifier.set_if_first_not_none('timeout', opts.check_timeout)

        endpoint.update_notify_ids_info(monitor_info, vars(opts))

        endpoint.modifyMonitor(monitor_info)
        return_code = ResultPrinter.success(
            None, opts.mgr_url, 'modifyMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
