#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
SQL監視(数値)の監視設定を登録する

<概要>
SQL監視(数値)の監視設定を登録します。

<使用例>
[command]
    $ python MonitorSetting_addMonitor_SqlI.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I SQLI1 -A MYAPP -F SCOPE001 -O jdbc:sqlserver -V user1 -W pass1 -Q "SELECT 1;" -J MySQL

[result]
    http://192.168.1.2:8080/HinemosWS/, addMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_add_args_parser(help_default_info)
    psr.add_option('-O', '--checkConnectionURL', action='store', type='string',
                   metavar='STRING', dest='check_connection_url',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='connection URL')
    psr.add_option('-J', '--checkJDBCDriver', action='store', type='string',
                   metavar='STRING', dest='check_jdbc_driver',
                   default=('PostgreSQL', {'INLIST': [
                            'PostgreSQL', 'MySQL', 'Oracle']}),
                   help='JDBC driver = PostgreSQL or MySQL or Oracle (default: PostgreSQL)')
    psr.add_option('-V', '--checkUser', action='store', type='string',
                   metavar='STRING', dest='check_user',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='user')
    psr.add_option('-W', '--checkPassword', action='store', type='string',
                   metavar='STRING', dest='check_password',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='password')
    psr.add_option('-Q', '--checkQuery', action='store', type='string',
                   metavar='STRING', dest='check_query',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='query')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)
        endpoint.add_monitor_sql_n(vars(opts))

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
