#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
SQL監視(数値)の監視設定情報を変更する

<概要>
SQL監視(数値)の監視設定情報を変更します。

<使用例>
[command]
    $ python MonitorSetting_modifyMonitor_SqlI.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I SQLI1 -A MYAPP -F SCOPE001 -O jdbc:sqlserver -V user2 -W pass1 -Q "SELECT 2;" -J MySQL

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.modifier import ObjectModifier
from hinemos.util.notify import NotifyUtil


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_modify_args_parser(help_default_info)
    psr.add_option('-O', '--checkConnectionURL', action='store', type='string',
                   metavar='STRING', dest='check_connection_url',
                   default=(None, 'NOTBLANK'), help='connection URL')
    psr.add_option('-J', '--checkJDBCDriver', action='store', type='string',
                   metavar='STRING', dest='check_jdbc_driver',
                   default=('PostgreSQL', {'INLIST': [
                            'PostgreSQL', 'MySQL', 'Oracle']}),
                   help='JDBC driver = PostgreSQL or MySQL or Oracle (default: PostgreSQL)')
    psr.add_option('-V', '--checkUser', action='store', type='string',
                   metavar='STRING', dest='check_user',
                   default=(None, 'NOTBLANK'), help='user')
    psr.add_option('-W', '--checkPassword', action='store', type='string',
                   metavar='STRING', dest='check_password',
                   default=(None, 'NOTBLANK'), help='password')
    psr.add_option('-Q', '--checkQuery', action='store', type='string',
                   metavar='STRING', dest='check_query',
                   default=(None, 'NOTBLANK'), help='query')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # login
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Get monitorInfo
        monitor_info = endpoint.getMonitor(opts.monitor_id)

        # Get jdbc_driver
        if opts.check_jdbc_driver is not None:
            jdbc_driver_list = endpoint.getJdbcDriverList()
            for i in jdbc_driver_list:
                if i.jdbcDriverName == opts.check_jdbc_driver:
                    check_jdbc_driver = i.jdbcDriverClass
        else:
            check_jdbc_driver = None

        # Modification
        with ObjectModifier(monitor_info) as modifier:
            endpoint.update_common_infos(modifier, vars(opts))
            endpoint.update_collect_infos(modifier, vars(opts))
            endpoint.update_prediction_info(modifier, vars(opts))
            endpoint.update_change_info(modifier, vars(opts))
            endpoint.updete_judgement_tresholds(modifier, vars(opts))

            modifier.change_ptr('sqlCheckInfo')
            modifier.set_if_first_not_none(
                'connectionUrl', opts.check_connection_url)
            modifier.set_if_first_not_none('jdbcDriver', check_jdbc_driver)
            modifier.set_if_first_not_none('user', opts.check_user)
            modifier.set_if_first_not_none('password', opts.check_password)
            modifier.set_if_first_not_none('query', opts.check_query)

        endpoint.update_notify_ids_info(monitor_info, vars(opts))

        endpoint.modifyMonitor(monitor_info)
        return_code = ResultPrinter.success(
            None, opts.mgr_url, 'modifyMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
