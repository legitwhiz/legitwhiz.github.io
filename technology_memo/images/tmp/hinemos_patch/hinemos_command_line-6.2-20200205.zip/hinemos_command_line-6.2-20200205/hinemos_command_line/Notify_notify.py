#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
直接通知処理を実行する

<概要>
直接通知処理を実行します。

<使用例>
[command]
    $ python Notify_notify.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -P MON_PNG -M TEST_PNG2 -F TEST_NODE -S TEST_SUBKEY -G "2017/3/6 10:30:00" -p 2 -A test-API -I 0 -m notify_API_TEST_MESSAGE_2 -O notify_API_TEST_MESSAGEORG2 -N TEST_EVENT -s 002

[result]
    http://192.168.1.2:8080/HinemosWS/, notify is succeeded.
"""

### import ###
import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.notify import NotifyUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-P', '--pluginID',  action='store', type='string', metavar='ID', dest='plugin_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='pluginID')
    psr.add_option('-M', '--monitorID',  action='store', type='string', metavar='ID', dest='monitor_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='monitorID')
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='facilityID')
    psr.add_option('-S', '--subKey', action='store', type='string', metavar='STRING', dest='sub_key',
                    default=(None, 'REQUIRED'), help='subKey')
    psr.add_option('-G', '--generationDate', action='store', type='string', metavar='STRING', dest='generation_date',
                    default=(None, 'REQUIRED','NOTBLANK'), help='generationDate')
    psr.add_option('-p', '--priority', action='store', type='string', metavar='STRING', dest='priority',converter=NotifyUtil.convert2priority,
                    default=('UNKNOWN', 'REQUIRED', {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN']}), help='priority = INFO or WARN or CRITICAL or UNKNOWN')
    psr.add_option('-A', '--application', action='store', type='string', metavar='STRING', dest='application',
                    default=(None, 'REQUIRED','NOTBLANK'), help='application')
    psr.add_option('-I', '--messageID',  action='store', type='string', metavar='ID', dest='message_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='messageID')
    psr.add_option('-m', '--message', action='store', type='string', metavar='STRING', dest='message',
                    default=(None, 'REQUIRED','NOTBLANK'), help='message')
    psr.add_option('-O', '--messageOrg', action='store', type='string', metavar='STRING', dest='message_org',
                    default=(None, 'REQUIRED','NOTBLANK'), help='original message')
    psr.add_option('-N', '--notifyIDs', action='store_split', type='string', metavar='STRING', dest='notify_ids_raw',
                    default=(None, 'REQUIRED','NOTBLANK'), help='notifyID = ID1,ID2,..,IDN')
    psr.add_option('-s', '--srcID',  action='store', type='string', metavar='ID', dest='src_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='source ID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        notifyIdList = opts.notify_ids[:]
        opts.generation_date = DateConvert.get_epochtime_from_datetime(opts.generation_date)

        priority = None if opts.priority is None else NotifyUtil.convert2priority(opts.priority)
        endpoint.notify(opts.plugin_id, opts.monitor_id, opts.facility_id, opts.sub_key, opts.generation_date, priority, opts.application, opts.message, opts.message_org, notifyIdList, opts.src_id)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'notify')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
