#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation

u"""
ノードの情報を変更する

<概要>
ノードの情報を変更します。

<使用例>
- 名前(-N)、説明(-D)とノート(-n)を変更し、管理対象(-e)と自動デバイスサーチ(-a)を無効にします。
[command]
    $ python Repository_modifyNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE -N "OLD Server(Stopped)" -D "Stopped." -e false -a false -n "Already replaced by B server."

[result]
    ... 中略 ...
    http://192.168.1.2:8080/HinemosWS/, modifyNode succeeded.


- サーバ基本情報(ハードウェア(Hardware)、ネットワーク(Network)、 OS(OS)とHinemosエージェント(HinemosAgent)を変更します(-b)。
[command]
    $ python Repository_modifyNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE -b '{
        "Hardware":{
            "platformFamily":"WINDOWS",
            "subPlatformFamily":"",
            "hardwareType":"Unknown",
            "iconImage":"/tmp/test.png"},
        "Network":{
            "ipAddressVersion":4,
            "ipAddressV4":"192.168.1.1",
            "ipAddressV6":":::",
            "nodeName":"node-1",
            "hostname":"node-1"},
        "OS":{
            "osName":"Windows",
            "osRelease":"7",
            "osVersion":"7.20",
            "characterSet":"UTF-8"},
        "HinemosAgent":{"agentAwakePort":24321}}
[result]
    ... 中略 ...
    http://192.168.1.2:8080/HinemosWS/, modifyNode succeeded.


- 上記では、JSON形式のオプションをわかりやすく表現するために、オプション内容に改行とインデントを追加して整形します。
  実際の場合は、すべて1行に集約した形で実行しても問題ありません。 例えば、

[command]
    $ python Repository_modifyNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE -b '{"Hardware":{...略...},"HinemosAgent":{"agentAwakePort":24321}}'

- なお、ここの例ではすべての項目を網羅していますが、実際に使用する場合、変更しない項目は省略可能です。 例えば、

[command]
    $ python Repository_modifyNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE -b '{"Hardware":{"platformFamily":"LINUX"}, "OS":{"osName":"Red Hat Enterprise Linux"}}'


この二点については、以下の例でも同様です。

- ジョブ関連情報を変更します(-j)。
[command]
    $ python Repository_modifyNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE -j '{"jobPriority":10, "jobMultiplicity": 10}'

[result]
    ... 中略 ...
    http://192.168.1.2:8080/HinemosWS/, modifyNode succeeded.


- サービス関連情報を変更します(-s)。
[command]
    $ python Repository_modifyNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE -s '{
        "SNMP":{
            "snmpUser":"user1",
            "snmpPort":161,
            "snmpCommunity":"public",
            "snmpVersion":"2c",
            "snmpSecurityLevel":"auth_priv",
            "snmpAuthPassword":"pass1",
            "snmpPrivPassword":"pass2",
            "snmpAuthProtocol":"SHA",
            "snmpPrivProtocol":"AES",
            "snmpTimeout":1000,
            "snmpRetryCount":3},
        "WBEM":{
            "wbemUser":"user1",
            "wbemUserPassword":"pass2",
            "wbemPort":5988,
            "wbemProtocol":"https",
            "wbemTimeout":1000,
            "wbemRetryCount":3},
        "IPMI":{
            "ipmiIpAddress":"192.168.2.2",
            "ipmiPort":623,
            "ipmiUser":"user1",
            "ipmiUserPassword":"pass3",
            "ipmiTimeout":1000,
            "ipmiRetries":3,
            "ipmiProtocol":"RMCP+",
            "ipmiLevel":""},
        "WinRM":{
            "winrmUser":"winrmUser",
            "winrmUserPassword":"winrmPass",
            "winrmVersion":"9.0",
            "winrmPort":5985,
            "winrmProtocol":"https",
            "winrmTimeout":1000,
            "winrmRetries":3},
        "SSH":{
            "sshUser":"user1",
            "sshUserPassword":"",
            "sshPrivateKeyFilepath":"/__PATH__/user1.key",
            "sshPrivateKeyPassphrase":"HELLO",
            "sshPort":22,
            "sshTimeout":1000}}'
[result]
    ... 中略 ...
    http://192.168.1.2:8080/HinemosWS/, modifyNode succeeded.


- デバイス関連情報(-c)を変更します。
[command]
    $ python Repository_modifyNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE -c '{
        "CPU":[
            {"deviceDisplayName":"cpu0", "deviceName":"cpu0", "deviceIndex":1,
            "deviceSize":500, "deviceSizeUnit":"GB", "deviceDescription":"Added manually"},
            {"deviceDisplayName":"cpu1", "deviceName":"cpu1", "deviceIndex":2,
            "deviceSize":1, "deviceSizeUnit":"TB", "deviceDescription":"Added manually"}
        ],
        "Memory":[
            {"deviceDisplayName":"mem0", "deviceName":"mem0", "deviceIndex":1,
            "deviceSize":993, "deviceSizeUnit":"MB", "deviceDescription":"Added manually"}
        ],
        "NIC":[
            {"deviceDisplayName":"eth0", "deviceName":"eth0", "deviceIndex":1,
            "deviceDescription":"Added manually",
            "nicIpAddress":"192.168.0.3", "nicMacAddress":"00:11:22:AA:BB:CE"}
        ],
        "Disk":[
            {"deviceDisplayName":"sda", "deviceName":"sda", "deviceIndex":1,
            "deviceSize":600, "deviceSizeUnit":"GB", "deviceDescription":"Added manually",
            "diskRpm":7200}
        ],
        "Filesystem":[
            {"deviceDisplayName":"/", "deviceName":"/", "deviceIndex":1,
            "deviceSize":500, "deviceSizeUnit":"GB", "deviceDescription":"Added manually",
            "filesystemType":"ext4"},
            {"deviceDisplayName":"/tmp", "deviceName":"/tmp", "deviceIndex":2,
            "deviceSize":100, "deviceSizeUnit":"GB", "deviceDescription":"Added manually",
            "filesystemType":"ext3"}
        ],
        "Generic":[
            {"deviceDisplayName":"st0", "deviceName":"st0", "deviceIndex":1, "deviceType":"Tape",
            "deviceSize":400, "deviceSizeUnit":"GB", "deviceDescription":"Added manually"},
            {"deviceDisplayName":"fd0", "deviceName":"fd0", "deviceIndex":2, "deviceType":"Floppy",
            "deviceSize":1.44, "deviceSizeUnit":"MB", "deviceDescription":"Added manually"}
        ]}'

[result]
    ... 中略 ...
    http://192.168.1.2:8080/HinemosWS/, modifyNode succeeded.


- デバイス関連情報を削除します(-C)。
[command]
    $ python Repository_modifyNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE -C '{"CPU":"*", "Disk":[1]}'

[result]
    ... 中略 ...
    http://192.168.1.2:8080/HinemosWS/, modifyNode succeeded.

※ "*" を指定すると、すべてのデバイスが削除されます。
※ [N] を指定すると、N番目のデバイスが削除されます。


- クラウド仮想化関連情報を変更します(-x)。
[command]
    $ python Repository_modifyNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE -x '{
        "cloudService":"AWS",
        "cloudScope":"A-Scope",
        "cloudResourceType":"",
        "cloudResourceId":"a12344567890",
        "cloudResourceName":"A-1234567890",
        "cloudLocation":"Tokyo"}'

[result]
    ... 中略 ...
    http://192.168.1.2:8080/HinemosWS/, modifyNode succeeded.


- ノード変数を追加します(-y)。
[command]
    $ python Repository_modifyNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE -y '[
        {"nodeVariableName":"VAR1", "nodeVariableValue":"I am var1"},
        {"nodeVariableName":"VAR2", "nodeVariableValue":"I am var2"},
        {"nodeVariableName":"VAR3", "nodeVariableValue":"I am var3 ..."}]'

[result]
    ... 中略 ...
    http://192.168.1.2:8080/HinemosWS/, modifyNode succeeded.

※ 同じ変数名(nodeVariableName)のものがすでに存在する場合は、既存のノード変数の値が上書きされます。


- ノード変数を削除します(-Y)。
[command]
    $ python Repository_modifyNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE -Y 'VAR1,VAR2,VAR3'

[result]
    ... 中略 ...
    http://192.168.1.2:8080/HinemosWS/, modifyNode succeeded.


- 保守関連情報を変更します(-m)。
[command]
    $ python Repository_modifyNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE -m '{
        "administrator":"Manager taro <manager.taro@example>",
        "contact":"+81-(0)90-8765-4321"}'

[result]
    ... 中略 ...
    http://192.168.1.2:8080/HinemosWS/, modifyNode succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs, locale
import json
import fnmatch

from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.common import ResultPrinter, SettingUtil

### Functions ###

def changeLog(k, old, new):
    print('CHANGE %s : %s -> %s' % (k, old, new))

def replaceAttr(info, k, item):
    ''' Replace attribute
    '''
    if k in item:
        changeLog(k, getattr(info, k), item[k])
        setattr(info, k, item[k])

def replaceAttr2(info, k_1, k, subitem):
    ''' Replace attribute on 2nd level
    '''
    if k in subitem:
        changeLog('%s.%s' % (k_1, k), getattr(info, k), subitem[k])
        setattr(info, k, subitem[k])

    # <BADHC> *Crypt fields
    if k.endswith('Password') and k+'Crypt' in info:
        setattr(info, k+'Crypt', None)

def addOrReplaceNodeVars(endpoint, vars_info, add_objs):
    if isinstance(add_objs, dict):
        existed_names = tuple(v.nodeVariableName for v in vars_info)
        # if exist then replace
        if add_objs['nodeVariableName'] in existed_names:
            changeLog('nodeVariable.'+add_objs['nodeVariableName'], vars_info[existed_names.index(add_objs['nodeVariableName'])].nodeVariableValue, add_objs['nodeVariableValue'])
            vars_info[existed_names.index(add_objs['nodeVariableName'])].nodeVariableValue = add_objs['nodeVariableValue']
        else:
            # otherwise, add
            info = endpoint.create_node_variable_info()
            replaceAttr(info, 'nodeVariableName', add_objs)
            replaceAttr(info, 'nodeVariableValue', add_objs)
            if info.nodeVariableName is not None:
                vars_info.append(info)
    elif isinstance(add_objs, list):
        for one in add_objs:
            addOrReplaceNodeVars(endpoint, vars_info, one)

def delVarsByWildname(vars_info, wildname):
    for info in vars_info[:]:
        if fnmatch.fnmatch(info.nodeVariableName, wildname):
            vars_info.remove(info)

def addCPUInfo(endpoint, device_info_lst, add_objs):
    if isinstance(add_objs, dict):
        info = endpoint.create_node_cpu_info();
        replaceAttr2(info, 'CPU', 'deviceDisplayName', add_objs)
        replaceAttr2(info, 'CPU', 'deviceName', add_objs)
        replaceAttr2(info, 'CPU', 'deviceIndex', add_objs)
        replaceAttr2(info, 'CPU', 'deviceSize', add_objs)
        replaceAttr2(info, 'CPU', 'deviceSizeUnit', add_objs)
        replaceAttr2(info, 'CPU', 'deviceDescription', add_objs)
        if info.deviceDisplayName is not None:
            info.deviceType = 'cpu'
            device_info_lst.append(info)
    elif isinstance(add_objs, list):
        for one in add_objs:
            addCPUInfo(endpoint, device_info_lst, one)

def addMemoryInfo(endpoint, device_info_lst, add_objs):
    if isinstance(add_objs, dict):
        info = endpoint.create_node_memory_info()
        replaceAttr2(info, 'MEM', 'deviceDisplayName', add_objs)
        replaceAttr2(info, 'MEM', 'deviceName', add_objs)
        replaceAttr2(info, 'MEM', 'deviceIndex', add_objs)
        replaceAttr2(info, 'MEM', 'deviceSize', add_objs)
        replaceAttr2(info, 'MEM', 'deviceSizeUnit', add_objs)
        replaceAttr2(info, 'MEM', 'deviceDescription', add_objs)
        if info.deviceDisplayName is not None:
            info.deviceType = 'mem'
            device_info_lst.append(info)
    elif isinstance(add_objs, list):
        for one in add_objs:
            addMemoryInfo(endpoint, device_info_lst, one)

def addNetworkInterfaceInfo(endpoint, device_info_lst, add_objs):
    if isinstance(add_objs, dict):
        info = endpoint.create_node_network_interface_info()
        replaceAttr2(info, 'NIC', 'deviceDisplayName', add_objs)
        replaceAttr2(info, 'NIC', 'deviceName', add_objs)
        replaceAttr2(info, 'NIC', 'deviceIndex', add_objs)
        replaceAttr2(info, 'NIC', 'deviceSize', add_objs)
        replaceAttr2(info, 'NIC', 'deviceSizeUnit', add_objs)
        replaceAttr2(info, 'NIC', 'deviceDescription', add_objs)
        replaceAttr2(info, 'NIC', 'nicIpAddress', add_objs)
        replaceAttr2(info, 'NIC', 'nicMacAddress', add_objs)
        if info.deviceDisplayName is not None:
            info.deviceType = 'nic'
            device_info_lst.append(info)
    elif isinstance(add_objs, list):
        for one in add_objs:
            addNetworkInterfaceInfo(endpoint, device_info_lst, one)

def addDiskInfo(endpoint, device_info_lst, add_objs):
    if isinstance(add_objs, dict):
        info = endpoint.create_node_disk_info()
        replaceAttr2(info, 'Disk', 'deviceDisplayName', add_objs)
        replaceAttr2(info, 'Disk', 'deviceName', add_objs)
        replaceAttr2(info, 'Disk', 'deviceIndex', add_objs)
        replaceAttr2(info, 'Disk', 'deviceSize', add_objs)
        replaceAttr2(info, 'Disk', 'deviceSizeUnit', add_objs)
        replaceAttr2(info, 'Disk', 'deviceDescription', add_objs)
        replaceAttr2(info, 'Disk', 'diskRpm', add_objs)
        if info.deviceDisplayName is not None:
            info.deviceType = 'disk'
            device_info_lst.append(info)
    elif isinstance(add_objs, list):
        for one in add_objs:
            addDiskInfo(endpoint, device_info_lst, one)

def addFilesystemInfo(endpoint, device_info_lst, add_objs):
    if isinstance(add_objs, dict):
        info = endpoint.create_node_filesystem_info()
        replaceAttr2(info, 'Filesystem', 'deviceDisplayName', add_objs)
        replaceAttr2(info, 'Filesystem', 'deviceName', add_objs)
        replaceAttr2(info, 'Filesystem', 'deviceIndex', add_objs)
        replaceAttr2(info, 'Filesystem', 'deviceSize', add_objs)
        replaceAttr2(info, 'Filesystem', 'deviceSizeUnit', add_objs)
        replaceAttr2(info, 'Filesystem', 'deviceDescription', add_objs)
        replaceAttr2(info, 'Filesystem', 'filesystemType', add_objs)
        if info.deviceDisplayName is not None:
            info.deviceType = 'filesystem'
            device_info_lst.append(info)
    elif isinstance(add_objs, list):
        for one in add_objs:
            addFilesystemInfo(endpoint, device_info_lst, one)

def addDeviceInfo(endpoint, device_info_lst, add_objs):
    if isinstance(add_objs, dict):
        info = endpoint.create_node_device_info()
        replaceAttr2(info, 'Generic', 'deviceDisplayName', add_objs)
        replaceAttr2(info, 'Generic', 'deviceName', add_objs)
        replaceAttr2(info, 'Generic', 'deviceIndex', add_objs)
        replaceAttr2(info, 'Generic', 'deviceType', add_objs)
        replaceAttr2(info, 'Generic', 'deviceSize', add_objs)
        replaceAttr2(info, 'Generic', 'deviceSizeUnit', add_objs)
        replaceAttr2(info, 'Generic', 'deviceDescription', add_objs)
        if info.deviceDisplayName is not None:
            device_info_lst.append(info)
    elif isinstance(add_objs, list):
        for one in add_objs:
            addDeviceInfo(endpoint, device_info_lst, one)

def removeDeviceInfo(device_info_lst, n_lst):
    if isinstance(n_lst, list):
        n_lst.sort(reverse=True)
        for n in n_lst:
            idx = n - 1
            if 0 <= idx < len(device_info_lst):
                print('DELETE %i' % idx)
                del device_info_lst[idx]
    elif isinstance(n_lst, int):
        idx = n_lst- 1
        if 0 <= idx < len(device_info_lst):
            print('DELETE %i' % idx)
            del device_info_lst[idx]
    elif isinstance(n_lst, basestring) and '*' == n_lst:
        print('DELETE *')
        del device_info_lst[:]


def modifyNodeOSInfo(node_os_info, obj):
    replaceAttr2(node_os_info, 'OS', 'osName', obj)
    replaceAttr2(node_os_info, 'OS', 'osRelease', obj)
    replaceAttr2(node_os_info, 'OS', 'osVersion', obj)
    replaceAttr2(node_os_info, 'OS', 'characterSet', obj)


### Main ###
def main():

    psr = MyOptionParser()
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='facilityID')
    psr.add_option('-N', '--facilityName', action='store', type='string', metavar='STRING', dest='facility_name',
                    default=None, help='facilityName')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                   default=None, help='description')
    psr.add_option('-e', '--enable', action='store', type='string', metavar='BOOL', dest='enable_raw',converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false')
    psr.add_option('-a', '--enableAutoDeviceUpdate', action='store', type='string', metavar='BOOL', dest='enable_auto_dev_update_raw',converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false')
    psr.add_option('-b', '--basics', action='store', type='string', metavar='STRING', dest='basics_j',
                   default=None, help='Set basic details in JSON.')
    psr.add_option('-j', '--job', action='store', type='string', metavar='STRING', dest='job_j',
                   default=None, help='Set job related details in JSON.')
    psr.add_option('-s', '--services', action='store', type='string', metavar='STRING', dest='services_j',
                   default=None, help='Set service related details in JSON.')
    psr.add_option('-c', '--devices', action='store', type='string', metavar='STRING', dest='devices_j',
                   default=None, help='Add device related details in JSON.')
    psr.add_option('-C', '--removeDevices', action='store', type='string', metavar='STRING', dest='devices_remove_j',
                   default=None, help='Remove device related details in JSON..')
    psr.add_option('-x', '--xcloud', action='store', type='string', metavar='STRING', dest='xcloud_j',
                   default=None, help='Set xCloud related details in JSON.')
    psr.add_option('-y', '--variables', action='store', type='string', metavar='STRING', dest='vars_j',
                   default=None, help='Add variable(s). Please specify in JSON.')
    psr.add_option('-Y', '--deleteVariables', action='store_split', type='string', metavar='STRING', dest='delete_vars_raw',
                   default=None, help='Remove variables by varibale name pattern. Also accept wildcard.')
    psr.add_option('-m', '--maintenance', action='store', type='string', metavar='STRING', dest='maintenance_j',
                   default=None, help='Set maintenance details in JSON. e.g. "{\'administrator\':\'admin<test1>\', \'contact\':\'080-7654-3210\'}"')
    psr.add_option('-n', '--note', action='store', type='string', metavar='STRING', dest='note',
                   default=None, help='Note')

    opts = psr.parse_opts(sys.argv)
    del psr


    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        info = endpoint.getNode(opts.facility_id)

        ### Moditfy ###
        # Top level
        if opts.facility_name is not None:
            changeLog('description', info.facilityName, opts.facility_name)
            info.facilityName = opts.facility_name

        if opts.description is not None:
            changeLog('description', info.description, opts.description)
            info.description = opts.description

        if opts.enable is not None:
            changeLog('enable', info.valid, opts.enable)
            info.valid = opts.enable

        if opts.enable_auto_dev_update is not None:
            changeLog('autoDeviceSearch', info.autoDeviceSearch, opts.enable_auto_dev_update)
            info.autoDeviceSearch = opts.enable_auto_dev_update

        # Basics
        if opts.basics_j is not None:
            # XXX delete print
            print '#################', opts
            json_obj = json.loads(opts.basics_j)
            # - Hardware
            k_1 = 'Hardware'
            if k_1 in json_obj:
                subitem = json_obj[k_1]

                replaceAttr2(info, k_1, 'platformFamily', subitem)
                replaceAttr2(info, k_1, 'subPlatformFamily', subitem)
                replaceAttr2(info, k_1, 'hardwareType', subitem)
                replaceAttr2(info, k_1, 'iconImage', subitem)

            # - Network
            k_1 = 'Network'
            if k_1 in json_obj:
                subitem = json_obj[k_1]

                replaceAttr2(info, k_1, 'ipAddressVersion', subitem)
                replaceAttr2(info, k_1, 'ipAddressV4', subitem)
                replaceAttr2(info, k_1, 'ipAddressV6', subitem)
                replaceAttr2(info, k_1, 'nodeName', subitem)
                #replaceAttr2(info, k_1, 'hostname', subitem)
                k = 'hostname'
                if k in subitem:
                    if 'nodeHostnameInfo' in info:
                        curr_hostname = info.nodeHostnameInfo[0].hostname
                    else:
                        curr_hostname = None
                    changeLog('%s.%s' % (k_1, k), curr_hostname, subitem[k])

                    sub_info = endpoint.create_node_hostname_info()
                    sub_info.hostname = subitem[k]
                    info.nodeHostnameInfo = [sub_info]

            # - OS
            k_1 = 'OS'
            if k_1 in json_obj:
                subitem = json_obj[k_1]
                modifyNodeOSInfo(info.nodeOsInfo, subitem)

            # - HinemosAgent
            k_1 = 'HinemosAgent'
            if k_1 in json_obj:
                subitem = json_obj[k_1]
                replaceAttr2(info, k_1, 'agentAwakePort', subitem)

        # Job
        if opts.job_j is not None:
            json_obj = json.loads(opts.job_j)

            replaceAttr(info, 'jobPriority', json_obj)
            replaceAttr(info, 'jobMultiplicity', json_obj)

        # Service(SNMP, WBEM,IPMI,WinRM,SSH)
        if opts.services_j is not None:
            json_obj = json.loads(opts.services_j)

            k_1 = 'SNMP'
            if k_1 in json_obj:
                subitem = json_obj[k_1]

                replaceAttr2(info, k_1, 'snmpUser', subitem)
                replaceAttr2(info, k_1, 'snmpPort', subitem)
                replaceAttr2(info, k_1, 'snmpCommunity', subitem)
                replaceAttr2(info, k_1, 'snmpVersion', subitem)
                replaceAttr2(info, k_1, 'snmpSecurityLevel', subitem)
                replaceAttr2(info, k_1, 'snmpAuthPassword', subitem)
                replaceAttr2(info, k_1, 'snmpPrivPassword', subitem)
                replaceAttr2(info, k_1, 'snmpAuthProtocol', subitem)
                replaceAttr2(info, k_1, 'snmpPrivProtocol', subitem)
                replaceAttr2(info, k_1, 'snmpTimeout', subitem)
                replaceAttr2(info, k_1, 'snmpRetryCount', subitem)

            k_1 = 'WBEM'
            if k_1 in json_obj:
                subitem = json_obj[k_1]

                replaceAttr2(info, k_1, 'wbemUser', subitem)
                replaceAttr2(info, k_1, 'wbemUserPassword', subitem)
                replaceAttr2(info, k_1, 'wbemPort', subitem)
                replaceAttr2(info, k_1, 'wbemProtocol', subitem)
                replaceAttr2(info, k_1, 'wbemTimeout', subitem)
                replaceAttr2(info, k_1, 'wbemRetryCount', subitem)

            k_1 = 'IPMI'
            if k_1 in json_obj:
                subitem = json_obj[k_1]

                replaceAttr2(info, k_1, 'ipmiIpAddress', subitem)
                replaceAttr2(info, k_1, 'ipmiPort', subitem)
                replaceAttr2(info, k_1, 'ipmiUser', subitem)
                replaceAttr2(info, k_1, 'ipmiUserPassword', subitem)
                replaceAttr2(info, k_1, 'ipmiTimeout', subitem)
                replaceAttr2(info, k_1, 'ipmiRetries', subitem)
                replaceAttr2(info, k_1, 'ipmiProtocol', subitem)
                replaceAttr2(info, k_1, 'ipmiLevel', subitem)

            k_1 = 'WinRM'
            if k_1 in json_obj:
                subitem = json_obj[k_1]

                replaceAttr2(info, k_1, 'winrmUser', subitem)
                replaceAttr2(info, k_1, 'winrmUserPassword', subitem)
                replaceAttr2(info, k_1, 'winrmVersion', subitem)
                replaceAttr2(info, k_1, 'winrmPort', subitem)
                replaceAttr2(info, k_1, 'winrmProtocol', subitem)
                replaceAttr2(info, k_1, 'winrmTimeout', subitem)
                replaceAttr2(info, k_1, 'winrmRetries', subitem)

            k_1 = 'SSH'
            if k_1 in json_obj:
                subitem = json_obj[k_1]

                replaceAttr2(info, k_1, 'sshUser', subitem)
                replaceAttr2(info, k_1, 'sshUserPassword', subitem)
                replaceAttr2(info, k_1, 'sshPrivateKeyFilepath', subitem)
                replaceAttr2(info, k_1, 'sshPrivateKeyPassphrase', subitem)
                replaceAttr2(info, k_1, 'sshPort', subitem)
                replaceAttr2(info, k_1, 'sshTimeout', subitem)

        # Device
        # - Add
        if opts.devices_j is not None:
            json_obj = json.loads(opts.devices_j)

            k_1 = 'CPU'
            if k_1 in json_obj:
                if not hasattr(info, 'nodeCpuInfo'):
                    setattr(info, 'nodeCpuInfo', [])
                addCPUInfo(endpoint, info.nodeCpuInfo, json_obj[k_1])

            k_1 = 'Memory'
            if k_1 in json_obj:
                if not hasattr(info, 'nodeMemoryInfo'):
                    setattr(info, 'nodeMemoryInfo', [])
                addMemoryInfo(endpoint, info.nodeMemoryInfo, json_obj[k_1])

            k_1 = 'NIC'
            if k_1 in json_obj:
                if not hasattr(info, 'nodeNetworkInterfaceInfo'):
                    setattr(info, 'nodeNetworkInterfaceInfo', [])
                addNetworkInterfaceInfo(endpoint, info.nodeNetworkInterfaceInfo, json_obj[k_1])

            k_1 = 'Disk'
            if k_1 in json_obj:
                if not hasattr(info, 'nodeDiskInfo'):
                    setattr(info, 'nodeDiskInfo', [])
                addDiskInfo(endpoint, info.nodeDiskInfo, json_obj[k_1])

            k_1 = 'Filesystem'
            if k_1 in json_obj:
                if not hasattr(info, 'nodeFilesystemInfo'):
                    setattr(info, 'nodeFilesystemInfo', [])
                addFilesystemInfo(endpoint, info.nodeFilesystemInfo, json_obj[k_1])

            k_1 = 'Generic'
            if k_1 in json_obj:
                if not hasattr(info, 'nodeDeviceInfo'):
                    setattr(info, 'nodeDeviceInfo', [])
                addDeviceInfo(endpoint, info.nodeDeviceInfo, json_obj[k_1])

        # - Remove
        if opts.devices_remove_j is not None:
            json_obj = json.loads(opts.devices_remove_j)

            k_1 = 'CPU'
            if k_1 in json_obj:
                if hasattr(info, 'nodeCpuInfo') and info.nodeCpuInfo is not None and 0 < len(info.nodeCpuInfo):
                    removeDeviceInfo(info.nodeCpuInfo, json_obj[k_1])

            k_1 = 'Memory'
            if k_1 in json_obj:
                if hasattr(info, 'nodeMemoryInfo') and info.nodeMemoryInfo is not None and 0 < len(info.nodeMemoryInfo):
                    removeDeviceInfo(info.nodeMemoryInfo, json_obj[k_1])

            k_1 = 'NIC'
            if k_1 in json_obj:
                if hasattr(info, 'nodeNetworkInterfaceInfo') and info.nodeNetworkInterfaceInfo is not None and 0 < len(info.nodeNetworkInterfaceInfo):
                    removeDeviceInfo(info.nodeNetworkInterfaceInfo, json_obj[k_1])

            k_1 = 'Disk'
            if k_1 in json_obj:
                if hasattr(info, 'nodeDiskInfo') and info.nodeDiskInfo is not None and 0 < len(info.nodeDiskInfo):
                    removeDeviceInfo(info.nodeDiskInfo, json_obj[k_1])

            k_1 = 'Filesystem'
            if k_1 in json_obj:
                if hasattr(info, 'nodeFilesystemInfo') and info.nodeFilesystemInfo is not None and 0 < len(info.nodeFilesystemInfo):
                    removeDeviceInfo(info.nodeFilesystemInfo, json_obj[k_1])

            k_1 = 'Generic'
            if k_1 in json_obj:
                if hasattr(info, 'nodeDeviceInfo') and info.nodeDeviceInfo is not None and 0 < len(info.nodeDeviceInfo):
                    removeDeviceInfo(info.nodeDeviceInfo, json_obj[k_1])

        # Cloud/Virtualization
        if opts.xcloud_j is not None:
            json_obj = json.loads(opts.xcloud_j)

            replaceAttr(info, 'cloudService', json_obj)
            replaceAttr(info, 'cloudScope', json_obj)
            replaceAttr(info, 'cloudResourceType', json_obj)
            replaceAttr(info, 'cloudResourceId', json_obj)
            replaceAttr(info, 'cloudResourceName', json_obj)
            replaceAttr(info, 'cloudLocation', json_obj)

        # NodeVariables
        # add vars
        if opts.vars_j is not None:
            json_obj = json.loads(opts.vars_j)

            if not hasattr(info, 'nodeVariableInfo'):
                setattr(info, 'nodeVariableInfo', [])
            addOrReplaceNodeVars(endpoint, info.nodeVariableInfo, json_obj)

        # delete vars
        if opts.delete_vars is not None:
            if hasattr(info, 'nodeVariableInfo') and info.nodeVariableInfo is not None and 0 < len(info.nodeVariableInfo):
                for a in opts.delete_vars:
                    delVarsByWildname(info.nodeVariableInfo, a)

        # Maintenance
        if opts.maintenance_j is not None:
            json_obj = json.loads(opts.maintenance_j.encode(locale.getdefaultlocale()[1]))
            replaceAttr(info, 'administrator', json_obj)
            replaceAttr(info, 'contact', json_obj)

        # Note
        if opts.note is not None:
            if hasattr(info, 'nodeNoteInfo') and info.nodeNoteInfo is not None and 0 < len(info.nodeNoteInfo):
                curr_note = info.nodeNoteInfo[0].note
            else:
                curr_note = None
            k = 'note'
            changeLog(k, curr_note, opts.note)

            sub_info = endpoint.create_node_note_info()
            sub_info.note = opts.note
            sub_info.noteId = 0
            info.nodeNoteInfo = [sub_info]

        endpoint.modifyNode(info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyNode')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
