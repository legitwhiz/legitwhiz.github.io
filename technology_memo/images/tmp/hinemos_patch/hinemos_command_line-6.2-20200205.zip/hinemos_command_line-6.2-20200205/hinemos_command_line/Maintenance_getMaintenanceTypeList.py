#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
メンテナンス種別の一覧を取得する

<概要>
メンテナンス種別の一覧を取得して表示します。

<使用例>
[command]
    $ python Maintenance_getMaintenanceTypeList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    [(maintenanceTypeMst){
       name_id = "maintenance.delete_event_log_all"
       order_no = 0
       type_id = "DELETE_EVENT_LOG_ALL"
     }, (maintenanceTypeMst){
       name_id = "maintenance.delete_event_log"
       order_no = 1
       type_id = "DELETE_EVENT_LOG"
     }, (maintenanceTypeMst){
       name_id = "maintenance.delete_job_history_all"
       order_no = 10
       type_id = "DELETE_JOB_HISTORY_ALL"
     }, (maintenanceTypeMst){
       name_id = "maintenance.delete_job_history"
       order_no = 11
       type_id = "DELETE_JOB_HISTORY"
     }, (maintenanceTypeMst){
       name_id = "maintenance.delete_collect_data_raw"
       order_no = 20
       type_id = "DELETE_COLLECT_DATA_RAW"
     }, (maintenanceTypeMst){
       name_id = "maintenance.delete_summary_data_hour"
       order_no = 30
       type_id = "DELETE_SUMMARY_DATA_HOUR"
     }, (maintenanceTypeMst){
       name_id = "maintenance.delete_summary_data_day"
       order_no = 40
       type_id = "DELETE_SUMMARY_DATA_DAY"
     }, (maintenanceTypeMst){
       name_id = "maintenance.delete_summary_data_month"
       order_no = 50
       type_id = "DELETE_SUMMARY_DATA_MONTH"
     }, (maintenanceTypeMst){
       name_id = "maintenance.delete_collect_string_data"
       order_no = 60
       type_id = "DELETE_COLLECT_STRING_DATA"
     }]
    http://192.168.1.2:8080/HinemosWS/, getMaintenanceTypeList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.maintenance import MaintenanceEndpoint

def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MaintenanceEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = endpoint.getMaintenanceTypeList()
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getMaintenanceTypeList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
