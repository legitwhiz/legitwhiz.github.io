#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
「監視」タブの情報を変更する

<概要>
「監視」タブの情報を変更します。

<使用例>
- 対象スコープと監視設定を変更します。
[command]
    $ python Job_modifyJob_MonitorTab.py -J JU001/JM001 -F "#[FACILITY_ID]" -I CPU001

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.

- タイムアウトとその終了値を変更する。
[command]
    $ python Job_modifyJob_MonitorTab.py -J JU001/JM001 -T 3 -S 1

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.

- 対象監視設定と各重要度の終了値を変更する。
[command]
    $ python Job_modifyJob_MonitorTab.py -J JU001/JM001 -I PING001 -O 0 -P 1 -Q 2 -R 3

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.
"""

import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil, TabInfo
from hinemos.util.common import ResultPrinter

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facilityID',
                    default=(None, 'NOTBLANK'), help='Scope: job parameter = \'#[FACILITY_ID]\', fixed value = facility ID')
    psr.add_option('-M', '--processingMethod', action='store', type='int', metavar='INT', dest='processingMethod',
                    default=None, help='Processing method: all nodes = 0, try one by one = 1')
    psr.add_option('-I', '--monitorID',  action='store', type='string', metavar='ID', dest='monitorID',
                    default=None, help='Monitor setting ID')

    psr.add_option('-O', '--endValueInfo', action='store', type='int', metavar='INT', dest='endValueInfo',
                    default=None, help='End value of INFO')
    psr.add_option('-P', '--endValueWarn', action='store', type='int', metavar='INT', dest='endValueWarn',
                    default=None, help='End value of WARN')
    psr.add_option('-Q', '--endValueCritical', action='store', type='int', metavar='INT', dest='endValueCritical',
                    default=None, help='End value of CRITICAL')
    psr.add_option('-R', '--endValueUnknown', action='store', type='int', metavar='INT', dest='endValueUnknown',
                    default=None, help='End value of UNKNOWN')

    psr.add_option('-T', '--timeout', action='store', type='int', metavar='INT', dest='timeout',
                    default=None, help='Timeout')
    psr.add_option('-S', '--endValueTimeout', action='store', type='int', metavar='INT', dest='endValueTimeout',
                    default=None, help='End value when timed out')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job)
        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, job_map['jobunitId'])
        del job_tree_full

        LOGGER.debug(job_tree)

        job_info = JobUtil.find_job_info(job_tree, job_map['jobId'])
        if job_info is None:
            raise ErrorHandler.ArgumentError('Job {:s} not found!'.format(job_map['jobId']))

        job_type_label = JobUtil.convert2job_type_label(job_info.type)
        if job_type_label not in ('MONITORJOB',):
            raise ErrorHandler.ArgumentError('This operation is not available for %s!' % job_type_label)

        new_job_info = endpoint.getJobFull(endpoint.create_job_info_minimal(job_map['jobunitId'], job_map['jobId']))

        TabInfo.set_monitor_tab(
            new_job_info,
            opts.facilityID, opts.processingMethod, opts.monitorID,
            opts.endValueInfo, opts.endValueWarn, opts.endValueCritical, opts.endValueUnknown,
            opts.timeout, opts.endValueTimeout)

        JobUtil.replace_job_info(job_tree, new_job_info)

        # Clean up and replace none with blank
        JobUtil.cleanup_and_fixnone(job_tree)

        LOGGER.debug(job_tree)
        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJob')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
