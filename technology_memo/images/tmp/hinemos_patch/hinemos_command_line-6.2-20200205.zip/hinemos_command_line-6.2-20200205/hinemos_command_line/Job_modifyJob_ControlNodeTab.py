#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
「制御(ノード)」タブの情報を変更する

<概要>
「制御(ノード)」タブの情報を変更します。

<使用例>
- 多重度の通知処理を変更します。
[command]
    $ python Job_modifyJob_ControlNodeTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB1 -N true -P INFO -O END -E 9

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- 試行回数の設定を変更します。
[command]
    $ python Job_modifyJob_ControlNodeTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB1 -A false -B 1 -C 0 -R true -S 1

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.modifier import ObjectModifier
from hinemos.util.notify import NotifyUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    ### 多重度タブ設定項目 ###
    psr.add_option('-N', '--multiplicityNotify', action='store', type='string', metavar='STRING', dest='multiplicity_notify_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='multiplicityNotify: enable=true, disable=false')
    psr.add_option('-P', '--multiplicityNotifyPriority', action='store', type='string', metavar='STRING', dest='multiplicity_notify_priority_raw',converter=NotifyUtil.convert2priority,
                    default=(None, {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN']}), help='multiplicityNotifyPriority = INFO or WARN or CRITICAL or UNKNOWN')
    psr.add_option('-O', '--multiplicityOperation', action='store', type='string', metavar='STRING', dest='multiplicity_operation_raw',converter=JobUtil.convert2multiplicity_operation,
                    default=(None, {'INLIST':JobUtil._multiplicity_operation_.keys()}), help='multiplicityOperation: ' + ' or '.join(JobUtil._multiplicity_operation_.keys()))
    psr.add_option('-E', '--multiplicityEndValue', action='store', type='int', metavar='INT', dest='multiplicity_end_value',
                    default=None, help='multiplicityEndValue = integer')

    psr.add_option('-A', '--agentRetry', action='store', type='string', metavar='STRING', dest='agent_retry_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='errorEndFlg: enable=true, disable=false')
    psr.add_option('-B', '--agentRetryTime', action='store', type='int', metavar='INT', dest='agent_retry_time',
                    default=None, help='agentRetryTime = integer')
    psr.add_option('-C', '--agentRetryEndValue', action='store', type='int', metavar='INT', dest='agent_retry_end_value',
                    default=None, help='agentRetryEndValue = integer')

    psr.add_option('-R', '--commandRetry', action='store', type='string', metavar='STRING', dest='command_retry_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='errorEndFlg: enable=true, disable=false, #NOT AVAILABLE FOR FILE TRANSFER JOB')
    psr.add_option('-S', '--commandRetryTime', action='store', type='int', metavar='INT', dest='command_retry_time',
                    default=None, help='commandRetryTime = integer, #NOT AVAILABLE FOR FILE TRANSFER JOB')
    psr.add_option('-T', '--commandRetryEndStatus', action='store', type='string', metavar='STRING', dest='command_retry_finish_status_raw',converter=JobUtil.convert2finish_status,
                    default=(None, {'INLIST':JobUtil._job_finish_status_}), help='finish statuses: ' + ', '.join(JobUtil._job_finish_status_) + ', #NOT AVAILABLE FOR FILE TRANSFER JOB')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job)
        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, job_map['jobunitId'])
        del job_tree_full

        job_info = JobUtil.find_job_info(job_tree, job_map['jobId'])
        if job_info is None:
            raise ErrorHandler.ArgumentError('Job {:s} not found!'.format(job_map['jobId']))

        job_type_label = JobUtil.convert2job_type_label(job_info.type)
        if job_type_label not in ('JOB','FILEJOB'):
            raise ErrorHandler.ArgumentError('This operation is not available for %s!' % job_type_label)

        new_job_info = endpoint.getJobFull(endpoint.create_job_info_minimal(job_map['jobunitId'], job_map['jobId']))
        with ObjectModifier(new_job_info) as modifier:
            if hasattr(new_job_info, 'file'):
                modifier.change_ptr('file')
                modifier.set_if_first_not_none('messageRetryEndFlg', opts.agent_retry)
                modifier.set_if_first_not_none('messageRetry', opts.agent_retry_time)
                modifier.set_if_first_not_none('messageRetryEndValue', opts.agent_retry_end_value)
                # TODO seems this is never activated. need to confirm with the spec
                # modifier.set_if_first_not_none('commandRetry', opts.command_retry_time)
                # modifier.set_if_first_not_none('commandRetryFlg', opts.command_retry)
                # if opts.command_retry_finish_status_raw:
                #     modifier.set_attr(commandRetryEndStatus=opts.command_retry_finish_status)

            if hasattr(new_job_info, 'command'):
                modifier.change_ptr('command')
                modifier.set_if_first_not_none('messageRetryEndFlg', opts.agent_retry)
                modifier.set_if_first_not_none('messageRetry', opts.agent_retry_time)
                modifier.set_if_first_not_none('messageRetryEndValue', opts.agent_retry_end_value)
                modifier.set_if_first_not_none('commandRetry', opts.command_retry_time)
                modifier.set_if_first_not_none('commandRetryFlg', opts.command_retry)
                if opts.command_retry_finish_status_raw:
                    modifier.set_attr(commandRetryEndStatus=opts.command_retry_finish_status)

            modifier.change_ptr('waitRule')
            modifier.set_if_first_not_none('multiplicityNotify', opts.multiplicity_notify)
            modifier.set_if_first_not_none('multiplicityNotifyPriority', opts.multiplicity_notify_priority)
            modifier.set_if_first_not_none('multiplicityOperation', opts.multiplicity_operation)
            modifier.set_if_first_not_none('multiplicityEndValue', opts.multiplicity_end_value)

        JobUtil.replace_job_info(job_tree, new_job_info)

        # Clean up and replace none with blank
        JobUtil.cleanup_and_fixnone(job_tree)

        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJob')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
