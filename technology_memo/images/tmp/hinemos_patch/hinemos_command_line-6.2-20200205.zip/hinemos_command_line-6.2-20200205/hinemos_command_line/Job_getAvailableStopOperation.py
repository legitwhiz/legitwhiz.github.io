#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したジョブ操作停止用プロパティを取得する

<概要>
引数で指定したジョブ操作停止用プロパティを取得して表示します。

<使用例>
[command]
    $ python Job_getAvailableStopOperation.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J TEST_JOBU -I TEST_JOB -S 20170307102729-000

[result]
    [8]
    http://192.168.1.2:8080/HinemosWS/, getAvailableStopOperation succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-S', '--sessionID',  action='store', type='string', metavar='ID', dest='session_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='sessionID')
    psr.add_option('-J', '--jobunitID',  action='store', type='string', metavar='ID', dest='jobunit_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='jobunit ID')
    psr.add_option('-I', '--jobID',  action='store', type='string', metavar='ID', dest='job_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='job ID')
    psr.add_option('-F', '--facility', action='store', type='string', metavar='STRING', dest='facility_id',
                   default='', help='facilityID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = endpoint.getAvailableStopOperation(opts.session_id, opts.jobunit_id, opts.job_id, opts.facility_id)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getAvailableStopOperation')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
