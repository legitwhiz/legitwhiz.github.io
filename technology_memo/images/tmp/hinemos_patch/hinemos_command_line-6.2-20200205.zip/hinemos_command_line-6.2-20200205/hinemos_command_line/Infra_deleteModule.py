#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
モジュールを削除する

<概要>
モジュールを削除します。

<使用例>
[command]
    $ python Infra_deleteModule.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -M MAN001 -I CMOD001

[result]
    http://192.168.1.2:8080/HinemosWS/, deleteModule succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.infra import InfraEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-M', '--managementID',  action='store', type='string', metavar='ID', dest='management_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='infra management ID')
    psr.add_option('-I', '--moduleID',  action='store', type='string', metavar='ID', dest='module_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='module ID')
    opts = psr.parse_opts(sys.argv)
    del psr

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = InfraEndpoint(opts.mgr_url, opts.user, opts.passwd)
        endpoint.delete_module(opts.management_id, opts.module_id)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'deleteModule')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
