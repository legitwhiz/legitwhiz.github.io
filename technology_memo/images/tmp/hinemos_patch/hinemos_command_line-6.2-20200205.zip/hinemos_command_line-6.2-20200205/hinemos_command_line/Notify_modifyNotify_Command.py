#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
コマンド通知情報を変更する

<概要>
コマンド通知情報を変更します。

<使用例>
[command]
    $ python Notify_modifyNotify_Command.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I COMMAND1 -e true

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyNotify_Command succeeded.
"""

### import ###
import sys
import codecs, locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.notify import NotifyUtil

def main():

    ### argument setting ###
    psr = MyOptionParser()
    psr.add_option('-I', '--notifyID',  action='store', type='string', metavar='ID', dest='notify_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='notifyID')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='description')
    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                    default=(None,'NOTBLANK'), help='calendar ID')
    psr.add_option('-c', '--initialCount', action='store', type='int', metavar='INT', dest='initial_count',
                    default=None, help='initialCount')
    psr.add_option('-F', '--notFirstNotify', action='store', type='string', metavar='STRING', dest='not_first_notify',
                    default=(None,{'INLIST':['true','false']}), help='notify after validated')
    psr.add_option('-T', '--renotifyType', action='store', type='int', metavar='INT', dest='renotify_type',
                    default=(None, {'INLIST':[0,1,2]}), help='renotifyType Always = 0, Time Suppressing = 1, Don\'t notify = 2')
    psr.add_option('-P', '--renotifyPeriod', action='store', type='int', metavar='INT', dest='renotify_period',
                    default=(None, {'WHEN':{'renotify_type':1}, 'DO':('REQUIRED')}), help='renotifyPeriod')
    psr.add_option('-i', '--infoFlg', action='store', type='int', metavar='INT', dest='info_flg',
                    default=(None, {'INLIST':[0,1]}), help='infoFlg : valid = 1, invalid = 0')
    psr.add_option('-o', '--effectiveUserInfo', action='store', type='string', metavar='STRING', dest='effective_user_info',
                    default=(None, {'WHEN':{'info_flg':1}, 'DO':('REQUIRED','NOTBLANK')}), help='effectiveUser_info')
    psr.add_option('-O', '--commandInfo', action='store', type='string', metavar='STRING', dest='command_info',
                    default=(None, {'WHEN':{'info_flg':1}, 'DO':('REQUIRED','NOTBLANK')}), help='command_info')
    psr.add_option('-a', '--warningFlg', action='store', type='int', metavar='INT', dest='warning_flg',
                    default=(None, {'INLIST':[0,1]}), help='warningFlg : valid = 1, invalid = 0')
    psr.add_option('-g', '--effectiveUserWarning', action='store', type='string', metavar='STRING', dest='effective_user_warning',
                    default=(None, {'WHEN':{'warning_flg':1}, 'DO':('REQUIRED','NOTBLANK')}), help='effectiveUser_warning')
    psr.add_option('-G', '--commandWarning', action='store', type='string', metavar='STRING', dest='command_warning',
                    default=(None, {'WHEN':{'warning_flg':1}, 'DO':('REQUIRED','NOTBLANK')}), help='command_warning')
    psr.add_option('-t', '--criticalFlg', action='store', type='int', metavar='INT', dest='critical_flg',
                    default=(None, {'INLIST':[0,1]}), help='criticalFlg : valid = 1, invalid = 0')
    psr.add_option('-l', '--effectiveUserCritical', action='store', type='string', metavar='STRING', dest='effective_user_critical',
                    default=(None, {'WHEN':{'critical_flg':1}, 'DO':('REQUIRED','NOTBLANK')}), help='effectiveUser_critical')
    psr.add_option('-L', '--commandCritical', action='store', type='string', metavar='STRING', dest='command_critical',
                    default=(None, {'WHEN':{'critical_flg':1}, 'DO':('REQUIRED','NOTBLANK')}), help='command_critical')
    psr.add_option('-u', '--unknownFlg', action='store', type='int', metavar='INT', dest='unknown_flg',
                    default=(None, {'INLIST':[0,1]}), help='unknownFlg : valid = 1, invalid = 0')
    psr.add_option('-k', '--effectiveUserUnknown', action='store', type='string', metavar='STRING', dest='effective_user_unknown',
                    default=(None, {'WHEN':{'unknown_flg':1}, 'DO':('REQUIRED','NOTBLANK')}), help='effectiveUser_unknown')
    psr.add_option('-K', '--commandUnknown', action='store', type='string', metavar='STRING', dest='command_unknown',
                    default=(None, {'WHEN':{'unknown_flg':1}, 'DO':('REQUIRED','NOTBLANK')}), help='command_unknown')
    psr.add_option('-m', '--timeout', action='store', type='int', metavar='INT', dest='timeout',
                    default=None, help='timeout')
    psr.add_option('-e', '--enable', action='store', type='string', metavar='STRING', dest='enable_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### notifyInfo parameter ###
        notify_info = endpoint.getNotify(opts.notify_id, NotifyUtil.convert2notify_type('COMMAND'))
        if notify_info is None:
            raise ErrorHandler.ObjectNotFoundError('Setting ' + opts.notify_id + ' does not exist!')

        if opts.description is not None:
            notify_info.description = opts.description
        if opts.calendar_id is not None:
            notify_info.calendarId = opts.calendar_id
        if opts.initial_count is not None:
            notify_info.initialCount = opts.initial_count
        if opts.not_first_notify is not None:
            notify_info.notFirstNotify = SettingUtil.convert2nint(opts.not_first_notify)
        if opts.renotify_type is not None:
            notify_info.renotifyType = opts.renotify_type
        if opts.renotify_period is not None:
            notify_info.renotifyPeriod = opts.renotify_period
        if opts.enable is not None:
            notify_info.validFlg = opts.enable

        ### notifyCommandInfo parameter ###
        if opts.info_flg is not None:
            notify_info.notifyCommandInfo.infoValidFlg = opts.info_flg
        if opts.effective_user_info is not None:
            notify_info.notifyCommandInfo.infoEffectiveUser = opts.effective_user_info
        if opts.command_info is not None:
            notify_info.notifyCommandInfo.infoCommand = opts.command_info

        if opts.warning_flg is not None:
            notify_info.notifyCommandInfo.warnValidFlg = opts.warning_flg
        if opts.effective_user_warning is not None:
            notify_info.notifyCommandInfo.warnEffectiveUser = opts.effective_user_warning
        if opts.command_warning is not None:
            notify_info.notifyCommandInfo.warnCommand = opts.command_warning

        if opts.critical_flg is not None:
            notify_info.notifyCommandInfo.criticalValidFlg = opts.critical_flg
        if opts.effective_user_critical is not None:
            notify_info.notifyCommandInfo.criticalEffectiveUser = opts.effective_user_critical
        if opts.command_critical is not None:
            notify_info.notifyCommandInfo.criticalCommand = opts.command_critical

        if opts.unknown_flg is not None:
            notify_info.notifyCommandInfo.unknownValidFlg = opts.unknown_flg
        if opts.effective_user_unknown is not None:
            notify_info.notifyCommandInfo.unknownEffectiveUser = opts.effective_user_unknown
        if opts.command_unknown is not None:
            notify_info.notifyCommandInfo.unknownCommand = opts.command_unknown

        if opts.timeout is not None:
            notify_info.notifyCommandInfo.timeout = opts.timeout

        endpoint.modifyNotify(notify_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyNotify_Command')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
