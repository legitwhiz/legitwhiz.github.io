#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
Hinemosプロパティを作成する

<概要>
Hinemosプロパティを作成します。

<使用例>
[command]
    $ python HinemosProperty_addHinemosProperty.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -K my.new.property -T NUMERIC -V 100

[result]
    http://192.168.1.2:8080/HinemosWS/, addHinemosProperty succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.hinemosproperty import HinemosPropertyEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-T', '--type', action='store', type='string', metavar='STRING', dest='type',
                   default=(None, 'REQUIRED', {'INLIST':['STRING','NUMERIC','BOOLEAN']}), help='type = STRING or NUMERIC or BOOLEAN')
    psr.add_option('-K', '--key', action='store', type='string', metavar='STRING', dest='key',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='key')
    psr.add_option('-V', '--value', action='store', type='string', metavar='STRING', dest='value',
                   default=(None, 'REQUIRED',{'WHEN':{'type':'NUMERIC'},'DO':('INTEGER')},{'WHEN':{'type':'BOOLEAN'},'DO':({'INLIST':['true','false']})}), help='value')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                   default=None, help='description')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = HinemosPropertyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        hinemos_property_info = endpoint.create_hinemos_property_info(opts.type, opts.key, opts.value, opts.description, 'ADMINISTRATORS')
        endpoint.addHinemosProperty(hinemos_property_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addHinemosProperty')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
