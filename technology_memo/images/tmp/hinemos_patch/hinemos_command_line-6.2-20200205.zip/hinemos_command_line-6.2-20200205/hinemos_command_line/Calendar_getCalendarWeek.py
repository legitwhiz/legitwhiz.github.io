#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定された日付からの、週間予定の表示情報を取得して表示する

<概要>
引数で指定された、日付からのカレンダ[週間予定]の表示情報を取得して表示します。

<使用例>
[command]
    $ python Calendar_getCalendarWeek.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -C TEST_CAL02 -Y 2017 -M 3 -D 3

[result]
    [(calendarDetailInfo){
       afterday = 0
       calendarId = "TEST_CAL02"
       dayOfWeek = 6
       dayOfWeekInMonth = 0
       dayType = 1
       month = 0
       operateFlg = True
       substituteFlg = False
       substituteLimit = 10
       substituteTime = 24
       timeFrom = "09:00:00"
       timeTo = "18:00:00"
       year = 0
     }]
    http://192.168.1.2:8080/HinemosWS/, getCalendarWeek succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser

import hinemos.api.exceptions as ErrorHandler
from hinemos.api.calendar import CalendarEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='calendarID')
    psr.add_option('-Y', '--year', action='store', type='string', metavar='STRING', dest='year',
                    default=(None, 'REQUIRED', {'REGEXP':(r'^\d\d\d\d$','must be a year')}), help='year = YYYY')
    psr.add_option('-M', '--month', action='store', type='int', metavar='INT', dest='month',
                    default=(None, 'REQUIRED', {'RANGE':[1,12]}), help='month = 1-12')
    psr.add_option('-D', '--day', action='store', type='int', metavar='INT', dest='day',
                    default=(None, 'REQUIRED', {'RANGE':[1,31]}), help='day = 1-31')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = CalendarEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = endpoint.getCalendarWeek(opts.calendar_id, opts.year, opts.month, opts.day)
        if len(result) != 0:
            for res in result:
                res.timeFrom = DateConvert.get_time48_from_epochtime(res.timeFrom)
                res.timeTo = DateConvert.get_time48_from_epochtime(res.timeTo)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getCalendarWeek')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
