#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ファイル配布モジュールを変更する

<概要>
ファイル配布モジュールを変更します。

<使用例>
[command]
    $ python Infra_modifyFileTransferModule.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -M MAN001 -I FMOD001 -F file2 -D /tmp2 -T WinRM -O user1 -E 755 -S true -B true -P true -e true

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyCommandModule succeeded.

<その他>
    python Infra_modifyFileTransferModule.py -w hinemos -M test01 -I mod02 -N Mod-2-updated -R pattern1 pattern2x pattern3x -Q repl1x repl2x repl3x
    python Infra_modifyFileTransferModule.py -w hinemos -M test01 -I mod02 -N Mod-2-updated -X pattern2x
    python Infra_modifyFileTransferModule.py -w hinemos -M test01 -I mod02 -N Mod-2-updated -X pattern3x pattern1x
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.infra import InfraEndpoint
from hinemos.util.infra import InfraMaker, InfraUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-M', '--managementID',  action='store', type='string', metavar='ID', dest='management_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='infra management ID')
    psr.add_option('-I', '--moduleID',  action='store', type='string', metavar='ID', dest='module_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='module ID')
    psr.add_option('-N', '--name', action='store', type='string', metavar='STRING', dest='name',
                   default=(None, 'NOTBLANK'), help='name')
    psr.add_option('-F', '--fileID',  action='store', type='string', metavar='ID', dest='file_id',
                   default=(None, 'NOTBLANK'), help='file ID')
    psr.add_option('-D', '--dst', action='store', type='string', metavar='STRING', dest='dst',
                   default=(None, 'NOTBLANK'), help='destination directory')
    psr.add_option('-T', '--transferMethod', action='store', type='string', metavar='STRING', dest='transfer_method_raw', converter=InfraUtil.convert2send_method_type,
                   default=(None, {'INLIST':['SCP', 'WinRM']}), help='transfer file over SCP or WinRM')
    psr.add_option('-O', '--destOwner', action='store', type='string', metavar='STRING', dest='dest_owner',
                   default=(None,'NOTBLANK'), help='file owner of transferred file')
    psr.add_option('-E', '--destPermission', action='store', type='string', metavar='STRING', dest='dest_permission',
                   default=(None, {'REGEXP':[r'[01243567]{3}$','Please specify file permission correctly (eg. 644, 400).']}), help='file permission of transferred file')
    psr.add_option('-S', '--stopIfFail', action='store', metavar='BOOL', dest='stop_if_fail_raw', converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST':['true','false']}), help='stop when there is any module failed')
    psr.add_option('-B', '--backupIfExist', action='store', type='string', metavar='BOOL', dest='backup_if_exist_raw', converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST':['true','false']}), help='backupIfExist')
    psr.add_option('-P', '--precheck', action='store', metavar='BOOL', dest='precheck_raw', converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST':['true','false']}), help='check MD5 checksum before transferring')

    psr.add_option('-R', '--replaceVarPatterns', action='my_x_append', type='string', metavar='STRING', dest='replaceVarPatterns',
                   default=None, help='Replace variable patterns')
    psr.add_option('-Q', '--replaceVarReplacements', action='my_x_append', type='string', metavar='STRING', dest='replaceVarReplacements',
                   default=None, help='Replace variable replacements')
    psr.add_option('-X', '--delReplaceVarPatterns', action='my_x_append', type='string', metavar='STRING', dest='delReplaceVarPatterns',
                   default=None, help='Replace variable patterns to delete')

    psr.add_option('-e', '--enable', action='store', type='string', metavar='BOOL', dest='enable_raw', converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = InfraEndpoint(opts.mgr_url, opts.user, opts.passwd)

        replace_var_lst = []
        if opts.replaceVarPatterns is not None:
            # Format
            if opts.replaceVarReplacements is None or len(opts.replaceVarPatterns) != len(opts.replaceVarReplacements):
                raise ErrorHandler.ArgumentError('Number of replaceVarPatterns not equal to number of replaceVarReplacements!')
            for i, a in enumerate(opts.replaceVarPatterns):
                replace_var_lst.append((a, opts.replaceVarReplacements[i]))

        InfraMaker(endpoint).modify_file_transfer_module(opts.management_id,\
            opts.module_id,\
            opts.name,\
            opts.file_id,\
            opts.dst,\
            opts.transfer_method,\
            opts.dest_owner,\
            opts.dest_permission,\
            opts.stop_if_fail,\
            opts.backup_if_exist,\
            opts.precheck,\
            replace_var_lst,\
            opts.delReplaceVarPatterns,\
            opts.enable)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyFileTransferModule')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
