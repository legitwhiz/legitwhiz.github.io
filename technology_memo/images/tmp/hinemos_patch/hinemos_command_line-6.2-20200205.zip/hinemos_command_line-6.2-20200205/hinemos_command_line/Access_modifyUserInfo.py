#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ユーザ情報を変更する

<概要>
ユーザ情報を変更します。

<使用例>
[command]
    $ python Access_modifyUserInfo.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST01 -N TEST02

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyUserInfo succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.access import AccessEndpoint
from hinemos.util.common import ResultPrinter

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--userID',  action='store', type='string', metavar='ID', dest='user_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='userID')
    psr.add_option('-N', '--rolename', action='store', type='string', metavar='STRING', dest='name',
                    default=None, help='name')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='description')
    psr.add_option('-M', '--mailAddress', action='store', type='string', metavar='STRING', dest='mail_address',
                    default='', help='mailAddress')

    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = AccessEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        user_info = endpoint.getUserInfo(opts.user_id)
        if user_info is None:
            raise ErrorHandler.ArgumentError('modifyUserInfo failed, ' + 'userID:' + opts.user_id + ' does not exist')
        if opts.name is not None:
            user_info.userName = opts.name
        if opts.description is not None:
            user_info.description = opts.description
        if opts.mail_address is not None:
            user_info.mailAddress = opts.mail_address

        endpoint.modifyUserInfo(user_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyUserInfo')
    except ErrorHandler.ArgumentError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
