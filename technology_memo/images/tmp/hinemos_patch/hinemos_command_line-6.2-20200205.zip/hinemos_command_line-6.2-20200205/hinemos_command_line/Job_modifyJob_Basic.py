#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
基本情報(ジョブ名、説明)を変更する

<概要>
基本情報(ジョブ名、説明)を変更します。

<使用例>
[command]
    $ python Job_modifyJob_Basic.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB1 -N NewName -D "Changed!"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.modifier import ObjectModifier

def main():

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    psr.add_option('-I', '--jobId', action='store', type='string', metavar='STRING', dest='job_id',
                    default=(None, 'NOTBLANK'), help='New job ID')

    psr.add_option('-N', '--jobName', action='store', type='string', metavar='STRING', dest='name',
                    default=(None, 'NOTBLANK'), help='Job name')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='Description')

    psr.add_option('-M', '--modularize', action='store', type='string', metavar='BOOL', dest='modularize_raw', converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST':['true','false']}), help='Set as module')
    psr.add_option('--iconID',  action='store', type='string', metavar='ID', dest='iconID',
                   default=None, help='Icon ID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job)
        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, job_map['jobunitId'])
        del job_tree_full

        new_job_info = endpoint.getJobFull(endpoint.create_job_info_minimal(job_map['jobunitId'], job_map['jobId']))
        with ObjectModifier(new_job_info) as modifier:
            modifier.set_if_first_not_none('name', opts.name)
            modifier.set_if_first_not_none('description', opts.description)
            modifier.set_if_first_not_none('registeredModule', opts.modularize)
            modifier.set_if_first_not_none('iconId', opts.iconID)

        old_id = None
        if opts.job_id is not None:
            old_id = job_map['jobId']
            new_job_info.id = opts.job_id
        JobUtil.replace_job_info(job_tree, new_job_info, old_id)

        # Clean up and replace none with blank
        JobUtil.cleanup_and_fixnone(job_tree)

        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJob')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
