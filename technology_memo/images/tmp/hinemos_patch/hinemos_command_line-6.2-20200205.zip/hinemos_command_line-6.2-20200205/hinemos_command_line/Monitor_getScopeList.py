#!/usr/bin/env python
# -*- coding: utf-8 -*-e
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定されたファシリティの配下全てのファシリティのスコープ情報一覧を取得する

<概要>
引数で指定されたファシリティの配下全てのファシリティのスコープ情報一覧を取得して表示します。

<使用例>
[command]
    $ python Monitor_getScopeList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE

[result]
    [(scopeDataInfo){
       facilityId = "TEST_NODE"
       facilityPath = "TEST_NODE"
       outputDate = "2017/03/08 11:42:45.051"
       priority = 3
       sortValue = 0
     }]
    http://192.168.1.2:8080/HinemosWS/, getScopeList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitor import MonitorEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='facilityID')
    psr.add_option('-S', '--statusFlag', action='store', type='string', metavar='BOOL', dest='status_flag_raw', converter=SettingUtil.convert2nbool,
                    default=('true',{'INLIST':['true','false']},'NOTBLANK'), help='statusFlag')
    psr.add_option('-E', '--eventFlag', action='store', type='string', metavar='BOOL', dest='event_flag_raw', converter=SettingUtil.convert2nbool,
                    default=('true',{'INLIST':['true','false']},'NOTBLANK'), help='eventFlag')
    psr.add_option('-O', '--orderFlg', action='store', type='string', metavar='BOOL', dest='order_flg_raw', converter=SettingUtil.convert2nbool,
                    default=('false',{'INLIST':['true','false']},'NOTBLANK'), help='orderFlg')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getScopeList(opts.facility_id, opts.status_flag, opts.event_flag, opts.order_flg)
        if result is not None:
            for i in range(len(result)):
                result[i].outputDate = DateConvert.get_datetime_from_epochtime(result[i].outputDate)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getScopeList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
