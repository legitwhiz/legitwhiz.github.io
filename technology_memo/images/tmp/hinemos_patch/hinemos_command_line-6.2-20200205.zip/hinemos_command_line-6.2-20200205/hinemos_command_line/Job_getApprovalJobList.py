#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
承認対象ジョブの一覧情報を取得する

<概要>
承認対象ジョブの一覧情報を取得して表示します。

<使用例>
[command]
    $ python Job_getApprovalJobList.py -S PENDING -N 10

[result]
    [(jobApprovalInfo){
       approvalUser = None
       comment = None
       jobId = "A1"
       jobName = "a1"
       jobunitId = "J2"
       requestSentence = "hello"
       requestUser = "hinemos"
       sessionId = "20170317020313-000"
       startDate = "2017/03/17 15:03:13.393"
       status = 5
     }]
    http://192.168.1.2:8080/HinemosWS/, getApprovalJobList succeeded.
"""

import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
from hinemos.util.job import JobUtil
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.modifier import ObjectModifier


def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()

    psr.add_option('-S', '--statusList', action='store_split', type='string', metavar='STRING', dest='statusList_raw',
                    default=(None, 'NOTBLANK'), help='statusList = status1,status2,... status = ' + ' or '.join(JobUtil.enum_job_approval_status()))
    psr.add_option('-T', '--resultType', action='store', type='string', metavar='STRING', dest='resultType',
                    default=(None, 'NOTBLANK'), help='Result type = ' + ' or '.join(JobUtil._job_approval_result_type_.keys()))

    psr.add_option('--sessionID',  action='store', type='string', metavar='ID', dest='sessionID',
                    default=(None, 'NOTBLANK'), help='Session ID')
    psr.add_option('--jobunitID',  action='store', type='string', metavar='ID', dest='jobunitID',
                    default=(None, 'NOTBLANK'), help='Jobunit ID')
    psr.add_option('--jobID',  action='store', type='string', metavar='ID', dest='jobID',
                    default=(None, 'NOTBLANK'), help='Job ID')
    psr.add_option('--jobName', action='store', type='string', metavar='STRING', dest='jobName',
                    default=(None, 'NOTBLANK'), help='Job name')

    psr.add_option('--requestDateFrom', action='store', type='string', metavar='STRING', dest='requestDateFrom',
                    default=(None, {'REGEXP':[r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}), help='Datetime format: "yyyy/mm/dd HH:MM:SS"')
    psr.add_option('--requestDateTo', action='store', type='string', metavar='STRING', dest='requestDateTo',
                    default=(None, {'REGEXP':[r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}), help='Datetime format: "yyyy/mm/dd HH:MM:SS"')
    psr.add_option('--completeDateFrom', action='store', type='string', metavar='STRING', dest='completeDateFrom',
                    default=(None, {'REGEXP':[r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}), help='Datetime format: "yyyy/mm/dd HH:MM:SS"')
    psr.add_option('--completeDateTo', action='store', type='string', metavar='STRING', dest='completeDateTo',
                    default=(None, {'REGEXP':[r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}), help='Datetime format: "yyyy/mm/dd HH:MM:SS"')

    psr.add_option('--requestUser', action='store', type='string', metavar='STRING', dest='requestUser',
                    default=(None, 'NOTBLANK'), help='Request user')
    psr.add_option('--approvalUser', action='store', type='string', metavar='STRING', dest='approvalUser',
                    default=(None, 'NOTBLANK'), help='Approval user')

    psr.add_option('--requestContent', action='store', type='string', metavar='STRING', dest='requestContent',
                    default=(None, 'NOTBLANK'), help='Request content')
    psr.add_option('--comment', action='store', type='string', metavar='STRING', dest='comment',
                    default=(None, 'NOTBLANK'), help='Comment')


    psr.add_option('-N', '--limit', action='store', type='int', metavar='INT', dest='limit',
                    default=100, help='Limit (Default:100)')

    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### filtering ###
        # HC
        status_list = None
        if opts.statusList is None:
            status_list = [JobUtil.convert2job_approval_status(a) for a in JobUtil.enum_job_approval_status()]
        else:
            status_list = [JobUtil.convert2job_approval_status(a) for a in opts.statusList]

        conditions = endpoint.create_object('jobApprovalFilter')
        ObjectModifier.replace_if_not_none(
            conditions,
            approvalUser = opts.approvalUser,
            comment = opts.comment,
            endFromDate = opts.completeDateFrom,
            endToDate = opts.completeDateTo,
            jobId = opts.jobID,
            jobName = opts.jobName,
            jobunitId = opts.jobunitID,
            requestSentence = opts.requestContent,
            requestUser = opts.requestUser,
            result = JobUtil.convert2job_approval_result(opts.resultType),
            sessionId = opts.sessionID,
            startFromDate = opts.requestDateFrom,
            startToDate = opts.requestDateTo,
            statusList = status_list)

        LOGGER.debug(conditions)

        result = endpoint.getApprovalJobList(conditions, opts.limit)
        if result:
            for a in result:
                if 'startDate' in a:
                    a.startDate = DateConvert.get_datetime_from_epochtime(a.startDate)
                if 'endDate' in a:
                    a.endDate = DateConvert.get_datetime_from_epochtime(a.endDate)
        else:
            LOGGER.info('No results')

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getApprovalJobList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
