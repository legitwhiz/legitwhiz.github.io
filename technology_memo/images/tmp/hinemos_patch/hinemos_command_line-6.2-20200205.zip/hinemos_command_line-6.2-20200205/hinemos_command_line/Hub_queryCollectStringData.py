#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# ---------------------------------------------------
# Hinemos Command-Line Tools Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# ---------------------------------------------------
u"""
文字列収集情報を検索する

<概要>
文字列収集情報を検索します。

<使用例>
[command]
    $ python Hub_queryCollectStringData.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -F LINUX
    --needCount true --keywords "localhost%" --maxCount 1

[result]
    (stringQueryResult){
       count = 16
       dataList[] =
          (stringData){
             data = "<30>Apr  3 17:00:02 localhost systemd: Removed slice User Slice of root."
             facilityId = "localhost"
             monitorId = "TEST_SYSLOG"
             primaryKey =
                (collectStringDataPK){
                   collectId = 1
                   dataId = 59
                }
             tagList[] =
                (tag){
                   key = "severity"
                   value = "INFO"
                },
                (tag){
                   key = "hostname"
                   value = "localhost"
                },
                (tag){
                   key = "PRI"
                   value = "30"
                },
                (tag){
                   key = "TIMESTAMP_IN_LOG"
                   value = "1554278402000"
                },
                (tag){
                   key = "message"
                   value = "systemd: Removed slice User Slice of root."
                },
                (tag){
                   key = "facility"
                   value = "DAEMON"
                },
                (tag){
                   key = "TIMESTAMP_RECIEVED"
                   value = "1554278402116"
                },
             time = 1554278402000
          },
       offset = 0
       size = 1
       time = 11
     }
    http://127.0.0.1:8080/HinemosWS/, queryCollectStringData succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.common import DateConvert, SettingUtil, ResultPrinter
from hinemos.util.opt import MyOptionParser
from hinemos.api.hub import HubEndpoint
from hinemos.util.hub import HubUtil
from hinemos.util.modifier import ObjectModifier


def main():
    psr = MyOptionParser()
    psr.add_option('-F', '--facilityId', action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Facility ID')
    psr.add_option('-I', '--monitorId', action='store', type='string', metavar='ID', dest='monitor_id',
                   default=(None, 'NOTBLANK'), help='Monitor ID')
    psr.add_option('--keywords', action='store', type='string', metavar='STRING', dest='keywords',
                   default='', help='Keywords (default: "")')
    psr.add_option('--operator', action='store', type='string', metavar='OPERATOR', dest='operator_raw',
                   default=('AND', {'INLIST': ['AND', 'OR']}), converter=HubUtil.convert2operator,
                   help='Condition operator (default: AND)')
    psr.add_option('--offset', action='store', type='int', metavar='INT', dest='offset',
                   default=(0, 'INTEGER'), help='Fetch records starting at offset')
    psr.add_option('--maxCount', action='store', type='int', metavar='INT', dest='size',
                   default=(HubUtil.PAGE_MAX_DEFAULT, 'INTEGER'), help='Max limit of records to output')
    psr.add_option('--needCount', action='store', type='string', metavar='BOOL', dest='need_count_raw',
                   converter=SettingUtil.convert2nbool, default=('false', {'INLIST': ['true', 'false']}),
                   help='true: Get count of records (default: false)'),
    psr.add_option('--from', action='store', type='string', metavar='STRING',
                   converter=DateConvert.get_epochtime_from_datetime, dest='from_date_raw',
                   default=(None, {'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', ' must be in datetime format']}),
                   help='Fetch records after date [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('--to', action='store', type='string', metavar='STRING',
                   converter=DateConvert.get_epochtime_from_datetime, dest='to_date_raw',
                   default=(None, {'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', ' must be in datetime format']}),
                   help='Fetch records before date [yyyy/mm/dd HH:MM:SS]')

    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = HubEndpoint(opts.mgr_url, opts.user, opts.passwd)

        query_info = endpoint.create_object('stringQueryInfo')
        ObjectModifier.replace_if_not_none(
            query_info,
            to=opts.to_date,
            monitorId=opts.monitor_id,
            facilityId=opts.facility_id,
            keywords=opts.keywords,
            operator=opts.operator,
            offset=opts.offset,
            size=opts.size,
            needCount=opts.need_count)
        if opts.from_date is not None:
            setattr(query_info, 'from', opts.from_date)

        result = endpoint.queryCollectStringData(query_info)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'queryCollectStringData')
    except Exception, exc:
        return_code = ResultPrinter.failure(exc)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
