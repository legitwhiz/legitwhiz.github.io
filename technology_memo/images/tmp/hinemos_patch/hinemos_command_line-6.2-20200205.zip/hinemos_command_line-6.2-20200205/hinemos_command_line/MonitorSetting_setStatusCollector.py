#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
監視設定の収集を有効化/無効化する

<概要>
監視設定の収集を有効化/無効化します。

<使用例>
[command]
    $ python MonitorSetting_setStatusCollector.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_PNG2 -T MON_PNG -c true

[result]
    http://192.168.1.2:8080/HinemosWS/, setStatusCollector succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.util.common import ResultPrinter, SettingUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--monitorID',  action='store', type='string', metavar='ID', dest='monitor_id',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='monitorID')
    psr.add_option('-T', '--monitorTypeID',  action='store', type='string', metavar='ID', dest='monitor_type_id',
                    default=(None, 'NOTBLANK'), help='monitorTypeID')
    psr.add_option('-c', '--collect', action='store', type='string', metavar='BOOL', dest='collect_raw', converter=SettingUtil.convert2nbool,
                   default=(None, 'REQUIRED', {'INLIST':['true','false']}), help='collect=true, not collect=false')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        if opts.monitor_type_id is None:
            print("Check type...")
            info_list = endpoint.getMonitorList()
            for info in info_list:
                if opts.monitor_id == info.monitorId:
                    opts.monitor_type_id = info.monitorTypeId
                    break
            else:
                raise ErrorHandler.ObjectNotFoundError('Failed to find ' + opts.monitor_id + '\'s monitorTypeId!') 

        endpoint.setStatusCollector(opts.monitor_id, opts.monitor_type_id, opts.collect)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'setStatusCollector')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
