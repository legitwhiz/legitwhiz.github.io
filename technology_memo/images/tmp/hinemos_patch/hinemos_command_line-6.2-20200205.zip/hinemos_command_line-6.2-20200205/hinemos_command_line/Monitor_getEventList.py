#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定された条件に一致するイベント一覧情報を取得する

<概要>
引数で指定された条件に一致するイベント一覧情報を取得して表示します。

<使用例>
[command]
    $ python Monitor_getEventList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_NODE -A agent01

[result]
    ========================
    ==      SUMMARY       ==
    ========================
     INFO      :        0
     WARN      :        3
     CRITICAL  :        0
     UNKNOWN   :        0
    ------------------------
     Total     :        3
    ========================
    (eventDataInfo){
       application = "agent01"
       collectGraphFlg = False
       comment = None
       commentUser = None
       confirmUser = None
       confirmed = 0
       facilityId = "TEST_NODE"
       generationDate = "2017/03/08 11:38:45.001"
       message = "$[MESSAGE_AGENT_IS_AVAILABLE]"
       monitorDetailId = None
       monitorId = "AGENT01"
       outputDate = "2017/03/08 11:38:45.339"
       ownerRoleId = "ALL_USERS"
       pluginId = "MON_AGT_B"
       priority = 3
       scopeText = "TEST_NODE"
     }
    (eventDataInfo){
       application = "agent01"
       collectGraphFlg = False
       comment = None
       commentUser = None
       confirmUser = None
       confirmed = 0
       facilityId = "TEST_NODE"
       generationDate = "2017/03/08 11:37:45.024"
       message = "$[MESSAGE_AGENT_IS_AVAILABLE]"
       monitorDetailId = None
       monitorId = "AGENT01"
       outputDate = "2017/03/08 11:37:45.891"
       ownerRoleId = "ALL_USERS"
       pluginId = "MON_AGT_B"
       priority = 3
       scopeText = "TEST_NODE"
     }
    (eventDataInfo){
       application = "agent01"
       collectGraphFlg = False
       comment = None
       commentUser = None
       confirmUser = None
       confirmed = 0
       facilityId = "TEST_NODE"
       generationDate = "2017/03/08 11:36:45"
       message = "$[MESSAGE_AGENT_IS_AVAILABLE]"
       monitorDetailId = None
       monitorId = "AGENT01"
       outputDate = "2017/03/08 11:36:53.875"
       ownerRoleId = "ALL_USERS"
       pluginId = "MON_AGT_B"
       priority = 3
       scopeText = "TEST_NODE"
     }
    http://192.168.1.2:8080/HinemosWS/, getEventList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import SettingUtil, DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
from hinemos.api.monitor import MonitorEndpoint
from hinemos.util.notify import NotifyUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='Facility ID')

    # Search all

    psr.add_option('-P', '--priorities', action='store_split', type='string', metavar='LIST', dest='priorities_raw',
                    default=None, help='Priorities [INFO|WARN|CRITICAL|UNKNOWN]. Download all by default.')

    psr.add_option('-o', '--outputDateFrom', action='store', type='string', metavar='STRING', dest='output_date_from',
                    default=None, help='Output date from [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-O', '--outputDateTo', action='store', type='string', metavar='STRING', dest='output_date_to',
                    default=None, help='Output date to [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-g', '--createdDateFrom', action='store', type='string', metavar='STRING', dest='generation_date_from',
                    default=None, help='Created date from [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-G', '--createdDateTo', action='store', type='string', metavar='STRING', dest='generation_date_to',
                    default=None, help='Created date to [yyyy/mm/dd HH:MM:SS]')

    # Monitor ID
    psr.add_option('--monitorID', action='store', type='string', metavar='STRING', dest='monitor_id',
                    default=None, help='Monitor ID')
    # Monitor Detail ID
    psr.add_option('--monitorDetailID', action='store', type='string', metavar='STRING', dest='monitor_detail_id',
                    default=None, help='Monitor Detail ID')
    psr.add_option('-T', '--facilityType', action='store', type='int', metavar='INT', dest='facility_type',
                    default=1, help='Facility type = 0:Sub-scope Facilities Only or 1:ALL Facilities')
    psr.add_option('-A', '--application', action='store', type='string', metavar='STRING', dest='application',
                    default=None, help='Application')
    psr.add_option('-M', '--message', action='store', type='string', metavar='STRING', dest='message',
                    default=None, help='Message')
    # ConfirmFlgList
    psr.add_option('-F', '--confirmFlg', action='store_split', type='string', metavar='STRING',
                   dest='confirm_flg_type_list_raw', default=None, help='Confirm flag=UNCONFIRMED, CONFIRMED, CONFIRMING.'
                                                                    'Fetch UNCONFIRMED,CONFIRMING by default')

    psr.add_option('-N', '--confirmedUser', action='store', type='string', metavar='STRING', dest='confirmed_user',
                    default=None, help='Confirmed user')
    psr.add_option('-C', '--comment', action='store', type='string', metavar='STRING', dest='comment',
                    default=None, help='Comment')
    psr.add_option('-c', '--commentUser', action='store', type='string', metavar='STRING', dest='comment_user',
                    default=None, help='Commented user')
    # Collect Flag
    psr.add_option('-p', '--collectGraphFlg', action='store', type='string', metavar='BOOL',
                   dest='collect_graph_flg_raw', converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['on', 'off']}), help='Performance Graph Flag(on or off)')

    psr.add_option('--positionFrom', action='store', type='int', metavar='INT', dest='position_from',
                    default=None, help='Position number from NUM')
    psr.add_option('--positionTo', action='store', type='int', metavar='INT', dest='position_to',
                    default=None, help='Position number to NUM')

    # Collect flag
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=None, help='Owner role ID')
    psr.add_option('-n', '--displayNum', action='store', type='int', metavar='INT', dest='display_num',
                    default=100, help='Display number (default: 100)')

    # userItem
    psr.add_option('--userItem01', action='store', type='string', metavar='STRING', dest='user_item01',
                    default=None, help='User item01')

    psr.add_option('--userItem02', action='store', type='string', metavar='STRING', dest='user_item02',
                   default=None, help='User item02')

    psr.add_option('--userItem03', action='store', type='string', metavar='STRING', dest='user_item03',
                   default=None, help='User item03')

    psr.add_option('--userItem04', action='store', type='string', metavar='STRING', dest='user_item04',
                   default=None, help='User item04')

    psr.add_option('--userItem05', action='store', type='string', metavar='STRING', dest='user_item05',
                   default=None, help='User item05')

    psr.add_option('--userItem06', action='store', type='string', metavar='STRING', dest='user_item06',
                   default=None, help='User item06')

    psr.add_option('--userItem07', action='store', type='string', metavar='STRING', dest='user_item07',
                   default=None, help='User item07')

    psr.add_option('--userItem08', action='store', type='string', metavar='STRING', dest='user_item08',
                   default=None, help='User item08')

    psr.add_option('--userItem09', action='store', type='string', metavar='STRING', dest='user_item09',
                   default=None, help='User item09')

    psr.add_option('--userItem10', action='store', type='string', metavar='STRING', dest='user_item10',
                   default=None, help='User item10')

    psr.add_option('--userItem11', action='store', type='string', metavar='STRING', dest='user_item11',
                   default=None, help='User item11')

    psr.add_option('--userItem12', action='store', type='string', metavar='STRING', dest='user_item12',
                   default=None, help='User item12')

    psr.add_option('--userItem13', action='store', type='string', metavar='STRING', dest='user_item13',
                   default=None, help='User item13')

    psr.add_option('--userItem14', action='store', type='string', metavar='STRING', dest='user_item14',
                   default=None, help='User item14')

    psr.add_option('--userItem15', action='store', type='string', metavar='STRING', dest='user_item15',
                   default=None, help='User item15')

    psr.add_option('--userItem16', action='store', type='string', metavar='STRING', dest='user_item16',
                   default=None, help='User item16')

    psr.add_option('--userItem17', action='store', type='string', metavar='STRING', dest='user_item17',
                   default=None, help='User item17')

    psr.add_option('--userItem18', action='store', type='string', metavar='STRING', dest='user_item18',
                   default=None, help='User item18')

    psr.add_option('--userItem19', action='store', type='string', metavar='STRING', dest='user_item19',
                   default=None, help='User item19')

    psr.add_option('--userItem20', action='store', type='string', metavar='STRING', dest='user_item20',
                   default=None, help='User item20')

    psr.add_option('--userItem21', action='store', type='string', metavar='STRING', dest='user_item21',
                   default=None, help='User item21')

    psr.add_option('--userItem22', action='store', type='string', metavar='STRING', dest='user_item22',
                   default=None, help='User item22')

    psr.add_option('--userItem23', action='store', type='string', metavar='STRING', dest='user_item23',
                   default=None, help='User item23')

    psr.add_option('--userItem24', action='store', type='string', metavar='STRING', dest='user_item24',
                   default=None, help='User item24')

    psr.add_option('--userItem25', action='store', type='string', metavar='STRING', dest='user_item25',
                   default=None, help='User item25')

    psr.add_option('--userItem26', action='store', type='string', metavar='STRING', dest='user_item26',
                   default=None, help='User item26')

    psr.add_option('--userItem27', action='store', type='string', metavar='STRING', dest='user_item27',
                   default=None, help='User item27')

    psr.add_option('--userItem28', action='store', type='string', metavar='STRING', dest='user_item28',
                   default=None, help='User item28')

    psr.add_option('--userItem29', action='store', type='string', metavar='STRING', dest='user_item29',
                   default=None, help='User item29')

    psr.add_option('--userItem30', action='store', type='string', metavar='STRING', dest='user_item30',
                   default=None, help='User item30')

    psr.add_option('--userItem31', action='store', type='string', metavar='STRING', dest='user_item31',
                   default=None, help='User item31')

    psr.add_option('--userItem32', action='store', type='string', metavar='STRING', dest='user_item32',
                   default=None, help='User item32')

    psr.add_option('--userItem33', action='store', type='string', metavar='STRING', dest='user_item33',
                   default=None, help='User item33')

    psr.add_option('--userItem34', action='store', type='string', metavar='STRING', dest='user_item34',
                   default=None, help='User item34')

    psr.add_option('--userItem35', action='store', type='string', metavar='STRING', dest='user_item35',
                   default=None, help='User item35')

    psr.add_option('--userItem36', action='store', type='string', metavar='STRING', dest='user_item36',
                   default=None, help='User item36')

    psr.add_option('--userItem37', action='store', type='string', metavar='STRING', dest='user_item37',
                   default=None, help='User item37')

    psr.add_option('--userItem38', action='store', type='string', metavar='STRING', dest='user_item38',
                   default=None, help='User item38')

    psr.add_option('--userItem39', action='store', type='string', metavar='STRING', dest='user_item39',
                   default=None, help='User item39')

    psr.add_option('--userItem40', action='store', type='string', metavar='STRING', dest='user_item40',
                   default=None, help='User item40')

    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    try:
        ### login ###
        endpoint = MonitorEndpoint(opts.mgr_url, opts.user, opts.passwd)

        if opts.generation_date_from is not None:
            opts.generation_date_from = DateConvert.get_epochtime_from_datetime(opts.generation_date_from)
        if opts.generation_date_to is not None:
            opts.generation_date_to = DateConvert.get_epochtime_from_datetime(opts.generation_date_to)
        if opts.output_date_from is not None:
            opts.output_date_from = DateConvert.get_epochtime_from_datetime(opts.output_date_from)
        if opts.output_date_to is not None:
            opts.output_date_to = DateConvert.get_epochtime_from_datetime(opts.output_date_to)

        ### method edit###
        eventFilterInfo = endpoint.create_object('eventFilterInfo')
        if opts.application is not None:
            eventFilterInfo.application=opts.application
        if opts.comment is not None:
            eventFilterInfo.comment=opts.comment
        if opts.comment_user is not None:
            eventFilterInfo.commentUser=opts.comment_user
        if opts.confirmed_user is not None:
            eventFilterInfo.confirmedUser=opts.confirmed_user
        if opts.confirm_flg_type_list is None:
            opts.confirm_flg_type_list = ['UNCONFIRMED', 'CONFIRMING']
        eventFilterInfo.confirmFlgTypeList = tuple(NotifyUtil.convert2confirm_flg(confirm_flg)
                                                   for confirm_flg in opts.confirm_flg_type_list)
        if opts.facility_type is not None:
            eventFilterInfo.facilityType=opts.facility_type
        if opts.generation_date_from is not None:
            eventFilterInfo.generationDateFrom=opts.generation_date_from
        if opts.generation_date_to is not None:
            eventFilterInfo.generationDateTo=opts.generation_date_to
        if opts.message is not None:
            eventFilterInfo.message=opts.message
        if opts.output_date_from is not None:
            eventFilterInfo.outputDateFrom=opts.output_date_from
        if opts.output_date_to is not None:
            eventFilterInfo.outputDateTo=opts.output_date_to
        if opts.priorities is None:
            opts.priorities = ['INFO','WARN','CRITICAL','UNKNOWN']
        eventFilterInfo.priorityList=tuple(NotifyUtil.convert2priority(a) for a in opts.priorities)
        if opts.owner_role_id is not None:
            eventFilterInfo.ownerRoleId=opts.owner_role_id
        if opts.monitor_id is not None:
            eventFilterInfo.monitorId=opts.monitor_id
        if opts.monitor_detail_id is not None:
            eventFilterInfo.monitorDetailId=opts.monitor_detail_id
        if opts.collect_graph_flg is not None:
            eventFilterInfo.collectGraphFlg=opts.collect_graph_flg
        if opts.position_from is not None:
            eventFilterInfo.positionFrom=opts.position_from
        if opts.position_to is not None:
            eventFilterInfo.positionTo=opts.position_to

        # userItem
        if opts.user_item01 is not None:
            eventFilterInfo.userItem01=opts.user_item01
        if opts.user_item02 is not None:
            eventFilterInfo.userItem02=opts.user_item02
        if opts.user_item03 is not None:
            eventFilterInfo.userItem03=opts.user_item03
        if opts.user_item04 is not None:
            eventFilterInfo.userItem04=opts.user_item04
        if opts.user_item05 is not None:
            eventFilterInfo.userItem05=opts.user_item05
        if opts.user_item06 is not None:
            eventFilterInfo.userItem06=opts.user_item06
        if opts.user_item07 is not None:
            eventFilterInfo.userItem07=opts.user_item07
        if opts.user_item08 is not None:
            eventFilterInfo.userItem08=opts.user_item08
        if opts.user_item09 is not None:
            eventFilterInfo.userItem09=opts.user_item09
        if opts.user_item10 is not None:
            eventFilterInfo.userItem10=opts.user_item10
        if opts.user_item11 is not None:
            eventFilterInfo.userItem11=opts.user_item11
        if opts.user_item12 is not None:
            eventFilterInfo.userItem12=opts.user_item12
        if opts.user_item13 is not None:
            eventFilterInfo.userItem13=opts.user_item13
        if opts.user_item14 is not None:
            eventFilterInfo.userItem14=opts.user_item14
        if opts.user_item15 is not None:
            eventFilterInfo.userItem15=opts.user_item15
        if opts.user_item16 is not None:
            eventFilterInfo.userItem16=opts.user_item16
        if opts.user_item17 is not None:
            eventFilterInfo.userItem17=opts.user_item17
        if opts.user_item18 is not None:
            eventFilterInfo.userItem18=opts.user_item18
        if opts.user_item19 is not None:
            eventFilterInfo.userItem19=opts.user_item19
        if opts.user_item20 is not None:
            eventFilterInfo.userItem20=opts.user_item20
        if opts.user_item21 is not None:
            eventFilterInfo.userItem21=opts.user_item21
        if opts.user_item22 is not None:
            eventFilterInfo.userItem22=opts.user_item22
        if opts.user_item23 is not None:
            eventFilterInfo.userItem23=opts.user_item23
        if opts.user_item24 is not None:
            eventFilterInfo.userItem24=opts.user_item24
        if opts.user_item25 is not None:
            eventFilterInfo.userItem25=opts.user_item25
        if opts.user_item26 is not None:
            eventFilterInfo.userItem26=opts.user_item26
        if opts.user_item27 is not None:
            eventFilterInfo.userItem27=opts.user_item27
        if opts.user_item28 is not None:
            eventFilterInfo.userItem28=opts.user_item28
        if opts.user_item29 is not None:
            eventFilterInfo.userItem29=opts.user_item29
        if opts.user_item30 is not None:
            eventFilterInfo.userItem30=opts.user_item30
        if opts.user_item31 is not None:
            eventFilterInfo.userItem31=opts.user_item31
        if opts.user_item32 is not None:
            eventFilterInfo.userItem32=opts.user_item32
        if opts.user_item33 is not None:
            eventFilterInfo.userItem33=opts.user_item33
        if opts.user_item34 is not None:
            eventFilterInfo.userItem34=opts.user_item34
        if opts.user_item35 is not None:
            eventFilterInfo.userItem35=opts.user_item35
        if opts.user_item36 is not None:
            eventFilterInfo.userItem36=opts.user_item36
        if opts.user_item37 is not None:
            eventFilterInfo.userItem37=opts.user_item37
        if opts.user_item38 is not None:
            eventFilterInfo.userItem38=opts.user_item38
        if opts.user_item39 is not None:
            eventFilterInfo.userItem39=opts.user_item39
        if opts.user_item40 is not None:
            eventFilterInfo.userItem40=opts.user_item40

        # do
        result = endpoint.getEventList(opts.facility_id, eventFilterInfo, opts.display_num)

        total = result.total
        # If there are more on DB, the total of result will be display_num+1
        if total > opts.display_num:
            total = opts.display_num

        # SUMMARY
        print('='*24)
        print('=={:^20}=='.format('SUMMARY'))
        print('='*24)
        print(' {0:10}: {1:8d}'.format('INFO', result.info))
        print(' {0:10}: {1:8d}'.format('WARN', result.warning))
        print(' {0:10}: {1:8d}'.format('CRITICAL', result.critical))
        print(' {0:10}: {1:8d}'.format('UNKNOWN', result.unKnown))
        print('-'*24)
        print(' {0:10}: {1:8d}'.format('Total', total))
        print('='*24)

        # Display eventList
        if 'eventList' in result:
            for x in result.eventList:
                x.generationDate = DateConvert.get_datetime_from_epochtime(x.generationDate)
                x.outputDate = DateConvert.get_datetime_from_epochtime(x.outputDate)
                if 'commentDate' in x:
                    x.commentDate = DateConvert.get_datetime_from_epochtime(x.commentDate)
                print x

        return_code = ResultPrinter.success(None, opts.mgr_url, 'getEventList')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
        import traceback
        traceback.print_exc()
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
