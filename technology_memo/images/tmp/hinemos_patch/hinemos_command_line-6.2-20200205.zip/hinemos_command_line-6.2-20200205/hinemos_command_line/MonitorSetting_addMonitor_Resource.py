#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
リソース監視の監視設定を登録する

<概要>
リソース監視の監視設定を登録します。

<使用例>
[command]
    $ python MonitorSetting_addMonitor_Resource.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I RES1 -A MYAPP -F NODE001 -i CPU0100_CPU_UTIL

[result]
    http://192.168.1.2:8080/HinemosWS/, addMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.api.performancecollectmaster import PerformanceCollectMasterEndpoint
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {
        'infoLowerThreshold': '0[%]',
        'infoUpperThreshold': '0[%]',
        'warnLowerThreshold': '0[%]',
        'warnUpperThreshold': '0[%]'
    }
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_add_args_parser(help_default_info)
    psr.add_option('-i', '--monitorItemCode', action='store', type='string',
                   metavar='STRING', dest='item_code',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='item code[device] (e.g. CPU0100_CPU_UTIL,MEM0100_MEM_UTIL, etc.)')
    psr.add_option('-v', '--monitorDevice', action='store', type='string',
                   metavar='STRING', dest='item_code_dev',
                   default=(None, 'NOTBLANK'),
                   help='device (e.g. "", *ALL*, cpu0, sda1, eth0)')
    psr.add_option('-B', '--collectBreakdownDetail', action='store', type='string',
                   metavar='STRING', dest='collect_breakdown_detail_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='collect =true, do not collect =false')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Check master list at first
        endpoint = PerformanceCollectMasterEndpoint(
            opts.mgr_url, opts.user, opts.passwd)
        collect_master_info = endpoint.get_collect_master_info()
        # item_code_mst_data_map = { x.itemCode: x for x in collect_master_info.collectorItemCodeMstDataList} #py27
        item_code_mst_data_map = dict(zip(
            [x.itemCode for x in collect_master_info.collectorItemCodeMstDataList], collect_master_info.collectorItemCodeMstDataList))
        polling_mst_data_map = {}
        for x in collect_master_info.collectorPollingMstDataList:
            if x.itemCode in polling_mst_data_map:
                polling_mst_data_map[x.itemCode][x.collectMethod] = x
            else:
                polling_mst_data_map[x.itemCode] = {x.collectMethod: x}
        del collect_master_info

        if opts.item_code not in item_code_mst_data_map:
            print 'monitorItem must be one of: '
            for x in polling_mst_data_map.itervalues():
                for y in x.itervalues():
                    print '\t%s : %s, collect by %s for platform = %s' % (y.itemCode, item_code_mst_data_map[y.itemCode].itemName, y.collectMethod, y.platformId)
            raise ErrorHandler.ObjectNotFoundError(
                'the specified monitorItem(%s) does not existed!' % opts.item_code)
        del polling_mst_data_map

        # check subitemcode(device)
        dev_type = item_code_mst_data_map[opts.item_code].deviceType
        if dev_type is not None and not opts.item_code_dev:
            raise ErrorHandler.ArgumentError(
                'monitorDevice(%s) is required! (hint: *ALL* for all)' % dev_type)

        # TODO item_code_dev validate and OS check

        # Login
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        args = vars(opts)
        args['item_code_mst_data_list'] = item_code_mst_data_map.values()
        endpoint.add_monitor_pref(args)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
