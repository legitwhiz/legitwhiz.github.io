#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.model import BasicObject


class jobCommandInfo(BasicObject):
    __keylist__ = ['commandRetry', 'commandRetryFlg', 'facilityID', 'messageRetry', 'messageRetryEndFlg', 'messageRetryEndValue', 'processingMethod', 'scope', 'specifyUser', 'startCommand', 'stopCommand', 'stopType', 'user']

    commandRetry = None
    commandRetryFlg = None
    facilityID = None
    messageRetry = None
    messageRetryEndFlg = None
    messageRetryEndValue = None
    processingMethod = None
    scope = None
    specifyUser = None
    startCommand = None
    stopCommand = None
    stopType = None
    user = None

class jobWaitRuleInfo(BasicObject):
    __keylist__ = ['calendar', 'calendarEndStatus', 'calendarEndValue', 'calendarId', 'condition', 'endCondition', 'endStatus', 'endValue', 'end_delay', 'end_delay_condition_type', 'end_delay_job', 'end_delay_job_value', 'end_delay_notify', 'end_delay_notify_priority', 'end_delay_operation', 'end_delay_operation_end_status', 'end_delay_operation_end_value', 'end_delay_operation_type', 'end_delay_session', 'end_delay_session_value', 'end_delay_time', 'end_delay_time_value', 'multiplicityEndValue', 'multiplicityNotify', 'multiplicityNotifyPriority', 'multiplicityOperation', 'object', 'skip', 'skipEndStatus', 'skipEndValue', 'start_delay', 'start_delay_condition_type', 'start_delay_notify', 'start_delay_notify_priority', 'start_delay_operation', 'start_delay_operation_end_status', 'start_delay_operation_end_value', 'start_delay_operation_type', 'start_delay_session', 'start_delay_session_value', 'start_delay_time', 'start_delay_time_value', 'suspend']

    calendar = None
    calendarEndStatus = None
    calendarEndValue = None
    calendarId = None
    condition = None
    endCondition = None
    endStatus = None
    endValue = None
    end_delay = None
    end_delay_condition_type = None
    end_delay_job = None
    end_delay_job_value = None
    end_delay_notify = None
    end_delay_notify_priority = None
    end_delay_operation = None
    end_delay_operation_end_status = None
    end_delay_operation_end_value = None
    end_delay_operation_type = None
    end_delay_session = None
    end_delay_session_value = None
    end_delay_time = None
    end_delay_time_value = None
    multiplicityEndValue = None
    multiplicityNotify = None
    multiplicityNotifyPriority = None
    multiplicityOperation = None
    object= []
    skip = None
    skipEndStatus = None
    skipEndValue = None
    start_delay = None
    start_delay_condition_type = None
    start_delay_notify = None
    start_delay_notify_priority = None
    start_delay_operation = None
    start_delay_operation_end_status = None
    start_delay_operation_end_value = None
    start_delay_operation_type = None
    start_delay_session = None
    start_delay_session_value = None
    start_delay_time = None
    start_delay_time_value = None
    suspend = None

    def __init__(self):
        BasicObject.__init__(self)

        self.object= []

class jobFileInfo(BasicObject):
    __keylist__ = ['checkFlg', 'commandRetry', 'commandRetryFlg', 'compressionFlg', 'destDirectory', 'destFacilityID', 'destScope', 'destWorkDir', 'messageRetry', 'messageRetryEndFlg', 'messageRetryEndValue', 'processingMethod', 'specifyUser', 'srcFacilityID', 'srcFile', 'srcScope', 'srcWorkDir', 'user']

    checkFlg = None
    commandRetry = None
    commandRetryFlg = None
    compressionFlg = None
    destDirectory = None
    destFacilityID = None
    destScope = None
    destWorkDir = None
    messageRetry = None
    messageRetryEndFlg = None
    messageRetryEndValue = None
    processingMethod = None
    specifyUser = None
    srcFacilityID = None
    srcFile = None
    srcScope = None
    srcWorkDir = None
    user = None

class jobInfo(BasicObject):
    __keylist__ = ['abnormalPriority', 'approvalReqMailBody', 'approvalReqMailTitle', 'approvalReqRoleId', 'approvalReqSentence', 'approvalReqUserId', 'beginPriority', 'command', 'createTime', 'createUser', 'description', 'endStatus',
                   'file', 'iconId', 'id', 'jobunitId', 'monitor', 'name', 'normalPriority', 'notifyRelationInfos', 'ownerRoleId', 'param',
                   'parentId', 'propertyFull', 'referJobId', 'referJobSelectType', 'referJobUnitId', 'registeredModule', 'type', 'updateTime', 'updateUser', 'useApprovalReqSentence', 'waitRule', 'warnPriority']

    abnormalPriority = None
    approvalReqMailBody = None
    approvalReqMailTitle = None
    approvalReqRoleId = None
    approvalReqSentence = None
    approvalReqUserId = None
    beginPriority = None
    command = None #jobCommandInfo()
    createTime = None
    createUser = None
    description = None
    endStatus= []
    file = None #jobFileInfo()
    iconId = None
    id = None
    jobunitId = None
    monitor = None
    name = None
    normalPriority = None
    notifyRelationInfos= []
    ownerRoleId = None
    param= []
    parentId = None
    propertyFull = None
    referJobId = None
    referJobSelectType = None
    referJobUnitId = None
    registeredModule = None
    type = None
    updateTime = None
    updateUser = None
    useApprovalReqSentence = None
    waitRule = None #jobWaitRuleInfo()
    warnPriority = None

    def __init__(self):
        BasicObject.__init__(self)

        self.command = jobCommandInfo()
        self.endStatus = []
        self.file = jobFileInfo()
        self.monitor = monitorJobInfo()
        self.notifyRelationInfos = []
        self.param = []
        self.waitRule = jobWaitRuleInfo()

class jobDetailInfo(BasicObject):
    __keylist__ = ['endDate', 'endStatus', 'endValue', 'facilityId', 'scope', 'startDate', 'startMinute', 'status', 'waitRuleTime']

    endDate = None
    endStatus = None
    endValue = None
    facilityId = None
    scope = None
    startDate = None
    startMinute = None
    status = None
    waitRuleTime = None

class monitorJobInfo(BasicObject):
    __keylist__ = ['commandRetry', 'commandRetryFlg', 'facilityID', 'monitorCriticalEndValue', 'monitorId', 'monitorInfoEndValue', 'monitorUnknownEndValue', 'monitorWaitEndValue', 'monitorWaitTime', 'monitorWarnEndValue', 'processingMethod', 'scope']

    commandRetry = None
    commandRetryFlg = None
    facilityID = None
    monitorCriticalEndValue = None
    monitorId = None
    monitorInfoEndValue = None
    monitorUnknownEndValue = None
    monitorWaitEndValue = None
    monitorWaitTime = None
    monitorWarnEndValue = None
    processingMethod = None
    scope = None

''' JobEndpoint.create_object('jobTreeItem')
'''
class jobTreeItem(BasicObject):
    __keylist__ = ['children', 'data', 'detail', 'parent']

    children= []
    data = None #jobInfo()
    detail = None #jobDetailInfo()
    parent = None #jobTreeItem() # Recursive

    def __init__(self):
        BasicObject.__init__(self)

        self.children= []
        self.data = jobInfo()
        self.detail = jobDetailInfo()
        #parent = None #Need to add manually

''' JobEndpoint.create_object('jobEndStatusInfo')
'''
class jobEndStatusInfo(BasicObject):
    __keylist__ = ['endRangeValue', 'startRangeValue', 'type', 'value']

    endRangeValue = None
    startRangeValue = None
    type = None
    value = None

''' JobEndpoint.create_object('ns2:notifyRelationInfo')
'''
class notifyRelationInfo(BasicObject):
    __keylist__ = ['notifyGroupId', 'notifyId', 'notifyType']

    notifyGroupId = None
    notifyId = None
    notifyType = None

''' JobEndpoint.create_object('jobParameterInfo')
'''
class jobParameterInfo(BasicObject):
    __keylist__ = ['description', 'paramId', 'type', 'value']

    description = None
    paramId = None
    type = None
    value = None

''' JobEndpoint.create_object('jobObjectInfo')
'''
class jobObjectInfo(BasicObject):
    __keylist__ = ['decisionCondition', 'decisionValue01', 'decisionValue02', 'description', 'jobId', 'jobName', 'startMinute', 'time', 'type', 'value']

    decisionCondition = None
    decisionValue01 = None
    decisionValue02 = None
    description = None
    jobId = None
    jobName = None
    startMinute = None
    time = None
    type = None
    value = None

''' JobEndpoint.create_object('jobEnvVariableInfo')
'''
class jobEnvVariableInfo(BasicObject):
    __keylist__ = ['description', 'envVariableId', 'value']

    description = None
    envVariableId = None
    type = None

''' JobEndpoint.create_object('jobCommandParamList')
'''
class jobCommandParamList(BasicObject):
    __keylist__ = ['jobStandardOutputFlg', 'paramId', 'value']

    jobStandardOutputFlg = None
    paramId = None
    value = None

