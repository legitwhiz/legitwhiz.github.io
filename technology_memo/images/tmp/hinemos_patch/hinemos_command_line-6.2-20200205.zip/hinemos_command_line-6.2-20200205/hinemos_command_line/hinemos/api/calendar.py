#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.common import DateConvert
from hinemos.util.common import is_empty
from hinemos.util.calendar import CalendarUtil

# HC for Utility data consistence
def formatted_calendar(info):
    if info.description is None:
        info.description = ''
    return info

class CalendarEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'Calendar')

    # カレンダ一覧を取得します
    def getAllCalendarList(self):
        try:
            return self._client.service.getAllCalendarList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addCalendarPattern failed, ' + str(e))
            raise ErrorHandler.APIError('addCalendarPattern failed, ' + str(e))

    # オーナーロールIDを条件としてカレンダ一覧を取得します
    def getCalendarList(self, ownerRoleId):
        try:
            return self._client.service.getCalendarList(ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addCalendarPattern failed, ' + str(e))
            raise ErrorHandler.APIError('addCalendarPattern failed, ' + str(e))

    # 引数で指定したカレンダーIDに対応するカレンダ情報を取得します
    def getCalendar(self, calendarId):
        try:
            return self._client.service.getCalendar(calendarId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getCalendar failed, '  +str(e))
            raise ErrorHandler.APIError('getCalendar failed, ' + str(e))

    # カレンダ(基本)情報を登録します
    def addCalendar(self, calendarInfo):
        # 新仕様対応
        if 'calendarDetailList' in calendarInfo:
            for info in calendarInfo.calendarDetailList:
                # Reset to default values
                if is_empty(info.substituteFlg):
                    info.substituteFlg = False
                if is_empty(info.substituteLimit):
                    info.substituteLimit = 10
                if is_empty(info.substituteTime):
                    info.substituteTime = 24

        try:
            return self._client.service.addCalendar(formatted_calendar(calendarInfo))
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addCalendarPattern failed, ' + str(e))
            raise ErrorHandler.APIError('addCalendarPattern failed, ' + str(e))

    # カレンダ(基本)情報を削除します
    def deleteCalendar(self, calendarIdList):
        try:
            return self._client.service.deleteCalendar(calendarIdList)
        except Exception, e:
            err_msg = 'deleteCalendar(%s) failed, %s' % (calendarIdList, str(e))
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(err_msg)
            raise ErrorHandler.APIError(err_msg)

    # 引数で指定された、年月の1日から順番に、まるさんかくばつを詰めたArrayListを返す
    def getCalendarMonth(self, calendarId, year, month):
        try:
            return self._client.service.getCalendarMonth(calendarId, year, month)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getCalendarMonth failed, ' + str(e))
            raise ErrorHandler.APIError('getCalendarMonth failed, ' + str(e))

    # スケジュールバーを表示するための情報取得
    def getCalendarWeek(self, calendarId, year, month, day):
        try:
            return self._client.service.getCalendarWeek(calendarId, year, month, day)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addCalendarPattern failed, ' + str(e))
            raise ErrorHandler.APIError('addCalendarPattern failed, ' + str(e))

    # カレンダ[カレンダパターン]情報一覧を取得します
    def getCalendarPatternList(self, ownerRoleId):
        try:
            return self._client.service.getCalendarPatternList(ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getCalendarPatternList failed, ' + str(e))
            raise ErrorHandler.APIError('getCalendarPatternList failed, ' + str(e))

    # 引数で指定したIDに対応するカレンダ[カレンダパターン]情報を取得します
    def getCalendarPattern(self, calendarPatternId):
        try:
            return self._client.service.getCalendarPattern(calendarPatternId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getCalendarPattern failed, ' + str(e))
            raise ErrorHandler.APIError('getCalendarPattern failed, ' + str(e))

    # カレンダ[カレンダパターン]情報を登録します
    def addCalendarPattern(self, calendarPatternInfo):
        try:
            return self._client.service.addCalendarPattern(calendarPatternInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addCalendarPattern failed, ' + str(e))
            raise ErrorHandler.APIError('addCalendarPattern failed, ' + str(e))

    # カレンダ[カレンダパターン]情報を変更します
    def modifyCalendarPattern(self, calendarPatternInfo):
        try:
            return self._client.service.modifyCalendarPattern(calendarPatternInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyCalendarPattern failed, ' + str(e))
            raise ErrorHandler.APIError('modifyCalendarPattern failed, ' + str(e))

    # カレンダ[カレンダパターン]情報を削除します
    def deleteCalendarPattern(self, calendarPatternId):
        try:
            return self._client.service.deleteCalendarPattern(calendarPatternId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteCalendarPattern failed, ' + str(e))
            raise ErrorHandler.APIError('deleteCalendarPattern failed, ' + str(e))


    def create_calendar_info(self, calendar_id=None, name=None, description='', owner_role_id=None, valid_time_from=None, valid_time_to=None, calendar_detail_info_list=None):
        # Default
        if owner_role_id is None:
            owner_role_id = 'ALL_USERS'
        if description is None:
            description = ''

        try:
            info = self._client.factory.create('calendarInfo')

            info.calendarId = calendar_id
            info.calendarName = name
            info.description = description
            info.ownerRoleId = owner_role_id
            info.validTimeFrom = valid_time_from
            info.validTimeTo = valid_time_to
            if calendar_detail_info_list:
                info.calendarDetailList.extend(calendar_detail_info_list)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create roleInfo failed, ' + str(e))

    def get_all_calendar_list_formatted(self):
        result = self.getAllCalendarList()
        if result is not None:
            for res in result:
                res.regDate = DateConvert.get_datetime_from_epochtime(res.regDate)
                res.updateDate = DateConvert.get_datetime_from_epochtime(res.updateDate)
                res.validTimeFrom = DateConvert.get_datetime_from_epochtime(res.validTimeFrom)
                res.validTimeTo = DateConvert.get_datetime_from_epochtime(res.validTimeTo)
        return result

    def _str2ymd_list(self, patterns):
        try:
            ymd_list = []
            for p in patterns.split(','):
                p = p.split('/')
                ymd = self._client.factory.create('ymd')
                ymd.year = int(p[0])
                ymd.month = int(p[1])
                ymd.day = int(p[2])
                ymd_list.append(ymd)
            return ymd_list
        except Exception, e:
            raise Exception('YMD pattern setting failed ,' + str(e))

    def create_calendar_pattern_info(self, calendar_pattern_id, name, owner_role_id, patterns=''):
        try:
            info = self._client.factory.create('calendarPatternInfo')
            info.calPatternId = calendar_pattern_id
            info.calPatternName = name
            info.ownerRoleId = owner_role_id
            if patterns != '':
                info.ymd = self._str2ymd_list(patterns)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create roleInfo failed, ' + str(e))

    def get_calendar_pattern_formatted(self, calendar_pattern_id):
        result = self.getCalendarPattern(calendar_pattern_id)
        if result is not None:
            result.regDate = DateConvert.get_datetime_from_epochtime(result.regDate)
            result.updateDate = DateConvert.get_datetime_from_epochtime(result.updateDate)
        return result

    def modify_calendar_pattern_x(self, calendar_pattern_id, name=None, add_ymds=None, delete_ymds=None):
        calendar_pattern_info = self.getCalendarPattern(calendar_pattern_id)

        if name is not None and name != '':
            calendar_pattern_info.calPatternName = name

        # Delete YMD
        if delete_ymds is not None and delete_ymds != '' and hasattr(calendar_pattern_info, 'ymd'):
            delete_ymd_list = self._str2ymd_list(delete_ymds)
            for ymd1 in delete_ymd_list:
                for ymd2 in calendar_pattern_info.ymd:
                    if CalendarUtil.ymd_equal(ymd1, ymd2):
                        calendar_pattern_info.ymd.remove(ymd2)
                        break
        # Add YMD
        if add_ymds is not None and add_ymds != '':
            add_ymd_list = self._str2ymd_list(add_ymds)
            if hasattr(calendar_pattern_info,'ymd'):
                calendar_pattern_info.ymd.append(add_ymd_list)
            else:
                calendar_pattern_info.ymd = add_ymd_list

        self.modifyCalendarPattern(calendar_pattern_info)

    def get_calendar_pattern_list_formatted(self, owner_role_id):
        result = self.getCalendarPatternList(owner_role_id)
        if result is not None:
            for res in result:
                res.regDate = DateConvert.get_datetime_from_epochtime(res.regDate)
                res.updateDate = DateConvert.get_datetime_from_epochtime(res.updateDate)
        return result

    def get_calendar_list_formatted(self, owner_role_id):
        result = self.get_calendar_list(owner_role_id)
        if result is not None:
            for res in result:
                print res
                res.regDate = DateConvert.get_datetime_from_epochtime(res.regDate)
                res.updateDate = DateConvert.get_datetime_from_epochtime(res.updateDate)
                res.validTimeFrom = DateConvert.get_datetime_from_epochtime(res.validTimeFrom)
                res.validTimeTo = DateConvert.get_datetime_from_epochtime(res.validTimeTo)
        return result

    def modifyCalendar(self, calendar_info):
        # 新仕様対応
#        if 'calendarDetailList' in calendar_info:
#            for info in calendar_info.calendarDetailList:
#                # Reset to default values
#                if is_empty(info.substituteFlg):
#                    info.substituteFlg = False
#                if is_empty(info.substituteLimit):
#                    info.substituteLimit = 10
#                if is_empty(info.substituteTime):
#                    info.substituteTime = 24
        try:
            return self._client.service.modifyCalendar(formatted_calendar(calendar_info))
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyCalendarPattern failed, ' + str(e))
            raise ErrorHandler.APIError('modifyCalendarPattern failed, ' + str(e))

    def create_calendar_detail_info(self, description=None, afterday=None, substitute_flg=None, substitute_limit=None, substitute_time=None, time_from=None, time_to=None, operate_flg=None):
        # Default
        if description is None: description = ''
        if operate_flg is None: operate_flg = True
        if afterday is None: afterday = 0
        if substitute_flg is None: substitute_flg = False
        if substitute_limit is None: substitute_limit = 10
        if substitute_time is None: substitute_time = 24
        if time_from is None: time_from = DateConvert.get_epochtime_from_time('00:00:00')
        if time_to is None: time_to = DateConvert.get_epochtime_from_time('24:00:00')

        obj_name = 'calendarDetailInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.description = description
            info.afterday = afterday
            info.substituteFlg = substitute_flg
            info.substituteLimit = substitute_limit
            info.substituteTime = substitute_time
            info.timeFrom = time_from
            info.timeTo = time_to
            info.operateFlg = operate_flg
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))
