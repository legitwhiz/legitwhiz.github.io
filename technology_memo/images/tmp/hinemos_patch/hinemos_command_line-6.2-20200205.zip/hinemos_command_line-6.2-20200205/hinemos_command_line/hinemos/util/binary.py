# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------
import time
from hinemos.util.modifier import ObjectModifier


def create_binary_query(endpoint, args):
    # バイナリの検索条件設定.
    query = endpoint.get_obj('ns1', 'binaryQueryInfo')
    ObjectModifier.replace_if_not_none(
        query,
        **{'monitorId': args['monitorId'],
           'facilityId': args['facilityId'],
           'from': args['from'],
           'to': args['to'],
           'keywords': args['keywords'],
           'needCount': True,  # TODO check firstQuery = true only ?????
           'offset': args['dispOffset'],
           'operator': args['operator'],
           'size': args['size'],
           'textEncoding': args['textEncoding'],
           'tag': None})
    return query


def prepare_binary_record_download(args, query_res):
    item_list = filter(
        lambda x: x.recordKey == args['recordKey'], query_res.dataList)
    if len(item_list) is 0:
        raise Exception('No item matches recordKey: %s' % args['recordKey'])
    item = item_list.pop()
    primaryKey = item.primaryKey
    fileName = filter(lambda x: x.key == 'FileName', item.tagList)\
        .pop()['value'].split('/').pop()
    return primaryKey, fileName


def prepare_binary_records_download(args, query_res, query):
    fileName = time.strftime('%Y%m%d%H%M%S.zip')
    dlList = map(lambda x: {
        'primaryKey': x.primaryKey,
        'queryInfo': query,
        'recordKey': x.recordKey
    }, query_res.dataList)
    return fileName, dlList
