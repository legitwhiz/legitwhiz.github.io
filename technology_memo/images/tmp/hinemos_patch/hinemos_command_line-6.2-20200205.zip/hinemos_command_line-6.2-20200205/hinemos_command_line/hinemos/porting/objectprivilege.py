# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import copy
from hinemos.util.common import ResultPrinter
from hinemos.util.xmlprocessor import XMLReader
from hinemos import porting
from hinemos.porting import elem_attr2info
from hinemos.api.exceptions import APIError

class ObjectPrivilegeImporter(object):
    _porting_code = 'OBJPRIV'
    _porting_xml = None
    _endpoint = None

    def __init__(self, xml_directory, endpoint):
        # XML readers
        (self._porting_xml, ) = (XMLReader(x[0], xml_directory) for x in porting.xml_list[ObjectPrivilegeImporter._porting_code])

        # login
        self._endpoint = endpoint

    def run(self, filter_object_type=None, filter_object_id=None, stop_if_error=False, update_mode=False, delete_mode=False):
        done_list = set()
        info_tpl = self._endpoint.create_object('objectPrivilegeInfo')

        elem_root = self._porting_xml.element_tree.getroot()
        for key_elem in elem_root.iterfind('ObjectPrivilegeInfo'):
            # store as key pair
            key = (key_elem.attrib['objectType'], key_elem.attrib['objectId'])

            # Filter
            if filter_object_type is not None:
                if key[0] != filter_object_type:
                    continue
            if filter_object_id is not None:
                if key[1] != filter_object_id:
                    continue

            # Skip if is done already
            if key in done_list:
                continue

            # put to done list
            done_list.add(key)

            ResultPrinter.info('addObjectPrivilege %s, %s...' % (key[0], key[1]))
            try:
                # Check if already exists
                filter_info = self._endpoint.create_object_privilege_filter_info(object_id=key[1], object_type=key[0])
                exists = len(self._endpoint.getObjectPrivilegeInfoList(filter_info)) > 0
                # add list to db
                if not update_mode: # !-u
                    if exists:
                        raise APIError('addObjectPrivilege failed. Setting already exists.')
                else:
                    if exists:
                        ResultPrinter.info('updateObjectPrivilege %s, %s...' % (key[0], key[1]))

                info_list = []
                for elem in elem_root.iterfind('ObjectPrivilegeInfo'):
                    if key == (elem.attrib['objectType'], elem.attrib['objectId']):
                        ResultPrinter.info('\t%s, %s' % (elem.attrib['roleId'], elem.attrib['objectPrivilege']))
                        info = copy.deepcopy(info_tpl)
                        elem_attr2info(elem.attrib, info)
                        info_list.append(info)

                self._endpoint.replaceObjectPrivilegeInfo(key[0], key[1], info_list)
            except Exception, e:
                if stop_if_error:
                    raise e
                else:
                    ResultPrinter.failure(e)

        # Delete settings do not exist in XML (-d)
        if delete_mode:
            # Load XML info list
            imported_id_list = set((elem.get('objectType'),elem.get('objectId')) for elem in elem_root.iterfind('ObjectPrivilegeInfo'))
            # Get DB info list
            existed_id_list = [(info.objectType,info.objectId) for info in self._endpoint.getObjectPrivilegeInfoList(None)]

            # Compare lists and perform deletion
            for info_id in existed_id_list:
                try:
                    if info_id not in imported_id_list:
                        ResultPrinter.info('deleteObjectPrivilege %s, %s...' % info_id)
                        self._endpoint.replaceObjectPrivilegeInfo(info_id[0], info_id[1], [])
                except Exception, e:
                    if stop_if_error:
                        raise e
                    else:
                        ResultPrinter.failure(e)
