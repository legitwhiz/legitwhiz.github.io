#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
from hinemos.api.endpoint import Endpoint
import hinemos.api.exceptions as ErrorHandler

class RepositoryEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'Repository')

    # ファシリティツリー(スコープツリー)取得を取得します
    def getFacilityTree(self, ownerRoleId):
        try:
            return self._client.service.getFacilityTree(ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getFacilityTree failed, ' + str(e))
            raise ErrorHandler.APIError('getFacilityTree failed, ' + str(e))

    # ファシリティツリー(スコープツリー)取得を取得します
    def getExecTargetFacilityTreeByFacilityId(self, facility_id, ownerRoleId):
        try:
            return self._client.service.getExecTargetFacilityTreeByFacilityId(facility_id, ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getExecTargetFacilityTreeByFacilityId failed, ' + str(e))
            raise ErrorHandler.APIError('getExecTargetFacilityTreeByFacilityId failed, ' + str(e))

    # ファシリティツリー(ノードツリー)取得を取得します。
    def getNodeFacilityTree(self, ownerRoleId):
        try:
            return self._client.service.getNodeFacilityTree(ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNodeFacilityTree failed, ' + str(e))
            raise ErrorHandler.APIError('getNodeFacilityTree failed, ' + str(e))

    # ノード一覧を取得します
    def getNodeListAll(self):
        try:
            return self._client.service.getNodeListAll()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNodeListAll failed, ' + str(e))
            raise ErrorHandler.APIError('getNodeListAll failed, ' + str(e))

    # ノード一覧を取得します
    def getFilterNodeList(self, nodeInfo):
        try:
            return self._client.service.getFilterNodeList(nodeInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getFilterNodeList failed, ' + str(e))
            raise ErrorHandler.APIError('getFilterNodeList failed, ' + str(e))

    # 監視・ジョブ等の処理を実行する対象となる、ファシリティIDのリストを取得します。
    def  getExecTargetFacilityIdList(self, facilityId, ownerRoleId):
        try:
            return self._client.service.getExecTargetFacilityIdList(facilityId, ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getExecTargetFacilityIdList failed, ' + str(e))
            raise ErrorHandler.APIError('getExecTargetFacilityIdList failed, ' + str(e))

    # ノードの詳細プロパティを取得します。
    def getNode(self, facilityId):
        try:
            return self._client.service.getNode(facilityId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNode failed, ' + str(e))
            raise ErrorHandler.APIError('getNode failed, ' + str(e))

    # ノードの詳細プロパティ（構成情報含めて）を取得します。
    def getNodeFull(self, facility_id):
        try:
            return self._client.service.getNodeFull(facility_id)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNodeFull failed, ' + str(e))
            raise ErrorHandler.APIError('getNodeFull failed, ' + str(e))

    # ファシリティパスを取得します。
    def getFacilityPath(self, facilityId, parentFacilityId):
        try:
            return self._client.service.getFacilityPath(facilityId, parentFacilityId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getFacilityPath failed, ' + str(e))
            raise ErrorHandler.APIError('getFacilityPath failed, ' + str(e))

    # SNMPを利用してノードの情報を取得します。
    def getNodePropertyBySNMP(self, ipAddress, port, community, version, facilityID=None, securityLevel=None, user=None, authPass=None, privPass=None, authProtocol=None, privProtocol=None):
        # Default
        if version == '1':
            version = 0
        elif version is None or version =='2c':
            version = 1
        elif version == '3':
            if user is None:
                user = 'root'
            if securityLevel is None:
                securityLevel = 'noauth_nopriv'
            if authProtocol is None:
                authProtocol = 'MD5'
            if privProtocol is None:
                privProtocol = 'DES'

        try:
            return self._client.service.getNodePropertyBySNMP(ipAddress, port, community, version, facilityID, securityLevel, user, authPass, privPass, authProtocol, privProtocol)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNodePropertyBySNMP failed, ' + str(e))
            raise ErrorHandler.APIError('getNodePropertyBySNMP failed, ' + str(e))

    # ノードを新規に追加します。
    def addNode(self, nodeInfo):
        try:
            return self._client.service.addNode(nodeInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNode failed, ' + str(e))
            raise ErrorHandler.APIError('getNode failed, ' + str(e))

    # ノードを変更します
    def modifyNode(self, nodeInfo):
        try:
            return self._client.service.modifyNode(nodeInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyNode failed, ' + str(e))
            raise ErrorHandler.APIError('modifyNode failed, ' + str(e))

    # ノード情報を削除します。
    def deleteNode(self, facilityIds):
        try:
            return self._client.service.deleteNode(facilityIds)
        except Exception, e:
            msg = 'deleteNode(%s) failed, ' % facilityIds
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(msg + str(e))
            raise ErrorHandler.APIError(msg + str(e))

    # ファシリティ一覧を取得します。
    def getFacilityList(self, parentFacilityId):
        try:
            return self._client.service.getFacilityList(parentFacilityId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getFacilityList failed, ' + str(e))
            raise ErrorHandler.APIError('getFacilityList failed, ' + str(e))

    # スコープ用プロパティ情報を取得します
    def getScope(self, facilityId):
        try:
            return self._client.service.getScope(facilityId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getScope failed, ' + str(e))
            raise ErrorHandler.APIError('getScope failed, ' + str(e))

    # スコープを新規に追加します
    def addScope(self, parentFacilityId, scopeInfo):
        # 要確認仕様：xmlのなかにfacilityTypeがない。Utilityではどうか確認。　ここでハードコードすべきではない。
        if scopeInfo.facilityType is None:
            scopeInfo.facilityType = 0

        # 6.0から仕様：マネージャ側返還すべき
        if parentFacilityId == '_ROOT_':
            parentFacilityId = ''

        try:
            # TODO: 要確認。だぶっても登録できてしまう。エラー無。マネージャ側で対応すべき。
            return self._client.service.addScope(parentFacilityId, scopeInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addScope failed, ' + str(e))
            raise ErrorHandler.APIError('addScope failed, ' + str(e))

    # スコープの情報を変更します
    def modifyScope(self, scopeInfo):
        try:
            return self._client.service.modifyScope(scopeInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyScope failed, ' + str(e))
            raise ErrorHandler.APIError('modifyScope failed, ' + str(e))

    # スコープ情報を削除します
    def deleteScope(self, facilityIds):
        try:
            return self._client.service.deleteScope(facilityIds)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteScope failed, ' + str(e))
            raise ErrorHandler.APIError('deleteScope failed, ' + str(e))

    # 割当ノード一覧を取得します
    def getNodeList(self, parentFacilityId, level):
        try:
            return self._client.service.getNodeList(parentFacilityId, level)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNodeList failed, ' + str(e))
            raise ErrorHandler.APIError('getNodeList failed, ' + str(e))

    # 割当スコープ一覧を取得します
    def getNodeScopeList(self, facilityId):
        try:
            return self._client.service.getNodeScopeList(facilityId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNodeScopeList failed, ' + str(e))
            raise ErrorHandler.APIError('getNodeScopeList failed, ' + str(e))

    # ファシリティIDリストを取得します
    def getFacilityIdList(self, parentFacilityId, level):
        try:
            return self._client.service.getFacilityIdList(parentFacilityId, level)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getFacilityIdList failed, ' + str(e))
            raise ErrorHandler.APIError('getFacilityIdList failed, ' + str(e))

    # ノードのファシリティIDリストを取得します
    def getNodeFacilityIdList(self, parentFacilityId, ownerRoleId, level):
        try:
            return self._client.service.getNodeFacilityIdList(parentFacilityId, ownerRoleId, level)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNodeFacilityIdList failed, ' + str(e))
            raise ErrorHandler.APIError('getNodeFacilityIdList failed, ' + str(e))

    # スコープへのノードの割り当てを行います
    def assignNodeScope(self, parentFacilityId, facilityIds):
        try:
            return self._client.service.assignNodeScope(parentFacilityId, facilityIds)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('assignNodeScope failed, ' + str(e))
            raise ErrorHandler.APIError('assignNodeScope failed, ' + str(e))

    # ノードをスコープから削除します。(割り当てを解除します。)
    def releaseNodeScope(self, parentFacilityId, facilityIds):
        try:
            return self._client.service.releaseNodeScope(parentFacilityId, facilityIds)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('releaseNodeScope failed, ' + str(e))
            raise ErrorHandler.APIError('releaseNodeScope failed, ' + str(e))

    # ファシリティがノードかどうかをチェックします
    def isNode(self, facilityId):
        try:
            return self._client.service.isNode(facilityId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('isNode failed, ' + str(e))
            raise ErrorHandler.APIError('isNode failed, ' + str(e))

    # ノード作成変更時に、利用可能プラットフォームを表示するためのメソッド
    def getPlatformList(self):
        try:
            return self._client.service.getPlatformList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getPlatformList failed, ' + str(e))
            raise ErrorHandler.APIError('getPlatformList failed, ' + str(e))

    # ノード作成変更時に、利用可能な仮想化ソリューションを表示するためのメソッド
    def getCollectorSubPlatformTableInfoList(self):
        try:
            return self._client.service.getCollectorSubPlatformTableInfoList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getCollectorSubPlatformTableInfoList failed, ' + str(e))
            raise ErrorHandler.APIError('getCollectorSubPlatformTableInfoList failed, ' + str(e))

    # ノードの「管理対象」フラグを変更します
    def setValid(self, facilityId, validFlag):
        try:
            return self._client.service.setValid(facilityId, validFlag)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('setValid failed, ' + str(e))
            raise ErrorHandler.APIError('setValid failed, ' + str(e))


    # ノード作成変更時に、利用可能な仮想化プロトコルを表示するためのメソッド
    def getVmProtocolMstList(self):
        try:
            return self._client.service.getVmProtocolMstList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getVmProtocolMstList failed, ' + str(e))
            raise ErrorHandler.APIError('getVmProtocolMstList failed, ' + str(e))

    # リポジトリの最終更新時刻を取得
    def getLastUpdate(self):
        try:
            return self._client.service.getLastUpdate()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getLastUpdate failed, ' + str(e))
            raise ErrorHandler.APIError('getLastUpdate failed, ' + str(e))

    # エージェントの状態を返します
    def getAgentStatusList(self):
        try:
            return self._client.service.getAgentStatusList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getAgentStatusList failed, ' + str(e))
            raise ErrorHandler.APIError('getAgentStatusList failed, ' + str(e))

    # エージェントを再起動、アップデートします
    def restartAgent(self, facilityIdList, agentCommand):
        try:
            return self._client.service.restartAgent(facilityIdList, agentCommand)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('restartAgent failed, ' + str(e))
            raise ErrorHandler.APIError('restartAgent failed, ' + str(e))

    # 指定された文字列内に存在するノード変数を置換した文字列を返します
    def replaceNodeVariable(self, facilityId, replaceObject):
        try:
            return self._client.service.replaceNodeVariable(facilityId, replaceObject)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('replaceNodeVariable failed, ' + str(e))
            raise ErrorHandler.APIError('replaceNodeVariable failed, ' + str(e))

    # 構成情報取得設定の収集フラグを有効化/無効化します
    def setStatusNodeConfigSetting(self, setting_id, valid_flag):
        try:
            return self._client.service.setStatusNodeConfigSetting(setting_id, valid_flag)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('setStatusNodeConfigSetting failed, ' + str(e))
            raise ErrorHandler.APIError('setStatusNodeConfigSetting failed, ' + str(e))

    # 引数で渡された設定に従い、構成情報収集を即時実行します
    def runCollectNodeConfig(self, setting_id):
        try:
            return self._client.service.runCollectNodeConfig(setting_id)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('runCollectNodeConfig failed, ' + str(e))
            raise ErrorHandler.APIError('runCollectNodeConfig failed, ' + str(e))

    # 構成情報取得設定の一覧を取得します
    def getNodeConfigSettingList(self):
        try:
            return self._client.service.getNodeConfigSettingList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNodeConfigSettingList failed, ' + str(e))
            raise ErrorHandler.APIError('getNodeConfigSettingList failed, ' + str(e))

    # 構成情報取得設定を取得します
    def getNodeConfigSettingInfo(self, setting_id):
        try:
            return self._client.service.getNodeConfigSettingInfo(setting_id)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNodeConfigSettingInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getNodeConfigSettingInfo failed, ' + str(e))

    # 構成情報取得設定を変更します
    def modifyNodeConfigSettingInfo(self, node_config_setting_info):
        try:
            return self._client.service.modifyNodeConfigSettingInfo(node_config_setting_info)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyNodeConfigSettingInfo failed, ' + str(e))
            raise ErrorHandler.APIError('modifyNodeConfigSettingInfo failed, ' + str(e))

    # 構成情報取得設定を削除します
    def deleteNodeConfigSettingInfo(self, setting_id_list):
        try:
            return self._client.service.deleteNodeConfigSettingInfo(setting_id_list)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteNodeConfigSettingInfo failed, ' + str(e))
            raise ErrorHandler.APIError('deleteNodeConfigSettingInfo failed, ' + str(e))

    # 構成情報取得設定を追加します
    def addNodeConfigSettingInfo(self, node_config_setting):
        try:
            return self._client.service.addNodeConfigSettingInfo(node_config_setting)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addNodeConfigSettingInfo failed, ' + str(e))
            raise ErrorHandler.APIError('addNodeConfigSettingInfo failed, ' + str(e))

    def create_notify_relation_info(self, notify_info, setting_id):
        obj_name = 'ns1:notifyRelationInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.notifyGroupId = 'NODE_CONFIG_SETTING-' + setting_id
            info.notifyId = notify_info.notifyId
            info.notifyType = notify_info.notifyType
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_node_config_setting_item_info(self, item_id):
        try:
            setting_item_info = self.create_object('nodeConfigSettingItemInfo')
            setting_item_info.settingItemId = item_id
            return setting_item_info
        except Exception, e:
            raise ErrorHandler.APIError('create nodeConfigSettingItemInfo failed, ' + str(e))

    def create_node_custom_config_info(self, custom_id, custom_name, description, command, valid_flag, is_specify_user,
                                       effective_user):
        try:
            custom_config_info = self.create_object('nodeConfigCustomInfo')
            custom_config_info.settingCustomId = custom_id
            custom_config_info.displayName = custom_name
            custom_config_info.description = description
            custom_config_info.command = command
            custom_config_info.validFlg = valid_flag
            custom_config_info.specifyUser = is_specify_user
            if is_specify_user:
                custom_config_info.effectiveUser = effective_user

            return custom_config_info
        except Exception, e:
            raise ErrorHandler.APIError('create nodeConfigCustomInfo failed, ' + str(e))

    # SNMPを利用してノードの情報を検索します
    def searchNodesBySNMP(self, ownerRoleId, ipAddressFrom, ipAddressTo, port, community, version, facilityID, securityLevel, user, authPass, privPass, authProtocol, privProtocol):
        # Default
        if ownerRoleId is None:
            ownerRoleId = 'ALL_USERS'
        if version == '1':
            version = 0
        elif version is None or version =='2c':
            version = 1
        elif version == '3':
            if user is None:
                user = 'root'
            if securityLevel is None:
                securityLevel = 'noauth_nopriv'
            if authProtocol is None:
                authProtocol = 'MD5'
            if privProtocol is None:
                privProtocol = 'DES'
        if community is None:
            community = 'public'
        if port is None:
            port = 161

        try:
            return self._client.service.searchNodesBySNMP(ownerRoleId, ipAddressFrom, ipAddressTo, port, community, version, facilityID, securityLevel, user, authPass, privPass, authProtocol, privProtocol)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('searchNodesBySNMP failed, ' + str(e))
            raise ErrorHandler.APIError('searchNodesBySNMP failed, ' + str(e))


    def create_node_info(self, facility_id, facility_name, description, ipaddress_v4, ipaddress_v6, os_name, os_release, administrator, contact):
        obj_name = 'nodeInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.facilityId = facility_id
            info.facilityName = facility_name
            info.description = description
            info.ipAddressV4 = ipaddress_v4
            info.ipAddressV6 = ipaddress_v6
            info.administrator = administrator
            info.contact = contact
            info.nodeOsInfo = self.create_node_os_info(os_name, os_release)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_scope_info(self, facility_id, facility_name, description, owner_role_id, icon_image):
        # Format input
        if description is None:
            description = ''
        if owner_role_id is None or owner_role_id == '':
            owner_role_id = 'ALL_USERS'
        if icon_image is None:
            icon_image = ''

        obj_name = 'scopeInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.facilityId = facility_id
            info.facilityName = facility_name
            info.description = description
            info.ownerRoleId = owner_role_id
            info.iconImage = icon_image
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_node_cpu_info(self):
        obj_name = 'nodeCpuInfo'
        try:
            info = self._client.factory.create(obj_name)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_node_memory_info(self):
        obj_name = 'nodeMemoryInfo'
        try:
            info = self._client.factory.create(obj_name)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_node_hostname_info(self):

        obj_name = 'nodeHostnameInfo'
        try:
            info = self._client.factory.create(obj_name)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_node_device_info(self):

        obj_name = 'nodeDeviceInfo'
        try:
            info = self._client.factory.create(obj_name)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_node_filesystem_info(self):

        obj_name = 'nodeFilesystemInfo'
        try:
            info = self._client.factory.create(obj_name)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_node_disk_info(self):

        obj_name = 'nodeDiskInfo'
        try:
            info = self._client.factory.create(obj_name)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_node_network_interface_info(self):

        obj_name = 'nodeNetworkInterfaceInfo'
        try:
            info = self._client.factory.create(obj_name)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_node_variable_info(self):

        obj_name = 'nodeVariableInfo'
        try:
            info = self._client.factory.create(obj_name)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_node_note_info(self):

        obj_name = 'nodeNoteInfo'
        try:
            info = self._client.factory.create(obj_name)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_node_os_info(self, os_name, os_release):
        node_os_info_obj_name = 'nodeOsInfo'
        try:
            node_os_info_obj = self._client.factory.create(node_os_info_obj_name)
            node_os_info_obj.osName = os_name
            node_os_info_obj.osRelease = os_release

            return node_os_info_obj
        except Exception, e:
            raise ErrorHandler.APIError('create ' + node_os_info_obj_name + ' failed, ' + str(e))


# Zeep用なリポジトリエンドポイント
class RepositoryEndpoint_Zeep(Endpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(
            hm_url, user, passwd, 'Repository')

    # 対象日時時点のノードの詳細プロパティを取得します
    def getNodeFullByTargetDatetime(self, facility_id, target_date_time, node_filter_info):
        try:
            return self._client.service.getNodeFullByTargetDatetime(facility_id, target_date_time, node_filter_info)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNodeFullByTargetDatetime failed, ' + str(e))
            raise ErrorHandler.APIError('getNodeFullByTargetDatetime failed, ' + str(e))
