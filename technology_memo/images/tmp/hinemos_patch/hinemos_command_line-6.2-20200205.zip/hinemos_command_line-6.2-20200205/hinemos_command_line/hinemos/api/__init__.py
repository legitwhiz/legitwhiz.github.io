# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import os
import re
import sys
import codecs

from logging.config import fileConfig
from suds.transport.http import HttpAuthenticated
from suds.client import Client
from urlparse import urlparse

from hinemos.api.exceptions import LoginError
from hinemos.api.exceptions import APIError
from hinemos.api import exceptions as ErrorHandler

import logging
from copy import deepcopy
logging.basicConfig(level=logging.WARNING)
logging.getLogger('suds.client').setLevel(logging.CRITICAL)
#logging.basicConfig(level=logging.INFO) ### For Debug
#logging.getLogger('suds.client').setLevel(logging.INFO) ### For Debug
#logging.getLogger('suds.client').setConsoleLevel(logging.ERROR)
#logging.getLogger('suds.client').setFileLevel(logging.INFO)

def url_autocomplete(raw):
    ''' autocomplete for Manager URL

        @see com.clustercontrol.util.EndpointUnit#validateManagerURL()
    '''
    url = raw.strip()
    has_protocol = re.match(r'\w+://.*', url)
    if not has_protocol:
        url = 'http://' + url

    # try
    parsed = urlparse(url)
    formatted = parsed.scheme + '://' + parsed.netloc
    if not parsed.port:
        formatted += ':8080'
    #else: # no need because the port number is included parsed.netloc already
    #    formatted += ':%d' % formatted.port

    if not parsed.path:
        formatted += '/HinemosWS/'
    else:
        formatted += parsed.path

    if not formatted.endswith('/'):
        formatted += '/'

    return formatted

class BasicEndpoint(object):

    @staticmethod
    def login(hm_url, user, passwd, endpoint_name):

        # Load cache from local schema
        from suds.options import Options
        from suds.cache import ObjectCache
        from suds.reader import DocumentReader
        import urlparse, urllib
        import ConfigParser
        import ssl
        #do not verify ssl certificate
        if hasattr(ssl, '_create_unverified_context'):
            ssl._create_default_https_context = ssl._create_unverified_context

        inifile = ConfigParser.SafeConfigParser({'connection_timeout': '30', 'cache_duration': '86400', 'cache_dir': None})
        inifile.read(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..','..', 'settings.ini'))

        connection_timeout = inifile.getint('SOAPclient', 'connection_timeout')
        cache_dir = inifile.get('SOAPclient', 'cache_dir')
        cache_duration =  inifile.getint('SOAPclient', 'cache_duration')
        if cache_dir == '':
            cache_dir = None

        precacheschemas = {'http://www.w3.org/2005/05/xmlmime' : 'xmlmime.xml'}

        options = Options()
        options.transport = HttpAuthenticated()
        mycache = ObjectCache(cache_dir, seconds=cache_duration)
        options.cache = mycache
        reader = DocumentReader(options)
        # Hacking reader.open(url)
        cache = reader.cache()
        for url, filename in precacheschemas.items():
            cacheid = reader.mangle( url, 'document' )
            d = cache.get(cacheid)
            if d is None:
                if not re.match( r'^(https?|file|suds):', filename ):
                    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'precache', filename)
                    path_url = urlparse.urljoin('file:', urllib.pathname2url(path))
                d = reader.download( path_url )
                cache.put( cacheid, d )

        # Login
        url = url_autocomplete(hm_url) + endpoint_name + 'Endpoint?wsdl'
        try:
            t = HttpAuthenticated(username=user, password=passwd, timeout=connection_timeout)
            client = Client(url, transport=t, cache=mycache)
            return client
        except Exception, e:
            raise LoginError(hm_url + ', login failed, ' + str(e))

    @staticmethod
    def modify_none2empty(info):
        ''' suds bug? empty suds.sax.text.Text data in DB will become None '''

        for k,v in info.__dict__.iteritems():
            if not k.startswith('__'):
                t = type(v).__name__
                if t == 'instance':
                    BasicEndpoint.modify_none2empty(v)
                elif t == 'NoneType':
                    #print 'DEBUG: Replace', k, 'value(None) with "".'
                    setattr(info, k, '')

    _client = None
    _object_cache = {}

    def __init__(self, hm_url, user, passwd, endpoint_name):
        self._client = BasicEndpoint.login(hm_url, user, passwd, endpoint_name)

    def create_object(self, obj_name, cache=True):
        try:
            if obj_name in self._object_cache:
                return deepcopy(self._object_cache[obj_name])
            else:
                result = self._client.factory.create(obj_name)
                self._object_cache[obj_name] = deepcopy(result)
                return result
        except Exception, e:
            raise APIError('create ' + obj_name + ' failed, ' + str(e))

    def echo(self, echo_string):
        try:
            echo = self._client.service.echo(echo_string)
        except Exception, e:
            raise APIError('echo failed, ' + str(e))
        return echo

    def __str__(self):
        return str(self._client)

    def get_obj(self, namespace, obj_name):
        return self._client.factory.create(obj_name)

    def call(self, service_name, *args):
        service = getattr(self._client.service, service_name)
        try:
            return service(*args)
        except ErrorHandler.LoginError, e:
            return_code = ResultPrinter.failure(e)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    service_name + ' failed, ' + str(e))
            raise ErrorHandler.APIError(service_name + ' failed, ' + str(e))
