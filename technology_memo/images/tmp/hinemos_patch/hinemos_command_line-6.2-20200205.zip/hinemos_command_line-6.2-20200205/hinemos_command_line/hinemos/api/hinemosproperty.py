#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.hinemosproperty import HinemosPropertyUtil


# HC for Utility data consistence
def formatted_info(info):
    if info.description is None:
        info.description = ''
    if info.valueType == 2 and info.valueNumeric == '':
        info.valueNumeric = None
    return info


class HinemosPropertyEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'HinemosProperty')

    # 共通設定情報を追加します
    def addHinemosProperty(self, hinemosPropertyInfo):
        try:
            return self._client.service.addHinemosProperty(formatted_info(hinemosPropertyInfo))
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addHinemosProperty failed, ' + str(e))
            raise ErrorHandler.APIError('addHinemosProperty failed, ' + str(e))

    # 共通設定情報を変更します
    def modifyHinemosProperty(self, hinemosPropertyInfo):
        try:
            return self._client.service.modifyHinemosProperty(formatted_info(hinemosPropertyInfo))
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyHinemosProperty failed, ' + str(e))
            raise ErrorHandler.APIError('modifyHinemosProperty failed, ' + str(e))

    # 共通設定情報を削除します
    def deleteHinemosProperty(self, key):
        try:
            return self._client.service.deleteHinemosProperty(key)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteHinemosProperty failed, ' + str(e))
            raise ErrorHandler.APIError('deleteHinemosProperty failed, ' + str(e))

    # 共通設定情報を取得します
    def getHinemosProperty(self, key):
        try:
            return self._client.service.getHinemosProperty(key)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getHinemosProperty failed, ' + str(e))
            raise ErrorHandler.APIError('getHinemosProperty failed, ' + str(e))

    # 共通設定情報の一覧を取得します
    def getHinemosPropertyList(self):
        try:
            return self._client.service.getHinemosPropertyList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getHinemosPropertyList failed, ' + str(e))
            raise ErrorHandler.APIError('getHinemosPropertyList failed, ' + str(e))

    # 現在のHinemos時刻を返します
    def getHinemosTime(self):
        try:
            return self._client.service.getHinemosTime()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getHinemosTime failed, ' + str(e))
            raise ErrorHandler.APIError('getHinemosTime failed, ' + str(e))

    def create_hinemos_property_info(self, type_string, key, value, description, owner_role_id):
        # Format input
        if description is None:
            description = ''

        #value_string, value_numeric, value_boolean
        obj_name = 'hinemosPropertyInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.key = key
            info.ownerRoleId = owner_role_id
            if type_string == 'BOOLEAN':
                info.valueType = 3
            elif type_string == 'NUMERIC':
                info.valueType = 2
            else:
                info.valueType = 1
            info = HinemosPropertyUtil.set_hinemos_property_info_value(info, value)
            info.description = description
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))
