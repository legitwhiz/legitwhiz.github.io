# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import re
from hinemos.api.exceptions import ArgumentError

class CalendarUtil(object):

    _weekday_ = {'Sun':1, 'Mon':2, 'Tue':3, 'Wed':4, 'Thu':5, 'Fri':6, 'Sat':7}

    @staticmethod
    def convert2weekday(label):
        return CalendarUtil._weekday_[label]

    @staticmethod
    def ymd_equal(ymd1, ymd2):
        return ymd1.day == ymd2.day and ymd1.month == ymd2.month and ymd1.year == ymd2.year

    @staticmethod
    def set_calendar_ymddetail(info, ymd_detail):
        ''' info: calendar_detail_info '''

        if hasattr(info, 'calPatternInfo'):
            delattr(info, 'calPatternInfo')
        try:
            matches = re.match(r'(Yearly|\d{4})[/ ](Monthly|\w+)[ /](Daily|\d{1,2}|Every-\w+|[1-5]-\w+|Pattern [^\s]+)$', ymd_detail)
            if matches:
                # Year
                info.year = 0 if matches.group(1) == 'Yearly' else int(matches.group(1))

                # Month
                info.month = 0 if matches.group(2) == 'Monthly' else int(matches.group(2))

                # Day / Pattern
                info.dayOfWeek = -1
                info.dayOfWeekInMonth = -1
                info.date = -1
                setattr(info, 'calPatternId', None)

                day_part = matches.group(3)
                if day_part == 'Daily':
                    info.dayType = 0
                elif day_part.startswith('Pattern '):
                    info.dayType = 3
                    info.calPatternId = re.sub(r'^Pattern *', '', day_part)
                else:
                    matches = re.match(r'(Every|[1-5])[- ](\w+)$', day_part)
                    if matches:
                        info.dayType = 1
                        info.dayOfWeekInMonth = 0 if matches.group(1) == 'Every' else int(matches.group(1))
                        info.dayOfWeek = CalendarUtil.convert2weekday(matches.group(2))
                    else:
                        info.dayType = 2
                        info.date = int(day_part)
            else:
                raise ValueError
            return info
        except (ValueError, KeyError):
            raise ArgumentError('schedule format is not correct - "$YEAR $MONTH $DAY/$PATTERN". e.g. "Yearly Monthly Daily", "1998/12 Daily", "Yearly 01 Pattern holiday2013-2020", "2015 Monthly 30", "2015/02/28", "2015/12 Every-Sun", "2015/12 1-Sun"')
