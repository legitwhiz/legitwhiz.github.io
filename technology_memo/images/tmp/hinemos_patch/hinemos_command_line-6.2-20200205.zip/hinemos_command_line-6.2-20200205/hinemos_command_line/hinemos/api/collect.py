#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler
import traceback
class CollectEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'Collect')

    def getCollectId(self, itemName, displayName, monitorId, facilityIdList):
        try:
            return self._client.service.getCollectId(itemName, displayName, monitorId, facilityIdList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getCollectId failed, ' + str(e))
            raise ErrorHandler.APIError('getCollectId failed, ' + str(e))

    def getCollectData(self, idList, summaryType, fromTime, toTime):
        try:
            return self._client.service.getCollectData(idList, summaryType, fromTime, toTime)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getCollectData failed, ' + str(e))
            raise ErrorHandler.APIError('getCollectData failed, ' + str(e))

    def getItemCodeList(self, facility_id_lst):
        try:
            return self._client.service.getItemCodeList(facility_id_lst)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getItemCodeList failed, ' + str(e))
            raise ErrorHandler.APIError('getItemCodeList failed, ' + str(e))

    def createPerfFile(self, map1, collect_key_info_list, facility_list, summary_type, locale_str, show_header, default_date_str):
        '''
        @see com.clustercontrol.collect.action.RecordDataWriter

        defaultDateStr
        @see com.clustercontrol.collect.dialog.ExportDialog
            // 対象ファイル名に含めるID(日付)を生成
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            // クライアントで出力するファイル名の日時情報はクライアントのタイムゾーンの現在時刻とする(マネージャのタイムゾーン時刻に補正しない)
            String defaultDateStr = sdf.format(new Date(System.currentTimeMillis()));
        '''
        try:
            return self._client.service.createPerfFile(map1, collect_key_info_list, facility_list, summary_type, locale_str, show_header, default_date_str)
        except Exception, e:
            traceback.print_exc()
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('createPerfFile failed, ' + str(e))
            raise ErrorHandler.APIError('createPerfFile failed, ' + str(e))

    def downloadPerfFile(self, fileName):
        try:
            return self._client.service.downloadPerfFile(fileName)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('downloadPerfFile failed, ' + str(e))
            raise ErrorHandler.APIError('downloadPerfFile failed, ' + str(e))

    def deletePerfFile(self, fileNameList):
        try:
            return self._client.service.deletePerfFile(fileNameList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deletePerfFile failed, ' + str(e))
            raise ErrorHandler.APIError('deletePerfFile failed, ' + str(e))

    def getEventDataMap(self, facilityIdList):
        try:
            return self._client.service.getEventDataMap(facilityIdList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getEventDataMap failed, ' + str(e))
            raise ErrorHandler.APIError('getEventDataMap failed, ' + str(e))
