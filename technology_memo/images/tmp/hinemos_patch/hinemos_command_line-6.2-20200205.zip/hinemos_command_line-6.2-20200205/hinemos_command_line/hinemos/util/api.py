# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.common import ResultPrinter


notify_endpoint = None


def setattr_if_not_exists(obj, attr, val=None):
    if hasattr(obj, attr):
        if val is None:
            return False
        elif getattr(obj, attr) is not None:
            return False
    setattr(obj, attr, val)
    return True


def set_default_values_if_none(args, defaults):
    for key in defaults:
        if args.get(key) is None:
            args[key] = defaults[key]
    return args


def validate_ids(ids, args):
    global notify_endpoint
    if notify_endpoint is None:
        notify_endpoint = NotifyEndpoint(args['mgr_url'],
                                         args['user'],
                                         args['passwd'])
    notify_response = notify_endpoint.getNotifyList()
    verified = []
    for info in notify_response:
        if info.notifyId in ids:
            verified.append(info)
            ids.remove(info.notifyId)
    if len(ids) is not 0:
        ResultPrinter.warning(
            'Notify ' + (', '.join(ids)) + ' will be ignored!')
    return verified


def verify_all_ids(args):
    id_keys = filter(lambda x: 'notify_ids' in x, args.keys())
    for key in id_keys:
        if args.get(key) is not None:
            args[key] = validate_ids(args[key], args)
    return args


def all_ids_str_to_list(args):
    id_keys = filter(lambda x: 'notify_ids' in x, args.keys())
    for key in id_keys:
        if args.get(key) is not None and isinstance(
                args.get(key), (str, unicode)):
            args[key] = map(lambda x: x.strip(), args[key].split(','))
    return args


def prepare_args(args, defaults):
    args = set_default_values_if_none(args, defaults)
    args = all_ids_str_to_list(args)
    args = verify_all_ids(args)
    return args
