# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------
#
# このパッケージはメモリ節約用(主にインポートエクスポートに使用)

from suds.sudsobject import Object as SudsObject

class BasicObject( SudsObject ):
    __keylist__ = []

    def __init__( self ):
        tmp = self.__keylist__[:]
        SudsObject.__init__( self )

        for k in tmp:
            setattr( self, k, None )
