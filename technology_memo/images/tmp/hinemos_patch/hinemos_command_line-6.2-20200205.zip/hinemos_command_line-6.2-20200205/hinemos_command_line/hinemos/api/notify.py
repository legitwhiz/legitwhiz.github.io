#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.notify import NotifyUtil
from hinemos.util.modifier import ObjectModifier


# HC for Utility data consistence
def formatted_info(info):
    if 'notifyLogEscalateInfo' in info and info.notifyLogEscalateInfo is not None:
        if '' == info.notifyLogEscalateInfo.infoEscalateMessage:
            info.notifyLogEscalateInfo.infoEscalateMessage = None
        if '' == info.notifyLogEscalateInfo.criticalEscalateMessage:
            info.notifyLogEscalateInfo.criticalEscalateMessage = None
        if '' == info.notifyLogEscalateInfo.warnEscalateMessage:
            info.notifyLogEscalateInfo.warnEscalateMessage = None
        if '' == info.notifyLogEscalateInfo.unknownEscalateMessage:
            info.notifyLogEscalateInfo.unknownEscalateMessage = None

    # HC for Utility Excel: Prevent renotifyPeriod=""
    if 'renotifyPeriod' in info and info.renotifyPeriod is not None:
        if '' == info.renotifyPeriod:
            info.renotifyPeriod = None

    # HC for Utility Excel: Prevent renotifyPeriod=""
    if 'notifyCommandInfo' in info and info.notifyCommandInfo is not None:
        if info.notifyCommandInfo.setEnvironment is None or '' == info.notifyCommandInfo.setEnvironment:
            info.notifyCommandInfo.setEnvironment = 1
        if info.notifyCommandInfo.timeout is None or '' == info.notifyCommandInfo.timeout:
            info.notifyCommandInfo.timeout = 15000
    return info

class NotifyEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'Notify')

    # 通知情報を作成します。
    def addNotify(self, notifyInfo):
        if not int(notifyInfo.notifyType) == NotifyUtil.convert2notify_type('COMMAND'):      notifyInfo.notifyCommandInfo     = None
        if not int(notifyInfo.notifyType) == NotifyUtil.convert2notify_type('EVENT'):        notifyInfo.notifyEventInfo       = None
        if not int(notifyInfo.notifyType) == NotifyUtil.convert2notify_type('INFRA'):        notifyInfo.notifyInfraInfo       = None
        if not int(notifyInfo.notifyType) == NotifyUtil.convert2notify_type('JOB'):          notifyInfo.notifyJobInfo         = None
        if not int(notifyInfo.notifyType) == NotifyUtil.convert2notify_type('LOG_ESCALATE'): notifyInfo.notifyLogEscalateInfo = None
        if not int(notifyInfo.notifyType) == NotifyUtil.convert2notify_type('MAIL'):         notifyInfo.notifyMailInfo        = None
        if not int(notifyInfo.notifyType) == NotifyUtil.convert2notify_type('STATUS'):       notifyInfo.notifyStatusInfo      = None

        try:
            return self._client.service.addNotify(formatted_info(notifyInfo))
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addNotify failed, ' + str(e))
            raise ErrorHandler.APIError('addNotify is failed, '+ str(e))

    # 通知情報を変更します。
    def modifyNotify(self, notifyInfo):
        try:
            return self._client.service.modifyNotify(formatted_info(notifyInfo))
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyNotify failed, ' + str(e))
            raise ErrorHandler.APIError('modifyNotify is failed, '+ str(e))

    # 通知情報を削除します。
    def deleteNotify(self, notifyId):
        try:
            return self._client.service.deleteNotify(notifyId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteNotify failed, ' + str(e))
            raise ErrorHandler.APIError('deleteNotify is failed, '+ str(e))

    # 引数で指定された通知情報を返します。
    def getNotify(self, notifyId, notifyType = None):
        try:
            info = self._client.service.getNotify(notifyId)
            if notifyType is None or info.notifyType == notifyType:
                return info
            else:
                return None
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNotify failed, ' + str(e))
            raise ErrorHandler.APIError('getNotify is failed, ' + str(e))

    # 通知情報一覧を返します。
    def getNotifyList(self):
        try:
            return self._client.service.getNotifyList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNotifyList failed, ' + str(e))
            raise ErrorHandler.APIError('getNotifyList is failed, '+ str(e))

    # オーナーロールIDを条件として通知情報一覧を返します。
    def getNotifyListByOwnerRole(self, ownerRoleId):
        try:
            return self._client.service.getNotifyListByOwnerRole(ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNotifyListByOwnerRole failed, ' + str(e))
            raise ErrorHandler.APIError('getNotifyListByOwnerRole is failed, '+ str(e))

    # 引数で指定した通知IDを利用している通知グループIDを取得する。
    def checkNotifyId(self, notifyIds):
        try:
            return self._client.service.checkNotifyId(notifyIds)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('checkNotifyId failed, ' + str(e))
            raise ErrorHandler.APIError('checkNotifyId is failed, '+ str(e))

    # 指定した通知IDを有効化する。
    def setNotifyStatus(self, notifyId, validFlag):
        try:
            self._client.service.setNotifyStatus(notifyId, validFlag)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('setNotifyStatus failed, ' + str(e))
            raise ErrorHandler.APIError('setNotifyStatus is failed, '+ str(e))

    # 外部から直接通知処理を実行します。
    def notify(self, pluginId, monitorId, facilityId, subKey, generationDate, priority, application, message, messageOrg, notifyIdList, srcId):
        try:
            self._client.service.notify(pluginId, monitorId, facilityId, subKey, generationDate, priority, application, message, messageOrg, notifyIdList, srcId)
        except Exception, e:
            raise ErrorHandler.APIError('notify failed, '+ str(e))

    def create_notify_relation_info(self, notify_info, setting_type, setting_id):
        obj_name = 'notifyRelationInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.notifyGroupId = setting_type + '-' + setting_id +'-0'
            info.notifyId = notify_info.notifyId
            info.notifyType = notify_info.notifyType
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def add_notify_status(self, notify_id, initial_count, description=None, owner_role_id=None, calendar_id=None, not_first_notify=None, renotify_type=None, renotify_period=None, valid_flg=None,\
                          info_valid_flg=None, warn_valid_flg=None, critical_valid_flg=None, unknown_valid_flg=None, status_valid_period=None, status_invalid_flg=None, status_update_priority=None):
        try:
            info = self.create_notify_info(NotifyUtil.convert2notify_type('STATUS'), notify_id, initial_count, description, owner_role_id, calendar_id, not_first_notify, renotify_type, renotify_period, valid_flg)
            info.notifyStatusInfo = self.create_notify_status_info(info_valid_flg, warn_valid_flg, critical_valid_flg, unknown_valid_flg, status_valid_period, status_invalid_flg, status_update_priority)
            return self.addNotify(info)
        except Exception, e:
            raise ErrorHandler.APIError('addNotify_Status failed, ' + str(e))

    def add_notify_event(self, notify_id, initial_count, description=None, owner_role_id=None, calendar_id=None, not_first_notify=None, renotify_type=None, renotify_period=None, valid_flg=None,\
                         info_valid_flg=None, info_event_normal_state=None, warn_valid_flg=None, warn_event_normal_state=None, critical_valid_flg=None, critical_event_normal_state=None, unknown_valid_flg=None, unknown_event_normal_state=None):
        try:
            info = self.create_notify_info(NotifyUtil.convert2notify_type('EVENT'), notify_id, initial_count, description, owner_role_id, calendar_id, not_first_notify, renotify_type, renotify_period, valid_flg)
            info.notifyEventInfo = self.create_notify_event_info(info_valid_flg, info_event_normal_state, warn_valid_flg, warn_event_normal_state, critical_valid_flg, critical_event_normal_state, unknown_valid_flg, unknown_event_normal_state)
            return self.addNotify(info)
        except Exception, e:
            raise ErrorHandler.APIError('addNotify_Event failed, ' + str(e))

    def add_notify_mail(self, notify_id=None, initial_count=None, description=None, owner_role_id=None, calendar_id=None, not_first_notify=None, renotify_type=None, renotify_period=None, valid_flg=None,\
                        mail_template_id=None, info_valid_flg=None, info_mail_address=None, warn_valid_flg=None, warn_mail_address=None, critical_valid_flg=None, critical_mail_address=None, unknown_valid_flg=None, unknown_mail_address=None):
        try:
            info = self.create_notify_info(NotifyUtil.convert2notify_type('MAIL'), notify_id, initial_count, description, owner_role_id, calendar_id, not_first_notify, renotify_type, renotify_period, valid_flg)
            info.notifyMailInfo = self.create_notify_mail_info(mail_template_id, info_valid_flg, info_mail_address, warn_valid_flg, warn_mail_address, critical_valid_flg, critical_mail_address, unknown_valid_flg, unknown_mail_address)
            return self.addNotify(info)
        except Exception, e:
            raise ErrorHandler.APIError('addNotify_Mail failed, ' + str(e))

    def add_notify_job(self, notify_id, initial_count, description=None, owner_role_id=None, calendar_id=None, not_first_notify=None, renotify_type=None, renotify_period=None, valid_flg=None,\
                       job_exec_facility=None, job_exec_facility_flg=None, info_valid_flg=None, info_jobunit_id=None, info_job_id=None, info_job_failure_priority=None, warn_valid_flg=None, warn_jobunit_id=None, warn_job_id=None, warn_job_failure_priority=None, critical_valid_flg=None, critical_jobunit_id=None, critical_job_id=None, critical_job_failure_priority=None, unknown_valid_flg=None, unknown_jobunit_id=None, unknown_job_id=None, unknown_job_failure_priority=None):
        try:
            info = self.create_notify_info(NotifyUtil.convert2notify_type('JOB'), notify_id, initial_count, description, owner_role_id, calendar_id, not_first_notify, renotify_type, renotify_period, valid_flg)
            info.notifyJobInfo = self.create_notify_job_info(job_exec_facility, job_exec_facility_flg, info_valid_flg, info_jobunit_id, info_job_id, info_job_failure_priority, warn_valid_flg, warn_jobunit_id, warn_job_id, warn_job_failure_priority, critical_valid_flg, critical_jobunit_id, critical_job_id, critical_job_failure_priority, unknown_valid_flg, unknown_jobunit_id, unknown_job_id, unknown_job_failure_priority)

            return self.addNotify(info)
        except Exception, e:
            raise ErrorHandler.APIError('addNotify_Job failed, ' + str(e))

    def add_notify_logesc(self, notify_id, initial_count, description=None, owner_role_id=None, calendar_id=None, not_first_notify=None, renotify_type=None, renotify_period=None, valid_flg=None,\
                          escalate_facility_flg=None, escalate_facility=None, escalate_port=None, info_valid_flg=None, info_syslog_facility=None, info_syslog_priority=None, info_escalate_message=None, warn_valid_flg=None, warn_syslog_facility=None, warn_syslog_priority=None, warn_escalate_message=None, critical_valid_flg=None, critical_syslog_facility=None, critical_syslog_priority=None, critical_escalate_message=None, unknown_valid_flg=None, unknown_syslog_facility=None, unknown_syslog_priority=None, unknown_escalate_message=None):
        try:
            info = self.create_notify_info(NotifyUtil.convert2notify_type('LOG_ESCALATE'), notify_id, initial_count, description, owner_role_id, calendar_id, not_first_notify, renotify_type, renotify_period, valid_flg)
            info.notifyLogEscalateInfo = self.create_notify_log_escalate_info(escalate_facility_flg, escalate_facility, escalate_port, info_valid_flg, info_syslog_facility, info_syslog_priority, info_escalate_message, warn_valid_flg, warn_syslog_facility, warn_syslog_priority, warn_escalate_message, critical_valid_flg, critical_syslog_facility, critical_syslog_priority, critical_escalate_message, unknown_valid_flg, unknown_syslog_facility, unknown_syslog_priority, unknown_escalate_message)
            return self.addNotify(info)
        except Exception, e:
            raise ErrorHandler.APIError('addNotify_LogEscalation failed, ' + str(e))

    def add_notify_command(self, notify_id, initial_count, description=None, owner_role_id=None, calendar_id=None, not_first_notify=None, renotify_type=None, renotify_period=None, valid_flg=None,\
                           info_valid_flg=None, info_effective_user=None, info_command=None, warn_valid_flg=None, warn_effective_user=None, warn_command=None, critical_valid_flg=None, critical_effective_user=None, critical_command=None, unknown_valid_flg=None, unknown_effective_user=None, unknown_command=None, timeout=None):
        try:
            info = self.create_notify_info(NotifyUtil.convert2notify_type('COMMAND'), notify_id, initial_count, description, owner_role_id, calendar_id, not_first_notify, renotify_type, renotify_period, valid_flg)
            info.notifyCommandInfo = self.create_notify_command_info(info_valid_flg, info_effective_user, info_command, warn_valid_flg, warn_effective_user, warn_command, critical_valid_flg, critical_effective_user, critical_command, unknown_valid_flg, unknown_effective_user, unknown_command, timeout)
            return self.addNotify(info)
        except Exception, e:
            raise ErrorHandler.APIError('addNotify_Command failed, ' + str(e))

    def add_notify_infra(self, notify_id, initial_count, description=None, owner_role_id=None, calendar_id=None, not_first_notify=None, renotify_type=None, renotify_period=None, valid_flg=None,\
                       infra_exec_facility=None, infra_exec_facility_flg=None, info_valid_flg=None, infra_info=None, info_infra_failure_priority=None, warn_valid_flg=None, infra_warn=None, warn_infra_failure_priority=None, critical_valid_flg=None, infra_critical=None, critical_infra_failure_priority=None, unknown_valid_flg=None, infra_unknown=None, unknown_infra_failure_priority=None):
        try:
            info = self.create_notify_info(NotifyUtil.convert2notify_type('INFRA'), notify_id, initial_count, description, owner_role_id, calendar_id, not_first_notify, renotify_type, renotify_period, valid_flg)
            info.notifyInfraInfo = self.create_notify_infra_info(infra_exec_facility, infra_exec_facility_flg, info_valid_flg, infra_info, info_infra_failure_priority, warn_valid_flg, infra_warn, warn_infra_failure_priority, critical_valid_flg, infra_critical, critical_infra_failure_priority, unknown_valid_flg, infra_unknown, unknown_infra_failure_priority)

            return self.addNotify(info)
        except Exception, e:
            raise ErrorHandler.APIError('addNotify_Infra failed, ' + str(e))


    def create_notify_info(self, notify_type, notify_id, initial_count, description=None, owner_role_id=None, calendar_id=None, not_first_notify=None, renotify_type=None, renotify_period=None, valid_flg=None):
        # Default
        if owner_role_id is None:
            owner_role_id = 'ALL_USERS'
        if description is None:
            description = ''
        if not_first_notify is None:
            not_first_notify = False
        if renotify_type is None:
            renotify_type = 0
        if valid_flg is None:
            valid_flg = True

        obj_name = 'notifyInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.notifyType = notify_type
            info.notifyId = notify_id
            if description is not None:
                info.description = description
            if owner_role_id is not None:
                info.ownerRoleId = owner_role_id
            if calendar_id is not None:
                info.calendarId = calendar_id
            if initial_count is not None:
                info.initialCount = initial_count
            if not_first_notify is not None:
                info.notFirstNotify = not_first_notify
            if renotify_type is not None:
                info.renotifyType = renotify_type
            if renotify_period is not None:
                info.renotifyPeriod = renotify_period
            if valid_flg is not None:
                info.validFlg = valid_flg
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_notify_command_info(self, info_valid_flg=None, info_effective_user=None, info_command=None, warn_valid_flg=None, warn_effective_user=None, warn_command=None, critical_valid_flg=None, critical_effective_user=None, critical_command=None, unknown_valid_flg=None, unknown_effective_user=None, unknown_command=None, timeout=None, set_environment=None):
        # Default
        if set_environment is None:
            set_environment = True
        if timeout is None:
            timeout = 15000
        if info_valid_flg is None:
            info_valid_flg = False
        if warn_valid_flg is None:
            warn_valid_flg = False
        if critical_valid_flg is None:
            critical_valid_flg = False
        if unknown_valid_flg is None:
            unknown_valid_flg = False

        obj_name = 'notifyCommandInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.setEnvironment = set_environment

            if critical_valid_flg is not None:
                info.criticalValidFlg = critical_valid_flg
            if info_valid_flg is not None:
                info.infoValidFlg = info_valid_flg
            if unknown_valid_flg is not None:
                info.unknownValidFlg = unknown_valid_flg
            if warn_valid_flg is not None:
                info.warnValidFlg = warn_valid_flg
            if critical_command is not None:
                info.criticalCommand = critical_command
            if critical_effective_user is not None:
                info.criticalEffectiveUser = critical_effective_user
            if info_command is not None:
                info.infoCommand = info_command
            if info_effective_user is not None:
                info.infoEffectiveUser = info_effective_user
            if unknown_command is not None:
                info.unknownCommand = unknown_command
            if unknown_effective_user is not None:
                info.unknownEffectiveUser = unknown_effective_user
            if warn_command is not None:
                info.warnCommand = warn_command
            if warn_effective_user is not None:
                info.warnEffectiveUser = warn_effective_user
            if timeout is not None:
                info.timeout = timeout
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_notify_status_info(self,  info_valid_flg=None, warn_valid_flg=None, critical_valid_flg=None, unknown_valid_flg=None, status_valid_period=None, status_invalid_flg=None, status_update_priority=None):
        # Default
        if info_valid_flg is None:
            info_valid_flg=False
        if warn_valid_flg is None:
            warn_valid_flg=False
        if critical_valid_flg is None:
            critical_valid_flg=False
        if unknown_valid_flg is None:
            unknown_valid_flg=False

        if status_valid_period is None:
            status_valid_period = 10
        if status_invalid_flg is None:
            status_invalid_flg = NotifyUtil.convert2process_after_duration('DELETE')
        if status_update_priority is None:
            status_update_priority = 2

        obj_name = 'notifyStatusInfo'
        try:
            info = self._client.factory.create(obj_name)
            if critical_valid_flg is not None:
                info.criticalValidFlg = critical_valid_flg
            if info_valid_flg is not None:
                info.infoValidFlg = info_valid_flg
            if unknown_valid_flg is not None:
                info.unknownValidFlg = unknown_valid_flg
            if warn_valid_flg is not None:
                info.warnValidFlg = warn_valid_flg
            if status_invalid_flg is not None:
                info.statusInvalidFlg = status_invalid_flg
            if status_update_priority is not None:
                info.statusUpdatePriority = status_update_priority
            if status_valid_period is not None:
                info.statusValidPeriod = status_valid_period
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_notify_mail_info(self, mail_template_id=None, info_valid_flg=None, info_mail_address=None, warn_valid_flg=None, warn_mail_address=None, critical_valid_flg=None, critical_mail_address=None, unknown_valid_flg=None, unknown_mail_address=None):
        # Default
        if info_valid_flg is None:
            info_valid_flg = False
        if warn_valid_flg is None:
            warn_valid_flg = False
        if critical_valid_flg is None:
            critical_valid_flg = False
        if unknown_valid_flg is None:
            unknown_valid_flg = False 

        obj_name = 'notifyMailInfo'
        try:
            info = self._client.factory.create(obj_name)
            if critical_valid_flg is not None:
                info.criticalValidFlg = critical_valid_flg
            if info_valid_flg is not None:
                info.infoValidFlg = info_valid_flg
            if unknown_valid_flg is not None:
                info.unknownValidFlg = unknown_valid_flg
            if warn_valid_flg is not None:
                info.warnValidFlg = warn_valid_flg
            if critical_mail_address is not None:
                info.criticalMailAddress = critical_mail_address
            if info_mail_address is not None:
                info.infoMailAddress = info_mail_address
            if mail_template_id is not None:
                info.mailTemplateId = mail_template_id
            if unknown_mail_address is not None:
                info.unknownMailAddress = unknown_mail_address
            if warn_mail_address is not None:
                info.warnMailAddress = warn_mail_address
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_notify_log_escalate_info(self, escalate_facility_flg=None, escalate_facility=None, escalate_port=None, info_valid_flg=None, info_syslog_facility=None, info_syslog_priority=None, info_escalate_message=None, warn_valid_flg=None, warn_syslog_facility=None, warn_syslog_priority=None, warn_escalate_message=None, critical_valid_flg=None, critical_syslog_facility=None, critical_syslog_priority=None, critical_escalate_message=None, unknown_valid_flg=None, unknown_syslog_facility=None, unknown_syslog_priority=None, unknown_escalate_message=None):
        # Default
        if escalate_facility_flg is None:
            escalate_facility_flg = 0
        if escalate_facility is None:
            escalate_scope = ''
        else:
            escalate_scope = ' '
        if escalate_port is None:
            escalate_port = 514
        if info_valid_flg is None:
            info_valid_flg = False
        if info_syslog_facility is None:
            info_syslog_facility = 8
        if info_syslog_priority is None:
            info_syslog_priority = 3
        if warn_valid_flg is None:
            warn_valid_flg = False
        if warn_syslog_facility is None:
            warn_syslog_facility = 8
        if warn_syslog_priority is None:
            warn_syslog_priority = 3
        if critical_valid_flg is None:
            critical_valid_flg = False
        if critical_syslog_facility is None:
            critical_syslog_facility = 8
        if critical_syslog_priority is None:
            critical_syslog_priority = 3
        if unknown_valid_flg is None:
            unknown_valid_flg = False
        if unknown_syslog_facility is None:
            unknown_syslog_facility = 8
        if unknown_syslog_priority is None:
            unknown_syslog_priority = 3

        obj_name = 'notifyLogEscalateInfo'
        try:
            info = self._client.factory.create(obj_name)
            if critical_valid_flg is not None:
                info.criticalValidFlg = critical_valid_flg
            if info_valid_flg is not None:
                info.infoValidFlg = info_valid_flg
            if unknown_valid_flg is not None:
                info.unknownValidFlg = unknown_valid_flg
            if warn_valid_flg is not None:
                info.warnValidFlg = warn_valid_flg
            if critical_escalate_message is not None:
                info.criticalEscalateMessage = critical_escalate_message
            if critical_syslog_facility is not None:
                info.criticalSyslogFacility = critical_syslog_facility
            if critical_syslog_priority is not None:
                info.criticalSyslogPriority = critical_syslog_priority
            if escalate_facility is not None:
                info.escalateFacility = escalate_facility
            if escalate_facility_flg is not None:
                info.escalateFacilityFlg = escalate_facility_flg
            if escalate_port is not None:
                info.escalatePort = escalate_port
                info.escalateScope = escalate_scope
            if info_escalate_message is not None:
                info.infoEscalateMessage = info_escalate_message
            if info_syslog_facility is not None:
                info.infoSyslogFacility = info_syslog_facility
            if info_syslog_priority is not None:
                info.infoSyslogPriority = info_syslog_priority
            if unknown_escalate_message is not None:
                info.unknownEscalateMessage = unknown_escalate_message
            if unknown_syslog_facility is not None:
                info.unknownSyslogFacility = unknown_syslog_facility
            if unknown_syslog_priority is not None:
                info.unknownSyslogPriority = unknown_syslog_priority
            if warn_escalate_message is not None:
                info.warnEscalateMessage = warn_escalate_message
            if warn_syslog_facility is not None:
                info.warnSyslogFacility = warn_syslog_facility
            if warn_syslog_priority is not None:
                info.warnSyslogPriority = warn_syslog_priority
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_notify_job_info(self, job_exec_facility=None, job_exec_facility_flg=None, info_valid_flg=None, info_jobunit_id=None, info_job_id=None, info_job_failure_priority=None, warn_valid_flg=None, warn_jobunit_id=None, warn_job_id=None, warn_job_failure_priority=None, critical_valid_flg=None, critical_jobunit_id=None, critical_job_id=None, critical_job_failure_priority=None, unknown_valid_flg=None, unknown_jobunit_id=None, unknown_job_id=None, unknown_job_failure_priority=None):
        # Default
        job_exec_scope = ' '
        if job_exec_facility is None:
            job_exec_facility = None
            job_exec_scope = ''
        if job_exec_facility_flg is None:
            job_exec_facility_flg = 0
        if info_valid_flg is None:
            info_valid_flg = False
        if info_job_failure_priority is None:
            info_job_failure_priority = 1
        if warn_valid_flg is None:
            warn_valid_flg = False
        if warn_job_failure_priority is None:
            warn_job_failure_priority = 1
        if critical_valid_flg is None:
            critical_valid_flg = False
        if critical_job_failure_priority is None:
            critical_job_failure_priority = 1
        if unknown_valid_flg is None:
            unknown_valid_flg = False
        if unknown_job_failure_priority is None:
            unknown_job_failure_priority = 1

        obj_name = 'notifyJobInfo'
        try:
            info = self._client.factory.create(obj_name)
            if critical_valid_flg is not None:
                info.criticalValidFlg = critical_valid_flg
            if info_valid_flg is not None:
                info.infoValidFlg = info_valid_flg
            if unknown_valid_flg is not None:
                info.unknownValidFlg = unknown_valid_flg
            if warn_valid_flg is not None:
                info.warnValidFlg = warn_valid_flg
            if critical_job_failure_priority is not None:
                info.criticalJobFailurePriority = critical_job_failure_priority
            if critical_job_id is not None:
                info.criticalJobId = critical_job_id
            if critical_jobunit_id is not None:
                info.criticalJobunitId = critical_jobunit_id
            if info_job_failure_priority is not None:
                info.infoJobFailurePriority = info_job_failure_priority
            if info_job_id is not None:
                info.infoJobId = info_job_id
            if info_jobunit_id is not None:
                info.infoJobunitId = info_jobunit_id
            if job_exec_facility is not None:
                info.jobExecFacility = job_exec_facility
                info.jobExecScope = job_exec_scope
            if job_exec_facility_flg is not None:
                info.jobExecFacilityFlg = job_exec_facility_flg
            if unknown_job_failure_priority is not None:
                info.unknownJobFailurePriority = unknown_job_failure_priority
            if unknown_job_id is not None:
                info.unknownJobId = unknown_job_id
            if unknown_jobunit_id is not None:
                info.unknownJobunitId = unknown_jobunit_id
            if warn_job_failure_priority is not None:
                info.warnJobFailurePriority = warn_job_failure_priority
            if warn_job_id is not None:
                info.warnJobId = warn_job_id
            if warn_jobunit_id is not None:
                info.warnJobunitId = warn_jobunit_id
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_notify_event_info(self, info_valid_flg=None, info_event_normal_state=None, warn_valid_flg=None, warn_event_normal_state=None, critical_valid_flg=None, critical_event_normal_state=None, unknown_valid_flg=None, unknown_event_normal_state=None):
        # Default
        if info_valid_flg is None:
            info_valid_flg = False
        if info_event_normal_state is None:
            info_event_normal_state = 0
        if warn_valid_flg is None:
            warn_valid_flg = False
        if warn_event_normal_state is None:
            warn_event_normal_state = 0
        if critical_valid_flg is None:
            critical_valid_flg = False
        if critical_event_normal_state is None:
            critical_event_normal_state = 0
        if unknown_valid_flg is None:
            unknown_valid_flg = False
        if unknown_event_normal_state is None:
            unknown_event_normal_state = 0

        obj_name = 'notifyEventInfo'
        try:
            info = self._client.factory.create(obj_name)

            if critical_valid_flg is not None:
                info.criticalValidFlg = critical_valid_flg
            if info_valid_flg is not None:
                info.infoValidFlg = info_valid_flg
            if unknown_valid_flg is not None:
                info.unknownValidFlg = unknown_valid_flg
            if warn_valid_flg is not None:
                info.warnValidFlg = warn_valid_flg
            if critical_event_normal_state is not None:
                info.criticalEventNormalState = critical_event_normal_state
            if info_event_normal_state is not None:
                info.infoEventNormalState = info_event_normal_state
            if unknown_event_normal_state is not None:
                info.unknownEventNormalState = unknown_event_normal_state
            if warn_event_normal_state is not None:
                info.warnEventNormalState = warn_event_normal_state
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_notify_infra_info(self, infra_exec_facility=None, infra_exec_facility_flg=None, info_valid_flg=None, infra_info=None, info_infra_failure_priority=None, warn_valid_flg=None, infra_warn=None, warn_infra_failure_priority=None, critical_valid_flg=None, infra_critical=None, critical_infra_failure_priority=None, unknown_valid_flg=None, infra_unknown=None, unknown_infra_failure_priority=None):
        # Default
        infra_exec_scope = ' '
        if infra_exec_facility is None:
            infra_exec_facility = None
            infra_exec_scope = ''
        if infra_exec_facility_flg is None:
            infra_exec_facility_flg = 0
        if info_valid_flg is None:
            info_valid_flg = False
        if info_infra_failure_priority is None:
            info_infra_failure_priority = 1
        if warn_valid_flg is None:
            warn_valid_flg = False
        if warn_infra_failure_priority is None:
            warn_infra_failure_priority = 1
        if critical_valid_flg is None:
            critical_valid_flg = False
        if critical_infra_failure_priority is None:
            critical_infra_failure_priority = 1
        if unknown_valid_flg is None:
            unknown_valid_flg = False
        if unknown_infra_failure_priority is None:
            unknown_infra_failure_priority = 1

        obj_name = 'notifyInfraInfo'
        try:
            info = self._client.factory.create(obj_name)
            if critical_valid_flg is not None:
                info.criticalValidFlg = critical_valid_flg
            if info_valid_flg is not None:
                info.infoValidFlg = info_valid_flg
            if unknown_valid_flg is not None:
                info.unknownValidFlg = unknown_valid_flg
            if warn_valid_flg is not None:
                info.warnValidFlg = warn_valid_flg
            if critical_infra_failure_priority is not None:
                info.criticalInfraFailurePriority = critical_infra_failure_priority
            if infra_critical is not None:
                info.criticalInfraId = infra_critical
            if info_infra_failure_priority is not None:
                info.infoInfraFailurePriority = info_infra_failure_priority
            if infra_info is not None:
                info.infoInfraId = infra_info
            if infra_exec_facility is not None:
                info.infraExecFacility = infra_exec_facility
                info.infraExecScope = infra_exec_scope
            if infra_exec_facility_flg is not None:
                info.infraExecFacilityFlg = infra_exec_facility_flg
            if unknown_infra_failure_priority is not None:
                info.unknownInfraFailurePriority = unknown_infra_failure_priority
            if infra_unknown is not None:
                info.unknownInfraId = infra_unknown
            if warn_infra_failure_priority is not None:
                info.warnInfraFailurePriority = warn_infra_failure_priority
            if infra_warn is not None:
                info.warnInfraId = infra_warn
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    # 外部から直接イベント通知処理を実行します。
    def notifyUserExtentionEvent(self, event_notify_info):
        try:
            return self._client.service.notifyUserExtentionEvent(event_notify_info)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('notifyUserExtentionEvent failed, ' + str(e))
            raise ErrorHandler.APIError('notifyUserExtentionEvent is failed, ' + str(e))

    def create_event_notify_info(self, application, confirm_flg, facility_id, generation_date, message, message_org,
                                 monitor_detail, monitor_id, owner_role_id, plugin_id, priority, scope_text,
                                 user_item_01, user_item_02, user_item_03, user_item_04, user_item_05, user_item_06,
                                 user_item_07, user_item_08, user_item_09, user_item_10, user_item_11, user_item_12,
                                 user_item_13, user_item_14, user_item_15, user_item_16, user_item_17, user_item_18,
                                 user_item_19, user_item_20, user_item_21, user_item_22, user_item_23, user_item_24,
                                 user_item_25, user_item_26, user_item_27, user_item_28, user_item_29, user_item_30,
                                 user_item_31, user_item_32, user_item_33, user_item_34, user_item_35, user_item_36,
                                 user_item_37, user_item_38, user_item_39, user_item_40):
        obj_name = 'eventNotifyInfo'
        try:
            event_notify_info = self._client.factory.create(obj_name)

            ObjectModifier.replace_if_not_none(
                event_notify_info,
                application=application,
                confirmFlg=confirm_flg,
                facilityId=facility_id,
                generationDate=generation_date,
                message=message,
                messageOrg=message_org,
                monitorDetail=monitor_detail,
                monitorId=monitor_id,
                ownerRoleId=owner_role_id,
                pluginId=plugin_id,
                priority=priority,
                scopeText=scope_text,
                userItem01=user_item_01,
                userItem02=user_item_02,
                userItem03=user_item_03,
                userItem04=user_item_04,
                userItem05=user_item_05,
                userItem06=user_item_06,
                userItem07=user_item_07,
                userItem08=user_item_08,
                userItem09=user_item_09,
                userItem10=user_item_10,
                userItem11=user_item_11,
                userItem12=user_item_12,
                userItem13=user_item_13,
                userItem14=user_item_14,
                userItem15=user_item_15,
                userItem16=user_item_16,
                userItem17=user_item_17,
                userItem18=user_item_18,
                userItem19=user_item_19,
                userItem20=user_item_20,
                userItem21=user_item_21,
                userItem22=user_item_22,
                userItem23=user_item_23,
                userItem24=user_item_24,
                userItem25=user_item_25,
                userItem26=user_item_26,
                userItem27=user_item_27,
                userItem28=user_item_28,
                userItem29=user_item_29,
                userItem30=user_item_30,
                userItem31=user_item_31,
                userItem32=user_item_32,
                userItem33=user_item_33,
                userItem34=user_item_34,
                userItem35=user_item_35,
                userItem36=user_item_36,
                userItem37=user_item_37,
                userItem38=user_item_38,
                userItem39=user_item_39,
                userItem40=user_item_40
            )
            return event_notify_info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))
