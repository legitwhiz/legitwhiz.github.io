#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.model import BasicObject


class calendarInfo(BasicObject):
    __keylist__ = ['calendarDetailList', 'description', 'id', 'name', 'ownerRoleId', 'regDate', 'regUser', 'updateDate', 'updateUser', 'validTimeFrom', 'validTimeTo']

    calendarDetailList = []
    description = None
    id = None
    name = None
    ownerRoleId = None
    regDate = None
    regUser = None
    updateDate = None
    updateUser = None
    validTimeFrom = None
    validTimeTo = None

    def __init__(self):
        BasicObject.__init__(self)
        self.calendarDetailList = []

class commandExecType(BasicObject):
    __keylist__ = ['value']

    value = None

class customCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'command', 'commandExecType', 'convertFlg', 'effectiveUser', 'selectedFacilityId', 'specifyUser', 'timeout']

    monitorId = None
    monitorTypeId = None
    command = None
    commandExecType = None #commandExecType()
    convertFlg = None
    effectiveUser = None
    selectedFacilityId = None
    specifyUser = None
    timeout = None

    def __init__(self):
        BasicObject.__init__(self)
        self.commandExecType = commandExecType()

class customTrapCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'convertFlg', 'targetKey']

    monitorId = None
    monitorTypeId = None
    convertFlg = None
    targetKey = None

class httpCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'proxyHost', 'proxyPort', 'proxySet', 'requestUrl', 'timeout', 'urlReplace']

    monitorId = None
    monitorTypeId = None
    proxyHost = None
    proxyPort = None
    proxySet = None
    requestUrl = None
    timeout = None
    urlReplace = None

class httpScenarioCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'authPassword', 'authType', 'authUser', 'connectTimeout', 'monitoringPerPageFlg', 'pages', 'proxyFlg', 'proxyPassword', 'proxyPort', 'proxyUrl', 'proxyUser', 'requestTimeout', 'userAgent']

    monitorId = None
    monitorTypeId = None
    authPassword = None
    #authPasswordCrypt = None
    authType = None
    authUser = None
    connectTimeout = None
    monitoringPerPageFlg = None
    pages = []
    proxyFlg = None
    proxyPassword = None
    #proxyPasswordCrypt = None
    proxyPort = None
    proxyUrl = None
    proxyUser = None
    requestTimeout = None
    userAgent = None

    def __init__(self):
        BasicObject.__init__(self)
        self.pages = []

class jmxCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'authPassword', 'authUser', 'convertFlg', 'masterId', 'port']

    monitorId = None
    monitorTypeId = None
    authPassword = None
    #authPasswordCrypt = None
    authUser = None
    convertFlg = None
    masterId = None
    port = None

class logfileCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'directory', 'fileEncoding', 'fileName', 'fileReturnCode', 'logfile', 'maxBytes', 'patternHead', 'patternTail']

    monitorId = None
    monitorTypeId = None
    directory = None
    fileEncoding = None
    fileName = None
    fileReturnCode = None
    logfile = None
    maxBytes = None
    patternHead = None
    patternTail = None

class perfCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'breakdownFlg', 'deviceDisplayName', 'itemCode']

    monitorId = None
    monitorTypeId = None
    breakdownFlg = None
    deviceDisplayName = None
    itemCode = None

class pingCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'runCount', 'runInterval', 'timeout']

    monitorId = None
    monitorTypeId = None
    runCount = None
    runInterval = None
    timeout = None

class pluginCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'monitorPluginNumericInfoList', 'monitorPluginStringInfoList']

    monitorId = None
    monitorTypeId = None
    monitorPluginNumericInfoList = []
    monitorPluginStringInfoList = []

    def __init__(self):
        BasicObject.__init__(self)
        self.monitorPluginNumericInfoList = []
        self.monitorPluginStringInfoList = []

class portCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'portNo', 'runCount', 'runInterval', 'serviceId', 'timeout']

    monitorId = None
    monitorTypeId = None
    portNo = None
    runCount = None
    runInterval = None
    serviceId = None
    timeout = None

class processCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'caseSensitivityFlg', 'command', 'param']

    monitorId = None
    monitorTypeId = None
    caseSensitivityFlg = None
    command = None
    param = None

class snmpCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'communityName', 'convertFlg', 'snmpOid', 'snmpPort', 'snmpVersion']

    monitorId = None
    monitorTypeId = None
    communityName = None
    convertFlg = None
    snmpOid = None
    snmpPort = None
    snmpVersion = None

class sqlCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'connectionUrl', 'jdbcDriver', 'password', 'query', 'user']

    monitorId = None
    monitorTypeId = None
    connectionUrl = None
    jdbcDriver = None
    password = None
    query = None
    user = None

class trapCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'charsetConvert', 'charsetName', 'communityCheck', 'communityName', 'notifyofReceivingUnspecifiedFlg', 'priorityUnspecified', 'trapValueInfos']

    monitorId = None
    monitorTypeId = None
    charsetConvert = None
    charsetName = None
    communityCheck = None
    communityName = None
    notifyofReceivingUnspecifiedFlg = None
    priorityUnspecified = None
    trapValueInfos = []

    def __init__(self):
        BasicObject.__init__(self)
        self.trapValueInfos = []

class winEventCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'category', 'eventId', 'keywords', 'levelCritical', 'levelError', 'levelInformational', 'levelVerbose', 'levelWarning', 'logName', 'source']

    monitorId = None
    monitorTypeId = None
    category = []
    eventId = []
    keywords = []
    levelCritical = None
    levelError = None
    levelInformational = None
    levelVerbose = None
    levelWarning = None
    logName = []
    source = []

    def __init__(self):
        BasicObject.__init__(self)
        self.category = []
        self.eventId = []
        self.keywords = []
        self.logName = []
        self.source = []

class winServiceCheckInfo(BasicObject):
    __keylist__ = ['monitorId', 'monitorTypeId', 'serviceName']

    monitorId = None
    monitorTypeId = None
    serviceName = None

''' MonitorEndpoint.create_object('monitorInfo')
'''
class monitorInfo(BasicObject):
    __keylist__ = ['ownerRoleId', 'application', 'calendar', 'calendarId', 'collectorFlg', 'customCheckInfo', 'customTrapCheckInfo', 'delayTime', 'description', 'facilityId', 'failurePriority', 'httpCheckInfo', 'httpScenarioCheckInfo', 'itemName', 'jmxCheckInfo', 'logFormatId', 'logfileCheckInfo', 'measure', 'monitorFlg', 'monitorId', 'monitorType', 'monitorTypeId', 'notifyGroupId', 'notifyRelationList', 'numericValueInfo', 'perfCheckInfo', 'pingCheckInfo', 'pluginCheckInfo', 'portCheckInfo', 'processCheckInfo', 'regDate', 'regUser', 'runInterval', 'scope', 'snmpCheckInfo', 'sqlCheckInfo', 'stringValueInfo', 'trapCheckInfo', 'triggerType', 'truthValueInfo', 'updateDate', 'updateUser', 'winEventCheckInfo', 'winServiceCheckInfo']

    ownerRoleId = None
    application = None
    calendar = None
    calendarId = None
    collectorFlg = None
    customCheckInfo = None
    customTrapCheckInfo = None
    delayTime = None
    description = None
    facilityId = None
    failurePriority = None
    httpCheckInfo = None
    httpScenarioCheckInfo = None
    itemName = None
    jmxCheckInfo = None
    logFormatId = None
    logfileCheckInfo = None
    measure = None
    monitorFlg = None
    monitorId = None
    monitorType = None
    monitorTypeId = None
    notifyGroupId = None
    notifyRelationList = []
    numericValueInfo = []
    perfCheckInfo = None
    pingCheckInfo = None
    pluginCheckInfo = None
    portCheckInfo = None
    processCheckInfo = None
    regDate = None
    regUser = None
    runInterval = None
    scope = None
    snmpCheckInfo = None
    sqlCheckInfo = None
    stringValueInfo = []
    trapCheckInfo = None
    triggerType = None
    truthValueInfo = []
    updateDate = None
    updateUser = None
    winEventCheckInfo = None
    winServiceCheckInfo = None

    def __init__(self):
        BasicObject.__init__(self)

        self.calendar = calendarInfo()
        self.customCheckInfo = customCheckInfo()
        self.customTrapCheckInfo = customTrapCheckInfo()
        self.httpCheckInfo = httpCheckInfo()
        self.httpScenarioCheckInfo = httpScenarioCheckInfo()
        self.jmxCheckInfo = jmxCheckInfo()
        self.logfileCheckInfo = logfileCheckInfo()
        self.notifyRelationList= []
        self.numericValueInfo = []
        self.perfCheckInfo = perfCheckInfo()
        self.pingCheckInfo = pingCheckInfo()
        self.pluginCheckInfo = pluginCheckInfo()
        self.portCheckInfo = portCheckInfo()
        self.processCheckInfo = processCheckInfo()
        self.snmpCheckInfo = snmpCheckInfo()
        self.sqlCheckInfo = sqlCheckInfo()
        self.stringValueInfo = []
        self.trapCheckInfo = trapCheckInfo()
        self.truthValueInfo = []
        self.winEventCheckInfo = winEventCheckInfo()
        self.winServiceCheckInfo = winServiceCheckInfo()


''' MonitorEndpoint.create_object('trapValueInfo')
'''
class trapValueInfo(BasicObject):
    __keylist__ = ['description', 'formatVarBinds', 'genericId', 'logmsg', 'mib', 'priorityAnyVarbind', 'processingVarbindSpecified', 'specificId', 'trapOid', 'uei', 'validFlg', 'varBindPatterns', 'version']

    description = None
    formatVarBinds = None
    genericId = None
    logmsg = None
    mib = None
    priorityAnyVarbind = None
    processingVarbindSpecified = None
    specificId = None
    trapOid = None
    uei = None
    validFlg = None
    varBindPatterns = []
    version = None

    def __init__(self):
        BasicObject.__init__(self)

        self.varBindPatterns = []

''' MonitorEndpoint.create_object('varBindPattern')
'''
class varBindPattern(BasicObject):
    __keylist__ = ['caseSensitivityFlg', 'description', 'pattern', 'priority', 'processType', 'validFlg']

    caseSensitivityFlg = None
    description = None
    pattern = None
    priority = None
    processType = None
    validFlg = None

