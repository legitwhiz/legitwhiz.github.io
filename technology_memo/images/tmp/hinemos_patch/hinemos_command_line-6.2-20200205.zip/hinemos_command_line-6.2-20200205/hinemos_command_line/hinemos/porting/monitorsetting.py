# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api.helper import BasicFormatter
import re
import types
from hinemos.model.virtual import AgentCheckInfo, SyslogCheckInfo
from hinemos.porting import xdata_has, xdata_get, xdata_set, xdata_find, xdata_del, xdata_appendforce, xdata_findall, xdata_removeall, xdata_remove_bycond 
from hinemos.util.monitorsetting import MonitorSettingUtil

'''
    DEPRECATED
    Format: ('Object/dict variable path', 'reorganize to')
    ! Must be in depth order
'''
tag_rename_list = (\
    ('agentCheckInfo', 'agentInfo'),\
    ('syslogCheckInfo', 'syslogInfo'),\
    ('sqlCheckInfo', 'sqlInfo'),\
    ('snmpCheckInfo', 'snmpInfo'),\
    ('processCheckInfo', 'processInfo'),\
    ('portCheckInfo', 'portInfo'),\
    ('pingCheckInfo', 'pingInfo'),\
    ('perfCheckInfo', 'perfInfo'),\
    ('logfileCheckInfo', 'logfileInfo'),\
    ('logfileCheckInfo/patternHead', 'filePatternHead'),\
    ('logfileCheckInfo/patternTail', 'filePatternTail'),\
    ('logfileCheckInfo/maxBytes', 'fileMaxBytes'),\
    ('winServiceCheckInfo', 'winServiceInfo'),\
    ('stringValueInfo', 'stringValue'),\
    ('numericValueInfo', 'numericValue'),\
    ('truthValueInfo', 'truthValue'),\
    ('customCheckInfo', 'customInfo'),\
    ('customCheckInfo/commandExecType', 'executeType'),\
    ('customTrapCheckInfo', 'customTrapInfo'),\
    ('jmxCheckInfo', 'jmxInfo'),\
    ('httpCheckInfo', 'httpInfo'),\
    ('httpScenarioCheckInfo', 'httpScenarioInfo'),\
    ('httpScenarioCheckInfo/pages', 'pageValue'),\
    ('httpScenarioCheckInfo/pages/patterns', 'patternValue'),\
    ('httpScenarioCheckInfo/pages/variables', 'variableValue'),\
    ('trapCheckInfo', 'snmpTrapInfo'),\
    ('winEventCheckInfo', 'winEventInfo'),\
    ('winEventCheckInfo/logName', 'log'),\
    ('winEventCheckInfo/keywords', 'keyword'),\
    ('winEventCheckInfo/logName/logName', 'log'),\
    ('winEventCheckInfo/keywords/keywords', 'keyword'))

''' Convert xdata elements to timestamp '''
CONVLST_TIMESTAMP = ('regDate', 'updateDate')

''' Rename xdata element's attributes to timestamp '''
CONVMAP_ATTRS = ()

'''
    Format: ('Object/dict variable path', 'reorganize to')
    ! Must be in depth order
'''
CONVMAP_MOVE_TAGS = (
    ('delayTime',       None), # None for removal
    ('failurePriority', None),
    ('notifyGroupId',   None),
    ('triggerType',     None),
    ('httpScenarioCheckInfo/authPasswordCrypt',     None),
    ('httpScenarioCheckInfo/proxyPasswordCrypt',     None),
    ('jmxCheckInfo/authPasswordCrypt',     None),
    ('sqlCheckInfo/passwordCrypt',     None),
    ('monitorId',   'monitor/monitorId'),
    ('facilityId',  'monitor/facilityId'),
    ('calendarId',  'monitor/calendarId'),
    ('description',  'monitor/description'),
    ('scope',       'monitor/scope'),
    ('monitorType', 'monitor/monitorType'),
    ('monitorTypeId', 'monitor/monitorTypeId'),
    ('runInterval',  'monitor/runInterval'),
    ('application',  'monitor/application'),
    ('monitorFlg',   'monitor/monitorFlg'),
    ('collectorFlg', 'monitor/collectorFlg'),
    ('itemName',     'monitor/itemName'),
    ('measure',      'monitor/measure'),
    ('logFormatId',  'monitor/logFormatId'),
    ('ownerRoleId',  'monitor/ownerRoleId'),
    ('regDate',      'monitor/regDate'),
    ('regUser',      'monitor/regUser'),
    ('updateDate',   'monitor/updateDate'),
    ('updateUser',   'monitor/updateUser'),
    ('notifyRelationList',   'monitor/notifyId'),
    ('trapCheckInfo/monitorId',  None), # UTILHC
    ('snmpCheckInfo/snmpVersion', None), # HC
    ('httpScenarioCheckInfo/proxyPasswordCrypt', None))

CONVMAP_RENAME_TAGS = (
    ('stringValueInfo', 'stringValue'),
    ('numericValueInfo', 'numericValue'),
    ('truthValueInfo', 'truthValue'),
    ('agentCheckInfo', 'agentInfo'),
    ('customCheckInfo/commandExecType', 'executeType'),
    ('customCheckInfo', 'customInfo'),
    ('customTrapCheckInfo', 'customTrapInfo'),
    ('logfileCheckInfo/patternHead', 'filePatternHead'),
    ('logfileCheckInfo/patternTail', 'filePatternTail'),
    ('logfileCheckInfo/maxBytes', 'fileMaxBytes'),
    ('logfileCheckInfo', 'logfileInfo'), # Must be in order, a/b > a
    ('syslogCheckInfo', 'syslogInfo'),
    ('sqlCheckInfo', 'sqlInfo'),
    ('snmpCheckInfo', 'snmpInfo'),
    ('httpScenarioCheckInfo/pages/patterns', 'patternValue'),
    ('httpScenarioCheckInfo/pages/variables', 'variableValue'),
    ('httpScenarioCheckInfo/pages', 'pageValue'),
    ('winServiceCheckInfo', 'winServiceInfo'),
    ('jmxCheckInfo', 'jmxInfo'),
    ('httpCheckInfo', 'httpInfo'),
    ('httpScenarioCheckInfo', 'httpScenarioInfo'),
    ('trapCheckInfo', 'snmpTrapInfo'),
    ('processCheckInfo', 'processInfo'),
    ('portCheckInfo', 'portInfo'),
    ('pingCheckInfo', 'pingInfo'),
    ('perfCheckInfo', 'perfInfo'),
    ('winEventCheckInfo/keywords', 'keyword'),
    ('winEventCheckInfo/logName', 'log'),
    ('winEventCheckInfo', 'winEventInfo'))


def inverse_tag_rename_list(org_rename_list):
    tmp_dict = dict(org_rename_list)
    inverse_list = []
    for pair in org_rename_list:
        tags = pair[0].split('/')
        new_key = pair[1]
        new_val = tags[-1]

        level = len(tags)
        if level > 1:
            for i in reversed(xrange(level-1)):
                new_key = tmp_dict['/'.join(tags[:(i+1)])] + '/' +new_key
        inverse_list.append((new_key, new_val))
    return inverse_list

def format_input_xml(element):
    if element.tag == 'agentMonitor':
        element.remove(element.find('agentCheckInfo'))
    elif element.tag == 'syslogMonitor':
        element.remove(element.find('syslogCheckInfo'))

def format_input(info):
    info.failurePriority = 1
    info.regDate = None
    info.regUser = None
    info.updateDate = None
    info.updateUser = None

    if hasattr(info, 'stringValueInfo'):
        for x in info.stringValueInfo:
            if x.message is None: x.message = ''

    if hasattr(info, 'numericValueInfo'):
        for x in info.numericValueInfo:
            if x.message is None: x.message = ''
    if hasattr(info, 'truthValueInfo'):
        for x in info.truthValueInfo:
            if x.message is None: x.message = ''

    # Remove non-related subinfo
    #if info.monitorTypeId != 'MON_AGT_B' and 'XXXXXX' in info:
    #    delattr(info, 'XXXXXX')
    if info.monitorTypeId != 'MON_CUSTOM_N' and info.monitorTypeId != 'MON_CUSTOM_S' and 'customCheckInfo' in info:
        delattr(info, 'customCheckInfo')
    if info.monitorTypeId != 'MON_CUSTOMTRAP_N' and info.monitorTypeId != 'MON_CUSTOMTRAP_S' and 'customTrapCheckInfo' in info:
        delattr(info, 'customTrapCheckInfo')
    if info.monitorTypeId != 'MON_HTP_N' and info.monitorTypeId != 'MON_HTP_S' and 'httpCheckInfo' in info:
        delattr(info, 'httpCheckInfo')
    if info.monitorTypeId != 'MON_HTP_SCE' and 'httpScenarioCheckInfo' in info:
        delattr(info, 'httpScenarioCheckInfo')
    if info.monitorTypeId != 'MON_PRF_N' and 'perfCheckInfo' in info:
        delattr(info, 'perfCheckInfo')
    if info.monitorTypeId != 'MON_PNG_N' and 'pingCheckInfo' in info:
        delattr(info, 'pingCheckInfo')
    if info.monitorTypeId != 'MON_PRT_N' and 'portCheckInfo' in info:
        delattr(info, 'portCheckInfo')
    if info.monitorTypeId != 'MON_PRC_N' and 'processCheckInfo' in info:
        delattr(info, 'processCheckInfo')
    if info.monitorTypeId != 'MON_SNMP_N' and info.monitorTypeId != 'MON_SNMP_S' and 'snmpCheckInfo' in info:
        delattr(info, 'snmpCheckInfo')
    if info.monitorTypeId != 'MON_SNMP_TRP' and 'trapCheckInfo' in info:
        delattr(info, 'trapCheckInfo')
    if info.monitorTypeId != 'MON_SQL_N' and info.monitorTypeId != 'MON_SQL_S' and 'sqlCheckInfo' in info:
        delattr(info, 'sqlCheckInfo')
    #if info.monitorTypeId != 'MON_SYSLOG_S' and 'XXXXXX' in info:
    #    delattr(info, 'XXXXXX')
    if info.monitorTypeId != 'MON_LOGFILE_S' and 'logfileCheckInfo' in info:
        delattr(info, 'logfileCheckInfo')
    if info.monitorTypeId != 'MON_WINSERVICE_B' and 'winServiceCheckInfo' in info:
        delattr(info, 'winServiceCheckInfo')
    if info.monitorTypeId != 'MON_WINEVENT_S' and 'winEventCheckInfo' in info:
        delattr(info, 'winEventCheckInfo')
    if info.monitorTypeId != 'MON_JMX_N' and 'jmxCheckInfo' in info:
        delattr(info, 'jmxCheckInfo')


def format_output(monitor_info):
    delattr(monitor_info, 'failurePriority')
    BasicFormatter.output(monitor_info)
    if hasattr(monitor_info, 'stringValueInfo'):
        i = 1
        for x in monitor_info.stringValueInfo:
            if not x.message: delattr(x, 'message')
            setattr(x, 'orderNo', i)
            i += 1
    if hasattr(monitor_info, 'numericValueInfo'):
        for x in monitor_info.numericValueInfo:
            if 'message' in x: delattr(x, 'message')
    if hasattr(monitor_info, 'truthValueInfo'):
        for x in monitor_info.truthValueInfo:
            if 'message' in x: delattr(x, 'message')

    if hasattr(monitor_info, 'httpScenarioCheckInfo') and hasattr(monitor_info.httpScenarioCheckInfo, 'pages'):
        i = 1
        for page in monitor_info.httpScenarioCheckInfo.pages:
            if 'monitorId' not in page: page.monitorId = monitor_info.monitorId
            if 'monitorTypeId' not in page: page.monitorTypeId = monitor_info.monitorTypeId

            setattr(page, 'pageOrderNo', i)
            i += 1

            if 'patterns' in page:
                j = 1
                for subsubinfo in page.patterns:
                    # BAD HC
                    if not hasattr(subsubinfo, 'monitorId'):
                        setattr(subsubinfo, 'monitorId', None)
                    if hasattr(subsubinfo, 'monitorTypeId'):
                        delattr(subsubinfo, 'monitorTypeId')
                    setattr(subsubinfo, 'patternOrderNo', j)
                    j += 1
            if 'variables' in page:
                for subsubinfo in page.variables:
                    # BAD HC
                    if not hasattr(subsubinfo, 'monitorId'):
                        setattr(subsubinfo, 'monitorId', None)
                    if hasattr(subsubinfo, 'monitorTypeId'):
                        delattr(subsubinfo, 'monitorTypeId')

    if hasattr(monitor_info, 'trapCheckInfo') and hasattr(monitor_info.trapCheckInfo, 'trapValueInfos'):
        for trap_info in monitor_info.trapCheckInfo.trapValueInfos:
            if hasattr(trap_info, 'varBindPatterns'):
                i = 1
                for pat in trap_info.varBindPatterns:
                    setattr(pat, 'orderNo', i)
                    i += 1

    if hasattr(monitor_info, 'customCheckInfo'):
        if 'SELECTED' == monitor_info.customCheckInfo.commandExecType: # HC
            monitor_info.customCheckInfo.commandExecType = 1
        else:
            monitor_info.customCheckInfo.commandExecType = 0

    if hasattr(monitor_info, 'trapCheckInfo'):
        if hasattr(monitor_info.trapCheckInfo, 'monitorId'):
            delattr(monitor_info.trapCheckInfo, 'monitorId')
        if hasattr(monitor_info.trapCheckInfo, 'monitorTypeId'):
            delattr(monitor_info.trapCheckInfo, 'monitorTypeId')

    if hasattr(monitor_info, 'processCheckInfo'):
        if True == monitor_info.processCheckInfo.caseSensitivityFlg:
            monitor_info.processCheckInfo.caseSensitivityFlg = 1
        else:
            monitor_info.processCheckInfo.caseSensitivityFlg = 0

    if hasattr(monitor_info, 'snmpCheckInfo'):
        if hasattr(monitor_info.snmpCheckInfo, 'snmpVersion'):
            delattr(monitor_info.snmpCheckInfo, 'snmpVersion')

    # Unify special-cases
    if monitor_info.monitorTypeId == 'MON_AGT_B' and 'agentCheckInfo' not in monitor_info:
        monitor_info['agentCheckInfo'] = AgentCheckInfo()
        monitor_info['agentCheckInfo'].monitorId = monitor_info.monitorId
        monitor_info['agentCheckInfo'].monitorTypeId =  monitor_info.monitorTypeId
    elif monitor_info.monitorTypeId == 'MON_SYSLOG_S' and 'syslogCheckInfo' not in monitor_info:
        monitor_info['syslogCheckInfo'] = SyslogCheckInfo()
        monitor_info['syslogCheckInfo'].monitorId = monitor_info.monitorId
        monitor_info['syslogCheckInfo'].monitorTypeId =  monitor_info.monitorTypeId

    # Extend to monitorInfo.monitor
    monitor_dict = {}
    for attr in dir(monitor_info):
        if not attr.startswith('__'):
            val = getattr(monitor_info, attr)
            if type(val) is not types.InstanceType and not re.match(r'(numeric|string|truth)ValueInfo', attr):
                monitor_dict[attr] = val
                delattr(monitor_info, attr)
    setattr(monitor_info, 'monitor', monitor_dict)

def format_xdata_pre(xdata):
    # By group (num/str/bool/trap)
    if xdata_has(xdata, 'numericValueInfo'):
        # HC: Remove the 0 and 1 numericValueInfo
        xdata_remove_bycond(xdata, 'numericValueInfo/priority', 0)
        xdata_remove_bycond(xdata, 'numericValueInfo/priority', 1)

    if xdata_has(xdata, 'stringValueInfo'):
        # Insert orderNo
        tmp = xdata_findall(xdata, 'stringValueInfo')
        i = 1
        for a in tmp:
            (_,v) = a.items()[0]
            xdata_appendforce(v, 'orderNo', i)
            i += 1

    # By monitor typd ID
    #if 'MON_AGT_B' == xdata_get(xdata, 'monitorTypeId'):
        # UTILHC Add sub tag: <agentInfo><monitorId>AGENT001</monitorId><monitorTypeId/></agentInfo>

    if 'MON_HTP_SCE' == xdata_get(xdata, 'monitorTypeId'):
        # TODO Support in CONVMAP_MOVE_TAGS
        # HC Move tags
        tmp = xdata_findall(xdata, 'httpScenarioCheckInfo/pages')
        for a in tmp:
            (_, v) = a.items()[0]
            subdata = xdata_get(v, 'id')
            v.extend(subdata)
            xdata_del(v, 'id')

    if 'MON_WINEVENT_S' == xdata_get(xdata, 'monitorTypeId'):
        # TODO Support in CONVMAP_MOVE_TAGS
        # HC Move tags
        tmp = xdata_findall(xdata, 'winEventCheckInfo/keywords')
        for a in tmp:
            (k, v) = a.items()[0]
            a[k] = [{'keyword': v}]
        tmp = xdata_findall(xdata, 'winEventCheckInfo/category')
        for a in tmp:
            (k, v) = a.items()[0]
            a[k] = [{'category': v}]
        tmp = xdata_findall(xdata, 'winEventCheckInfo/logName')
        for a in tmp:
            (k, v) = a.items()[0]
            a[k] = [{'log': v}]
        tmp = xdata_findall(xdata, 'winEventCheckInfo/source')
        for a in tmp:
            (k, v) = a.items()[0]
            a[k] = [{'source': v}]

    monitor_id = xdata_get(xdata, 'monitorId')
    monitor_type_id = xdata_get(xdata, 'monitorTypeId')
    if 'MON_CUSTOM_N' == monitor_type_id or 'MON_CUSTOM_S' == monitor_type_id:
        tmp = xdata_get(xdata, 'customCheckInfo/commandExecType')
        xdata_set(xdata, 'customCheckInfo/commandExecType', MonitorSettingUtil.convert_command_exec_type(tmp))

    if monitor_type_id == 'MON_SYSLOG_S':
        xdata_appendforce(xdata, 'syslogInfo', [{'monitorId':monitor_id},{'monitorTypeId':monitor_type_id}])

    if monitor_type_id == 'MON_AGT_B':
        xdata_appendforce(xdata, 'agentInfo', [{'monitorId':monitor_id},{'monitorTypeId':monitor_type_id}])

    if monitor_type_id == 'MON_HTP_SCE':
        found = xdata_findall(xdata, 'httpScenarioCheckInfo/pages')
        if found:
            for a in found:
                found2 = xdata_find(a['pages'], 'monitorId')
                if found2 is None:
                    a['pages'].extend([{'monitorId':monitor_id}])
                found2 = xdata_find(a['pages'], 'monitorTypeId')
                if found2 is None:
                    a['pages'].extend([{'monitorTypeId':monitor_type_id}])

                found2 = xdata_findall(a['pages'], 'patterns')
                if found2:
                    for b in found2:
                        b['patterns'].extend([{'monitorId':monitor_id}])

                found2 = xdata_findall(a['pages'], 'variables')
                if found2:
                    for b in found2:
                        b['variables'].extend([{'monitorId':monitor_id}])

                found2 = xdata_findall(a['pages'], 'patterns')
                if found2:
                    i = 0
                    for b in found2:
                        i += 1
                        b['patterns'].extend([{'patternOrderNo':i}])

        # UTIL BUG order+1
        found = xdata_findall(xdata, 'httpScenarioCheckInfo/pages/pageOrderNo')
        if found:
            for a in found:
                a['pageOrderNo'] += 1

        xdata_removeall(xdata, 'numericValueInfo')

    if monitor_type_id == 'MON_PRC_N':
        found = xdata_find(xdata, 'processCheckInfo/caseSensitivityFlg')
        if found:
            found['caseSensitivityFlg'] = 1 if found['caseSensitivityFlg'] is True else 0

    if monitor_type_id == 'MON_SNMP_TRP':
        found = xdata_findall(xdata, 'trapCheckInfo/trapValueInfos/varBindPatterns')
        if found:
            i = 0
            for a in found:
                i += 1
                a['varBindPatterns'].extend([{'orderNo':i}])

    if monitor_type_id == 'MON_WINEVENT_S':
        found = xdata_findall(xdata, 'winEventCheckInfo/eventId')
        if found:
            for a in found:
                a['eventId'] = [{'eventId':a['eventId']}]

    # Utilityの場合、デバイス別以外の監視項目は<deviceDisplayName/>を出力するため統一
    if monitor_type_id == 'MON_PRF_N':
        found = xdata_find(xdata, 'perfCheckInfo/deviceDisplayName')
        if found:
            if found['deviceDisplayName'] is None:
                found['deviceDisplayName'] = ''
