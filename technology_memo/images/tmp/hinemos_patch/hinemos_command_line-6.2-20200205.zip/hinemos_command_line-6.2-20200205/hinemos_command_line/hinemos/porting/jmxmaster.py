# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------


'''
    must be in deep order
'''
attr_rename_list = {'id': 'masterId'}

def format_output(info):
    if info.keys is None:
        info.keys = ''
