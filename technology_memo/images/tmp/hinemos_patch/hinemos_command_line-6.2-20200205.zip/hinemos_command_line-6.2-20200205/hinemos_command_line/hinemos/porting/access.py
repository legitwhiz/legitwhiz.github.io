# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import re
import hinemos.api.exceptions as ErrorHandler
from copy import deepcopy
from hinemos.util.common import ResultPrinter

'''
    {ypath1:new_attr_name, ...}
'''
attr_rename_list = {\
                    'UserInfo': {'userName':'name'}\
                    }

def inverse_attr_rename_list(rename_list):
    inv_list={}
    for k, v in rename_list.iteritems():
        inv_list[k] = dict(zip(v.values(), v.keys()))
    return inv_list

def create_user_info_list(tree, endpoint):
    userInfoList = []
    elem = tree.getroot()
    try:
        for el in elem:
            if el.tag == 'UserInfo':
                u'''
                userInfo を生成し、リストに追加
                '''
                userInfo = endpoint.create_object('userInfo')
                temp = str(el.attrib).split(',')
                for s in temp:
                    p = re.compile('\'.*\':')
                    m = p.search(s, 0)
                    if m:
                        attribute = s[m.start()+1:m.end()-2]
                        if attribute == 'userId':
                            userInfo['userId'] = el.get(attribute)
                        else:
                            userInfo[attribute] = el.get(attribute)
                if 'password' in userInfo:
                    del userInfo.password
                if userInfo.userId != 'hinemos':
                    userInfoList.append(userInfo)
        return userInfoList
    except Exception, e:
        raise ErrorHandler.FileReadError('create userInfoList failed, ' + str(e))

def create_role_info_list(tree, endpoint):
    roleInfoList = []
    elem = tree.getroot()
    try:
        for el in elem.iterfind('RoleInfo'):
            u'''
            roleInfo を生成し、リストに追加
            '''
            roleInfo = endpoint.create_object('roleInfo')
            temp = str(el.attrib).split(',')
            for s in temp:
                p = re.compile('\'.*\':')
                m = p.search(s, 0)
                if m:
                    attribute = s[m.start()+1:m.end()-2]
                    roleInfo[attribute] = el.get(attribute)
            roleInfoList.append(roleInfo)
        return roleInfoList
    except Exception, e:
        raise ErrorHandler.FileReadError('create roleInfoList failed, ' + str(e))

def create_account_role_user_list(tree, endpoint):
    account_role_user_list = []
    my_list = []
    elem = tree.getroot()

    try:
        for el in elem:
            if el.tag == 'RoleUserInfo':
                u'''
                roleInfo を生成し、リストに追加
                '''
                accountRoleUser = ['', '']
                temp = str(el.attrib).split(',')
                for s in temp:
                    p = re.compile('\'.*\':')
                    m = p.search(s, 0)
                    if m:
                        attribute = s[m.start()+1:m.end()-2]
                        if attribute == 'roleId':
                            accountRoleUser[0] = el.get(attribute)
                        elif attribute == 'userId':
                            accountRoleUser[1] = el.get(attribute)
                my_list.append(accountRoleUser)
        u'''
                       ロールへのユーザの割り当てリストを生成
        '''
        for i in range(len(my_list)):
            if len(account_role_user_list) == 0:
                accountRoleUser = [my_list[i][0], my_list[i][1]]
                account_role_user_list.append(accountRoleUser)
            else:
                flg = True
                for j in range(len(account_role_user_list)):
                    if my_list[i][0] == account_role_user_list[j][0]:
                        account_role_user_list[j][1] = account_role_user_list[j][1] + ',' + my_list[i][1]
                        flg = False
                        break
                if flg:
                    accountRoleUser = [my_list[i][0], my_list[i][1]]
                    account_role_user_list.append(accountRoleUser)
        return account_role_user_list
    except Exception, e:
        raise ErrorHandler.FileReadError('create accountRoleUser failed, ' + str(e))

def create_system_privilege_info_list(tree, role_id, sysprivil_info_tpl):
    info_lst = []
    elem = tree.getroot()

    try:
        for el in elem.iterfind('SystemPrivilegeInfo'):
            u'''
            systemPrivilegeInfo を生成し、リストに追加
            '''
            if el.get('roleId') == role_id:
                info = deepcopy(sysprivil_info_tpl)
                info.systemFunction = el.get('systemFunction')
                info.systemPrivilege = el.get('systemPrivilege')
                info_lst.append(info)
        return info_lst
    except Exception, e:
        raise ErrorHandler.FileReadError('create objectPrivilegeInfoList failed, ' + str(e))

def import_system_privilege(porting_xml, endpoint, stop_if_error=False, update_mode=False, delete_mode=False):
    queue_set = set()

    for elem in porting_xml.element_tree.getroot().iterfind('SystemPrivilegeInfo'):
        queue_set.add(elem.get('roleId'))

    info_tpl = endpoint.create_object('systemPrivilegeInfo')
    while len(queue_set) > 0:
        role_id = queue_set.pop()

        # @see com.clustercontrol.fault.UnEditableRole
        if role_id == 'ADMINISTRATORS':
            ResultPrinter.warning('ADMINISTRATORS is uneditable. It will be skipped.')
            continue

        # Load existing info list
        info_lst = endpoint.getSystemPrivilegeInfoListByRoleId(role_id)
        exists = len(info_lst) > 0
        if update_mode:
            # Clear the list if in update mode
            info_lst = []
        check_func_set = set(info.systemFunction for info in info_lst)
        for elem in porting_xml.element_tree.getroot().iterfind('SystemPrivilegeInfo[@roleId=\'%s\']' % role_id):
            ResultPrinter.info('addSystemPrivilege %s,%s,%s...' % (elem.get('roleId'),elem.get('systemFunction'),elem.get('systemPrivilege')))

            try:
                if elem.get('systemFunction') in check_func_set:
                    raise ErrorHandler.APIError('addSystemPrivilege failed. Setting already exists.')
                else:
                    info = deepcopy(info_tpl)
                    info.systemFunction = elem.get('systemFunction')
                    info.systemPrivilege = elem.get('systemPrivilege')
                    info_lst.append(info)
            except Exception, e:
                if stop_if_error:
                    raise e
                else:
                    ResultPrinter.failure(e)
        if exists:
            ResultPrinter.info('updateSystemPrivilege %s...' % role_id)
        endpoint.replaceSystemPrivilegeRole(role_id, info_lst)

    # Delete settings do not exist in XML (-d)
    if delete_mode:
        all_role_id_lst = tuple(info.id for info in endpoint.get_role_info_list())
        # for each roleID
        for role_id in all_role_id_lst:
            # @see com.clustercontrol.fault.UnEditableRole
            if role_id == 'ADMINISTRATORS':
                ResultPrinter.warning('ADMINISTRATORS is uneditable. It will be skipped.')
                continue

            # Load XML info list
            imported_lst = tuple((elem.get('systemFunction'),elem.get('systemPrivilege')) for elem in porting_xml.element_tree.getroot().iterfind('SystemPrivilegeInfo[@roleId=\'%s\']' % role_id))
            # Get DB info list
            existing_info_lst = endpoint.get_system_privilege_info_list_by_role_id(role_id)

            remove_idx_lst = []
            for i, info in enumerate(existing_info_lst):
                if (info.systemFunction, info.systemPrivilege) not in imported_lst:
                    remove_idx_lst.append(i)
            if len(remove_idx_lst) > 0:
                # remove from info list and replace
                for i in reversed(remove_idx_lst):
                    info = existing_info_lst.pop(i)
                    ResultPrinter.info('deleteSystemPrivilege %s, %s, %s...' % (role_id, info.systemFunction, info.systemPrivilege))

                ResultPrinter.info('replaceSystemPrivilege %s...' % role_id)
                endpoint.replace_system_privilege_role(role_id, existing_info_lst)
