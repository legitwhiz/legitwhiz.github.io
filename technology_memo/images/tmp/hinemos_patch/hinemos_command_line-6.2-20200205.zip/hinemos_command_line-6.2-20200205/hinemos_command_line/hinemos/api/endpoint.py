import os
import ConfigParser
from requests import Session
from requests.auth import HTTPBasicAuth
from zeep import Client
from zeep.transports import Transport
from zeep.cache import SqliteCache
from hinemos.api import exceptions as ErrorHandler
from hinemos.api import url_autocomplete
from hinemos.util.common import ResultPrinter
#do not warn for not verifying SSL certificate
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class Endpoint(object):

    def __init__(self, url, user, passwd, endpoint, **kwargs):
        self._client = self.create_conn(url_autocomplete(url), user, passwd, endpoint, **kwargs)

    def create_conn(self, url, user, passwd, endpoint, **kwargs):
        session = Session()
        session.auth = HTTPBasicAuth(user, passwd)
        #do not verify ssl certificate
        session.verify = False

        client_cfg = self.get_client_cfg()
        cache = SqliteCache(path=client_cfg['cache_dir'],
                            timeout=client_cfg['cache_duration'])
        self.load_precache(cache)

        trans = Transport(session=session, cache=cache,
                          timeout=client_cfg['connection_timeout'])

        url += endpoint + 'Endpoint?wsdl'
        client = Client(url,
                        transport=trans,
                        strict=kwargs.get('xml_strict', True))
        return client

    def get_obj(self, namespace, obj_name):
        return self._client.get_type(namespace + ':' + obj_name)()

    def echo(self, echo_string):
        return self._client.service.echo(echo_string)

    def load_precache(self, cache_obj):
        precache_dir = os.path.join(os.path.dirname(__file__), 'precache')
        cache_files = {'xmlmime.xml': 'http://www.w3.org/2005/05/xmlmime'}
        for file in cache_files:
            self.load_precashed_file(os.path.join(precache_dir, file),
                                     cache_files[file],
                                     cache_obj)

    def load_precashed_file(self, path, url, cache_obj):
        with open(path, 'r') as f:
            content = f.read()
        cache_obj.add(url, content)

    def get_client_cfg(self):
        inifile = ConfigParser.SafeConfigParser(
            {'connection_timeout': '30',
             'cache_duration': '86400',
             'cache_dir': None}
        )
        inifile.read(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  '..', '..', 'settings.ini'))

        cfg = {
            'connection_timeout': inifile.getint(
                'SOAPclient', 'connection_timeout'),
            'cache_dir': inifile.get('SOAPclient', 'cache_dir'),
            'cache_duration': inifile.getint('SOAPclient', 'cache_duration')
        }
        if cfg['cache_dir'] == '':
            cfg['cache_dir'] = None
        return cfg

    def call(self, service_name, *args):
        service = getattr(self._client.service, service_name)
        try:
            return service(*args)
        except ErrorHandler.LoginError, e:
            return_code = ResultPrinter.failure(e)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    service_name + ' failed, ' + str(e))
            raise ErrorHandler.APIError(service_name + ' failed, ' + str(e))
