# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import re
import hinemos.api.exceptions as ErrorHandler

'''
    {ypath1:new_attr_name, ...}
'''
attr_rename_list = {'/notifyCommandInfo@timeout':'commandTimeout', '/notifyLogEscalateInfo@escalateFacilityFlg': 'esaclateFacilityFlg'}

def reverse_attr_rename_list(rename_list):
    rev_list = {}
    for k, v in rename_list.iteritems():
        rev_list[v] = re.sub('^.*[/@]', '', k)
    return rev_list

def create_notify_info_list(tree, endpoint):
    notifyInfoList = []
    elem = tree.getroot()
    try:
        for el in elem:
            if el.tag == 'notifyInfo':
                u'''
                notifyInfo を生成し、リストに追加
                '''
                notifyInfo = endpoint.create_object('notifyInfo')
                temp = str(el.attrib).split(',')
                for s in temp:
                    p = re.compile('\'.*\':')
                    m = p.search(s, 0)
                    if m:
                        attribute = s[m.start()+1:m.end()-2]
                        notifyInfo[attribute] = el.get(attribute)
                for vl in el:
                    info = endpoint.create_object(vl.tag)
                    temp = str(vl.attrib).split(',')
                    for s in temp:
                        p = re.compile('\'.*\':')
                        m = p.search(s, 0)
                        if m:
                            attribute = s[m.start()+1:m.end()-2]
                            if attribute == 'commandTimeout':
                                info['timeout'] = vl.get(attribute)
                            elif attribute == 'esaclateFacilityFlg':
                                info['escalateFacilityFlg'] = vl.get(attribute)
                            else:
                                info[attribute] = vl.get(attribute)
                    notifyInfo[vl.tag].append(info)
                notifyInfoList.append(notifyInfo)
        return notifyInfoList
    except Exception, e:
        raise ErrorHandler.FileReadError('create notifyInfoList failed, ' + str(e))

def format_notify_for_modify(info):
    # HC for Utility Excel: Prevent renotifyPeriod=""
    if '' == info.renotifyPeriod:
        info.renotifyPeriod = None

    # HC for Utility Excel: Prevent renotifyPeriod=""
    if info.notifyCommandInfo is not None:
        if info.notifyCommandInfo.setEnvironment is None or '' == info.notifyCommandInfo.setEnvironment:
            info.notifyCommandInfo.setEnvironment = True
        if info.notifyCommandInfo.timeout is None or '' == info.notifyCommandInfo.timeout:
            info.notifyCommandInfo.timeout = 15000
    return info
