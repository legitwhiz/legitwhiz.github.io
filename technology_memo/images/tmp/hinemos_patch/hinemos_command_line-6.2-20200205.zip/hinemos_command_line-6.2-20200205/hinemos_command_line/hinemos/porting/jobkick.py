# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2015-2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

'''
    must be in deep order
'''
tag_rename_list = (
    ('value', 'defaultValue'),
    ('jobRuntimeParamDetailList', 'JobRuntimeDetailInfos'))

def inverse_tag_rename_list(org_rename_list):
    tmp_dict = dict(org_rename_list)
    inverse_list = []
    for pair in org_rename_list:
        tags = pair[0].split('/')
        new_key = pair[1]
        new_val = tags[-1]

        level = len(tags)
        if level > 1:
            for i in reversed(xrange(level-1)):
                new_key = tmp_dict['/'.join(tags[:(i+1)])] + '/' +new_key
        inverse_list.append((new_key, new_val))
    return inverse_list
