# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------
from hinemos.api.exceptions import PermissoinError, APIError,\
    ObjectNotFoundError
from hinemos.util.modifier import ObjectModifier

class InfraUtil(object):

    # @see com.clustercontrol.infra.bean.InfraNodeInputConstant
    _AUTH_TYPE_ = ('NODE_PARAM', 'INFRA_PARAM', 'DIALOG')

    @staticmethod
    def convert2send_method_type(label):
        if label is None: return None

        label = label.upper()
        if label == 'SCP':
            return 0
        elif label == 'WINRM':
            return 1
        else:
            return None

    @staticmethod
    def convert2access_method_type(label):
        if label is None: return None

        label = label.upper()
        if label == 'SSH':
            return 0
        elif label == 'WINRM':
            return 1
        else:
            return None

    @staticmethod
    def convert2auth_type(label):
        return None if label is None else InfraUtil._AUTH_TYPE_.index(label)


class InfraMaker(object):

    _endpoint = None

    def __init__(self, endpoint):
        self._endpoint = endpoint

    def modify_file_transfer_module(self, management_id, module_id, name, file_id, dst, transfer_method, dest_owner, dest_permission, stop_if_fail_b, backup_if_exist_b, precheck_b,
                                    replace_var_lst, del_var_lst, valid_flg_b):
        try:
            management_info = self._endpoint.getInfraManagement(management_id)

            for module_info in management_info.moduleList:
                if module_info.moduleId == module_id and module_info.__class__.__name__ == 'fileTransferModuleInfo':
                    ObjectModifier.replace_if_not_none(module_info,\
                           name = name,\
                           precheckFlg = precheck_b,\
                           stopIfFailFlg = stop_if_fail_b,\
                           validFlg = valid_flg_b,\
                           backupIfExistFlg = backup_if_exist_b,\
                           destAttribute = dest_permission,\
                           destOwner = dest_owner,\
                           destPath = dst,\
                           fileId = file_id,\
                           sendMethodType = transfer_method)

                    # Add replacement variables
                    if replace_var_lst:
                        if 'fileTransferVariableList' not in module_info:
                            setattr(module_info, 'fileTransferVariableList', [])

                        for (k, v) in replace_var_lst:
                            # Replase or append
                            for a in module_info.fileTransferVariableList:
                                if a.name == k:
                                    a.value = v
                                    break
                            else:
                                subinfo = self._endpoint.create_file_transfer_variable_info(k, v)
                                module_info.fileTransferVariableList.append(subinfo)

                    # Delete replacement variables
                    if del_var_lst:
                        if 'fileTransferVariableList' not in module_info:
                            setattr(module_info, 'fileTransferVariableList', [])

                        new_lst = []
                        for a in module_info.fileTransferVariableList:
                            if a.name not in del_var_lst:
                                new_lst.append(a)
                            else:
                                del_var_lst.remove(a.name)
                        module_info.fileTransferVariableList = new_lst

                    self._endpoint.modifyInfraManagement(management_info)

                    # Found and break the loop
                    break
            else:
                # End of loop
                raise ObjectNotFoundError('Module "' + module_id + '" does not exist!') 
        except Exception, e:
            if 'need-role' in str(e):
                raise PermissoinError('modifyFileTransferModule failed, ' + str(e))
            raise APIError('modifyFileTransferModule failed, ' + str(e))

    def modify_command_module(self, management_id, module_id, name, access_method, precheck_b, stop_if_fail_b, check_command, exec_command, valid_flg_b):
        try:
            management_info = self._endpoint.getInfraManagement(management_id)
            for module_info in management_info.moduleList:
                if module_info.moduleId == module_id and module_info.__class__.__name__ == 'commandModuleInfo':
                    ObjectModifier.replace_if_not_none(module_info,\
                            name = name,\
                            precheckFlg = precheck_b,\
                            stopIfFailFlg = stop_if_fail_b,\
                            validFlg = valid_flg_b,\
                            accessMethodType = access_method,\
                            checkCommand = check_command,\
                           execCommand = exec_command)

                    self._endpoint.modifyInfraManagement(management_info)

                    # Found and break the loop
                    break
            else:
                # End of loop
                raise ObjectNotFoundError('Module "' + module_id + '" does not exist!') 
        except Exception, e:
            if 'need-role' in str(e):
                raise PermissoinError('modifyCommandModule failed, ' + str(e))
            raise APIError('modifyCommandModule failed, ' + str(e))
