#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api.exceptions import ObjectNotFoundError

class ObjectModifier(object):
    _info = None
    _ptr = None

    def __init__(self, info):
        self._ptr = self._info = info

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        pass

    def change_ptr(self, attrs):
        self._ptr = self._info
        for attr in attrs.split('.'):
            self._ptr = getattr(self._ptr, attr)

    def set_attr(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self._ptr, k, v)

    def set_if_first_not_none(self, key1, val1, **kwargs):
        if val1 is not None:
            setattr(self._ptr, key1, val1)
            for k, v in kwargs.iteritems():
                    setattr(self._ptr, k, v)

    def set_if_first_not_none_and_empty(self, key1, val1, **kwargs):
        if val1 is not None and val1 is not '':
            setattr(self._ptr, key1, val1)
            for k, v in kwargs.iteritems():
                    setattr(self._ptr, k, v)

    # For list object
    def select(self, **kwargs):
        for x in self._ptr:
            allmatch = True
            for k, v in kwargs.iteritems():
                if getattr(x, k) != v:
                    allmatch = False
                    break
            if allmatch:
                return x
        raise ObjectNotFoundError(', '.join(( (k+'='+str(v)) for k,v in kwargs.iteritems() )) + ' does not exist!')

    # For list object
    def remove(self, **kwargs):
        for i, x in enumerate(self._ptr):
            allmatch = True
            for k, v in kwargs.iteritems():
                if getattr(x, k) != v:
                    allmatch = False
                    break
            if allmatch:
                del self._ptr[i]
                return
        raise ObjectNotFoundError(', '.join(( (k+'='+str(v)) for k,v in kwargs.iteritems() )) + ' does not exist!')


    @staticmethod
    def set_attrs(info, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(info, k, v)

    @staticmethod
    def del_none_attrs_recursively(info):
        ''' suds bug? empty suds.sax.text.Text data in DB will become None '''
        for k,v in info.__dict__.iteritems():
            if not k.startswith('__'):
                t = type(v).__name__
                if t == 'instance':
                    ObjectModifier.modify_none2empty(v)
                elif t == 'NoneType':
                    #print 'DEBUG: Replace', k, 'value(None) with "".'
                    delattr(info, k)

    @staticmethod
    def replace_if_not_none(info, **kwargs):
        for k, v in kwargs.iteritems():
            if v is not None:
                setattr(info, k, v)

    @staticmethod
    def replace_if_not_none_and_obj_val_is_none(info, **kwargs):
        for k, v in kwargs.iteritems():
            if v is not None:
                if info.get(k, None) is None:
                    if isinstance(info, dict):
                        info[k] = v
                    else:
                        setattr(info, k, v)

    @staticmethod
    def replace_if_none(info, **kwargs):
        for k, v in kwargs.iteritems():
            if v is None:
                setattr(info, k, v)

    @staticmethod
    def replace_none_if_empty(info, *args):
        for k in args:
            if hasattr(info, k) and getattr(info, k) == '':
                setattr(info, k, None)

    @staticmethod
    def replace_blank_if_none(info, *args):
        for k in args:
            if hasattr(info, k) and getattr(info, k) is None:
                setattr(info, k, '')
