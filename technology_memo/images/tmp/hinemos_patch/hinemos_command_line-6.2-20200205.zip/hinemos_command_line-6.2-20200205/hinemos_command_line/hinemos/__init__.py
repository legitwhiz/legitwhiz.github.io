# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2018 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

# HinemosPorting.jar reads "__project__" and "__version__", please keep this format.
__project__ = 'Hinemos Command Line Tool Suite'
__version__ = '6.2'
__hinemos_version__ = '6.2'
__copyright__ = '''
Copyright (c) 2018 NTT DATA INTELLILINK Corporation. All rights reserved.
'''
