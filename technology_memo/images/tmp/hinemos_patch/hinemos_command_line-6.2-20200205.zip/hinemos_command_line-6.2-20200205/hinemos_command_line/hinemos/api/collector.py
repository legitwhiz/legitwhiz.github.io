#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler

class CollectorEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'Collector')

    def get_available_collector_item_list(self, facility_id):
        try:
            return self._client.service.getAvailableCollectorItemList(facility_id)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getAvailableCollectorItemList failed, ' + str(e))
            raise ErrorHandler.APIError('getAvailableCollectorItemList failed, ' + str(e))

    def get_item_code_map(self):
        try:
            return self._client.service.getItemCodeMap()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getItemCodeMap failed, ' + str(e))
            raise ErrorHandler.APIError('getItemCodeMap failed, ' + str(e))

    def get_performance_list(self):
        try:
            return self._client.service.getPerformanceList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getPerformanceList failed, ' + str(e))
            raise ErrorHandler.APIError('getPerformanceList failed, ' + str(e))

    def get_record_collected_data_from_id_list(self, facilityIdList, collectorItemInfo, startDate , endDate):
        try:
            return self._client.service.getRecordCollectedDataFromIdList(facilityIdList, collectorItemInfo, startDate , endDate)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getRecordCollectedDataFromIdList failed, ' + str(e))
            raise ErrorHandler.APIError('getRecordCollectedDataFromIdList failed, ' + str(e))

    def get_performance_list_by_condition(self,performanceFilterInfo):
        try:
            return self._client.service.getPerformanceListByCondition(performanceFilterInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getPerformanceListByCondition failed, ' + str(e))
            raise ErrorHandler.APIError('getPerformanceListByCondition failed, ' + str(e))

    def get_performance_graph_info(self, monitorId):
        try:
            return self._client.service.getPerformanceGraphInfo(monitorId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getPerformanceGraphInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getPerformanceGraphInfo failed, ' + str(e))

    def create_perf_file(self, monitorId, facilityId, header, archive):
        try:
            return self._client.service.createPerfFile(monitorId,facilityId,header,archive)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('downloadPerfFile failed, ' + str(e))
            raise ErrorHandler.APIError('downloadPerfFile failed, ' + str(e))

    def download_perf_file(self, fileName):
        try:
            return self._client.service.downloadPerfFile(fileName)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('downloadPerfFile failed, ' + str(e))
            raise ErrorHandler.APIError('downloadPerfFile failed, ' + str(e))

    def delete_perf_file(self, fileNameList):
        try:
            return self._client.service.deletePerfFile(fileNameList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('downloadPerfFile failed, ' + str(e))
            raise ErrorHandler.APIError('downloadPerfFile failed, ' + str(e))

    def create_performance_filter_info(self, monitor_Id, monitor_Type_Id, description, oldest_from_date, oldest_to_date, latest_from_date, latest_to_date):
        obj_name = 'performanceFilterInfo'
        try:
            info = self._client.factory.create(obj_name)
            if monitor_Id is not None and monitor_Id != '':
                info.monitorId = monitor_Id
            if monitor_Type_Id is not None and monitor_Type_Id != '':
                info.monitorTypeId = monitor_Type_Id
            if description is not None and description != '':
                info.description=description
            if oldest_from_date is not None and oldest_from_date != '':
                info.oldestFromDate=oldest_from_date
            if oldest_to_date is not None and oldest_to_date != '':
                info.oldestToDate=oldest_to_date
            if latest_to_date is not None and latest_from_date != '':
                info.latestFromDate=latest_from_date
            if latest_to_date is not None and latest_to_date != '':
                info.latestToDate=latest_to_date
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_collector_item_info(self, collector_id, item_code, display_name):
        obj_name = 'collectorItemInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.collectorId = collector_id
            info.itemCode = item_code
            info.displayName = display_name
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))
