# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2015-2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import hinemos.api.exceptions as ErrorHandler
from hinemos.util.common import DateConvert
from xml.etree.ElementTree import SubElement
import types
from suds.sax.text import Text
from hinemos.api.exceptions import PortingExportError
from hinemos.api.helper import CtTypeFormatter
from hinemos.util.job import JobUtil

'''
    must be in deep order
'''
tag_rename_list = (\
    ('srcFacilityID', 'srcFacilityId'),\
    ('facilityID', 'facilityId'),\
    ('destFacilityID', 'destFacilityId'),\
    ('end_delay', 'endDelay'),\
    ('start_delay', 'startDelay'),\
    ('start_delay_condition_type', 'startDelayConditionType'),\
    ('start_delay_notify', 'startDelayNotify'),\
    ('start_delay_notify_priority', 'startDelayNotifyPriority'),\
    ('start_delay_operation', 'startDelayOperation'),\
    ('start_delay_operation_end_status', 'startDelayOperationEndStatus'),\
    ('start_delay_operation_end_value', 'startDelayOperationEndValue'),\
    ('start_delay_operation_type', 'startDelayOperationType'),\
    ('start_delay_session', 'startDelaySession'),\
    ('start_delay_session_value', 'startDelaySessionValue'),\
    ('start_delay_time', 'startDelayTime'),\
    ('start_delay_time_value', 'startDelayTimeValue'),\
    ('end_delay', 'endDelay'),\
    ('end_delay_condition_type', 'endDelayConditionType'),\
    ('end_delay_job', 'endDelayJob'),\
    ('end_delay_job_value', 'endDelayJobValue'),\
    ('end_delay_notify', 'endDelayNotify'),\
    ('end_delay_notify_priority', 'endDelayNotifyPriority'),\
    ('end_delay_operation', 'endDelayOperation'),\
    ('end_delay_operation_end_status', 'endDelayOperationEndStatus'),\
    ('end_delay_operation_end_value', 'endDelayOperationEndValue'),\
    ('end_delay_operation_type', 'endDelayOperationType'),\
    ('end_delay_session', 'endDelaySession'),\
    ('end_delay_session_value', 'endDelaySessionValue'),\
    ('end_delay_time', 'endDelayTime'),\
    ('end_delay_time_value', 'endDelayTimeValue'),\
    ('parentId', 'parentJobId'),\
    ('user', 'effectiveUser'),\
    ('referJobUnitId', 'referJobunitId'),\
    ('condition', 'conditionType'),\
    ('endValue', 'unmatchEndValue'),\
    ('endCondition', 'unmatchEndFlg'),\
    ('endStatus', 'unmatchEndStatus'),\
    ('object', 'startJob'),\
    ('object/time', 'startTime'),\
    ('object/value', 'targetJobEndValue'),\
    ('object/jobId', 'targetJobId'),\
    ('object/type', 'targetJobType'),\
    ('object/decisionCondition', 'startDecisionCondition'),\
    ('object/decisionValue01', 'startDecisionValue01'),\
    ('object/decisionValue02', 'startDecisionValue02'),\
    ('object/description', 'targetJobDescription'),\
    ('processingMethod', 'processMode'),\
    ('param', 'param'),\
    ('param/type', 'paramType'),\
    ('jobCommandParamList', 'commandParam'))


def inverse_tag_rename_list(org_rename_list):
    tmp_dict = dict(org_rename_list)
    inverse_list = []
    for pair in org_rename_list:
        tags = pair[0].split('/')
        new_key = pair[1]
        new_val = tags[-1]

        level = len(tags)
        if level > 1:
            for i in reversed(xrange(level-1)):
                new_key = tmp_dict['/'.join(tags[:(i+1)])] + '/' +new_key
        inverse_list.append((new_key, new_val))
    return inverse_list

def format_output(info):
    CtTypeFormatter.output(info) 

    # HC4UL: date format different
    info.createTime = info.createTime.replace('/', '-')
    info.updateTime = info.updateTime.replace('/', '-')

    delattr(info, 'propertyFull')

    if 'command' in info:
        delattr(info.command, 'scope')

    if info.type != JobUtil.convert2job_type('JOB'):
        if 'command' in info:
            delattr(info, 'command')

    if info.type != JobUtil.convert2job_type('FILEJOB'):
        if 'file' in info:
            delattr(info, 'file')
    else:
        delattr(info.file, 'messageRetryEndValue')

    if info.type != JobUtil.convert2job_type('MONITORJOB'):
        if 'monitor' in info:
            delattr(info, 'monitor')
    else:
        delattr(info.monitor, 'commandRetry')
        delattr(info.monitor, 'commandRetryFlg')

    if JobUtil.convert2job_type('JOBUNIT') == info.type:
        delattr(info, 'waitRule') # HC4UL: job unit cannot have waitRule

    if info.type not in (JobUtil.convert2job_type('JOBNET'),JobUtil.convert2job_type('JOB'),JobUtil.convert2job_type('FILEJOB')):
        if 'waitRule' in info:
            delattr(info.waitRule, 'multiplicityEndValue')
            delattr(info.waitRule, 'multiplicityNotify')
            delattr(info.waitRule, 'multiplicityNotifyPriority')
            delattr(info.waitRule, 'multiplicityOperation')

    if JobUtil.convert2job_type('APPROVALJOB') != info.type:
        if 'approvalReqMailBody' in info:
            delattr(info, 'approvalReqMailBody')
        if 'approvalReqMailTitle' in info:
            delattr(info, 'approvalReqMailTitle')
        if 'approvalReqRoleId' in info:
            delattr(info, 'approvalReqRoleId')
        if 'approvalReqSentence' in info:
            delattr(info, 'approvalReqSentence')
        if 'approvalReqUserId' in info:
            delattr(info, 'approvalReqUserId')
        if 'useApprovalReqSentence' in info:
            delattr(info, 'useApprovalReqSentence')

    if info.type in  (JobUtil.convert2job_type('REFERJOB'), JobUtil.convert2job_type('REFERJOBNET')):
        # HC4UL: job unit cannot have waitRule
        if 'waitRule' in info:
            delattr(info.waitRule, 'calendar')
            delattr(info.waitRule, 'calendarEndStatus')
            delattr(info.waitRule, 'calendarEndValue')
            delattr(info.waitRule, 'skip')
            delattr(info.waitRule, 'skipEndStatus')
            delattr(info.waitRule, 'skipEndValue')
            delattr(info.waitRule, 'start_delay')
            delattr(info.waitRule, 'start_delay_condition_type')
            delattr(info.waitRule, 'start_delay_notify')
            delattr(info.waitRule, 'start_delay_notify_priority')
            delattr(info.waitRule, 'start_delay_operation')
            delattr(info.waitRule, 'start_delay_operation_end_status')
            delattr(info.waitRule, 'start_delay_operation_end_value')
            delattr(info.waitRule, 'start_delay_operation_type')
            delattr(info.waitRule, 'start_delay_session')
            delattr(info.waitRule, 'start_delay_session_value')
            delattr(info.waitRule, 'start_delay_time')
            delattr(info.waitRule, 'start_delay_time_value')

            delattr(info.waitRule, 'end_delay')
            delattr(info.waitRule, 'end_delay_condition_type')
            delattr(info.waitRule, 'end_delay_job')
            delattr(info.waitRule, 'end_delay_job_value')
            delattr(info.waitRule, 'end_delay_notify')
            delattr(info.waitRule, 'end_delay_notify_priority')
            delattr(info.waitRule, 'end_delay_operation')
            delattr(info.waitRule, 'end_delay_operation_end_status')
            delattr(info.waitRule, 'end_delay_operation_end_value')
            delattr(info.waitRule, 'end_delay_operation_type')
            delattr(info.waitRule, 'end_delay_session')
            delattr(info.waitRule, 'end_delay_session_value')
            delattr(info.waitRule, 'end_delay_time')
            if 'end_delay_time_value' in info.waitRule:
                delattr(info.waitRule, 'end_delay_time_value')
#             delattr(info.waitRule, 'multiplicityEndValue')
#             delattr(info.waitRule, 'multiplicityNotify')
#             delattr(info.waitRule, 'multiplicityNotifyPriority')
#             delattr(info.waitRule, 'multiplicityOperation')
        delattr(info, 'abnormalPriority')
        delattr(info, 'beginPriority')
        delattr(info, 'normalPriority')
        delattr(info, 'warnPriority')
    else: # If not refer
        delattr(info, 'referJobSelectType')

    # Reorganize endStatus
    if 'endStatus' in info:
        for a in info.endStatus:
            prefix = 'normal' # a.type == 0
            if 1 == a.type:
                prefix = 'warn'
            elif 2 == a.type:
                prefix = 'abnormal'
            setattr(info, prefix+'EndValue', a.value)
            setattr(info, prefix+'EndValueFrom', a.startRangeValue)
            setattr(info, prefix+'EndValueTo', a.endRangeValue)
        delattr(info, 'endStatus')

#     if info.jobunitId == info.id:
#         parent_jobunit_id = 'ROOT'
#         setattr(info, 'parentId', 'TOP')
#     else:
#         parent_jobunit_id = info.jobunitId
#     setattr(info, 'parentJobunitId', parent_jobunit_id)

    if 'file' in info:
        if 'destScope' in info.file:
            delattr(info.file, 'destScope')

    # waitRule object
    if 'waitRule' in info:
        if 'object' in info.waitRule:
            for x in info.waitRule.object:
                if 'jobName' in x:
                    delattr(x, 'jobName')
                if 3 == x.type: # HC
                    x.value = x.startMinute
                delattr(x, 'startMinute')
                if 'time' in x:
                    x.time = DateConvert.get_time48_from_epochtime(x.time)
                if not 'jobId' in x:
                    setattr(x, 'jobId', None)

        if 'start_delay_time_value' in info.waitRule:
            info.waitRule.start_delay_time_value = DateConvert.get_time48_from_epochtime(info.waitRule.start_delay_time_value)
        if 'end_delay_time_value' in info.waitRule:
            info.waitRule.end_delay_time_value = DateConvert.get_time48_from_epochtime(info.waitRule.end_delay_time_value)

def format_input(job_info):
    if job_info.createTime and '-' in job_info.createTime:
        job_info.createTime = job_info.createTime.replace('-', '/')
    if job_info.updateTime and '-' in job_info.updateTime:
        job_info.updateTime = job_info.updateTime.replace('-', '/')

    if 'waitRule' in job_info:
        if 'start_delay_time_value' in job_info.waitRule:
            job_info.waitRule.start_delay_time_value = DateConvert.get_epochtime_from_time(job_info.waitRule.start_delay_time_value)
        if 'end_delay_time_value' in job_info.waitRule:
            job_info.waitRule.end_delay_time_value = DateConvert.get_epochtime_from_time(job_info.waitRule.end_delay_time_value)
        if 'object' in job_info.waitRule:
            for x in job_info.waitRule.object:
                if str(3) == str(x.type): # HC
                    x.startMinute = x.value
                    x.value = None
                if 'time' in x and x.time is not None:
                    x.time = DateConvert.get_epochtime_from_time(x.time)

    # FIXME utililty bug
    if int(job_info.type) == JobUtil.convert2job_type('APPROVALJOB'):
        if job_info.approvalReqMailBody is None and job_info.useApprovalReqSentence is None:
            job_info.approvalReqMailBody = '   ' # FIXME

    CtTypeFormatter.input(job_info) 

def append_obj2element_flattype_root(parent, obj, tag_name):
    ''' Root of single level tag type '''

    elem = SubElement(parent, tag_name)
    for attr in dir(obj):
        if not attr.startswith('__'):
            obj_child = getattr(obj, attr)
            t2 = type(obj_child)
            if t2 is not types.BuiltinMethodType and t2 is not types.MethodType:
                append_obj2element_flattype(elem, obj_child, attr)
    return elem

def append_obj2element_flattype(parent, obj, tag_name=None):
    ''' Single level tag type '''

    if tag_name is None:
        tag_name = obj.__class__.__name__

    t = type(obj)
    if obj is None:
        elem = SubElement(parent, tag_name)
        return elem
    elif isinstance(obj, Text) or t is types.StringType:
        elem = SubElement(parent, tag_name)
        elem.text = obj
        return elem
    elif t is types.InstanceType:
        # elem = SubElement(parent, tag_name) # do not create deeper level
        for attr in dir(obj):
            if not attr.startswith('__'):
                obj_child = getattr(obj, attr)
                t2 = type(obj_child)
                if t2 is not types.BuiltinMethodType and t2 is not types.MethodType:
                    append_obj2element_flattype(parent, obj_child, attr)
    elif t is types.IntType or t is types.LongType or t is types.FloatType:
        elem = SubElement(parent, tag_name)
        elem.text = str(obj)
    elif t is types.BooleanType:
        elem = SubElement(parent, tag_name)
        elem.text = str(obj).lower()
    elif t is types.ListType:
        for x in obj:
            if type(x) is types.InstanceType:
                elemt = SubElement(parent, tag_name)
                append_obj2element_flattype(elemt, x, tag_name)
            else:
                elem = SubElement(parent, tag_name)
                append_obj2element_flattype(elem, x, tag_name)
    elif t is types.DictType:  # Customized attribute
        elem = SubElement(parent, tag_name)
        for k, v in obj.iteritems():
            append_obj2element_flattype(elem, v, k)
    else:
        raise PortingExportError('failed to fetch value from %s, "%s"' % (str(t), str(obj)))

def set_start_job(element, objectInfo):
    try:
        for n in objectInfo:
            if objectInfo[str(n[0])] is None:
                objectInfo[str(n[0])] = ''

        startJob = SubElement(element, 'startJob')
        targetJobId = SubElement(startJob, 'targetJobId')
        if hasattr(objectInfo, 'jobId'):
            targetJobId.text = str(objectInfo.jobId)
        targetJobType = SubElement(startJob, 'targetJobType')
        targetJobType.text = str(objectInfo.type)
        targetJobEndValue = SubElement(startJob, 'targetJobEndValue')
        targetJobEndValue.text = str(objectInfo.value)
        startTime = SubElement(startJob, 'startTime')
        if hasattr(objectInfo, 'time'):
            startTime.text = DateConvert.get_time48_from_epochtime(objectInfo.time)
    except Exception, e:
        raise ErrorHandler.PortingExportError('set startJob failed, ' + str(e))

def set_end_status(element, endStatus):
    try:
        for n in endStatus:
            if endStatus[str(n[0])] is None:
                endStatus[str(n[0])] = ''
        EndStatus = SubElement(element, 'endStatus')
        etype = SubElement(EndStatus, 'type')
        etype.text = str(endStatus.type)
        value = SubElement(EndStatus, 'value')
        if hasattr(endStatus, 'value'):
            value.text = str(endStatus.value)
        startRangeValue = SubElement(EndStatus, 'startRangeValue')
        startRangeValue.text = str(endStatus.startRangeValue)
        endRangeValue = SubElement(EndStatus, 'endRangeValue')
        endRangeValue.text = str(endStatus.endRangeValue)
        return element
    except Exception, e:
        raise ErrorHandler.PortingExportError('set endStauts failed, ' + str(e))

def set_notices(element, notifications):
    try:
        for n in notifications:
            if notifications[str(n[0])] is None:
                notifications[str(n[0])] = ''

        notices = SubElement(element, 'notices')
        ntype = SubElement(notices, 'type')
        ntype.text = str(notifications.type)
        priority = SubElement(notices, 'priority')
        priority.text = str(notifications.priority)
        notifyGroupId = SubElement(notices, 'notifyGroupId')
        notifyGroupId.text = str(notifications.notifyGroupId)
        return element
    except Exception, e:
        raise ErrorHandler.PortingExportError('set Notices failed, ' + str(e))

def set_notify_id(element, notifyId):
    try:
        for n in notifyId:
            if notifyId[str(n[0])] is None:
                notifyId[str(n[0])] = ''

        NotifyId = SubElement(element, 'notifyId')
        notifyGroupId = SubElement(NotifyId, 'notifyGroupId')
        notifyGroupId.text = str(notifyId.notifyGroupId)
        notifyid = SubElement(NotifyId, 'notifyId')
        notifyid.text = str(notifyId.notifyId)
        notifyType = SubElement(NotifyId, 'notifyType')
        notifyType.text = str(notifyId.notifyType)
        notifyFlg = SubElement(NotifyId, 'notifyFlg')
        notifyFlg.text = str(notifyId.notifyFlg)
    except Exception, e:
        raise ErrorHandler.PortingExportError('set notifyId failed, ' + str(e))

def set_param(element, param):
    try:
        for n in param:
            if param[str(n[0])] is None:
                param[str(n[0])] = ''

        Param = SubElement(element, 'param')
        paramid = SubElement(Param, 'paramId')
        paramid.text = str(param.paramId)
        description = SubElement(Param, 'description')
        if hasattr(param, 'description'):
            description.text = str(param.description)
        ptype = SubElement(Param, 'type')
        ptype.text = str(param.type)
        value = SubElement(Param, 'value')
        if hasattr(param, 'value'):
            value.text = str(param.value)
        return element
    except Exception, e:
        raise ErrorHandler.PortingExportError('set param failed, ' + str(e))
