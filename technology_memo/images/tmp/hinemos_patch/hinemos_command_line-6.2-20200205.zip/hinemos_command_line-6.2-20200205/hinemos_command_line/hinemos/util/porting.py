# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from xml.etree.ElementTree import SubElement
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.common import DateConvert

class PortingUtil(object):

    @staticmethod
    def setMonitor(element, monitor_info):
        u'''
        monitorをセット
        '''
        try:
            monitor = SubElement(element, 'monitor')
            monitorId = SubElement(monitor, 'monitorId')
            monitorId.text = monitor_info.monitorId
            if 'description' in monitor_info:
                description = SubElement(monitor, 'description')
                description.text = str(monitor_info.description)
            facilityId = SubElement(monitor, 'facilityId')
            facilityId.text = monitor_info.facilityId
            scope = SubElement(monitor, 'scope')
            scope.text = monitor_info.scope
            monitorType = SubElement(monitor, 'monitorType')
            monitorType.text = str(monitor_info.monitorType)
            monitorTypeId = SubElement(monitor, 'monitorTypeId')
            monitorTypeId.text = monitor_info.monitorTypeId
            runInterval = SubElement(monitor, 'runInterval')
            runInterval.text = str(monitor_info.runInterval)
            if 'calendarId' in monitor_info:
                calendarId = SubElement(monitor, 'calendarId')
                calendarId.text = str(monitor_info.calendarId)
            notifyGroupId = SubElement(monitor, 'notifyGroupId')
            notifyGroupId.text = monitor_info.notifyGroupId
            if 'notifyId' in monitor_info:
                if monitor_info.notifyId != None:
                    for notifyRelationInfo in monitor_info.notifyId:
                        notifyId = SubElement(monitor, 'notifyId')
                        notifyGroupId = SubElement(notifyId, 'notifyGroupId')
                        notifyGroupId.text = str(notifyRelationInfo.notifyGroupId)
                        notifyRelationInfonotifyId = SubElement(notifyId, 'notifyId')
                        notifyRelationInfonotifyId.text = str(notifyRelationInfo.notifyId)
                        notifyType = SubElement(notifyId, 'notifyType')
                        notifyType.text = str(notifyRelationInfo.notifyType)
                        notifyFlg = SubElement(notifyId, 'notifyFlg')
                        notifyFlg.text = str(notifyRelationInfo.notifyFlg   )
            if 'application' in monitor_info:
                application = SubElement(monitor, 'application')
                application.text = str(monitor_info.application)
            monitorFlg = SubElement(monitor, 'monitorFlg')
            monitorFlg.text = str(monitor_info.monitorFlg)
            collectorFlg = SubElement(monitor, 'collectorFlg')
            collectorFlg.text = str(monitor_info.collectorFlg)
            if 'itemName' in monitor_info:
                if monitor_info.itemName == 'None':
                    monitor_info.itemName = ''
                itemName = SubElement(monitor, 'itemName')
                itemName.text = str(monitor_info.itemName)
            if 'measure' in monitor_info:
                if monitor_info.measure == 'None':
                    monitor_info.measure = ''
                measure = SubElement(monitor, 'measure')
                measure.text = str(monitor_info.measure)
            ownerRoleId = SubElement(monitor, 'ownerRoleId')
            ownerRoleId.text = str(monitor_info.ownerRoleId)
            regDate = SubElement(monitor, 'regDate')
            regDate.text = DateConvert.get_datetime_from_epochtime(monitor_info.regDate)
            regUser = SubElement(monitor, 'regUser')
            regUser.text = str(monitor_info.regUser)
            if 'updateDate' in monitor_info:
                updateDate = SubElement(monitor, 'updateDate')
                updateDate.text = DateConvert.get_datetime_from_epochtime(monitor_info.updateDate)
            if 'updateUser' in monitor_info:
                updateUser = SubElement(monitor, 'updateUser')
                updateUser.text = str(monitor_info.updateUser)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set monitor failed, ' + str(e))

    @staticmethod
    def setNumericValue(element, monitorNumericValueInfo):
        try:
            numericValue = SubElement(element, 'numericValue')
            monitorId = SubElement(numericValue, 'monitorId')
            monitorId.text = monitorNumericValueInfo.monitorId
            SubElement(numericValue, 'monitorTypeId')
            priority = SubElement(numericValue, 'priority')
            priority.text = str(monitorNumericValueInfo.priority)
            thresholdLowerLimit = SubElement(numericValue, 'thresholdLowerLimit')
            thresholdLowerLimit.text = str(monitorNumericValueInfo.thresholdLowerLimit)
            thresholdUpperLimit = SubElement(numericValue, 'thresholdUpperLimit')
            thresholdUpperLimit.text = str(monitorNumericValueInfo.thresholdUpperLimit)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set numericValue failed, ' + str(e))

    def setStringValue(self, element, monitorStringValueInfo):
        try:
            stringValue = SubElement(element, 'stringValue')
            monitorId = SubElement(stringValue, 'monitorId')
            monitorId.text = monitorStringValueInfo.monitorId
            SubElement(stringValue, 'monitorTypeId')
            priority = SubElement(stringValue, 'priority')
            priority.text = str(monitorStringValueInfo.priority)
            if 'description' in monitorStringValueInfo:
                description = SubElement(stringValue, 'description')
                description.text = str(monitorStringValueInfo.description)
            order_idx = SubElement(stringValue, 'order_idx')
            order_idx.text = str(monitorStringValueInfo.orderNo)
            pattern = SubElement(stringValue, 'pattern')
            pattern.text = str(monitorStringValueInfo.pattern)
            processType = SubElement(stringValue, 'processType')
            processType.text = str(monitorStringValueInfo.processType)
            caseSensitivityFlg = SubElement(stringValue, 'caseSensitivityFlg')
            if monitorStringValueInfo.caseSensitivityFlg:
                caseSensitivityFlg.text = 'true'
            else:
                caseSensitivityFlg.text = 'false'
            if 'message' in monitorStringValueInfo:
                message = SubElement(stringValue, 'message')
                if monitorStringValueInfo.message != None:
                    message.text = str(monitorStringValueInfo.message)
            validFlg = SubElement(stringValue, 'validFlg')
            if monitorStringValueInfo.validFlg:
                validFlg.text = 'true'
            else:
                validFlg.text = 'false'
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set stringValue failed, ' + str(e))

    def setTruthValue(self, element, monitorTruthValueInfo):
        try:
            truthValue = SubElement(element, 'truthValue')
            monitorId = SubElement(truthValue, 'monitorId')
            monitorId.text = monitorTruthValueInfo.monitorId
            SubElement(truthValue, 'monitorTypeId')
            priority = SubElement(truthValue, 'priority')
            priority.text = str(monitorTruthValueInfo.priority)
            truVal = SubElement(truthValue, 'truthValue')
            truVal.text = str(monitorTruthValueInfo.truthValue)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set stringValue failed, ' + str(e))

    def setPingMonitor(self, element, monitor_info):
        try:
            pingInfo = SubElement(element, 'pingInfo')
            monitorId = SubElement(pingInfo, 'monitorId')
            monitorId.text = monitor_info.pingCheckInfo.monitorId
            monitorTypeId = SubElement(pingInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.pingCheckInfo.monitorTypeId
            runCount = SubElement(pingInfo, 'runCount')
            runCount.text = str(monitor_info.pingCheckInfo.runCount)
            runInterval = SubElement(pingInfo, 'runInterval')
            runInterval.text = str(monitor_info.pingCheckInfo.runInterval)
            timeout = SubElement(pingInfo, 'timeout')
            timeout.text = str(monitor_info.pingCheckInfo.timeout)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set pingMonitor failed, ' + str(e))

    def setPerfMonitor(self, element, monitor_info):
        try:
            perfInfo = SubElement(element, 'perfInfo')
            monitorId = SubElement(perfInfo, 'monitorId')
            monitorId.text = monitor_info.perfCheckInfo.monitorId
            monitorTypeId = SubElement(perfInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.perfCheckInfo.monitorTypeId
            itemCode = SubElement(perfInfo, 'itemCode')
            itemCode.text = str(monitor_info.perfCheckInfo.itemCode)
            deviceDisplayName = SubElement(perfInfo, 'deviceDisplayName')
            if monitor_info.perfCheckInfo.deviceDisplayName != None:
                deviceDisplayName.text = str(monitor_info.perfCheckInfo.deviceDisplayName)
            breakdownFlg = SubElement(perfInfo, 'breakdownFlg')
            breakdownFlg.text = str(monitor_info.perfCheckInfo.breakdownFlg)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set perfMonitor failed, ' + str(e))

    def setPortMonitor(self, element, monitor_info):
        try:
            portInfo = SubElement(element, 'portInfo')
            monitorId = SubElement(portInfo, 'monitorId')
            monitorId.text = monitor_info.portCheckInfo.monitorId
            monitorTypeId = SubElement(portInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.portCheckInfo.monitorTypeId
            serviceId = SubElement(portInfo, 'serviceId')
            serviceId.text = str(monitor_info.portCheckInfo.serviceId)
            portNo = SubElement(portInfo, 'portNo')
            portNo.text = str(monitor_info.portCheckInfo.portNo)
            runCount = SubElement(portInfo, 'runCount')
            runCount.text = str(monitor_info.portCheckInfo.runCount)
            runInterval = SubElement(portInfo, 'runInterval')
            runInterval.text = str(monitor_info.portCheckInfo.runInterval)
            timeout = SubElement(portInfo, 'timeout')
            timeout.text = str(monitor_info.portCheckInfo.timeout)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set portMonitor failed, ' + str(e))

    def setHttpMonitor(self, element, monitor_info):
        try:
            httpInfo = SubElement(element, 'httpInfo')
            monitorId = SubElement(httpInfo, 'monitorId')
            monitorId.text = monitor_info.httpCheckInfo.monitorId
            monitorTypeId = SubElement(httpInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.httpCheckInfo.monitorTypeId
            requestUrl = SubElement(httpInfo, 'requestUrl')
            requestUrl.text = str(monitor_info.httpCheckInfo.requestUrl)
            urlReplace = SubElement(httpInfo, 'urlReplace')
            urlReplace.text = str(monitor_info.httpCheckInfo.urlReplace)
            proxyPort = SubElement(httpInfo, 'proxyPort')
            proxyPort.text = str(monitor_info.httpCheckInfo.proxyPort)
            proxySet = SubElement(httpInfo, 'proxySet')
            proxySet.text = str(monitor_info.httpCheckInfo.proxySet)
            timeout = SubElement(httpInfo, 'timeout')
            timeout.text = str(monitor_info.httpCheckInfo.timeout)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set httpMonitor failed, ' + str(e))

    def setSqlMonitor(self, element, monitor_info):
        try:
            sqlInfo = SubElement(element, 'sqlInfo')
            monitorId = SubElement(sqlInfo, 'monitorId')
            monitorId.text = monitor_info.sqlCheckInfo.monitorId
            monitorTypeId = SubElement(sqlInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.sqlCheckInfo.monitorTypeId
            connectionUrl = SubElement(sqlInfo, 'connectionUrl')
            connectionUrl.text = str(monitor_info.sqlCheckInfo.connectionUrl)
            jdbcDriver = SubElement(sqlInfo, 'jdbcDriver')
            jdbcDriver.text = str(monitor_info.sqlCheckInfo.jdbcDriver)
            user = SubElement(sqlInfo, 'user')
            user.text = str(monitor_info.sqlCheckInfo.user)
            password = SubElement(sqlInfo, 'password')
            password.text = str(monitor_info.sqlCheckInfo.password)
            query = SubElement(sqlInfo, 'query')
            query.text = str(monitor_info.sqlCheckInfo.query)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set sqlMonitor failed, ' + str(e))

    def setWinServiceMonitor(self, element, monitor_info):
        try:
            winServiceInfo = SubElement(element, 'winServiceInfo')
            monitorId = SubElement(winServiceInfo, 'monitorId')
            monitorId.text = monitor_info.winServiceCheckInfo.monitorId
            monitorTypeId = SubElement(winServiceInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.winServiceCheckInfo.monitorTypeId
            serviceName = SubElement(winServiceInfo, 'serviceName')
            serviceName.text = str(monitor_info.winServiceCheckInfo.serviceName)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set winServiceMonitor failed, ' + str(e))

    def setProcessMonitor(self, element, monitor_info):
        try:
            processInfo = SubElement(element, 'processInfo')
            monitorId = SubElement(processInfo, 'monitorId')
            monitorId.text = monitor_info.processCheckInfo.monitorId
            monitorTypeId = SubElement(processInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.processCheckInfo.monitorTypeId
            command = SubElement(processInfo, 'command')
            command.text = str(monitor_info.processCheckInfo.command)
            param = SubElement(processInfo, 'param')
            if monitor_info.processCheckInfo.param != None:
                param.text = str(monitor_info.processCheckInfo.param)
            caseSensitivityFlg = SubElement(processInfo, 'caseSensitivityFlg')
            if monitor_info.processCheckInfo.caseSensitivityFlg:
                flg = 1
            else:
                flg = 0
            caseSensitivityFlg.text = str(flg)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set processMonitor failed, ' + str(e))

    def setTrapMonitor(self, element, monitor_info):
        try:
            snmpTrapInfo = SubElement(element, 'snmpTrapInfo')
            checkMode = SubElement(snmpTrapInfo, 'checkMode')
            checkMode.text = str(monitor_info.trapCheckInfo.checkMode)
            communityCheck = SubElement(snmpTrapInfo, 'communityCheck')
            communityCheck.text = str(monitor_info.trapCheckInfo.communityCheck)
            charsetConvert = SubElement(snmpTrapInfo, 'charsetConvert')
            charsetConvert.text = str(monitor_info.trapCheckInfo.charsetConvert)
            if 'communityName' in monitor_info.trapCheckInfo:
                communityName = SubElement(snmpTrapInfo, 'communityName')
                communityName.text = str(monitor_info.trapCheckInfo.communityName)
            if 'charsetName' in monitor_info.trapCheckInfo:
                charsetName = SubElement(snmpTrapInfo, 'charsetName')
                charsetName.text = str(monitor_info.trapCheckInfo.charsetName)
            if 'trapValueInfo' in monitor_info:
                for monitorTrapValueInfo in monitor_info.trapValueInfo:
                    oidInfo = SubElement(snmpTrapInfo, 'oidInfo')
                    monitorId = SubElement(oidInfo, 'monitorId')
                    monitorId.text = str(monitorTrapValueInfo.monitorId)
                    mib = SubElement(oidInfo, 'mib')
                    mib.text = str(monitorTrapValueInfo.mib)
                    trapName = SubElement(oidInfo, 'trapName')
                    trapName.text = str(monitorTrapValueInfo.uei)
                    trapOid = SubElement(oidInfo, 'trapOid')
                    trapOid.text = str(monitorTrapValueInfo.trapOid)
                    genericId = SubElement(oidInfo, 'genericId')
                    genericId.text = str(monitorTrapValueInfo.genericId)
                    specificId = SubElement(oidInfo, 'specificId')
                    specificId.text = str(monitorTrapValueInfo.specificId)
                    priority = SubElement(oidInfo, 'priority')
                    priority.text = str(monitorTrapValueInfo.priority)
                    validFlg = SubElement(oidInfo, 'validFlg')
                    if monitorTrapValueInfo.validFlg:
                        validFlg.text = '1'
                    else:
                        validFlg.text = '0'
                    logmsg = SubElement(oidInfo, 'logmsg')
                    logmsg.text = str(monitorTrapValueInfo.logmsg)
                    descr = SubElement(oidInfo, 'descr')
                    descr.text = str(monitorTrapValueInfo.descr)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set trapMonitor failed, ' + str(e))

    def setSystemlogMonitor(self, element, monitor_info):
        try:
            syslogInfo = SubElement(element, 'syslogInfo')
            monitorId = SubElement(syslogInfo, 'monitorId')
            monitorId.text = monitor_info.monitorId
            monitorTypeId = SubElement(syslogInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.monitorTypeId
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set systemlogMonitor failed, ' + str(e))

    def setWinEventMonitor(self, element, monitor_info):
        try:
            winEventInfo = SubElement(element, 'winEventInfo')
            monitorId = SubElement(winEventInfo, 'monitorId')
            monitorId.text = monitor_info.monitorId
            monitorTypeId = SubElement(winEventInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.monitorTypeId
            levelCritical = SubElement(winEventInfo, 'levelCritical')
            if monitor_info.winEventCheckInfo.levelCritical:
                levelCritical.text = 'true'
            else:
                levelCritical.text = 'false'
            levelWarning = SubElement(winEventInfo, 'levelWarning')
            if monitor_info.winEventCheckInfo.levelWarning:
                levelWarning.text = 'true'
            else:
                levelWarning.text = 'false'
            levelVerbose = SubElement(winEventInfo, 'levelVerbose')
            if monitor_info.winEventCheckInfo.levelVerbose:
                levelVerbose.text = 'true'
            else:
                levelVerbose.text = 'false'
            levelError = SubElement(winEventInfo, 'levelError')
            if monitor_info.winEventCheckInfo.levelError:
                levelError.text = 'true'
            else:
                levelError.text = 'false'
            levelInformational = SubElement(winEventInfo, 'levelInformational')
            if monitor_info.winEventCheckInfo.levelInformational:
                levelInformational.text = 'true'
            else:
                levelInformational.text = 'false'
            if 'logName' in monitor_info.winEventCheckInfo:
                for logName in monitor_info.winEventCheckInfo.logName:
                    logFolder= SubElement(winEventInfo, 'log')
                    log = SubElement(logFolder, 'log')
                    log.text = str(logName)
            if 'source' in monitor_info.winEventCheckInfo:
                for source in monitor_info.winEventCheckInfo.source:
                    source = SubElement(winEventInfo, 'source')
                    source.text = str(source)
            if 'eventId' in monitor_info.winEventCheckInfo:
                for eventId in monitor_info.winEventCheckInfo.eventId:
                    eventId = SubElement(winEventInfo, 'eventId')
                    eventId.text = str(eventId)
            if 'keywords' in monitor_info.winEventCheckInfo:
                for keywords in monitor_info.winEventCheckInfo.keywords:
                    keyword = SubElement(winEventInfo, 'keyword')
                    keyword.text = str(keywords)
            if 'category' in monitor_info.winEventCheckInfo:
                for category in monitor_info.winEventCheckInfo.category:
                    category = SubElement(winEventInfo, 'category')
                    category.text = str(category)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set winEventMonitor failed, ' + str(e))

    def setlogFileMonitor(self, element, monitor_info):
        try:
            logfileInfo = SubElement(element, 'logfileInfo')
            monitorId = SubElement(logfileInfo, 'monitorId')
            monitorId.text = monitor_info.monitorId
            monitorTypeId = SubElement(logfileInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.monitorTypeId
            directory = SubElement(logfileInfo, 'directory')
            directory.text = str(monitor_info.logfileCheckInfo.directory)
            fileName = SubElement(logfileInfo, 'fileName')
            fileName.text = str(monitor_info.logfileCheckInfo.fileName)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set logFileMonitor failed, ' + str(e))

    def setAgentMonitor(self, element, monitor_info):
        try:
            agentInfo = SubElement(element, 'agentInfo')
            monitorId = SubElement(agentInfo, 'monitorId')
            monitorId.text = monitor_info.monitorId
            monitorTypeId = SubElement(agentInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.monitorTypeId
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set agentMonitor failed, ' + str(e))

    def setSnmpMonitor(self, element, monitor_info):
        try:
            snmpInfo = SubElement(element, 'snmpInfo')
            monitorId = SubElement(snmpInfo, 'monitorId')
            monitorId.text = monitor_info.monitorId
            monitorTypeId = SubElement(snmpInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.monitorTypeId
            convertFlg = SubElement(snmpInfo, 'convertFlg')
            convertFlg.text = str(monitor_info.snmpCheckInfo.convertFlg)
            snmpOid = SubElement(snmpInfo, 'snmpOid')
            snmpOid.text = str(monitor_info.snmpCheckInfo.snmpOid)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set snmpMonitor failed, ' + str(e))

    def setCustomMonitor(self, element, monitor_info):
        try:
            customInfo = SubElement(element, 'customInfo')
            monitorId = SubElement(customInfo, 'monitorId')
            monitorId.text = monitor_info.monitorId
            monitorTypeId = SubElement(customInfo, 'monitorTypeId')
            monitorTypeId.text = monitor_info.monitorTypeId
            executeType = SubElement(customInfo, 'executeType')
            if monitor_info.customCheckInfo.commandExecType == 'SELECTED':
                executeType.text = '1'
            else:
                executeType.text = '0'
            if 'selectedFacilityId' in monitor_info.customCheckInfo:
                selectedFacilityId = SubElement(customInfo, 'selectedFacilityId')
                selectedFacilityId.text = str(monitor_info.customCheckInfo.selectedFacilityId)
            specifyUser = SubElement(customInfo, 'specifyUser')
            specifyUser.text = str(monitor_info.customCheckInfo.specifyUser)
            effectiveUser = SubElement(customInfo, 'effectiveUser')
            if monitor_info.customCheckInfo.effectiveUser != None:
                effectiveUser.text = str(monitor_info.customCheckInfo.effectiveUser)
            command = SubElement(customInfo, 'command')
            command.text = str(monitor_info.customCheckInfo.command  )
            timeout = SubElement(customInfo, 'timeout')
            timeout.text = str(monitor_info.customCheckInfo.timeout)
            return element
        except Exception, e:
            raise ErrorHandler.PortingExportError('set customMonitor failed, ' + str(e))
