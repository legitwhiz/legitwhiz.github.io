# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import copy

def delete_string_value_info(stringValueInfo, pattern_OrderNo):
    for i in range(0,len(stringValueInfo)):
        if stringValueInfo[i].orderNo  == int(pattern_OrderNo):
            del stringValueInfo[i]
            for i in range(i,len(stringValueInfo)):
                stringValueInfo[i].orderNo = stringValueInfo[i].orderNo - 1
            break
    return stringValueInfo

def mod_string_value_info(patternChangeFlg, monitorInfo, endpoint, pattern_OrderNo, pattern_Description, pattern_Pattern, pattern_ProcessType, pattern_CaseSensitivityFlg, pattern_Priority, pattern_Message, pattern_ValidFlg, pattern_NewOrderNo):
    ###  pattern add or mod  ###
    if patternChangeFlg == 'ADD':
        ### add stringValueInfo create  ###
        stringValueInfo = endpoint.create_object('stringValueInfo')
    else:
        ###  modify stringValueInfo create  ###
        for i in range(0,len(monitorInfo.stringValueInfo)):
            if monitorInfo.stringValueInfo[i].orderNo  == int(pattern_OrderNo):
                stringValueInfo = copy.deepcopy(monitorInfo.stringValueInfo[i])
                no = i
                break

    ###  New Value Insert  ###
    if pattern_Description != '':
        stringValueInfo.description = pattern_Description
    if pattern_Pattern != '':
        stringValueInfo.pattern = pattern_Pattern
    if pattern_ProcessType != '':
        stringValueInfo.processType = pattern_ProcessType
    if pattern_CaseSensitivityFlg != '':
        stringValueInfo.caseSensitivityFlg = pattern_CaseSensitivityFlg
    if pattern_Priority != '':
        stringValueInfo.priority = pattern_Priority
    if pattern_Message != '':
        stringValueInfo.message = pattern_Message
    if pattern_ValidFlg != '':
        stringValueInfo.validFlg = pattern_ValidFlg
    if pattern_NewOrderNo != '':
        stringValueInfo.orderNo =pattern_NewOrderNo

    ###  New stringValueInfo append  ###
    flag = False
    if patternChangeFlg == 'ADD':
        ###  pattern add  ###
        if hasattr(monitorInfo,'stringValueInfo'):
            monitorInfo.stringValueInfo.append(stringValueInfo)
        else:
            monitorInfo.stringValueInfo = stringValueInfo
            flag = True

    else:
        ###  pattern modfiy  ###
        if pattern_NewOrderNo == '':
            monitorInfo.stringValueInfo[no] = stringValueInfo
        else:
            ###  OrderNo  modfiy ###
            newNo = int(pattern_NewOrderNo) - 1
            del monitorInfo.stringValueInfo[no]
            monitorInfo.stringValueInfo.insert(newNo, stringValueInfo)
    if flag:
        monitorInfo.stringValueInfo.orderNo = 1
    else:
        for i in range(0,len(monitorInfo.stringValueInfo)):
            monitorInfo.stringValueInfo[i].orderNo = i + 1

    return monitorInfo
