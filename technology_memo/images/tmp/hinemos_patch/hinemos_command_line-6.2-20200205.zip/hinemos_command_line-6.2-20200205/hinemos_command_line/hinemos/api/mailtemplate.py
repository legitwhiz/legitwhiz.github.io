#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler

class MailTemplateEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'MailTemplate')

    # メールテンプレート情報をマネージャに登録します
    def addMailTemplate(self, mailTemplateInfo):
        try:
            return self._client.service.addMailTemplate(mailTemplateInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addMailTemplate failed, ' + str(e))
            raise ErrorHandler.APIError('addMailTemplate failed, ' + str(e))

    # マネージャ上のメールテンプレート情報を変更します
    def modifyMailTemplate(self, mailTemplateInfo):
        try:
            return self._client.service.modifyMailTemplate(mailTemplateInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyMailTemplate failed, ' + str(e))
            raise ErrorHandler.APIError('modifyMailTemplate failed, ' + str(e))

    # メールテンプレート情報をマネージャから削除します
    def deleteMailTemplate(self, mailTemplateId):
        try:
            return self._client.service.deleteMailTemplate(mailTemplateId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteMailTemplate failed, ' + str(e))
            raise ErrorHandler.APIError('deleteMailTemplate failed, ' + str(e))

    # 引数で指定されたメールテンプレート情報を返します
    def getMailTemplateInfo(self, mailTemplateId):
        try:
            return self._client.service.getMailTemplateInfo(mailTemplateId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getMailTemplateInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getMailTemplateInfo failed, ' + str(e))

    # メールテンプレート情報一覧を取得します
    def getMailTemplateList(self):
        try:
            return self._client.service.getMailTemplateList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getMailTemplateList failed, ' + str(e))
            raise ErrorHandler.APIError('getMailTemplateList failed, ' + str(e))

    # オーナーロールIDを条件としてメールテンプレート情報一覧を取得します
    def getMailTemplateListByOwnerRole(self, ownerRoleId):
        try:
            return self._client.service.getMailTemplateListByOwnerRole(ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getMailTemplateListByOwnerRole failed, ' + str(e))
            raise ErrorHandler.APIError('getMailTemplateListByOwnerRole failed, ' + str(e))
