#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler

class ManagerCliEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'ManagerCli')

    def invoke(self, class_name, method_name, args):
        """ManagerCli invoke"""
        try:
            return self._client.service.invoke(class_name, method_name, args)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('invoke failed, ' + str(e))
            else:
                raise ErrorHandler.APIError('invoke is failed, ' + str(e))


