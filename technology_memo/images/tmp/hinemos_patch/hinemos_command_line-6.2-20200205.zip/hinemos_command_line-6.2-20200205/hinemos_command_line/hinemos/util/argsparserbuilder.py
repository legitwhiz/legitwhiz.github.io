from opt import MyOptionParser
from collections import OrderedDict
from hinemos.util.common import SettingUtil


class ArgsParserBuilder(object):

    def __init__(self):
        self.psr = MyOptionParser(conflict_handler='resolve')

    def get_parser(self):
        return self.psr

    def merge_dicts(self, a, b):
        for key in b:
            a[key] = b[key]
        return a

    def reset_default_help(self):
        self.help_default_info = {}
        self.update_help_default_info({})

    def update_help_default_info(self, new_help):
        self.help_default_info = self.merge_dicts(self.help_default_info,
                                                  new_help)
        return self

    def get_args(self):
        return []

    def build(self, exclude=[], help_default_info={}, action_type='ADD'):
        self.change_action_type(action_type)
        self.update_help_default_info(help_default_info)

        arg_defs = self.filter_out_excluded(exclude)
        for flags, params in arg_defs.values():
            self.psr.add_option(*flags, **params)
        return self.psr

    def filter_out_excluded(self, exclude):
        return OrderedDict(
            filter(lambda x: x[0] not in exclude, self.get_args())
        )

    def change_action_type(self, type):
        self.action_type = type.upper()
        if self.action_type in 'ADD':
            self.reset_default_help()
            self.monitor_default = 'true'
        elif self.action_type in 'MODIFY':
            self.default = (None, 'NOTBLANK')
            self.monitor_default = None
            self.reset_default_help()
            for k in self.help_default_info:
                self.help_default_info[k] = 'current value'
        else:
            raise Exception(self.action_type + ' is invalid action type')


class MonitorSettingArgsParserBuilder(ArgsParserBuilder):

    def __init__(self):
        super(MonitorSettingArgsParserBuilder, self).__init__()
        self.action_type = "ADD"
        self.default = (None, 'REQUIRED', 'NOTBLANK')

    def reset_default_help(self):
        super(MonitorSettingArgsParserBuilder, self).reset_default_help()
        self.update_help_default_info({
            'runInterval': '5[min]',
            'ownerRoleID': 'ALL_USERS',
            'monitor': 'true',
            'collect': 'false'
        })

    def get_args(self):
        return super(MonitorSettingArgsParserBuilder, self).get_args() + \
            [
                ('monitorID', (
                    ['-I', '--monitorID'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'ID',
                        'dest': 'monitor_id',
                        'default': (None, 'REQUIRED', 'NOTBLANK'),
                        'help': 'monitorID'
                    })
                 ),
                ('description', (
                    ['-D', '--description'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'description',
                        'default': None,
                        'help': 'description'
                    }
                )
                ),
                ('facilityID', (
                    ['-F', '--facilityID'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'ID',
                        'dest': 'facility_id',
                        'default': self.default,
                        'help': 'facilityID'
                    }
                )
                ),
                ('application', (
                    ['-A', '--application'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'application',
                        'default': self.default,
                        'help': 'application'
                    }
                )
                ),
                ('ownerRoleID', (
                    ['-R', '--ownerRoleID'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'ID',
                        'dest': 'owner_role_id',
                        'default': None,
                        'help': 'ownerRoleID (default: %s)'
                        % self.help_default_info['ownerRoleID']
                    }
                )
                ),
                ('runInterval', (
                    ['-n', '--runInterval'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'run_interval_raw',
                        'converter': SettingUtil.convert2sec,
                        'default': (None, {
                            'INLIST': ['30s', '1', '5', '10', '30', '60']
                        }),
                        'help': 'run interval = 30s [sec]'
                        ' or 1 or 5 or 10 or 30 or 60 [min]'
                        '(default: %s)'
                        % self.help_default_info['runInterval']
                    }
                )
                ),
                ('calendarID', (
                    ['-C', '--calendarID'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'ID',
                        'dest': 'calendar_id',
                        'default': None,
                        'help': 'calendarID'
                    }
                )
                ),
                ('monitor', (
                    ['-m', '--monitor'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'BOOL',
                        'dest': 'monitor_raw',
                        'converter': SettingUtil.convert2nbool,
                        'default': (self.monitor_default,
                                    {'INLIST': ['true', 'false']}),
                        'help': 'enable=true, disable=false (default: %s)'
                        % self.help_default_info['monitor']
                    }
                )),
                ('notifyIDs', (
                    ['-N', '--notifyIDs'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'notify_ids',
                        'default': None,
                        'help': 'notifyIDs = notifyID1,notifyID2,...,notifyIDN'
                    }
                )),
                ('addNotifyIDs', (
                    ['-a', '--addNotifyIDs'],
                    {
                        'action': 'store_split',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'add_notify_ids',
                        'default': None,
                        'help': 'add notifications. addNotifyIDs ='
                        'notifyID1,notifyID2,...,notifyIDN'
                    }
                )),
                ('deleteNotifyIDs', (
                    ['-d', '--deleteNotifyIDs'],
                    {
                        'action': 'store_split',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'del_notify_ids',
                        'default': None,
                        'help': 'delete notifications. deleteNotifyIDs ='
                        'notifyID1,notifyID2,...,notifyIDN'
                    }
                )),
                ('collect', (
                    ['-c', '--collect'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'BOOL',
                        'dest': 'collect_raw',
                        'converter': SettingUtil.convert2nbool,
                        'default': (None, {'INLIST': ['true', 'false']}),
                        'help': 'collect=true, not collect=false (default: %s)'
                        % self.help_default_info['collect']
                    }
                ))
        ]

    def build_monitor_setting_add_args_parser(self,
                                              help_default_info={},
                                              exclude=[]):
        exclude += ['deleteNotifyIDs', 'addNotifyIDs']
        self.build(exclude=exclude,
                   help_default_info=help_default_info,
                   action_type='ADD')
        return self.psr

    def build_monitor_setting_modify_args_parser(self,
                                                 help_default_info={},
                                                 exclude=[]):
        exclude += ['notifyIDs', 'ownerRoleID']
        self.build(exclude=exclude,
                   help_default_info=help_default_info,
                   action_type='MODIFY')
        return self.psr


class NumericMonitorSettingArgsParserBuilder(MonitorSettingArgsParserBuilder):

    def reset_default_help(self):
        super(NumericMonitorSettingArgsParserBuilder, self)\
            .reset_default_help()

        self.update_help_default_info({
            'infoLowerThreshold': '0',
            'infoUpperThreshold': '0',
            'warnLowerThreshold': '0',
            'warnUpperThreshold': '0',
            'predictionFlg': 'false',
            'predictionAnalysisRange': '60',
            'predictionTarget': '60',
            'predictionMethod': 'POLYNOMIAL_1',
            'changeFlg': 'false',
            'changeAnalysisRange': '60',
            'changeInfoLowerThreshold': '-1',
            'changeInfoUpperThreshold': '1',
            'changeWarnLowerThreshold': '-2',
            'changeWarnUpperThreshold': '2',
        })

    def get_args(self):
        return super(NumericMonitorSettingArgsParserBuilder, self).get_args() + \
            [
                ('infoLowerThreshold', (
                    ['-L', '--infoLowerThreshold'],
                    {
                        'action': 'store',
                        'type': 'float',
                        'metavar': 'NUMERIC',
                        'dest': 'info_lower_threshold',
                        'default': None,
                        'help': 'lower threshold of INFO (default: %s)'
                        % self.help_default_info['infoLowerThreshold']
                    }
                )),
                ('infoUpperThreshold', (
                    ['-P', '--infoUpperThreshold'],
                    {
                        'action': 'store',
                        'type': 'float',
                        'metavar': 'NUMERIC',
                        'dest': 'info_upper_threshold',
                        'default': None,
                        'help': 'upper threshold of INFO (default: %s)'
                        % self.help_default_info['infoUpperThreshold']
                    }
                )),
                ('warnLowerThreshold', (
                    ['-l', '--warnLowerThreshold'],
                    {
                        'action': 'store',
                        'type': 'float',
                        'metavar': 'NUMERIC',
                        'dest': 'warn_lower_threshold',
                        'default': None,
                        'help': 'lower threshold of WARN (default: %s)'
                        % self.help_default_info['warnLowerThreshold']
                    }
                )),
                ('warnUpperThreshold', (
                    ['-p', '--warnUpperThreshold'],
                    {
                        'action': 'store',
                        'type': 'float',
                        'metavar': 'NUMERIC',
                        'dest': 'warn_upper_threshold',
                        'default': None,
                        'help': 'upper threshold of WARN (default: %s)'
                        % self.help_default_info['warnUpperThreshold']
                    }
                )),
                ('predictionFlg', (
                    ['--predictionFlg'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'BOOL',
                        'dest': 'prediction_flg',
                        'converter': SettingUtil.convert2nbool,
                        'default': (None, {'INLIST': ['true', 'false']}),
                        'help': 'set predictionFlg=true to enable prediction'
                        ' (default: %s)'
                        % self.help_default_info['predictionFlg']
                    }
                )),
                ('predictionMethod', (
                    ['--predictionMethod'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'prediction_method',
                        'default': (
                            None,
                            {
                                'INLIST': [
                                    'POLYNOMIAL_1',
                                    'POLYNOMIAL_2',
                                    'POLYNOMIAL_3'
                                ]
                            }),
                        'help': 'POLYNOMIAL_1: Linear Regression,'
                        ' POLYNOMIAL_2: Quadratic Regression,'
                        ' POLYNOMIAL_3: Cubic Regression'
                        ' (default: %s)'
                        % self.help_default_info['predictionMethod']
                    }
                )),
                ('predictionAnalysisRange', (
                    ['--predictionAnalysisRange'],
                    {
                        'action': 'store',
                        'type': 'int',
                        'metavar': 'INT',
                        'dest': 'prediction_analysis_range',
                        'default': None,
                        'help': 'collection period[min] (default: %s)'
                        % self.help_default_info['predictionAnalysisRange']
                    }
                )),
                ('predictionTarget', (
                    ['--predictionTarget'],
                    {
                        'action': 'store',
                        'type': 'int',
                        'metavar': 'INT',
                        'dest': 'prediction_target',
                        'default': None,
                        'help': 'prediction time interval [min] (default: %s)'
                        % self.help_default_info['predictionTarget']
                    }
                )),
                ('predictionApplication', (
                    ['--predictionApplication'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'prediction_application',
                        'default': (None, {'WHEN': {'prediction_flg': 'true'},
                                           'DO': ('REQUIRED', 'NOTBLANK')}),
                        'help': 'prediction application, RQUIRED if predicton'
                        ' flag set to true'
                    }
                )),
                ('predictionNotifyIDs', (
                    ['--predictionNotifyIDs'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'prediction_notify_ids',
                        'default': None,
                        'help': 'prediction notifyIDs ='
                        'notifyID1,notifyID2,...,notifyIDN'
                    }
                )),
                ('addPredictionNotifyIDs', (
                    ['--addPredictionNotifyIDs'],
                    {
                        'action': 'store_split',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'add_prediction_notify_ids',
                        'default': None,
                        'help': 'add prediction notifications.'
                        'addPredictionNotifyIDs ='
                        'notifyID1,notifyID2,...,notifyIDN'
                    }
                )),
                ('deletePredictionNotifyIDs', (
                    ['--deletePredictionNotifyIDs'],
                    {
                        'action': 'store_split',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'del_prediction_notify_ids',
                        'default': None,
                        'help': 'delete prediction notifications.'
                        'deletePredictionNotifyIDs ='
                        'notifyID1,notifyID2,...,notifyIDN'
                    }
                )),
                ('changeFlg', (
                    ['--changeFlg'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'BOOL',
                        'dest': 'change_flg',
                        'converter': SettingUtil.convert2nbool,
                        'default': (None, {'INLIST': ['true', 'false']}),
                        'help': 'set changeFlg=true to enable change '
                        'monitoring (default: %s)'
                        % self.help_default_info['changeFlg']
                    }
                )),
                ('changeAnalysisRange', (
                    ['--changeAnalysisRange'],
                    {
                        'action': 'store',
                        'type': 'int',
                        'metavar': 'INT',
                        'dest': 'change_analysis_range',
                        'default': None,
                        'help': 'collection period [min](default: %s)'
                        % self.help_default_info['changeAnalysisRange']
                    }
                )),
                ('changeInfoLowerThreshold', (
                    ['--changeInfoLowerThreshold'],
                    {
                        'action': 'store',
                        'type': 'float',
                        'metavar': 'NUMERIC',
                        'dest': 'change_info_lower_threshold',
                        'default': None,
                        'help': 'change lower threshold of INFO (default: %s)'
                        % self.help_default_info['changeInfoLowerThreshold']
                    }
                )),
                ('changeInfoUpperThreshold', (
                    ['--changeInfoUpperThreshold'],
                    {
                        'action': 'store',
                        'type': 'float',
                        'metavar': 'NUMERIC',
                        'dest': 'change_info_upper_threshold',
                        'default': None,
                        'help': 'change upper threshold of INFO (default: %s)'
                        % self.help_default_info['changeInfoUpperThreshold']
                    }
                )),
                ('changeWarnLowerThreshold', (
                    ['--changeWarnLowerThreshold'],
                    {
                        'action': 'store',
                        'type': 'float',
                        'metavar': 'NUMERIC',
                        'dest': 'change_warn_lower_threshold',
                        'default': None,
                        'help': 'change lower threshold of WARN (default: %s)'
                        % self.help_default_info['changeWarnLowerThreshold']
                    }
                )),
                ('changeWarnUpperThreshold', (
                    ['--changeWarnUpperThreshold'],
                    {
                        'action': 'store',
                        'type': 'float',
                        'metavar': 'NUMERIC',
                        'dest': 'change_warn_upper_threshold',
                        'default': None,
                        'help': 'change upper threshold of WARN (default: %s)'
                        % self.help_default_info['changeWarnUpperThreshold']
                    }
                )),
                ('changeApplication', (
                    ['--changeApplication', ],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'change_application',
                        'default': (None, {'WHEN': {'change_flg': 'true'},
                                           'DO': ('REQUIRED', 'NOTBLANK')}),
                        'help': 'prediction application, RQUIRED if change'
                        ' flag set to true'
                    }
                )),
                ('changeNotifyIDs', (
                    ['--changeNotifyIDs', ],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'change_notify_ids',
                        'default': None,
                        'help': 'change notifyIDs ='
                        'notifyID1,notifyID2,...,notifyIDN'
                    }
                )),
                ('addChangeNotifyIDs', (
                    ['--addChangeNotifyIDs'],
                    {
                        'action': 'store_split',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'add_change_notify_ids',
                        'default': None,
                        'help': 'add change notifications.'
                        'addChangeNotifyIDs = notifyID1,notifyID2,..,notifyIDN'
                    }
                )),
                ('deleteChangeNotifyIDs', (
                    ['--deleteChangeNotifyIDs'],
                    {
                        'action': 'store_split',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'del_change_notify_ids',
                        'default': None,
                        'help': 'delete change notifications.'
                        'deleteChangeNotifyIDs ='
                        'notifyID1,notifyID2,...,notifyIDN'
                    }
                )),
                ('itemName', (
                    ['-i', '--itemName'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'item_name',
                        'default': (None, 'NOTBLANK'),
                        'help': 'collector item name'
                    }
                )),
                ('unit', (
                    ['-u', '--unit'],
                    {
                        'action': 'store',
                        'type': 'string',
                        'metavar': 'STRING',
                        'dest': 'unit',
                        'default': (None, 'NOTBLANK'),
                        'help': 'collector unit'
                    }
                ))
        ]

    def build_numeric_monitor_setting_add_args_parser(self,
                                                      help_default_info={},
                                                      exclude=[]):
        exclude += ['deleteNotifyIDs', 'addNotifyIDs',
                    'deletePredictionNotifyIDs', 'addPredictionNotifyIDs',
                    'deleteChangeNotifyIDs', 'addChangeNotifyIDs']
        self.build(exclude=exclude,
                   help_default_info=help_default_info,
                   action_type='ADD')
        return self.psr

    def build_numeric_monitor_setting_modify_args_parser(self,
                                                         help_default_info={},
                                                         exclude=[]):
        exclude += ['notifyIDs', 'predictionNotifyIDs', 'changeNotifyIDs']
        self.build(exclude=exclude,
                   help_default_info=help_default_info,
                   action_type='MODIFY')
        return self.psr
