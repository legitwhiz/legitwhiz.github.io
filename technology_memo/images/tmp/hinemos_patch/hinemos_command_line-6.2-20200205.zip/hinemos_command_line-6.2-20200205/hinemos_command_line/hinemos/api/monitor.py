#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler

class MonitorEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'Monitor')

    # 引数で指定された条件に一致するイベント一覧情報を取得します。(クライアントview用)
    def getEventList(self, facilityId, eventFilterInfo, messages):
        try:
            return self._client.service.getEventList(facilityId,eventFilterInfo,messages)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getEventList failed, ' + str(e))
            raise ErrorHandler.APIError('getEventList failed, ' + str(e))

    # 引数で指定されたファシリティの配下全てのファシリティのスコープ情報一覧を返します。
    def getScopeList(self, facilityId, statusFlag, eventFlag, orderFlag):
        try:
            return self._client.service.getScopeList(facilityId, statusFlag, eventFlag, orderFlag)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getScopeList failed, ' + str(e))
            raise ErrorHandler.APIError('getScopeList failed, ' + str(e))

    # 引数で指定された条件に一致するステータス情報一覧を取得します。
    def getStatusList(self, facilityId, statusFilterInfo):
        try:
            return self._client.service.getStatusList(facilityId,statusFilterInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getStatusList failed, ' + str(e))
            raise ErrorHandler.APIError('getStatusList failed, ' + str(e))

    # 引数で指定されたステータス情報を削除します。
    def deleteStatus(self, status_data_info):
        try:
            return self._client.service.deleteStatus(status_data_info)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteStatus failed, ' + str(e))
            raise ErrorHandler.APIError('deleteStatus failed, ' + str(e))

    # 引数で指定された条件に一致する帳票出力用イベント情報一覧を返します。
    def downloadEventFile(self, facilityId, eventFilterInfo, filename, language):
        try:
            return self._client.service.downloadEventFile(facilityId,eventFilterInfo,filename,language)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('downloadEventFile failed, ' + str(e))
            raise ErrorHandler.APIError('downloadEventFile failed, ' + str(e))


    def deleteEventFile(self, filename):
        try:
            return self._client.service.deleteEventFile(filename)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteEventFile failed, ' + str(e))
            raise ErrorHandler.APIError('deleteEventFile failed, ' +str(e))

    # イベント詳細情報を取得します。
    def getEventInfo(self, monitorId, monitorDetailId, pluginId, facilityId, outputDate):
        if monitorDetailId is None:
            monitorDetailId = ''

        try:
            return self._client.service.getEventInfo(monitorId, monitorDetailId, pluginId, facilityId, outputDate)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getEventInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getEventInfo failed, ' + str(e))

    # 引数で指定されたイベント情報のコメントを更新します。
    def modifyComment(self, monitorId, monitorDetailId, pluginId, facilityId, outputDate, comment, commentDate, commentUser):
        # Format
        if monitorId is None:
            monitorId = ''
        if monitorDetailId is None:
            monitorDetailId = ''
        if pluginId is None:
            pluginId = ''
        if facilityId is None:
            facilityId = ''
        if outputDate is None:
            outputDate = ''
        if comment is None:
            comment = ''

        try:
            return self._client.service.modifyComment(monitorId, monitorDetailId, pluginId, facilityId, outputDate, comment, commentDate, commentUser)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyComment failed, ' + str(e))
            raise ErrorHandler.APIError('modifyComment failed, ' + str(e))

    # 引数で指定されたイベント情報一覧の確認を更新します。
    def modifyConfirm(self, eventDataInfo, confirmType):
        try:
            return self._client.service.modifyConfirm(eventDataInfo, confirmType)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyConfirm failed, ' + str(e))
            raise ErrorHandler.APIError('modifyConfirm failed, ' + str(e))

    # 引数で指定された条件に一致するイベント情報の確認を一括更新します。
    def modifyBatchConfirm(self, confirmType, facilityId, eventBatchConfirmInfo):
        try:
            return self._client.service.modifyBatchConfirm(confirmType, facilityId,eventBatchConfirmInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyBatchConfirm failed, ' + str(e))
            raise ErrorHandler.APIError('modifyBatchConfirm failed, ' + str(e))

    # 引数で指定されたイベント情報一覧の性能グラフ用フラグを更新します。
    def modifyCollectGraphFlg(self, eventDataInfo, collectGraphFlg):
        try:
            return self._client.service.modifyCollectGraphFlg(eventDataInfo, collectGraphFlg)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyCollectGraphFlg failed, ' + str(e))
            raise ErrorHandler.APIError('modifyCollectGraphFlg failed, ' + str(e))

    # 引数で指定されたイベント情報のコメント、確認、性能グラフ用フラグ、ユーザ拡張イベント項目を更新します。
    def modifyEventInfo(self, event_data_info):
        try:
            return self._client.service.modifyEventInfo(event_data_info)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyEventInfo failed, ' + str(e))
            raise ErrorHandler.APIError('modifyEventInfo is failed, ' + str(e))

    # イベントの画面表示設定を取得します。
    def getEventDisplaySettingInfo(self):
        try:
            return self._client.service.getEventDisplaySettingInfo()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getEventDisplaySettingInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getEventDisplaySettingInfo failed, ' + str(e))

    # イベントカスタムコマンドの設定を取得します。
    def getEventCustomCommandSettingInfo(self):
        try:
            return self._client.service.getEventCustomCommandSettingInfo()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getEventCustomCommandSettingInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getEventCustomCommandSettingInfo failed, ' + str(e))

    # イベントカスタムコマンドの実行結果を取得します。
    def getEventCustomCommandResult(self, command_result_id):
        try:
            return self._client.service.getEventCustomCommandResult(command_result_id)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getEventCustomCommandResult failed, ' + str(e))
            raise ErrorHandler.APIError('getEventCustomCommandResult failed, ' + str(e))

    # 引数で指定されたイベントNoのコマンドを指定されたイベント情報に対して実行します。
    def execEventCustomCommand(self, command_no, event_data_info):
        try:
            return self._client.service.execEventCustomCommand(command_no, event_data_info)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('execEventCustomCommand failed, ' + str(e))
            raise ErrorHandler.APIError('execEventCustomCommand failed, ' + str(e))
