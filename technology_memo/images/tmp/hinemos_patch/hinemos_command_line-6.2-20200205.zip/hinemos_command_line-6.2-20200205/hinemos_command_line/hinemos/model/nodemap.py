# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.model import BasicObject


# NodeMapEndpointより取得した結果のダミーデータを除外するため、必要十分なモデルクラスの定義
class NodeInfo(BasicObject):
    __keylist__ = ['facilityId', 'facilityName', 'platformFamily', 'ownerRoleId', 'createDatetime', 'modifyDatetime']

    facilityId = None
    facilityName = None
    platformFamily = None
    ownerRoleId = None
    createDatetime = None
    modifyDatetime = None

    def __init__(self):
        BasicObject.__init__(self)
