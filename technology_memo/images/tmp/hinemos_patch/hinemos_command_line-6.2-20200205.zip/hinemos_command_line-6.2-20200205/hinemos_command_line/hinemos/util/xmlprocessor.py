# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import sys
import os
import platform
import hinemos
import socket
import datetime
import re
from xml.etree.ElementTree import Element, ElementTree
from xml.etree.ElementTree import SubElement
from xml.etree.ElementTree import parse as parse_element_tree
from hinemos.api import exceptions as ErrorHandler
from hinemos import porting

class XMLWriter(object):

    _name = None
    element = None

    def __init__(self, name, xmlroot):
        self._name = name

        # 出力XMLの形成
        self.element = Element(xmlroot)

    def set_common(self, mgr_url, user):
        u'''
        Set XML header (<common/>)
        '''

        # Get local IP
        myhost = 'UNKNOWN'
        myip = 'UNKNOWN'
        try:
            myhost = socket.gethostname()
            myip = socket.gethostbyname_ex(myhost)[-1][0]
        except:
            pass

        try:
            common = SubElement(self.element, 'common')
            version = SubElement(common, 'toolVersion')
            version.text = hinemos.__version__
            hversion = SubElement(common, 'hinemosVersion')
            hversion.text = hinemos.__hinemos_version__
            manager = SubElement(common, 'connectedManager')
            manager.text = mgr_url
            author = SubElement(common, 'author')
            author.text = user
            runat = SubElement(common, 'runtimeHost')
            runat.text = '%s(%s)' % (myhost, myip)
            generator = SubElement(common, 'generator')
            generator.text = 'python %s - %s' % (re.sub('[\r\n]','',sys.version), platform.platform())
            genearte_date = SubElement(common, 'generateDate')
            genearte_date.text = datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')
        except Exception, e:
            raise ErrorHandler.PortingExportError('set common failed, ' + str(e))

    def set_schema_info(self):
        u'''
        schemaInfoをセット
        '''
        try:
            schema_info = porting.xml_schema[self._name]
            s_revision = 1

            schemaInfo = SubElement(self.element, 'schemaInfo')
            schemaType = SubElement(schemaInfo, 'schemaType')
            schemaType.text = schema_info['SCHEMATYPE']
            schemaVersion = SubElement(schemaInfo, 'schemaVersion')
            schemaVersion.text = str(schema_info['SCHEMAVER'])
            schemaRevision = SubElement(schemaInfo, 'schemaRevision')
            schemaRevision.text = str(s_revision)
        except Exception, e:
            raise ErrorHandler.PortingExportError('set schemaInfo failed, ' + str(e))

    def set_header(self, mgr_url, user):
        u'''
        Set XML header (<common/>, <schemaInfo/>)
        ''' 
        self.set_common(mgr_url, user)
        self.set_schema_info()

    def write(self, directory, force=False):
        if not os.path.isdir(os.path.abspath(directory)):
            raise ErrorHandler.PortingExportError( 'Directory Not Found, ' + directory )
        file_path = os.path.abspath(os.path.join(directory, self._name + '.xml'))

        if not force and os.path.exists(file_path):
            raise ErrorHandler.PortingExportError('writeXML failed, %s already exists!' % file_path)
        try:
            with file(file_path, 'wb') as fp:
                tree = ElementTree(self.element)
                tree.write(fp, encoding='UTF-8')
        except IOError, e:
            raise ErrorHandler.PortingExportError('writeXML failed, ' + str(e))

class XMLReader(object):
    _name = None
    element_tree = None

    def __init__(self, name, directory):
        self._name = name

        # Check and load file
        file_path = os.path.join(directory, name+'.xml')
        if not os.path.isfile(file_path):
            raise ErrorHandler.FileReadError( 'File Not Found, ' + file_path )

        tree = parse_element_tree(file_path)
        schema_info = porting.xml_schema[self._name]
        s_revision = 1
        XMLReader.validate_schema_info(tree, schema_info['SCHEMATYPE'], schema_info['SCHEMAVER'], s_revision)
        self.element_tree = tree

    @staticmethod
    def validate_schema_info(tree, schema_type, schema_ver, schema_rev):
        try:
            schema_info_element = tree.getroot().find('schemaInfo')

            u'''
            XML のスキーマタイプを取得し、ツールと比較
            '''
            your_schema_type = schema_info_element.find('schemaType').text
            your_schema_ver = int(schema_info_element.find('schemaVersion').text)
        except:
            raise ErrorHandler.FileReadError('checkSchemaInfo failed, failed to fetch schema info!')

        if your_schema_type == schema_type:
            if your_schema_ver > schema_ver:
                raise ErrorHandler.FileReadError('checkSchemaInfo failed, the version of your XML is not compatible with this tool ("%s-%d" > "%s-%d")! Please use a newer version.' % (your_schema_type, your_schema_ver, schema_type, schema_rev))
        else:
            raise ErrorHandler.FileReadError('checkSchemaInfo failed, the version of your XML is not compatible with this tool ("%s-%d" <> "%s-%d")!' % (your_schema_type, your_schema_ver, schema_type, schema_rev))
