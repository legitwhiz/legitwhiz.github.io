# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import re
import hinemos.api.exceptions as ErrorHandler

def create_logformat_list(element_tree, endpoint):
    info_list = []
    try:
        elem = element_tree.getroot()
        print elem.tag
        for el in elem.iterfind('logFormatInfo'):
            u'''
            logformat_info を生成し、リストに追加
            '''
            logformat_info = endpoint.create_object('logFormat')
            logformat_info.keyPatternList = []
            temp = str(el.attrib).split(',')
            for s in temp:
                p = re.compile('\'.*\':')
                m = p.search(s, 0)
                if m:
                    attribute = s[m.start()+1:m.end()-2]
                    if attribute == 'logFormatId':
                        logformat_info['logFormatId'] = el.get(attribute)
                    elif attribute == 'ownerRoleId':
                        logformat_info['ownerRoleId'] = el.get(attribute)
                    elif attribute == 'description':
                        logformat_info['description'] = el.get(attribute)
                    elif attribute == 'timestampFormat':
                        logformat_info['timestampFormat'] = el.get(attribute)
                    elif attribute == 'timestampRegex':
                        logformat_info['timestampRegex'] = el.get(attribute)
                    else:
                        logformat_info[attribute] = el.get(attribute)
            for vl in el:
                keyPatternList = endpoint.create_object('keyPatternList')
                temp = str(vl.attrib).split(',')
                fixed_value = ''
                for s in temp:
                    p = re.compile('\'.*\': ')
                    m = p.search(s, 0)
                    if m:
                        attribute = s[m.start()+1:m.end()-3]
                        if attribute == 'key':
                            keyPatternList.key = vl.get(attribute)
                        elif attribute == 'pattern':
                            keyPatternList.pattern = vl.get(attribute)
                        elif attribute == 'description':
                            keyPatternList.description = vl.get(attribute)
                        elif attribute == 'keyType':
                            if vl.get(attribute) == '0':
                                keyPatternList.keyType = 'parsing'
                            elif vl.get(attribute) == '1':
                                keyPatternList.keyType = 'fixed'
                            else:
                                raise ErrorHandler.ArgumentError('Invalid keyType - %s.' % vl.get(attribute))
                        elif attribute == 'value':
                            fixed_value = vl.get(attribute)
                        elif attribute == 'valueType':
                            if vl.get(attribute) == '0':
                                keyPatternList.valueType = 'string'
                            elif vl.get(attribute) == '1':
                                keyPatternList.valueType = 'number'
                            elif vl.get(attribute) == '2':
                                keyPatternList.valueType = 'bool'
                            else:
                                raise ErrorHandler.ArgumentError('Invalid valueType - %s.' % vl.get(attribute))
                if fixed_value is not None and keyPatternList.keyType == 'fixed':
                    keyPatternList.value = fixed_value
                logformat_info.keyPatternList.append(keyPatternList)
            info_list.append(logformat_info)
        return info_list
    except Exception, e:
        raise ErrorHandler.FileReadError('create logFormat failed, ' + str(e))
