# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

class ArgumentError(Exception):

    def __init__(self, value):
        super(self.__class__, self).__init__(value)

class PermissoinError(Exception):

    def __init__(self, value):
        super(self.__class__, self).__init__(value)

class LoginError(Exception):

    def __init__(self, value):
        super(self.__class__, self).__init__(value)

class APIError(Exception):

    def __init__(self, value):
        super(self.__class__, self).__init__(value)

class JUNotFoundError(Exception):

    def __init__(self, value):
        super(self.__class__, self).__init__(value)

class JobNotFoundError(Exception):

    def __init__(self, value):
        super(self.__class__, self).__init__(value)

class ObjectNotFoundError(Exception):

    def __init__(self, value):
        super(self.__class__, self).__init__(value)

class FileReadError(Exception):

    def __init__(self, value):
        super(self.__class__, self).__init__(value)

class PortingExportError(Exception):

    def __init__(self, value):
        super(self.__class__, self).__init__(value)

class PortingImportError(Exception):

    def __init__(self, value):
        super(self.__class__, self).__init__(value)

class BadResultError(Exception):

    def __init__(self, value):
        super(self.__class__, self).__init__(value)

