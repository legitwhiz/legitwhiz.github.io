# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.model.nodemap import NodeInfo
from hinemos.util.common import DateConvert


# NodeMapEndpointより取得した結果のダミーデータを除外し、設定するクラス
class ResultSet(object):

    # nodeListInfoの結果を編集
    @staticmethod
    def format_node_list_info(result):
        node_list = []
        for i in range(len(result)):
            node_info = NodeInfo()
            node_info.facilityId = result[i].facilityId
            node_info.facilityName = result[i].facilityName
            node_info.platformFamily = result[i].platformFamily
            node_info.ownerRoleId = result[i].ownerRoleId
            node_info.createDatetime = DateConvert.get_datetime_from_epochtime(result[i].createDatetime)
            node_info.modifyDatetime = DateConvert.get_datetime_from_epochtime(result[i].modifyDatetime)
            node_list.append(node_info)
        return node_list
