#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.util.modifier import ObjectModifier


class HubUtil(object):

    # @see com.clustercontrol.hub.model.TransferInfo
    _transfer_type_ = ['realtime', 'batch', 'delay']

    _data_type_ = ['job', 'event', 'numeric', 'string']

    # :see: com.clustercontrol.ws.hub.Operator
    _operator_ = ['AND', 'OR']

    # :see: HubPreferencePage.PAGE_MAX_DEFAULT
    PAGE_MAX_DEFAULT = 12

    @staticmethod
    def set_transfer_info(info, desc, cal_id, data_type, dest_type_id, dest_props, trans_type, interval, enable):
        ObjectModifier.replace_if_not_none(
            info,
            description=desc,
            dataType=data_type,
            destTypeId=dest_type_id,
            destProps=dest_props,
            transType=trans_type,
            interval=interval,
            calendarId=cal_id,
            validFlg=enable)

        ObjectModifier.replace_none_if_empty(info, 'calendarId')

        return info

    @staticmethod
    def set_logformat(info, desc, ts_regex, ts_format):
        ObjectModifier.replace_if_not_none(
            info,
            description=desc,
            timestampRegex=ts_regex,
            timestampFormat=ts_format)
        return info

    @staticmethod
    def set_logformat_key(info, desc, value_type, key_type, pattern, value):
        if pattern is None:
            pattern = ''
        if value is None:
            value = ''

        ObjectModifier.replace_if_not_none(
            info,
            description=desc,
            valueType=value_type,
            keyType=key_type,
            pattern=pattern,
            value=value)
        return info

    @staticmethod
    def convert2operator(label):
        return None if label is None else label.upper()
