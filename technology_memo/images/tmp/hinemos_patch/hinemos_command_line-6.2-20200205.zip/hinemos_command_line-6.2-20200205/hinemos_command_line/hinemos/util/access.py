#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

class AccessUtil(object):
    '''
    Access Utility
    '''

    # @see com.clustercontrol.accesscontrol.bean.FunctionConstant
    _function_type_ = ('HinemosAgent', 'HinemosHA', 'Repository', 'AccessControl', 'JobManagement', 'Collect', 'MonitorResult', 'MonitorSetting', 'Calendar', 'Notify', 'Infra', 'Maintenance', 'CloudManagement', 'Reporting', 'Hub')


    # @see com.clustercontrol.accesscontrol.bean.PrivilegeConstant
    _obj_privilege_type_ = ('READ', 'MODIFY', 'EXEC') #, 'NONE')
    _sys_privilege_type_ = ('ADD', 'READ', 'MODIFY', 'EXEC', 'APPROVAL')
