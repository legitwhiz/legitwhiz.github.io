#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler

class JmxMasterEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'JmxMaster')

    def get_jmx_master_info_list(self):
        try:
            return self._client.service.getJmxMasterInfoList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getJmxMasterInfoList failed, ' + str(e))
            raise ErrorHandler.APIError('getJmxMasterInfoList failed, ' + str(e))

    def create_jmx_master_info(self, attribute_name, master_id, keys, measure, name, object_name):
        # Format input
        if keys is None:
            keys = ''

        obj_name = 'ns1:jmxMasterInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.attributeName = attribute_name
            info.id = master_id
            info.keys = keys
            info.measure = measure
            info.name = name
            info.objectName = object_name
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def add_jmx_master_list(self, jmx_master_infos):
        try:
            return self._client.service.addJmxMasterList(jmx_master_infos)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addJmxMasterList failed, ' + str(e))
            raise ErrorHandler.APIError('addJmxMasterList failed, ' + str(e))

    def delete_jmx_master_all(self):
        try:
            return self._client.service.deleteJmxMasterAll()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteJmxMasterAll failed, ' + str(e))
            raise ErrorHandler.APIError('deleteJmxMasterAll failed, ' + str(e))

    def delete_jmx_master_list(self, jmx_master_ids):
        try:
            return self._client.service.deleteJmxMasterList(jmx_master_ids)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteJmxMasterList failed, ' + str(e))
            raise ErrorHandler.APIError('deleteJmxMasterList failed, ' + str(e))
