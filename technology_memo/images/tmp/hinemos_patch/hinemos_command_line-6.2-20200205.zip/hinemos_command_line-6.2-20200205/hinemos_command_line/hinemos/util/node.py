# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

class NodeUtil(object):
    '''
    NodeUtil
    '''

    @staticmethod
    def setnode_cpu_info(cpuInfo,cpu_DeviceDisplayName,cpu_DeviceIndex,cpu_DeviceName,cpu_DeviceDescription,cpu_DeviceSize,cpu_DeviceSizeUnit):
        try:
            cpuInfo.deviceType = 'cpu'
            if cpu_DeviceDisplayName != '':
                cpuInfo.deviceDisplayName = cpu_DeviceDisplayName
            if cpu_DeviceIndex != '':
                cpuInfo.deviceIndex = int(cpu_DeviceIndex)
            if cpu_DeviceName != '':
                cpuInfo.deviceName = cpu_DeviceName
            if cpu_DeviceDescription != '':
                cpuInfo.deviceDescription = cpu_DeviceDescription
            if cpu_DeviceSize != '':
                cpuInfo.deviceSize = int(cpu_DeviceSize)
            if cpu_DeviceSizeUnit != '':
                cpuInfo.deviceSizeUnit = cpu_DeviceSizeUnit

        except Exception, e:
            raise Exception(e)
        return cpuInfo

    @staticmethod
    def setnode_memory_info(memoryInfo,memory_DeviceDisplayName,memory_DeviceIndex,memory_DeviceName,memory_DeviceDescription,memory_DeviceSize,memory_DeviceSizeUnit):
        try:
            memoryInfo.deviceType = 'mem'
            if memory_DeviceDisplayName != '':
                memoryInfo.deviceDisplayName = memory_DeviceDisplayName
            if memory_DeviceIndex != '':
                memoryInfo.deviceIndex = int(memory_DeviceIndex)
            if memory_DeviceName != '':
                memoryInfo.deviceName = memory_DeviceName
            if memory_DeviceDescription != '':
                memoryInfo.deviceDescription = memory_DeviceDescription
            if memory_DeviceSize != '':
                memoryInfo.deviceSize = int(memory_DeviceSize)
            if memory_DeviceSizeUnit != '':
                memoryInfo.deviceSizeUnit = memory_DeviceSizeUnit
        except Exception, e:
            raise Exception(e)
        return memoryInfo

    @staticmethod
    def setnode_nic_info(nicInfo,nic_DeviceDisplayName,nic_DeviceIndex,nic_DeviceName,nic_DeviceDescription,nic_DeviceSize,nic_DeviceSizeUnit,nic_NicIpAddress,nic_NicMacAddress):
        try:
            nicInfo.deviceType = 'nic'
            if nic_DeviceDisplayName != '':
                nicInfo.deviceDisplayName = nic_DeviceDisplayName
            if nic_DeviceIndex != '':
                nicInfo.deviceIndex = int(nic_DeviceIndex)
            if nic_DeviceName != '':
                nicInfo.deviceName = nic_DeviceName
            if nic_DeviceDescription != '':
                nicInfo.deviceDescription = nic_DeviceDescription
            if nic_DeviceSize != '':
                nicInfo.deviceSize = int(nic_DeviceSize)
            if nic_DeviceSizeUnit != '':
                nicInfo.deviceSizeUnit = nic_DeviceSizeUnit
            if nic_NicIpAddress != '':
                nicInfo.nicIpAddress = nic_NicIpAddress
            if nic_NicMacAddress != '':
                nicInfo.nicMacAddress = nic_NicMacAddress
        except Exception, e:
            raise Exception(e)
        return nicInfo

    @staticmethod
    def setnode_disk_info(diskInfo,disk_DeviceDisplayName,disk_DeviceIndex,disk_DeviceName,disk_DeviceDescription,disk_DeviceSize,disk_DeviceSizeUnit,disk_DiskRpm):
        try:
            diskInfo.deviceType = 'disk'
            if disk_DeviceDisplayName != '':
                diskInfo.deviceDisplayName = disk_DeviceDisplayName
            if disk_DeviceIndex != '':
                diskInfo.deviceIndex = int(disk_DeviceIndex)
            if disk_DeviceName != '':
                diskInfo.deviceName = disk_DeviceName
            if disk_DeviceDescription != '':
                diskInfo.deviceDescription = disk_DeviceDescription
            if disk_DeviceSize != '':
                diskInfo.deviceSize = int(disk_DeviceSize)
            if disk_DeviceSizeUnit != '':
                diskInfo.deviceSizeUnit = disk_DeviceSizeUnit
            if disk_DiskRpm != '':
                diskInfo.diskRpm = int(disk_DiskRpm)
        except Exception, e:
            raise Exception(e)
        return diskInfo

    @staticmethod
    def setnode_filesystem_info(filesystemInfo,filesystem_DeviceDisplayName,filesystem_DeviceIndex,filesystem_DeviceName,filesystem_DeviceDescription,filesystem_DeviceSize,filesystem_DeviceSizeUnit):
        try:
            filesystemInfo.deviceType = 'filesystem'
            if filesystem_DeviceDisplayName != '':
                filesystemInfo.deviceDisplayName = filesystem_DeviceDisplayName
            if filesystem_DeviceIndex != '':
                filesystemInfo.deviceIndex = int(filesystem_DeviceIndex)
            if filesystem_DeviceName != '':
                filesystemInfo.deviceName = filesystem_DeviceName
            if filesystem_DeviceDescription != '':
                filesystemInfo.deviceDescription = filesystem_DeviceDescription
            if filesystem_DeviceSize != '':
                filesystemInfo.deviceSize = int(filesystem_DeviceSize)
            if filesystem_DeviceSizeUnit != '':
                filesystemInfo.deviceSizeUnit = filesystem_DeviceSizeUnit
        except Exception, e:
            raise Exception(e)
        return filesystemInfo

    @staticmethod
    def setnode_device_info(deviceInfo,device_DeviceDisplayName,device_DeviceIndex,device_DeviceName,device_DeviceDescription,device_DeviceSize,device_DeviceSizeUnit,device_DeviceType):
        try:
            if device_DeviceDisplayName != '':
                deviceInfo.deviceDisplayName = device_DeviceDisplayName
            if device_DeviceIndex != '':
                deviceInfo.deviceIndex =int(device_DeviceIndex)
            if device_DeviceName != '':
                deviceInfo.deviceName = device_DeviceName
            if device_DeviceDescription != '':
                deviceInfo.deviceDescription = device_DeviceDescription
            if device_DeviceSize != '':
                deviceInfo.deviceSize = int(device_DeviceSize)
            if device_DeviceSizeUnit != '':
                deviceInfo.deviceSizeUnit = device_DeviceSizeUnit
            if device_DeviceType != '':
                deviceInfo.deviceType = device_DeviceType
        except Exception, e:
            raise Exception(e)
        return deviceInfo

    @staticmethod
    def setnode_hostname_info(nodeHostnameInfo,hostname):
        try:
            nodeHostnameInfo.hostname = hostname
        except Exception, e:
            raise Exception(e)
        return nodeHostnameInfo

    @staticmethod
    def setnode_variable_info(nodeVariableInfo,nodeVariableName,nodeVariableValue):
        try:
            if nodeVariableName != '':
                nodeVariableInfo.nodeVariableName = nodeVariableName
            if nodeVariableValue != '':
                nodeVariableInfo.nodeVariableValue = nodeVariableValue
        except Exception, e:
            raise Exception(e)
        return nodeVariableInfo

    @staticmethod
    def setnode_note_info(nodeNoteInfo,noteId,note):
        try:
            nodeNoteInfo.noteId = int(noteId)
            nodeNoteInfo.note = note
        except Exception, e:
            raise Exception(e)
        return nodeNoteInfo

    @staticmethod
    def snmp_version_check(version):
        if version != '1' and version != '2c' and version != '':
            return True
        else:
            return False

    @staticmethod
    def protocol_check(version):
        if version != 'http' and version != 'https' and version != '':
            return True
        else:
            return False

    @staticmethod
    def vm_node_type_check(vmNodeType):
        if vmNodeType != 'guest' and vmNodeType != 'host' and vmNodeType != 'controller' and vmNodeType != '':
            return True
        else:
            return False

    @staticmethod
    def port_check(port):
        try:
            if int(port) < 0 or int(port) > 65535:
                return True
            else:
                return False
        except Exception, e:
            raise Exception(e)

    @staticmethod
    def retry_count_check(retryCount):
        try:
            if int(retryCount) < 1 or int(retryCount) > 10:
                return True
            else:
                return False
        except Exception, e:
            raise Exception(e)

    @staticmethod
    def number_check(number):
        try:
            if int(number) < 0 or int(number) > 2147483647:
                return True
            else:
                return False
        except Exception, e:
            raise Exception(e)
