#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------


class CollectUtil(object):

    # @see com.clustercontrol.collect.bean.SummaryTypeConstant
    _summary_type_ = ['RAW', 'AVG_HOUR', 'AVG_DAY', 'AVG_MONTH', 'MIN_HOUR', 'MIN_DAY', 'MIN_MONTH', 'MAX_HOUR', 'MAX_DAY', 'MAX_MONTH']

    @staticmethod
    def convert2summary_type(label):
        return CollectUtil._summary_type_.index(label)
