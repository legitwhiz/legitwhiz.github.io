#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import re
import sys
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.calendar import CalendarUtil
from hinemos.util.modifier import ObjectModifier
from hinemos.util.common import ResultPrinter

class JobUtil(object):

    # @see com.clustercontrol.jobmanagement.bean.JobConstant
    '''
    ツリーのトップ    TYPE_COMPOSITE = -1
    unreferable jobunit (ジョブの種別)    TYPE_JOBUNIT_UNREFERABLE = 4
    マネージャ(ジョブの種別) TYPE_MANAGER = 6
    参照ジョブネット(ジョブの種別)    TYPE_REFERJOBNET = 7
    '''
    _job_type_ = {'JOBUNIT':0, 'JOBNET':1, 'JOB':2, 'FILEJOB':3, 'REFERJOB':5, 'REFERJOBNET':7, 'APPROVALJOB':8, 'MONITORJOB':9}
    _job_type_full_ = dict(_job_type_.items() + {'COMPOSITE':-1, 'JOBUNIT_UNREFERABLE':4, 'MANAGER':6}.items())

    # @see com/clustercontrol/bean/EndStatusConstant
    _end_status_ = ('NORMAL', 'WARNING', 'ABNORMAL')
    _end_status_full_ = _end_status_ + ('BEGINNING', 'ANY')
    _end_status_wait_ = _end_status_ + ('ANY',)

    # @see com.clustercontrol.jobmanagement.bean.FileCheckConstant
    _file_check_event_type_ = ('ADD', 'DEL', 'MOD')
    _file_check_mod_type_ = ('TIMESTAMP', 'FILESIZE')

    # @see com.clustercontrol.bean.ScheduleConstant
    _job_schedule_type_ = {'DAILY':1, 'WEEKLY':2, 'HOURLY':3}

    # @see com.clustercontrol.bean.JobRuntimeParamTypeConstant
    _job_runtime_param_type_ = ('INPUT', 'RADIO', 'COMBO', 'FIXED')

    # @see com/clustercontrol/jobmanagement/bean/JobParamTypeConstant
    _job_param_type_ = ('SYSTEM_JOB', 'SYSTEM_NODE', 'USER', 'RUNTIME')

    _multiplicity_operation_ = {'WAIT':0, 'END':300}

    _start_delay_operation_type_ = {'SKIP':4, 'WAIT':6}
    _end_delay_operation_type_ = {'COMMAND':0, 'SUSPEND':2, 'SET_END_VALUE':10}

    # @see com.clustercontrol.jobmanagement.bean.JobRuntimeParamTypeConstant
    _rt_param_type_ = ('INPUT', 'RADIO', 'COMBO', 'FIXED')

    # @see
    _wait_rule_object_type_ = ('JOB_END_STATUS', 'JOB_END_CODE', 'TIME', 'MINUTE_AFTER_STARTED', 'JOB_PARAM')
    # @see
    _condition_ = ('AND', 'OR')

    # @see com.clustercontrol.bean.JobApprovalStatusConstant
    _job_approval_status_ = (None, 'CLOSED', 'STOP', 'SUSPEND', 'STILL', 'PENDING')

    # TYPE_APPROVAL = 0, TYPE_DENIAL = 9
    _job_approval_result_type_ = {'APPROVED':0, 'DENIED': 9}

    _job_finish_status_ = {'NOT_DEFINED': None, 'NORMAL': 0, 'WARNING': 1, 'ABNORMAL': 2}


    # @see com.clustercontrol.jobmanagement.bean.DecisionObjectMessage, com.clustercontrol.jobmanagement.bean.DecisionObjectConstant
    _decision_comparators_ = ('==', '!=', '>', '>=', '<', '<=', 'EQUAL_STRING', 'NOT_EQUAL_STRING')

    @staticmethod
    def enum_job_type():
        return JobUtil._job_type_.keys()

    @staticmethod
    def enum_decision_comparators():
        return JobUtil._decision_comparators_

    @staticmethod
    def convert2dicision_comparator(label):
        return None if label is None else JobUtil._decision_comparators_.index(label)

    @staticmethod
    def convert2job_type(label):
        return JobUtil._job_type_[label]

    @staticmethod
    def convert2job_type_label(job_type):
        for k,v in JobUtil._job_type_.iteritems():
            if v == job_type:
                return k
        else:
            return None

    @staticmethod
    def convert2end_status(label):
        return None if label is None else JobUtil._end_status_full_.index(label)

    @staticmethod
    def convert2finish_status(label):
        return None if label is None else JobUtil._job_finish_status_.get(label)

    @staticmethod
    def convert2file_check_event_type(label):
        return None if label is None else JobUtil._file_check_event_type_.index(label)

    @staticmethod
    def convert2file_check_mod_type(label):
        return None if label is None else JobUtil._file_check_mod_type_.index(label)

    @staticmethod
    def convert2job_schedule_type(label):
        return None if label is None else JobUtil._job_schedule_type_[label.upper()]

    @staticmethod
    def convert2job_runtime_param_type(label):
        return None if label is None else JobUtil._job_runtime_param_type_[label.upper()]

    @staticmethod
    def convert2multiplicity_operation(label):
        return None if label is None else JobUtil._multiplicity_operation_[label.upper()]

    @staticmethod
    def convert2job_param_type(label):
        return None if label is None else JobUtil._job_param_type_.index(label)

    @staticmethod
    def convert2wait_rule_object_type(label):
        return None if label is None else JobUtil._wait_rule_object_type_.index(label)

    @staticmethod
    def convert2condition(label):
        return None if label is None else JobUtil._condition_.index(label)

    @staticmethod
    def convert2start_delay_operation_type(label):
        return None if label is None else JobUtil._start_delay_operation_type_[label]

    @staticmethod
    def convert2end_delay_operation_type(label):
        return None if label is None else JobUtil._end_delay_operation_type_[label]

    @staticmethod
    def enum_job_approval_status():
        return tuple(a for a in JobUtil._job_approval_status_ if a is not None)

    @staticmethod
    def convert2job_approval_status(label):
        return None if label is None else JobUtil._job_approval_status_.index(label)

    @staticmethod
    def enum_job_approval_result():
        return JobUtil._job_approval_result_type_.keys()

    @staticmethod
    def convert2job_approval_result(label):
        return None if label is None else JobUtil._job_approval_result_type_[label]

    @staticmethod
    def convert2param_type(label):
        return None if label is None else JobUtil._rt_param_type_.index(label)

    @staticmethod
    def convert2job(job_path):
        jobunit_id = None
        job_id = None
        if job_path is not None:
            job_splited = job_path.split('/')
            if len(job_splited) == 1:
                jobunit_id = job_id = job_path
            elif len(job_splited) == 2:
                jobunit_id, job_id = job_splited
            else:
                jobunit_id = job_path
        return {'jobunitId': jobunit_id, 'jobId': job_id}

    @staticmethod
    def convert2schedule(schedule_str):
        schedule_type = None
        hour = None
        minute = None
        week = None
        every_x_minutes = None
        from_x_minutes = None
        if schedule_str is not None:
            try:
                matches = re.match(r'(\w+) (\w+ |)(\*|\d+)[:/](\d+)$', schedule_str)
                if matches:
                    sch_type_str = matches.group(1)
                    schedule_type = JobUtil.convert2job_schedule_type(sch_type_str)

                    if schedule_type == JobUtil.convert2job_schedule_type('HOURLY'):
                        from_x_minutes, every_x_minutes = int(matches.group(3)), int(matches.group(4))
                    elif schedule_type == JobUtil.convert2job_schedule_type('DAILY'):
                        if '*' == matches.group(3):
                            hour = None
                        else:
                            hour = int(matches.group(3))
                        minute = int(matches.group(4))
                    elif schedule_type == JobUtil.convert2job_schedule_type('WEEKLY'):
                        week = CalendarUtil.convert2weekday(matches.group(2).strip())
                        if '*' == matches.group(3):
                            hour = None
                        else:
                            hour = int(matches.group(3))
                        minute = int(matches.group(4))
                else:
                    raise ValueError
            except (ValueError, KeyError, TypeError):
                raise ErrorHandler.ArgumentError('schedule format is not correct!')
        return {'scheduleType': schedule_type, 'hour': hour, 'minute': minute, 'week': week, 'everyXminutes': every_x_minutes, 'fromXminutes': from_x_minutes}

    @staticmethod
    def remove_unexisted_notifications(job_tree_item, notify_endpoint):
        if hasattr(job_tree_item.data, 'notifyRelationInfos'):
            for i in reversed(xrange(len(job_tree_item.data.notifyRelationInfos))):
                noti = job_tree_item.data.notifyRelationInfos[i]
                skip_noti = True

                # pylint: disable=W0703
                try:
                    notify_info = notify_endpoint.getNotify(noti.notifyId)
                    if str(notify_info.notifyType) != str(noti.notifyType):
                        print('[WARN] notifyType is not matched.')
                    else:
                        skip_noti = False
                except Exception, e:
                    print('[WARN] %s' % e)
                if skip_noti:
                    print('Notify( NotifyId =%s) will be ignored.' % noti.notifyId)
                    del job_tree_item.data.notifyRelationInfos[i]
        # Scan recursively and remove
        if job_tree_item.children is not None and len(job_tree_item.children) > 0:
            for one in job_tree_item.children:
                JobUtil.remove_unexisted_notifications(notify_endpoint, one)

    @staticmethod
    def get_job_unit_tree_item(job_tree_full, jobunit_id):
        for x in job_tree_full.children[0].children:
            if x.data.id == jobunit_id:
                return x
        raise ErrorHandler.JUNotFoundError('Jobunit Not found,')

    @staticmethod
    def find_job_info(job_tree, job_id):
        if job_tree.data.id == job_id:
            return job_tree.data
        else:
            if hasattr(job_tree, 'children'):
                for x in job_tree.children:
                    job_info = JobUtil.find_job_info(x, job_id)
                    if job_info:
                        return job_info
            return None

    @staticmethod
    def add_child(root_tree, parent_id, job_tree_item):
        if root_tree.data.id == parent_id:
            if not hasattr(root_tree, 'children'):
                setattr(root_tree, 'children', [])
            root_tree.children.append(job_tree_item)
            return True

        if hasattr(root_tree, 'children'):
            for x in root_tree.children:
                if JobUtil.add_child(x, parent_id, job_tree_item):
                    return True
        return False

    @staticmethod
    def del_child(root_tree, job_id):
        if hasattr(root_tree, 'children'):
            for i, x in enumerate(root_tree.children):
                if x.data.id == job_id:
                    job_info = x
                    del root_tree.children[i]
                    return job_info
                job_info = JobUtil.del_child(x, job_id)
                if job_info:
                    return job_info
        return None

    @staticmethod
    def replace_job_info(job_tree, new_job_info, old_id=None):
        if old_id is None:
            job_id = new_job_info.id
        else:
            job_id = old_id

        if not JobUtil.find_and_replace_job_info(job_tree, job_id, new_job_info):
            raise ErrorHandler.JobNotFoundError('%s does not exist!' % new_job_info.id)

    @staticmethod
    def find_and_replace_job_info(job_tree, job_id, new_job_info):
        if job_tree.data.id == job_id:
            # Reuse type and name
            # FIXME HC Sometimes name becomes None and type is 0
            if new_job_info.type == 0  or new_job_info.type is None:
                new_job_info.type  = job_tree.data.type
            if new_job_info.name is None:
                new_job_info.name  = job_tree.data.name

            job_tree.data = new_job_info
            return True
        else:
            if hasattr(job_tree, 'children'):
                for x in job_tree.children:
                    pass
                    if JobUtil.find_and_replace_job_info(x, job_id, new_job_info) == True:
                        return True
            return False

    @staticmethod
    def del_attr_when(info, attr, **kwargs):
        matched = True
        for k, v in kwargs.iteritems():
            if getattr(info, k) != v:
                matched = False
                break
        if matched and hasattr(info, attr):
            delattr(info, attr)

    @staticmethod
    def cleanup_and_fixnone(job_tree_item):
        if hasattr(job_tree_item, 'data') and job_tree_item.data:
            # Clean-up
            if hasattr(job_tree_item.data, 'param'):
                for x in job_tree_item.data.param:
                    if hasattr(x, 'value') and x.value == '':
                        delattr(x, 'value')

            if hasattr(job_tree_item.data, 'command'):
                JobUtil.del_attr_when(job_tree_item.data.command, 'stopCommand', stopType=1)
                JobUtil.del_attr_when(job_tree_item.data.command, 'user', specifyUser=0)
            if hasattr(job_tree_item.data, 'file'):
                JobUtil.del_attr_when(job_tree_item.data.file, 'user', specifyUser=0)

            # Replace none
            if job_tree_item.data.description is None:
                job_tree_item.data.description = ''
        if hasattr(job_tree_item, 'children') and job_tree_item.children:
            for x in job_tree_item.children:
                JobUtil.cleanup_and_fixnone(x)

    @staticmethod
    def set_job_command_info(command_attr, facility_id, start_command):
        ''' jobCommandInfo attribute with default setting '''

        if facility_id == '#[FACILITY_ID]':
            scope = None
        else:
            scope = ' '

        ObjectModifier.set_attrs(command_attr,\
        commandRetry = 10,\
        commandRetryFlg = 0,\
        facilityID = facility_id,\
        scope = scope,\
        messageRetry = 10,\
        messageRetryEndFlg = 1,\
        messageRetryEndValue = -1,\
        processingMethod = 0,\
        specifyUser = 0,\
        startCommand = start_command,\
        stopType = 1)

    @staticmethod
    def set_wait_rule_info(wait_rule_attr):
        ''' WaitRule attribute with default setting '''

        ObjectModifier.set_attrs(wait_rule_attr,\
            calendar = 0,\
            calendarEndStatus = 2,\
            calendarEndValue = 0,\
            condition = 0,\
            endCondition = 1,\
            endStatus = 2,\
            endValue = -1,\
            end_delay = 0,\
            end_delay_condition_type = 0,\
            end_delay_job = 0,\
            end_delay_job_value = 1,\
            end_delay_notify = 0,\
            end_delay_notify_priority = 0,\
            end_delay_operation = 0,\
            end_delay_operation_end_status = 2,\
            end_delay_operation_end_value = -1,\
            end_delay_operation_type = 0,\
            end_delay_session = 0,\
            end_delay_session_value = 1,\
            end_delay_time = 0,\
            multiplicityEndValue = -1,\
            multiplicityNotify = 1,\
            multiplicityNotifyPriority = 2,\
            multiplicityOperation = 0,\
            skip = 0,\
            skipEndStatus = 2,\
            skipEndValue = 0,\
            start_delay = 0,\
            start_delay_condition_type = 0,\
            start_delay_notify = 0,\
            start_delay_notify_priority = 0,\
            start_delay_operation = 0,\
            start_delay_operation_end_status = 2,\
            start_delay_operation_end_value = -1,\
            start_delay_operation_type = 0,\
            start_delay_session = 0,\
            start_delay_session_value = 1,\
            start_delay_time = 0,\
            start_delay_time_value = '09:00:00',\
            suspend = 0)

    @staticmethod
    def setInitialValue_jobunit(endpoint,jobunitId,jobName,description,ownerRoleId):
        u'''ジョブユニットの初期値を設定する
        '''
        job_tree = endpoint.create_job_tree_item(jobunitId, jobunitId, jobName, description, 0, ownerRoleId, True)

        job_tree.data.endStatus = [None]*3
        job_tree.data.endStatus[0] = endpoint.create_job_end_status_info(0, 0, 0, 0)
        job_tree.data.endStatus[1] = endpoint.create_job_end_status_info(1, 1, 1, 1)
        job_tree.data.endStatus[2] = endpoint.create_job_end_status_info(2, 0, 0, -1)

        job_tree.data.notifications = [None]*4
        job_tree.data.notifications[0] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 3, 0)
        job_tree.data.notifications[1] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 2, 1)
        job_tree.data.notifications[2] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 0, 2)
        job_tree.data.notifications[3] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 3, 3)

        job_tree.data.param = []

        job_tree.data.waitRule = endpoint.create_waite_rule_info()

        return job_tree

    @staticmethod
    def setInitialValue_jobnet(endpoint,jobunitId,jobId,jobName,description):
        u'''ジョブネットの初期値を設定する
        '''
        job_tree = endpoint.create_job_tree_item(jobId, jobunitId, jobName, description, 1, None, True)

        job_tree.data.endStatus = [None]*3
        job_tree.data.endStatus[0] = endpoint.create_job_end_status_info(0, 0, 0, 0)
        job_tree.data.endStatus[1] = endpoint.create_job_end_status_info(1, 1, 1, 1)
        job_tree.data.endStatus[2] = endpoint.create_job_end_status_info(2, 0, 0, -1)

        job_tree.data.notifications = [None]*4
        job_tree.data.notifications[0] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 3, 0)
        job_tree.data.notifications[1] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 2, 1)
        job_tree.data.notifications[2] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 0, 2)
        job_tree.data.notifications[3] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 3, 3)

        job_tree.data.waitRule = endpoint.create_waite_rule_info()

        return job_tree

    @staticmethod
    def setInitialValue_job(endpoint,jobunitId,jobId,jobName,description):
        u'''ジョブの初期値を設定する
        '''
        job_tree = endpoint.create_job_tree_item(jobId, jobunitId, jobName, description, 2, None, True)

        job_tree.data.command.errorEndFlg= 1
        job_tree.data.command.errorEndValue= -1
        job_tree.data.command.facilityID= None
        job_tree.data.command.messageRetry=10
        job_tree.data.command.processingMethod=0
        job_tree.data.command.scope = None
        job_tree.data.command.specifyUser=0
        job_tree.data.command.startCommand= None
        job_tree.data.command.stopType=1
        job_tree.data.command.user = None


        job_tree.data.endStatus = [None]*3
        job_tree.data.endStatus[0] = endpoint.create_job_end_status_info(0, 0, 0, 0)
        job_tree.data.endStatus[1] = endpoint.create_job_end_status_info(1, 1, 1, 1)
        job_tree.data.endStatus[2] = endpoint.create_job_end_status_info(2, 0, 0, -1)

        job_tree.data.notifications = [None]*4
        job_tree.data.notifications[0] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 3, 0)
        job_tree.data.notifications[1] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 2, 1)
        job_tree.data.notifications[2] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 0, 2)
        job_tree.data.notifications[3] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 3, 3)

        job_tree.data.waitRule = endpoint.create_waite_rule_info()

        return job_tree

    @staticmethod
    def setInitialValue_file(endpoint, jobunitId, jobId, jobName, description):
        u'''ファイル転送ジョブの初期値を設定する
        '''
        job_tree = endpoint.create_job_tree_item(jobId, jobunitId, jobName, description, 3)

        job_tree.data.id = jobId
        job_tree.data.jobunitId = jobunitId
        job_tree.data.name = jobName
        job_tree.data.description = description
        job_tree.data.ownerRoleId = None
        job_tree.data.propertyFull = True
        job_tree.data.type = 3

        job_tree.data.endStatus = [None]*3
        job_tree.data.endStatus[0] = endpoint.create_job_end_status_info(0, 0, 0, 0)
        job_tree.data.endStatus[1] = endpoint.create_job_end_status_info(1, 1, 1, 1)
        job_tree.data.endStatus[2] = endpoint.create_job_end_status_info(2, 0, 0, -1)

        job_tree.data.notifications = [None]*4
        job_tree.data.notifications[0] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 3, 0)
        job_tree.data.notifications[1] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 2, 1)
        job_tree.data.notifications[2] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 0, 2)
        job_tree.data.notifications[3] = endpoint.create_job_notifications_info(job_tree.data.jobunitId, job_tree.data.id, 3, 3)

        job_tree.data.file.checkFlg = 0
        job_tree.data.file.compressionFlg = 0
        job_tree.data.file.messageRetry = 10
        job_tree.data.file.processingMethod = 0
        job_tree.data.file.specifyUser = 0

        job_tree.data.waitRule = endpoint.create_waite_rule_info()

        return job_tree

    @staticmethod
    def setInitialValue_refer(endpoint, jobunitId, jobId, jobName, description, ownerRoleId, parent_id, refer_job_id, refer_job_unit_id):
        job_tree = endpoint.create_job_tree_item(jobId, jobunitId, jobName, description, 5, None, True)
        job_tree.data.ownerRoleId = ownerRoleId
        job_tree.data.parentId = parent_id
        job_tree.data.referJobId = refer_job_id
        job_tree.data.referJobUnitId = refer_job_unit_id
        job_tree.data.waitRule = endpoint.create_waite_rule_info()

        return job_tree

    @staticmethod
    def set_schedule(info, name, job_map, schedule_map, cal_id=None, enable=None, params=None):
        ObjectModifier.replace_if_not_none(
            info,
            calendarId = cal_id,
            jobId = job_map['jobId'],
            #jobName = ,
            jobRuntimeParamList = params,
            jobunitId = job_map['jobunitId'],
            name = name,
            #type = 1, #HC
            valid = enable)

        # Set if any in is not None
        tmp = set(schedule_map.values())
        if None in tmp and len(tmp) > 1:
            ObjectModifier.set_attrs(
                info,
                everyXminutes = schedule_map['everyXminutes'],
                fromXminutes = schedule_map['fromXminutes'],
                hour = schedule_map['hour'],
                minute = schedule_map['minute'],
                scheduleType = schedule_map['scheduleType'],
                week = schedule_map['week'])

            ObjectModifier.replace_none_if_empty(info, 'calendarId')
        return info

    @staticmethod
    def set_job_kick(info, name, job_map, params=None):
        ObjectModifier.replace_if_not_none(
            info,
            name = name,
            jobId = job_map['jobId'],
            jobunitId = job_map['jobunitId'],
            jobRuntimeParamList = params)
        return info

    @staticmethod
    def get_job(endpoint, ju_id, job_id):
        job_info = endpoint.create_object('jobInfo')
        job_info.jobunitId = ju_id
        job_info.id = job_id
        job_info.name = ''
        return(endpoint.getJobFull(job_info))

    @staticmethod
    def sortNextJobIds(nextJobsInfos, orderdIdsString):
        if orderdIdsString is None:
            return nextJobsInfos
        ordered = []
        invalid = []
        ids = map(lambda x: x.strip(), orderdIdsString.split(','))
        for id in ids:
            found = filter(lambda x: id == x.nextJobId, nextJobsInfos)
            if len(found) is 1:
                ordered += found
            else:
                invalid.append(id)

        if len(invalid) is not 0:
            ResultPrinter.warning('Invalid next job ids will be omited: ' + ', '.join(invalid))
        if len(ordered) is not len(nextJobsInfos):
            ResultPrinter.failure(Exception('Number of provided valid next job ids does not equal to number of next jobs'))
            sys.exit(1)
        return ordered


class TabInfo(object):

    @staticmethod
    def waitRule(endpoint, waitRule, condition,endCondition,endStatus,endValue,
                objType, objJobId, objValue, objTime, objDec, tobjType, tobjJobId, tobjValue):
        u'''待ち条件タブ変更
        condition:0=AND 1=OR
        endcondition:0=true 1=false
        endStatus:終了状態
            0=正常,1=警告,2=異常
        endValue:終了値
        obj***:登録判定対象の値
        objType: 0=ジョブ終了状態,1=ジョブ終了値,2=時刻
        objDec:add,mod,del
        tobj***:objDecがmod,delのとき変更・削除対象の値
        '''
        i = 0
        j = 0
        objcount = 0
        objTimecount = 0
        if tobjType != '':
            tobjType = int(tobjType)
        if tobjValue != '':
            tobjValue = int(tobjValue)
        if objType != '':
            objType = int(objType)
        if objValue != '':
            objValue = int(objValue)

        if condition != '':
            waitRule.condition = condition
        if endCondition != '':
            waitRule.endCondition = endCondition
        if endStatus != '':
            waitRule.endStatus = endStatus
        if endValue != '':
            waitRule.endValue = endValue

        if objDec == 'ADD':
            if not hasattr(waitRule,'object'):
                setattr(waitRule,'object',[])
            waitRule.object.append(endpoint.create_job_object_info(objType, objJobId, objValue, objTime))

        elif objDec == 'MOD':
            if not hasattr(waitRule,'object'):
                raise ErrorHandler.ObjectNotFoundError('')
            if tobjType == 0 or tobjType == 1:
                for i in waitRule.object:
                    if i.type == tobjType and i.jobId == tobjJobId and i.value == tobjValue:
                        if objJobId != '':
                            i.jobId = objJobId
                        if objType != '':
                            i.type = objType
                        if objValue != '':
                            i.value = objValue
                        if objTime != '':
                            i.time = objTime
                        objcount = objcount + 1
                        break
                if objcount == 0:
                    raise ErrorHandler.ObjectNotFoundError('object not found')

            elif tobjType == 2:
                for i in waitRule.object:
                    if i.type == 2:
                        if objJobId != '':
                            i.jobId = objJobId
                        if objType != '':
                            i.type = objType
                        if objValue != '':
                            i.value = objValue
                        if objTime != '':
                            i.time = objTime
                        objcount = objcount + 1
                        break
                if objcount == 0:
                    raise ErrorHandler.ObjectNotFoundError('object not found')

        elif objDec == 'DEL':
            if not hasattr(waitRule,'object'):
                raise ErrorHandler.ObjectNotFoundError('object not found')

            if tobjType == 0 or tobjType == 0:
                for i in waitRule.object:
                    if i.type == tobjType and i.jobId == tobjJobId and i.value == tobjValue:
                        waitRule.object.remove(i)
                        objcount = objcount + 1
                        break
                if objcount == 0:
                    raise ErrorHandler.ObjectNotFoundError('object not found')
            elif tobjType == 2:
                for i in waitRule.object:
                    if i.type == 2:
                        waitRule.object.remove(i)
                        objcount = objcount + 1
                        break
                if objcount == 0:
                    raise ErrorHandler.ObjectNotFoundError('object not found')
        ##check jobObjectInfo###
        if hasattr(waitRule,'object'):
            for j in waitRule.object:
                if j.type == 2:
                    objTimecount = objTimecount + 1
                    if objTimecount > 1 :
                        raise Exception('Is not possible to specify a time of multiple wait rule')
        return waitRule

    @staticmethod
    def control(waitRule,
                calendar,calendarId,CEndStatus,CEndValue,
                skip,suspend,SEndStatus,SEndValue):
        u'''制御タブ変更
        '''
        if calendar != '':
            waitRule.calendar = int(calendar)
        if CEndStatus != '':
            waitRule.calendarEndStatus = CEndStatus
        if CEndValue != '':
            waitRule.calendarEndValue = CEndValue
        if calendarId != '':
            waitRule.calendarId = calendarId
        if skip != '':
            waitRule.skip = skip
            if skip == 1 and waitRule.suspend == 1:
                waitRule.suspend = 0
        if suspend != '':
            waitRule.suspend = suspend
            if suspend == 1 and waitRule.skip == 1:
                waitRule.skip = 0
        if SEndStatus != '':
            waitRule.skipEndStatus = SEndStatus
        if SEndValue != '':
            waitRule.skipEndValue =  SEndValue
        if waitRule.calendar == 1:
            if not hasattr(waitRule,'calendarId'):
                raise Exception('Please input the calenarId')
            elif len(waitRule.calendarId) == 0:
                raise Exception('Please input the calenarId')
        return waitRule

    @staticmethod
    def start_delay(waitRule,start_delay,start_delay_condition_type,
                    start_delay_notify,start_delay_notify_priority,
                    start_delay_operation,start_delay_operation_end_status,
                    start_delay_operation_end_value,start_delay_operation_type,
                    start_delay_session,start_delay_session_value,
                    start_delay_time,start_delay_time_value):
        u'''開始遅延タブ変更
        '''

        if start_delay != '':
            waitRule.start_delay = start_delay
        if start_delay_condition_type != '':
            waitRule.start_delay_condition_type = start_delay_condition_type
        if start_delay_notify != '':
            waitRule.start_delay_notify = start_delay_notify
        if start_delay_notify_priority != '':
            waitRule.start_delay_notify_priority = start_delay_notify_priority
        if start_delay_operation != '':
            waitRule.start_delay_operation = start_delay_operation
        if start_delay_operation_end_status != '':
            waitRule.start_delay_operation_end_status = start_delay_operation_end_status
        if start_delay_operation_end_value != '':
            waitRule.start_delay_operation_end_value = start_delay_operation_end_value
        if start_delay_operation_type != '':
            waitRule.start_delay_operation_type = start_delay_operation_type
        if start_delay_session != '':
            waitRule.start_delay_session = start_delay_session
        if start_delay_session_value != '':
            waitRule.start_delay_session_value = start_delay_session_value
        if start_delay_time != '':
            waitRule.start_delay_time = start_delay_time
        if start_delay_time_value != '':
            waitRule.start_delay_time_value = start_delay_time_value

        return waitRule

    @staticmethod
    def end_delay(waitRule,end_delay,end_delay_condition_type,
                    end_delay_notify,end_delay_notify_priority,
                    end_delay_job,end_delay_job_value,
                    end_delay_operation,end_delay_operation_end_status,
                    end_delay_operation_end_value,end_delay_operation_type,
                    end_delay_session,end_delay_session_value,
                    end_delay_time,end_delay_time_value):
        u'''終了遅延タブ変更
        '''

        if end_delay != '':
            waitRule.end_delay = end_delay
        if end_delay_condition_type != '':
            waitRule.end_delay_condition_type = end_delay_condition_type
        if end_delay_notify != '':
            waitRule.end_delay_notify = end_delay_notify
        if end_delay_notify_priority != '':
            waitRule.end_delay_notify_priority = end_delay_notify_priority
        if end_delay_job != '':
            waitRule.end_delay_job = end_delay_job
        if end_delay_job_value != '':
            waitRule.end_delay_job_value = end_delay_job_value
        if end_delay_operation != '':
            waitRule.end_delay_operation = end_delay_operation
        if end_delay_operation_end_status != '':
            waitRule.end_delay_operation_end_status = end_delay_operation_end_status
        if end_delay_operation_end_value != '':
            waitRule.end_delay_operation_end_value = end_delay_operation_end_value
        if end_delay_operation_type != '':
            waitRule.end_delay_operation_type = end_delay_operation_type
        if end_delay_session != '':
            waitRule.end_delay_session = end_delay_session
        if end_delay_session_value != '':
            waitRule.end_delay_session_value = end_delay_session_value
        if end_delay_time != '':
            waitRule.end_delay_time = end_delay_time
        if end_delay_time_value != '':
            waitRule.end_delay_time_value = end_delay_time_value

        return waitRule

    @staticmethod
    def endStatus(endStatus,
                  value_normal,startRangeValue_normal,endRangeValue_normal,
                  value_warning,startRangeValue_warning,endRangeValue_warning,
                  value_critical):
        u'''終了状態タブ変更
        type:0=正常,1=警告:2=危険　
        value:終了値
        start - end :終了値の範囲
                  危険は終了値以外変更なし
        '''

        for i in endStatus:
            if i.type == 0:
                if value_normal != '':
                    i.value = int(value_normal)
                if startRangeValue_normal != '':
                    i.startRangeValue = int(startRangeValue_normal)
                if endRangeValue_normal != '':
                    i.endRangeValue = int(endRangeValue_normal)
            elif i.type == 1:
                if value_warning != '':
                    i.value = int(value_warning)
                if startRangeValue_warning != '':
                    i.startRangeValue = int(startRangeValue_warning)
                if endRangeValue_warning != '':
                    i.endRangeValue = int(endRangeValue_warning)

            elif i.type == 2:
                if value_critical != '':
                    i.value = int(value_critical)

        return endStatus

    @staticmethod
    def multiplicity(waitRule,multiplicityEndValue,multiplicityNotify,
                     multiplicityNotifyPriority,multiplicityOperation):
        u'''多重度タブ変更
        '''
        if multiplicityNotify != '':
            waitRule.multiplicityNotify = multiplicityNotify
        if multiplicityNotifyPriority != '':
            waitRule.multiplicityNotifyPriority = multiplicityNotifyPriority
        if multiplicityOperation != '':
            waitRule.multiplicityOperation = multiplicityOperation
        if multiplicityEndValue != '':
            waitRule.multiplicityEndValue = multiplicityEndValue

        return waitRule

    @staticmethod
    def command(command,errorEndFlg,errorEndValue,
                facilityID,messageRetry,processingMethod,
                specifyUser,startCommand,stopCommand,stopType,user):
        u'''コマンドタブ変更
        '''
        if errorEndFlg != '':
            command.errorEndFlg = errorEndFlg
        if errorEndValue != '':
            command.errorEndValue = errorEndValue
        if facilityID != '':
            command.facilityID = facilityID
        if messageRetry != '':
            command.messageRetry = messageRetry
        if processingMethod != '':
            command.processingMethod = int(processingMethod)
        if specifyUser !=  '':
            command.specifyUser =  int(specifyUser)
        if startCommand != '':
            command.startCommand = startCommand
        if stopCommand != '':
            command.stopCommand = stopCommand
        if  stopType != '':
            command.stopType = int(stopType)
        if user != '':
            command.user = user

        return command

    @staticmethod
    def fileTransfer(filet,checkFlg,compressionFlg,
                     destDirectory,destFacilityID,
                     messageRetry,processingMethod,specifyUser,
                     srcFacilityID,srcFile,user):
        u'''ファイル転送タブ変更
        '''

        if checkFlg != '':
            filet.checkFlg = checkFlg
        if compressionFlg != '':
            filet.compressionFlg = compressionFlg
        if destDirectory != '':
            filet.destDirectory = destDirectory
        if destFacilityID != '':
            filet.destFacilityID = destFacilityID
        if messageRetry != '':
            filet.messageRetry = messageRetry
        if processingMethod != '':
            filet.processingMethod = processingMethod
        if specifyUser != '':
            filet.specifyUser = int(specifyUser)
        if srcFacilityID != '':
            filet.srcFacilityID = srcFacilityID
        if srcFile != '':
            filet.srcFile = srcFile
        if user != '':
            filet.user = user

        return filet

    @staticmethod
    def referJob(data,referjobId):
        u'''参照タブ変更
        '''
        if referjobId != '':
            data.referJobId = referjobId
        return data

    @staticmethod
    def set_approval_tab(job_info, role_id, user_id, content, title, body, use_content):
        ObjectModifier.replace_if_not_none(
            job_info,
            approvalReqMailBody = body,
            approvalReqMailTitle = title,
            approvalReqRoleId = role_id,
            approvalReqSentence = content,
            approvalReqUserId = user_id,
            useApprovalReqSentence = use_content)
        return job_info

    @staticmethod
    def set_monitor_tab(job_info, facility_id, method, monitor_id, end_info, end_warn, end_critical, end_unknown, timeout, end_timeout):
        ObjectModifier.replace_if_not_none(
            job_info.monitor,
            facilityID = facility_id,
            monitorId = monitor_id,
            monitorInfoEndValue = end_info,
            monitorWarnEndValue = end_warn,
            monitorCriticalEndValue = end_critical,
            monitorUnknownEndValue = end_unknown,
            monitorWaitTime = timeout,
            monitorWaitEndValue = end_timeout,
            processingMethod = method)

        ObjectModifier.replace_if_none(
            job_info.monitor,
            commandRetry = 10, #HC unused
            commandRetryFlg = False, #HC unused
            scope='')
        return job_info


    @staticmethod
    def set_command_tab(job_info, facility_id, method, distribute, script_name, encoding, script, start_command,
                        stop_type, stop_command, specify_user, user):
        ObjectModifier.replace_if_not_none(
            job_info.command,
            facilityID = facility_id,
            processingMethod = method,
            managerDistribution = distribute,
            scriptContent = script,
            scriptEncoding = encoding,
            scriptName = script_name,
            startCommand = start_command,
            stopType = stop_type,
            stopCommand = stop_command,
            specifyUser = specify_user,
            #envVariableInfo[] = <empty>,
            #jobCommandParamList[] = <empty>,
            user = user)
        #messageRetry = 11    in Node tab
        #messageRetryEndFlg = True    in Node tab
        #messageRetryEndValue = -11    in Node tab
        #commandRetry = 10, in Node tab
        #commandRetryFlg = False, in Node tab

        ObjectModifier.replace_if_none(
            job_info.command,
            scriptEncoding = 'UTF-8',
            commandRetry = 10, #HC default value
            commandRetryFlg = False,
            scope='')
        return job_info



class Tree(object):

    _jobdata_info = None
    _search_id = None
    _data = None

    u'''ジョブツリーを探索    '''
    def __init__(self, jobdata_info, search_id, data=0):
        self._jobdata_info = jobdata_info
        self._search_id = search_id
        self._data = data

    def modify_data(self, my_list):
        if 'data' in my_list:
            if my_list.data.id == self._search_id:
                my_list.data = self._jobdata_info
                return my_list

        if 'children' in my_list:
            self.children(my_list.children, 0)
        return my_list

    def register_data(self, tree):
        if 'data' in tree:
            if tree.data.id == self._search_id:
                if not hasattr(tree,'children'):
                    tree['children'] = []

                tree.children.append(self._jobdata_info)
                return tree

        if 'children' in tree:
            self.children(tree.children, 1)
        return tree

    def getjobdata(self, job_tree):
        if 'data' in job_tree:
            if job_tree.data.id == self._search_id:
                self._data = job_tree.data
        if 'children' in job_tree:
            self.children(job_tree.children, 2)
        return self._data

    def children(self, my_list, flg):
        for i in my_list:
            if flg == 0:
                i = self.modify_data(i)
            if flg == 1:
                i = self.register_data(i)
            if flg == 2:
                self.getjobdata(i)
        return my_list

class JobTree(object):
    @staticmethod
    def add_parent_ids(job_tree, jobunit_id=None, parent_id=None):
        if 'data' in job_tree:
            if job_tree.data.id is not None and job_tree.data.jobunitId is not None:
                if parent_id is None:
                    setattr(job_tree.data, 'parentId', 'TOP')
                    setattr(job_tree.data, 'parentJobunitId', 'ROOT')
                else:
                    setattr(job_tree.data, 'parentId', parent_id)
                    setattr(job_tree.data, 'parentJobunitId', jobunit_id)

                jobunit_id = job_tree.data.jobunitId
                parent_id = job_tree.data.id

        if 'children' in job_tree:
            for a in job_tree.children:
                JobTree.add_parent_ids(a, jobunit_id, parent_id)

    _data_list = []

    def __init__(self, data_list):
        self._data_list = data_list

    def getdata(self, job_tree, parent_id):
        if 'data' in job_tree:
            if job_tree.data.type != -1: # HC
                job_tree.data.parentId = parent_id
                self._data_list.append(job_tree.data)

        if 'children' in job_tree:
            if hasattr(job_tree,'data'):
                parentId = job_tree.data.id
                self.children(job_tree.children,parentId)
            else:
                self.children(job_tree.children,'')

        return self._data_list

    def children(self,List,parentId):
        for i in List:
            self.getdata(i,parentId)
