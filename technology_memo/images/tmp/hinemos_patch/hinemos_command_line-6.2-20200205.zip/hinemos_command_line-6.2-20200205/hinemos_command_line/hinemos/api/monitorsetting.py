#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
from hinemos.api.endpoint import Endpoint
from hinemos.api.binary import BinaryEndpoint
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.modifier import ObjectModifier
from hinemos.util.api import *
from hinemos.util.notify import NotifyUtil
from hinemos.util.monitorsetting import MonitorSettingUtil

# HC for Utility data consistence


def formatted_info(info):
    if 'trapCheckInfo' in info and info.trapCheckInfo is not None:
        # if 1 == int(info.trapCheckInfo.communityCheck) and '' == info.trapCheckInfo.communityName:
        if 'communityName' in info.trapCheckInfo and '' == info.trapCheckInfo.communityName:
            info.trapCheckInfo.communityName = None
        if 'trapValueInfos' in info.trapCheckInfo and info.trapCheckInfo.trapValueInfos is not None:
            for subinfo in info.trapCheckInfo.trapValueInfos:
                if 'formatVarBinds' in subinfo and '' == subinfo.formatVarBinds:
                    subinfo.formatVarBinds = None
                if 'varBindPatterns' in subinfo and subinfo.varBindPatterns is not None:
                    for subsubinfo in subinfo.varBindPatterns:
                        if 'description' in subsubinfo and '' == subsubinfo.description:
                            subsubinfo.description = None

    if 'customCheckInfo' in info and info.customCheckInfo is not None:
        if 'selectedFacilityId' in info.customCheckInfo and '' == info.customCheckInfo.selectedFacilityId:
            info.customCheckInfo.selectedFacilityId = None
        if 'convertFlg' in info.customCheckInfo and ('' == info.customCheckInfo.convertFlg or info.customCheckInfo.convertFlg is None):
            info.customCheckInfo.convertFlg = 0
        # TODO find out the cause
        if 'effectiveUser' in info.customCheckInfo and info.customCheckInfo.effectiveUser is None:
            info.customCheckInfo.effectiveUser = ''

    if 'customTrapCheckInfo' in info and info.customTrapCheckInfo is not None:
        if 'convertFlg' in info.customTrapCheckInfo and ('' == info.customTrapCheckInfo.convertFlg or info.customTrapCheckInfo.convertFlg is None):
            info.customTrapCheckInfo.convertFlg = 0

    if 'httpCheckInfo' in info and info.httpCheckInfo is not None:
        if 'proxyHost' in info.httpCheckInfo and '' == info.httpCheckInfo.proxyHost:
            info.httpCheckInfo.proxyHost = None

    if 'httpScenarioCheckInfo' in info and info.httpScenarioCheckInfo is not None:
        if 'authUser' in info.httpScenarioCheckInfo and '' == info.httpScenarioCheckInfo.authUser:
            info.httpScenarioCheckInfo.authUser = None
        if 'authPassword' in info.httpScenarioCheckInfo and '' == info.httpScenarioCheckInfo.authPassword:
            info.httpScenarioCheckInfo.authPassword = None
        if 'authType' in info.httpScenarioCheckInfo and '' == info.httpScenarioCheckInfo.authType:
            info.httpScenarioCheckInfo.authType = None

        if 'pages' in info.httpScenarioCheckInfo and info.httpScenarioCheckInfo.pages is not None:
            for subinfo in info.httpScenarioCheckInfo.pages:
                if 'patterns' in subinfo and subinfo.patterns is not None:
                    for subsubinfo in subinfo.patterns:
                        if 'description' in subsubinfo and '' == subsubinfo.description:
                            subsubinfo.description = None

    if 'stringValueInfo' in info and info.stringValueInfo is not None:
        for subinfo in info.stringValueInfo:
            if 'description' in subinfo and '' == subinfo.description:
                subinfo.description = None

    if 'description' in info and '' == info.description:
        info.description = None

    if 'application' in info and '' == info.application:
        info.application = None

    if 'itemName' in info and '' == info.itemName:
        info.itemName = None
    if 'measure' in info and '' == info.measure:
        info.measure = None

    # FIXME HC:
    if 'numericValueInfo' in info and info.numericValueInfo:
        for subinfo in info.numericValueInfo:
            if subinfo.monitorNumericType is None:
                subinfo.monitorNumericType = ''
    if 'perfCheckInfo' in info and info.perfCheckInfo:
        if info.perfCheckInfo.deviceDisplayName is None:
            info.perfCheckInfo.deviceDisplayName = ''

    return info


class MonitorSettingEndpoint(Endpoint):

    mon_type_id2name = {
        'MON_SYSLOG_S': 'System Log Monitor (String)',
        'MON_WINEVENT_S': 'Windows Event Monitor (String)',
        'MON_LOGFILE_S': 'Logfile Monitor (String)',
        'MON_SNMP_TRP': 'SNMPTRAP Monitor (Trap)',
        'MON_WINSERVICE_B': 'Windows Service Monitor (True or False)',
        'MON_PNG_N': 'Ping Monitor (Numeric)',
        'MON_PRT_N': 'Service Port Monitor (Numeric)',
        'MON_PRC_N': 'Process Monitor (Numeric)',
        'MON_SNMP_N': 'SNMP Monitor (Numeric)',
        'MON_SNMP_S': 'SNMP Monitor (String)',
        'MON_SQL_N': 'SQL Monitor (Numeric)',
        'MON_SQL_S': 'SQL Monitor (String)',
        'MON_PRF_N': 'Resource Monitor (Numeric)',
        'MON_JMX_N': 'JMX Monitor (Numeric)',
        'MON_HTP_SCE': 'HTTP Monitor (Scenario)',
        'MON_HTP_N': 'HTTP Monitor (Numeric)',
        'MON_HTP_S': 'HTTP Monitor (String)',
        'MON_CUSTOMTRAP_N': 'Custom Trap Monitor (Numeric)',
        'MON_CUSTOMTRAP_S': 'Custom Trap Monitor (String)',
        'MON_CUSTOM_N': 'Custom Monitor (Numeric)',
        'MON_CUSTOM_S': 'Custom Monitor (String)',
        'MON_AGT_B': 'Hinemos Agent Monitor (True or False)'
    }

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(
            hm_url, user, passwd, 'MonitorSetting')

    # 監視設定一覧の取得
    def getMonitorList(self):
        try:
            return self._client.service.getMonitorList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getMonitorList failed, ' + str(e))
            raise ErrorHandler.APIError('getMonitorList failed, ' + str(e))

    # 監視設定一覧の取得
    def getMonitorListByCondition(self, monitorFilterInfo):
        try:
            return self._client.service.getMonitorListByCondition(monitorFilterInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getMonitorListByCondition failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getMonitorListByCondition failed, ' + str(e))

    # 監視設定情報をマネージャに登録します。
    def addMonitor(self, info):
        mon_name = self.get_monitor_name(info.monitorTypeId)
        info = formatted_info(info)
        try:
            res = self._client.service.addMonitor(info)
            return res
        except Exception, e:
            if "need-role" in str(e):
                raise ErrorHandler.PermissoinError(
                    'adding monitor "' + mon_name + '" failed, ' + str(e))
            raise ErrorHandler.APIError(
                'adding monitor "' + mon_name + '" failed, ' + str(e))

    # 監視設定情報を更新します。
    def modifyMonitor(self, monitorInfo):
        monitorInfo = formatted_info(monitorInfo)
        try:
            return self._client.service.modifyMonitor(monitorInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'modifyMonitor failed, ' + str(e))
            raise ErrorHandler.APIError('modifyMonitor failed, ' + str(e))

    # 監視設定情報をマネージャから削除します。
    def deleteMonitor(self, monitorIdList):
        try:
            return self._client.service.deleteMonitor(monitorIdList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'deleteMonitor failed, ' + str(e))
            raise ErrorHandler.APIError('deleteMonitor failed, ' + str(e))

    # 監視設定情報を取得します。
    def getMonitor(self, monitorId):
        if monitorId is None:
            for info in self.getMonitorList():
                if monitorId == info.monitorId:
                    break
            else:
                raise ErrorHandler.ObjectNotFoundError(
                    'MonitorSetting %s of type  does not exist!' % (monitorId))
        try:
            res = self._client.service.getMonitor(monitorId)
            return res
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getMonitor failed, ' + str(e))
            raise ErrorHandler.APIError('getMonitor failed, ' + str(e))

    # 監視設定の監視を有効化/無効化します。
    def setStatusMonitor(self, monitorId, monitorTypeId, validFlag):
        try:
            return self._client.service.setStatusMonitor(monitorId, monitorTypeId, validFlag)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'setStatusMonitor failed, ' + str(e))
            raise ErrorHandler.APIError('setStatusMonitor failed, ' + str(e))

    # 監視設定の収集を有効化/無効化します。
    def setStatusCollector(self, monitorId, monitorTypeId, validFlag):
        try:
            ### method edit###
            self._client.service.setStatusCollector(
                monitorId, monitorTypeId, validFlag)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'setStatusCollector failed, ' + str(e))
            raise ErrorHandler.APIError('setStatusCollector failed, ' + str(e))


    # JDBC定義一覧をリストで返却します。
    def getJdbcDriverList(self):
        try:
            return self._client.service.getJdbcDriverList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJdbcDriverList failed, ' + str(e))
            raise ErrorHandler.APIError('getJdbcDriverList failed, ' + str(e))

    # JDBC定義一覧をリストで返却します。
    def getJdbcDriverList(self):
        try:
            return self._client.service.getJdbcDriverList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJdbcDriverList failed, ' + str(e))
            raise ErrorHandler.APIError('getJdbcDriverList failed, ' + str(e))

    # Hinemosエージェント監視設定一覧の取得
    def getAgentList(self):
        try:
            return self._client.service.getAgentList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getAgentList failed, ' + str(e))
            raise ErrorHandler.APIError('getAgentList failed, ' + str(e))

    # HTTP監視設定一覧の取得
    def getHttpList(self):
        try:
            return self._client.service.getHttpList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getHttpList failed, ' + str(e))
            raise ErrorHandler.APIError('getHttpList failed, ' + str(e))

    # JMX監視設定一覧の取得
    def getJmxList(self):
        try:
            return self._client.service.getJmxList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJmxList failed, ' + str(e))
            raise ErrorHandler.APIError('getJmxList failed, ' + str(e))

    # ログファイル監視設定一覧の取得
    def getLogfileList(self):
        try:
            return self._client.service.getLogfileList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getLogfileList failed, ' + str(e))
            raise ErrorHandler.APIError('getLogfileList failed, ' + str(e))

    # リソース監視設定一覧の取得
    def getPerformanceList(self):
        try:
            return self._client.service.getPerformanceList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getPerformanceList failed, ' + str(e))
            raise ErrorHandler.APIError('getPerformanceList failed, ' + str(e))

    # Ping監視設定一覧の取得
    def getPingList(self):
        try:
            return self._client.service.getPingList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getPingList failed, ' + str(e))
            raise ErrorHandler.APIError('getPingList failed, ' + str(e))

    # ポート監視設定一覧の取得
    def getPortList(self):
        try:
            return self._client.service.getPortList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getPortList failed, ' + str(e))
            raise ErrorHandler.APIError('getPortList failed, ' + str(e))

    # プロセス監視設定一覧の取得
    def getProcessList(self):
        try:
            return self._client.service.getProcessList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getProcessList failed, ' + str(e))
            raise ErrorHandler.APIError('getProcessList failed, ' + str(e))

    # SNMPトラップ監視設定一覧の取得
    def getTrapList(self):
        try:
            return self._client.service.getTrapList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getTrapList failed, ' + str(e))
            raise ErrorHandler.APIError('getTrapList failed, ' + str(e))

    # SNMP監視設定一覧の取得
    def getSnmpList(self):
        try:
            return self._client.service.getSnmpList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getSnmpList failed, ' + str(e))
            raise ErrorHandler.APIError('getSnmpList failed, ' + str(e))

    # SQL監視設定一覧の取得
    def getSqlList(self):
        try:
            return self._client.service.getSqlList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getSqlList failed, ' + str(e))
            raise ErrorHandler.APIError('getSqlList failed, ' + str(e))

    # システムログ監視設定一覧の取得
    def getSystemlogList(self):
        try:
            return self._client.service.getSystemlogList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getSystemlogList failed, ' + str(e))
            raise ErrorHandler.APIError('getSystemlogList failed, ' + str(e))

    # コマンド監視設定一覧の取得
    def getCustomList(self):
        try:
            return self._client.service.getCustomList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getCustomList failed, ' + str(e))
            raise ErrorHandler.APIError('getCustomList failed, ' + str(e))

    # カスタムトラップ監視設定一覧の取得
    def getCustomTrapList(self):
        try:
            return self._client.service.getCustomTrapList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getCustomTrapList failed, ' + str(e))
            raise ErrorHandler.APIError('getCustomTrapList failed, ' + str(e))

    # Windowsサービス監視設定一覧の取得
    def getWinServiceList(self):
        try:
            return self._client.service.getWinServiceList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getWinServiceList failed, ' + str(e))
            raise ErrorHandler.APIError('getWinServiceList failed, ' + str(e))

    # Windowsイベント監視設定一覧の取得
    def getWinEventList(self):
        try:
            return self._client.service.getWinEventList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getWinEventList failed, ' + str(e))
            raise ErrorHandler.APIError('getWinEventList failed, ' + str(e))

    # 収集項目コードの一覧を取得します
    def getItemCodeMap(self):
        try:
            return self._client.service.getItemCodeMap()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getItemCodeMap failed, ' + str(e))
            raise ErrorHandler.APIError('getItemCodeMap failed, ' + str(e))

    # 指定のファシリティで収集可能な項目のリストを返します
    def getAvailableCollectorItemList(self, facilityId):
        try:
            return self._client.service.getAvailableCollectorItemList(facilityId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getAvailableCollectorItemList failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getAvailableCollectorItemList failed, ' + str(e))

    def slim_monitor_info(self, info):
            # TODO check
        del info.pluginCheckInfo

        # if not info.monitorTypeId =='MON_SYSLOG_S': # TODO
        # if not info.monitorTypeId =='MON_AGT_': # TODO

        if not info.monitorTypeId == 'MON_WINEVENT_S':
            del info.winEventCheckInfo
        if not info.monitorTypeId == 'MON_LOGFILE_S':
            del info.logfileCheckInfo
        if not info.monitorTypeId == 'MON_SNMP_TRP':
            del info.trapCheckInfo
        if not info.monitorTypeId == 'MON_WINSERVICE_B':
            del info.winServiceCheckInfo

        if not info.monitorTypeId == 'MON_PNG_N':
            del info.pingCheckInfo
        if not info.monitorTypeId == 'MON_PRT_N':
            del info.portCheckInfo
        if not info.monitorTypeId == 'MON_PRC_N':
            del info.processCheckInfo
        if not info.monitorTypeId == 'MON_SNMP_N' and not info.monitorTypeId == 'MON_SNMP_S':
            del info.snmpCheckInfo
        if not info.monitorTypeId == 'MON_SQL_N' and not info.monitorTypeId == 'MON_SQL_S':
            del info.sqlCheckInfo
        if not info.monitorTypeId == 'MON_PRF_N':
            del info.perfCheckInfo
        if not info.monitorTypeId == 'MON_JMX_N':
            del info.jmxCheckInfo
        if not info.monitorTypeId == 'MON_HTP_SCE':
            del info.httpScenarioCheckInfo
        if not info.monitorTypeId == 'MON_HTP_N' and not info.monitorTypeId == 'MON_HTP_S':
            del info.httpCheckInfo
        if not info.monitorTypeId == 'MON_CUSTOMTRAP_N' and not info.monitorTypeId == 'MON_CUSTOMTRAP_S':
            del info.customTrapCheckInfo
        if not info.monitorTypeId == 'MON_CUSTOM_N' and not info.monitorTypeId == 'MON_CUSTOM_S':
            del info.customCheckInfo

        if not info.monitorTypeId.endswith('_S'):
            del info.stringValueInfo
        if not info.monitorTypeId.endswith('_N'):
            del info.numericValueInfo
        if not info.monitorTypeId.endswith('_B'):
            del info.truthValueInfo

        return(info)

    def add_monitor_agent(self, monitor_id, facility_id, run_interval,
                          calendar_id, application, description, owner_role_id,
                          monitor_flg, notify_infos, priority_ok, priority_ng):

        monitor_info = self.create_monitor_info_boolean('MON_AGT_B',
                                                        monitor_id,
                                                        facility_id,
                                                        run_interval,
                                                        calendar_id,
                                                        application,
                                                        description,
                                                        owner_role_id,
                                                        monitor_flg,
                                                        notify_infos,
                                                        priority_ok,
                                                        priority_ng)

        self.addMonitor(monitor_info)

    def add_monitor_win_service(self, monitor_id, facility_id, run_interval,
                                calendar_id, application, service_name,
                                description, owner_role_id, monitor_flg,
                                notify_infos, priority_ok, priority_ng):

        monitor_type_id = 'MON_WINSERVICE_B'
        monitor_info = self.create_monitor_info_boolean(monitor_type_id,
                                                        monitor_id,
                                                        facility_id,
                                                        run_interval,
                                                        calendar_id,
                                                        application,
                                                        description,
                                                        owner_role_id,
                                                        monitor_flg,
                                                        notify_infos,
                                                        priority_ok,
                                                        priority_ng)

        monitor_info.winServiceCheckInfo = self.create_check_winservice({
            'monitor_id': monitor_id,
            'monitor_type_id': monitor_type_id,
            'service_name': service_name
        })

        self.addMonitor(monitor_info)

    def add_monitor_trap(self, monitor_id, facility_id, calendar_id,
                         application, description, owner_role_id, monitor_flg,
                         notify_infos, community_check, community_name,
                         charset_convert, charset_name,
                         notifyof_receiving_unspecified_flg,
                         priority_unspecified, trap_value_infos,
                         collector_flg, logformat_id):

        monitor_type_id = 'MON_SNMP_TRP'

        monitor_info = self.create_monitor_info_trap(monitor_type_id,
                                                     monitor_id, facility_id,
                                                     calendar_id,
                                                     application,
                                                     description,
                                                     owner_role_id,
                                                     monitor_flg,
                                                     notify_infos,
                                                     collector_flg,
                                                     logformat_id,
                                                     community_check,
                                                     community_name,
                                                     charset_convert,
                                                     charset_name,
                                                     notifyof_receiving_unspecified_flg,
                                                     priority_unspecified,
                                                     trap_value_infos)

        self.addMonitor(monitor_info)

    def add_monitor_custom_n(self, args):
        # Default
        defaults = {
            'run_user': '',
            'specify_user_converted': 0,
            'timeout': 15000,
            'selected_facility_id': '',
            'info_lower_threshold': 0.0,
            'info_upper_threshold': 0.0,
            'warn_lower_threshold': 0.0,
            'warn_upper_threshold': 0.0,
            'item_name': u'取得値',
            'unit': u'収集値単位',
            'command_exec_type': 'INDIVIDUAL',
            'convert_flg': 0,
            'monitor_type_id': 'MON_CUSTOM_N',
            'monitor': True,
            'change_info_lower_threshold': -1,
            'change_info_upper_threshold': 1,
            'change_warn_lower_threshold': -2,
            'change_warn_upper_threshold': 2,
        }
        args, monitor_info = self.prepare_numeric_monitor(args, defaults)

        if args.get('command_exec_type') == '':
            args['command_exec_type'] = 'INDIVIDUAL'
        if args.get('convert_flg') == '':
            args['convert_flg'] = 0

        monitor_info.customCheckInfo = self.create_check_custom(args)
        self.addMonitor(monitor_info)

    def add_monitor_custom_s(self, monitor_id, facility_id, run_interval,
                             calendar_id, application, command, description,
                             owner_role_id, monitor_flg, notify_infos,
                             collector_flg, logformat_id, selected_facility_id,
                             timeout, command_exec_type, specify_user,
                             effective_user, string_value_infos):
        # Default
        if timeout is None:
            timeout = 15000
        if command_exec_type is None or command_exec_type == '':
            command_exec_type = 'INDIVIDUAL'
        if specify_user is None or specify_user == '':
            specify_user = False
        if effective_user is None:
            effective_user = ''
        if selected_facility_id is None:
            selected_facility_id = ''

        monitor_type_id = 'MON_CUSTOM_S'

        monitor_info = self.create_monitor_info_string(monitor_type_id,
                                                       monitor_id,
                                                       facility_id, run_interval,
                                                       calendar_id,
                                                       application,
                                                       description,
                                                       owner_role_id,
                                                       monitor_flg,
                                                       collector_flg,
                                                       logformat_id,
                                                       notify_infos,
                                                       string_value_infos)

        monitor_info.customCheckInfo = self.create_check_custom()
        monitor_info.customCheckInfo.monitorId = monitor_id
        monitor_info.customCheckInfo.command = command
        monitor_info.customCheckInfo.commandExecType = command_exec_type
        monitor_info.customCheckInfo.selectedFacilityId = selected_facility_id
        monitor_info.customCheckInfo.effectiveUser = effective_user
        monitor_info.customCheckInfo.specifyUser = specify_user
        monitor_info.customCheckInfo.timeout = timeout

        self.addMonitor(monitor_info)

    def add_monitor_customtrap_n(self, args):
        # Default
        defaults = {
            'info_lower_threshold': 0.0,
            'info_upper_threshold': 0.0,
            'warn_lower_threshold': 0.0,
            'warn_upper_threshold': 0.0,
            'item_name': u'取得値',
            'unit': u'収集値単位',
            'monitor_type_id': 'MON_CUSTOMTRAP_N',
            'run_interval': 0,
            'change_info_lower_threshold': -1,
            'change_info_upper_threshold': 1,
            'change_warn_lower_threshold': -2,
            'change_warn_upper_threshold': 2,
        }
        args, monitor_info = self.prepare_numeric_monitor(args, defaults)

        if args.get('convert_flg') == '':
            args['convert_flg'] = 0

        monitor_info.customTrapCheckInfo = self.create_check_custom_trap(args)
        self.addMonitor(monitor_info)

    def add_monitor_customtrap_s(self, monitor_id, facility_id, calendar_id,
                                 application, description, owner_role_id,
                                 monitor_flg, notify_infos, collector_flg,
                                 logformat_id, key_pattern, string_value_infos):

        monitor_type_id = 'MON_CUSTOMTRAP_S'
        run_interval = 0
        monitor_info = self.create_monitor_info_string(monitor_type_id,
                                                       monitor_id,
                                                       facility_id,
                                                       run_interval,
                                                       calendar_id,
                                                       application,
                                                       description,
                                                       owner_role_id,
                                                       monitor_flg,
                                                       collector_flg,
                                                       logformat_id,
                                                       notify_infos,
                                                       string_value_infos)

        monitor_info.customTrapCheckInfo = self.create_check_custom_trap({
            'monitor_id': monitor_id,
            'key_pattern': key_pattern
        })
        self.addMonitor(monitor_info)

    def add_monitor_http_n(self, args):
        # Default
        defaults = {
            'timeout': 5000,
            'selected_facility_id': '',
            'info_lower_threshold': 0.0,
            'info_upper_threshold': 1000.0,
            'warn_lower_threshold': 1000.0,
            'warn_upper_threshold': 3000.0,
            'item_name': u'応答時間',
            'unit': 'msec',
            'monitor_type_id': 'MON_HTP_N',
            'monitor': True,
            'change_info_lower_threshold': -1,
            'change_info_upper_threshold': 1,
            'change_warn_lower_threshold': -2,
            'change_warn_upper_threshold': 2,
        }
        args, monitor_info = self.prepare_numeric_monitor(args, defaults)

        monitor_info.httpCheckInfo = self.create_check_http(args)
        self.addMonitor(monitor_info)

    def add_monitor_http_s(self, monitor_id, facility_id, run_interval,
                           calendar_id, application, request_url,
                           description, owner_role_id, monitor_flg,
                           notify_infos, timeout, string_value_infos,
                           collector_flg, logformat_id):
        # Default
        if timeout is None:
            timeout = 5000

        monitor_type_id = 'MON_HTP_S'

        monitor_info = self.create_monitor_info_string(monitor_type_id,
                                                       monitor_id,
                                                       facility_id,
                                                       run_interval,
                                                       calendar_id,
                                                       application,
                                                       description,
                                                       owner_role_id,
                                                       monitor_flg,
                                                       collector_flg,
                                                       logformat_id,
                                                       notify_infos,
                                                       string_value_infos)

        monitor_info.httpCheckInfo = self.create_check_http({
            'monitor_id': monitor_id,
            'request_url': request_url,
            'timeout': timeout
        })
        self.addMonitor(monitor_info)

    def add_monitor_http_sce(self, monitor_id, facility_id, run_interval,
                             calendar_id, application, pages, description,
                             owner_role_id, monitor_flg, notify_infos,
                             collector_flg, item_name, measure, auth_type,
                             auth_user, auth_password, proxy_flg, proxy_url,
                             proxy_port=None, proxy_user=None,
                             proxy_password=None, monitoring_per_page_flg=None,
                             user_agent=None, connect_timeout=None,
                             request_timeout=None):
        # Default
        if item_name is None:
            item_name = u'応答時間'
        if measure is None:
            measure = 'msec'

        if proxy_flg is None:
            proxy_flg = False
        if proxy_url is None:
            proxy_url = 'http://'
        if proxy_port is None:
            proxy_port = 8080
        if proxy_user is None:
            proxy_user = ''
        if proxy_password is None:
            proxy_password = ''
        if monitoring_per_page_flg is None:
            monitoring_per_page_flg = False
        if user_agent is None:
            user_agent = "Internet Explorer 11.0"
        if connect_timeout is None:
            connect_timeout = 5000
        if request_timeout is None:
            request_timeout = 5000
        if auth_type == '':  # special-case
            auth_type = None
        if auth_user is None:
            auth_user = ''
        if auth_password is None:
            auth_password = ''
        if auth_type:
            assert auth_user, 'auth_user is required!'
            assert auth_password, 'auth_user is required!'
        if proxy_flg is True:
            assert proxy_url is not None and proxy_url != 'http://', 'proxy_url is required!'
            assert proxy_port, 'proxy_port is required!'
        assert pages, 'at least 1 page is required!'

        monitor_type_id = 'MON_HTP_SCE'

        monitor_info = self.create_monitor_info_basic(4,
                                                      monitor_type_id,
                                                      monitor_id,
                                                      facility_id,
                                                      run_interval,
                                                      calendar_id,
                                                      application,
                                                      description,
                                                      owner_role_id,
                                                      monitor_flg,
                                                      notify_infos,
                                                      collector_flg)
        monitor_info.itemName = item_name
        monitor_info.measure = measure

        monitor_info.httpScenarioCheckInfo = self.create_check_http_scenario({
            'monitor_id': monitor_id,
            'monitor_type_id': monitor_type_id,
            'auth_type': auth_type,
            'auth_user': auth_user,
            'auth_password': auth_password,
            'connect_timeout': connect_timeout,
            'monitoring_per_page_flg': monitoring_per_page_flg,
            'pages': pages,
            'proxy_flg': proxy_flg,
            'proxy_password': proxy_password,
            'proxy_port': proxy_port,
            'proxy_url': proxy_url,
            'proxy_user': proxy_user,
            'request_timeout': request_timeout,
            'user_agent': user_agent
        })
        monitor_info.changeFlg = False
        monitor_info.predictionFlg = False
        self.addMonitor(monitor_info)

    def add_monitor_jmx(self, args):
        # Default
        defaults = {
            'info_lower_threshold': 0.0,
            'info_upper_threshold': 0.0,
            'warn_lower_threshold': 0.0,
            'warn_upper_threshold': 0.0,
            'item_name': u'取得値',
            'unit': u'収集値単位',
            'convert_flg': 0,
            'monitor_type_id': 'MON_JMX_N',
            'monitor': True,
            'change_info_lower_threshold': -1,
            'change_info_upper_threshold': 1,
            'change_warn_lower_threshold': -2,
            'change_warn_upper_threshold': 2,
        }
        args, monitor_info = self.prepare_numeric_monitor(args, defaults)

        for x in args['jmx_master_info_list']:
            if x.id == args['master_id']:
                args['item_name'] = x.name
                args['unit'] = x.measure
                break
        if args.get('convert_flg') == '':
            args['convert_flg'] = 0

        monitor_info.jmxCheckInfo = self.create_check_jmx(args)
        self.addMonitor(monitor_info)

    def add_monitor_pref(self, args):
        # Default
        defaults = {
            'collect_breakdown_detail': 0,
            'item_code_dev': '',
            'info_lower_threshold': 0.0,
            'info_upper_threshold': 0.0,
            'warn_lower_threshold': 0.0,
            'warn_upper_threshold': 0.0,
            'item_name':  u'取得値',
            'unit': u'収集値単位',
            'monitor_type_id': 'MON_PRF_N',
            'monitor': True,
            'change_info_lower_threshold': -1,
            'change_info_upper_threshold': 1,
            'change_warn_lower_threshold': -2,
            'change_warn_upper_threshold': 2,
        }
        args, monitor_info = self.prepare_numeric_monitor(args, defaults)

        for x in args['item_code_mst_data_list']:
            if x.itemCode == args['item_code']:
                args['item_name'] = x.itemName
                args['unit'] = x.measure
                break

        monitor_info.perfCheckInfo = self.create_check_pref(args)
        self.addMonitor(monitor_info)

    def add_monitor_syslog(self, monitor_id, facility_id, application,
                           string_value_infos, collector_flg, logformat_id,
                           description=None, calendar_id=None,
                           owner_role_id=None, monitor_flg=None,
                           notify_infos=None):
        # Default
        monitor_type_id = 'MON_SYSLOG_S'
        monitor_info = self.create_monitor_info_string(monitor_type_id,
                                                       monitor_id,
                                                       facility_id,
                                                       None,
                                                       calendar_id,
                                                       application,
                                                       description,
                                                       owner_role_id,
                                                       monitor_flg,
                                                       collector_flg,
                                                       logformat_id,
                                                       notify_infos,
                                                       string_value_infos)
        self.addMonitor(monitor_info)

    def add_monitor_winevent(self, monitor_id, facility_id, application,
                             string_value_infos, collector_flg, logformat_id,
                             log_names=[], sources=[], event_ids=[],
                             categories=[], keywords=[], description=None,
                             calendar_id=None, owner_role_id=None,
                             monitor_flg=None, notify_infos=None,
                             level_verbose=None, level_informational=None,
                             level_warning=None, level_critical=None,
                             level_error=None):
        # Default
        if level_verbose is None:
            level_verbose = False
        if level_informational is None:
            level_informational = False
        if level_warning is None:
            level_warning = True
        if level_critical is None:
            level_critical = True
        if level_error is None:
            level_error = True
        if not log_names:
            log_names = ['Application', 'System']
        if sources is None:
            sources = []
        if event_ids is None:
            event_ids = []
        if categories is None:
            categories = []
        if keywords is None:
            keywords = []

        monitor_type_id = 'MON_WINEVENT_S'
        monitor_info = self.create_monitor_info_string(monitor_type_id,
                                                       monitor_id,
                                                       facility_id,
                                                       None,
                                                       calendar_id,
                                                       application,
                                                       description,
                                                       owner_role_id,
                                                       monitor_flg,
                                                       collector_flg,
                                                       logformat_id,
                                                       notify_infos,
                                                       string_value_infos)

        monitor_info.winEventCheckInfo = self.create_check_winevent({
            'monitor_id': monitor_id,
            'monitor_type_id': monitor_type_id,
            'level_verbose': level_verbose,
            'level_informational': level_informational,
            'level_warning': level_warning,
            'level_critical': level_critical,
            'level_error': level_error,
            'log_names': log_names,
            'sources': sources,
            'event_ids': event_ids,
            'categories': categories,
            'keywords': keywords
        })
        self.addMonitor(monitor_info)

    def add_monitor_sql_s(self, monitor_id, facility_id, application,
                          string_value_infos, connection_url, jdbc_driver,
                          user, password, query, collector_flg, logformat_id,
                          run_interval=None, description=None, calendar_id=None,
                          owner_role_id=None, monitor_flg=None,
                          notify_infos=None):
        # Validate
        assert connection_url or connection_url == 'jdbc:'
        assert jdbc_driver
        assert user
        assert password
        assert query

        monitor_type_id = 'MON_SQL_S'
        monitor_info = self.create_monitor_info_string(monitor_type_id,
                                                       monitor_id,
                                                       facility_id,
                                                       run_interval,
                                                       calendar_id,
                                                       application,
                                                       description,
                                                       owner_role_id,
                                                       monitor_flg,
                                                       collector_flg,
                                                       logformat_id,
                                                       notify_infos,
                                                       string_value_infos)

        jdbc_driver_list = self._client.service.getJdbcDriverList()
        for i in jdbc_driver_list:
            if i.jdbcDriverName == jdbc_driver:
                jdbc_driver = i.jdbcDriverClass

        monitor_info.sqlCheckInfo = self.create_check_sql()
        ObjectModifier.replace_if_not_none(monitor_info.sqlCheckInfo,
                                           monitorId=monitor_id,
                                           monitorTypeId=monitor_type_id,
                                           connectionUrl=connection_url,
                                           jdbcDriver=jdbc_driver,
                                           user=user,
                                           password=password,
                                           query=query)
        self.addMonitor(monitor_info)

    def add_monitor_sql_n(self, args):
        # Default
        defaults = {
            'info_lower_threshold': 0.0,
            'info_upper_threshold': 0.0,
            'warn_lower_threshold': 0.0,
            'warn_upper_threshold': 0.0,
            'item_name': u'取得値',
            'unit': u'収集値単位',
            'monitor_type_id': 'MON_SQL_N',
            'monitor': True,
            'change_info_lower_threshold': -1,
            'change_info_upper_threshold': 1,
            'change_warn_lower_threshold': -2,
            'change_warn_upper_threshold': 2,
        }
        args, monitor_info = self.prepare_numeric_monitor(args, defaults)

        # Validate
        assert args['check_connection_url']
        assert args['check_connection_url'] != 'jdbc:'
        assert args['check_jdbc_driver']
        assert args['check_user']
        assert args['check_password']
        assert args['check_query']

        jdbc_driver_list = self._client.service.getJdbcDriverList()
        for i in jdbc_driver_list:
            if i.jdbcDriverName == args['check_jdbc_driver']:
                args['check_jdbc_driver'] = i.jdbcDriverClass

        monitor_info.sqlCheckInfo = self.create_check_sql()
        ObjectModifier.replace_if_not_none(monitor_info.sqlCheckInfo,
                                           monitorId=args['monitor_id'],
                                           monitorTypeId=args['monitor_type_id'],
                                           connectionUrl=args['check_connection_url'],
                                           jdbcDriver=args['check_jdbc_driver'],
                                           user=args['check_user'],
                                           password=args['check_password'],
                                           query=args['check_query'])

        self.addMonitor(monitor_info)

    def add_monitor_snmp_n(self, args):
        # Default
        defaults = {
            'info_lower_threshold': 0.0,
            'info_upper_threshold': 0.0,
            'warn_lower_threshold': 0.0,
            'warn_upper_threshold': 0.0,
            'item_name': u'取得値',
            'unit': u'収集値単位',
            'cal_diff': 0,
            'monitor_type_id': 'MON_SNMP_N',
            'monitor': True,
            'change_info_lower_threshold': -1,
            'change_info_upper_threshold': 1,
            'change_warn_lower_threshold': -2,
            'change_warn_upper_threshold': 2,
        }
        args, monitor_info = self.prepare_numeric_monitor(args, defaults)

        # Validate
        assert args['snmp_oid']
        assert args['cal_diff'] in (0, 1)

        monitor_info.snmpCheckInfo = self.create_check_snmp(args)
        self.addMonitor(monitor_info)

    def add_monitor_snmp_s(self, monitor_id, facility_id, application,
                           string_value_infos, snmp_oid, collector_flg,
                           logformat_id, run_interval=None, description=None,
                           calendar_id=None, owner_role_id=None,
                           monitor_flg=None, notify_infos=None):
        # Validate
        assert snmp_oid

        monitor_type_id = 'MON_SNMP_S'
        monitor_info = self.create_monitor_info_string(monitor_type_id,
                                                       monitor_id,
                                                       facility_id,
                                                       run_interval,
                                                       calendar_id,
                                                       application,
                                                       description,
                                                       owner_role_id,
                                                       monitor_flg,
                                                       collector_flg,
                                                       logformat_id,
                                                       notify_infos,
                                                       string_value_infos)

        monitor_info.snmpCheckInfo = self.create_check_snmp({
            'monitor_id': monitor_id,
            'monitor_type_id': monitor_type_id,
            'snmp_oid': snmp_oid,
            'cal_diff': 1
        })
        self.addMonitor(monitor_info)

    def add_monitor_logfile(self, monitor_id, facility_id, application,
                            string_value_infos, collector_flg, logformat_id,
                            directory, filename, file_encoding=None,
                            pattern_head=None, pattern_tail=None,
                            return_code=None, max_bytes=None, description=None,
                            calendar_id=None, owner_role_id=None,
                            monitor_flg=None, notify_infos=None):
        # Default
        if not file_encoding:
            file_encoding = 'UTF-8'
        if not return_code:
            return_code = 'LF'

        # Validate
        assert directory
        assert filename
        assert file_encoding
        assert return_code

        monitor_type_id = 'MON_LOGFILE_S'
        monitor_info = self.create_monitor_info_string(monitor_type_id,
                                                       monitor_id,
                                                       facility_id,
                                                       None,
                                                       calendar_id,
                                                       application,
                                                       description,
                                                       owner_role_id,
                                                       monitor_flg,
                                                       collector_flg,
                                                       logformat_id,
                                                       notify_infos,
                                                       string_value_infos)

        monitor_info.logfileCheckInfo = self.create_check_logfile()
        ObjectModifier.replace_if_not_none(monitor_info.logfileCheckInfo,
                                           monitorId=monitor_id,
                                           monitorTypeId=monitor_type_id,
                                           directory=directory,
                                           fileName=filename,
                                           fileEncoding=file_encoding,
                                           fileReturnCode=return_code,
                                           maxBytes=max_bytes,
                                           patternHead=pattern_head,
                                           patternTail=pattern_tail)
        self.addMonitor(monitor_info)

    def add_monitor_ping(self, args):
        # Default
        defaults = {
            'info_lower_threshold': 1000.0,
            'info_upper_threshold': 1.0,
            'warn_lower_threshold': 3000.0,
            'warn_upper_threshold': 51.0,
            'item_name': u'応答時間',
            'unit': 'msec',
            'convert_flg': 0,
            'monitor_type_id': 'MON_PNG_N',
            'monitor': True,
            'change_info_lower_threshold': -1,
            'change_info_upper_threshold': 1,
            'change_warn_lower_threshold': -2,
            'change_warn_upper_threshold': 2,
            'check_run_count': 1,
            'check_timeout': 5000,
            'check_run_interval': 1000
        }
        args, monitor_info = self.prepare_numeric_monitor(args, defaults)

        # Validate
        assert 1 <= args['check_run_count'] and args['check_run_count'] <= 9
        assert 0 <= args['check_run_interval'] <= 5000

        monitor_info.pingCheckInfo = self.create_check_ping(args)
        self.addMonitor(monitor_info)

    def add_monitor_port(self, args):
        # Default
        defaults = {
            'check_run_count': 1,
            'check_port': 80,
            'check_run_interval': 1000,
            'check_service_id': '001',
            'check_timeout': 5000,
            'info_lower_threshold': 0.0,
            'info_upper_threshold': 1000.0,
            'warn_lower_threshold': 1000.0,
            'warn_upper_threshold': 3000.0,
            'item_name':  u'応答時間',
            'unit': 'msec',
            'monitor_type_id': 'MON_PRT_N',
            'monitor': True,
            'change_info_lower_threshold': -1,
            'change_info_upper_threshold': 1,
            'change_warn_lower_threshold': -2,
            'change_warn_upper_threshold': 2,
        }
        args, monitor_info = self.prepare_numeric_monitor(args, defaults)

        # Validate
        assert 1 <= args['check_run_count'] and args['check_run_count'] <= 9
        assert 0 <= args['check_run_interval'] and args['check_run_interval'] <= 5000

        monitor_info.portCheckInfo = self.create_check_port(args)
        self.addMonitor(monitor_info)

    def add_monitor_proc(self, args):
        # Default
        defaults = {
            'check_case_sensitive': False,
            'check_argument': '',
            'info_lower_threshold': 1.0,
            'info_upper_threshold': 99.0,
            'warn_lower_threshold': 99.0,
            'warn_upper_threshold': 99.0,
            'item_name': u'プロセス数',
            'unit': u'個',
            'monitor_type_id': 'MON_PRC_N',
            'monitor': True,
            'change_info_lower_threshold': -1,
            'change_info_upper_threshold': 1,
            'change_warn_lower_threshold': -2,
            'change_warn_upper_threshold': 2,
        }
        args, monitor_info = self.prepare_numeric_monitor(args, defaults)

        # Validate
        assert args['check_command']

        monitor_info.processCheckInfo = self.create_check_process(args)
        self.addMonitor(monitor_info)

    def add_monitor_packet_capture(self, args):
        defaults = {
            'monitor_type': 5,
            'monitor_type_id': 'MON_PCAP_BIN',
            'run_interval': 0
        }
        args = prepare_args(args, defaults)
        info = self.create_monitor_info_basic_from_args(args)
        info.packetCheckInfo = self.create_check_packet(args)
        info.binaryPatternInfo = [self.create_binary_pattern(args)]
        info.changeFlg = False
        info.predictionFlg = False
        self.addMonitor(info)

    def modify_monitor_packet_capture(self, args):
        info = self.getMonitor(args['monitor_id'])

        info = self.modify_monitor_info_basic(info, args)
        info.packetCheckInfo = self.create_check_packet(args,
                                                        info.packetCheckInfo)
        self.modify_binary_fiter_rules(args, info)

        return self.modifyMonitor(info)

    def add_monitor_binaryfile(self, args):
        defaults = {
            'monitor_type': 5,
            'monitor_type_id': 'MON_BINARYFILE_BIN',
            'tagType_raw': 'NONE',
            'run_interval': 0
        }
        args = prepare_args(args, defaults)
        info = self.create_monitor_info_basic_from_args(args)
        info.binaryCheckInfo = self.create_check_binary(args)
        info.binaryPatternInfo = [self.create_binary_pattern(args)]
        info.changeFlg = False
        info.predictionFlg = False
        self.addMonitor(info)

    def modify_monitor_binaryfile(self, args):
        info = self.getMonitor(args['monitor_id'])

        info = self.modify_monitor_info_basic(info, args)
        info.binaryCheckInfo = self.modify_check_binary(args,
                                                        info.binaryCheckInfo)
        self.modify_binary_fiter_rules(args, info)

        return self.modifyMonitor(info)

    def add_monitor_compound_collectors(self, args):
        defaults = {
            'monitor_type': 0,
            'monitor_type_id': 'MON_COMPOUND_B',
            'conditionAction': 'ADD'
        }
        args = prepare_args(args, defaults)

        info = self.create_monitor_info_basic_from_args(args)
        info.integrationCheckInfo = self.create_check_integration(args)
        info.truthValueInfo = [
            self.create_monitor_truth_value_info(
                args['monitor_id'], 1, args['priorityOk']),
            self.create_monitor_truth_value_info(
                args['monitor_id'], 0, args['priorityNg'])
        ]
        info.changeFlg = False
        info.predictionFlg = False
        self.addMonitor(info)

    def modify_monitor_compound_collectors(self, args):
        info = self.getMonitor(args['monitor_id'])

        info = self.modify_monitor_info_basic(info, args)
        info.integrationCheckInfo = self.create_check_integration(
            args, info.integrationCheckInfo)

        with ObjectModifier(info.truthValueInfo) as modifier:
            modifier.replace_if_not_none(
                modifier.select(truthValue=1),
                priority=args.get('priorityOk'))
            modifier.replace_if_not_none(
                modifier.select(truthValue=0),
                priority=args.get('priorityNg'))
        return self.modifyMonitor(info)

    def add_monitor_correlation_coeff(self, args):
        defaults = {
            'monitor_type': 1,
            'monitor_type_id': 'MON_CORRELATION_N',
            'info_lower_threshold': 0.8,
            'info_upper_threshold': 1.0,
            'warn_lower_threshold': 0.6,
            'warn_upper_threshold': 0.8,
            'item_name': u'Value',
            'unit': u'Unit of Collected Item',
            'change_info_lower_threshold': -1,
            'change_info_upper_threshold': 1,
            'change_warn_lower_threshold': -2,
            'change_warn_upper_threshold': 2,
        }
        args, info = self.prepare_numeric_monitor(args, defaults)
        info.correlationCheckInfo = self.create_check_correlation(args)
        self.addMonitor(info)

    def modify_monitor_correlation_coeff(self, args):
        info = self.getMonitor(args['monitor_id'])
        self.update_numeric_monitor(info, args)
        self.create_check_correlation(args, info.correlationCheckInfo)
        self.modifyMonitor(info)

    def add_monitor_log_count(self, args):
        defaults = {
            'monitor_type': 1,
            'monitor_type_id': 'MON_LOGCOUNT_N',
            'info_lower_threshold': 0,
            'info_upper_threshold': 100,
            'warn_lower_threshold': 100,
            'warn_upper_threshold': 200,
            'item_name': u'Value',
            'unit': u'Records',
            'change_info_lower_threshold': -1,
            'change_info_upper_threshold': 1,
            'change_warn_lower_threshold': -2,
            'change_warn_upper_threshold': 2,
        }
        args, info = self.prepare_numeric_monitor(args, defaults)
        info.logcountCheckInfo = self.create_check_logcount(args)
        self.addMonitor(info)

    def modify_monitor_log_count(self, args):
        info = self.getMonitor(args['monitor_id'])
        self.update_numeric_monitor(info, args)
        self.create_check_logcount(args, info.logcountCheckInfo)
        self.modifyMonitor(info)

    def modify_binary_fiter_rules(self, args, info):
        # order indexing starts from 1
        if args['rulePos']:
            args['rulePos'] = args['rulePos'] - 1
        if args['ruleNewPos']:
            args['ruleNewPos'] = args['ruleNewPos'] - 1

        if args['ruleAction'] == 'ADD':
            i = args['rulePos'] if args['rulePos'] is not None else len(
                info.binaryPatternInfo)
            info.binaryPatternInfo.insert(i, self.create_binary_pattern(args))
        elif args['ruleAction'] == 'MOD':
            self.create_binary_pattern(args,
                                       info.binaryPatternInfo[args['rulePos']])
        elif args['ruleAction'] == 'DEL':
            del info.binaryPatternInfo[args['rulePos']]
        if args['rulePos'] is not None and args['ruleNewPos'] is not None:
            self.change_obj_index_in_list(
                info.binaryPatternInfo, args['rulePos'], args['ruleNewPos'])

    def create_check_packet(self, args, mod_obj=None):
        if mod_obj is None:
            name_space = 'ns1'
            obj_name = 'packetCheckInfo'
            info = self.get_obj(name_space, obj_name)
        else:
            info = mod_obj

        ObjectModifier.replace_if_not_none(
            info,
            monitorId=args.get('monitor_id'),
            monitorTypeId=args.get('monitor_type_id'),
            filterStr=args.get('filterStr'),
            promiscuousMode=args.get('promiscuousMode')
        )
        return info

    def create_check_logcount(self, args, mod_obj=None):
        if mod_obj is None:
            name_space = 'ns1'
            obj_name = 'logcountCheckInfo'
            info = self.get_obj(name_space, obj_name)
        else:
            info = mod_obj

        ObjectModifier.replace_if_not_none(
            info,
            monitorId=args.get('monitor_id'),
            monitorTypeId=args.get('monitor_type_id'),
            isAnd=args.get('isAnd'),
            keyword=args.get('keyword'),
            targetMonitorId=args.get('targetMonitorId')
        )
        if args.get('tag_raw') is not None:
            info.tag = args.get('tag')
        if info.keyword is None:
            info.keyword = ''
        return info

    def create_check_correlation(self, args, mod_obj=None):
        if mod_obj is None:
            name_space = 'ns1'
            obj_name = 'correlationCheckInfo'
            info = self.get_obj(name_space, obj_name)
        else:
            info = mod_obj

        if args.get('targetMonitorId') is not None:
            targetInfo = self.getMonitor(args.get('targetMonitorId'))
        else:
            targetInfo = {'itemName': None}
        if args.get('referMonitorId') is not None:
            refInfo = self.getMonitor(args.get('referMonitorId'))
        else:
            refInfo = {'itemName': None}

        ObjectModifier.replace_if_not_none(
            info,
            monitorId=args.get('monitor_id'),
            monitorTypeId=args.get('monitor_type_id'),
            analysysRange=args.get('analysysRange'),
            # FIXME get this value with API
            referDisplayName='',
            referFacilityId=args.get('referFacilityId'),
            referItemName=refInfo['itemName'],
            referMonitorId=args.get('referMonitorId'),
            # FIXME get this value with API
            targetDisplayName='',
            targetItemName=targetInfo['itemName'],
            targetMonitorId=args.get('targetMonitorId')
        )
        return info

    def create_check_integration(self, args, mod_obj=None):
        if mod_obj is None:
            name_space = 'ns1'
            obj_name = 'integrationCheckInfo'
            info = self.get_obj(name_space, obj_name)
        else:
            info = mod_obj

        ObjectModifier.replace_if_not_none(
            info,
            monitorId=args.get('monitor_id'),
            monitorTypeId=args.get('monitor_type_id'),
            messageNg=args.get('check_messageNg'),
            messageOk=args.get('check_messageOk'),
            notOrder=args.get('check_notOrder'),
            timeout=args.get('check_timeout')
        )

        info.conditionList = self.create_integration_condition_list(
            args,
            info.conditionList)
        return info

    def create_integration_condition_list(self, args, list):
        if args['jcMonitorNode']:
            args['jcTargetFacilityId'] = args['facility_id']

        if args.get('conditionPos') is not None:
            args['conditionPos'] -= 1
        if args.get('conditionNewPos') is not None:
            args['conditionNewPos'] -= 1

        for integrationConditionInfo in list:
            if integrationConditionInfo.targetDisplayName is None:
                integrationConditionInfo.targetDisplayName = ''

        if args.get('conditionAction') == 'ADD' \
                or args.get('conditionAction') == 'MOD':
            if args['conditionAction'] == 'ADD':
                name_space = 'ns1'
                obj_name = 'integrationConditionInfo'
                info = self.get_obj(name_space, obj_name)
                i = len(list) if args.get('conditionPos') is None \
                    else args['conditionPos']
                list.insert(i, info)
            elif args['conditionAction'] == 'MOD':
                info = list[args['conditionPos']]

            if args['jcTargetMonitorType_raw'] == 'string':
                if args['jcComparisonMethod'] != '=':
                    if args['jcComparisonMethod'] is None \
                            and args.get('conditionAction') == 'MOD' \
                            and info.comparisonMethod == '=':
                        pass
                    else:
                        raise Exception('Only comparison method: "=" can be'
                                        ' used with collect type string')

            if args.get('jcTargetMonitorId') is not None:
                targetInfo = self.getMonitor(args.get('jcTargetMonitorId'))
            else:
                targetInfo = {'itemName': None}

            ObjectModifier.replace_if_not_none(
                info,
                comparisonMethod=args.get('jcComparisonMethod'),
                comparisonValue=args.get('jcComparisonValue'),
                description=args.get('jcDescription'),
                isAnd=args.get('jcIsAnd'),
                monitorId=args.get('monitor_id'),
                monitorNode=args.get('jcMonitorNode'),
                # FIXME get this value with API
                targetDisplayName='',
                targetFacilityId=args.get('jcTargetFacilityId'),
                # FIXME get this value with API
                targetItemDisplayName='',
                targetItemName=targetInfo['itemName'],
                targetMonitorId=args.get('jcTargetMonitorId'),
                targetMonitorType=args.get('jcTargetMonitorType')
            )
        elif args.get('conditionAction') == 'DEL':
            del list[args['conditionPos']]

        if args.get('conditionPos', False) \
                and args.get('conditionNewPos', False):
            self.change_obj_index_in_list(
                list, args['conditionPos'], args['conditionNewPos'])
        return list

    def modify_monitor_info_basic(self, info, args):
        # defaults
        # info.failurePriority = 1
        # info.scope = ' '

        ObjectModifier.replace_if_not_none(
            info,
            monitorType=args.get('monitor_type'),
            monitorTypeId=args.get('monitor_type_id'),
            monitorId=args.get('monitor_id'),
            application=args.get('application'),
            calendarId=args.get('calendar_id'),
            collectorFlg=args.get('collect'),
            description=args.get('description'),
            ownerRoleId=args.get('owner_role_id'),
            facilityId=args.get('facility_id'),
            scope=args.get('scope'),
            failurePriority=args.get('failure_priority'),
            monitorFlg=args.get('monitor'),
            runInterval=args.get('run_interval'),
        )
        info = self.update_notify_ids_info(info, args)
        return info

    def create_check_binary(self, args, modify_object=None):
        from pprint import pprint
        pprint(args)

        if args['tagType'] in ['pacct', 'pcap', 'wtmp']:
            endpoint = BinaryEndpoint(
                args['mgr_url'], args['user'], args['passwd'])
            result = endpoint.getPresetList()
            info = filter(
                lambda x: x.tagType == args['tagType'], result)[0]
        elif args['tagType_raw'] == 'NONE' or \
                args['tagType_raw'] == 'regularInterval':
            name_space = 'ns1'
            obj_name = 'binaryCheckInfo'
            info = self.get_obj(name_space, obj_name)
            # defaults
            info.fileHeadSize = 0
            info.recordSize = 0
            info.recordHeadSize = 0
            info.sizeLength = 0
            info.sizePosition = 0

            info.littleEndian = False
            info.haveTs = False
            info.tsPosition = 0
        elif args['tagType_raw'] is None:
            info = modify_object
        else:
            raise Exception('incorect data structure type')

        ObjectModifier.replace_if_not_none(
            info,
            monitorId=args.get('monitor_id'),
            monitorTypeId=args.get('monitor_type_id'),
            binaryfile=args.get('binaryfile'),
            collectType=args.get('collectType'),
            cutType=args.get('cutType'),
            directory=args.get('directory'),
            errMsg=args.get('errMsg'),
            fileHeadSize=args.get('fileHeadSize'),
            fileName=args.get('fileName'),
            haveTs=args.get('haveTs'),
            lengthType=args.get('lengthType'),
            littleEndian=args.get('littleEndian'),
            recordHeadSize=args.get('recordHeadSize'),
            recordSize=args.get('recordSize'),
            sizeLength=args.get('sizeLength'),
            sizePosition=args.get('sizePosition'),
            tagType=args.get('tagType'),
            tsPosition=args.get('tsPosition'),
            tsType=args.get('tsType')
        )

        if args['tagType_raw'] is not None:
            if args['tagType'] is None:
                info.cutType = 'binary.cut.type.interval'
            else:
                info.cutType = 'binary.cut.type.length'

        pprint(info)
        return info

    def modify_check_binary(self, args, mod_obj):
        info = mod_obj
        ObjectModifier.replace_if_not_none_and_obj_val_is_none(
            args,
            monitor_type_id=info.monitorTypeId,
            binaryfile=info.binaryfile,
            collectType=info.collectType,
            cutType=info.cutType,
            directory=info.directory,
            errMsg=info.errMsg,
            fileName=info.fileName,
        )
        return self.create_check_binary(args, info)

    def create_binary_pattern(self, args, modify_object=None):
        if modify_object is None:
            if args['bfgrepString']:
                name_space = 'ns1'
                obj_name = 'binaryPatternInfo'
                info = self.get_obj(name_space, obj_name)
            else:
                return None
        else:
            info = modify_object

        ObjectModifier.replace_if_not_none(
            info,
            description=args.get('bfDescription'),
            encoding=args.get('bfencoding'),
            grepString=args.get('bfgrepString'),
            message=args.get('bfmessage'),
            monitorId=args.get('monitor_id'),
            priority=args.get('bfpriority'),
            processType=args.get('bfprocessType'),
            validFlg=args.get('bfvalidFlg')
        )
        return info

    def create_notify_relation_info(self, notify_info, monitor_type_id,
                                    monitor_id):
        name_space = 'ns0'
        obj_name = 'notifyRelationInfo'
        try:
            info = self.get_obj(name_space, obj_name)
            info.notifyGroupId = monitor_type_id + '-' + monitor_id + '-0'
            info.notifyId = notify_info.notifyId
            info.notifyType = notify_info.notifyType
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_monitor_filter_info(self, calendar_id, collector_flg,
                                   description, facility_id, monitor_flg,
                                   monitor_id, monitor_type_id, reg_from_date,
                                   reg_to_date, reg_user, update_from_date,
                                   update_to_date, update_user, owner_role_id):

        obj_name = 'monitorFilterInfo'
        name_space = 'ns1'
        try:
            info = self.get_obj(name_space, obj_name)
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))
        if calendar_id is not None and calendar_id != '':
            info.calendarId = calendar_id
        if collector_flg is not None and collector_flg != '':
            info.collectorFlg = collector_flg
        if description is not None and description != '':
            info.description = description
        if facility_id is not None and facility_id != '':
            info.facilityId = facility_id
        if monitor_flg is not None and monitor_flg != '':
            info.monitorFlg = monitor_flg
        if monitor_id is not None and monitor_id != '':
            info.monitorId = monitor_id
        if monitor_type_id is not None and monitor_type_id != '':
            info.monitorTypeId = monitor_type_id
        if reg_from_date is not None and reg_from_date != '':
            info.regFromDate = reg_from_date
        if reg_to_date is not None and reg_to_date != '':
            info.regToDate = reg_to_date
        if reg_user is not None and reg_user != '':
            info.regUser = reg_user
        if update_from_date is not None and update_from_date != '':
            info.updateFromDate = update_from_date
        if update_to_date is not None and update_to_date != '':
            info.updateToDate = update_to_date
        if update_user is not None and update_user != '':
            info.updateUser = update_user
        if owner_role_id is not None and owner_role_id != '':
            info.ownerRoleId = owner_role_id
        return info

    def create_monitor_info_basic(self, monitor_type, monitor_type_id,
                                  monitor_id, facility_id, run_interval,
                                  calendar_id, application, description=None,
                                  owner_role_id=None, monitor_flg=None,
                                  notify_infos=None, collector_flg=None):
        # Setting
        failure_priority = 1
        scope = ' '

        # Default
        if collector_flg is None:
            collector_flg = 0
        if monitor_flg is None:
            monitor_flg = 1
        if description is None:
            description = ''
        if owner_role_id is None:
            owner_role_id = 'ALL_USERS'
        if run_interval is None:
            if monitor_type_id in ('MON_WINEVENT_S', 'MON_SYSLOG_S',
                                   'MON_LOGFILE_S', 'MON_SNMP_TRP'):
                run_interval = 0
            else:
                run_interval = 300

        obj_name = 'monitorInfo'
        name_space = 'ns1'
        try:
            info = self.get_obj(name_space, obj_name)
            info.monitorType = monitor_type
            info.monitorTypeId = monitor_type_id
            info.monitorId = monitor_id

            info.application = application
            info.calendarId = calendar_id
            info.collectorFlg = collector_flg
            info.description = description
            info.ownerRoleId = owner_role_id
            info.facilityId = facility_id
            info.scope = scope
            info.failurePriority = failure_priority
            info.monitorFlg = monitor_flg
            info.runInterval = run_interval
            if notify_infos is not None:
                for a in notify_infos:
                    info.notifyRelationList.append(
                        self.create_notify_relation_info(a,
                                                         monitor_type_id,
                                                         monitor_id))
            info.calendar = None
            return(info)
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_monitor_info_basic_from_args(self, args):
        return self.create_monitor_info_basic(args['monitor_type'],
                                              args['monitor_type_id'],
                                              args['monitor_id'],
                                              args['facility_id'],
                                              args['run_interval'],
                                              args['calendar_id'],
                                              args['application'],
                                              args['description'],
                                              args['owner_role_id'],
                                              args['monitor'],
                                              args['notify_ids'],
                                              args.get('collect'))

    def create_monitor_truth_value_info(self, monitor_id, truth_value,
                                        priority):
        obj_name = 'monitorTruthValueInfo'
        name_space = 'ns1'
        try:
            info = self.get_obj(name_space, obj_name)
            info.monitorId = monitor_id
            info.priority = priority
            info.truthValue = truth_value
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_monitor_info_boolean(self, monitor_type_id, monitor_id,
                                    facility_id, run_interval, calendar_id,
                                    application, description, owner_role_id,
                                    monitor_flg, notify_infos, priority_ok,
                                    priority_ng):
        # Default
        if priority_ok is None:
            priority_ok = 3
        if priority_ng is None:
            priority_ng = 0

        try:
            info = self.create_monitor_info_basic(0,
                                                  monitor_type_id,
                                                  monitor_id,
                                                  facility_id,
                                                  run_interval,
                                                  calendar_id,
                                                  application,
                                                  description,
                                                  owner_role_id,
                                                  monitor_flg,
                                                  notify_infos)
            info.truthValueInfo.append(
                self.create_monitor_truth_value_info(monitor_id, 1, priority_ok))
            info.truthValueInfo.append(
                self.create_monitor_truth_value_info(monitor_id, 0, priority_ng))
            info.changeFlg = False
            info.predictionFlg = False
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create monitorInfo(Boolean, ' + str(monitor_type_id) + ') failed, ' + str(e))

    def create_monitor_info_string(self, monitor_type_id, monitor_id,
                                   facility_id, run_interval, calendar_id,
                                   application, description, owner_role_id,
                                   monitor_flg, collector_flg, logformat_id,
                                   notify_infos, string_value_infos):
        # Default
        if string_value_infos is None:
            string_value_infos = []
        if collector_flg is None or collector_flg == '':
            collector_flg = False

        try:
            info = self.create_monitor_info_basic(2,
                                                  monitor_type_id,
                                                  monitor_id,
                                                  facility_id,
                                                  run_interval,
                                                  calendar_id,
                                                  application,
                                                  description,
                                                  owner_role_id,
                                                  monitor_flg,
                                                  notify_infos)
            info.stringValueInfo = string_value_infos
            info.collectorFlg = collector_flg
            info.logFormatId = logformat_id
            info.changeFlg = False
            info.predictionFlg = False
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create monitorInfo(String, ' + str(monitor_type_id) + ') failed, ' + str(e))

    def create_monitor_info_numeric(self, args):
        defaults = {
            'item_name': u'取得値',
            'unit': u'収集値単位',
            'collect_converted': False
        }
        args = set_default_values_if_none(args, defaults)

        try:
            info = self.create_monitor_info_basic(1,
                                                  args['monitor_type_id'],
                                                  args['monitor_id'],
                                                  args['facility_id'],
                                                  args['run_interval'],
                                                  args['calendar_id'],
                                                  args['application'],
                                                  args['description'],
                                                  args['owner_role_id'],
                                                  args['monitor'],
                                                  args['notify_ids'],
                                                  args['collect'])
        except Exception, e:
            raise ErrorHandler.APIError(
                'create monitorInfo(Numeric, ' + str(args['monitor_type_id']) + ') failed, ' + str(e))
        info.itemName = args['item_name']
        info.measure = args['unit']
        info.numericValueInfo = args['numeric_value_infos']
        return info

    def create_monitor_info_trap(self, monitor_type_id, monitor_id, facility_id,
                                 calendar_id, application, description,
                                 owner_role_id, monitor_flg, notify_infos,
                                 collector_flg, logformat_id,
                                 community_check=None, community_name=None,
                                 charset_convert=None, charset_name=None,
                                 notifyof_receiving_unspecified_flg=None,
                                 priority_unspecified=None,
                                 trap_value_infos=None):
        # Default
        if charset_convert is None:
            charset_convert = 0
        if community_check is None:
            community_check = 0
        if notifyof_receiving_unspecified_flg is None:
            notifyof_receiving_unspecified_flg = True
        if priority_unspecified is None:
            priority_unspecified = 1
        if collector_flg is None or collector_flg == '':
            collector_flg = False

        try:
            info = self.create_monitor_info_basic(3,
                                                  monitor_type_id,
                                                  monitor_id,
                                                  facility_id,
                                                  None,
                                                  calendar_id,
                                                  application,
                                                  description,
                                                  owner_role_id,
                                                  monitor_flg,
                                                  notify_infos)

            info.changeFlg = False
            info.predictionFlg = False
            info.trapCheckInfo = self.create_check_trap({
                'monitor_id': monitor_id,
                'monitor_type_id': monitor_type_id,
                'community_check': community_check,
                'community_name': community_name,
                'charset_convert': charset_convert,
                'charset_name': charset_name,
                'notifyof_receiving_unspecified_flg': notifyof_receiving_unspecified_flg,
                'priority_unspecified': priority_unspecified,
                'trap_value_infos': trap_value_infos
            })
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create monitorInfo(Trap, ' + str(monitor_type_id) + ') failed, ' + str(e))

    def create_check_trap(self, args=None):
        info = self.get_obj('ns1', 'trapCheckInfo')
        if args:
            info.monitorId = args.get('monitor_id')
            info.monitorTypeId = args.get('monitor_type_id')
            info.communityCheck = args.get('community_check')
            if args.get('community_name') is not None:
                info.communityName = args.get('community_name')
            info.charsetConvert = args.get('charset_convert')
            if args.get('charset_name') is not None:
                info.charsetName = args.get('charset_name')
            info.notifyofReceivingUnspecifiedFlg = args.get(
                'notifyof_receiving_unspecified_flg')
            info.priorityUnspecified = args.get('priority_unspecified')
            if args.get('trap_value_infos') is not None:
                info.trapValueInfos = args.get('trap_value_infos')
        return info

    def create_monitor_numeric_value_info(self, monitor_id, numeric_type,
                                          priority, threshold_lower_limit=0,
                                          threshold_upper_limit=0):

        obj_name = 'monitorNumericValueInfo'
        name_space = 'ns1'
        try:
            info = self.get_obj(name_space, obj_name)
            info.monitorId = monitor_id
            info.monitorNumericType = numeric_type
            info.priority = priority
            info.thresholdLowerLimit = threshold_lower_limit
            info.thresholdUpperLimit = threshold_upper_limit
            info.message = ''  # fixed-var
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_monitor_numeric_value_infos_list(self, args):
        return [
            self.create_monitor_numeric_value_info(args['monitor_id'], '', 0),
            self.create_monitor_numeric_value_info(args['monitor_id'], '', 1),
            self.create_monitor_numeric_value_info(
                args['monitor_id'], '', 2,
                args['warn_lower_threshold'],
                args['warn_upper_threshold']),
            self.create_monitor_numeric_value_info(
                args['monitor_id'], '', 3,
                args['info_lower_threshold'],
                args['info_upper_threshold']),
            self.create_monitor_numeric_value_info(
                args['monitor_id'], 'CHANGE', 0,
                0.0, 1.0),
            self.create_monitor_numeric_value_info(
                args['monitor_id'], 'CHANGE', 1,
                0.0, 1.0),
            self.create_monitor_numeric_value_info(
                args['monitor_id'], 'CHANGE', 2,
                args['change_warn_lower_threshold'],
                args['change_warn_upper_threshold']),
            self.create_monitor_numeric_value_info(
                args['monitor_id'], 'CHANGE', 3,
                args['change_info_lower_threshold'],
                args['change_info_upper_threshold'])
        ]

    def fill_prediction_values(self, monitor_info, args):
        defaults = {
            'prediction_analysis_range': 60,
            'prediction_flg': False,
            'prediction_method': 'POLYNOMIAL_1',
            'prediction_target': 60,
            'prediction_notify_ids': []
        }
        set_default_values_if_none(args, defaults)

        monitor_info.predictionAnalysysRange = args['prediction_analysis_range']
        monitor_info.predictionApplication = args['prediction_application']
        monitor_info.predictionFlg = args['prediction_flg']
        monitor_info.predictionMethod = args['prediction_method']
        monitor_info.predictionNotifyRelationList = args['prediction_notify_ids']
        monitor_info.predictionTarget = args['prediction_target']
        return monitor_info

    def fill_change_values(self, monitor_info, args):
        defaults = {
            'change_analysis_range': 60,
            'change_flg': False,
            'change_notify_ids': []
        }
        set_default_values_if_none(args, defaults)

        monitor_info.changeFlg = args['change_flg']
        monitor_info.changeAnalysysRange = args['change_analysis_range']
        monitor_info.changeApplication = args['change_application']
        monitor_info.changeNotifyRelationList = args['change_notify_ids']
        return monitor_info

    def create_var_bind_pattern(self, pattern, description=None,
                                case_sensitivity_flg=None, process_type=None,
                                priority=None, valid_flg=None):
        # Default
        if case_sensitivity_flg is None:
            case_sensitivity_flg = False
        if description is None:
            description = ''
        if priority is None:
            priority = 0
        if process_type is None:
            process_type = 1
        if valid_flg is None:
            valid_flg = True

        obj_name = 'varBindPattern'
        name_space = 'ns1'
        try:
            info = self.get_obj(name_space, obj_name)
            info.caseSensitivityFlg = case_sensitivity_flg
            info.description = description
            info.pattern = pattern
            info.priority = priority
            info.processType = process_type
            info.validFlg = valid_flg
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_trap_value_info(self, mib, uei, trap_oid, logmsg, description,
                               version=0, generic_id=None, specific_id=None,
                               processing_varbind_type=None,
                               priority_any_varbind=None, format_var_binds=None,
                               var_bind_patterns=None, valid_flg=True):
        # Default
        if version is None or version == '1':
            version = 0
            assert generic_id, 'generic_id is required!'
            assert specific_id, 'specific_id is required!'
        elif version == '2c/3':
            version = 1
        else:
            if generic_id is None:
                generic_id = ''
            if specific_id is None:
                specific_id = ''

        if processing_varbind_type is None:
            processing_varbind_type = 0
        elif processing_varbind_type == 1:
            assert format_var_binds, 'format_var_binds is required!'
            assert var_bind_patterns, 'var_bind_patterns is required!'
        if priority_any_varbind is None:
            priority_any_varbind = 0
        if format_var_binds is None:
            format_var_binds = ''
        if valid_flg is None:
            valid_flg = True

        obj_name = 'trapValueInfo'
        name_space = 'ns1'
        try:
            info = self.get_obj(name_space, obj_name)

            info.mib = mib
            info.trapOid = trap_oid
            info.uei = uei
            info.version = version
            info.genericId = generic_id
            info.specificId = specific_id
            info.logmsg = logmsg
            info.description = description

            info.processingVarbindSpecified = processing_varbind_type
            info.priorityAnyVarbind = priority_any_varbind
            info.formatVarBinds = format_var_binds
            if var_bind_patterns is not None:
                info.varBindPatterns = var_bind_patterns

            info.validFlg = valid_flg
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_monitor_string_value_info(self, monitor_id, pattern,
                                         description=None,
                                         case_sensitivity_flg=None,
                                         process_type=None, priority=None,
                                         message=None, valid_flg=None):
        # Default
        if case_sensitivity_flg is None:
            case_sensitivity_flg = False
        if description is None:
            description = ''
        if priority is None:
            priority = 0
        if process_type is None:
            process_type = 1
        if valid_flg is None:
            valid_flg = True
        if process_type == 0:
            assert message, 'message is required!'

        obj_name = 'monitorStringValueInfo'
        name_space = 'ns1'
        try:
            info = self.get_obj(name_space, obj_name)
            info.monitorId = monitor_id
            info.pattern = pattern
            info.description = description
            info.message = message
            info.priority = priority
            info.caseSensitivityFlg = case_sensitivity_flg
            info.processType = process_type
            info.validFlg = valid_flg
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_pattern(self, pattern, description=None,
                       case_sensitivity_flg=None,
                       process_type=None, valid_flg=None):
        # Default
        if description is None:
            description = ''
        if case_sensitivity_flg is None:
            case_sensitivity_flg = False
        if process_type is None:
            process_type = 1
        if valid_flg is None:
            valid_flg = True

        obj_name = 'pattern'
        name_space = 'ns1'
        try:
            info = self.get_obj(name_space, obj_name)
            info.caseSensitivityFlg = case_sensitivity_flg
            info.description = description
            info.pattern = pattern
            info.processType = process_type
            info.validFlg = valid_flg
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

#     def create_pagePK(self, pagePK, monitor_id, pageOrderNo=None):
#         # Default
#         if pageOrderNo is None:
#             pageOrderNo = 0
#
#         obj_name = 'pagePK'
#         try:
#             info = self._client.factory.create(obj_name)
#             info.monitor_id = monitor_id
#             info.pageOrderNo = pageOrderNo
#             return info
#         except Exception, e:
#             raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_variable(self, name, value, matching_with_response_flg=None):
        # Default
        if matching_with_response_flg is None:
            matching_with_response_flg = False

        obj_name = 'variable'
        name_space = 'ns1'
        try:
            info = self.get_obj(name_space, obj_name)
            info.matchingWithResponseFlg = False
            info.name = name
            info.value = value
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_page(self, monitor_id, order_no, url, message, patterns,
                    description=None, priority=None, post=None,
                    status_code=None, variables=None):
        # Default
        if description is None:
            description = ''
        if post is None:
            post = ''
        if priority is None:
            priority = 0
        if status_code is None:
            status_code = "200"
        assert patterns, 'at least 1 pattern is required!'
        if order_no is None:
            order_no = 0

        obj_name = 'page'
        name_space = 'ns1'
        try:
            info = self.get_obj(name_space, obj_name)
            info.id = self.create_pagePK({
                'monitor_id': monitor_id,
                'order_no': order_no
            })
            info.message = message
            info.priority = priority
            info.description = description
            info.post = post
            info.statusCode = status_code
            info.url = url
            info.patterns = patterns
            if variables is not None:
                info.variables = variables
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_check_ping(self, args=None):
        info = self.get_obj('ns1', 'pingCheckInfo')
        if args:
            ObjectModifier.replace_if_not_none(info,
                                               monitorId=args.get(
                                                   'monitor_id'),
                                               monitorTypeId=args.get(
                                                   'monitor_type_id'),
                                               runCount=args.get(
                                                   'check_run_count'),
                                               runInterval=args.get(
                                                   'check_run_interval'),
                                               timeout=args.get(
                                                   'check_timeout'))
        return info

    def create_check_port(self, args=None):
        info = self.get_obj('ns1', 'portCheckInfo')
        if args:
            ObjectModifier.replace_if_not_none(info,
                                               monitorId=args.get(
                                                   'monitor_id'),
                                               monitorTypeId=args.get(
                                                   'monitor_type_id'),
                                               portNo=args.get('check_port'),
                                               runCount=args.get(
                                                   'check_run_count'),
                                               runInterval=args.get(
                                                   'check_run_interval'),
                                               serviceId=args.get(
                                                   'check_service_id'),
                                               timeout=args.get('check_timeout'))
        return info

    def create_check_sql(self, args=None):
        info = self.get_obj('ns1', 'sqlCheckInfo')
        return info

    def create_check_snmp(self, args=None):
        info = self.get_obj('ns1', 'snmpCheckInfo')
        if args:
            ObjectModifier.replace_if_not_none(info,
                                               monitorId=args.get(
                                                   'monitor_id'),
                                               monitorTypeId=args.get(
                                                   'monitor_type_id'),
                                               # communityName = community_name,
                                               # snmpPort = snmp_port,
                                               convertFlg=args.get('cal_diff'),
                                               snmpOid=args.get('snmp_oid'),
                                               snmpVersion='1')
        return info

    def create_check_logfile(self, args=None):
        info = self.get_obj('ns1', 'logfileCheckInfo')
        return info

    def create_check_process(self, args=None):
        info = self.get_obj('ns1', 'processCheckInfo')
        if args:
            ObjectModifier.replace_if_not_none(info,
                                               monitorId=args.get(
                                                   'monitor_id'),
                                               monitorTypeId=args.get(
                                                   'monitor_type_id'),
                                               caseSensitivityFlg=args.get(
                                                   'check_case_sensitive'),
                                               command=args.get(
                                                   'check_command'),
                                               param=args.get('check_argument'))
        return info

    def create_check_custom(self, args=None):
        info = self.get_obj('ns1', 'customCheckInfo')
        if args:
            info.monitorId = args.get('monitor_id')
            info.command = args.get('command')
            info.commandExecType = args.get('command_exec_type')
            info.convertFlg = args.get('convert_flg')
            info.selectedFacilityId = args.get('selected_facility_id')
            info.effectiveUser = args.get('run_user')
            info.specifyUser = args.get('specify_user_converted')
            info.timeout = args.get('timeout')
        return info

    def create_check_custom_trap(self, args=None):
        info = self.get_obj('ns1', 'customTrapCheckInfo')
        if args:
            info.monitorId = args.get('monitor_id')
            info.convertFlg = args.get('convert_flg')
            info.targetKey = args.get('key_pattern')
        return info

    def create_check_http(self, args=None):
        info = self.get_obj('ns1', 'httpCheckInfo')
        if args:
            info.monitorId = args.get('monitor_id')
            info.monitorTypeId = args.get('monitor_type_id')
            info.requestUrl = args.get('request_url')
            info.timeout = args.get('timeout')
            info.proxyPort = 0
            info.proxySet = 0
            info.urlReplace = 0
        return info

    def create_check_http_scenario(self, args=None):
        info = self.get_obj('ns1', 'httpScenarioCheckInfo')
        if args:
            info.monitorId = args.get('monitor_id')
            info.monitorTypeId = args.get('monitor_type_id')
            info.authType = args.get('auth_type')
            info.authUser = args.get('auth_user')
            info.authPassword = args.get('auth_password')
            info.connectTimeout = args.get('connect_timeout')
            info.monitoringPerPageFlg = args.get('monitoring_per_page_flg')
            info.pages = args.get('pages')
            info.proxyFlg = args.get('proxy_flg')
            info.proxyPassword = args.get('proxy_password')
            info.proxyPort = args.get('proxy_port')
            info.proxyUrl = args.get('proxy_url')
            info.proxyUser = args.get('proxy_user')
            info.requestTimeout = args.get('request_timeout')
            info.userAgent = args.get('user_agent')
        return info

    def create_check_jmx(self, args=None):
        info = self.get_obj('ns1', 'jmxCheckInfo')
        if args:
            info.monitorId = args.get('monitor_id')
            info.monitorTypeId = args.get('monitor_type_id')
            info.masterId = args.get('master_id')
            info.port = args.get('port')
            info.convertFlg = args.get('convert_flg')
            if args.get('auth_user') is not None:
                info.authUser = args.get('auth_user')
            if args.get('auth_password') is not None:
                info.authPassword = args.get('auth_password')
        return info

    def create_check_pref(self, args=None):
        info = self.get_obj('ns1', 'perfCheckInfo')
        if args:
            info.monitorId = args.get('monitor_id')
            info.monitorTypeId = args.get('monitor_type_id')
            info.breakdownFlg = args.get('collect_breakdown_detail')
            info.itemCode = args.get('item_code')
            info.deviceDisplayName = args.get('item_code_dev')
        return info

    def create_check_winevent(self, args=None):
        info = self.get_obj('ns1', 'winEventCheckInfo')
        if args:
            info.monitorId = args.get('monitor_id')
            info.monitorTypeId = args.get('monitor_type_id')
            info.levelVerbose = args.get('level_verbose')
            info.levelInformational = args.get('level_informational')
            info.levelWarning = args.get('level_warning')
            info.levelCritical = args.get('level_critical')
            info.levelError = args.get('level_error')
            info.logName = args.get('log_names')
            if args.get('sources'):
                info.source = args.get('sources')
            if args.get('event_ids'):
                info.eventId = args.get('event_ids')
            if args.get('categories'):
                info.category = args.get('categories')
            if args.get('keywords'):
                info.keywords = args.get('keywords')
        return info

    def create_pagePK(self, args=None):
        info = self.get_obj('ns1', 'pagePK')
        if args:
            info.monitorId = args.get('monitor_id')
            info.pageOrderNo = args.get('order_no')
        return info

    def create_check_winservice(self, args=None):
        info = self.get_obj('ns1', 'winServiceCheckInfo')
        if args:
            info.monitorId = args.get('monitor_id')
            info.monitorTypeId = args.get('monitor_type_id')
            info.serviceName = args.get('service_name')
        return info

    def update_notify_ids_info(self, monitor_info, args):
        args = all_ids_str_to_list(args)
        args = verify_all_ids(args)
        notify_attrs = ['notifyRelationList', 'predictionNotifyRelationList',
                        'changeNotifyRelationList']

        for attr in notify_attrs:
            if attr not in monitor_info:
                setattr(monitor_info, attr, [])

        monitor_info.notifyRelationList = self.add_notify_ids(
            self.delete_notify_ids(
                monitor_info.notifyRelationList, args.get('del_notify_ids')),
            args.get('add_notify_ids'))
        monitor_info.predictionNotifyRelationList = self.add_notify_ids(
            self.delete_notify_ids(
                monitor_info.predictionNotifyRelationList,
                args.get('del_prediction_notify_ids')),
            args.get('add_prediction_notify_ids'))
        monitor_info.changeNotifyRelationList = self.add_notify_ids(
            self.delete_notify_ids(
                monitor_info.changeNotifyRelationList,
                args.get('del_change_notify_ids')),
            args.get('add_change_notify_ids'))
        return monitor_info

    def add_notify_ids(self, current_list, to_add_list):
        if to_add_list is None:
            to_add_list = []
        current_ids = map(lambda x: x.notifyId, current_list)
        to_add_list = filter(
            lambda x: x.notifyId not in current_ids, to_add_list)
        current_list += to_add_list
        return current_list

    def delete_notify_ids(self, current_list, to_delete_list):
        if to_delete_list is None:
            to_delete_list = []
        to_delete_ids = map(lambda x: x.notifyId, to_delete_list)
        return filter(lambda x: x.notifyId not in to_delete_ids, current_list)

    def update_common_infos(self, modifier, args):
        # modifier is ObjectModifier(monitor_info)
        modifier.set_if_first_not_none_and_empty(
            'application', args.get('application'))
        modifier.set_if_first_not_none('calendarId', args.get('calendar_id'))
        modifier.set_if_first_not_none('description', args.get('description'))
        modifier.set_if_first_not_none_and_empty(
            'facilityId', args.get('facility_id'), scope=' ')
        modifier.set_if_first_not_none('monitorFlg', args.get('monitor'))
        modifier.set_if_first_not_none('runInterval', args.get('run_interval'))
        return modifier

    def update_collect_infos(self, modifier, args):
        modifier.set_if_first_not_none('collectorFlg', args.get('collect'))
        modifier.set_if_first_not_none('itemName', args.get('item_name'))
        modifier.set_if_first_not_none('measure', args.get('unit'))
        return modifier

    def updete_judgement_tresholds(self, modifier, args):
        modifier.change_ptr('numericValueInfo')
        modifier.replace_if_not_none(
            modifier.select(
                priority=NotifyUtil.convert2priority('INFO'),
                monitorNumericType=None),
            thresholdLowerLimit=args.get('info_lower_threshold'),
            thresholdUpperLimit=args.get('info_upper_threshold')
        )
        modifier.replace_if_not_none(
            modifier.select(
                priority=NotifyUtil.convert2priority('WARN'),
                monitorNumericType=None),
            thresholdLowerLimit=args.get('warn_lower_threshold'),
            thresholdUpperLimit=args.get('warn_upper_threshold')
        )
        modifier.replace_if_not_none(
            modifier.select(
                priority=NotifyUtil.convert2priority('INFO'),
                monitorNumericType='CHANGE'),
            thresholdLowerLimit=args.get('change_info_lower_threshold'),
            thresholdUpperLimit=args.get('change_info_upper_threshold')
        )
        modifier.replace_if_not_none(
            modifier.select(
                priority=NotifyUtil.convert2priority('WARN'),
                monitorNumericType='CHANGE'),
            thresholdLowerLimit=args.get('change_warn_lower_threshold'),
            thresholdUpperLimit=args.get('change_warn_upper_threshold')
        )
        return modifier

    def update_prediction_info(self, modifier, args):
        modifier.set_if_first_not_none('predictionAnalysysRange',
                                       args.get('prediction_analysis_range'))
        modifier.set_if_first_not_none('predictionApplication',
                                       args.get('prediction_application'))
        modifier.set_if_first_not_none('predictionFlg',
                                       args.get('prediction_flg'))
        modifier.set_if_first_not_none('predictionMethod',
                                       args.get('prediction_method'))
        modifier.set_if_first_not_none('predictionTarget',
                                       args.get('prediction_target'))
        return modifier

    def update_change_info(self, modifier, args):
        modifier.set_if_first_not_none('changeAnalysysRange',
                                       args.get('change_analysis_range'))
        modifier.set_if_first_not_none('changeApplication',
                                       args.get('change_application'))
        modifier.set_if_first_not_none('changeFlg',
                                       args.get('change_flg'))
        return modifier

    def update_numeric_monitor(self, info, args):
        with ObjectModifier(info) as modifier:
            self.update_common_infos(modifier, args)
            self.update_collect_infos(modifier, args)
            self.update_prediction_info(modifier, args)
            self.update_change_info(modifier, args)
            self.updete_judgement_tresholds(modifier, args)
            self.update_notify_ids_info(info, args)

    def prepare_numeric_monitor(self, args, defaults):
        args = prepare_args(args, defaults)
        args['numeric_value_infos'] = self.create_monitor_numeric_value_infos_list(
            args)
        monitor_info = self.create_monitor_info_numeric(args)
        monitor_info = self.fill_prediction_values(monitor_info, args)
        monitor_info = self.fill_change_values(monitor_info, args)

        return args, monitor_info

    def get_monitor_name(self, mon_type_id):
        name = self.mon_type_id2name.get(mon_type_id)
        if name is None:
            name = mon_type_id
        return name

    def change_obj_index_in_list(self, list, old_i, new_i):
        obj = list[old_i]
        del list[old_i]
        list.insert(new_i, obj)
