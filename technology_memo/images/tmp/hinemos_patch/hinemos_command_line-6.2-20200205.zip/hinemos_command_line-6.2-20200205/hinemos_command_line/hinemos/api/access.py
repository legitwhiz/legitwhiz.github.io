# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler

class AccessEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'Access')

    # ログインチェック
    def checkLogin(self):
        try:
            return self._client.service.checkLogin()
        except Exception, e:
            raise ErrorHandler.APIError('checkLogin failed, ' + str(e))

    # ユーザ検索条件に基づき、ユーザ一覧情報を取得する
    def getUserInfoList(self):
        try:
            return self._client.service.getUserInfoList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getUserInfoList failed, ' + str(e))
            raise ErrorHandler.APIError('getUserInfoList failed, ' + str(e))

    # 自身のユーザ情報を取得する
    def getOwnUserInfo(self):
        try:
            return self._client.service.getOwnUserInfo()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getOwnUserInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getOwnUserInfo failed, ' + str(e))

    # ユーザ情報を取得する
    def getUserInfo(self, userId):
        try:
            return self._client.service.getUserInfo(userId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getUserInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getUserInfo failed, ' + str(e))

    # ユーザを追加する
    def addUserInfo(self, userInfo):
        try:
            return self._client.service.addUserInfo(userInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addUserInfo failed, ' + str(e))
            raise ErrorHandler.APIError('addUserInfo failed, ' + str(e))

    # ユーザ情報を変更する
    def modifyUserInfo(self, userInfo):
        try:
            return self._client.service.modifyUserInfo(userInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyUserInfo failed, ' + str(e))
            raise ErrorHandler.APIError('modifyUserInfo failed, ' + str(e))

    # ユーザ情報をパスワード込みで変更する
    def modifyUserInfoWithHashedPassword(self, userInfo):
        try:
            return self._client.service.modifyUserInfoWithHashedPassword(userInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyUserInfoWithHashedPassword failed, ' + str(e))
            raise ErrorHandler.APIError('modifyUserInfoWithHashedPassword failed, ' + str(e))

    # ユーザ情報を削除する
    def deleteUserInfo(self, userIdList):
        try:
            return self._client.service.deleteUserInfo(userIdList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteUserInfo failed, ' + str(e))
            raise ErrorHandler.APIError('deleteUserInfo failed, ' + str(e))

    # 自分自身のパスワードを変更する
    def changeOwnPassword(self, password):
        try:
            return self._client.service.changeOwnPassword(password)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('changeOwnPassword failed, ' + str(e))
            raise ErrorHandler.APIError('changeOwnPassword failed, ' + str(e))

    # パスワードを変更する
    def changePassword(self, userId, password):
        try:
            return self._client.service.changePassword(userId, password)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('ChangePassword failed, ' + str(e))
            raise ErrorHandler.APIError('ChangePassword failed, ' + str(e))

    # ログインしているユーザが指定したユーザ権限を持っているかどうかを確認する
    def isPermission(self, systemPrivilegeInfo):
        try:
            return self._client.service.isPermission(systemPrivilegeInfo)
        except Exception, e:
            raise ErrorHandler.APIError('isPermission failed, ' + str(e))

    # ログインユーザのユーザ名を取得する
    def getUserName(self):
        try:
            return self._client.service.getUserName()
        except Exception, e:
            raise ErrorHandler.APIError('getUserName failed, ' + str(e))

    # バージョン番号を取得する
    def getVersion(self):
        try:
            return self._client.service.getVersion()
        except Exception, e:
            raise ErrorHandler.APIError('getVersion failed, ' + str(e))

    # ロール検索条件に基づき、ロール一覧情報を取得する
    def getRoleInfoList(self):
        try:
            return self._client.service.getRoleInfoList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getRoleInfoList failed, ' + str(e))
            raise ErrorHandler.APIError('getRoleInfoList failed, ' + str(e))

    # ロール情報を取得する
    def getRoleInfo(self, roleId):
        try:
            return self._client.service.getRoleInfo(roleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getRoleInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getRoleInfo failed, ' + str(e))

    # ロールを追加する
    def addRoleInfo(self, roleInfo):
        try:
            return self._client.service.addRoleInfo(roleInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addRoleInfo failed, ' + str(e))
            raise ErrorHandler.APIError('addRoleInfo failed, ' + str(e))

    # ロール情報を変更する
    def modifyRoleInfo(self, roleInfo):
        try:
            return self._client.service.modifyRoleInfo(roleInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyRoleInfo failed, ' + str(e))
            raise ErrorHandler.APIError('modifyRoleInfo failed, ' + str(e))

    # ロール情報を削除する
    def deleteRoleInfo(self, roleIdList):
        try:
            return self._client.service.deleteRoleInfo(roleIdList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteRoleInfo failed, ' + str(e))
            raise ErrorHandler.APIError('deleteRoleInfo failed, ' + str(e))

    # ロールツリー情報を取得する
    def getRoleTree(self):
        try:
            return self._client.service.getRoleTree()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getRoleTree failed, ' + str(e))
            raise ErrorHandler.APIError('getRoleTree failed, ' + str(e))

    # 自身の所属するロールID情報を取得する
    def getOwnerRoleIdList(self):
        try:
            return self._client.service.getOwnerRoleIdList()
        except Exception, e:
            raise ErrorHandler.APIError('getOwnerRoleIdList failed, ' + str(e))

    # システム権限一覧情報を取得する
    def getSystemPrivilegeInfoList(self):
        try:
            return self._client.service.getSystemPrivilegeInfoList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getSystemPrivilegeInfoList failed, ' + str(e))
            raise ErrorHandler.APIError('getSystemPrivilegeInfoList failed, ' + str(e))

    # 指定されたロールIDを条件としてシステム権限一覧情報を取得する
    def getSystemPrivilegeInfoListByRoleId(self, roleId):
        try:
            return self._client.service.getSystemPrivilegeInfoListByRoleId(roleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getSystemPrivilegeInfoListByRoleId failed, ' + str(e))
            raise ErrorHandler.APIError('getSystemPrivilegeInfoListByRoleId failed, ' + str(e))

    # 指定されたユーザIDを条件としてシステム権限一覧情報を取得する
    def getSystemPrivilegeInfoListByUserId(self, userId):
        try:
            return self._client.service.getSystemPrivilegeInfoListByUserId(userId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getSystemPrivilegeInfoListByUserId failed, ' + str(e))
            raise ErrorHandler.APIError('getSystemPrivilegeInfoListByUserId failed, ' + str(e))

    # 指定された編集種別を条件としてシステム権限一覧情報を取得する
    def getSystemPrivilegeInfoListByEditType(self, editType):
        try:
            return self._client.service.getSystemPrivilegeInfoListByEditType(editType)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getSystemPrivilegeInfoListByEditType failed, ' + str(e))
            raise ErrorHandler.APIError('getSystemPrivilegeInfoListByEditType failed, ' + str(e))

    # ロールへのユーザの割り当てを行います
    def assignUserRole(self, roleId, userIds):
        try:
            return self._client.service.assignUserRole(roleId, userIds)
        except Exception, e:
            if "need-role" in str(e):
                raise ErrorHandler.PermissoinError("assignUserRole failed, " + str(e))
            raise ErrorHandler.APIError("assignUserRole failed, " + str(e))

    # ロールIDに紐づくシステム権限情報を差し替える
    def replaceSystemPrivilegeRole(self, roleId, systemPrivileges):
        if systemPrivileges is None:
            systemPrivileges =[]

        # Add default privilege
        is_default_included = False
        for info in systemPrivileges:
            if info.systemFunction == 'Repository' and info.systemPrivilege == 'READ':
                is_default_included = True
                break
        if not is_default_included:
            systemPrivileges.append(self.create_system_privilege_info('Repository', 'READ'))

        try:
            return self._client.service.replaceSystemPrivilegeRole(roleId, systemPrivileges)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('replaceSystemPrivilegeRole failed, ' + str(e))
            raise ErrorHandler.APIError('replaceSystemPrivilegeRole failed, ' + str(e))

    # オブジェクト権限検索条件に基づき、オブジェクト権限一覧情報を取得する
    def getObjectPrivilegeInfoList(self, objectPrivilegeFilterInfo):
        try:
            return self._client.service.getObjectPrivilegeInfoList(objectPrivilegeFilterInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getObjectPrivilegeInfoList failed, ' + str(e))
            raise ErrorHandler.APIError('getObjectPrivilegeInfoList failed, ' + str(e))

    def getObjectPrivilegeInfo(self, objectType, objectId, roleId, objectPrivilege):
        u"""
        オブジェクト権限情報を取得する
        
        @param objectType オブジェクトタイプ
        @param objectId オブジェクトID
        @param roleId ロールID
        @param objectPrivilege オブジェクト権限
        @return オブジェクト権限情報
        @deprecated 本APIは実装していない。引数と取得情報がほぼ同等のため、必要がない。
        """
        try:
            return self._client.service.getObjectPrivilegeInfo(objectType, objectId, roleId, objectPrivilege)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getObjectPrivilegeInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getObjectPrivilegeInfo failed, ' + str(e))

    # オブジェクト種別、オブジェクトIDに紐づくオブジェクト権限情報を差し替える
    def replaceObjectPrivilegeInfo(self, objectType, objectId, ObjectPrivilegeInfoList):
        try:
            return self._client.service.replaceObjectPrivilegeInfo(objectType, objectId, ObjectPrivilegeInfoList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('replaceObjectPrivilegeInfo failed, ' + str(e))
            raise ErrorHandler.APIError('replaceObjectPrivilegeInfo failed, ' + str(e))


    def create_role_info(self, role_id, name=None, description=''):
        # Default
        if description is None:
            description = ''

        obj_name = 'roleInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.roleId = role_id
            info.roleName = name
            info.description = description
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_user_info(self, user_id, name=None, description='' ,mail_address=''):
        # Default
        if description is None:
            description = ''
        if mail_address is None:
            mail_address = ''

        obj_name = 'userInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.userId = user_id
            info.userName = name
            info.description = description
            info.mailAddress = mail_address
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_object_privilege_filter_info(self, object_id=None, object_privilege=None, object_type=None, role_id=None):
        try:
            filter_info = self._client.factory.create('objectPrivilegeFilterInfo')

            if object_id is not None and object_id != '':
                filter_info.objectId = object_id
            if object_privilege is not None and object_privilege != '':
                filter_info.objectPrivilege = object_privilege
            if object_type is not None and  object_type != '':
                filter_info.objectType = object_type
            if role_id is not None and role_id != '':
                filter_info.roleId = role_id
            return filter_info
        except Exception, e:
            raise ErrorHandler.APIError('create objectPrivilegeFilterInfoFailed, ' + str(e))

    def create_system_privilege_info(self, system_function, system_privilege):
        try:
            info = self._client.factory.create('systemPrivilegeInfo')
            info.systemFunction  = system_function
            info.systemPrivilege  = system_privilege
            info.editType = 1

            return info
        except Exception, e:
            raise ErrorHandler.APIError('create systemPrivilegeInfo failed, ' + str(e))

    def create_object_privilege_info(self, role_id, object_privilege):
        try:
            info = self._client.factory.create('objectPrivilegeInfo')
            info.roleId = role_id
            info.objectPrivilege = object_privilege

            return info
        except Exception, e:
            raise ErrorHandler.APIError('create objectPrivilegeInfo failed, ' + str(e))
