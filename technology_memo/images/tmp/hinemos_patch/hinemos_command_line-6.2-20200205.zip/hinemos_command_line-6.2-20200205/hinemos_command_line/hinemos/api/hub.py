#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler

# 収集蓄積機能用のWebAPIエンドポイント
class HubEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'Hub')

    # 引数で指定したログフォーマットIDに対応するログフォーマットを取得します。
    def getLogFormat(self, logFormatId):
        try:
            return self._client.service.getLogFormat(logFormatId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getLogFormat failed, ' + str(e))
            raise ErrorHandler.APIError('getLogFormat failed, ' + str(e))

    # オーナーロールIDを条件としてログフォーマットのID一覧を取得します。
    def getLogFormatIdList(self, ownerRoleId):
        try:
            return self._client.service.getLogFormatIdList(ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getLogFormatIdList failed, ' + str(e))
            raise ErrorHandler.APIError('getLogFormatIdList failed, ' + str(e))

    def getLogFormatList(self):
        try:
            return self._client.service.getLogFormatList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getLogFormatList failed, ' + str(e))
            raise ErrorHandler.APIError('getLogFormatList failed, ' + str(e))

    # オーナーロールIDを条件としてログフォーマット一覧を取得します。
    def getLogFormatListByOwnerRole(self, ownerRoleId):
        try:
            return self._client.service.getLogFormatListByOwnerRole(ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getLogFormatListByOwnerRole failed, ' + str(e))
            raise ErrorHandler.APIError('getLogFormatListByOwnerRole failed, ' + str(e))

    # ログフォーマット情報を登録します。
    def addLogFormat(self, logFormat):
        try:
            return self._client.service.addLogFormat(logFormat)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addLogFormat failed, ' + str(e))
            raise ErrorHandler.APIError('addLogFormat failed, ' + str(e))

    # ログフォーマット情報を変更します。
    def modifyLogFormat(self, logFormat):
        try:
            return self._client.service.modifyLogFormat(logFormat)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyLogFormat failed, ' + str(e))
            raise ErrorHandler.APIError('modifyLogFormat failed, ' + str(e))

    # ログフォーマット情報を 削除します。
    def deleteLogFormat(self, formatIdList):
        try:
            return self._client.service.deleteLogFormat(formatIdList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteLogFormat failed, ' + str(e))
            raise ErrorHandler.APIError('deleteLogFormat failed, ' + str(e))

    # 引数で指定した受け渡し設定IDに対応する受け渡し設定を取得します。
    def getTransferInfo(self, transferId):
        try:
            return self._client.service.getTransferInfo(transferId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getTransferInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getTransferInfo failed, ' + str(e))

    # オーナーロールIDを条件として受け渡し設定ID一覧を取得します。
    def getTransferInfoIdList(self, ownerRoleId):
        try:
            return self._client.service.getTransferInfoIdList(ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getTransferInfoIdList failed, ' + str(e))
            raise ErrorHandler.APIError('getTransferInfoIdList failed, ' + str(e))

    # 受け渡し設定ID一覧を取得します。
    def getTransferInfoList(self):
        try:
            return self._client.service.getTransferInfoList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getTransferInfoList failed, ' + str(e))
            raise ErrorHandler.APIError('getTransferInfoList failed, ' + str(e))

    # オーナーロールIDを条件として受け渡し設定一覧を取得します。
    def getTransferInfoListByOwnerRole(self, ownerRoleId):
        try:
            return self._client.service.getTransferInfoListByOwnerRole(ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getTransferInfoListByOwnerRole failed, ' + str(e))
            raise ErrorHandler.APIError('getTransferInfoListByOwnerRole failed, ' + str(e))

    # 収集蓄積(転送)情報を登録します。
    def addTransferInfo(self, transferInfo):
        try:
            return self._client.service.addTransferInfo(transferInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addTransferInfo failed, ' + str(e))
            raise ErrorHandler.APIError('addTransferInfo failed, ' + str(e))

    # 収集蓄積(転送)情報を変更します。
    def modifyTransferInfo(self, transferInfo):
        try:
            return self._client.service.modifyTransferInfo(transferInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyTransferInfo failed, ' + str(e))
            raise ErrorHandler.APIError('modifyTransferInfo failed, ' + str(e))

    # 収集蓄積(転送)情報を 削除します。
    def deleteTransferInfo(self, transferIdList):
        try:
            return self._client.service.deleteTransferInfo(transferIdList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteTransferInfo failed, ' + str(e))
            raise ErrorHandler.APIError('deleteTransferInfo failed, ' + str(e))

    # 転送先種別リストを取得する
    def getTransferInfoDestTypeMstList(self):
        try:
            return self._client.service.getTransferInfoDestTypeMstList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getTransferInfoDestTypeMstList failed, ' + str(e))
            raise ErrorHandler.APIError('getTransferInfoDestTypeMstList failed, ' + str(e))

    # 文字列収集情報を検索する
    def queryCollectStringData(self, query_info):
        try:
            return self._client.service.queryCollectStringData(query_info)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('queryCollectStringData failed, ' + str(e))
            raise ErrorHandler.APIError('queryCollectStringData failed, ' + str(e))

    def create_logformat(self, logformatId, ownerRoleId, description=None, timestampRegex=None, timestampFormat=None):
        if ownerRoleId is None:
            ownerRoleId = 'ALL_USERS'

        obj_name = 'logFormat'
        try:
            log_format = self._client.factory.create(obj_name)
            log_format.logFormatId = logformatId
            log_format.description = description
            log_format.timestampRegex = timestampRegex
            log_format.timestampFormat = timestampFormat
            log_format.ownerRoleId = ownerRoleId

            return log_format
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_logformat_key(self, format_key):
        obj_name = 'logFormatKey'
        try:
            info = self._client.factory.create(obj_name)
            info.key = format_key
            info.keyType = "parsing" # HC
            info.valueType = "string" # HC
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def get_dest_type_prop_msts(self, dest_type_id):
        # Set destProps by destTypeId
        dest_props = []
        for a in self.getTransferInfoDestTypeMstList():
            if a.destTypeId == dest_type_id:
                dest_props = a.destTypePropMsts
                break
        else:
            raise ErrorHandler.ArgumentError('destType "%s" not exists!' % dest_type_id)
        return dest_props

    def create_transfer_info(self, i_d, or_id):
        # Format inputs
        if or_id is None:
            or_id = 'ALL_USERS'

        obj_name = 'transferInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.transferId = i_d
            info.ownerRoleId = or_id
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))
