# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import re
import hinemos.api.exceptions as ErrorHandler

def create_mail_template_info_list(tree, endpoint):
    flag = True
    mailTemplateInfoList = []
    elem = tree.getroot()
    try:
        for e in elem:
            u'''
            schemaInfoまでの要素をスキップ
            '''
            if flag:
                if e.tag == 'schemaInfo':
                    flag = False
            else:
                u'''
                mailTemplateInfoを生成し、リストに追加
                '''
                info = endpoint.create_object(e.tag)
                temp = str(e.attrib).split(',')
                for s in temp:
                    p = re.compile('\'.*\':')
                    m = p.search(s, 0)
                    if m:
                        attribute = s[m.start()+1:m.end()-2]
                        info[attribute] = e.get(attribute)
                for l in e:
                    info[l.tag] = l.text
                mailTemplateInfoList.append(info)
        return mailTemplateInfoList
    except Exception, e:
        raise ErrorHandler.FileReadError('create mailTemplateInfoList failed, ' + str(e))
