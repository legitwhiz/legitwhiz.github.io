# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

class NotifyUtil(object):
    '''
    NotifyUtil
    '''
    # @see NotifyTypeConstant
    _type_ = ['STATUS', 'EVENT', 'MAIL', 'JOB', 'LOG_ESCALATE', 'COMMAND', 'INFRA']

    _priorities_ = ['CRITICAL','UNKNOWN', 'WARN', 'INFO', '']

    _confirm_flg_ = ['UNCONFIRMED', 'CONFIRMED', 'CONFIRMING']

    _process_after_duration_ = {'DELETE':11, 'REPLACE':12}

    _syslog_facility_ = {'auth':32, 'authpriv':80, 'cron':72, 'daemon':24, 'ftp':88, 'kern':0, 'lpr':48, 'mail':16, 'news':56, 'syslog':40, 'user':8, 'uucp':64, 'local0':128, 'local1':136, 'local2':144, 'local3':152, 'local4':160,'local5':168, 'local6':176, 'local7':184}
    _syslog_severity_ = {'emergency':0, 'alert':1, 'critical':2, 'error':3, 'warning':4, 'notice':5, 'information':6, 'debug':7}

    @staticmethod
    def convert2priority(label):
        #return None if label is None else NotifyUtil._priorities_[label.upper()]
        return None if label is None else NotifyUtil._priorities_.index(label)

    @staticmethod
    def convert2confirm_flg(label):
        return None if label is None else NotifyUtil._confirm_flg_.index(label)

    @staticmethod
    def convert2notify_type(label):
        return None if label is None else NotifyUtil._type_.index(label)

    @staticmethod
    def convert2process_after_duration(label):
        return None if label is None else NotifyUtil._process_after_duration_[label]

    @staticmethod
    def convert2syslog_facility(label):
        return None if label is None else NotifyUtil._syslog_facility_[label]

    @staticmethod
    def convert2syslog_severity(label):
        return None if label is None else NotifyUtil._syslog_severity_[label]

    @staticmethod
    def remove_not_existed(endpoint, notify_relation_infos):
        for i in reversed(xrange(len(notify_relation_infos))):
            noti = notify_relation_infos[i]
            skipNoti = True
            try:
                notifyInfo = endpoint.getNotify(noti.notifyId)
                if str(notifyInfo.notifyType) != str(noti.notifyType):
                    print '[WARN] notifyType not matched!'
                else:
                    skipNoti = False
            except Exception, e:
                print '[WARN]', e
            if skipNoti:
                print 'Notify( NotifyId =', noti.notifyId, ') will be ignored.'
                del notify_relation_infos[i]
