# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api.exceptions import ArgumentError

class HinemosPropertyUtil(object):

    @staticmethod
    def set_hinemos_property_info_value(hinemos_property_info, value):
        if hinemos_property_info.valueType == 1:
            hinemos_property_info.valueString = str(value)
        elif hinemos_property_info.valueType == 2:
            try:
                hinemos_property_info.valueNumeric = int(value)
            except ValueError:
                raise ArgumentError('value must be a integer')
        elif hinemos_property_info.valueType == 3:
            if 'TRUE' == value.upper():
                hinemos_property_info.valueBoolean = True
            elif 'FALSE' == value.upper():
                hinemos_property_info.valueBoolean = False
            else:
                raise ArgumentError('value must be a boolean(TRUE or FALSE)')
        else:
            raise ArgumentError('valueType must be 1-3')
        return hinemos_property_info
