# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

def format_input(element):
    if 'value' in element.attrib:
        if int(element.get('valueType')) == 1:
            element.set('valueString', element.attrib['value'])
        elif int(element.get('valueType')) == 2:
            element.set('valueNumeric', element.attrib['value'])
        elif int(element.get('valueType')) == 3:
            element.set('valueBoolean', element.attrib['value'])

        del element.attrib['value']

def format_output(hinemos_property_info):
    if hinemos_property_info.valueType == 1:
        if hasattr(hinemos_property_info, 'valueString'):
            setattr(hinemos_property_info, 'value', hinemos_property_info.valueString)
            delattr(hinemos_property_info, 'valueString')
    elif hinemos_property_info.valueType == 2:
        if hasattr(hinemos_property_info, 'valueNumeric'):
            setattr(hinemos_property_info, 'value', hinemos_property_info.valueNumeric)
            delattr(hinemos_property_info, 'valueNumeric')
    elif hinemos_property_info.valueType == 3:
        if hasattr(hinemos_property_info, 'valueBoolean'):
            setattr(hinemos_property_info, 'value', hinemos_property_info.valueBoolean)
            delattr(hinemos_property_info, 'valueBoolean')
