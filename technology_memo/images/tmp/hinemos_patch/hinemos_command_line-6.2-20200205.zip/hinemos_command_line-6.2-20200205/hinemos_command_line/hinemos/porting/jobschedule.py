# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import re
import hinemos.api.exceptions as ErrorHandler
from hinemos.porting import elem_attr2info, element2info, rename_tags


# HC for Utility Excel: Remove invalid attributes
def format_file_check_data_elem(elem):
    for a in ('scheduleType', 'week', 'hour', 'minute', 'fromXminutes', 'everyXminutes'):
        if a in elem.attrib:
            del elem.attrib[a]

def create_job_schedule_list(tree, endpoint):
    jobScheduleList = []
    try:
        for el in tree.getroot().iterfind('ScheduleInfo'):
            u'''
            jobSchedule を生成し、リストに追加
            '''
            jobSchedule = endpoint.create_object('jobSchedule')
            jobSchedule.type = 0 #HC

            temp = str(el.attrib).split(',')
            for s in temp:
                p = re.compile('\'.*\':')
                m = p.search(s, 0)
                if m:
                    attribute = s[m.start()+1:m.end()-2]
                    if attribute == 'scheduleId':
                        jobSchedule['id'] = el.get(attribute)
                    elif attribute == 'scheduleName':
                        jobSchedule['name'] = el.get(attribute)
                    elif attribute == 'calId':
                        jobSchedule['calendarId'] = el.get(attribute)
                    elif attribute == 'validFlg':
                        jobSchedule['valid'] = el.get(attribute)
                    else:
                        jobSchedule[attribute] = el.get(attribute)
            u'''
                　　　　　　　　要素がScheduleDataの処理
            '''
            for sd in el:
                temp = str(sd.attrib).split(',')
                for s in temp:
                    p = re.compile('\'.*\':')
                    m = p.search(s, 0)
                    if m:
                        attribute = s[m.start()+1:m.end()-2]
                        jobSchedule[attribute] = sd.get(attribute)
            if jobSchedule.hour == '-1':
                del jobSchedule.hour
            if jobSchedule['calendarId'] == '':
                jobSchedule['calendarId'] = None

            for subelem in el.iterfind('jobRuntimeInfos'):
                subinfo = endpoint.create_object('jobRuntimeParam')

                # fetch details
                for subsubelem in subelem.iterfind('JobRuntimeDetailInfos'):
                    subsubinfo = endpoint.create_object('jobRuntimeParamDetail')
                    tmp = subsubelem.find('orderNo')
                    order_no = 0
                    if tmp is not None:
                        order_no = int(tmp.text) - 1
                        if order_no < 0:
                            order_no = 0
                        subsubelem.remove(tmp)

                    element2info(subsubelem, subsubinfo)
                    subinfo.jobRuntimeParamDetailList.insert(order_no, subsubinfo)
                # Clean up
                while True:
                    subsubelem = subelem.find('JobRuntimeDetailInfos')
                    if subsubelem is not None:
                        subelem.remove(subsubelem)
                    else:
                        break

                rename_lst = (('defaultValue', 'value'),) # TODO Move to porting
                rename_tags(subelem, rename_lst)
                element2info(subelem, subinfo)
                jobSchedule.jobRuntimeParamList.append(subinfo)

            jobScheduleList.append(jobSchedule)
        return jobScheduleList
    except Exception, e:
        raise ErrorHandler.FileReadError('create jobScheduleList failed, ' + str(e))

def create_job_file_check_list(tree, endpoint):
    jobFileCheckList = []
    try:
        for el in tree.getroot().iterfind('FileCheckInfo'):
            u'''
            jobFileCheck を生成し、リストに追加
            '''
            jobFileCheck = endpoint.create_object('jobFileCheck')
            jobFileCheck.type = 1 #HC

            temp = str(el.attrib).split(',')
            for s in temp:
                p = re.compile('\'.*\':')
                m = p.search(s, 0)
                if m:
                    attribute = s[m.start()+1:m.end()-2]
                    if attribute == 'scheduleId':
                        jobFileCheck['id'] = el.get(attribute)
                    elif attribute == 'scheduleName':
                        jobFileCheck['name'] = el.get(attribute)
                    elif attribute == 'calId':
                        jobFileCheck['calendarId'] = el.get(attribute)
                    elif attribute == 'validFlg':
                        jobFileCheck['valid'] = el.get(attribute)
                    else:
                        jobFileCheck[attribute] = el.get(attribute)
            u'''
                　　　　　　　　要素がFileCheckDataの処理
            '''
            for sd in el:

                format_file_check_data_elem(sd)

                temp = str(sd.attrib).split(',')
                for s in temp:
                    p = re.compile(r'\'.*\':')
                    m = p.search(s, 0)
                    if m:
                        attribute = s[m.start()+1:m.end()-2]
                        jobFileCheck[attribute] = sd.get(attribute)

            if jobFileCheck['calendarId'] == '':
                jobFileCheck['calendarId'] = None

            for subelem in el.iterfind('jobRuntimeInfos'):
                subinfo = endpoint.create_object('jobRuntimeParam')

                # fetch details
                for subsubelem in subelem.iterfind('JobRuntimeDetailInfos'):
                    subsubinfo = endpoint.create_object('jobRuntimeParamDetail')
                    tmp = subsubelem.find('orderNo')
                    order_no = 0
                    if tmp is not None:
                        order_no = int(tmp.text) - 1
                        if order_no < 0:
                            order_no = 0
                        subsubelem.remove(tmp)

                    element2info(subsubelem, subsubinfo)
                    subinfo.jobRuntimeParamDetailList.insert(order_no, subsubinfo)
                # Clean up
                while True:
                    subsubelem = subelem.find('JobRuntimeDetailInfos')
                    if subsubelem is not None:
                        subelem.remove(subsubelem)
                    else:
                        break

                rename_lst = (('defaultValue', 'value'),) # TODO Move to porting
                rename_tags(subelem, rename_lst)
                element2info(subelem, subinfo)
                jobFileCheck.jobRuntimeParamList.append(subinfo)

            jobFileCheckList.append(jobFileCheck)
        return jobFileCheckList
    except Exception, e:
        raise ErrorHandler.FileReadError('create jobFileCheckList failed, ' + str(e))

def create_job_manual_list(tree, endpoint):
    jk_lst = []
    try:
        for elem in tree.getroot().iterfind('ManualInfo'):
            u'''
            jobKick(ManualInfo) を生成し、リストに追加
            '''
            info = endpoint.create_object('jobKick')
            info.type = 2 #HC

            rename_lst = {'validFlg':'valid', 'calId':'calendarId'} # TODO Move to porting
            elem_attr2info(elem.attrib, info, rename_lst)
            if 'calendarInfo' in info:
                del info.calendarInfo

            for subelem in elem.iterfind('jobRuntimeInfos'):
                subinfo = endpoint.create_object('jobRuntimeParam')

                # fetch details
                for subsubelem in subelem.iterfind('JobRuntimeDetailInfos'):
                    subsubinfo = endpoint.create_object('jobRuntimeParamDetail')
                    tmp = subsubelem.find('orderNo')
                    order_no = 0
                    if tmp is not None:
                        order_no = int(tmp.text) - 1
                        if order_no < 0:
                            order_no = 0
                        subsubelem.remove(tmp)

                    element2info(subsubelem, subsubinfo)
                    subinfo.jobRuntimeParamDetailList.insert(order_no, subsubinfo)
                # Clean up
                while True:
                    subsubelem = subelem.find('JobRuntimeDetailInfos')
                    if subsubelem is not None:
                        subelem.remove(subsubelem)
                    else:
                        break

                rename_lst = (('defaultValue', 'value'),) # TODO Move to porting
                rename_tags(subelem, rename_lst)
                element2info(subelem, subinfo)
                info.jobRuntimeParamList.append(subinfo)

            jk_lst.append(info)
        return jk_lst
    except Exception, e:
        raise ErrorHandler.FileReadError('create jobManualList failed, ' + str(e))
