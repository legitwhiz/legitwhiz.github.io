#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import inspect
from xml.etree.ElementTree import SubElement
import types
from hinemos.api.exceptions import PortingExportError
from hinemos.util.common import DateConvert
from suds.sax.text import Text

# CODE: ((XMLFilename,XMLRoot), )
xml_list = {\
                 'CAL'    : (('platformCalendar' ,'calendar'), ('platformCalendarPattern', 'calendarPattern')),\
                 'ACC'    : (('platformUser' ,'User'), ('platformRole', 'Role'), ('platformAccountRoleUser', 'AccountRoleUser')),\
                 'NODE'   : (('platformNode', 'RepositoryNode'), ('platformNodeCpu', 'CPUList'), ('platformNodeDevice', 'DeviceList'), ('platformNodeDisk', 'DiskList'), ('platformNodeFilesystem', 'FSList'), ('platformNodeHostname', 'HostnameList'), ('platformNodeMemory', 'MemoryList'), ('platformNodeNetworkinterface', 'NetworkInterfaceList'), ('platformNodeNote', 'NoteList'), ('platformNodeVariable', 'NodeVariableList')),\
                 'SCOPE'  : (('platformScope', 'RepositoryScope'), ('platformScopeNode', 'RepositoryScopeNode')),\
                 'NOTIFY' : (('platformNotify','notify'),),
                 'MAILTPL': (('platformMailtemplate','mailTemplate'),),
                 'MON'    : (('monitorAgent', 'agentMonitors'),('monitorCustom', 'customMonitors'),('monitorCustomTrap', 'customTrapMonitors'),('monitorHttp', 'httpMonitors'),('monitorHttpScenario', 'httpScenarioMonitors'),('monitorJmx', 'jmxMonitors'),('monitorLogfile', 'logfileMonitors'),('monitorPerf', 'perfMonitors'),('monitorPing', 'pingMonitors'),('monitorPort', 'portMonitors'),('monitorProcess', 'processMonitors'),('monitorSnmp', 'snmpMonitors'),('monitorSnmpTrap', 'snmpTrapMonitors'),('monitorSql', 'sqlMonitors'),('monitorSyslog', 'syslogMonitors'),('monitorWinevent', 'winEventMonitors'),('monitorWinservice', 'winServiceMonitors')),
                 'JOB'    : (('jobMaster', 'jobMasters'),),
                 'JOBSCH' : (('jobSchedule', 'ScheduleList'), ('jobFileCheck', 'FileCheckList'), ('jobManual', 'ManualList')),
                 'JMX'    : (('masterJmx', 'JmxMaster'),),
                 'INFRA'  : (('infraManagement' ,'infraManagement'), ('infraFile', 'InfraFile')),\
                 'MT'     : (('platformMaintenance','maintenance'),),
                 'HBTRN'  : (('hubTransfer','transfer'),),
                 'LGFMT'  : (('platformLogFormat','logFormat'),),
                 'PROP'   : (('platformHinemosProperty','HinemosProperty'),),
                 'SYSPRIV': (('platformSystemPrivilege' ,'SystemPrivilege'),),\
                 'OBJPRIV': (('platformObjectPrivilege' ,'ObjectPrivilege'),),\
                 }

xml_schema = {\
                'platformNode'                : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformNodeHostname'        : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformNodeCpu'             : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformNodeMemory'          : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformNodeNetworkinterface': {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformNodeDisk'            : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformNodeFilesystem'      : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformNodeDevice'          : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformNodeVariable'        : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformNodeNote'            : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformScope'               : {'XSD':None, 'SCHEMATYPE':'E', 'SCHEMAVER':1},\
                'platformScopeNode'           : {'XSD':None, 'SCHEMATYPE':'E', 'SCHEMAVER':1},\
                'platformNotify'              : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformMailtemplate'        : {'XSD':None, 'SCHEMATYPE':'E', 'SCHEMAVER':1},\
                'platformCalendar'            : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformCalendarPattern'     : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformMaintenance'         : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformUser'                : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformRole'                : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformAccountRoleUser'     : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformSystemPrivilege'     : {'XSD':None, 'SCHEMATYPE':'F', 'SCHEMAVER':1},\
                'platformObjectPrivilege'     : {'XSD':None, 'SCHEMATYPE':'F', 'SCHEMAVER':1},\
                'monitorPing'                 : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorPerf'                 : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorPort'                 : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorHttp'                 : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorSql'                  : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorWinservice'           : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorProcess'              : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorSnmpTrap'             : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorSyslog'               : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorWinevent'             : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorLogfile'              : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorAgent'                : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorSnmp'                 : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorCustom'               : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorCustomTrap'           : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'jobMaster'                   : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'jobSchedule'                 : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'jobFileCheck'                : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'jobManual'                   : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'hubTransfer'                 : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'platformLogFormat'           : {'XSD':None, 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                #'collectorPlatformMaster'    : {'XSD':None, 'SCHEMATYPE':'E', 'SCHEMAVER':1},\
                #'collectorMaster'            : {'XSD':None, 'SCHEMATYPE':'E', 'SCHEMAVER':1},\
                'platformHinemosProperty'     : {'XSD':'maintenance_hinemosproperty.xsd', 'SCHEMATYPE':'G', 'SCHEMAVER':1},\
                'monitorHttpScenario'         : {'XSD':'monitor_check_http_scenario.xsd', 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'monitorJmx'                  : {'XSD':'monitor_check_jmx.xsd'          , 'SCHEMATYPE':'H', 'SCHEMAVER':1},\
                'infraManagement'             : {'XSD':'infra_management.xsd'           , 'SCHEMATYPE':'G', 'SCHEMAVER':1},\
                'infraFile'                   : {'XSD':'infra_file.xsd'                 , 'SCHEMATYPE':'G', 'SCHEMAVER':1},\
                'masterJmx'                   : {'XSD':'master_jmx.xsd'                 , 'SCHEMATYPE':'G', 'SCHEMAVER':1},\
                 }

def append_obj2element_atype(parent, obj, tag_name=None, formatter=None):
    # Format object
    if formatter: formatter(obj)

    # Fetch attributes, obj attr -> element attr
    attributes = {}
    for attr in dir(obj):
        if not attr.startswith('__'):
            val = getattr(obj, attr)

            t = type(val)
            if val is None:
                attributes[attr] = ''
            elif isinstance(val, Text) or t is types.StringType:
                attributes[attr] = val
            elif t is types.IntType or t is types.LongType or t is types.FloatType:
                attributes[attr] = str(val)
            elif t is types.BooleanType:
                attributes[attr] = str(val).lower() # Must be true / false
            else:
                raise PortingExportError('failed to fetch value from attribute "%s" (%s, %s)' % (attr, t, str(val)))

    if tag_name is None:
        tag_name = obj.__class__.__name__
    return SubElement(parent, tag_name, attributes)

def append_obj2element_mixedtype(parent, obj, item_name=None, rename_list=None, ypath=None):
    if item_name is None:
        item_name = obj.__class__.__name__
    t = type(obj)

    str_value = None
    if obj is None:
        str_value = ''
    elif isinstance(obj, Text) or t is types.StringType:
        str_value = obj
    elif t is types.IntType or t is types.LongType or t is types.FloatType:
        str_value = str(obj)
    elif t is types.BooleanType:
        str_value = str(obj).lower()

    if str_value is not None:
        # Rename attribute
        cur_ypath = ypath + '@' + item_name
        if rename_list and cur_ypath in rename_list:
            item_name = rename_list[cur_ypath]
        parent.set(item_name, str_value)

    elif t is types.InstanceType:
        if ypath is None:
            cur_ypath = ''
        else:
            cur_ypath = ypath + '/' + item_name

        elem = SubElement(parent, item_name)
        for attr in dir(obj):
            if not attr.startswith('__'):
                obj_child = getattr(obj, attr)
                t2 = type(obj_child)
                if t2 is not types.BuiltinMethodType and t2 is not types.MethodType:
                    append_obj2element_mixedtype(elem, obj_child, attr, rename_list, cur_ypath)
        return elem
    elif t is types.ListType:
        for x in obj:
            if type(x) is types.InstanceType:
                append_obj2element_mixedtype(parent, x, None, rename_list, ypath)
            else:
                raise PortingExportError('failed to fetch value from %s list, "%s"' % (item_name, str(obj)))
    else:
        raise PortingExportError('failed to fetch value from %s, %s, "%s"' % (item_name, str(t), str(obj)))

def append_obj2element_ttype(parent, obj, tag_name=None):
    if tag_name is None:
        tag_name = obj.__class__.__name__

    t = type(obj)
    if obj is None:
        elem = SubElement(parent, tag_name)
        return elem
    elif isinstance(obj, Text) or t is types.StringType:
        elem = SubElement(parent, tag_name)
        elem.text = obj
        return elem
    elif t is types.InstanceType:
        elem = SubElement(parent, tag_name)
        for attr in dir(obj):
            if not attr.startswith('__'):
                obj_child = getattr(obj, attr)
                t2 = type(obj_child)
                if t2 is not types.BuiltinMethodType and t2 is not types.MethodType:
                    append_obj2element_ttype(elem, obj_child, attr)
        return elem
    elif t is types.IntType or t is types.LongType or t is types.FloatType:
        elem = SubElement(parent, tag_name)
        elem.text = str(obj)
        return elem
    elif t is types.BooleanType:
        elem = SubElement(parent, tag_name)
        elem.text = str(obj).lower()
        return elem
    elif t is types.ListType:
        for x in obj:
            if type(x) is types.InstanceType:
                append_obj2element_ttype(parent, x, tag_name)
            else:
                elem = SubElement(parent, tag_name)
                append_obj2element_ttype(elem, x, tag_name)
    elif t is types.DictType: # Customized attribute
        elem = SubElement(parent, tag_name)
        for k,v in obj.iteritems():
            append_obj2element_ttype(elem, v, k)
        return elem
    else:
        raise PortingExportError('failed to fetch value from %s, "%s"' % (str(t), str(obj)))

def rename_tags(element, rename_list):
    for x in reversed(rename_list):
        for child in element.iterfind(x[0]):
            child.tag = x[1]

def elem_attr2info(attributes, info, rename_list=None):
    for k, v in attributes.iteritems():
        if rename_list and k in rename_list:
            k = rename_list[k]
        if k in info:
            info[k] = v
        else:
            print('BAD attribute : %s = "%s"' % (k, v))

def element2info_by_infoattr(element, info, cleanup=False):
    for attr_name in dir(info):
        if not attr_name.startswith('__') and info[attr_name] is None:
            subelem = element.find(attr_name)
            if subelem is not None:
                info[attr_name] = subelem.text
                if cleanup:
                    element.remove(subelem)

def element2info(element, info, cleanup=False):
    for x in element.findall('*'):
        if x.tag in info:
            attr_name = x.tag
            if len(x) > 0:
                print('BAD element : <%s> has %d child(ren)' % (x.tag, len(x)))
            else:
                if x.text is None:
                    x.text = ''
 
                info[attr_name] = x.text
                if cleanup:
                    element.remove(x)
        else:
            print('BAD attribute not found in object : %s' % x.tag)

def check_clean(element):
    if len(element) != 0:
        print('<%s> is not yet clean!' % element.tag)
        for x in element:
            print('\t%s - %s' % (x.tag, x.text))

def info2xdata(info):
    ''' Convert info(SOAP object) to dictionary recursively
    Output format: [
     {"tagname1": "Text value"},   => <tagname1>Text value</tagname1>
     {"tagname2": {'attr1':'value1', ...}},   => <tagname2 attr1=value1 ... />
     {"tagname3": ...}, {"tagname3": ...}, {"tagname3": ...}, ... => LIST are simply shown with same tag name
     [{"subtag1": }, ... ] => Subelement
    ]'''
    xdata = []
    for name in dir(info):
        if not name.startswith('__'):
            obj = getattr(info, name)
            if not type(obj) in (types.BuiltinFunctionType, types.MethodType, types.FunctionType):
                #if not isinstance(v, (basestring, long, float, bool, int)):
                if type(obj) is types.InstanceType:
                    xdata.append({name: info2xdata(obj)})
                elif isinstance(obj, list):
                    for a in obj:
                        if type(a) is types.InstanceType:
                            xdata.append({name: info2xdata(a)})
                        else:
                            #if isinstance(a, basestring): # Probably 'suds.sax.text.Text'
                            xdata.append({name: a})
                else:
                    xdata.append({name: obj})
    return xdata

def str_xdata(xdata):
    for a in xdata:
        if isinstance(a, dict):
            (k,v) = a.items()[0]

            if isinstance(v, basestring) or v is None: # Raw value or None
                pass
            # WARN: isinstance(True, int) == True
            elif isinstance(v, bool): # Raw bool value
                a[k] = str(v).lower()
            elif isinstance(v, (int, long, float)): # Raw numeric value
                a[k] = str(v)
            elif isinstance(v, dict): # Attributes and embeded children
                for k2,v2 in v.iteritems():
                    if k2 == ':CHILDREN:':
                        v2 = str_xdata(v2)
                    else:
                        if isinstance(v2, basestring) or v2 is None:
                            pass
                        elif isinstance(v2, (int, long, float)):
                            v[k2] = str(v2)
                        elif isinstance(v2, bool):
                            v[k2] = str(v2).lower()
            elif isinstance(v, list): # New tag (:children:)
                    v = str_xdata(v)
            else:
                raise PortingExportError('Failed to fetch value from %s: "%s"' % (k, str(v)))
        else:
            raise PortingExportError('Failed to fetch tag data: %s' % a)
    return xdata

def xdata_find(xdata, xpath, curr_path=''):
    # Fetch path
    xpaths = xpath.split('/', 1)
    curr_node = xpaths[0]
    next_xpath = None
    if len(xpaths) == 2:
        next_xpath = xpaths[1]
    curr_path = '/'.join([curr_path, curr_node])

    for a in xdata:
        # a must be a dict, otherwise it won't even pass format_xdata/str_xdata
        if curr_node in a:
            if next_xpath is None:
                return a
            else:
                # a[curr_node] must be a list(sub xdata element)
                return xdata_find(a[curr_node], next_xpath, curr_path)
            break
    return None

def xdata_set(xdata, xpath, val, curr_path=''):
    target = xdata_find(xdata, xpath, curr_path)
    (k,_) = target.items()[0]
    target[k] = val
    # TODO raise PortingExportError('xdata_find failed: %s' % curr_path)

def xdata_get(xdata, xpath, curr_path=''):
    target = xdata_find(xdata, xpath, curr_path)
    (_,v) = target.items()[0]
    return v
    # TODO raise PortingExportError('xdata_find failed: %s' % curr_path)

def xdata_has(xdata, xpath, curr_path=''):
    return xdata_find(xdata, xpath) is not None

def xdata_del(xdata, xpath, curr_path=''):
    #target = xdata_find(xdata, xpath, curr_path)
    #print target
    #del target
    # Fetch path
    xpaths = xpath.split('/', 1)
    curr_node = xpaths[0]
    next_xpath = None
    if len(xpaths) == 2:
        next_xpath = xpaths[1]
    curr_path = '/'.join([curr_path, curr_node])

    for a in xdata:
        # a must be a dict, otherwise it won't even pass format_xdata/str_xdata
        if curr_node in a:
            if next_xpath is None:
                xdata.remove(a)
                return True
            else:
                # a[curr_node] must be a list(sub xdata element)
                return xdata_del(a[curr_node], next_xpath, curr_path)
            break
    return False

def xdata_find_bycond(xdata, xpath, val, curr_path=''):
    # Fetch path
    xpaths = xpath.split('/', 1)
    curr_node = xpaths[0]
    next_xpath = None
    if len(xpaths) == 2:
        next_xpath = xpaths[1]
    curr_path = '/'.join([curr_path, curr_node])

    found = None
    for a in xdata:
        # a must be a dict, otherwise it won't even pass format_xdata/str_xdata
        if curr_node in a:
            if next_xpath is None:
                if a[curr_node] == val:
                    found = a
                    break
            else:
                # a[curr_node] must be a list(sub xdata element)
                found_tmp = xdata_find_bycond(a[curr_node], next_xpath, val, curr_path)
                if found_tmp:
                    found = a
                    break
    return found

def xdata_remove_bycond(xdata, xpath, val):
    ''' Remove a whole branch from root with the condition(xpath=val) matched '''
    target = xdata_find_bycond(xdata, xpath, val)
    if target is None:
        raise PortingExportError('xdata_remove_bycond failed: %s = %s' % (xpath, val))
    else:
        xdata.remove(target)

def xdata_findall(xdata, xpath, curr_path=''):
    # Fetch path
    xpaths = xpath.split('/', 1)
    curr_node = xpaths[0]
    next_xpath = None
    if len(xpaths) == 2:
        next_xpath = xpaths[1]
    curr_path = '/'.join([curr_path, curr_node])

    found = []
    for a in xdata:
        # a must be a dict, otherwise it won't even pass format_xdata/str_xdata
        if curr_node in a:
            if next_xpath is None:
                found.append(a)
            else:
                # a[curr_node] must be a list(sub xdata element)
                found.extend(xdata_findall(a[curr_node], next_xpath, curr_path))
            #break Do not break here
    # Only remove if exists
    #if not removed:
    #    raise PortingExportError('xdata_removeall failed: %s' % curr_path)
    return found

def xdata_removeall(xdata, xpath, curr_path=''):
    # Fetch path
    xpaths = xpath.split('/', 1)
    curr_node = xpaths[0]
    next_xpath = None
    if len(xpaths) == 2:
        next_xpath = xpaths[1]
    curr_path = '/'.join([curr_path, curr_node])

    removed = []
    for i,v in enumerate(xdata):
        # a must be a dict, otherwise it won't even pass format_xdata/str_xdata
        if curr_node in v:
            if next_xpath is None:
                removed.append(v)
                xdata[i] = None
            else:
                # a[curr_node] must be a list(sub xdata element)
                removed.extend(xdata_removeall(v[curr_node], next_xpath, curr_path))
            #break Do not break here
    if removed:
        # Clean empty node
        while None in xdata:
            xdata.remove(None)
    # Only remove if exists
    #else:
    #    raise PortingExportError('xdata_removeall failed: %s' % curr_path)
    return removed

def xdata_appendforce(xdata, xpath, val):
    # Fetch path
    xpaths = xpath.split('/', 1)
    curr_tag = xpaths[0]
    next_xpath = None
    if len(xpaths) == 2:
        next_xpath = xpaths[1]

    if next_xpath is None:
        xdata.append({curr_tag: val})
    else:
        # scan
        found_node = None
        for a in xdata:
            # a must be a dict, otherwise it won't even pass format_xdata/str_xdata
            if curr_tag in a:
                found_node = a
        # Add if not exists yet
        if found_node is None:
            # Just append a None
            found_node = {curr_tag: []}
            xdata.append(found_node)
        sub_xdata = found_node[curr_tag]
        xdata_appendforce(sub_xdata, next_xpath, val)

def xdata_appendas(xdata, to_path, node):
    (_,v) = node.items()[0]
    xdata_appendforce(xdata, to_path, v)

def xdata_rename(xdata, from_path, new_name):
    tmp = xdata_findall(xdata, from_path)
    for a in tmp:
        (_,v) = a.popitem()
        a[new_name] = v

def reorganize_xdata(xdata, from_path, to_path):
    tmp = xdata_removeall(xdata, from_path)
    if to_path is None:
        pass # Just remove
    else:
        for a in tmp:
            xdata_appendas(xdata, to_path, a)

def format_xdata(xdata, convlst_timestamp=None, convmap_attrs=None, convmap_move_tags=None, convmap_rename_tags=None):
    # 1. First convert to timestamp
    if convlst_timestamp:
        for a in convlst_timestamp:
            xdata_set(xdata, a, DateConvert.get_datetime_from_epochtime(xdata_get(xdata, a)))

    # 2.convert all to string for XML serializing
    str_xdata(xdata)

    # 3. Finally, reorganize it
    if convmap_attrs:
        pass # TODO FIXME
    if convmap_move_tags:
        for from_path, to_path in convmap_move_tags:
            reorganize_xdata(xdata, from_path, to_path)
    if convmap_rename_tags:
        for from_path, new_name in convmap_rename_tags:
            xdata_rename(xdata, from_path, new_name)
    return xdata

def add_xdata_as_element(elem, tag_name, xdata):
    subelem = SubElement(elem, tag_name)
    xdata2element(xdata, subelem)

def xdata2element(xdata, elem):
    ''' Support input: [
        {"tagname1": "Text value"},              => <tagname1>Text value</tagname1>
        {"tagname2": {'attr1':'value1', ...}},   => <tagname2 attr1=value1 ... />
        {"tagname3": ...}, {"tagname3": ...}, {"tagname3": ...}, ... => LIST are simply shown with same tag name
        [{"subtag1": }, ... ]                    => Subelement
    ]'''
    for a in xdata:
        # a must be a dict, otherwise it won't even pass format_xdata/str_xdata
        (k,v) = a.items()[0]

        # Ignore None tags
        if v is None:
            continue

        subelem = SubElement(elem, k)
        if isinstance(v, basestring):
            subelem.text = v
        elif isinstance(v, list):
            xdata2element(v, subelem)
        elif isinstance(v, dict): # Attributes and embeded children
            if 'ATTR' in v:
                subelem.attrib.update(v['ATTR'])
            if 'TEXT' in v:
                subelem.text = v['TEXT']
            if 'CHILD' in v:
                for a in v['CHILD']:
                    xdata2element(a, subelem)
        #else:
        #    if not None:
        #    raise PortingExportError('failed to fetch value %s = %s' % (k, v))
    return elem
