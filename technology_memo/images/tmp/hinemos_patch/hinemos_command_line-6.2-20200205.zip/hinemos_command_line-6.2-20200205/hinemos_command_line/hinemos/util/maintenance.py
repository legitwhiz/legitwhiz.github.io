#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

class MaintenanceSettingUtil(object):
    '''
    MaintenanceSettingUtil
    '''

    # @see getMaintenanceType()
    _type_ = ('DELETE_EVENT_LOG_ALL', 'DELETE_EVENT_LOG', 'DELETE_JOB_HISTORY_ALL', 'DELETE_JOB_HISTORY', 'DELETE_COLLECT_DATA_RAW', 'DELETE_SUMMARY_DATA_HOUR', 'DELETE_SUMMARY_DATA_DAY', 'DELETE_SUMMARY_DATA_MONTH', 'DELETE_COLLECT_STRING_DATA')

