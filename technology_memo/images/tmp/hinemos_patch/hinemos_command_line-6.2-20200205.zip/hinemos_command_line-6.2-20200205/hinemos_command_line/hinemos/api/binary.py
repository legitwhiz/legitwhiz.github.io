# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------
import re
import os
from hinemos.api.endpoint import Endpoint
from hinemos.util import binary as util
import hinemos.api.exceptions as ErrorHandler


class BinaryEndpoint(Endpoint):
    '''
        BinaryEndpoint
    '''

    def __init__(self, hm_url, user, passwd, **kwargs):
        super(BinaryEndpoint, self).__init__(hm_url, user, passwd, 'Binary',
                                             **kwargs)

    def manageBinaryData(self, args):
        query = util.create_binary_query(self, args)
        res = self.queryCollectBinaryData(query)

        if args['download'] is None:
            return res
        elif args['download'] == 'ONE':
            primaryKey, fileName = util.prepare_binary_record_download(
                args, res)
            self.downloadBinaryRecord(query, primaryKey, fileName,
                                      args['clientName'], args['dir'])
        elif args['download'] == 'ALL':
            fileName, downloadList = util.prepare_binary_records_download(
                args, res, query)
            self.downloadBinaryRecords(fileName, downloadList,
                                       args['clientName'], args['dir'])

    def queryCollectBinaryData(self, query):
        '''収集バイナリデータ検索

        :param query: BinaryQueryInfo
        :returns: StringQueryResult
        :throws: InvalidUserPass_Exception | InvalidRole_Exception
        | HinemosUnknown_Exception | HinemosDbTimeout_Exception
        | InvalidSetting_Exception
        '''
        try:
            res = self._client.service.queryCollectBinaryData(query)
            return res
        except Exception, e:
            if "need-role" in str(e):
                raise ErrorHandler.PermissoinError(
                    'queryCollectBinaryData failed, ' + str(e))
            raise ErrorHandler.APIError(
                'queryCollectBinaryData failed, ' + str(e))
        '''
            binaryQuery = makeNewBinaryQuery();
            OR
            binaryQuery = makeContinuousBinaryQuery(0,
             getDataCountPerPage(getTable()));

        '''

    def getPresetList(self):
        '''プリセット(データ構造)の一覧を取得する

        :returns: プリセットの一覧
        :raises PermissoinError: If the permission is not granted
        :raises APIError: If there is anything else wrong
        '''
        try:
            res = self._client.service.getPresetList()
            return res
        except Exception, e:
            if "need-role" in str(e):
                raise ErrorHandler.PermissoinError(
                    'getPresetList failed, ' + str(e))
            raise ErrorHandler.APIError('getPresetList failed, ' + str(e))

    def downloadBinaryRecord(self, queryInfo, primaryKey,
                             filename, clientName, output_dir):
        try:
            res = self._client.service.downloadBinaryRecord(
                queryInfo, primaryKey, filename, clientName)
            self.deleteDownloadedBinaryRecord(filename, clientName)
            if res is not None:
                with open(os.path.join(output_dir, filename), 'w') as f:
                    f.write(res)
        except Exception, e:
            if "need-role" in str(e):
                raise ErrorHandler.PermissoinError(
                    'downloadBinaryRecord failed, ' + str(e))
            raise ErrorHandler.APIError('downloadBinaryRecord failed, '
                                        + str(e))

    def downloadBinaryRecords(self, filename, binaryDownloadDTOList,
                              clientName, output_dir):
        try:
            res = self._client.service.downloadBinaryRecords(
                filename, binaryDownloadDTOList, clientName)
            self.deleteDownloadedBinaryRecord(filename, clientName)
            if res is not None:
                with open(os.path.join(output_dir, filename), 'w') as f:
                    f.write(res)
        except Exception, e:
            if "need-role" in str(e):
                raise ErrorHandler.PermissoinError(
                    'downloadBinaryRecords failed, ' + str(e))
            raise ErrorHandler.APIError('downloadBinaryRecords failed, ' + str(e))

    def deleteDownloadedBinaryRecord(self, fileName, clientName):
        try:
            res = self._client.service.deleteDownloadedBinaryRecord(
                fileName, clientName)
        except Exception, e:
            if "need-role" in str(e):
                raise ErrorHandler.PermissoinError(
                    'deleteDownloadedBinaryRecord failed, ' + str(e))
            raise ErrorHandler.APIError('deleteDownloadedBinaryRecord failed, '
                                        + str(e))
