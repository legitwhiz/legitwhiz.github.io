#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import re
from datetime import datetime
from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.calendar import CalendarUtil
from hinemos.util.modifier import ObjectModifier
import time

# HC for Utility data consistence
def formatted_info(info, username):
    if hasattr(info, 'description') and '' == info.description:
        info.description = None

    if hasattr(info, 'calendarId') and '' == info.calendarId:
        info.calendarId = None

    # Bad HC!
    if hasattr(info, 'regUser'):
        info.regUser = username
    if hasattr(info, 'updateUser'):
        info.updateUser = username

    # Bad HC!
    if not hasattr(info, 'regDate'):
        setattr(info, 'regDate', int(time.time() * 1000)) #HC
    elif info.regDate is None:
        info.regDate = int(time.time() * 1000) #HC

    if not hasattr(info, 'updateDate'):
        setattr(info, 'updateDate', int(time.time() * 1000)) #HC
    elif info.updateDate is None:
        info.updateDate = int(time.time() * 1000) #HC

    #HC for Utility Excel: do not have notifyGroupId tag
    if not hasattr(info, 'notifyGroupId'):
        setattr(info, 'notifyGroupId', None)
    if info.notifyGroupId is None or '' == info.notifyGroupId:
        info.notifyGroupId = 'MAINTENANCE-' + info.maintenanceId+'-0'

    if not hasattr(info, 'notifyId'):
        setattr(info, 'notifyId', [])
    for a in info.notifyId:
        if a.notifyGroupId is None or '' == a.notifyGroupId:
            a.notifyGroupId = 'MAINTENANCE-' + info.maintenanceId+'-0'

    #HC for Utility Excel: remove blank schedule fields
    if not hasattr(info, 'schedule'):
        setattr(info, 'schedule', None)
    if info.schedule is not None:
        if hasattr(info.schedule, 'hour') and '' == info.schedule.hour:
            info.schedule.hour = None
        if hasattr(info.schedule, 'minute') and '' == info.schedule.minute:
            info.schedule.minute = None
        if hasattr(info.schedule, 'day') and '' == info.schedule.day:
            info.schedule.day = None
        if hasattr(info.schedule, 'week') and '' == info.schedule.week:
            info.schedule.week = None
        if hasattr(info.schedule, 'month') and '' == info.schedule.month:
            info.schedule.month = None

    return info

class MaintenanceEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'Maintenance')

    # メンテナンス情報を追加します
    def addMaintenance(self, maintenanceInfo):
        try:
            return self._client.service.addMaintenance(formatted_info(maintenanceInfo, self._client.options.transport.credentials()[0]))
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addMaintenance failed, ' + str(e))
            raise ErrorHandler.APIError('addMaintenance failed, ' + str(e))

    # メンテナンス情報を変更します
    def modifyMaintenance(self, maintenanceInfo):
        try:
            return self._client.service.modifyMaintenance(formatted_info(maintenanceInfo, self._client.options.transport.credentials()[0]))
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyMaintenance failed, ' + str(e))
            raise ErrorHandler.APIError('modifyMaintenance failed, ' + str(e))

    # メンテナンス情報を削除します
    def deleteMaintenance(self, maintenanceId):
        try:
            return self._client.service.deleteMaintenance(maintenanceId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteMaintenance failed, ' + str(e))
            raise ErrorHandler.APIError('deleteMaintenance failed, ' + str(e))

    # メンテナンス情報を取得します
    def getMaintenanceInfo(self, maintenanceId):
        try:
            return self._client.service.getMaintenanceInfo(maintenanceId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getMaintenanceInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getMaintenanceInfo failed, ' + str(e))

    # メンテナンス情報の一覧を取得します
    def getMaintenanceList(self):
        try:
            return self._client.service.getMaintenanceList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getMaintenanceList failed, ' + str(e))
            raise ErrorHandler.APIError('getMaintenanceList failed, ' + str(e))

    # メンテナンス種別の一覧を取得します
    def getMaintenanceTypeList(self):
        try:
            return self._client.service.getMaintenanceTypeList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getMaintenanceTypeList failed, ' + str(e))
            raise ErrorHandler.APIError('getMaintenanceTypeList failed, ' + str(e))

    # メンテナンスの有効、無効を変更するメソッドです
    def setMaintenanceStatus(self, maintenanceId, validFlag):
        try:
            return self._client.service.setMaintenanceStatus(maintenanceId, validFlag)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('setMaintenanceStatus failed, ' + str(e))
            raise ErrorHandler.APIError('setMaintenanceStatus failed, ' + str(e))


    def create_notify_relation_info(self, notify_info, maintenance_id):
        obj_name = 'notifyId'
        try:
            info = self._client.factory.create(obj_name)
            info.notifyGroupId = 'MAINTENANCE-' + maintenance_id +'-0'
            info.notifyId = notify_info.notifyId
            info.notifyType = notify_info.notifyType
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_schedule_from_str(self, schedule_str):
        schedule_type = None
        month = None
        day = None
        hour = None
        minute = None
        week = None

        try:
            matches = re.match(r'(\d+):(\d+)', schedule_str)
            if matches:
                datetime.strptime(schedule_str, '%H:%M')
                hour = int(matches.group(1))
                minute = int(matches.group(2))
                schedule_type = 1

            if not matches:
                matches =  re.match(r'(\d+) (\d+):(\d+)', schedule_str)
                if matches:
                    datetime.strptime(schedule_str, '%d %H:%M')
                    day = int(matches.group(1))
                    hour = int(matches.group(2))
                    minute = int(matches.group(3))
                    schedule_type = 1

            if not matches:
                matches = re.match(r'(\w+) (\d+):(\d+)', schedule_str)
                if matches:
                    datetime.strptime(schedule_str, '%a %H:%M')
                    week = CalendarUtil.convert2weekday(matches.group(1))
                    hour = int(matches.group(2))
                    minute = int(matches.group(3))
                    schedule_type = 2

            if not matches:
                matches = re.match(r'(\d+)/(\d+) (\d+):(\d+)', schedule_str)
                if matches:
                    datetime.strptime(schedule_str, '%m/%d %H:%M')
                    month = int(matches.group(1))
                    day = int(matches.group(2))
                    hour = int(matches.group(3))
                    minute = int(matches.group(4))
                    schedule_type = 1
            if not matches:
                raise ValueError
        except (ValueError, KeyError):
            raise ErrorHandler.ArgumentError('schedule format is not correct - [[mm/]DD or WEEKDAY] HH:MM')

        return self.create_schedule(schedule_type, month, day, week, hour, minute)

    def create_schedule(self, schedule_type, month, day, week, hour, minute):
        # Validate
        assert schedule_type in (1, 2)
        assert hour is not None and minute is not None
        if schedule_type == 2:
            assert week is not None and 0 <= week and week <= 7
        if month is not None:
            assert day is not None

        obj_name = 'ns0:schedule'
        try:
            info = self._client.factory.create(obj_name)
            info.day = day
            info.hour = hour
            info.minute = minute
            info.month = month
            info.type = schedule_type
            info.week = week
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_maintenance_info(self, maintenance_id, type_id, data_retention_period, application, schedule,\
                                calendar_id=None, description=None, owner_role_id=None, valid_flg=None, notify_infos=None):
        # Default
        if description is None:
            description = ''
        if valid_flg is None:
            valid_flg = 1
        if owner_role_id is None:
            owner_role_id = 'ALL_USERS'

        # Validate
        assert schedule

        obj_name = 'maintenanceInfo'
        try:
            info = self._client.factory.create(obj_name)

            notify_group_id = 'MAINTENANCE-' + maintenance_id + '-0'

            ObjectModifier.replace_if_not_none(info,\
                maintenanceId = maintenance_id,\
                typeId = type_id,\
                dataRetentionPeriod = data_retention_period,\
                application = application,\
                schedule = schedule,\
                notifyGroupId = notify_group_id,\
                calendarId = calendar_id,\
                description = description,\
                ownerRoleId = owner_role_id,\
                validFlg = valid_flg)

            if notify_infos is not None:
                notify_relation_infos = []
                for a in notify_infos:
                    notify_relation_infos.append(self.create_notify_relation_info(a, maintenance_id))
                info.notifyId = notify_relation_infos

            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))
