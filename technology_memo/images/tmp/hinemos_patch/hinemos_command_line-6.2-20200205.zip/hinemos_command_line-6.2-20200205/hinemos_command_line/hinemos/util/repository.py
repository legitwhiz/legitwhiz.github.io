# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.util.common import DateConvert
from hinemos.model.repository import nodeListInfo, facilityListInfo, facilityInfo, propertyNON, nodePropertyBySNMPInfo, nodeHostnameInfo, nodeCpuInfo, nodeNetworkInterfaceInfo, nodeDiskInfo, nodeFilesystemInfo


class RepositoryUtil(object):
    '''
    Repository Utility
    '''

    # @see com.clustercontrol.bean.HinemosModuleConstant
    _monitor_type_ = ('MONITOR_AGENT', 'MONITOR_CUSTOM_N', 'MONITOR_CUSTOM_S', 'MONITOR_HTTP_N', 'MONITOR_HTTP_S', 'MONITOR_HTTP_SCENARIO', 'MONITOR_PERFORMANCE', 'MONITOR_PING', 'MONITOR_PORT', 'MONITOR_PROCESS', 'MONITOR_SNMP_N', 'MONITOR_SNMP_S', 'MONITOR_SNMPTRAP', 'MONITOR_SQL_N', 'MONITOR_SQL_S', 'MONITOR_SYSTEMLOG', 'MONITOR_LOGFILE', 'MONITOR_WINSERVICE', 'MONITOR_WINEVENT', 'MONITOR_CUSTOMTRAP_N', 'MONITOR_CUSTOMTRAP_S', 'MONITOR_JMX')


    # @see com.clustercontrol.beanHinemosModuleConstant
    _facility_type_ = ('SCOPE', 'NODE', 'ROOT')

    _builtin_scope_id_ = ('OWNER','INTERNAL','REGISTERED','UNREGISTERED','OS')

    @staticmethod
    def convert2facility_type(label):
        return None if label is None else RepositoryUtil._facility_type_.index(label)

    @staticmethod
    def get_built_in_scopes(endpoint):
        scope_ids = []
        facility_tree = endpoint.get_facility_tree('')
        for sub_tree_item in facility_tree.children[0].children:
            if sub_tree_item.data.builtInFlg == True and sub_tree_item.data.facilityType == RepositoryUtil.convert2facility_type('SCOPE'):
                scope_ids.append(sub_tree_item.data.facilityId)
        return scope_ids

class FacilityTree(object):

    @staticmethod
    def convert_datetime(facility_tree):
        if 'detail' in facility_tree:
            if 'startDate' in facility_tree.detail:
                facility_tree.detail.startDate = DateConvert.get_datetime_from_epochtime(facility_tree.detail.startDate)
            if 'endDate' in facility_tree.detail:
                facility_tree.detail.endDate = DateConvert.get_datetime_from_epochtime(facility_tree.detail.endDate)

        if 'data' in facility_tree:
            if 'createDatetime' in facility_tree.data:
                facility_tree.data.createDatetime = DateConvert.get_datetime_from_epochtime(facility_tree.data.createDatetime)
            if 'modifyDatetime' in facility_tree.data:
                facility_tree.data.modifyDatetime = DateConvert.get_datetime_from_epochtime(facility_tree.data.modifyDatetime)
            if 'createDate' in facility_tree.data:
                if facility_tree.data.createDate != 0:
                    facility_tree.data.createDate = DateConvert.get_datetime_from_epochtime(facility_tree.data.createDate)
            if 'modifyDate' in facility_tree.data:
                if facility_tree.data.modifyDate != 0:
                    facility_tree.data.modifyDate = DateConvert.get_datetime_from_epochtime(facility_tree.data.modifyDate)

            if 'waitRule' in facility_tree.data:
                if 'start_delay_time_value' in facility_tree.data.waitRule:
                    facility_tree.data.waitRule.start_delay_time_value = DateConvert.get_time48_from_epochtime(facility_tree.data.waitRule.start_delay_time_value)
                if 'end_delay_time_value' in facility_tree.data.waitRule:
                    facility_tree.data.waitRule.end_delay_time_value = DateConvert.get_time48_from_epochtime(facility_tree.data.waitRule.end_delay_time_value)

        if 'children' in facility_tree:
            for one in facility_tree.children:
                FacilityTree.convert_datetime(one)

    @staticmethod
    def to_id_name_map(facility_tree_item):
        id_name_map = {}
        if facility_tree_item is not None:
            for a in facility_tree_item.children:
                if a.data.facilityType == RepositoryUtil.convert2facility_type('NODE'):
                    if a.data.facilityId not in id_name_map:
                        id_name_map[a.data.facilityId] = a.data.facilityName
                elif a.data.facilityType == RepositoryUtil.convert2facility_type('SCOPE'):
                    for k, v in FacilityTree.to_id_name_map(a).items():
                        if k not in id_name_map:
                            id_name_map[k] = v
        return id_name_map

# RepositoryEndpointより取得した結果のダミーデータを除外し、設定するクラス
class ResultSet(object):

    # nodeListInfoの結果を編集
    @staticmethod
    def nodeListInfo(result):
        list = []
        for i in range(len(result)):
            nodeInfo = nodeListInfo()
            nodeInfo.facilityId = result[i].facilityId
            nodeInfo.facilityName = result[i].facilityName
            nodeInfo.ipAddressVersion = result[i].ipAddressVersion
            nodeInfo.ipAddressV4 = result[i].ipAddressV4
            nodeInfo.ipAddressV6 = result[i].ipAddressV6
            nodeInfo.description = result[i].description
            nodeInfo.ownerRoleId = result[i].ownerRoleId
            list.append(nodeInfo)
        return list

    # facilityListInfoの結果を編集
    @staticmethod
    def facilityListInfo(result):
        list = []
        for i in range(len(result)):
            nodeInfo = facilityListInfo()
            nodeInfo.facilityId = result[i].facilityId
            nodeInfo.facilityName = result[i].facilityName
            nodeInfo.facilityType = result[i].facilityType
            list.append(nodeInfo)
        return list

    # facilityInfoの結果を編集
    @staticmethod
    def facilityInfo(result):
        list = []
        for i in range(len(result)):
            facility = facilityInfo()
            facility.ownerRoleId = result[i].ownerRoleId
            facility.facilityId = result[i].facilityId
            facility.facilityName = result[i].facilityName
            facility.facilityType = result[i].facilityType
            facility.description = result[i].description
            facility.iconImage = result[i].iconImage
            facility.displaySortOrder = result[i].displaySortOrder
            facility.valid = result[i].valid
            list.append(facility)
        return list

    # propertyNONの結果を編集
    @staticmethod
    def propertyNON(result):
        property = propertyNON()
        property.facilityId = result.facilityId
        property.facilityName = result.facilityName
        property.description = result.description
        property.iconImage = result.iconImage
        property.ownerRoleId = result.ownerRoleId
        return property

    # nodePropertyBySNMPInfoの結果を編集
    @staticmethod
    def nodePropertyBySNMPInfo(result):
        nodeInfo = nodePropertyBySNMPInfo()
        nodeInfo.facilityId = result.nodeInfo.facilityId
        nodeInfo.facilityName = result.nodeInfo.facilityName
        nodeInfo.description = result.nodeInfo.description
        nodeInfo.platformFamily = result.nodeInfo.platformFamily
        nodeInfo.ipAddressVersion = result.nodeInfo.ipAddressVersion
        nodeInfo.ipAddressV4 = result.nodeInfo.ipAddressV4
        nodeInfo.ipAddressV6 = result.nodeInfo.ipAddressV6
        
        if result.nodeInfo.nodeHostnameInfo is not None:
            listHostName = []
            for i in range(len(result.nodeInfo.nodeHostnameInfo)):
                nodeHostname = nodeHostnameInfo()
                nodeHostname.hostname = result.nodeInfo.nodeHostnameInfo[i].hostname
                listHostName.append(nodeHostname)
            
            nodeInfo.nodeHostnameInfo = listHostName

        if 'nodeOsInfo' in result.nodeInfo:
            nodeInfo.nodeOsInfo.osName = result.nodeInfo.nodeOsInfo.osName
            nodeInfo.nodeOsInfo.osVersion = result.nodeInfo.nodeOsInfo.osVersion

        nodeInfo.nodeName = result.nodeInfo.nodeName
        nodeInfo.snmpPort = result.nodeInfo.snmpPort
        nodeInfo.snmpCommunity = result.nodeInfo.snmpCommunity
        nodeInfo.snmpVersion = result.nodeInfo.snmpVersion
        nodeInfo.snmpSecurityLevel = result.nodeInfo.snmpSecurityLevel
        nodeInfo.snmpUser = result.nodeInfo.snmpUser
        nodeInfo.snmpAuthPassword = result.nodeInfo.snmpAuthPassword
        nodeInfo.snmpPrivPassword = result.nodeInfo.snmpPrivPassword
        nodeInfo.snmpAuthProtocol = result.nodeInfo.snmpAuthProtocol
        nodeInfo.snmpPrivProtocol = result.nodeInfo.snmpPrivProtocol
        
        if result.nodeInfo.nodeCpuInfo is not None:
            listCpuInfo = []
            for i in range(len(result.nodeInfo.nodeCpuInfo)):
                nodeCpu = nodeCpuInfo()
                nodeCpu.deviceDisplayName = result.nodeInfo.nodeCpuInfo[i].deviceDisplayName
                nodeCpu.deviceName = result.nodeInfo.nodeCpuInfo[i].deviceName
                nodeCpu.deviceIndex = result.nodeInfo.nodeCpuInfo[i].deviceIndex
                nodeCpu.deviceType = result.nodeInfo.nodeCpuInfo[i].deviceType
                nodeCpu.deviceSize = result.nodeInfo.nodeCpuInfo[i].deviceSize
                nodeCpu.deviceSizeUnit = result.nodeInfo.nodeCpuInfo[i].deviceSizeUnit
                nodeCpu.deviceDescription = result.nodeInfo.nodeCpuInfo[i].deviceDescription
                listCpuInfo.append(nodeCpu)
            
            nodeInfo.nodeCpuInfo = listCpuInfo
        
        if result.nodeInfo.nodeNetworkInterfaceInfo is not None:
            listNetworkInterface = []
            for i in range(len(result.nodeInfo.nodeNetworkInterfaceInfo)):
                nodeNetworkInterface = nodeNetworkInterfaceInfo()
                nodeNetworkInterface.deviceDisplayName = result.nodeInfo.nodeNetworkInterfaceInfo[i].deviceDisplayName
                nodeNetworkInterface.deviceName = result.nodeInfo.nodeNetworkInterfaceInfo[i].deviceName
                nodeNetworkInterface.deviceIndex = result.nodeInfo.nodeNetworkInterfaceInfo[i].deviceIndex
                nodeNetworkInterface.deviceType = result.nodeInfo.nodeNetworkInterfaceInfo[i].deviceType
                nodeNetworkInterface.deviceSize = result.nodeInfo.nodeNetworkInterfaceInfo[i].deviceSize
                nodeNetworkInterface.deviceSizeUnit = result.nodeInfo.nodeNetworkInterfaceInfo[i].deviceSizeUnit
                nodeNetworkInterface.deviceDescription = result.nodeInfo.nodeNetworkInterfaceInfo[i].deviceDescription
                nodeNetworkInterface.nicIpAddress = result.nodeInfo.nodeNetworkInterfaceInfo[i].nicIpAddress
                nodeNetworkInterface.nicMacAddress = result.nodeInfo.nodeNetworkInterfaceInfo[i].nicMacAddress
                listNetworkInterface.append(nodeNetworkInterface)
            
            nodeInfo.nodeNetworkInterfaceInfo = listNetworkInterface
        
        if result.nodeInfo.nodeDiskInfo is not None:
            listNodeDisk = []
            for i in range(len(result.nodeInfo.nodeDiskInfo)):
                nodeDisk = nodeDiskInfo()
                nodeDisk.deviceDisplayName = result.nodeInfo.nodeDiskInfo[i].deviceDisplayName
                nodeDisk.deviceName = result.nodeInfo.nodeDiskInfo[i].deviceName
                nodeDisk.deviceIndex = result.nodeInfo.nodeDiskInfo[i].deviceIndex
                nodeDisk.deviceType = result.nodeInfo.nodeDiskInfo[i].deviceType
                nodeDisk.deviceSize = result.nodeInfo.nodeDiskInfo[i].deviceSize
                nodeDisk.deviceSizeUnit = result.nodeInfo.nodeDiskInfo[i].deviceSizeUnit
                nodeDisk.deviceDescription = result.nodeInfo.nodeDiskInfo[i].deviceDescription
                nodeDisk.diskRpm = result.nodeInfo.nodeDiskInfo[i].diskRpm
                listNodeDisk.append(nodeDisk)
            
            nodeInfo.nodeDiskInfo = listNodeDisk
        
        if result.nodeInfo.nodeFilesystemInfo is not None:
            listNodeFilesystem = []
            for i in range(len(result.nodeInfo.nodeFilesystemInfo)):
                nodeFilesystem = nodeFilesystemInfo()
                nodeFilesystem.deviceDisplayName = result.nodeInfo.nodeFilesystemInfo[i].deviceDisplayName
                nodeFilesystem.deviceName = result.nodeInfo.nodeFilesystemInfo[i].deviceName
                nodeFilesystem.deviceIndex = result.nodeInfo.nodeFilesystemInfo[i].deviceIndex
                nodeFilesystem.deviceType = result.nodeInfo.nodeFilesystemInfo[i].deviceType
                nodeFilesystem.deviceSize = result.nodeInfo.nodeFilesystemInfo[i].deviceSize
                nodeFilesystem.deviceSizeUnit = result.nodeInfo.nodeFilesystemInfo[i].deviceSizeUnit
                nodeFilesystem.deviceDescription = result.nodeInfo.nodeFilesystemInfo[i].deviceDescription
                nodeFilesystem.filesystemType = result.nodeInfo.nodeFilesystemInfo[i].filesystemType
                listNodeFilesystem.append(nodeFilesystem)
            
            nodeInfo.nodeFilesystemInfo = listNodeFilesystem
        
        nodeInfo.administrator = result.nodeInfo.administrator
        
        return nodeInfo

    # FacilityTreeのfacilityInfoの結果を編集
    @staticmethod
    def facilityTree(result):
        if 'data' in result:
            facility = facilityInfo()
            try:
                facility.ownerRoleId = result.data.ownerRoleId
            except :
                # ROOTについて、ownerRoleIdの要素すら作成しないので、処理継続のためpassする
                pass
            
            facility.facilityId = result.data.facilityId
            facility.facilityName = result.data.facilityName
            facility.facilityType = result.data.facilityType
            facility.description = result.data.description
            facility.iconImage = result.data.iconImage
            facility.displaySortOrder = result.data.displaySortOrder
            facility.valid = result.data.valid
            result.data = facility
        
        if 'children' in result:
            for one in result.children:
                ResultSet.facilityTree(one)
