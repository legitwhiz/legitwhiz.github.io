#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.job import JobUtil
from hinemos.util.modifier import ObjectModifier


# HC for Utility data consistence
def formatted_jobtree(tree):
    if hasattr(tree, 'data') and tree.data is not None:
        if hasattr(tree.data, 'createUser') and tree.data.createUser is not None:
            tree.data.createUser = None
        if hasattr(tree.data, 'createTime') and tree.data.createTime is not None:
            tree.data.createTime = None
        if hasattr(tree.data, 'updateUser') and tree.data.updateUser is not None:
            tree.data.updateUser = None
        if hasattr(tree.data, 'updateTime') and tree.data.updateTime is not None:
            tree.data.updateTime = None

        # Format jobunit (TOP, no recur actually)
        if str(tree.data.type) == str(JobUtil.convert2job_type('JOBUNIT')):
            if hasattr(tree.data, 'waitRule') and tree.data.waitRule is not None:
                subinfo = tree.data.waitRule
                # None -> 0
                if hasattr(subinfo, 'suspend') and subinfo.suspend is None:
                    subinfo.suspend = 0
                if hasattr(subinfo, 'skip') and subinfo.skip is None:
                    subinfo.skip = 0
                if hasattr(subinfo, 'skipEndStatus') and subinfo.skipEndStatus is None:
                    subinfo.skipEndStatus = 0
                if hasattr(subinfo, 'skipEndValue') and subinfo.skipEndValue is None:
                    subinfo.skipEndValue = 0
                if hasattr(subinfo, 'endCondition') and subinfo.endCondition is None:
                    subinfo.endCondition = 0
                if hasattr(subinfo, 'endStatus') and subinfo.endStatus is None:
                    subinfo.endStatus = 0
                if hasattr(subinfo, 'endValue') and subinfo.endValue is None:
                    subinfo.endValue = 0
                if hasattr(subinfo, 'calendar') and subinfo.calendar is None:
                    subinfo.calendar = 0

                if hasattr(subinfo, 'start_delay_operation_end_status') and subinfo.start_delay_operation_end_status is None:
                    subinfo.start_delay_operation_end_status = 0
                if hasattr(subinfo, 'start_delay_session_value') and subinfo.start_delay_session_value is None:
                    subinfo.start_delay_session_value = 0
                if hasattr(subinfo, 'end_delay_session_value') and subinfo.end_delay_session_value is None:
                    subinfo.end_delay_session_value = 0
                if hasattr(subinfo, 'end_delay_job_value') and subinfo.end_delay_job_value is None:
                    subinfo.end_delay_job_value = 0
                if hasattr(subinfo, 'end_delay_operation_end_status') and subinfo.end_delay_operation_end_status is None:
                    subinfo.end_delay_operation_end_status = 0
                if hasattr(subinfo, 'multiplicityNotify') and subinfo.multiplicityNotify is None:
                    subinfo.multiplicityNotify = 0
                if hasattr(subinfo, 'multiplicityNotifyPriority') and subinfo.multiplicityNotifyPriority is None:
                    subinfo.multiplicityNotifyPriority = 0
                if hasattr(subinfo, 'multiplicityEndValue') and subinfo.multiplicityEndValue is None:
                    subinfo.multiplicityEndValue = 0

        if str(tree.data.type) == str(JobUtil.convert2job_type('FILEJOB')):
            if hasattr(tree.data, 'file') and tree.data.file is not None:
                subinfo = tree.data.file
                # None -> -1
                if hasattr(subinfo, 'messageRetryEndValue') and subinfo.messageRetryEndValue is None:
                    subinfo.messageRetryEndValue = -1

        if str(tree.data.type) == str(JobUtil.convert2job_type('REFERJOB')):
            if hasattr(tree.data, 'waitRule') and tree.data.waitRule is not None:
                subinfo = tree.data.waitRule
                # None -> 0
                if hasattr(subinfo, 'start_delay_operation_end_status') and subinfo.start_delay_operation_end_status is None:
                    subinfo.start_delay_operation_end_status = 0
                if hasattr(subinfo, 'start_delay_session_value') and subinfo.start_delay_session_value is None:
                    subinfo.start_delay_session_value = 0
                if hasattr(subinfo, 'end_delay_session_value') and subinfo.end_delay_session_value is None:
                    subinfo.end_delay_session_value = 0
                if hasattr(subinfo, 'end_delay_job_value') and subinfo.end_delay_job_value is None:
                    subinfo.end_delay_job_value = 0
                if hasattr(subinfo, 'end_delay_operation_end_status') and subinfo.end_delay_operation_end_status is None:
                    subinfo.end_delay_operation_end_status = 0
                if hasattr(subinfo, 'multiplicityNotify') and subinfo.multiplicityNotify is None:
                    subinfo.multiplicityNotify = 0
                if hasattr(subinfo, 'multiplicityNotifyPriority') and subinfo.multiplicityNotifyPriority is None:
                    subinfo.multiplicityNotifyPriority = 0
                if hasattr(subinfo, 'multiplicityEndValue') and subinfo.multiplicityEndValue is None:
                    subinfo.multiplicityEndValue = 0

    # Recursively
    if hasattr(tree, 'children') and tree.children is not None:
        for child in tree.children:
            formatted_jobtree(child)

    return tree


class JobEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'Job')

    # ジョブツリー情報を取得する。
    def getJob():
        try:
            return self._client.service.getJobTree()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobTree failed, ' + str(e))
            raise ErrorHandler.APIError('getJobTree failed, ' + str(e))

    # ジョブツリー情報を取得する。
    def getJobTree(self, ownerRoleId, treeOnly):
        try:
            return self._client.service.getJobTree(ownerRoleId, treeOnly)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobTree failed, ' + str(e))
            raise ErrorHandler.APIError('getJobTree failed, ' + str(e))

    # ジョブ情報の詳細を取得する。
    def getJobFull(self, jobInfo):
        try:
            return self._client.service.getJobFull(jobInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobFull failed, ' + str(e))
            raise ErrorHandler.APIError('getJobFull failed, ' + str(e))

    # ジョブ情報の詳細を取得する。
    def getJobFullList(self, jobList):
        try:
            return self._client.service.getJobFullList(jobList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobFullList failed, ' + str(e))
            raise ErrorHandler.APIError('getJobFullList failed, ' + str(e))

    # ジョブユニット情報を登録する。
    def registerJobunit(self, item):
        try:
            return self._client.service.registerJobunit(formatted_jobtree(item))
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'registerJobunit failed, ' + str(e))
            raise ErrorHandler.APIError('registerJobunit failed, ' + str(e))

    # ジョブユニット単位でジョブツリー情報を削除する。
    def deleteJobunit(self, jobunitId):
        try:
            return self._client.service.deleteJobunit(jobunitId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'deleteJobunit failed, ' + str(e))
            raise ErrorHandler.APIError('deleteJobunit failed, ' + str(e))

    # ジョブ操作開始用プロパティを返します。
    def getAvailableStartOperation(self, sessionId, jobunitId, jobId, facilityId):
        try:
            return self._client.service.getAvailableStartOperation(sessionId, jobunitId, jobId, facilityId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getAvailableStartOperation failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getAvailableStartOperation failed, ' + str(e))

    # ジョブ操作停止用プロパティを返します。
    def getAvailableStopOperation(self, sessionId, jobunitId, jobId, facilityId):
        try:
            return self._client.service.getAvailableStopOperation(sessionId, jobunitId, jobId, facilityId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getAvailableStopOperation failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getAvailableStopOperation failed, ' + str(e))

    # ジョブを実行します。
    def runJob(self, jobunitId, jobId, info, triggerInfo):
        try:
            return self._client.service.runJob(jobunitId, jobId, info, triggerInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('runJob failed, ' + str(e))
            raise ErrorHandler.APIError('runJob failed, ' + str(e))

    # ジョブ操作を行います。
    def operationJob(self, OperationInfo):
        try:
            return self._client.service.operationJob(OperationInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'operationJob failed, ' + str(e))
            raise ErrorHandler.APIError('operationJob failed, ' + str(e))

    # ジョブ履歴一覧情報を返します。
    def getJobHistoryList(self, jobHistoryFilter, displayed):
        try:
            return self._client.service.getJobHistoryList(jobHistoryFilter, displayed)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobHistoryList failed, ' + str(e))
            raise ErrorHandler.APIError('getJobHistoryList failed, ' + str(e))

    # ジョブ詳細一覧情報を返します。
    def getJobDetailList(self, sessionId):
        try:
            return self._client.service.getJobDetailList(sessionId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobDetailList failed, ' + str(e))
            raise ErrorHandler.APIError('getJobDetailList failed, ' + str(e))

    # ノード詳細一覧情報を返します。
    def getNodeDetailList(self, sessionId, jobunitId, jobId):
        try:
            return self._client.service.getNodeDetailList(sessionId, jobunitId, jobId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getNodeDetailList failed, ' + str(e))
            raise ErrorHandler.APIError('getNodeDetailList failed, ' + str(e))

    # ファイル転送一覧情報を返します。
    def getForwardFileList(self, sessionId, jobunitId, jobId):
        try:
            return self._client.service.getForwardFileList(sessionId, jobunitId, jobId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getForwardFileList failed, ' + str(e))
            raise ErrorHandler.APIError('getForwardFileList failed, ' + str(e))

    # スケジュール情報を登録します。
    def addSchedule(self, jobFileCheck):
        try:
            return self._client.service.addSchedule(jobFileCheck)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'addSchedule failed, ' + str(e))
            raise ErrorHandler.APIError('addSchedule failed, ' + str(e))

    # ジョブ[実行契機]ファイルチェック情報を登録します。
    def addFileCheck(self, jobFileCheck):
        try:
            return self._client.service.addFileCheck(jobFileCheck)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'addFileCheck failed, ' + str(e))
            raise ErrorHandler.APIError('addFileCheck failed, ' + str(e))

    # ジョブ[実行契機]マニュアル情報を登録します。
    def addJobManual(self, jobKick):
        try:
            return self._client.service.addJobManual(jobKick)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'addJobManual failed, ' + str(e))
            raise ErrorHandler.APIError('addJobManual failed, ' + str(e))

    # ジョブキュー(同時実行制御キュー)の設定を追加します。
    def addJobQueue(self, job_queue_setting):
        try:
            return self._client.service.addJobQueue(job_queue_setting)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'addJobQueue failed, ' + str(e))
            raise ErrorHandler.APIError('addJobQueue failed, ' + str(e))

    # スケジュール情報を変更します。
    def modifySchedule(self, info):
        # Clean-up
        if hasattr(info, 'modifyType') and not info.modifyType:
            delattr(info, 'modifyType')
        if hasattr(info, 'calendarId') and not info.calendarId:
            delattr(info, 'calendarId')
        try:
            return self._client.service.modifySchedule(info)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'modifySchedule failed, ' + str(e))
            raise ErrorHandler.APIError('modifySchedule failed, ' + str(e))

    # ジョブ[実行契機]ファイルチェック情報を変更します。
    def modifyFileCheck(self, jobFileCheck):
        try:
            # Clean-up
            if hasattr(jobFileCheck, 'modifyType') and not jobFileCheck.modifyType:
                delattr(jobFileCheck, 'modifyType')
            if hasattr(jobFileCheck, 'calendarId') and not jobFileCheck.calendarId:
                delattr(jobFileCheck, 'calendarId')

            return self._client.service.modifyFileCheck(jobFileCheck)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'modifyFileCheck failed, ' + str(e))
            raise ErrorHandler.APIError('modifyFileCheck failed, ' + str(e))

    # ジョブ[実行契機]マニュアル情報を変更します。
    def modifyJobManual(self, jobKick):
        try:
            return self._client.service.modifyJobManual(jobKick)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'modifyJobManual failed, ' + str(e))
            raise ErrorHandler.APIError('modifyJobManual failed, ' + str(e))

    # ジョブ[実行契機]スケジュール情報を削除します。
    def deleteSchedule(self, jobkickIdList):
        try:
            return self._client.service.deleteSchedule(jobkickIdList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'deleteSchedule failed, ' + str(e))
            raise ErrorHandler.APIError('deleteSchedule failed, ' + str(e))

    # ジョブ[実行契機]ファイルチェック情報を削除します。
    def deleteFileCheck(self, jobkickIdList):
        try:
            return self._client.service.deleteFileCheck(jobkickIdList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'deleteFileCheck failed, ' + str(e))
            raise ErrorHandler.APIError('deleteFileCheck failed, ' + str(e))

    # ジョブ[実行契機]マニュアル情報を削除します。
    def deleteJobManual(self, jobkickIdList):
        try:
            return self._client.service.deleteJobManual(jobkickIdList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'deleteJobManual failed, ' + str(e))
            raise ErrorHandler.APIError('deleteJobManual failed, ' + str(e))

    # ジョブキュー(同時実行制御キュー)の設定を削除します。
    def deleteJobQueue(self, queue_id):
        try:
            return self._client.service.deleteJobQueue(queue_id)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'deleteJobQueue failed, ' + str(e))
            raise ErrorHandler.APIError('deleteJobQueue failed, ' + str(e))

    # 実行契機IDと一致するジョブスケジュールを返します。
    def getJobSchedule(self, jobKickId):
        try:
            return self._client.service.getJobSchedule(jobKickId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobSchedule failed, ' + str(e))
            raise ErrorHandler.APIError('getJobSchedule failed, ' + str(e))

    # 実行契機IDと一致するジョブファイルチェックを返します。
    def getJobFileCheck(self, jobKickId):
        try:
            return self._client.service.getJobFileCheck(jobKickId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobFileCheck failed, ' + str(e))
            raise ErrorHandler.APIError('getJobFileCheck failed, ' + str(e))

    # 実行契機IDと一致するジョブマニュアルを返します。
    def getJobManual(self, jobKickId):
        try:
            return self._client.service.getJobManual(jobKickId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobManual failed, ' + str(e))
            raise ErrorHandler.APIError('getJobManual failed, ' + str(e))

    # ジョブキュー(同時実行制御キュー)の設定を一覧表示するビューのための情報を返します。
    def getJobQueueSettingViewInfo(self, job_queue_setting_view_filter):
        try:
            return self._client.service.getJobQueueSettingViewInfo(job_queue_setting_view_filter)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobQueueSettingViewInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getJobQueueSettingViewInfo failed, ' + str(e))

    # ジョブキュー(同時実行制御キュー)を参照しているジョブを一覧表示するビューのための情報を返します。
    def getJobQueueReferrerViewInfo(self, queue_id):
        try:
            return self._client.service.getJobQueueReferrerViewInfo(queue_id)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobQueueReferrerViewInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getJobQueueReferrerViewInfo failed, ' + str(e))

    # 指定されたロールから参照可能なジョブキュー(同時実行制御キュー)の設定情報のリストを返します。
    def getJobQueueList(self, owner_role_id):
        try:
            return self._client.service.getJobQueueList(owner_role_id)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobQueueList failed, ' + str(e))
            raise ErrorHandler.APIError('getJobQueueList failed, ' + str(e))

    # ジョブキュー(同時実行制御キュー)の内部状況を表示するビューのための情報を返します。
    def getJobQueueContentsViewInfo(self, queue_id):
        try:
            return self._client.service.getJobQueueContentsViewInfo(queue_id)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobQueueContentsViewInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getJobQueueContentsViewInfo failed, ' + str(e))

    # 指定されたジョブキュー(同時実行制御キュー)の設定情報を返します。
    def getJobQueue(self, queue_id):
        try:
            return self._client.service.getJobQueue(queue_id)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobQueue failed, ' + str(e))
            raise ErrorHandler.APIError('getJobQueue failed, ' + str(e))

    # ジョブキュー(同時実行制御キュー)の設定を変更します。
    def modifyJobQueue(self, job_queue_setting):
        try:
            return self._client.service.modifyJobQueue(job_queue_setting)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'modifyJobQueue failed, ' + str(e))
            raise ErrorHandler.APIError('modifyJobQueue failed, ' + str(e))

    # 実行契機IDと一致するジョブ実行契機を返します。
    def getJobKick(self, jobKickId):
        try:
            return self._client.service.getJobKick(jobKickId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobKick failed, ' + str(e))
            raise ErrorHandler.APIError('getJobKick failed, ' + str(e))

    # ジョブキュー(同時実行制御キュー)の活動状況を一覧表示するビューのための情報を返します。
    def getJobQueueActivityViewInfo(self, job_queue_activity_view_filter):
        try:
            return self._client.service.getJobQueueActivityViewInfo(job_queue_activity_view_filter)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobQueueActivityViewInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getJobQueueActivityViewInfo failed, ' + str(e))

    # ジョブ[実行契機]スケジュール、ファイルチェックの有効/無効を変更します。
    def setJobKickStatus(self, jobKickId, validflag):
        try:
            return self._client.service.setJobKickStatus(jobKickId, validflag)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'setJobKickStatus failed, ' + str(e))
            raise ErrorHandler.APIError('setJobKickStatus failed, ' + str(e))

    # ジョブ実行契機一覧情報を返します。
    def getJobKickList(self):
        try:
            return self._client.service.getJobKickList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobKickList failed, ' + str(e))
            raise ErrorHandler.APIError('getJobKickList failed, ' + str(e))

    # ジョブ実行契機一覧情報を返します。
    def getJobKickListByCondition(self, condition):
        try:
            return self._client.service.getJobKickListByCondition(condition)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobKickListByCondition failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getJobKickListByCondition failed, ' + str(e))

    # セッションジョブ情報を返します。
    def getSessionJobInfo(self, sessionId, jobunitId, jobId):
        try:
            return self._client.service.getSessionJobInfo(sessionId, jobunitId, jobId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getSessionJobInfo failed, ' + str(e))
            raise ErrorHandler.APIError('getSessionJobInfo failed, ' + str(e))

    # ジョブ[スケジュール予定]の一覧を返します。
    def getPlanList(self, jobPlanFilter, plans):
        try:
            return self._client.service.getPlanList(jobPlanFilter, plans)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getPlanList failed, ' + str(e))
            raise ErrorHandler.APIError('getPlanList failed, ' + str(e))

    # 指定したジョブユニットの最終更新日時を返す
    def getUpdateTimeList(self, jobunitIdList):
        try:
            return self._client.service.getUpdateTimeList(jobunitIdList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getUpdateTimeList failed, ' + str(e))
            raise ErrorHandler.APIError('getUpdateTimeList failed, ' + str(e))

    # 編集ロックを取得する
    def getEditLock(self, jobunitId, updateTime, forceflag):
        try:
            return self._client.service.getEditLock(jobunitId, updateTime, forceflag)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getEditLock failed, ' + str(e))
            raise ErrorHandler.APIError('getEditLock failed, ' + str(e))

    # 編集ロックの正当性をチェックする
    def checkEditLock(self, jobunitId, editsession):
        try:
            return self._client.service.checkEditLock(jobunitId, editsession)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'checkEditLock failed, ' + str(e))
            raise ErrorHandler.APIError('checkEditLock failed, ' + str(e))

    # 編集ロックを開放する。
    def releaseEditLock(self, editSession):
        try:
            return self._client.service.releaseEditLock(editSession)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'releaseEditLock failed, ' + str(e))
            raise ErrorHandler.APIError('releaseEditLock failed, ' + str(e))

    # 登録済みモジュール一覧情報を取得する。
    def getRegisteredModule(self, jobunitId):
        try:
            return self._client.service.getRegisteredModule(jobunitId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getRegisteredModule failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getRegisteredModule failed, ' + str(e))

    # ジョブマップ用アイコン情報一覧を返します。
    def getJobmapIconImageList(self):
        try:
            return self._client.service.getJobmapIconImageList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobmapIconImageList failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getJobmapIconImageList failed, ' + str(e))

    # ジョブ設定用のジョブマップアイコン情報一覧を返します。
    def getJobmapIconImageIdListForSelect(self, ownerRoleId):
        try:
            return self._client.service.getJobmapIconImageIdListForSelect(ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getJobmapIconImageIdListForSelect failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getJobmapIconImageIdListForSelect failed, ' + str(e))

    # 承認ジョブにおける承認画面へのリンク先アドレスを取得する。
    def getApprovalPageLink(self):
        try:
            return self._client.service.getApprovalPageLink()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getApprovalPageLink failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getApprovalPageLink failed, ' + str(e))

    # 承認ジョブにおける参照のオブジェクト権限を持つロールIDのリストを取得。
    def getRoleIdListWithReadObjectPrivilege(self, objectId):
        try:
            return self._client.service.getRoleIdListWithReadObjectPrivilege(objectId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getRoleIdListWithReadObjectPrivilege failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getRoleIdListWithReadObjectPrivilege failed, ' + str(e))

    # 監視設定一覧の取得
    def getMonitorListForJobMonitor(self, ownerRoleId):
        try:
            return self._client.service.getMonitorListForJobMonitor(ownerRoleId)
        except Exception, e:
            import traceback
            traceback.print_exc()
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getMonitorListForJobMonitor failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getMonitorListForJobMonitor failed, ' + str(e))

    # 承認対象ジョブの一覧情報を取得します。
    def getApprovalJobList(self, jobApprovalFilter, limit):
        try:
            return self._client.service.getApprovalJobList(jobApprovalFilter, limit)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getApprovalJobList failed, ' + str(e))
            raise ErrorHandler.APIError('getApprovalJobList failed, ' + str(e))

    # 承認情報を更新します
    def modifyApprovalInfo(self, jobApprovalFilter, isApprove):
        try:
            return self._client.service.modifyApprovalInfo(jobApprovalFilter, isApprove)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'modifyApprovalInfo failed, ' + str(e))
            raise ErrorHandler.APIError('modifyApprovalInfo failed, ' + str(e))

    # スクリプトの最大サイズを取得します
    def getScriptContentMaxSize(self):
        try:
            return self._client.service.getScriptContentMaxSize()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getScriptContentMaxSize failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getScriptContentMaxSize failed, ' + str(e))

    def create_notify_relation_info(self, notify_info, jobunit_id, job_id):
        obj_name = 'ns3:notifyRelationInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.notifyGroupId = 'JOB_MST-' + jobunit_id + '-' + job_id + '-0'
            info.notifyId = notify_info.notifyId
            info.notifyType = notify_info.notifyType
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_trigger_info(self, trigger_type=None, trigger_info=None):
        # Set default value
        # if trigger_type is None:
        #    trigger_type = ''

        try:
            info = self._client.factory.create('jobTriggerInfo')
            if trigger_type is not None:
                info.trigger_type = trigger_type        # FIXME attribute with underscore
            if trigger_info is not None:
                info.trigger_info = trigger_info        # FIXME attribute with underscore
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create jobTriggerInfo failed, ' + str(e))

    def create_output_basic_info(self):
        try:
            info = self._client.factory.create('outputBasicInfo')
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create outputBasicInfo failed, ' + str(e))

    def get_exec_target_facility_id_list(self, facilityId):
        try:
            return self._client.service.getExecTargetFacilityIdList(facilityId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError(
                    'getExecTargetFacilityIdList failed, ' + str(e))
            raise ErrorHandler.APIError(
                'getExecTargetFacilityIdList failed, ' + str(e))

    def create_job_plan_filter(self, job_kick_id, from_date, to_date):
        obj_name = 'jobPlanFilter'
        try:
            info = self._client.factory.create(obj_name)
            if job_kick_id is not None:
                info.jobKickId = job_kick_id
            if from_date is not None:
                info.fromDate = from_date
            if to_date is not None:
                info.toDate = to_date
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_parameter_info(self, param_type, param_id, description, value=None):
        # Format input
        if description is None:
            description = ''

        obj_name = 'jobParameterInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.type = param_type
            info.paramId = param_id
            info.description = description
            if value is not None:
                info.value = value
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_file_info(self, src_node_id, src_file, dest_facility_id, dest_dir):
        ''' jobFileInfo attribute with default setting '''
        obj_name = 'jobFileInfo'
        try:
            info = self._client.factory.create(obj_name)
            ObjectModifier.set_attrs(info,
                                     srcFacilityID=src_node_id,
                                     srcScope=' ',
                                     srcFile=src_file,
                                     destFacilityID=dest_facility_id,
                                     destScope=' ',
                                     destDirectory=dest_dir,
                                     processingMethod=0,
                                     checkFlg=0,
                                     commandRetry=10,
                                     commandRetryFlg=0,
                                     compressionFlg=0,
                                     messageRetry=10,
                                     messageRetryEndFlg=1,
                                     messageRetryEndValue=-1,
                                     srcWorkDir='',
                                     destWorkDir='',
                                     specifyUser=0,
                                     user=None)
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_command_info(self, facility_id, start_command):
        ''' jobCommandInfo with default setting '''

        if facility_id == '#[FACILITY_ID]':
            scope = None
        else:
            scope = ' '

        obj_name = 'jobCommandInfo'
        try:
            info = self._client.factory.create(obj_name)
            ObjectModifier.set_attrs(info,
                                     commandRetry=10,
                                     commandRetryFlg=0,
                                     facilityID=facility_id,
                                     scope=scope,
                                     messageRetry=10,
                                     messageRetryEndFlg=1,
                                     messageRetryEndValue=-1,
                                     processingMethod=0,
                                     specifyUser=0,
                                     startCommand=start_command,
                                     stopType=1)
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_monitor_job_info(self, facility_id, monitor_id):
        ''' monitorJobInfo with default setting '''

        if facility_id == '#[FACILITY_ID]':
            scope = None
        else:
            scope = ' '

        obj_name = 'monitorJobInfo'
        try:
            info = self._client.factory.create(obj_name)
            ObjectModifier.set_attrs(
                info,
                commandRetry=10,
                commandRetryFlg=False,
                facilityID=facility_id,
                monitorId=monitor_id,
                monitorCriticalEndValue=9,
                monitorInfoEndValue=0,
                monitorUnknownEndValue=-1,
                monitorWaitEndValue=-1,
                monitorWaitTime=1,
                monitorWarnEndValue=1,
                processingMethod=0,
                scope=scope)
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_object_info(self, obj_type, job_id=None, value=0, time=None,
                               start_minute=0, decision_condition=None,
                               decision_value01=None, decision_value02=None,
                               description=None):
        # Default
        if value is None:
            value = 0
        if start_minute is None:
            start_minute = 0
        job_name = None
        if job_id is not None:
            job_name = ' '
        if decision_condition is None:
            decision_condition = 0
        if decision_value01 is None:
            decision_value01 = ''
        if decision_value02 is None:
            decision_value02 = ''
        if description is None:
            description = ''

        obj_name = 'jobObjectInfo'
        try:
            info = self._client.factory.create(obj_name)
            ObjectModifier.replace_if_not_none(info,
                                               type=obj_type,
                                               jobId=job_id,
                                               jobName=job_name,
                                               startMinute=start_minute,
                                               value=value,
                                               time=time,
                                               decisionCondition=decision_condition,
                                               decisionValue01=decision_value01,
                                               decisionValue02=decision_value02,
                                               description=description)
            return info
        except Exception, e:

            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_wait_rule_info(self):
        ''' WaitRule attribute with default setting '''

        obj_name = 'jobWaitRuleInfo'
        try:
            info = self._client.factory.create(obj_name)
            ObjectModifier.set_attrs(info,
                                     calendar=0,
                                     calendarEndStatus=2,
                                     calendarEndValue=0,
                                     condition=0,
                                     endCondition=1,
                                     endStatus=2,
                                     endValue=-1,
                                     end_delay=0,
                                     end_delay_condition_type=0,
                                     end_delay_change_mount=False,
                                     end_delay_change_mount_value=1.0,
                                     end_delay_job=0,
                                     end_delay_job_value=1,
                                     end_delay_notify=0,
                                     end_delay_notify_priority=0,
                                     end_delay_operation=0,
                                     end_delay_operation_end_status=2,
                                     end_delay_operation_end_value=-1,
                                     end_delay_operation_type=0,
                                     end_delay_session=0,
                                     end_delay_session_value=1,
                                     end_delay_time=0,
                                     multiplicityEndValue=-1,
                                     multiplicityNotify=1,
                                     multiplicityNotifyPriority=2,
                                     multiplicityOperation=0,
                                     skip=0,
                                     skipEndStatus=2,
                                     skipEndValue=0,
                                     start_delay=0,
                                     start_delay_condition_type=0,
                                     start_delay_notify=0,
                                     start_delay_notify_priority=0,
                                     start_delay_operation=0,
                                     start_delay_operation_end_status=2,
                                     start_delay_operation_end_value=-1,
                                     start_delay_operation_type=0,
                                     start_delay_session=0,
                                     start_delay_session_value=1,
                                     start_delay_time=0,
                                     start_delay_time_value="09:00:00",
                                     suspend=0)
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_end_status_info(self, end_status_type, start_range_value=None, end_range_value=None, value=None):
        # Default
        if start_range_value is None:
            if end_status_type == JobUtil.convert2end_status('NORMAL'):
                start_range_value = 0
            elif end_status_type == JobUtil.convert2end_status('WARNING'):
                start_range_value = 1
            elif end_status_type == JobUtil.convert2end_status('ABNORMAL'):
                start_range_value = 0
        if end_range_value is None:
            if end_status_type == JobUtil.convert2end_status('NORMAL'):
                end_range_value = 0
            elif end_status_type == JobUtil.convert2end_status('WARNING'):
                end_range_value = 1
            elif end_status_type == JobUtil.convert2end_status('ABNORMAL'):
                end_range_value = 0
        if value is None:
            if end_status_type == JobUtil.convert2end_status('NORMAL'):
                value = 0
            elif end_status_type == JobUtil.convert2end_status('WARNING'):
                value = 1
            elif end_status_type == JobUtil.convert2end_status('ABNORMAL'):
                value = -1

        obj_name = 'jobEndStatusInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.type = end_status_type
            info.startRangeValue = start_range_value
            info.endRangeValue = end_range_value
            info.value = value
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_notifications_info(self, jobunit_id, job_id, priority, job_type):
        obj_name = 'jobNotificationsInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.notifyGroupId = 'JOB_MST-' + jobunit_id + '-' + job_id + '-0'
            info.priority = priority
            info.type = job_type
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_file_check(self, schedule_id, name, job_map, facility_id, directory, file_name, event_type=None, modify_type=None, owner_role_id=None, calendar_id=None, valid=None):
        # Format
        if owner_role_id is None:
            owner_role_id = 'ALL_USERS'
        if modify_type is None:
            modify_type = JobUtil.convert2file_check_mod_type('TIMESTAMP')

        if valid is None:
            valid = 1
        if event_type is None:
            event_type = 0

        # Validate
        assert schedule_id
        assert name
        assert job_map
        assert facility_id
        assert directory
        assert file_name
        assert event_type in range(len(JobUtil._file_check_event_type_))
        if event_type == JobUtil.convert2file_check_event_type('MOD'):
            assert modify_type in range(len(JobUtil._file_check_mod_type_))
        else:
            assert not modify_type
        for x in job_map.keys():
            assert x in ('jobunitId', 'jobId')

        obj_name = 'jobFileCheck'
        try:
            info = self._client.factory.create(obj_name)
            info.id = schedule_id
            info.name = name
            info.jobunitId = job_map['jobunitId']
            info.jobId = job_map['jobId']
            info.jobName = ' '
            info.ownerRoleId = owner_role_id
            if not calendar_id:
                delattr(info, 'calendarId')
            else:
                info.calendarId = calendar_id
            if not modify_type:
                delattr(info, 'modifyType')
            else:
                info.modifyType = modify_type

            info.facilityId = facility_id
            info.directory = directory
            info.fileName = file_name

            info.type = 1  # HC
            info.eventType = event_type
            info.valid = valid
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_schedule(self, info_id, or_id):
        obj_name = 'jobSchedule'
        try:
            info = self._client.factory.create(obj_name)
            info.id = info_id
            info.ownerRoleId = or_id
            info.type = 0  # HC
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_kick(self, jk_id, or_id):
        obj_name = 'jobKick'
        try:
            info = self._client.factory.create(obj_name)
            info.id = jk_id
            info.ownerRoleId = or_id
            info.type = 2  # HC
            info.valid = True  # HC
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_info_minimal(self, jobunit_id, job_id):
        obj_name = 'jobInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.jobunitId = jobunit_id
            info.id = job_id
            info.name = ''  # necessary
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_info(self, job_type, jobunit_id, job_id, name, parent_id=None, description=None, owner_role_id=None, notify_infos=None,
                        end_status_lst=None, begin_priority=None, normal_priority=None, warn_priority=None, abnormal_priority=None,
                        refer_jobunit_id=None, refer_job_id=None,
                        job_parameter_infos=None):
        # Default
        if begin_priority is None:
            begin_priority = 3
        if normal_priority is None:
            normal_priority = 3
        if warn_priority is None:
            warn_priority = 2
        if abnormal_priority is None:
            abnormal_priority = 0
        if end_status_lst is None:
            end_status_lst = [
                self.create_job_end_status_info(0, 0, 0, 0),
                self.create_job_end_status_info(1, 1, 1, 1),
                self.create_job_end_status_info(2, 0, 0, -1)]
        if description is None:
            description = ''

        # Validate
        assert parent_id == ''  # parent_id cannot be empty, but None is OK

        obj_name = 'jobInfo'
        try:
            info = self._client.factory.create(obj_name)
            ObjectModifier.replace_if_not_none(info,
                                               parentId=parent_id,
                                               jobunitId=jobunit_id,
                                               id=job_id,
                                               name=name,
                                               description=description,
                                               ownerRoleId=owner_role_id,
                                               type=job_type,
                                               propertyFull=True,
                    \
                                               beginPriority=begin_priority,
                                               normalPriority=normal_priority,
                                               warnPriority=warn_priority,
                                               abnormalPriority=abnormal_priority,
                    \
                                               referJobId=refer_job_id,
                                               referJobUnitId=refer_jobunit_id)
            if job_parameter_infos is not None:
                info.param = job_parameter_infos
            if notify_infos is not None:
                notify_relation_infos = []
                for a in notify_infos:
                    notify_relation_infos.append(
                        self.create_notify_relation_info(a, job_id))
                info.notifyId = notify_relation_infos
            info.endStatus = end_status_lst
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_tree_item_basic(self, job_type, jobunit_id, job_id, name, description=None, owner_role_id=None, as_module=None, icon_id=None, notify_infos=None,
                                   begin_priority=None, normal_priority=None, warn_priority=None, abnormal_priority=None,
                                   normal_end_status_info=None, warn_end_status_info=None, abnormal_end_status_info=None,
                                   refer_jobunit_id=None, refer_job_id=None,
                                   job_parameter_infos=None):
        # Default
        if begin_priority is None:
            begin_priority = 3
        if normal_priority is None:
            normal_priority = 3
        if warn_priority is None:
            warn_priority = 2
        if abnormal_priority is None:
            abnormal_priority = 0
        if description is None:
            description = ''
        if as_module is not True:
            as_module = 'False'
        if owner_role_id is None:
            owner_role_id = 'ALL_USERS'
        if icon_id is None or '':
            icon_id = None

        if normal_end_status_info is None:
            normal_end_status_info = self.create_job_end_status_info(
                0, 0, 0, 0)
        if warn_end_status_info is None:
            warn_end_status_info = self.create_job_end_status_info(1, 1, 1, 1)
        if abnormal_end_status_info is None:
            abnormal_end_status_info = self.create_job_end_status_info(
                2, 0, 0, -1)

        obj_name = 'jobTreeItem'
        try:
            tree = self._client.factory.create(obj_name)
            tree.data.id = job_id
            tree.data.jobunitId = jobunit_id
            tree.data.name = name
            tree.data.description = description
            tree.data.ownerRoleId = owner_role_id
            tree.data.registeredModule = as_module
            tree.data.iconId = icon_id

            tree.data.propertyFull = True
            tree.data.type = job_type

            tree.data.beginPriority = begin_priority
            tree.data.normalPriority = normal_priority
            tree.data.warnPriority = warn_priority
            tree.data.abnormalPriority = abnormal_priority

            if notify_infos is not None:
                for a in notify_infos:
                    tree.data.notifyRelationInfos.append(
                        self.create_notify_relation_info(a, jobunit_id, job_id))

            tree.data.endStatus.append(normal_end_status_info)
            tree.data.endStatus.append(warn_end_status_info)
            tree.data.endStatus.append(abnormal_end_status_info)

            if job_parameter_infos is not None:
                tree.data.param = job_parameter_infos

            if refer_jobunit_id:
                tree.data.referJobUnitId = refer_jobunit_id
            if refer_job_id:
                tree.data.referJobId = refer_job_id
            return tree
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_runtime_param(self, param_id, param_type, description=None, required=None, def_value=None, detail_list=None):
        # Format input
        if description is None:
            description = ''

        obj_name = 'jobRuntimeParam'
        try:
            info = self._client.factory.create(obj_name)
            info.paramId = param_id
            info.paramType = param_type

            info.description = description
            info.value = def_value
            info.requiredFlg = required
            if detail_list is not None:
                info.jobRuntimeParamDetailList = detail_list

            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_runtime_param_detail(self, description, param_value=None):
        # Format input
        if description is None:
            description = ''

        obj_name = 'jobRuntimeParamDetail'
        try:
            info = self._client.factory.create(obj_name)
            info.description = description
            if param_value is not None:
                info.paramValue = param_value
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_command_param(self, param_id, value, stdout_flg):
        # Format input
        if stdout_flg is not True:
            stdout_flg = False

        obj_name = 'jobCommandParam'
        try:
            info = self._client.factory.create(obj_name)
            info.paramId = param_id
            info.value = value
            info.jobStandardOutputFlg = stdout_flg
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_job_env_variable_info(self, var_id, value, desc):
        # Format input
        if desc is None:
            desc = ''

        obj_name = 'jobEnvVariableInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.envVariableId = var_id
            info.value = value
            info.description = desc
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))
