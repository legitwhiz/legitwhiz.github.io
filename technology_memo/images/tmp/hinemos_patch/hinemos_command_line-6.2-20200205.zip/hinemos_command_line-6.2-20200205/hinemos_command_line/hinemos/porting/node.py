# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from xml.etree.ElementTree import SubElement
from hinemos.api.helper import CNoDatetimeTypeFormatter
from hinemos.porting import elem_attr2info

''' Settings '''
attr_rename_list = {\
                    'NodeInfo': {'sshPrivateKeyFilepath': 'sshPrivateKeyFilename', 'winrmRetries': 'winrmRetryCount', 'ipmiRetries': 'ipmiRetryCount', 'valid': 'validFlg'},\
                    'DiskInfo': {'diskRpm': 'deviceDiskRpm'},\
                    'FSInfo': {'filesystemType': 'deviceFSType'},\
                    'NetworkInterfaceInfo': {'nicMacAddress': 'deviceNicMacAddress', 'nicIpAddress': 'deviceNicIpAddress'},\
                    }

def inverse_attr_rename_list(rename_list):
    inv_list={}
    for k, v in rename_list.iteritems():
        inv_list[k] = dict(zip(v.values(), v.keys()))
    return inv_list

def append_noteinfo(element, facility_id, note_info, tag_name='NoteInfo'):
    if note_info.note is None:
        note_info.note = ''

    sub_elem = SubElement(element, tag_name, {'facilityId':facility_id, 'noteId':str(note_info.noteId)})
    SubElement(sub_elem, 'note').text = note_info.note

    return sub_elem

def format_output_node(node_info):
    CNoDatetimeTypeFormatter.output(node_info)

    # Remove attributes
    for attr in ('displaySortOrder', 'builtInFlg', 'facilityType', 'notReferFlg'):
        delattr(node_info, attr)

def format_output_xml(kkey, element):
    # format_output_xml
    for info_attr, xml_attr in attr_rename_list[kkey].iteritems():
        element.attrib[xml_attr] = element.attrib.pop(info_attr)

def format_input_xml(kkey, element):
    # format_output_xml
    for info_attr, xml_attr in attr_rename_list[kkey].iteritems():
        element.attrib[info_attr] = element.attrib.pop(xml_attr)

def append_sub_info(element, tag_name, facility_id, endpoint, obj_name, sub_info, attr_rename_list=None):
    for sub_elem in element.findall(tag_name):
        if sub_elem.get('facilityId') == facility_id:
            del sub_elem.attrib['facilityId']
            info = endpoint.create_object(obj_name)
            elem_attr2info(sub_elem.attrib, info, attr_rename_list)
            sub_info.append(info)

def append_sub_noteinfo(element, tag_name, facility_id, endpoint, obj_name, sub_info, attr_rename_list=None):
    for sub_elem in element.findall(tag_name):
        if sub_elem.get('facilityId') == facility_id:
            del sub_elem.attrib['facilityId']
            info = endpoint.create_object(obj_name)
            elem_attr2info(sub_elem.attrib, info, attr_rename_list)
            info.note = sub_elem.find('note').text
            if info.note is None:
                info.note = ''
            sub_info.append(info)

#HC for Utility Excel: Deprecated attributes
def format_node_elem(elem):
    for a in ('vnetSwitchType', 'cloudNodeType', 'openflowDataPathId', 'vmName', 'vmId', 'vnetHostNode', 'vmUser', 'vmProtocol', 'vmUserPassword', 'vmNodeType', 'cloudZone', 'cloudAccountResource', 'cloudRegion', 'openflowCtrlIpAddress', 'vmManagementNode'):
        if a in elem.attrib:
            del elem.attrib[a]
