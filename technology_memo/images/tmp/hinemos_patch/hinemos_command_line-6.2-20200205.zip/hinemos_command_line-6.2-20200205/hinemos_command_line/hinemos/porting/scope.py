# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import re
from xml.etree.ElementTree import SubElement
import hinemos.api.exceptions as ErrorHandler
from hinemos.porting import append_obj2element_atype
from hinemos.util.repository import RepositoryUtil

''' Settings '''
attr_rename_list = {'facilityId': 'nodeFacilityId', 'facilityName': 'nodeFacilityName'}

def format_output_scope(facility_info):
    # Remove attributes
    for attr in ('facilityType', 'builtInFlg', 'createDatetime', 'modifyDatetime', 'createUserId', 'displaySortOrder', 'modifyUserId', 'notReferFlg', 'valid'):
        delattr(facility_info, attr)

    #if not endpoint.is_node(tree_item.data.facilityId):
    if facility_info.description is None:
        facility_info.description =''
    if facility_info.iconImage is None:
        facility_info.iconImage =''

def format_output_node(facility_info):
    # Remove attributes
    for attr in ('facilityType', 'builtInFlg', 'createDatetime', 'modifyDatetime', 'createUserId', 'displaySortOrder', 'modifyUserId', 'notReferFlg', 'valid', 'description', 'iconImage', 'ownerRoleId'):
        delattr(facility_info, attr)

def append_scope2element(facility_tree, scope_element, assign_element):
    if 'children' not in facility_tree:
        return

    for sub_tree_item in facility_tree.children:
        if sub_tree_item.data.builtInFlg == False:
            facility_type = sub_tree_item.data.facilityType

            if facility_type == RepositoryUtil.convert2facility_type('NODE'):
                format_output_node(sub_tree_item.data)
                sub_elem = append_obj2element_atype(assign_element, sub_tree_item.data, 'ScopeNodeInfo')
                # format_output_xml
                for info_attr, xml_attr in attr_rename_list.iteritems():
                    sub_elem.attrib[xml_attr] = sub_elem.attrib.pop(info_attr)
                sub_elem.set('scopeFacilityId', facility_tree.data.facilityId)
                sub_elem.set('scopeFacilityName', facility_tree.data.facilityName)
            else:
                if facility_type == RepositoryUtil.convert2facility_type('SCOPE'):
                    format_output_scope(sub_tree_item.data)
                    next_scope_element = append_obj2element_atype(scope_element, sub_tree_item.data, 'ScopeInfo')
                    next_scope_element.set('parentFacilityId', facility_tree.data.facilityId or '')
                else: # ROOT Scope
                    next_scope_element = scope_element

                append_scope2element(sub_tree_item, next_scope_element, assign_element)

def set_scope_node_info(element, facilityTree, endpoint):
    try:
        if not endpoint.is_node(facilityTree.data.facilityId):
            my_list = endpoint.get_node_list(facilityTree.data.facilityId, '1')
            for i in my_list:
                SubElement(element, 'ScopeNodeInfo ', {'scopeFacilityId':str(facilityTree.data.facilityId),'scopeFacilityName':str(facilityTree.data.facilityName),'nodeFacilityId':str(i.facilityId),'nodeFacilityName':str(i.facilityName)})
            if 'children' in facilityTree:
                for children in facilityTree.children:
                    set_scope_node_info(element, children, endpoint)
        return element
    except Exception, e:
        raise ErrorHandler.PortingExportError('set scopeNodeInfo failed, ' + str(e))

def create_scope_info(el, scopeInfoList, endpoint):
    scopeInfo = endpoint.create_object('scopeInfo')
    temp = str(el.attrib).split(',')
    for s in temp:
        p = re.compile('\'.*\':')
        m = p.search(s, 0)
        if m:
            attribute = s[m.start()+1:m.end()-2]
            if attribute == 'parentFacilityId':
                parentFacilityId = el.get(attribute)
            else:
                scopeInfo[attribute] = el.get(attribute)
    parentScopeInfo = [parentFacilityId, scopeInfo]
    scopeInfoList.append(parentScopeInfo)
    u'''
              下位スコープがある場合、createScopeInfo再帰呼び出し
    '''
    for mi in el:
        scopeInfoList = create_scope_info(mi, scopeInfoList, endpoint)
    return scopeInfoList

def create_scope_info_list(tree, endpoint):
    scopeInfoList = []
    elem = tree.getroot()
    try:
        for el in elem:
            if el.tag == 'ScopeInfo':
                u'''
                scopeInfo を生成し、リストに追加
                '''
                scopeInfoList = create_scope_info(el, scopeInfoList, endpoint)
        return scopeInfoList
    except Exception, e:
        raise ErrorHandler.FileReadError('create scopeInfoList failed, ' + str(e))

def create_scope_node_info_list(tree, endpoint):
    scopeNodeInfoList = []
    elem = tree.getroot()
    try:
        for el in elem:
            if el.tag == 'ScopeNodeInfo':
                u'''
                scopeNodeInfo を生成し、リストに追加
                '''
                temp = str(el.attrib).split(',')
                for s in temp:
                    p = re.compile('\'.*\':')
                    m = p.search(s, 0)
                    if m:
                        attribute = s[m.start()+1:m.end()-2]
                        if attribute == 'scopeFacilityId':
                            scopeFacilityId = el.get(attribute)
                        if attribute == 'nodeFacilityId':
                            nodeFacilityId = el.get(attribute)
                scopeNodeInfo = [scopeFacilityId, nodeFacilityId]
                scopeNodeInfoList.append(scopeNodeInfo)
        return scopeNodeInfoList
    except Exception, e:
        raise ErrorHandler.FileReadError('create scopeNodeInfoList failed, ' + str(e))
