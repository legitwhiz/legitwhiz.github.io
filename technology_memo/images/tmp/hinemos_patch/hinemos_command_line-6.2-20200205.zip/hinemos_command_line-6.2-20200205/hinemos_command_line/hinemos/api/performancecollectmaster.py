#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler

class PerformanceCollectMasterEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'PerformanceCollectMaster')

    def get_collect_sub_platform_master(self):
        try:
            return self._client.service.getCollectSubPlatformMaster()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getCollectSubPlatformMaster failed,  ' + str(e))
            raise ErrorHandler.APIError('getCollectSubPlatformMaster failed, ' + str(e))

    def get_collect_platform_master(self):
        try:
            return self._client.service.getCollectPlatformMaster()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getCollectPlatformMaster failed,  ' + str(e))
            raise ErrorHandler.APIError('getCollectPlatformMaster failed, ' + str(e))

    def get_collect_master_info(self):
        try:
            return self._client.service.getCollectMasterInfo()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getCollectMasterInfo failed,  ' + str(e))
            raise ErrorHandler.APIError('getCollectMasterInfo failed, ' + str(e))

    def delete_collect_platform_master(self, platformId):
        try:
            return self._client.service.deleteCollectPlatformMaster(platformId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteCollectPlatformMaster failed, ' + str(e))
            raise ErrorHandler.APIError('deleteCollectPlatformMaster failed, ' + str(e))

    def delete_collect_sub_platform_master(self, platformId):
        try:
            return self._client.service.deleteCollectSubPlatformMaster(platformId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteCollectSubPlatformMaster failed, ' + str(e))
            raise ErrorHandler.APIError('deleteCollectSubPlatformMaster failed, ' + str(e))

    def add_collect_master(self, collectMasterInfo):
        try:
            return self._client.service.addCollectMaster(collectMasterInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addCollectMaster failed, ' + str(e))
            raise ErrorHandler.APIError('addCollectMaster is failed, '+ str(e))

    def create_collect_calc_method_mst_data(self, calc_method, class_name, expression):
        try:
            data = self._client.factory.create('collectorCalcMethodMstData')
            data.calcMethod = calc_method
            data.className = class_name
            data.expression = expression
            return data
        except Exception, e:
            raise ErrorHandler.APIError('create collectorCalcMethodMstData failed, ' + str(e))

    def create_collector_category_collect_mst_data(self, category_code, collect_method, platform_id, sub_platform_id):
        try:
            data = self._client.factory.create('collectorCategoryCollectMstData')
            data.categoryCode = category_code
            data.collectMethod = collect_method
            data.platformId = platform_id
            data.subPlatformId = sub_platform_id
            return data
        except Exception, e:
            raise ErrorHandler.APIError('create collectorCalcMethodMstData failed, ' + str(e))

    def create_collector_category_mst_data(self, category_code, category_name):
        try:
            data = self._client.factory.create('collectorCategoryMstData')
            data.categoryCode = category_code
            data.categoryName = category_name
            return data
        except Exception, e:
            raise ErrorHandler.APIError('create collectorCalcMethodMstData failed, ' + str(e))

    def create_collector_item_calc_method_mst_data(self, calc_method, collect_method, item_code, platform_id, sub_platform_id):
        try:
            data = self._client.factory.create('collectorItemCalcMethodMstData')
            data.calcMethod = calc_method
            data.collectMethod = collect_method
            data.itemCode = item_code
            data.platformId = platform_id
            data.subPlatformId = sub_platform_id
            return data
        except Exception, e:
            raise ErrorHandler.APIError('create collectorCalcMethodMstData failed, ' + str(e))

    def create_collector_item_code_mst_data(self, category_code, category_codeitem_code_device_support, device_type, graph_range, item_code, item_name, measure, parent_item_code):
        try:
            data = self._client.factory.create('collectorItemCodeMstData')
            data.categoryCode = category_code
            data.deviceSupport = category_codeitem_code_device_support
            data.deviceType = device_type
            data.graphRange = graph_range
            data.itemCode = item_code
            data.itemName = item_name
            data.measure = measure
            data.parentItemCode = parent_item_code
            return data
        except Exception, e:
            raise ErrorHandler.APIError('create collectorCalcMethodMstData failed, ' + str(e))

    def create_collector_polling_mst_data(self, collect_method, entry_key, item_code, platform_id, polling_target, sub_platform_id, value_type, variable_id, failure_value):
        try:
            data = self._client.factory.create('collectorPollingMstData')
            data.collectMethod = collect_method
            data.entryKey = entry_key
            data.itemCode = item_code
            data.platformId = platform_id
            data.pollingTarget = polling_target
            data.subPlatformId = sub_platform_id
            data.valueType = value_type
            data.variableId = variable_id
            if failure_value != '':
                data.failureValue = failure_value
            return data
        except Exception, e:
            raise ErrorHandler.APIError('create collectorCalcMethodMstData failed, ' + str(e))

    def delete_collect_master_all(self):
        try:
            return self._client.service.deleteCollectMasterAll()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteCollectMasterAll failed, ' + str(e))
            raise ErrorHandler.APIError('deleteCollectMasterAll failed, ' + str(e))

    def add_collect_sub_platform_master(self, collectorSubPlatformMstData):
        try:
            return self._client.service.addCollectSubPlatformMaster(collectorSubPlatformMstData)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addCollectSubPlatformMaster failed, ' + str(e))
            raise ErrorHandler.APIError('addCollectSubPlatformMasterl failed, ' + str(e))

    def add_collect_platform_master(self, collectorPlatformMstData):
        try:
            return self._client.service.addCollectPlatformMaster(collectorPlatformMstData)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addCollectPlatformMaster failed, ' + str(e))
            raise ErrorHandler.APIError('addCollectPlatformMasterl failed, ' + str(e))





