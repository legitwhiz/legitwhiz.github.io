#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api import BasicEndpoint
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.modifier import ObjectModifier

class InfraEndpoint(BasicEndpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(hm_url, user, passwd, 'Infra')

    def addInfraManagement(self, infraManagementInfo):
        ''' 環境構築情報を作成します
        '''
        try:
            return self._client.service.addInfraManagement(infraManagementInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addInfraManagement failed, ' + str(e))
            raise ErrorHandler.APIError('addInfraManagement failed, ' + str(e))

    def modifyInfraManagement(self, infraManagementInfo):
        ''' 環境構築情報を変更します
        '''
        try:
            return self._client.service.modifyInfraManagement(infraManagementInfo)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyInfraManagement failed, ' + str(e))
            raise ErrorHandler.APIError('modifyInfraManagement failed, ' + str(e))


    def deleteInfraManagement(self, managementIds):
        try:
            return self._client.service.deleteInfraManagement(managementIds)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteInfraManagement failed, ' + str(e))
            raise ErrorHandler.APIError('deleteInfraManagement failed, ' + str(e))


    def getInfraManagement(self, managementId):
        try:
            return self._client.service.getInfraManagement(managementId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getInfraManagement failed, ' + str(e))
            raise ErrorHandler.APIError('getInfraManagement failed, ' + str(e))


    def getInfraManagementList(self):
        try:
            return self._client.service.getInfraManagementList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getInfraManagementList failed, ' + str(e))
            raise ErrorHandler.APIError('getInfraManagementList failed, ' + str(e))


    def getInfraManagementListByOwnerRole(self, ownerRoleId):
        try:
            return self._client.service.getInfraManagementListByOwnerRole(ownerRoleId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getInfraManagementListByOwnerRole failed, ' + str(e))
            raise ErrorHandler.APIError('getInfraManagementListByOwnerRole failed, ' + str(e))


    def createSession(self, managementId, moduleIdList, nodeInputType, accessList):
        try:
            return self._client.service.createSession(managementId, moduleIdList, nodeInputType, accessList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('createSession failed, ' + str(e))
            raise ErrorHandler.APIError('createSession failed, ' + str(e))


    def deleteSession(self, sessionId):
        try:
            return self._client.service.deleteSession(sessionId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteSession failed, ' + str(e))
            raise ErrorHandler.APIError('deleteSession failed, ' + str(e))


    def runInfraModule(self, sessionId):
        '''
            Returns moduleResult
        '''

        try:
            return self._client.service.runInfraModule(sessionId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('runInfraModule failed, ' + str(e))
            raise ErrorHandler.APIError('runInfraModule failed, ' + str(e))


    def checkInfraModule(self, sessionId, verbose):
        try:
            return self._client.service.checkInfraModule(sessionId, verbose)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('checkInfraModule failed, ' + str(e))
            raise ErrorHandler.APIError('checkInfraModule failed, ' + str(e))


    def getCheckResultList(self, managementId):
        try:
            return self._client.service.getCheckResultList(managementId)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getCheckResultList failed, ' + str(e))
            raise ErrorHandler.APIError('getCheckResultList failed, ' + str(e))


    def addInfraFile(self, fileInfo, fileContent):
        try:
            self._client.service.addInfraFile(fileInfo, fileContent)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addInfraFile failed, ' + str(e))
            raise ErrorHandler.APIError('addInfraFile failed, ' + str(e))


    def modifyInfraFile(self, fileInfo, fileContent):
        try:
            self._client.service.modifyInfraFile(fileInfo, fileContent)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyInfraFile failed, ' + str(e))
            raise ErrorHandler.APIError('modifyInfraFile failed, ' + str(e))


    def downloadInfraFile(self, fileId, fileName):
        try:
            return self._client.service.downloadInfraFile(fileId, fileName)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('downloadInfraFile failed, ' + str(e))
            raise ErrorHandler.APIError('downloadInfraFile failed, ' + str(e))


    def downloadTransferFile(self, fileName):
        try:
            return self._client.service.downloadTransferFile(fileName)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('downloadTransferFile failed, ' + str(e))
            raise ErrorHandler.APIError('downloadTransferFile failed, ' + str(e))


    def deleteDownloadedInfraFile(self, fileName):
        try:
            return self._client.service.deleteDownloadedInfraFile(fileName)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteDownloadedInfraFile failed, ' + str(e))
            raise ErrorHandler.APIError('deleteDownloadedInfraFile failed, ' + str(e))


    def deleteInfraFileList(self, fileIdList):
        try:
            self._client.service.deleteInfraFileList(fileIdList)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteInfraFileList failed, ' + str(e))
            raise ErrorHandler.APIError('deleteInfraFileList failed, ' + str(e))


    def getInfraFileList(self):
        try:
            return self._client.service.getInfraFileList()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getInfraFileList failed, ' + str(e))
            raise ErrorHandler.APIError('getInfraFileList failed, ' + str(e))


    def getInfraMaxFileSize(self):
        try:
            return self._client.service.getInfraMaxFileSize()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getInfraMaxFileSize failed, ' + str(e))
            raise ErrorHandler.APIError('getInfraMaxFileSize failed, ' + str(e))






    def modify_infra_file(self, fileId, fileName, fileContent):
        try:
            fileInfo = self.get_infra_file(fileId)
            fileInfo.fileName = fileName
            self._client.service.modifyInfraFile(fileInfo, fileContent)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyInfraFile failed, ' + str(e))
            raise ErrorHandler.APIError('modifyInfraFile failed, ' + str(e))

    def create_notify_relation_info(self, notify_info, infra_management_id):
        obj_name = 'ns2:notifyRelationInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.notifyGroupId = 'INFRA_' + infra_management_id
            info.notifyId = notify_info.notifyId
            info.notifyType = notify_info.notifyType
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def get_infra_file(self, file_id):
        try:
            for info in self.getInfraFileList():
                if info.fileId == file_id:
                    return info
            return None
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getInfraFileList failed, ' + str(e))
            raise ErrorHandler.APIError('getInfraFileList failed, ' + str(e))

    def create_infra_file_info(self, file_id, file_name, owner_role_id):
        if owner_role_id is None:
            owner_role_id = 'ALL_USERS'

        obj_name = 'infraFileInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.fileId = file_id
            info.fileName = file_name
            info.ownerRoleId = owner_role_id
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_infra_management_info(self,
                                     management_id,
                                     name, description,
                                     owner_role_id,
                                     facility_id,
                                     start_priority,
                                     normal_priority_run,
                                     abnormal_priority_run,
                                     normal_priority_check,
                                     abnormal_priority_check,
                                     valid_flg,
                                     notify_endpoint = None,
                                     notify_id_list=None,
                                     param_list=None):

        if owner_role_id is None:
            owner_role_id = 'ALL_USERS'
        if start_priority is None:
            start_priority = 3
        if normal_priority_run is None:
            normal_priority_run = 3
        if abnormal_priority_run is None:
            abnormal_priority_run = 0
        if normal_priority_check is None:
            normal_priority_check = 3
        if abnormal_priority_check is None:
            abnormal_priority_check = 0

        obj_name = 'infraManagementInfo'
        try:
            info = self._client.factory.create(obj_name)

            info.managementId = management_id
            info.name = name
            info.description = description
            info.ownerRoleId = owner_role_id

            info.facilityId = facility_id
            info.scope = ' '

            info.startPriority = start_priority
            info.normalPriorityRun = normal_priority_run
            info.abnormalPriorityRun = abnormal_priority_run
            info.normalPriorityCheck = normal_priority_check
            info.abnormalPriorityCheck = abnormal_priority_check

            if notify_id_list is not None:
                for notify_id in notify_id_list:
                    info.notifyRelationList.append(self.create_notify_relation_info(notify_endpoint.getNotify(notify_id), management_id))

            info.validFlg = valid_flg

            if param_list:
                info.infraManagementParamList = self.create_infra_management_param_list(param_list)

            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def create_infra_management_param_list(self, param_list):
        obj_name = 'infraManagementParamList'
        info_list = []
        for obj in param_list:
            # add required default values
            if not obj.get('passwordFlg'):
                obj['passwordFlg'] = False
            try:
                info = self._client.factory.create(obj_name)
                for key in obj:
                    if info[key]:
                        raise "Invalid key '%s' in JSON" % key
                    else:
                        info[key] = obj[key]
                info_list.append(info)
            except Exception, e:
                raise ErrorHandler.APIError(
                    'create ' + obj_name + ' failed, ' + str(e))
        return info_list

    def create_file_transfer_variable_info(self, name, value):
        obj_name = 'fileTransferVariableInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.name = name
            info.value = value
            return info
        except Exception, e:
            raise ErrorHandler.APIError(
                'create ' + obj_name + ' failed, ' + str(e))

    def create_file_transfer_module_info(self, module_id, name, file_id, dst, transfer_method_type, dest_owner, dest_permission, stop_if_fail_flg, backup_if_exist_flg, precheck_flg, replace_var_lst, valid_flg):
        # Default input
        if transfer_method_type is None:
            transfer_method_type = 0
        if dest_owner is None:
            dest_owner = 'root'
        if dest_permission is None:
            dest_permission = '644'
        if valid_flg is None:
            valid_flg = True

        obj_name = 'fileTransferModuleInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.moduleId = module_id
            info.name = name
            info.precheckFlg = precheck_flg
            info.stopIfFailFlg = stop_if_fail_flg
            info.validFlg = valid_flg
            info.backupIfExistFlg = backup_if_exist_flg
            info.destPath = dst
            info.fileId = file_id
            info.destAttribute = dest_permission
            info.destOwner = dest_owner
            info.fileTransferVariableList = replace_var_lst
            info.sendMethodType = transfer_method_type
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def add_file_transfer_module(self, management_id, module_id, name, file_id, dst, transfer_method_type, dest_owner, dest_permission, stop_if_fail_flg, backup_if_exist_flg, precheck_flg, replace_var_lst, valid_flg):
        try:
            management_info = self.getInfraManagement(management_id)
            if 'moduleList' not in management_info:
                setattr(management_info, 'moduleList', [])

            module_info = self.create_file_transfer_module_info(module_id, name, file_id, dst, transfer_method_type, dest_owner, dest_permission, stop_if_fail_flg, backup_if_exist_flg, precheck_flg, replace_var_lst, valid_flg)
            management_info.moduleList.append(module_info)

            return self.modifyInfraManagement(management_info)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addFileTransferModule failed, ' + str(e))
            raise ErrorHandler.APIError('addFileTransferModule failed, ' + str(e))

    def create_command_module_info(self, module_id, name, access_method_type, precheck_flg, stop_if_fail_flg, check_command, exec_command, valid_flg):
        # Default input
        if access_method_type is None:
            access_method_type = 0
        if valid_flg is None:
            valid_flg = True

        obj_name = 'commandModuleInfo'
        try:
            info = self._client.factory.create(obj_name)
            info.moduleId = module_id
            info.name = name
            info.precheckFlg = precheck_flg
            info.stopIfFailFlg = stop_if_fail_flg
            info.accessMethodType = access_method_type
            info.checkCommand = check_command
            info.execCommand = exec_command
            info.validFlg = valid_flg
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))

    def add_command_module(self, management_id, module_id, name, access_method_type, precheck_flg, stop_if_fail_flg, check_command, exec_command, valid_flg):
        try:
            management_info = self.getInfraManagement(management_id)
            if 'moduleList' not in management_info:
                setattr(management_info, 'moduleList', [])

            module_info = self.create_command_module_info(module_id, name, access_method_type, precheck_flg, stop_if_fail_flg, check_command, exec_command, valid_flg)
            management_info.moduleList.append(module_info)

            return self.modifyInfraManagement(management_info)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addCommandModule failed, ' + str(e))
            raise ErrorHandler.APIError('addCommandModule failed, ' + str(e))

    def modify_command_module(self, management_id, module_id, **kwargs):
        try:
            management_info = self.getInfraManagement(management_id)
            for module_info in management_info.moduleList:
                if module_info.moduleId == module_id and module_info.__class__.__name__ == 'commandModuleInfo':
                    for k,v in kwargs.iteritems():
                        setattr(module_info, k, v)
                    return self.modifyInfraManagement(management_info)
            raise ErrorHandler.ObjectNotFoundError('Module %s does not exist!' % module_id)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('modifyCommandModule failed, ' + str(e))
            raise ErrorHandler.APIError('modifyCommandModule failed, ' + str(e))

    def delete_module(self, management_id, module_id):
        try:
            management_info = self.getInfraManagement(management_id)
            if 'moduleList' in management_info:
                for info in management_info.moduleList:
                    if info.moduleId == module_id:
                        management_info.moduleList.remove(info)
                        return self.modifyInfraManagement(management_info)
                        #break
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('addCommandModule failed, ' + str(e))
            raise ErrorHandler.APIError('addCommandModule failed, ' + str(e))
        raise ErrorHandler.ObjectNotFoundError('Module %s does not exist!' % module_id)

    def create_access_info(self, facility_id,\
                           ssh_user=None, ssh_password=None, ssh_port=22, ssh_private_key_filepath=None, ssh_private_key_passphrase=None, ssh_timeout=None,\
                           win_rm_user=None, win_rm_password=None, win_rm_port=5985, win_rm_timeout=None):
        # Format
        if ssh_timeout is None:
            ssh_timeout = 50000
        if ssh_port is None:
            ssh_port = 22
        if win_rm_timeout is None:
            win_rm_timeout = 5000
        if win_rm_port is None:
            win_rm_port = 5985

        # Validate
        assert facility_id
        #assert ssh_user or win_rm_user # both empty for directly using node property

        obj_name = 'accessInfo'
        try:
            info = self._client.factory.create(obj_name)
            ObjectModifier.replace_if_not_none(info,\
                    facilityId = facility_id,\
                    sshUser = ssh_user,\
                    sshPassword = ssh_password,\
                    sshPort = ssh_port,\
                    sshPrivateKeyFilepath = ssh_private_key_filepath,\
                    sshPrivateKeyPassphrase = ssh_private_key_passphrase,\
                    sshTimeout = ssh_timeout,\
                    winRmPassword = win_rm_password,\
                    winRmPort = win_rm_port,\
                    winRmTimeout = win_rm_timeout,\
                    winRmUser = win_rm_user)
            return info
        except Exception, e:
            raise ErrorHandler.APIError('create ' + obj_name + ' failed, ' + str(e))
