# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import os
import sys
import re
import locale
import json
from optparse import OptionParser
import hinemos
import ConfigParser
import socket
from hinemos.api.exceptions import ArgumentError
from hinemos.util.common import ResultPrinter


class MyOptionParser(OptionParser, object):

    def __init__(self, conflict_handler='error'):
        super(self.__class__, self).__init__(
            version=hinemos.__project__ + ' ' + hinemos.__version__ + os.linesep + '    %prog',
            conflict_handler=conflict_handler)
        self.usage = '%prog'
        self.add_option('-H', '--url', action='store', type='string', metavar='URL',
                        dest='mgr_url',
                        default='http://127.0.0.1:8080/HinemosWS/', help='Hinemos Manager URL (default: http://127.0.0.1:8080/HinemosWS/)')
        self.add_option('-U', '--user', action='store', type='string', metavar='ID',
                        dest='user',
                        default='hinemos', help='Login user (default: hinemos)')
        self.add_option('-w', '--passwd', action='store', type='string', metavar='PASSWORD',
                        dest='passwd',
                        default=('hinemos'), help='Login password (default: hinemos)')
        # TODO Gonna provide in next update
        #self.add_option('--jsonCfg', action='store', type='string', metavar='STRING', dest='json_cfg',
        #               default=None, help='path to JSON configuration file')

    @staticmethod
    def convert_split(s):
        return s if not isinstance(s, str) else s.split(',')

    @staticmethod
    def parse_nargs(option, opt_str, value, parser):
        args=[value]
        for arg in parser.rargs:
            if not arg.startswith('-'):
                args.append(arg)
            else:
                del parser.rargs[:(len(args)-1)]
                break
        setattr(parser.values, option.dest, args)

    _post_converters_ = {}

    def add_option(self, *args, **kwargs):
        if 'my_x_append' == kwargs['action']:
            kwargs['action'] = 'callback'
            kwargs['callback'] = MyOptionParser.parse_nargs
            kwargs['type'] = 'string'
        elif 'store_split' == kwargs['action']:
            kwargs['action'] = 'store'
            self._post_converters_[kwargs['dest']] = MyOptionParser.convert_split
        if 'converter' in kwargs:
            self._post_converters_[kwargs['dest']] = kwargs['converter']
            del kwargs['converter']

        super(self.__class__, self).add_option(*args, **kwargs)

        usage_1opt = args[0]
        if 'metavar' in kwargs and kwargs['metavar'] is not None and '' != kwargs['metavar']:
            usage_1opt += ' ' + kwargs['metavar']

        if not ( 'default' in kwargs and isinstance(kwargs['default'], tuple) and 'REQUIRED' in kwargs['default'] ):
            usage_1opt = '[' + usage_1opt + ']'
        self.set_usage(self.usage + ' ' + usage_1opt)

    @staticmethod
    def _check_one_condtion(condition, opts):
        for k, v in condition.iteritems():
            if k.endswith('!='):
                k = k[:-2]
                if hasattr(opts, k) and v == getattr(opts, k): return False
            else:
                if hasattr(opts, k):
                    if v != getattr(opts, k): return False
                else:
                    return False
        return True

    @staticmethod
    def _check_condtion(conditions, opts):
        if isinstance(conditions, dict):
            return MyOptionParser._check_one_condtion(conditions, opts)
        elif not isinstance(conditions, list) and not isinstance(conditions, tuple):
            raise Exception, 'CONDITION ERROR : ' + str(conditions)
        else:
            for a in conditions:
                if MyOptionParser._check_one_condtion( a, opts ):
                    return True
        return False

    @staticmethod
    def _no_required(conditions):
        if isinstance(conditions, tuple):
            for a in conditions:
                if not MyOptionParser._no_required(a):
                    return False
        elif isinstance(conditions, dict):
            for a in conditions.itervalues():
                if not MyOptionParser._no_required(a):
                    return False
        elif isinstance(conditions, list):
            for a in conditions:
                if not MyOptionParser._no_required(a):
                    return False
        elif isinstance(conditions, str):
            if 'REQUIRED' == conditions:
                return False
        return True

    @staticmethod
    def _validate(conditions, val, option_desc, opts):
        if isinstance(conditions, str):
            conditions = (conditions,)

        # Skip default(None) if not required
        if 'REQUIRED' not in conditions and val is None:
            return True

        for check in conditions:
            if 'REQUIRED' == check:
                if val is None:
                    print >>sys.stderr, ('Option ' + option_desc + ' is required!')
                    return False
            elif 'NOTBLANK' == check:
                if val == '':
                    print >>sys.stderr, ('Option ' + option_desc + ' must not be blank!')
                    return False
            elif 'INTEGER' == check:
                try:
                    int(val)
                except ValueError:
                    print >>sys.stderr, ('Option ' + option_desc + ' must be an integer!')
                    return False
                except TypeError:
                    print >>sys.stderr, ('Option ' + option_desc + ' must be an integer!')
                    return False
            elif 'ISFILE' == check:
                if val is None or not os.path.isfile(val):
                    print >>sys.stderr, ('Option ' + option_desc + ' must be an existing file!')
                    return False
            elif isinstance(check, dict):
                if 'RANGE' in check:
                    val = int(val)
                    val_min = check['RANGE'][0]
                    val_max = check['RANGE'][1]
                    if val < val_min or val > val_max:
                        print >>sys.stderr, ('Option ' + option_desc + ' must be ' + str(val_min)+'-'+ str(val_max)+'!')
                        return False
                elif 'INLIST' in check:
                    if val not in check['INLIST']:
                        my_list = check['INLIST']
                        if '' in my_list:
                            my_list[my_list.index('')] = '(EMPTY)'
                        print >>sys.stderr, ('Option ' + option_desc + ' must be ' + (' or '.join([str(a) for a in my_list]))+'!')
                        return False
                elif 'REGEXP' in check:
                    if not re.match(check['REGEXP'][0], val):
                        print >>sys.stderr, ('Option ' + option_desc + ' ' + check['REGEXP'][1] +'!')
                        return False
        return True

    def _replace_tuple_defaults(self, opts):
        for option in self.option_list:
            if option.dest is not None and isinstance(option.default, tuple):
                # Remove tuple when it is default
                if hasattr(opts, option.dest):
                    val = getattr(opts, option.dest)
                if val == option.default:
                    val = option.default[0] # Use first as default value
                    setattr(opts, option.dest, val)

    def _validate_option(self, opts, option):
        if isinstance(option.default, tuple):
            if option.default == ('NO', 'DEFAULT'):
                return True

            val = getattr(opts, option.dest)

            # Fetch 'WHEN'-condition at first
            conditions = tuple()
            for x in option.default[1:]:
                if isinstance(x, dict) and 'WHEN' in x:
                    if MyOptionParser._check_condtion(x['WHEN'], opts):
                        if isinstance(x['DO'], tuple):
                            conditions = x['DO'] + conditions
                        else:
                            conditions = (x['DO'], ) + conditions
                else:
                    conditions += (x, )
            return MyOptionParser._validate(conditions, val, option.__str__() + ' ' + option.metavar, opts)
        return True

    def parse_opts(self, args):
        # Windows(cmdなどはSJIS)のため、入力した環境の文字列を一旦デコードし、UTF-8で再エンコード
        # なお、sys.stdin.encodingの代わりにlocale.getpreferredencoding()を採用。stdin.encodingだと、
        # Windowsの場合、pipeかredirect時にsys.std*.encodingがNoneになってしまうから(Python 2.xのバグっぽい)
        for i,a in enumerate(args):
            args[i] = a.decode(locale.getpreferredencoding()).encode(sys.getdefaultencoding())

        if '--jsonCfg' in args:
            args = self.load_json_config(args[args.index('--jsonCfg') + 1])

        (opts, args) = super(self.__class__, self).parse_args(args)

        # Replace defaults at first
        self._replace_tuple_defaults(opts)

        # Load presets
        try:
            conf = ConfigParser.ConfigParser()
            conf.read('env.cfg')
            try:
                opts.mgr_url = conf.get('login', 'manager_url')
            except (AttributeError, ConfigParser.NoOptionError):
                pass
            try:
                opts.user = conf.get('login', 'user')
            except (AttributeError, ConfigParser.NoOptionError):
                pass
            try:
                opts.passwd = conf.get('login', 'password')
            except (AttributeError, ConfigParser.NoOptionError):
                pass
        except (AttributeError, ConfigParser.NoSectionError):
            pass

        err_cnt = 0
        for one in self.option_list:
            if not self._validate_option(opts, one):
                err_cnt += 1

        # Terminate if any error occurs
        if 0 < err_cnt:
            self.print_and_exit('This command will be terminated.', 1)

        return_code = -1
        try:
            # Post-process
            for k, v in self._post_converters_.iteritems():
                if k.endswith('_raw'):
                    setattr(opts, k[:-4], v(getattr(opts, k)))
                else:
                    setattr(opts, k+'_converted', v(getattr(opts, k)))
        except Exception, e:
            return_code = ResultPrinter.failure(e)
        if return_code > 0:
            sys.exit(return_code)

        return opts

    def load_json_config(self, path):
        cfg = json.load(open(path))
        args = []
        for opt in cfg:
            args.append('--' + opt.replace('-', ''))
            if cfg[opt] is not None:
                if isinstance(cfg[opt], dict) or isinstance(cfg[opt], list):
                    args.append(json.dumps(cfg[opt]))
                else:
                    args.append(cfg[opt])
        return args

    def print_and_exit(self, msg, return_code=None, show_usage=False):
        """print_help(return_code : return_code = None)

        Print an extended help message(default stdout and do not exit).
        """
        help_hint = '(use option --help to see usage)'
        if return_code is None:
            print msg
            print
            if show_usage:
                print
                self.print_help(file=sys.stdout)
            else:
                print help_hint
        else:
            if 0 == return_code:
                print msg
                print
                if show_usage:
                    print
                    self.print_help(file=sys.stdout)
                else:
                    print help_hint
            else:
                print >>sys.stderr, msg
                print >>sys.stderr
                if show_usage:
                    print >>sys.stderr
                    self.print_help(file=sys.stderr)
                else:
                    print >>sys.stderr, help_hint
            sys.exit(return_code)


class OptionUtil(object):

    @staticmethod
    def zip_pairs(args1, args2):
        if args1 is None:
            args1 = []
        if args2 is None:
            args2 = []
        if len(args1) != len(args2):
            raise ArgumentError('%d <> %d' % (len(args1), len(args2)))
        return dict(zip(args1, args2))
