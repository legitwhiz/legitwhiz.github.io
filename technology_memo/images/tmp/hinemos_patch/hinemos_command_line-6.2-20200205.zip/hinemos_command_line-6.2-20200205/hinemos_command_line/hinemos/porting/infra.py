# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api.helper import BasicFormatter
from xml.etree.ElementTree import SubElement

def format_output(info):
    BasicFormatter.output(info)

    attr_name = 'description'
    if attr_name not in info:
        setattr(info, attr_name, '')

def format_output_xml(element):
    i = 1
    for x in element:
        if x.tag == 'fileTransferModuleInfo':
            x.tag = 'infraModuleInfo'
            x.set('moduleType', 'FileTransferModule')
            x.set('orderNo', str(i))
            del x.attrib['managementId']

            # Rename attributes
            x.attrib['stopIfFailFileFlg'] = x.attrib.pop('stopIfFailFlg')
            x.attrib['precheckFileFlg'] = x.attrib.pop('precheckFlg')
            i += 1

            # <HC> find and rename variable tag
            for y in x.iter('fileTransferVariableInfo'):
                y.tag = 'fileTransferVariable'
                for id_element in y.findall('id'):
                    y.remove(id_element)
        elif x.tag == 'commandModuleInfo':
            x.tag = 'infraModuleInfo'
            x.set('moduleType', 'ExecModule')
            x.set('orderNo', str(i))
            del x.attrib['managementId']

            # Rename attributes
            x.attrib['stopIfFailCommandFlg'] = x.attrib.pop('stopIfFailFlg')
            x.attrib['precheckCommandFlg'] = x.attrib.pop('precheckFlg')
            i += 1
        elif x.tag == 'notifyRelationInfo':
            x.tag = 'notifyId'
            # attributes to sub tags
            sub = SubElement(x, 'notifyGroupId')
            sub.text = x.attrib.pop('notifyGroupId')
            sub = SubElement(x, 'notifyId')
            sub.text = x.attrib.pop('notifyId')
            sub = SubElement(x, 'notifyType')
            sub.text = x.attrib.pop('notifyType')

# HC for Utility Excel: remove useless name=""
def format_infra_file_elem(elem):
    if 'name' in elem.attrib:
        del elem.attrib['name']

# HC for Utility Excel: remove useless fields
def format_infra_management_elem(elem):
    if 'notifyGroupId' in elem.attrib:
        del elem.attrib['notifyGroupId']

# HC for Utility Excel: remove useless fields
def format_file_transfer_module_elem(elem):
    for a in ('checkCommand', 'execCommand', 'accessMethodType', 'stopIfFailCommandFlg', 'precheckCommandFlg'):
        if a in elem.attrib:
            del elem.attrib[a]

# HC for Utility Excel: remove useless fields
def format_exec_module_elem(elem):
    for a in ('sendMethodType', 'backupIfExistFlg', 'precheckFileFlg', 'fileId', 'destAttribute', 'destPath', 'stopIfFailFileFlg', 'destOwner'):
        if a in elem.attrib:
            del elem.attrib[a]
