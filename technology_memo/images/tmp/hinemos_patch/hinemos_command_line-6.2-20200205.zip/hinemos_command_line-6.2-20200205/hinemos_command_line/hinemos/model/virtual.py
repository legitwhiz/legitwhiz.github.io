#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.model import BasicObject

### Virtual object for monitor setting ###
class AgentCheckInfo( BasicObject ):
    __keylist__ = [ 'monitorId', 'monitorTypeId' ]

class SyslogCheckInfo( BasicObject ):
    __keylist__ = [ 'monitorId', 'monitorTypeId' ]
