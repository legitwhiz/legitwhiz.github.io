#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api.endpoint import Endpoint
import hinemos.api.exceptions as ErrorHandler


class NodeMapEndpoint(Endpoint):

    def __init__(self, hm_url, user, passwd):
        super(self.__class__, self).__init__(
            hm_url, user, passwd, 'NodeMap')

    # 対象日時時点のノード一覧を取得します。
    def getNodeList(self, facility_id, node_filter_info):
        try:
            return self._client.service.getNodeList(facility_id, node_filter_info)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNodeList failed, ' + str(e))
            raise ErrorHandler.APIError('getNodeList failed, ' + str(e))

    # 構成情報ファイルの一時ファイルIDを返します。
    def getNodeConfigFileId(self):
        try:
            return self._client.service.getNodeConfigFileId()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getNodeConfigFileId failed, ' + str(e))
            raise ErrorHandler.APIError('getNodeConfigFileId failed, ' + str(e))

    # 構成情報ファイルのヘッダーを返します。
    def downloadNodeConfigFileHeader(self, condition_str, file_name, language):
        try:
            return self._client.service.downloadNodeConfigFileHeader(condition_str, file_name, language)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('downloadNodeConfigFileHeader failed, ' + str(e))
            raise ErrorHandler.APIError('downloadNodeConfigFileHeader failed, ' + str(e))

    # 引数で指定された条件に一致する構成情報ファイルを返します。
    def downloadNodeConfigFile(self, facility_id_list, target_date_time, file_name, language, manager_name, item_list):
        try:
            return self._client.service.downloadNodeConfigFile(facility_id_list, target_date_time, file_name, language,
                                                               manager_name, item_list)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('downloadNodeConfigFile failed, ' + str(e))
            raise ErrorHandler.APIError('downloadNodeConfigFile failed, ' + str(e))

    # 構成情報CSVファイルダウンロードで一度に取得する情報のノード数を取得します。
    def getDownloadNodeConfigCount(self):
        try:
            return self._client.service.getDownloadNodeConfigCount()
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('getDownloadNodeConfigCount failed, ' + str(e))
            raise ErrorHandler.APIError('getDownloadNodeConfigCount failed, ' + str(e))

    # 一時ファイルから指定されたファイル名の構成情報ファイルを削除します。
    def deleteNodeConfigFile(self, file_name):
        try:
            return self._client.service.deleteNodeConfigFile(file_name)
        except Exception, e:
            if 'need-role' in str(e):
                raise ErrorHandler.PermissoinError('deleteNodeConfigFile failed, ' + str(e))
            raise ErrorHandler.APIError('deleteNodeConfigFile failed, ' + str(e))
