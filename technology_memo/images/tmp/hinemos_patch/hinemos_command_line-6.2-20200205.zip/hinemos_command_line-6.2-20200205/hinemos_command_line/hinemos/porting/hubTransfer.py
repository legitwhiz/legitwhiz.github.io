# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import re
import hinemos.api.exceptions as ErrorHandler

def create_hub_transfer_list(element_tree, endpoint):
    info_list = []
    try:
        elem = element_tree.getroot()
        for el in elem.iter('transferInfo'):
            u'''
            transfer_info を生成し、リストに追加
            '''
            transfer_info = endpoint.create_object(el.tag)
            transfer_info.destProps = []
            temp = str(el.attrib).split(',')
            for s in temp:
                p = re.compile('\'.*\':')
                m = p.search(s, 0)
                if m:
                    attribute = s[m.start()+1:m.end()-2]
                    if attribute == 'transferId':
                        transfer_info['transferId'] = el.get(attribute)
                    elif attribute == 'description':
                        transfer_info['description'] = el.get(attribute)
                    elif attribute == 'destTypeID':
                        transfer_info['destTypeId'] = el.get(attribute)
                    elif attribute == 'ownerRoleId':
                        transfer_info['ownerRoleId'] = el.get(attribute)
                    elif attribute == 'transType':
                        if el.get(attribute) == 'REALTIME':
                            transfer_info['transType'] = 'realtime'
                        elif el.get(attribute) == 'BATCH':
                            transfer_info['transType'] = 'batch'
                        elif el.get(attribute) == 'DELAY':
                            transfer_info['transType'] = 'delay'
                        else:
                            raise ErrorHandler.ArgumentError('Invalid transType - %s.' % el.get(attribute))
                    elif attribute == 'dataType':
                        if el.get(attribute) == '0':
                            transfer_info['dataType'] = 'job'
                        elif el.get(attribute) == '1':
                            transfer_info['dataType'] = 'event'
                        elif el.get(attribute) == '2':
                            transfer_info['dataType'] = 'numeric'
                        elif el.get(attribute) == '3':
                            transfer_info['dataType'] = 'string'
                        else:
                            raise ErrorHandler.ArgumentError('Invalid dataType - %s.' % el.get(attribute))
                    elif attribute == 'validFlg':
                        if el.get(attribute) == 'true':
                            transfer_info['validFlg'] = True
                        else:
                            transfer_info['validFlg'] = False
                    elif attribute == 'calendarId':
                        transfer_info['calendarId'] = el.get(attribute)
                    else:
                        transfer_info[attribute] = el.get(attribute)
            for vl in el:
                destProps = endpoint.create_object('destProps')
                temp = str(vl.attrib).split(',')
                for s in temp:
                    p = re.compile('\'.*\': ')
                    m = p.search(s, 0)
                    if m:
                        attribute = s[m.start()+1:m.end()-3]
                        if attribute == 'name':
                            destProps.name = vl.get(attribute)
                        elif attribute == 'value':
                            destProps.value = vl.get(attribute)

                transfer_info.destProps.append(destProps)
            info_list.append(transfer_info)
        return info_list
    except Exception, e:
        raise ErrorHandler.FileReadError('create hubTransfer failed, ' + str(e))
