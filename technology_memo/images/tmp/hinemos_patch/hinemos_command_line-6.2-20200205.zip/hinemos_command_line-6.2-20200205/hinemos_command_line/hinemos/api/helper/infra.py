# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------
from hinemos.api.helper import attr_formatter
from hinemos.util.common import DateConvert


def result_formatter(result):
    if result.__class__.__module__ == 'suds.sudsobject':
        if result.__class__.__name__ == 'infraManagementInfo':
            attr_formatter(result, DateConvert.get_datetime_from_epochtime, 'regDate', 'updateDate')

def list_formatter(result):
    for x in result:
        result_formatter(x)
