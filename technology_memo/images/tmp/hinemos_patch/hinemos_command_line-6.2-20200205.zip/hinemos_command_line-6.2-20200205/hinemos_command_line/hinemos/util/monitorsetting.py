#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.api.exceptions import ArgumentError
from collections import OrderedDict


class MonitorSettingUtil(object):
    '''
    MonitorSettingUtil
    '''

    # @see com.clustercontrol.beanHinemosModuleConstant
    _monitor_type_ = ('MON_AGT_B', 'MON_CUSTOM_N', 'MON_CUSTOM_S',
                      'MON_CUSTOMTRAP_N', 'MON_CUSTOMTRAP_S', 'MON_HTP_N',
                      'MON_HTP_S', 'MON_HTP_SCE', 'MON_PRF_N', 'MON_PNG_N',
                      'MON_PRT_N', 'MON_PRC_N', 'MON_SNMP_N', 'MON_SNMP_S',
                      'MON_SNMP_TRP', 'MON_SQL_N', 'MON_SQL_S', 'MON_SYSLOG_S',
                      'MON_LOGFILE_S', 'MON_WINSERVICE_B', 'MON_WINEVENT_S',
                      'MON_JMX_N')

    _monitor_groups_ = ('AGENT', 'CUSTOM', 'CUSTOMTRAP', 'HTTP', 'HTTPSCE', 'JMX', 'LOGFILE', 'PING',
                        'PROCESS', 'RESOURCE', 'SERVICEPORT', 'SNMP', 'SNMPTRAP', 'SQL', 'SYSLOG', 'WINEVENT', 'WINSERVICE')

    # @see com.clustercontrol.port.bean.ProtocolConstant
    _port_protocol_type_ = {'TCP': '001', 'FTP': '002', 'SMTP': '003', 'SMTPS': '004',
                            'POP3': '005', 'POP3S': '006', 'IMAP': '007', 'IMAPS': '008', 'NTP': '009', 'DNS': '010'}

    # @see com.clustercontrol.custom.bean.CustomConstant
    _command_exec_type_ = ('INDIVIDUAL', 'SELECTED')  # BADHC

    # BinaryFile Monitor
    _collect_type_ = OrderedDict(
        [('individual', 'binary.collect.type.individual'),
         ('continuous', 'binary.collect.type.continuous')]
    )

    # BinaryFile Monitor
    _data_struct_ = OrderedDict(
        [('NONE', 'binary.tag.type.none'),
         ('regularInterval', None),
         ('pacct', 'pacct'),
         ('pcap', 'pcap'),
         ('wtmp', 'wtmp')]
    )

    # BinaryFile Monitor
    _record_ = OrderedDict(
        [('fixed', 'binary.length.type.fixed'),
         ('variable', 'binary.length.type.variable')]
    )

    # BinaryFile Monitor
    _tsType_ = OrderedDict(
        [('SEC_SINCE_EPOCH', 'timestamp.only.seconds'),
         ('SEC_AND_MSEC_SINCE_EPOCH', 'timestamp.seconds.useconds')]
    )

    # Compound Collectors
    _cc_collect_type_ = OrderedDict(
        [('numeric', 1),
         ('string', 2)])

    # Log count
    _log_count_method_ = OrderedDict(
        [('ALL', None),
         ('TIMESTAMP_RECIEVED', 'TIMESTAMP_RECIEVED')]
    )

    @staticmethod
    def convert2port_protocol_code(label):
        return None if label is None else MonitorSettingUtil._port_protocol_type_[label]

    @staticmethod
    def convert_keyword(key_str):
        if key_str == 'Audit Failure' or key_str == 'FailureAudit' or key_str == '4503599627370496':
            return(4503599627370496)
        elif key_str == 'Audit Success' or key_str == 'SuccessAudit' or key_str == '9007199254740992':
            return(9007199254740992)
        elif key_str == 'Classic' or key_str == '36028797018963968':
            return(36028797018963968)
        elif key_str == 'Correlation Hint' or key_str == '18014398509481984':
            return(18014398509481984)
        elif key_str == 'Response Time' or key_str == '281474976710656':
            return(281474976710656)
        elif key_str == 'SQM' or key_str == '2251799813685248':
            return(2251799813685248)
        elif key_str == 'WDI Context' or key_str == '562949953421312':
            return(562949953421312)
        elif key_str == 'WDI Diag' or key_str == '1125899906842624':
            return(1125899906842624)
        else:
            raise ArgumentError('Unknown keyword: %s!' % key_str)

    @staticmethod
    def convert_command_exec_type(label):
        return None if label is None else MonitorSettingUtil._command_exec_type_.index(label)

    @staticmethod
    def convert2collectType(label):
        return MonitorSettingUtil._collect_type_.get(label)

    @staticmethod
    def convert2tagType(label):
        return MonitorSettingUtil._data_struct_.get(label)

    @staticmethod
    def convert2lengthType(label):
        return MonitorSettingUtil._record_.get(label)

    @staticmethod
    def converter2tsType(label):
        return MonitorSettingUtil._tsType_.get(label)

    @staticmethod
    def converter2ccCollectType(label):
        return MonitorSettingUtil._cc_collect_type_.get(label)

    @staticmethod
    def converter2logCountMethod(label):
        return MonitorSettingUtil._log_count_method_.get(label)


class TrapUtil(object):

    _trap_version_ = {'1': 0, '2c': 1, '3': 1, '2c/3': 1}

    @staticmethod
    def convert2version(label):
        TrapUtil._trap_version_[label]
