#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2018 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.model import BasicObject

# RepositoryEndpointより取得した結果のダミーデータを除外するため、必要十分なモデルクラスの定義

class nodeListInfo(BasicObject):
    __keylist__ = ['facilityId', 'facilityName', 'ipAddressVersion', 'ipAddressV4', 'ipAddressV6', 'description', 'ownerRoleId']

    facilityId = None
    facilityName = None
    ipAddressVersion = None
    ipAddressV4 = None
    ipAddressV6 = None
    description = None
    ownerRoleId = None

    def __init__(self):
        BasicObject.__init__(self)

class facilityListInfo(BasicObject):
    __keylist__ = ['facilityId', 'facilityName', 'facilityType']

    facilityId = None
    facilityName = None
    facilityType = None

    def __init__(self):
        BasicObject.__init__(self)

class facilityInfo(BasicObject):
    __keylist__ = ['ownerRoleId', 'facilityId', 'facilityName', 'facilityType', 'description', 'iconImage', 'displaySortOrder', 'valid']

    ownerRoleId = None
    facilityId = None
    facilityName = None
    facilityType = None
    description = None
    iconImage = None
    displaySortOrder = None
    valid = None

    def __init__(self):
        BasicObject.__init__(self)

class nodePropertyBySNMPInfo(BasicObject):
    __keylist__ = ['facilityId', 'facilityName', 'description', 'platformFamily', 'ipAddressVersion', 'ipAddressV4', 'ipAddressV6', 'nodeHostnameInfo', 'nodeName', 'nodeOsInfo',
                   'snmpPort', 'snmpCommunity','snmpVersion', 'snmpSecurityLevel', 'snmpUser', 'snmpAuthPassword', 'snmpPrivPassword', 'snmpAuthProtocol', 'snmpPrivProtocol', 'nodeCpuInfo',
                   'nodeNetworkInterfaceInfo', 'nodeDiskInfo', 'nodeFilesystemInfo', 'administrator']

    facilityId = None
    facilityName = None
    description = None
    platformFamily = None
    ipAddressVersion = None
    ipAddressV4 = None
    ipAddressV6 = None
    nodeHostnameInfo = None #hostnameInfo()
    nodeName = None
    snmpPort = None
    snmpCommunity = None
    snmpVersion = None
    snmpSecurityLevel = None
    snmpUser = None
    snmpAuthPassword = None
    snmpPrivPassword = None
    snmpAuthProtocol = None
    snmpPrivProtocol = None
    nodeOsInfo = None  # nodeOsInfo
    nodeCpuInfo = None #nodeCpuInfo
    nodeNetworkInterfaceInfo = None #nodeNetworkInterfaceInfo
    nodeDiskInfo = None #nodeDiskInfo
    nodeFilesystemInfo = None #nodeFilesystemInfo
    administrator = None

    def __init__(self):
        BasicObject.__init__(self)
        self.nodeOsInfo = nodeOsInfo()
        self.nodeHostnameInfo = nodeHostnameInfo()
        self.nodeCpuInfo = nodeCpuInfo()
        self.nodeNetworkInterfaceInfo = nodeNetworkInterfaceInfo()
        self.nodeDiskInfo = nodeDiskInfo()
        self.nodeFilesystemInfo = nodeFilesystemInfo()

class nodeHostnameInfo(BasicObject):
    __keylist__ = ['hostname']

    hostname = None


class nodeOsInfo(BasicObject):
    __keylist__ = ['osName', 'osVersion']

    osName = None
    osVersion = None


class nodeCpuInfo(BasicObject):
    __keylist__ = ['deviceDisplayName', 'deviceName', 'deviceIndex', 'deviceType', 'deviceSize', 'deviceSizeUnit', 'deviceDescription']

    deviceDisplayName = None
    deviceName = None
    deviceIndex = None
    deviceType = None
    deviceSize = None
    deviceSizeUnit = None
    deviceDescription = None

class nodeNetworkInterfaceInfo(BasicObject):
    __keylist__ = ['deviceDisplayName', 'deviceName', 'deviceIndex', 'deviceType', 'deviceSize', 'deviceSizeUnit', 'deviceDescription', 'nicIpAddress', 'nicMacAddress']

    deviceDisplayName = None
    deviceName = None
    deviceIndex = None
    deviceType = None
    deviceSize = None
    deviceSizeUnit = None
    deviceDescription = None
    nicIpAddress = None
    nicMacAddress = None

class nodeDiskInfo(BasicObject):
    __keylist__ = ['deviceDisplayName', 'deviceName', 'deviceIndex', 'deviceType', 'deviceSize', 'deviceSizeUnit', 'deviceDescription', 'diskRpm']

    deviceDisplayName = None
    deviceName = None
    deviceIndex = None
    deviceType = None
    deviceSize = None
    deviceSizeUnit = None
    deviceDescription = None
    diskRpm = None

class nodeFilesystemInfo(BasicObject):
    __keylist__ = ['deviceDisplayName', 'deviceName', 'deviceIndex', 'deviceType', 'deviceSize', 'deviceSizeUnit', 'deviceDescription', 'filesystemType']

    deviceDisplayName = None
    deviceName = None
    deviceIndex = None
    deviceType = None
    deviceSize = None
    deviceSizeUnit = None
    deviceDescription = None
    filesystemType = None

class propertyNON(BasicObject):
    __keylist__ = ['facilityId', 'facilityName', 'description', 'iconImage', 'ownerRoleId']

    facilityId = None
    facilityName = None
    description = None
    iconImage = None
    ownerRoleId = None

