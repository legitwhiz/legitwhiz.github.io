# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import re
import hinemos.api.exceptions as ErrorHandler


'''
    {ypath1:new_attr_name, ...}
'''
attr_rename_list = {'/schedule@week':'dayOfWeek', '/schedule@minute': 'min', '/schedule@day': 'mday'}

def reverse_attr_rename_list(rename_list):
    rev_list = {}
    for k, v in rename_list.iteritems():
        rev_list[v] = re.sub('^.*[/@]', '', k)
    return rev_list

def create_maintenance_info_list(tree, endpoint):
    maintenanceInfoList = []
    elem = tree.getroot()
    try:
        for el in elem:
            if el.tag == 'maintenanceInfo':
                u'''
                maintenanceInfo を生成し、リストに追加
                '''
                maintenanceInfo = endpoint.create_object(el.tag)
                schedule = endpoint.create_object('schedule')
                temp = str(el.attrib).split(',')
                for s in temp:
                    p = re.compile('\'.*\':')
                    m = p.search(s, 0)
                    if m:
                        attribute = s[m.start()+1:m.end()-2]
                        if attribute == 'type' or attribute == 'month' or attribute == 'hour':
                            schedule[attribute] = el.get(attribute)
                        elif attribute == 'dayOfWeek':
                            schedule.week = el.get(attribute)
                        elif attribute == 'mday':
                            schedule.day = el.get(attribute)
                        elif attribute == 'min':
                            schedule.minute = el.get(attribute)
                        else:
                            maintenanceInfo[attribute] = el.get(attribute)
                for vl in el:
                    # 要素がnotifyIdの処理
                    if vl.tag == 'notifyId':
                        notifyRelationInfo = endpoint.create_object('notifyId')
                        for n in vl:
                            notifyRelationInfo[n.tag] = n.text
                        maintenanceInfo.notifyId.append(notifyRelationInfo)
                    else:
                        maintenanceInfo[vl.tag] = vl.text
                maintenanceInfo.schedule = schedule
                if maintenanceInfo.description == '':
                    del maintenanceInfo.description
                if maintenanceInfo.calendarId == '':
                    maintenanceInfo.calendarId = None
                maintenanceInfoList.append(maintenanceInfo)
        return maintenanceInfoList
    except Exception, e:
        raise ErrorHandler.FileReadError('create maintenanceInfoList failed, ' + str(e))

def format_maintenance_elem(elem):
    #HC for Utility Excel: remove calendarName=""
    if 'calendarName' in elem.attrib:
        del elem.attrib['calendarName']

def format_maintenance_for_modify(info):
    #HC for Utility Excel: do not have notifyGroupId tag
    if info.notifyGroupId is None or '' == info.notifyGroupId:
        info.notifyGroupId = 'MAINTENANCE-' + info.maintenanceId+'-0'

    for a in info.notifyId:
        if a.notifyGroupId is None or '' == a.notifyGroupId:
            a.notifyGroupId = 'MAINTENANCE-' + info.maintenanceId+'-0'

    return info
