# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import re
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.common import DateConvert

def create_calendar_list(element_tree, endpoint):
    info_list = []
    try:
        elem = element_tree.getroot()
        for el in elem.iter('calendarInfo'):
            u'''
            calendar_info を生成し、リストに追加
            '''
            calendar_info = endpoint.create_object(el.tag)
            calendar_info.calendarDetailList = []
            temp = str(el.attrib).split(',')
            for s in temp:
                p = re.compile('\'.*\':')
                m = p.search(s, 0)
                if m:
                    attribute = s[m.start()+1:m.end()-2]
                    if attribute == 'calendarId':
                        calendar_info['calendarId'] = el.get(attribute)
                    elif attribute == 'calendarName':
                        calendar_info['calendarName'] = el.get(attribute)
                    elif attribute == 'validTimeFrom':
                        timeValidTimeFrom = el.get(attribute).replace('-', '/')
                        calendar_info['validTimeFrom'] = DateConvert.get_epochtime_from_datetime(timeValidTimeFrom)
                    elif attribute == 'validTimeTo':
                        timeValidTimeTo = el.get(attribute).replace('-', '/')
                        calendar_info['validTimeTo'] = DateConvert.get_epochtime_from_datetime(timeValidTimeTo)
                    else:
                        calendar_info[attribute] = el.get(attribute)
            for vl in el:
                calendarDetailList = endpoint.create_object('calendarDetailList')
                temp = str(vl.attrib).split(',')
                for s in temp:
                    p = re.compile('\'.*\': ')
                    m = p.search(s, 0)
                    if m:
                        attribute = s[m.start()+1:m.end()-3]
                        if attribute == 'description':
                            calendarDetailList.description = vl.get(attribute)
                        elif attribute == 'yearNo':
                            calendarDetailList.year = vl.get(attribute)
                        elif attribute == 'monthNo':
                            calendarDetailList.month = vl.get(attribute)
                        elif attribute == 'dayType':
                            calendarDetailList.dayType = vl.get(attribute)
                        elif attribute == 'startTime':
                            calendarDetailList.timeFrom = DateConvert.get_epochtime_from_time(vl.get(attribute))
                        elif attribute == 'endTime':
                            calendarDetailList.timeTo = DateConvert.get_epochtime_from_time(vl.get(attribute))
                        elif attribute == 'executeFlg':
                            calendarDetailList.operateFlg = vl.get(attribute)
                        elif attribute == 'weekNo':
                            calendarDetailList.dayOfWeek = vl.get(attribute)
                        elif attribute == 'weekXth':
                            calendarDetailList.dayOfWeekInMonth = vl.get(attribute)
                        elif attribute == 'dayNo':
                            calendarDetailList.date = vl.get(attribute)
                        elif attribute == 'afterDay':
                            calendarDetailList.afterday = vl.get(attribute)
                        elif attribute == 'calendarPatternId':
                            calendarDetailList.calPatternId = vl.get(attribute)
                        elif attribute == 'substituteFlg':
                            calendarDetailList.substituteFlg = vl.get(attribute)
                        elif attribute == 'substituteTime':
                            calendarDetailList.substituteTime = vl.get(attribute)
                        elif attribute == 'substituteLimit':
                            calendarDetailList.substituteLimit = vl.get(attribute)

                        #HC4UL
                        if calendarDetailList.dayOfWeek is None:
                            calendarDetailList.dayOfWeek = 0
                        if calendarDetailList.dayOfWeekInMonth is None:
                            calendarDetailList.dayOfWeekInMonth = 0
                        if calendarDetailList.date is None:
                            calendarDetailList.date = 0

                calendar_info.calendarDetailList.append(calendarDetailList)
            info_list.append(calendar_info)
        return info_list
    except Exception, e:
        raise ErrorHandler.FileReadError('create calendar failed, ' + str(e))

def create_calendar_pattern_list(element_tree, endpoint):
    calendarPatternInfoList = []
    try:
        for el in element_tree.getroot():
            if el.tag == 'calendarPatternInfo':
                u'''
                calendarPatternInfo を生成し、リストに追加
                '''
                calendarPatternInfo = endpoint.create_object('calendarPatternInfo')
                temp = str(el.attrib).split(',')
                for s in temp:
                    p = re.compile('\'.*\':')
                    m = p.search(s, 0)
                    if m:
                        attribute = s[m.start()+1:m.end()-2]
                        if attribute == 'calendarPatternId':
                            calendarPatternInfo['calPatternId'] = el.get(attribute)
                        elif attribute == 'calendarPatternName':
                            calendarPatternInfo['calPatternName'] = el.get(attribute)
                        else:
                            calendarPatternInfo[attribute] = el.get(attribute)
                for vl in el:
                    ymd = endpoint.create_object('ymd')
                    temp = str(vl.attrib).split(',')
                    for s in temp:
                        p = re.compile('\'.*\':')
                        m = p.search(s, 0)
                        if m:
                            attribute = s[m.start()+1:m.end()-2]
                            if attribute == 'yearNo':
                                ymd.year = vl.get(attribute)
                            elif attribute == 'monthNo':
                                ymd.month = vl.get(attribute)
                            elif attribute == 'dayNo':
                                ymd.day = vl.get(attribute)
                    calendarPatternInfo.ymd.append(ymd)
                calendarPatternInfoList.append(calendarPatternInfo)
        return calendarPatternInfoList
    except Exception, e:
        raise ErrorHandler.FileReadError('create calendarPattern failed, ' + str(e))

#HC for Utility Excel
def format_calendar_for_modify(info):
    # info.calendarDetailList[].calPatternId = ""
    if info.calendarDetailList is not None:
        for a in info.calendarDetailList:
            if '' == a.calPatternId:
                a.calPatternId = None
    return info
