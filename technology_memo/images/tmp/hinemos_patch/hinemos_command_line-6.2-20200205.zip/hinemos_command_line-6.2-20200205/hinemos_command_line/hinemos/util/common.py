# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

import sys
import time
import hashlib
import base64
import traceback
import codecs
import locale
import re
import hinemos.api.exceptions as ErrorHandler

date_range_min = '2000/01/01 00:00:00'
date_range_max = '2299/12/31 23:59:59'

def is_empty(obj):
    return(obj is None or obj == '')


class SettingUtil(object):

    @staticmethod
    def convert2camel_back_case(s):
        if 0 < len(s):
            s = s.title().replace('_', '')
        if 0 < len(s):
            return s[0].lower() + s[1:]
        else:
            return s

    @staticmethod
    def convert2nbool(label):
        if label is None or label == '':
            return None
        if label in ['on', 'true', 'yes', '1', 1, True]:
            return True
        elif label in ['off', 'false', 'no', '0', 0, False]:
            return False
        raise ErrorHandler.ArgumentError('unknown label: %s' % label)

    @staticmethod
    def convert2nint(label):
        flg = SettingUtil.convert2nbool(label)
        if flg is None:
            return None
        elif flg is True:
            return 1
        else:
            return 0

    @staticmethod
    def convert2sec(val):
        if val is None:
            return None
        if bool(re.match(r'^\d+s$', str(val))):
            return int(val.replace('s', ''))
        if bool(re.match(r'^\d+h$', str(val))):
            return int(val.replace('h', '')) * 60 * 60
        if bool(re.match(r'^\d+$', str(val))):
            return int(val) * 60
        else:
            raise Exception('Error: Value: "%s" '
                            'cannot be converted to seconds') % str(val)


class DateConvert(object):

    @staticmethod
    def get_epochtime_from_datetime(dt_stamp):
        if dt_stamp is None:
            return None

        dt_min = time.strptime(date_range_min, '%Y/%m/%d %H:%M:%S')
        dt_max = time.strptime(date_range_max, '%Y/%m/%d %H:%M:%S')

        dt_seg = dt_stamp.split('.')
        if len(dt_seg) > 1:
            t = time.strptime(dt_stamp, '%Y/%m/%d %H:%M:%S.%f')
            if t < dt_min or dt_max < t:
                raise ErrorHandler.ArgumentError('out of range datetime: %s' % dt_stamp)
            milliepoch = str(int(time.mktime(t))) + dt_seg[1]
        else:
            t = time.strptime(dt_stamp, '%Y/%m/%d %H:%M:%S')
            if t < dt_min or dt_max < t:
                raise ErrorHandler.ArgumentError('out of range datetime: %s' % dt_stamp)
            milliepoch = str(int((time.mktime(t)))*1000)
        return milliepoch

    @staticmethod
    def get_datetime_from_epochtime(milliepoch):
        date = time.strftime('%Y/%m/%d %H:%M:%S',
                             time.localtime(int(milliepoch) / 1000))
        if int(str(milliepoch)[10:13]) != 0:
            date = date + '.' + str(milliepoch)[10:13]
        return date

    @staticmethod
    def get_time48_from_epochtime(epochtime):
        epochseconds = int((epochtime + 32400000) / 1000)
        isminus = False
        if epochseconds < 0:
            epochseconds = -epochseconds
            isminus = True
        hourcount = 0
        hourseconds = 60 * 60
        while epochseconds >= hourseconds:
            epochseconds -= hourseconds
            hourcount += 1
        convtime = '%02d:%s' % (hourcount, time.strftime(
            '%M:%S', time.gmtime(epochseconds)))
        return convtime if not isminus else '-' + convtime

    @staticmethod
    def get_epochtime_from_time(hhmmss):
        if hhmmss is None:
            return None

        a = hhmmss.split(':')
        epochtime = (int(a[0]) * 3600) + (int(a[1]) * 60) + (int(a[2]))
        epochtime = (epochtime * 1000) - 32400000
        return epochtime


class PasswordConvert(object):

    @staticmethod
    def slappasswd(password):
        ctx = hashlib.md5()
        ctx.update(password)
        hashed = base64.b64encode(ctx.digest())
        return hashed


class ResultPrinter(object):

    @staticmethod
    def success(result, prefix, action, formatter=None):
        try:
            #sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
            if result is not None:
                if formatter:
                    formatter(result)
                if isZeepObject(result):
                    print ZeepResultPrinter(result)
                else:
                    print result
            print
            print prefix + ',', action, 'succeeded.'
            return 0
        except Exception:
            raise

    @staticmethod
    def info(msg):
        try:
            #sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
            print msg
        except Exception:
            raise

    @staticmethod
    def warning(msg):
        try:
            #sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
            print 'WARN:', msg
        except Exception:
            raise

    @staticmethod
    def failure(ex):
        try:
            # エラーの情報をsysモジュールから事前に取得
            info = sys.exc_info()
            # with open('log', mode='a+') as f:
            #     f.write(dir(sys.stderr))
            # sys.stderr = codecs.getwriter(
            #     locale.getpreferredencoding())(sys.stderr)
            try:
                print >>sys.stderr, ex.__class__.__name__ + ': ' + str(ex)
            except Exception:
                print >>sys.stderr, ex.__class__.__name__ + ': ' + str(ex).decode(locale.getpreferredencoding())

            # ----------------------------------------------------------------------------------
            # tracebackモジュールのformat_tbメソッドで特定の書式に変換
            tbinfo = traceback.format_tb(info[2])

            # 収集した情報を読みやすいように整形して出力する
            print('')
            print(' [Error Details] '.center(80, '='))
            for tbi in tbinfo:
                print(tbi)
            try:
                print(str(info[1]))
            except Exception:
                print(str(info[1]).decode(locale.getpreferredencoding()))
            print('=' * 80)
            print('')
            # -----------------------------------------------------------------------------------

            if isinstance(ex, ErrorHandler.ArgumentError):
                return 1
            elif isinstance(ex, AssertionError):
                print >>sys.stderr, 'something wrong with the API arguments!'
                return 1
            elif isinstance(ex, ErrorHandler.LoginError):
                return 2
            elif isinstance(ex, ErrorHandler.PermissoinError):
                return 3
            elif isinstance(ex, ErrorHandler.APIError):
                return 4
            elif isinstance(ex, ErrorHandler.PortingExportError) or isinstance(ex, ErrorHandler.PortingImportError):
                return 5
            elif isinstance(ex, ErrorHandler.ObjectNotFoundError) or isinstance(ex, ErrorHandler.JobNotFoundError):
                return 6
            elif isinstance(ex, ErrorHandler.BadResultError):
                return 7
            else:
                return 9
        except Exception:
            raise


def isZeepObject(result):
    if isinstance(result, list) and (len(result) != 0) and (result[0].__class__.__module__ == 'zeep.objects'):
        return True
    if result.__class__.__module__ == 'zeep.objects':
        return True
    return False


class ZeepResultPrinter(object):
    def __init__(self, result):
        if not isinstance(result, list):
            result_list = [result]
            self.zeep_result_list = result_list
        else:
            self.zeep_result_list = result
        self.formatted_result = ""

    def __str__(self):
        if 0 == len(self.formatted_result):
            self.formatted_result += "[ "
        else:
            self.formatted_result += "\n[ "
        for zeep_result_info in self.zeep_result_list:
            self.formatted_result += "\n  {"
            for key in zeep_result_info:
                value = zeep_result_info[key]
                if isinstance(value, unicode):
                    self.formatted_result += "\n    '%s': %s," % (key, value.encode('utf-8'))
                elif isinstance(value, list) and (len(value) != 0):
                    self.printZeepObjectList(key, value)
                elif value.__class__.__module__ == 'zeep.objects':
                    self.printZeepObject(key, value)
                else:
                    self.formatted_result += "\n    '%s': %s," % (key, value)
            self.formatted_result += "\n  },"
        self.formatted_result = self.formatted_result[:-1] + "\n]"
        return self.formatted_result

    def printZeepObjectList(self, key, obj_list):
        self.formatted_result += "\n    '%s': [ " % key
        for obj in obj_list:
            self.formatted_result += "\n      {"
            for attr in obj:
                attr_val = obj[attr]
                if isinstance(attr_val, unicode):
                    self.formatted_result += "\n        '%s': %s," % (attr, attr_val.encode('utf-8'))
                else:
                    self.formatted_result += "\n        '%s': %s," % (attr, attr_val)
            self.formatted_result += "\n      },"
        self.formatted_result = self.formatted_result[:-1] + "\n    ],"

    def printZeepObject(self, key, obj):
        self.formatted_result += "\n    '%s': {" % key
        for attr in obj:
            attr_val = obj[attr]
            if isinstance(attr_val, unicode):
                self.formatted_result += "\n      '%s': %s," % (attr, attr_val.encode('utf-8'))
            else:
                self.formatted_result += "\n      '%s': %s," % (attr, attr_val)
        self.formatted_result += "\n    },"

