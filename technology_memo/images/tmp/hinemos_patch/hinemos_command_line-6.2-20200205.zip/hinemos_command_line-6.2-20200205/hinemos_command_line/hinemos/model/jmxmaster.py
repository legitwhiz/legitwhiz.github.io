#-*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

from hinemos.model import BasicObject

class JmxMasterInfo( BasicObject ):
    __keylist__ = [ 'attributeName', 'id', 'keys', 'measure', 'name', 'objectName' ]
