# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------
from hinemos.util.common import DateConvert

def attr_formatter(result, func, *args):
    for x in args:
        raw = getattr(result, x)
        if raw is not None and raw != '':
            setattr(result, x, func(raw))

def remove_attrib(result, *args):
    for x in args:
        delattr(result, x)

class BasicFormatter(object):

    _datetime_fields = ('regDate', 'updateDate')
    _time48_fields = tuple()
    _hidden_fields = tuple()

    @classmethod
    def output(cls, result, masked=True):
        if result.__class__.__module__ == 'suds.sudsobject':
            #if result.__class__.__name__ == '*Info':

            if BasicFormatter._datetime_fields:
                attr_formatter(result, DateConvert.get_datetime_from_epochtime, *cls._datetime_fields)

            if BasicFormatter._time48_fields:
                attr_formatter(result, DateConvert.get_time48_from_epochtime, *cls._time48_fields)

            if masked:
                remove_attrib(result, *cls._hidden_fields)

    @classmethod
    def input(cls, info):
        if info.__class__.__module__ == 'suds.sudsobject':
            #if result.__class__.__name__ == '*Info':

            if BasicFormatter._datetime_fields:
                attr_formatter(info, DateConvert.get_epochtime_from_datetime, *cls._datetime_fields)

            if BasicFormatter._time48_fields:
                attr_formatter(info, DateConvert.get_epochtime_from_time, *cls._time48_fields)

    @classmethod
    def input_xml(cls, element):
        for x in element:
            if x.tag in cls._datetime_fields:
                x.text = DateConvert.get_epochtime_from_datetime(x.text)

class NoDatetimeFormatter(BasicFormatter):

    _datetime_fields = tuple()
    _hidden_fields = ('updateUser', 'regUser', 'regDate', 'updateDate')


class CTypeFormatter(BasicFormatter):

    _datetime_fields = ('createDatetime', 'modifyDatetime')
    _hidden_fields = tuple()

class CtTypeFormatter(BasicFormatter):

    _datetime_fields = ('createTime', 'updateTime')
    _hidden_fields = tuple()

class CNoDatetimeTypeFormatter(BasicFormatter):

    _datetime_fields = tuple()
    _hidden_fields = ('createDatetime', 'createUserId', 'modifyDatetime', 'modifyUserId')
