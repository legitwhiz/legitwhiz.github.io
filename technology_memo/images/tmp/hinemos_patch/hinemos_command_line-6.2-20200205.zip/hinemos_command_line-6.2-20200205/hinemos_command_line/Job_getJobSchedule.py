#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定した実行契機IDと一致したスケジュール実行契機情報を取得する

<概要>
引数で指定した実行契機IDと一致したスケジュール実行契機情報を取得して表示します。

<使用例>
[command]
    $ python Job_getJobSchedule.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_SC

[result]
    (jobSchedule){
       createTime = "2017/03/07 11:50:25.654"
       createUser = "hinemos"
       id = "TEST_SC"
       jobId = "JOB01"
       jobName = "JOB01"
       jobunitId = "JU01"
       name = "TEST_SC"
       ownerRoleId = "ALL_USERS"
       type = 0
       updateTime = "2017/03/07 11:50:25.654"
       updateUser = "hinemos"
       valid = True
       minute = 0
       scheduleType = 1
     }
    http://192.168.1.2:8080/HinemosWS/, getJobSchedule succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--scheduleID',  action='store', type='string', metavar='ID', dest='schedule_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='schedule ID')

    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = endpoint.getJobSchedule(opts.schedule_id)
        if result is not None:
            result.createTime = DateConvert.get_datetime_from_epochtime(result.createTime)
            result.updateTime = DateConvert.get_datetime_from_epochtime(result.updateTime)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getJobSchedule')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
