#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定されたイベント情報のコメントを変更する

<概要>
引数で指定されたイベント情報のコメントを変更します。

<使用例>
[command]
    $ python Monitor_modifyComment.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -M TEST_PING2 -P MON_PNG_N -F TEST_NODE -O "2017/03/08 11:44:45.234" -m '' -C 'This is for test.'

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyComment succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitor import MonitorEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-M', '--monitorID',  action='store', type='string', metavar='ID', dest='monitor_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='monitorID')
    psr.add_option('-m', '--monitorDetailID',  action='store', type='string', metavar='ID', dest='monitor_detail_id',
                    default=None, help='monitorDetailID')
    psr.add_option('-P', '--pluginID',  action='store', type='string', metavar='ID', dest='plugin_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='pluginID')
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='facilityID')
    psr.add_option('-O', '--outputDate', action='store', type='string', metavar='STRING', dest='output_date',
                    default=(None, 'REQUIRED','NOTBLANK'), help='outputDate: \'yyyy/mm/dd HH:MM:SS.sss\'')
    psr.add_option('-C', '--comment', action='store', type='string', metavar='STRING', dest='comment',
                    default=None, help='comment')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorEndpoint(opts.mgr_url, opts.user, opts.passwd)

        opts.output_date = DateConvert.get_epochtime_from_datetime(opts.output_date)

        endpoint.modifyComment(opts.monitor_id, opts.monitor_detail_id, opts.plugin_id, opts.facility_id, opts.output_date, opts.comment, None, None)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyComment')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
