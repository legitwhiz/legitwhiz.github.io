#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定された条件に一致するイベント情報の確認を一括変更する

<概要>
引数で指定された条件に一致するイベント情報の確認を一括変更します。

<使用例>
[command]
    $ python Monitor_modifyBatchConfirm.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I APITEST_SCOPE

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyBatchConfirm succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitor import MonitorEndpoint
from hinemos.util.notify import NotifyUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=None, help='Facility ID')

    psr.add_option('-P', '--priorities', action='store_split', type='string', metavar='STRING', dest='priorities_raw',
                    default=None, help='Priorities [INFO|WARN|CRITICAL|UNKNOWN]. Download all by default.')

    psr.add_option('-o', '--outputFromDate', action='store', type='string', metavar='DATETIME', dest='output_from_date',
                    default=None, help='Output date from [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-O', '--outputToDate', action='store', type='string', metavar='DATETIME', dest='output_to_date',
                    default=None, help='Output date to [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-g', '--generationFromDate', action='store', type='string', metavar='DATETIME', dest='generation_from_date',
                    default=None, help='Created date from [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-G', '--generationToDate', action='store', type='string', metavar='DATETIME', dest='generation_to_date',
                    default=None, help='Created date to [yyyy/mm/dd HH:MM:SS]')

    #TODO Monitor ID
    #TODO Monitor Detail ID

    psr.add_option('-T', '--facilityType', action='store', type='int', metavar='INT', dest='facility_type',
                    default=1, help='Facility type = 0:Sub-scope Facilities Only or 1:ALL Facilities')
    psr.add_option('-A', '--application', action='store', type='string', metavar='STRING', dest='application',
                    default=None, help='Application')
    psr.add_option('-M', '--message', action='store', type='string', metavar='STRING', dest='message',
                    default=None, help='Message')
    psr.add_option('-C', '--comment', action='store', type='string', metavar='STRING', dest='comment',
                    default=None, help='Comment')
    psr.add_option('-c', '--commentUser', action='store', type='string', metavar='STRING', dest='comment_user',
                    default=None, help='Commented User')

    psr.add_option('-F', '--confirmFlg', action='store', type='int', metavar='INT', dest='confirm_type',
                    default=(1, 'REQUIRED', {'INLIST':[0, 1, 2]}), help='Confirm flag = 0:unconfirmed, 1:confirmed, 2:confirming')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorEndpoint(opts.mgr_url, opts.user, opts.passwd)

        if opts.generation_from_date is not None:
            opts.generation_from_date = DateConvert.get_epochtime_from_datetime(opts.generation_from_date)
        if opts.generation_to_date is not None:
            opts.generation_to_date = DateConvert.get_epochtime_from_datetime(opts.generation_to_date)
        if opts.output_from_date is not None:
            opts.output_from_date = DateConvert.get_epochtime_from_datetime(opts.output_from_date)
        if opts.output_to_date is not None:
            opts.output_to_date = DateConvert.get_epochtime_from_datetime(opts.output_to_date)

        ### method edit###
        eventBatchConfirmInfo = endpoint.create_object('eventBatchConfirmInfo')
        if opts.application is not None:
            eventBatchConfirmInfo.application=opts.application
        if opts.comment is not None:
            eventBatchConfirmInfo.comment=opts.comment
        if opts.comment_user is not None:
            eventBatchConfirmInfo.commentUser=opts.comment_user
        if opts.facility_type is not None:
            eventBatchConfirmInfo.facilityType=opts.facility_type
        if opts.generation_from_date is not None:
            eventBatchConfirmInfo.generationFromDate=opts.generation_from_date
        if opts.generation_to_date is not None:
            eventBatchConfirmInfo.generationToDate=opts.generation_to_date
        if opts.message is not None:
            eventBatchConfirmInfo.message=opts.message
        if opts.output_from_date is not None:
            eventBatchConfirmInfo.outputFromDate=opts.output_from_date
        if opts.output_to_date is not None:
            eventBatchConfirmInfo.outputToDate=opts.output_to_date
        if opts.priorities is None:
            opts.priorities = ['INFO','WARN','CRITICAL','UNKNOWN']
        eventBatchConfirmInfo.priorityList=tuple(NotifyUtil.convert2priority(a) for a in opts.priorities)
        print eventBatchConfirmInfo.priorityList

        endpoint.modifyBatchConfirm(opts.confirm_type, opts.facility_id, eventBatchConfirmInfo)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyBatchConfirm')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
