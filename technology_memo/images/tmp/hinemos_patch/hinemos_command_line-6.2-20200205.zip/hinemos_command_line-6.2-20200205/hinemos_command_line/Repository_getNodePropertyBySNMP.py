#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
SNMPを利用してノードの情報を取得する

<概要>
SNMPを利用してノードの情報を取得して表示します。

<使用例>
[command]
    $ python Repository_getNodePropertyBySNMP.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I 192.168.0.2 -P 161 -C public -V 2c

[result]
    (nodePropertyBySNMPInfo){
         facilityId = "TEST_NODE"
         facilityName = "TEST_NODE"
         description = "Auto detect at Mon Mar 06 13:34:41 +09:00 2017"
         platformFamily = "LINUX"
         ipAddressVersion = 4
         ipAddressV4 = "192.168.0.3"
         ipAddressV6 = None
         nodeHostnameInfo[] =
             (nodeHostnameInfo){
                hostname = "TEST_NODE"
         }
         nodeName = "TEST_NODE"
         nodeOsInfo =
             (nodeOsInfo){
                osName = "Linux"
                osVersion = "Linux TEST_NODE 3.10.0-862.el7.x86_64 #1 SMP Wed Mar 21 18:14:51 EDT 2018 x86_64"
         }
         ...中略...
         nodeFilesystemInfo[] =
             (nodeFilesystemInfo){
                deviceDisplayName = "/"
                deviceName = "/"
                deviceIndex = 31
                deviceType = "filesystem"
                deviceSize = 0
                deviceSizeUnit = None
                deviceDescription = None
                filesystemType = None
         },
         administrator = "Root <root@localhost> (configure /etc/snmp/snmp.local.conf)"
     }
    http://192.168.1.2:8080/HinemosWS/, getNodePropertyBySNMP succeeded.


※ 実行結果のうち、snmpVersionの値については、
利用したSNMPのバージョンに応じて
以下のものが表示されます。

  - SNMPバージョン 1   => 「snmpVersion = 0」
  - SNMPバージョン 2c  => 「snmpVersion = 1」
  - SNMPバージョン 3   => 「snmpVersion = 3」
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.repository import RepositoryEndpoint
from hinemos.model.repository import nodePropertyBySNMPInfo, nodeHostnameInfo, nodeCpuInfo, nodeNetworkInterfaceInfo, nodeDiskInfo, nodeFilesystemInfo
from hinemos.util.repository import ResultSet

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--ipAddress', action='store', type='string', metavar='STRING', dest='ip_address',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='ipAddress')
    psr.add_option('-P', '--port', action='store', type='int', metavar='INT', dest='port',
                    default=161, help='port number (default: 161)')
    psr.add_option('-C', '--community', action='store', type='string', metavar='STRING', dest='community',
                    default=('public', 'NOTBLANK'), help='community name (default: public)')
    psr.add_option('-V', '--snmpVersion', action='store', type='string', metavar='STRING', dest='version',
                    default=('2c',{'INLIST':['1','2c','3']}), help='version 1 or 2c or 3 (default: 2c)')
    psr.add_option('-F', '--facilityId', action='store', type='string', metavar='STRING', dest='facility_id',
                    default=None, help='facility id')

    psr.add_option('--snmpSecurityLevel', action='store', type='string', metavar='STRING', dest='snmpSecurityLevel',
                    default=('noauth_nopriv', {'INLIST':['noauth_nopriv', 'auth_nopriv', 'auth_priv']}), help='security level: noauth_nopriv or auth_nopriv or auth_priv (SNMPv3 only)')
    psr.add_option('--snmpUser', action='store', type='string', metavar='STRING', dest='snmpUser',
                    default='', help='username (SNMPv3 only)')
    psr.add_option('--snmpAuthPasswd', action='store', type='string', metavar='STRING', dest='snmpAuthPasswd',
                    default='', help='auth pass (SNMPv3 only)')
    psr.add_option('--snmpPrivPasswd', action='store', type='string', metavar='STRING', dest='snmpPrivPasswd',
                    default='', help='priv pass (SNMPv3 only)')
    psr.add_option('--snmpAuthProtocol', action='store', type='string', metavar='STRING', dest='snmpAuthProtocol',
                    default=('MD5', {'INLIST':['MD5', 'SHA']}), help='auth protocol: MD5 or SHA (SNMPv3 only)')
    psr.add_option('--snmpPrivProtocol', action='store', type='string', metavar='STRING', dest='snmpPrivProtocol',
                    default=('DES', {'INLIST':['DES', 'AES']}), help='priv protocol: DES or AES (SNMPv3 only)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)

    try:
        ### method edit###
        result = endpoint.getNodePropertyBySNMP(opts.ip_address, opts.port, opts.community, opts.version, opts.facility_id, opts.snmpSecurityLevel, opts.snmpUser, opts.snmpAuthPasswd, opts.snmpPrivPasswd, opts.snmpAuthProtocol, opts.snmpPrivProtocol)
        nodeInfo = nodePropertyBySNMPInfo()
        
        if result is not None:
            nodeInfo = ResultSet.nodePropertyBySNMPInfo(result)
        return_code = ResultPrinter.success(nodeInfo, opts.mgr_url, 'getNodePropertyBySNMP')
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
