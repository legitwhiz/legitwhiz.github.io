#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ファイル転送ジョブの基本情報を登録する

<概要>
ファイル転送ジョブの基本情報を登録します。

<使用例>
[command]
    $ python Job_addJob_FileJob.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001 -P JN001 -I JF001 -N "FileTransJob-1" -S NODE001 -F /tmp/file1.txt -T SCOPE01 -R /root/store/

[result]
    http://192.168.1.2:8080/HinemosWS/, addJob succeeded.
"""

import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-J', '--jobunitID',  action='store', type='string', metavar='ID', dest='jobunit_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Jobunit ID')
    psr.add_option('-P', '--parentID',  action='store', type='string', metavar='ID', dest='parent_id',
                   default=(None, 'NOTBLANK'), help='Parent job ID')
    psr.add_option('-I', '--jobID',  action='store', type='string', metavar='ID', dest='job_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Job ID')
    psr.add_option('-N', '--jobName', action='store', type='string', metavar='STRING', dest='name',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Job name')

    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='description')

    psr.add_option('-M', '--modularize', action='store', type='string', metavar='BOOL', dest='modularize_raw', converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST':['true','false']}), help='Set as module')
    psr.add_option('--iconID',  action='store', type='string', metavar='ID', dest='iconID',
                   default=None, help='Icon ID')

    psr.add_option('-S', '--srcFacilityID',  action='store', type='string', metavar='ID', dest='src_facility_id',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='srcFacilityID : source facility ID ')
    psr.add_option('-F', '--srcFile', action='store', type='string', metavar='STRING', dest='src_file',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='srcFile source file path')
    psr.add_option('-T', '--destFacilityID',  action='store', type='string', metavar='ID', dest='dest_facility_id',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='destFacilitID : destination facility ID ')
    psr.add_option('-R', '--destDirectory', action='store', type='string', metavar='STRING', dest='dest_directory',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='destDirectory : destination directory ')
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, opts.jobunit_id)
        del job_tree_full

        # ユニットのロール確保
        owner_role_id = endpoint.getJobFull(job_tree.data).ownerRoleId

        new_job_tree = endpoint.create_job_tree_item_basic(\
                    JobUtil.convert2job_type('FILEJOB'),\
                    opts.jobunit_id,\
                    opts.job_id,\
                    opts.name,\
                    opts.description,\
                    owner_role_id,\
                    opts.modularize,\
                    opts.iconID)
        new_job_tree.data.file = endpoint.create_job_file_info(opts.src_facility_id, opts.src_file, opts.dest_facility_id, opts.dest_directory)
        new_job_tree.data.waitRule = endpoint.create_wait_rule_info()

        LOGGER.debug(new_job_tree)

        parent_id = opts.parent_id
        if parent_id is None:
            parent_id = opts.jobunit_id
        added = JobUtil.add_child(job_tree, parent_id, new_job_tree)
        if not added:
            raise ErrorHandler.ArgumentError('Failed to add new job!')

        LOGGER.debug(job_tree)
        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addJob')
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
