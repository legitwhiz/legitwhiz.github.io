#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ノード一覧を取得する

<概要>
ノード一覧を取得して表示します。

<使用例>
[command]
    $ python Repository_getNodeListAll.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    [(nodeListInfo){
       facilityId = "NODE001"
       facilityName = "NODE001"
       ipAddressVersion = 4
       ipAddressV4 = "192.168.1.3"
       ipAddressV6 = None
       ownerRoleId = "ALL_USERS"
     }]
    http://192.168.1.2:8080/HinemosWS/, getNodeListAll succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.repository import ResultSet

def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit###
        nodeInfo = []
        result = endpoint.getNodeListAll()
        list = []

        if result is not None:
            list = ResultSet.nodeListInfo(result)
        return_code = ResultPrinter.success(list, opts.mgr_url, 'getNodeListAll')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
