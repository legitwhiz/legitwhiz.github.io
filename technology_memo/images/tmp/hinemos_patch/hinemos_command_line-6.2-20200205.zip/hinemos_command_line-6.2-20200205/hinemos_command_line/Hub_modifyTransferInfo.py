#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
収集蓄積(転送)情報を変更する

<概要>
収集蓄積(転送)情報を変更します。

<使用例>
[command]
    $ python Hub_modifyTransferInfo.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TRAN001 -C CAL001

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyTransferInfo succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.hub import HubUtil
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.hub import HubEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--transferID',  action='store', type='string', metavar='ID', dest='info_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='LogFormat ID')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='Description')
    psr.add_option('-C', '--calendarId', action='store', type='string', metavar='STRING', dest='calendar_id',
                    default=None, help='calendar ID')

    psr.add_option('-E', '--destTypeID',  action='store', type='string', metavar='ID', dest='dest_type_id',
                    default=(None, 'NOTBLANK'), help='Destination type ID, e.g. "fluentd"')
    psr.add_option('-P', '--destProps',  action='my_x_append', type='string', metavar='LIST', dest='destProps',
                    default=None, help='Destination properties, e.g. "fluentd.url=http://127.0.0.1:8888/" "fluentd.connect_timeout=5000" "fluentd.request_timeout=10000"')

    psr.add_option('-T', '--transType', action='store', type='string', metavar='STRING', dest='trans_type',
                    default=(None, {'INLIST':HubUtil._transfer_type_}), help='transfer type (' + ', '.join(HubUtil._transfer_type_)+ ')')

    psr.add_option('-N', '--interval', action='store', type='int', metavar='INT', dest='interval',
                    default=None, help='interval')
    psr.add_option('-e', '--enable', action='store', type='string', metavar='STRING', dest='enable_raw', converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false')

    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = HubEndpoint(opts.mgr_url, opts.user, opts.passwd)

        info = HubUtil.set_transfer_info(
            endpoint.getTransferInfo(opts.info_id),
            opts.description, opts.calendar_id,
            None,
            opts.dest_type_id,
            endpoint.get_dest_type_prop_msts(opts.dest_type_id) if opts.dest_type_id is not None else None,
            opts.trans_type,opts.interval,
            opts.enable)

        # Replace dest props
        if opts.destProps is not None:
            for arg in opts.destProps:
                pair = arg.split('=', 1)
                for subinfo in info.destProps:
                    if subinfo.name == pair[0]:
                        subinfo.value = pair[1]
                        break

        result = endpoint.modifyTransferInfo(info)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'modifyTransferInfo')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
