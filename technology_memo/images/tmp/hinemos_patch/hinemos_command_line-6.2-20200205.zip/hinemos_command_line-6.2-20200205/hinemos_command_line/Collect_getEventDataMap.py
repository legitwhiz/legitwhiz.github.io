#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
イベント履歴のフラグを取得する

<概要>
イベント履歴のフラグを取得します。

<使用例>
[command]
    $ python Collect_getEventDataMap.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE

[result]
    (hashMapInfo){
       map2 = ""
       map3 = ""
       map4 = ""
       map5 = ""
       map6 = ""
       map7 =
          (map7){
             entry[] =
                (entry){
                   key = "TEST_NODE"
                   value =
                      (arrayListInfo){
                         list3[] =
                            (eventDataInfo){
                               application = "agent01"
                               collectGraphFlg = True
                               comment = None
                               commentUser = None
                               confirmUser = None
                               confirmed = 0
                               facilityId = "TEST_NODE"
                               generationDate = 1488946065000
                               message = "$[MESSAGE_AGENT_IS_AVAILABLE]"
                               monitorDetailId = None
                               monitorId = "AGENT01"
                               outputDate = 1488946065214
                               ownerRoleId = "ALL_USERS"
                               pluginId = "MON_AGT_B"
                               priority = 3
                               scopeText = "TEST_NODE"
                            },
                      }
                },
          }
       map8 = ""
     }
    http://192.168.1.2:8080/HinemosWS/, getEventDataMap succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.collect import CollectEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-F', '--facilityIDList', action='store', type='string', metavar='STRING', dest='facilityIdList',
                    default=(None, 'REQUIRED','NOTBLANK'), help='facilityID1,facilityID2,...,facilityIDN')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = CollectEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getEventDataMap(opts.facilityIdList)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getEventDataMap')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
