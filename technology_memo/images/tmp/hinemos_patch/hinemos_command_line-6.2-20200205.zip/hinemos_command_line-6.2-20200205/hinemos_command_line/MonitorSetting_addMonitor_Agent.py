#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
Hinemosエージェント監視の監視設定情報を登録する

<概要>
Hinemosエージェント監視の監視設定情報を登録します。

<使用例>
[command]
    $ python MonitorSetting_addMonitor_Agent.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I AGT001 -A MYAPP -F NODE001

[result]
    http://192.168.1.2:8080/HinemosWS/, addMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.notify import NotifyUtil
from hinemos.util.argsparserbuilder import MonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = MonitorSettingArgsParserBuilder()\
        .build_monitor_setting_add_args_parser(help_default_info,
                                               exclude=['collect'])

    psr.add_option('-O', '--okPriority', action='store', type='string',
                   metavar='STRING', dest='ok_priority',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                       'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']
                   }),
                   help='okPriority = INFO or WARN or CRITICAL or'
                   ' UNKNOWN (default: INFO)')
    psr.add_option('-G', '--ngPriority', action='store', type='string',
                   metavar='STRING', dest='ng_priority',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                       'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']
                   }),
                   help='ngPriority = INFO or WARN or CRITICAL or'
                   ' UNKNOWN (default: CRITICAL)')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        notify_infos = []
        if opts.notify_ids is not None:
            notify_infos = []
            notify_id_lst = opts.notify_ids.split(',')
            for a in notify_endpoint.getNotifyList():
                if a.notifyId in notify_id_lst:
                    notify_infos.append(a)
                    notify_id_lst.remove(a.notifyId)
            if 0 < len(notify_id_lst):
                ResultPrinter.warning(
                    'Notify ' + (', '.join(notify_id_lst)) + ' will be ignored!')
        if 0 == len(notify_infos):
            notify_infos = None

        ### execute ###
        endpoint.add_monitor_agent(
            opts.monitor_id,
            opts.facility_id,
            opts.run_interval,
            opts.calendar_id,
            opts.application,
            opts.description,
            opts.owner_role_id,
            SettingUtil.convert2nint(opts.monitor),
            notify_infos,
            None if opts.ok_priority is None else NotifyUtil.convert2priority(
                opts.ok_priority),
            None if opts.ng_priority is None else NotifyUtil.convert2priority(opts.ng_priority))

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
