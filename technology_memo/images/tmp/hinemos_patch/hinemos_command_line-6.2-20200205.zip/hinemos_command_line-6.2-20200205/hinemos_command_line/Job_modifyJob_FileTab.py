#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
「ファイル」タブの情報を変更する

<概要>
「ファイル」タブの情報を変更します。

<使用例>
[command]
    $ python Job_modifyJob_FileTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JF001 --destFacilityID LINUX --destDirectory /tmp/test --srcFacilityID NODE001 --srcFile /tmp/test.log -Y user01 -X 1

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.modifier import ObjectModifier

def main():

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    ### ファイル転送タブ設定項目 ###
    psr.add_option('-M', '--processMode', action='store', type='int', metavar='INT', dest='process_mode',
                    default=(None, 'NOTBLANK'), help='processMode : all nodes = 0, one node = 1')
    psr.add_option('-S', '--srcFacilityID',  action='store', type='string', metavar='ID', dest='src_facility_id',
                    default=(None, 'NOTBLANK'), help='srcFacilityID : source facility ID ')
    psr.add_option('-F', '--srcFile', action='store', type='string', metavar='STRING', dest='src_file',
                    default=(None, 'NOTBLANK'), help='srcFile source file path')
    psr.add_option('-T', '--destFacilityID',  action='store', type='string', metavar='ID', dest='dest_facility_id',
                    default=(None, 'NOTBLANK'), help='destFacilitID : destination facility ID ')
    psr.add_option('-R', '--destDirectory', action='store', type='string', metavar='STRING', dest='dest_directory',
                    default=(None, 'NOTBLANK'), help='destDirectory : destination directory ')

    psr.add_option('-Z', '--compress', action='store', type='string', metavar='STRING', dest='compress_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='compressionFlg : enable=true, disable=false')
    psr.add_option('-C', '--checkFile', action='store', type='string', metavar='STRING', dest='check_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='checkFlg : enable=true, disable=false')
    psr.add_option('-X', '--specifyUser', action='store', type='int', metavar='INT', dest='specify_user',
                    default=(None, 'NOTBLANK'), help='specifyUser : agent startup user  = 0, specify user = 1 ')
    psr.add_option('-Y', '--execUser', action='store', type='string', metavar='STRING', dest='exec_user',
                    default=(None, 'NOTBLANK', {'WHEN':{'specify_user':1}, 'DO':('REQUIRED')}), help='execUser : run as user')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job)
        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, job_map['jobunitId'])
        del job_tree_full

        job_info = JobUtil.find_job_info(job_tree, job_map['jobId'])
        if job_info is None:
            raise ErrorHandler.ArgumentError('Job {:s} not found!'.format(job_map['jobId']))

        job_type_label = JobUtil.convert2job_type_label(job_info.type)
        if job_type_label not in ('FILEJOB',):
            raise ErrorHandler.ArgumentError('This operation is not available for %s!' % job_type_label)

        new_job_info = endpoint.getJobFull(endpoint.create_job_info_minimal(job_map['jobunitId'], job_map['jobId']))
        with ObjectModifier(new_job_info) as modifier:
            modifier.change_ptr('file')
            modifier.set_if_first_not_none('processingMethod', opts.process_mode)
            modifier.set_if_first_not_none('srcFacilityID', opts.src_facility_id)
            if opts.src_facility_id is not None:
                modifier.set_if_first_not_none('srcScope', ' ')
            modifier.set_if_first_not_none('srcFile', opts.src_file)

            modifier.set_if_first_not_none('destFacilityID', opts.dest_facility_id)
            if opts.dest_facility_id is not None:
                modifier.set_if_first_not_none('destScope', ' ')
            modifier.set_if_first_not_none('destDirectory', opts.dest_directory)

            modifier.set_if_first_not_none('compressionFlg', opts.compress)
            modifier.set_if_first_not_none('checkFlg', opts.check)
            modifier.set_if_first_not_none('specifyUser', opts.specify_user)
            modifier.set_if_first_not_none('user', opts.exec_user)

        JobUtil.replace_job_info(job_tree, new_job_info)

        # Clean up and replace none with blank
        JobUtil.cleanup_and_fixnone(job_tree)

        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJob')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
