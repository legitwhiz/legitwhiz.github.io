#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ロールIDに紐づくシステム権限情報を差し替える

<概要>
ロールIDに紐づくシステム権限情報の差し替えを実施します。

<使用例>
[command]
    $ python Access_replaceSystemPrivilegeRole.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -R TEST01 -F AccessControl -P READ

[result]
    http://192.168.1.2:8080/HinemosWS/, replaceSystemPrivilegeRole succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.access import AccessEndpoint
from hinemos.util.common import ResultPrinter
from hinemos.util.access import AccessUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='ownerRoleID')
    psr.add_option('-F', '--systemFunctions', action='store_split', type='string', metavar='STRING', dest='system_functions_raw',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='systemFunctions = systemFunction1,systemFunction2,...,systemFunctionN (systemFunction = %s)' % (' / '.join(AccessUtil._function_type_)) )
    psr.add_option('-P', '--systemPrivileges', action='store_split', type='string', metavar='STRING', dest='system_privileges_raw',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='systemPrivileges = systemPrivilege1,systemPrivilege2,systemPrivilegeN (systemPrivilege = %s)' % (' / '.join(AccessUtil._sys_privilege_type_)))
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = AccessEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        ### systemPrivilegeInfo parameter ###

        if len(opts.system_functions) != len(opts.system_privileges):
            raise ErrorHandler.ArgumentError('The number of SYSTEMFUNCTIONS does not equal to SYSTEMPRIVILEGES\'s')

        for a in opts.system_functions:
            if not a in AccessUtil._function_type_:
                raise ErrorHandler.ArgumentError('Invalid SystemFunction - %s.' % a)

        for a in opts.system_privileges:
            if not a in AccessUtil._sys_privilege_type_:
                raise ErrorHandler.ArgumentError('Invalid SystemPrivilege - %s.' % a)

        system_privilege_info_list = []
        for i in xrange(len(opts.system_functions)):
            info = endpoint.create_system_privilege_info(opts.system_functions[i], opts.system_privileges[i])
            system_privilege_info_list.append(info)

        endpoint.replaceSystemPrivilegeRole(opts.owner_role_id, system_privilege_info_list)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'replaceSystemPrivilegeRole')
    except ErrorHandler.ArgumentError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
