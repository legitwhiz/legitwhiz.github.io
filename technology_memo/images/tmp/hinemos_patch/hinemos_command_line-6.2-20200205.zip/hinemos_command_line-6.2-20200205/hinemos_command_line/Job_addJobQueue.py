#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブキュー(同時実行制御キュー)の設定を追加する

<概要>
ジョブキュー(同時実行制御キュー)の設定を追加します。

<使用例>
[command]
    $ python Job_addJobQueue.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -I TESTQ01 -N "Test Queue"
    -C 4 -R ALL_USERS

[result]
    http://127.0.0.1:8080/HinemosWS/, addJobQueue succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.job import JobEndpoint
from hinemos.util.common import ResultPrinter


def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--queueId',  action='store', type='string', metavar='ID', dest='queue_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Job Queue ID')
    psr.add_option('-N', '--queueName', action='store', type='string', metavar='STRING', dest='name',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Job Queue name')
    psr.add_option('-C', '--concurrency', action='store', type='int', metavar='INT', dest='concurrency',
                   default=(None, 'REQUIRED', 'INTEGER'), help='Concurrency Value')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                   default=('ALL_USERS', 'NOTBLANK'), help='Owner role ID (default: ALL_USERS)')
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_queue_setting = endpoint.create_object('jobQueueSetting')
        job_queue_setting.queueId = opts.queue_id
        job_queue_setting.name = opts.name
        job_queue_setting.concurrency = opts.concurrency
        job_queue_setting.ownerRoleId = opts.owner_role_id

        endpoint.addJobQueue(job_queue_setting)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addJobQueue')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
