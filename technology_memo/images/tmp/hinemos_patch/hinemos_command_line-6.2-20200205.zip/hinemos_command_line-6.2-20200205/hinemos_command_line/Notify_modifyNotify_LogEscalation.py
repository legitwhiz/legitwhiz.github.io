#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ログエスカレーション通知情報を変更する

<概要>
ログエスカレーション通知情報を変更します。

<使用例>
[command]
    $ python Notify_modifyNotify_LogEscalation.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I LOGESC1 -c 1 -a 1 -M warning -D mynotify -C CAL001 -c 2 -F true -T 2 -P 22 -f 1 -x NODE001 -p 123 -i 1 -a 1 -t 1 -u 1 -b auth -B auth -g auth -G local1 -k notice -K notice -j notice -J notice -m testmessage -M testmessage2 -o testmessage3 -O testmessage3 -e true

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyNotify_LogEscalation succeeded.
"""

### import ###
import sys
import codecs, locale

import hinemos.api.exceptions as ErrorHandler
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.opt import MyOptionParser
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.notify import NotifyUtil

def main():

    ### argument setting ###
    psr = MyOptionParser()
    psr.add_option('-I', '--notifyID',  action='store', type='string', metavar='ID', dest='notify_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='notifyID')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='description')
    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                   default=(None,'NOTBLANK'), help='calendar ID')
    psr.add_option('-c', '--initialCount', action='store', type='int', metavar='INT', dest='initial_count',
                    default=None, help='initialCount')
    psr.add_option('-F', '--notFirstNotify', action='store', type='string', metavar='STRING', dest='not_first_notify',
                    default=(None,{'INLIST':['true','false']}), help='notify after validated')
    psr.add_option('-T', '--renotifyType', action='store', type='int', metavar='INT', dest='renotify_type',
                    default=(None, {'INLIST':[0,1,2]}), help='renotifyType Always = 0, Time Suppressing = 1, Don\'t notify = 2')
    psr.add_option('-P', '--renotifyPeriod', action='store', type='int', metavar='INT', dest='renotify_period',
                    default=(None, {'WHEN':{'renotify_type':1}, 'DO':('REQUIRED')}), help='renotifyPeriod')

    psr.add_option('-f', '--escalateFacilityFlg', action='store', type='int', metavar='INT', dest='escalate_facility_flg',
                    default=(None, {'INLIST':[0,1]}), help='occurred scope = 0, fixed scope = 1')
    psr.add_option('-x', '--escalateFacilityID',  action='store', type='string', metavar='ID', dest='escalate_facility_id',
                    default=None, help='escalateFacilityID')
    psr.add_option('-p', '--escalatePort', action='store', type='string', metavar='STRING', dest='escalate_port',
                    default=None, help='escalatePort')

    psr.add_option('-i', '--infoFlg', action='store', type='int', metavar='INT', dest='info_flg',
                    default=(None,{'INLIST':[0,1]}), help='infoFlg : valid = 1, invalid = 0')
    psr.add_option('-a', '--warningFlg', action='store', type='int', metavar='INT', dest='warning_flg',
                    default=(None,{'INLIST':[0,1]}), help='warningFlg : valid = 1, invalid = 0')
    psr.add_option('-t', '--criticalFlg', action='store', type='int', metavar='INT', dest='critical_flg',
                    default=(None,{'INLIST':[0,1]}), help='criticalFlg : valid = 1, invalid = 0')
    psr.add_option('-u', '--unknownFlg', action='store', type='int', metavar='INT', dest='unknown_flg',
                    default=(None,{'INLIST':[0,1]}), help='unknownFlg : valid = 1, invalid = 0')

    psr.add_option('-b', '--facilityInfo', action='store', type='string', metavar='STRING', dest='facility_info',
                    default=(None,{'INLIST':['auth','authpriv','cron','daemon','ftp','kern','lpr','mail','news','syslog','user','uucp','local0','local1','local2','local3','local4','local5','local6','local7']}),
                    help='facility_info = auth, authpriv, cron, daemon, ftp, kern, lpr, mail, news, syslog, user, uucp, local0, local1, local2, local3, local4, local5, local6, local7')
    psr.add_option('-B', '--facilityWarning', action='store', type='string', metavar='STRING', dest='facility_warning',
                    default=(None,{'INLIST':['auth','authpriv','cron','daemon','ftp','kern','lpr','mail','news','syslog','user','uucp','local0','local1','local2','local3','local4','local5','local6','local7']}),
                    help='facility_warning = auth, authpriv, cron, daemon, ftp, kern, lpr, mail, news, syslog, user, uucp, local0, local1, local2, local3, local4, local5, local6, local7')
    psr.add_option('-g', '--facilityCritical', action='store', type='string', metavar='STRING', dest='facility_critical',
                    default=(None,{'INLIST':['auth','authpriv','cron','daemon','ftp','kern','lpr','mail','news','syslog','user','uucp','local0','local1','local2','local3','local4','local5','local6','local7']}),
                    help='facility_critical = auth, authpriv, cron, daemon, ftp, kern, lpr, mail, news, syslog, user, uucp, local0, local1, local2, local3, local4, local5, local6, local7')
    psr.add_option('-G', '--facilityUnknown', action='store', type='string', metavar='STRING', dest='facility_unknown',
                    default=(None,{'INLIST':['auth','authpriv','cron','daemon','ftp','kern','lpr','mail','news','syslog','user','uucp','local0','local1','local2','local3','local4','local5','local6','local7']}),
                    help='facility_unknown = auth, authpriv, cron, daemon, ftp, kern, lpr, mail, news, syslog, user, uucp, local0, local1, local2, local3, local4, local5, local6, local7')

    psr.add_option('-k', '--priorityInfo', action='store', type='string', metavar='STRING', dest='priority_info',
                    default=(None,{'INLIST':['emergency','alert','critical','error','warning','notice','information','debug']}),
                    help='priority_info = emergency, alert, critical, error, warning, notice, information, debug')
    psr.add_option('-K', '--priorityWarning', action='store', type='string', metavar='STRING', dest='priority_warning',
                    default=(None,{'INLIST':['emergency','alert','critical','error','warning','notice','information','debug']}),
                    help='priority_warning = emergency, alert, critical, error, warning, notice, information, debug')
    psr.add_option('-j', '--priorityCritical', action='store', type='string', metavar='STRING', dest='priority_critical',
                    default=(None,{'INLIST':['emergency','alert','critical','error','warning','notice','information','debug']}),
                    help='priority_critical = emergency, alert, critical, error, warning, notice, information, debug')
    psr.add_option('-J', '--priorityUnknown', action='store', type='string', metavar='STRING', dest='priority_unknown',
                    default=(None,{'INLIST':['emergency','alert','critical','error','warning','notice','information','debug']}),
                    help='priority_unknown = emergency, alert, critical, error, warning, notice, information, debug')

    psr.add_option('-m', '--messageInfo', action='store', type='string', metavar='STRING', dest='message_info',
                    default=None, help='message_info')
    psr.add_option('-M', '--messageWarning', action='store', type='string', metavar='STRING', dest='message_warning',
                    default=None, help='message_warning')
    psr.add_option('-o', '--messageCritical', action='store', type='string', metavar='STRING', dest='message_critical',
                    default=None, help='message_critical')
    psr.add_option('-O', '--messageUnknown', action='store', type='string', metavar='STRING', dest='message_unknown',
                    default=None, help='message_unknown')

    psr.add_option('-e', '--enable', action='store', type='string', metavar='STRING', dest='enable_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### notifyInfo parameter ###
        notify_info = endpoint.getNotify(opts.notify_id, NotifyUtil.convert2notify_type('LOG_ESCALATE'))
        if notify_info is None:
            raise ErrorHandler.ObjectNotFoundError('Setting ' + opts.notify_id + ' does not exist!')

        if opts.description is not None:
            notify_info.description = opts.description
        if opts.calendar_id is not None:
            notify_info.calendarId = opts.calendar_id
        if opts.initial_count is not None:
            notify_info.initialCount = opts.initial_count
        if opts.not_first_notify is not None:
            notify_info.notFirstNotify = SettingUtil.convert2nint(opts.not_first_notify)
        if opts.renotify_type is not None:
            notify_info.renotifyType = opts.renotify_type
        if opts.renotify_period is not None:
            notify_info.renotifyPeriod = opts.renotify_period
        if opts.enable is not None:
            notify_info.validFlg = opts.enable

        ### notifyLogEscalateInfo parameter ###
        # BADHC!
        if 'infoEscalateMessage' not in notify_info.notifyLogEscalateInfo:
            setattr(notify_info.notifyLogEscalateInfo, 'infoEscalateMessage', None)
        if 'warnEscalateMessage' not in notify_info.notifyLogEscalateInfo:
            setattr(notify_info.notifyLogEscalateInfo, 'warnEscalateMessage', None)
        if 'criticalEscalateMessage' not in notify_info.notifyLogEscalateInfo:
            setattr(notify_info.notifyLogEscalateInfo, 'criticalEscalateMessage', None)
        if 'unknownEscalateMessage' not in notify_info.notifyLogEscalateInfo:
            setattr(notify_info.notifyLogEscalateInfo, 'unknownEscalateMessage', None)

        if opts.escalate_facility_flg is not None:
            notify_info.notifyLogEscalateInfo.escalateFacilityFlg = opts.escalate_facility_flg
        if opts.escalate_facility_id is not None:
            notify_info.notifyLogEscalateInfo.escalateFacility = opts.escalate_facility_id
            notify_info.notifyLogEscalateInfo.escalateScope = ' '
        if opts.escalate_port is not None:
            notify_info.notifyLogEscalateInfo.escalatePort = opts.escalate_port

        if opts.info_flg is not None:
            notify_info.notifyLogEscalateInfo.infoValidFlg = opts.info_flg
        if opts.facility_info is not None:
            notify_info.notifyLogEscalateInfo.infoSyslogFacility = NotifyUtil.convert2syslog_facility(opts.facility_info)
        if opts.priority_info is not None:
            notify_info.notifyLogEscalateInfo.infoSyslogPriority = NotifyUtil.convert2syslog_severity(opts.priority_info)
        if opts.message_info is not None:
            notify_info.notifyLogEscalateInfo.infoEscalateMessage = opts.message_info

        if opts.warning_flg is not None:
            notify_info.notifyLogEscalateInfo.warnValidFlg = opts.warning_flg
        if opts.facility_warning is not None:
            notify_info.notifyLogEscalateInfo.warnSyslogFacility = NotifyUtil.convert2syslog_facility(opts.facility_warning)
        if opts.priority_warning is not None:
            notify_info.notifyLogEscalateInfo.warnSyslogPriority = NotifyUtil.convert2syslog_severity(opts.priority_warning)
        if opts.message_warning is not None:
            notify_info.notifyLogEscalateInfo.warnEscalateMessage = opts.message_warning

        if opts.critical_flg is not None:
            notify_info.notifyLogEscalateInfo.criticalValidFlg = opts.critical_flg
        if opts.facility_critical is not None:
            notify_info.notifyLogEscalateInfo.criticalSyslogFacility = NotifyUtil.convert2syslog_facility(opts.facility_critical)
        if opts.priority_critical is not None:
            notify_info.notifyLogEscalateInfo.criticalSyslogPriority = NotifyUtil.convert2syslog_severity(opts.priority_critical)
        if opts.message_critical is not None:
            notify_info.notifyLogEscalateInfo.criticalEscalateMessage = opts.message_critical

        if opts.unknown_flg is not None:
            notify_info.notifyLogEscalateInfo.unknownValidFlg = opts.unknown_flg
        if opts.facility_unknown is not None:
            notify_info.notifyLogEscalateInfo.unknownSyslogFacility = NotifyUtil.convert2syslog_facility(opts.facility_unknown)
        if opts.priority_unknown is not None:
            notify_info.notifyLogEscalateInfo.unknownSyslogPriority = NotifyUtil.convert2syslog_severity(opts.priority_unknown)
        if opts.message_unknown is not None:
            notify_info.notifyLogEscalateInfo.unknownEscalateMessage = opts.message_unknown

        endpoint.modifyNotify(notify_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyNotify_LogEscalation')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
