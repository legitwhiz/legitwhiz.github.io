#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
「終了状態」タブの情報を変更する

<概要>
「終了状態」タブの情報を変更します。

<使用例>
[command]
    $ python Job_modifyJob_EndStatusTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JOB1 -N 1 -n 1 -o 2 -X 3 -x 3 -y 4 -A 9

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil
from hinemos.util.common import ResultPrinter
from hinemos.util.modifier import ObjectModifier

def main():

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    ### 終了状態タブ設定項目 ###
    psr.add_option('-N', '--valueNormal', action='store', type='int', metavar='INT', dest='value_normal',
                    default=None, help='value_normal(end status tab)= integer')
    psr.add_option('-n', '--startRangeValueNormal', action='store', type='int', metavar='INT', dest='start_range_value_normal',
                    default=None, help='startRangeValue_normal(end status tab)= integer')
    psr.add_option('-o', '--endRangeValueNormal', action='store', type='int', metavar='INT', dest='end_range_value_normal',
                    default=None, help='endRangeValue_normal(end status tab)= integer')
    psr.add_option('-X', '--valueWarning', action='store', type='int', metavar='INT', dest='value_warn',
                    default=None, help='value_warn(end status tab)= integer')
    psr.add_option('-x', '--startRangeValueWarn', action='store', type='int', metavar='INT', dest='start_range_value_warn',
                    default=None, help='startRangeValue_warn(end status tab)= integer')
    psr.add_option('-y', '--endRangeValueWarn', action='store', type='int', metavar='INT', dest='end_range_value_warn',
                    default=None, help='endRangeValue_warn(end status tab)= integer')
    psr.add_option('-A', '--valueAbnormal', action='store', type='int', metavar='INT', dest='value_abnormal',
                    default=None, help='value_abnormal(end status tab)= integer')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job)
        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, job_map['jobunitId'])
        del job_tree_full

        job_info = JobUtil.find_job_info(job_tree, job_map['jobId'])
        if job_info is None:
            raise ErrorHandler.ArgumentError('Job {:s} not found!'.format(job_map['jobId']))

        job_type_label = JobUtil.convert2job_type_label(job_info.type)
        if job_type_label in ('REFERJOB', 'REFERJOBNET'): # TODO Do not use exclusion condition
            raise ErrorHandler.ArgumentError('This operation is not available for %s!' % job_type_label)

        new_job_info = endpoint.getJobFull(endpoint.create_job_info_minimal(job_map['jobunitId'], job_map['jobId']))
        with ObjectModifier(new_job_info) as modifier:
            modifier.change_ptr('endStatus')

            if opts.start_range_value_normal is not None or opts.end_range_value_normal is not None or opts.value_normal is not None:
                job_end_status_info = modifier.select(type = JobUtil.convert2end_status('NORMAL'))
                ObjectModifier.replace_if_not_none(job_end_status_info,\
                            startRangeValue = opts.start_range_value_normal,\
                            endRangeValue = opts.end_range_value_normal,\
                            value = opts.value_normal)

            if opts.start_range_value_warn is not None or opts.end_range_value_warn is not None or opts.value_warn is not None:
                job_end_status_info = modifier.select(type = JobUtil.convert2end_status('WARNING'))
                ObjectModifier.replace_if_not_none(job_end_status_info,\
                            startRangeValue = opts.start_range_value_warn,\
                            endRangeValue = opts.end_range_value_warn,\
                            value = opts.value_warn)

            if opts.value_abnormal is not None:
                job_end_status_info = modifier.select(type = JobUtil.convert2end_status('ABNORMAL'))
                ObjectModifier.replace_if_not_none(job_end_status_info,\
                            value = opts.value_abnormal)

        JobUtil.replace_job_info(job_tree, new_job_info)

        # Clean up and replace none with blank
        JobUtil.cleanup_and_fixnone(job_tree)

        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJob')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
