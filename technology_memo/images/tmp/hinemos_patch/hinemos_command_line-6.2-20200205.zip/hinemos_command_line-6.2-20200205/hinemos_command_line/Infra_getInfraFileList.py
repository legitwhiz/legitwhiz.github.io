#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
環境構築ファイル一覧を取得する

<概要>
環境構築ファイル一覧を取得して表示します。

<使用例>
[command]
    $ python Infra_getInfraFileList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    [(infraFileInfo){
       ownerRoleId = "ALL_USERS"
       createDatetime = 1486732617826
       createUserId = "hinemos"
       fileId = "HINEMOS_AGENT_LINUX"
       fileName = "hinemos-6.0-agent-6.0.0-1.el.noarch.rpm"
       modifyDatetime = 1486732617826
       modifyUserId = "hinemos"
     }, (infraFileInfo){
       ownerRoleId = "ALL_USERS"
       createDatetime = 1486732621756
       createUserId = "hinemos"
       fileId = "HINEMOS_AGENT_WINDOWS"
       fileName = "HinemosAgentInstaller-6.0.0_win.msi"
       modifyDatetime = 1486732621756
       modifyUserId = "hinemos"
     }]
    http://192.168.1.2:8080/HinemosWS/, getInfraFileList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.common import ResultPrinter
from hinemos.api.infra import InfraEndpoint

def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        end_point = InfraEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = end_point.getInfraFileList()

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getInfraFileList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
