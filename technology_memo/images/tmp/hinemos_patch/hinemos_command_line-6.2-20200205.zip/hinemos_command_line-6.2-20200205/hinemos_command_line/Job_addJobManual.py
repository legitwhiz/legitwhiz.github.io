#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブのマニュアル実行契機情報を登録する

<概要>
ジョブのマニュアル実行契機情報を登録します。

<使用例>
- マニュアル実行契機を作成します。
[command]
    $ python Job_addJobManual.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I JMN001 -N JobManual1 -J JU001/J001 -R ADMINISTRATORS

[result]
    http://192.168.1.2:8080/HinemosWS/, addJobManual succeeded.
"""
import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.common import ResultPrinter
from hinemos.util.job import JobUtil

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-I', '--jobKickID',  action='store', type='string', metavar='ID', dest='jobkick_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='Job kick ID')
    psr.add_option('-N', '--name', action='store', type='string', metavar='STRING', dest='name',
                    default=(None, 'REQUIRED','NOTBLANK'), help='Job kick name')

    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job_path',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='or_id',
                    default=('ALL_USERS', 'NOTBLANK'), help='Owner Role ID (default: ALL_USERS)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job_path)
        LOGGER.debug(job_map)

        info = JobUtil.set_job_kick(
            endpoint.create_job_kick(opts.jobkick_id, opts.or_id),
            opts.name,
            job_map,
            None) # Only available in Job_modify*
        LOGGER.debug(info)
        endpoint.addJobManual(info)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addJobManual')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
