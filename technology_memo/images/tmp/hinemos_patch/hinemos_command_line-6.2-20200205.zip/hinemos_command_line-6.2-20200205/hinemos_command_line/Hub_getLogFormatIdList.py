#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
オーナーロールIDを条件としてログフォーマットのID一覧を取得する

<概要>
オーナーロールIDを条件としてログフォーマットのID一覧を取得して表示します。

<使用例>
[command]
    $ python Hub_getLogFormatIdList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -R ALL_USERS

[result]
    [LOGFORMAT_APACHE_ACCESSLOG, LOGFORMAT_APACHE_ERRORLOG, LOGFORMAT_SYSLOG, TEST_LOGFORMAT]
    http://192.168.1.2:8080/HinemosWS/, getLogFormatIdList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
from hinemos.util.common import ResultPrinter
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.hub import HubEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=('ALL_USERS', 'NOTBLANK'), help='Owner role ID (default: ALL_USERS)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = HubEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getLogFormatIdList(opts.owner_role_id)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getLogFormatIdList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
