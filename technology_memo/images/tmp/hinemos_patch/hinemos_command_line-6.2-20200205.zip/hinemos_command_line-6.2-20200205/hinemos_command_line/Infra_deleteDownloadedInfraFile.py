#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------
u"""
ダウンロードファイルを削除する

<概要>
ダウンロードファイルを削除します。

<使用例>
[command]
    $ python Infra_deleteDownloadedInfraFile.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F FILE01

[result]
    http://192.168.1.2:8080/HinemosWS/, deleteDownloadedInfraFile succeeded.
"""


import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.infra import InfraEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-F', '--fileName', action='store', type='string', metavar='STRING', dest='file_name',
                    default=(None, 'REQUIRED','NOTBLANK'), help='file_name')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = InfraEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = endpoint.deleteDownloadedInfraFile(opts.file_name)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'deleteDownloadedInfraFile')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
