#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
PING監視の監視設定情報を変更する

<概要>
PING監視の監視設定情報を変更します。

<使用例>
[command]
    $ python MonitorSetting_modifyMonitor_Ping.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I PING1 -A MYAPP -F SCOPE001

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.modifier import ObjectModifier
from hinemos.util.notify import NotifyUtil
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_modify_args_parser(
            help_default_info,
        exclude=[
            'infoLowerThreshold',
            'infoUpperThreshold',
            'warnLowerThreshold',
            'warnUpperThreshold'
        ])
    psr.add_option('-t', '--checkRunCount', action='store', type='int',
                   metavar='INT', dest='check_run_count',
                   default=(None, {'RANGE': [1, 9]}), help='run count = 1 to 9')
    psr.add_option('-r', '--checkRunInterval', action='store', type='int',
                   metavar='INT', dest='check_run_interval',
                   default=(None, {'RANGE': [0, 5000]}),
                   help='run interval = 0 to 5000 [msec]')
    psr.add_option('-O', '--checkTimeout', action='store', type='int',
                   metavar='INT', dest='check_timeout',
                   default=None, help='timeout [msec]')
    psr.add_option('-L', '--infoResponseThreshold', action='store', type='float',
                   metavar='NUMERIC', dest='info_response_threshold',
                   default=None, help='response time [msec] threshold of INFO')
    psr.add_option('-P', '--infoPacketLossThreshold', action='store',
                   type='float', metavar='NUMERIC',
                   dest='info_packetloss_threshold',
                   default=None, help='packet loss [%] threshold of INFO')
    psr.add_option('-l', '--warnResponseThreshold', action='store', type='float',
                   metavar='NUMERIC', dest='warn_response_threshold',
                   default=None, help='response time [msec] threshold of WARN ')
    psr.add_option('-p', '--warnPacketLossThreshold', action='store', type='float',
                   metavar='NUMERIC', dest='warn_packetloss_threshold',
                   default=None, help='packet loss [%] threshold of WARN')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    return_code = -1

    # pylint: disable=W0703
    try:
        # login
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Get monitorInfo
        monitor_info = endpoint.getMonitor(opts.monitor_id)

        # Modification
        with ObjectModifier(monitor_info) as modifier:
            endpoint.update_common_infos(modifier, vars(opts))
            endpoint.update_collect_infos(modifier, vars(opts))
            endpoint.update_prediction_info(modifier, vars(opts))
            endpoint.update_change_info(modifier, vars(opts))
            endpoint.updete_judgement_tresholds(modifier, vars(opts))

            modifier.change_ptr('pingCheckInfo')
            modifier.set_if_first_not_none('runCount', opts.check_run_count)
            modifier.set_if_first_not_none(
                'runInterval', opts.check_run_interval)
            modifier.set_if_first_not_none('timeout', opts.check_timeout)

        endpoint.update_notify_ids_info(monitor_info, vars(opts))

        endpoint.modifyMonitor(monitor_info)
        return_code = ResultPrinter.success(
            None, opts.mgr_url, 'modifyMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
