#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# ----------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2018 NTT DATA INTELLILINK Corporation
# ----------------------------------------------------

u"""
コマンドラインツール、Utilityオプションまたは編集ExcelでエクスポートしたXMLを標準化する

<概要>
コマンドラインツール、Utilityオプションまたは編集ExcelでエクスポートしたXMLを標準化します。

異なるコンポーネントよりエクスポートしたXMLを比較する場合、
XMLの要素・属性の記載順番や、比較不要な要素・属性(例えば、設定の最終更新日時)などの考慮が必要で、
diffコマンドで直接比較することが困難です。
本ツールにより、要素・属性の順番をソート、比較不要なものをあらかじめ削除などの標準化をすることで、
diffコマンドなどのファイル比較ツールで差分比較できるようにします。

**注意事項** : Hinemosマネージャまたは編集Excelに、標準化したXMLをインポートすることはできません。


<使用例>
- Utilityオプションと移行ツールそれぞれからエクスポートしたユーザ設定(platformUser.xml)を標準化します。

  1つ目の引数に標準化したいXMLを指定します。

  2つ目の引数に指定したパスに標準化したXMLが出力されます。

[command]
    $ python Porting_normalizeXML.py utility_export/platformUser.xml platformUser1.xml


- Utilityオプションと移行ツールそれぞれからエクスポートしたユーザ設定(platformUser.xml)を標準化し、
  diffコマンドで差分比較する一例です。

  1つ目の引数に標準化したいXMLを指定します。

  2つ目の引数に指定したパスに標準化したXMLが出力されます。

[command]
    $ python Porting_normalizeXML.py utility_export/platformUser.xml platformUser1.xml

[command]
    $ python Porting_normalizeXML.py porting_export/platformUser.xml platformUser2.xml


標準化された、platformUser1.xmlとplatformUser2.xmlをdiffコマンドで差分がある場合、

[command]
    $ diff platformUser1.xml platformUser2.xml

[result]
    50a51,53
    >       <UserInfo description="サンプル" name="ユーザ001" password="" userId="test_user_001"/>
    >       <UserInfo description="サンプル" name="ユーザ002" password="" userId="test_user_002"/>
    >       <UserInfo description="サンプル" name="ユーザ003" password="" userId="test_user_003"/>

[command]
    $ echo $?

[result]
    1

標準化された、platformUser1.xmlとplatformUser2.xmlをdiffコマンドで差分がない場合、

[command]
    $ diff platformUser1.xml platformUser2.xml

[result]
    (なし)

[command]
    $ echo $?

[result]
    0

"""

import sys
import os
from xml.etree import ElementTree
from xml.dom import minidom
from fnmatch import fnmatchcase
import logging

######################## Classes/Functions ########################

class StardardXML():

    ######################## Settings ########################

        #commonや更新日など、比較不要なものの一覧
        #
        #NOTE: "*"でwildcard指定可能だが、部分wildcardはサポートしておりません(例えば、"co*on"、"*Monitor")


    IGNORE_LIST = (
        '*/common',
        '*/schemaInfo/schemaRevision',
        '*/*/monitor/notifyId/notifyGroupId',
        '*/*/monitor/predictionNotifyId/notifyGroupId',
        '*/*/monitor/changeNotifyId/notifyGroupId',
        '*/*/monitor/regDate',
        '*/*/monitor/regUser',
        '*/*/monitor/updateDate',
        '*/*/monitor/updateUser',
        'infraManagement/infraManagementInfo/notifyId/notifyGroupId',
        'jobMasters/JobInfo/createTime',
        'jobMasters/JobInfo/createUser',
        'jobMasters/JobInfo/updateUser',
        'jobMasters/JobInfo/scope',
        'jobMasters/JobInfo/srcScope',
        'jobMasters/JobInfo/notifyRelationInfos/notifyGroupId',
        'maintenance/maintenanceInfo/notifyGroupId',
        'maintenance/maintenanceInfo/notifyId/notifyGroupId')

        #特定のnotifyGroupIdなど、コマンドラインツールまたは編集Excelの出力形式が異なるため、
        #あらかじめ統一するものの一覧
        #実際にマネージャ側では参照しないもののため、比較不要
        #
        #NOTE: IGNORE_LISTと同様に"*"でwildcard指定可能だが、部分wildcardはサポートしておりません
    
    REPLACE_MAP = {
        '*/*/*/monitorTypeId': '**FORMATTED**',
        'jobMasters/JobInfo/updateTime': '**FORMATTED**',
        'httpScenarioMonitors/httpScenarioMonitor/httpScenarioInfo/pageValue/monitorTypeId': '**FORMATTED**'}

        #値が一致すれば、あらかじめ取り除いておくタグの一覧
        #コマンドラインツール、編集Excelの出力形式が異なるため、タグ自体が出力されなかったり、
        #<tag />のように出力されたりするので、あらかじめ取り除くためです
        #
        #なお、値はすべて文字列(例えば、falseの場合は'false'、0の場合は'0')で指定してください。
        #ただし、値なし(例えば、<description />)の場合はNoneと指定してください
        #
        #NOTE: IGNORE_LISTと同様に"*"でwildcard指定可能だが、部分wildcardはサポートしておりません

    IGNORE_IF_TEXT_MATCHED_MAP = {
        '*/*/stringValue/message': None,
        '*/*/jobRuntimeInfos/defaultValue': None,
        'binaryfileMonitors/binaryfileMonitor/binaryValue/textEncoding': None,
        'packetCapMonitors/packetCapMonitor/binaryValue/textEncoding': None,
        'httpMonitors/httpMonitor/httpInfo/proxyPort': '0',
        'httpMonitors/httpMonitor/httpInfo/proxySet': 'false',
        'httpMonitors/httpMonitor/httpInfo/urlReplace': 'false',
        'logcountMonitors/logcountMonitor/logcountInfo/keyword': None,
        'logfileMonitors/logfileMonitor/logfileInfo/filePatternHead': None,
        'logfileMonitors/logfileMonitor/logfileInfo/filePatternTail': None,
        'snmpTrapMonitors/trapMonitor/snmpTrapInfo/trapValueInfos/formatVarBinds': None,
        'snmpTrapMonitors/trapMonitor/snmpTrapInfo/trapValueInfos/priorityAnyVarbind': None,
        'httpScenarioMonitors/httpScenarioMonitor/httpScenarioInfo/pageValue/description': None,
        'httpScenarioMonitors/httpScenarioMonitor/httpScenarioInfo/pageValue/patternValue/description': None,
        'httpScenarioMonitors/httpScenarioMonitor/httpScenarioInfo/pageValue/post': None,
        'httpScenarioMonitors/httpScenarioMonitor/httpScenarioInfo/proxyPassword': None,
        'httpScenarioMonitors/httpScenarioMonitor/httpScenarioInfo/proxyUser': None,
        'jmxMonitors/jmxMonitor/jmxInfo/authPassword': None,
        'jmxMonitors/jmxMonitor/jmxInfo/authUser': None,
        'perfMonitors/perfMonitor/perfInfo/deviceDisplayName': None,
        'processMonitors/processMonitor/processInfo/param': None,
        'jobMasters/JobInfo/destWorkDir': None,
        'jobMasters/JobInfo/srcWorkDir': None,
        'jobMasters/JobInfo/startJob/startTime': None,
        'jobMasters/JobInfo/startJob/startDecisionValue01': None,
        'jobMasters/JobInfo/startJob/startDecisionValue02': None,
        'jobMasters/JobInfo/startJob/targetJobDescription': None,
        'jobMasters/JobInfo/iconId': None}

        #値が一致すればあらかじめ取り除いておく属性の一覧
        #
        #なお、値はすべて文字列(例えば、falseの場合は'false'、0の場合は'0')で指定してください。
        #ただし、「任意値」の場合はNoneと指定してください

    IGNORE_IF_ATTRIBUTE_MATCHED_MAP = {
        'HinemosProperty/HinemosPropertyInfo@value': '',
        'maintenance/maintenanceInfo@description': '',
        'notify/notifyInfo/notifyCommandInfo@setEnvironment': 'true',
        'notify/notifyInfo@regDate': None,
        'notify/notifyInfo@regUser': None,
        'notify/notifyInfo@updateDate': None,
        'notify/notifyInfo@updateUser': None,
        'InfraFile/InfraFileInfo@createDatetime': None,
        'InfraFile/InfraFileInfo@createUserId': None,
        'InfraFile/InfraFileInfo@modifyDatetime': None,
        'InfraFile/InfraFileInfo@modifyUserId': None,
        'FileCheckList/FileCheckInfo/FileCheckData@modifyType': ['', '0'],
        'infraManagement/infraManagementInfo/infraModuleInfo@destAttribute': '',
        'infraManagement/infraManagementInfo/infraModuleInfo@destOwner': '',
        'infraManagement/infraManagementInfo/infraModuleInfo@execReturnParamName': '',
        'infraManagement/infraManagementInfo@regDate': None,
        'infraManagement/infraManagementInfo@regUser': None,
        'infraManagement/infraManagementInfo@updateDate': None,
        'infraManagement/infraManagementInfo@updateUser': None,
        'transfer/transferInfo/transferDestProp@transferId': '',
        'User/UserInfo@mailAddress': '',
        'Role/RoleInfo@description': ['', 'None']}

        #あるタグの持つ属性が特定の条件に合致した場合、指定の属性を削除、もしくは上書きする

    REPLACE_ATTRIBUTES_MAP = (
        (
            'calendar/calendarInfo/calendarDetailInfo',
            {'dayType': '0'},
            {'afterDay':None}
        ),(
            'calendar/calendarInfo/calendarDetailInfo',
            {'dayType': ['0', '2', '3']},
            {'weekNo':None, 'weekXth':None}
        ),(
            'calendar/calendarInfo/calendarDetailInfo',
            {'dayType': ['0', '1', '3']},
            {'dayNo':None}
        ),(
            'ScheduleList/ScheduleInfo/ScheduleData',
            {'scheduleType': ['1', '2'], 'fromXminutes': ['0', '']},
            {'fromXminutes':None}
        ),(
            'ScheduleList/ScheduleInfo/ScheduleData',
            {'scheduleType': ['1', '2'], 'everyXminutes': ['0', '']},
            {'everyXminutes':None}
        ),(
            'ScheduleList/ScheduleInfo/ScheduleData',
            {'scheduleType': '3', 'minute': ['0', '']},
            {'minute':None}
        )
    )

        #特定の条件を満たした場合、該当タグを削除する
        #引数1で指定しているタグの配下に、引数2で指定している条件のタグが含まれている場合、引数3のサブタグを削除する

    IGNORE_TAGS_BY_COND_MAP = (
        (
            'jobMasters/JobInfo/startJob',
            [{'targetJobType': '2'}],
            ['targetJobEndValue']
        ), (
            'jobMasters/JobInfo',
            [{'type': '5'},{'type': '7'}],
            ['suspend']
        ), (
            'jobMasters/JobInfo',
            [{'type': '1'}],
            ['multiplicityEndValue', 'multiplicityNotify', 'multiplicityNotifyPriority', 'multiplicityOperation']
        ), (
            'snmpTrapMonitors/trapMonitor/snmpTrapInfo/trapValueInfos',
            [{'processingVarbindSpecified': 'true'}],
            ['priorityAnyVarbind']
        )
    )

        #特定の条件(主に空)を満たした属性を取り除く

    FORMAT_NUMBER_NOTATION_MAP = {
        '*/*/numericValue/thresholdLowerLimit':'%.0E',
        '*/*/numericValue/thresholdUpperLimit':'%.0E'
    }

    xmltree = None
    def __init__(self, file_path):
        with open(file_path, 'rb') as fp:
            self.xmltree = ElementTree.parse(fp)

    def prettify(self, elem, output_path):
        """Return a pretty-printed XML string for the Element.
            @see https://pymotw.com/2/xml/etree/ElementTree/create.html
        """
        rough_string = ElementTree.tostring(elem, 'utf-8')
        reparsed = minidom.parseString(rough_string)
        #return reparsed.toprettyxml(indent='\t')
        with open(output_path, 'wb') as fpw:
            reparsed.writexml(fpw, addindent='\t', newl=os.linesep)

    @staticmethod
    def delete_by_xpath(parent_elem, xpath):
        xpaths = xpath.split('/', 1)

        subelems = parent_elem.findall(xpaths[0])
        if len(xpaths) == 1:
            # Remove all
            while len(subelems) > 0:
                parent_elem.remove(subelems.pop())
        else:
            for subelem in subelems:
                StardardXML.delete_by_xpath(subelem, xpaths[1])

    def remove_tags(self, elem):
        #commonなど、比較不要なものを取り除く 
        for xpath in StardardXML.IGNORE_LIST:
            xpaths = xpath.split('/', 1)
            if fnmatchcase(elem.tag, xpaths[0]):
                self.delete_by_xpath(elem, xpaths[1])

    @staticmethod
    def unify_by_xpath(parent_elem, xpath, repl):
        xpaths = xpath.split('/', 1)

        is_ending = len(xpaths) == 1
        for elem in parent_elem.iterfind(xpaths[0]):
            if is_ending:
                elem.text = repl
            else:
                StardardXML.unify_by_xpath(elem, xpaths[1], repl)

    def unify_tags(self, elem):
        #特定のnotifyGroupIdなど、コマンドラインツールまたは編集Excelに不要なもの/出力されないものをダミー値で統一する
        for xpath, repl in StardardXML.REPLACE_MAP.iteritems():
            xpaths = xpath.split('/', 1)
            if fnmatchcase(elem.tag, xpaths[0]):
                self.unify_by_xpath(elem, xpaths[1], repl)

    @staticmethod
    def is_matched(elem, conditions):
        is_matched = True
        for k,v in conditions.iteritems():
            # Not matched if such a tag does not even exist
            subelem = elem.find(k)
            if subelem is None or subelem.text != v:
                is_matched = False
                break
        return is_matched

    def remove_by_cond(self, elem):
        #特定の条件を満たした場合、該当タグを削除する
        for (xpath, multiple_conditions, remove_subpaths) in StardardXML.IGNORE_TAGS_BY_COND_MAP:
            xpaths = xpath.split('/', 1)
            for subelem in elem.iterfind(xpaths[1]):
                for conditions in multiple_conditions:
                    if self.is_matched(subelem, conditions):
                        for subxpath in remove_subpaths:
                            self.delete_by_xpath(subelem, subxpath)

    def unify_attributes_by_cond(self, elem):
        #特定の条件を見たした場合、該当属性を削除する
        for (xpath, conditions, replacements) in StardardXML.REPLACE_ATTRIBUTES_MAP:
            xpaths = xpath.split('/', 1)
            if fnmatchcase(elem.tag, xpaths[0]):
                for subelem in elem.iterfind(xpaths[1]):
                    is_matched = True
                    # Filtering, if all attributes' values match
                    for k,v in conditions.iteritems():
                        if k not in subelem.attrib:
                            is_matched = False
                            break
                        else:
                            if isinstance(v, list):
                                if subelem.attrib[k] not in v:
                                    is_matched = False
                                    break
                            else:
                                if subelem.attrib[k] != v:
                                    is_matched = False
                                    break
                    if is_matched:
                        for k,v in replacements.iteritems():
                            if k in subelem.attrib:
                                # Noneの場合は削除、それ以外は上書き
                                if v is None:
                                    del subelem.attrib[k]
                                else:
                                    subelem.attrib[k] = v

    @staticmethod
    def delete_if_text_matched(parent_elem, xpath, val):
        xpaths = xpath.split('/', 1)

        subelems = parent_elem.findall(xpaths[0])
        if len(xpaths) == 1:
            # Filtering, only remove if text matched
            if isinstance(val, list):
                subelems2 = list(a for a in subelems if a.text in val)
            else:
                subelems2 = list(a for a in subelems if a.text == val)
            # Remove all
            while len(subelems2) > 0:
                parent_elem.remove(subelems2.pop())
        else:
            for subelem in subelems:
                StardardXML.delete_if_text_matched(subelem, xpaths[1], val)

    def remove_if_text_matched(self, elem):
        #説明文など、<description />のようなものをあらかじめ取り除く 
        for xpath, val in StardardXML.IGNORE_IF_TEXT_MATCHED_MAP.iteritems():
            xpaths = xpath.split('/', 1)
            if fnmatchcase(elem.tag, xpaths[0]):
                self.delete_if_text_matched(elem, xpaths[1], val)

    @staticmethod
    def delete_if_attr_matched(parent_elem, xpath, val):
        xpaths = xpath.split('/', 1)

        if len(xpaths) == 1:
            (tag_name, attr_name) = xpaths[0].split('@', 1)
            for subelem in parent_elem.iterfind(tag_name):
                if attr_name in subelem.attrib:
                    if isinstance(val, list):
                        if subelem.attrib[attr_name] in val:
                            del subelem.attrib[attr_name]
                    elif subelem.attrib[attr_name] == val or val is None:
                        del subelem.attrib[attr_name]
        else:
            for subelem in parent_elem.iterfind(xpaths[0]):
                StardardXML.delete_if_attr_matched(subelem, xpaths[1], val)

    def remove_if_attribute_matched(self, elem):
        #特定の条件(主に空)を満たした属性を取り除く 
        for xpath, val in StardardXML.IGNORE_IF_ATTRIBUTE_MATCHED_MAP.iteritems():
            xpaths = xpath.split('/', 1)
            if fnmatchcase(elem.tag, xpaths[0]):
                self.delete_if_attr_matched(elem, xpaths[1], val)

    @staticmethod
    def str_to_number(s):
        #Returns if string is a number.
        try:
            return float(s)
        except ValueError:
            return None

    def format_number_tags(self, elem):
        #特定の条件(主に空)を満たした属性を取り除く 
        for xpath, format_specifier in StardardXML.FORMAT_NUMBER_NOTATION_MAP.iteritems():
            xpaths = xpath.split('/', 1)
            if fnmatchcase(elem.tag, xpaths[0]):
                for subelem in elem.iterfind(xpaths[1]):
                    n = self.str_to_number(subelem.text)
                    if n:
                        subelem.text = (format_specifier % n)

    @staticmethod
    def sorting(elem, max_depth=3):
        
        #NOTE: リソース枯渇防止のために、最大3階層までスキャンすることにする
        

        sorting_key = elem.tag

        # Append sorted attributes as sorting key
        if elem.attrib:
            attributes = elem.items()
            attributes.sort()
            # Join its key and value for sorting
            for (_,v) in attributes:
                #sorting_key += '@'+k+'='+v+';'
                # Or just simpily use value to sort
                sorting_key += v

        # Append sorted element text as sorting key
        if max_depth > 0:
            sub_keys = []
            for subelem in elem:
                sub_keys.append('-'+StardardXML.sorting(subelem, max_depth-1))
            sub_keys.sort()
            sorting_key += ''.join(sub_keys)

        if elem.text:
            sorting_key += '='+elem.text
        return sorting_key

    @staticmethod
    def sort_elements(elem):
        #属性とタグをソート
        #    1. タグはタグ名 > コンテンツ(属性とサブノードのText)のアルファベット順
        #    2. 属性は属性のアルファベット順
        
        #elem[:] = sorted(elem, key=lambda child: child.get(attr))
        elem[:] = sorted(elem, key=StardardXML.sorting)
        for child in elem:
            StardardXML.sort_elements(child)

    def normalize(self):
        global LOGGER
        LOGGER.info('Parse xml...')
        root = self.xmltree.getroot()

        ### Format
        LOGGER.info('First, remove unused...')
        self.remove_tags(root)
        self.remove_if_text_matched(root)
        self.remove_if_attribute_matched(root)
        self.unify_tags(root)

        self.remove_by_cond(root)
        self.unify_attributes_by_cond(root)
        self.format_number_tags(root)

        LOGGER.info('Then, sort elements with same tag name using attributes and children...')
        self.sort_elements(root)

        LOGGER.info('Done.')

    def saveas(self, filepath):
        self.prettify(self.xmltree.getroot(), filepath)

def print_usage():
    print('''Usage: Porting_normalizeXML.py INPUT_XML OUTPUT_XML

Arguments:
  INPUT_XML             XML file to normalize
  OUTPUT_XML            Write normalized XML to this path
''')

def main(xml_in, xml_out):
    global LOGGER
    sxml = StardardXML(xml_in)
    sxml.normalize()
    sxml.saveas(xml_out)

######################## Main ########################
if __name__ == '__main__':
    logging.basicConfig(level=logging.WARNING)
    LOGGER = logging.getLogger()

    if '-h' in sys.argv or '--help' in sys.argv:
        print_usage()
    elif len(sys.argv) != 3:
        print_usage()
        LOGGER.error('Argument Error!')
        sys.exit(1)
    else:
        main(sys.argv[1], sys.argv[2])
