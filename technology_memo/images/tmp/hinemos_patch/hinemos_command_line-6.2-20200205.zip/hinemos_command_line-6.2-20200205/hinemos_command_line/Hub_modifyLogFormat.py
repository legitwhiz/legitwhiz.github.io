#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ログフォーマット情報を変更する

<概要>
ログフォーマット情報を変更します。

<使用例>

- 基本情報を変更します。
[command]
    $ python Hub_modifyLogFormat.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_LOGFORMAT -D change_logformat -E test_logformat -F "2017-04-01 00:00:00"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyLogFormat succeeded.

- 文字列のタグ抽出定義を追加します。
[command]
    $ python Hub_modifyLogFormat.py -w hinemos -I LF001 -A ADD -K key1 -S 'First key' -T string -Y parsing -P '\\[ERROR\\] (.*)'

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyLogFormat succeeded.

- 真偽値のタグ抽出定義を追加します。
[command]
    $ python Hub_modifyLogFormat.py -w hinemos -I LF001 -A ADD -K key2 -S 'Second key' -T bool -Y fixed -P '\\[NOTICE\\]' -V true

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyLogFormat succeeded.

- タグ抽出定義を変更します。
[command]
    $ python Hub_modifyLogFormat.py -w hinemos -I LF001 -A MOD -K key1 -S updated -T number -Y fixed -P '\\[ERROR\\]' -V false

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyLogFormat succeeded.

- タグ抽出定義を削除します。
[command]
    $ python Hub_modifyLogFormat.py -w hinemos -I LF001 -A DEL -K key1,key2

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyLogFormat succeeded.
"""

import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.opt import MyOptionParser
from hinemos.util.common import ResultPrinter
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.hub import HubEndpoint
from hinemos.util.hub import HubUtil

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-I', '--logFormatID',  action='store', type='string', metavar='ID', dest='info_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='LogFormat ID')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='Description')
    psr.add_option('-E', '--patternRegex', action='store', type='string', metavar='REGEXP', dest='patternRegex',
                    default=None, help='Pattern Regex')
    psr.add_option('-F', '--timestampFormat', action='store', type='string', metavar='STRING', dest='timestampFormat',
                    default=None, help='Timestamp Format')

    psr.add_option('-A', '--tagExtAction', action='store', type='string', metavar='MODE', dest='tagExtAction',
                    default=(None, {'INLIST':['ADD','MOD','DEL']}), help='ADD/MOD/DEL. ADD: Add a format; MOD: Modify a format; DEL: Delete a format.')
    psr.add_option('-K', '--tagExtKey', action='store', type='string', metavar='STRING', dest='tagExtKey',
                   default=(None, 'NOTBLANK', {'WHEN':{'tagExtAction!=':None}, 'DO':('REQUIRED')}), help='Tag extraction format key')
    psr.add_option('-S', '--tagExtDescription', action='store', type='string', metavar='STRING', dest='tagExtDescription',
                   default=None, help='Tag extraction format description')
    psr.add_option('-T', '--tagExtValueType', action='store', type='string', metavar='TYPE', dest='tagExtValueType',
                   default=(None, {'INLIST':['string','number','bool']}), help='Tag extraction format type = string/number/bool')
    psr.add_option('-Y', '--tagExtKeyType', action='store', type='string', metavar='TYPE', dest='tagExtKeyType',
                   default=(None, {'INLIST':['parsing','fixed']}), help='Tag extraction format key type. parsing: parse from message; fixed: parse from META information.')
    psr.add_option('-P', '--tagExtPattern', action='store', type='string', metavar='STRING', dest='tagExtPattern',
                   default=(None, 'NOTBLANK'), help='Tag extraction format pattern')
    psr.add_option('-V', '--tagExtValue', action='store', type='string', metavar='STRING', dest='tagExtValue',
                   default=(None, 'NOTBLANK'), help='Tag extraction format value')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = HubEndpoint(opts.mgr_url, opts.user, opts.passwd)

        info = endpoint.getLogFormat(opts.info_id)
        LOGGER.debug(info)

        # Modify basics
        HubUtil.set_logformat(
            info,
            opts.description,
            opts.patternRegex,
            opts.timestampFormat)

        # Modify tag extraction formats
        if opts.tagExtAction == 'ADD':
            if not hasattr(info, 'keyPatternList'):
                setattr(info, 'keyPatternList', [])

            info.keyPatternList.append(
                HubUtil.set_logformat_key(
                    endpoint.create_logformat_key(opts.tagExtKey),
                    opts.tagExtDescription,
                    opts.tagExtValueType,
                    opts.tagExtKeyType,
                    opts.tagExtPattern,
                    opts.tagExtValue))
        elif opts.tagExtAction == 'MOD':
            not_found = True

            if hasattr(info, 'keyPatternList'):
                for subinfo in info.keyPatternList:
                    if subinfo.key == opts.tagExtKey:
                        HubUtil.set_logformat_key(
                            subinfo,
                            opts.tagExtDescription,
                            opts.tagExtValueType,
                            opts.tagExtKeyType,
                            opts.tagExtPattern,
                            opts.tagExtValue)
                        not_found = False
                        break
            if not_found:
                raise ErrorHandler.ObjectNotFoundError('Format %s does not exist!' % opts.tagExtKey)
        elif opts.tagExtAction == 'DEL':
            if not hasattr(info, 'keyPatternList'):
                LOGGER.warning('No formats!')
            else:
                del_keys = [a.strip() for a in opts.tagExtKey.split(',')]
                new_lst = []
                for a in info.keyPatternList:
                    if a.key not in del_keys:
                        new_lst.append(a)
                    else:
                        del_keys.remove(a.key)
                info.keyPatternList = new_lst
                for a in del_keys:
                    LOGGER.warning('Format %s not found!', a)

        # HC
        if 'keyPatternList' in info:
            for a in info.keyPatternList:
                if a.pattern is None:
                    a.pattern = ''

        LOGGER.debug(info)
        endpoint.modifyLogFormat(info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyLogFormat')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
