#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブキュー(同時実行制御キュー)を参照しているジョブを一覧表示するビューのための情報を返す

<概要>
ジョブキュー(同時実行制御キュー)を参照しているジョブを一覧表示するビューのための情報を返します。

<使用例>
[command]
    $ python Job_getJobQueueReferrerViewInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -I TESTQ02

[result]
    (jobQueueReferrerViewInfo){
       items[] =
          (jobQueueReferrerViewInfoListItem){
             jobId = "CMD_JOB"
             jobInfoWithOwnerRoleId =
                (jobInfo){
                   abnormalPriority = 0
                   approvalReqMailBody = None
                   approvalReqMailTitle = None
                   approvalReqRoleId = None
                   approvalReqSentence = None
                   approvalReqUserId = None
                   beginPriority = 3
                   command =
                      (jobCommandInfo){
                         commandRetry = 10
                         commandRetryFlg = False
                         facilityID = "LINUX"
                         managerDistribution = False
                         messageRetry = 10
                         messageRetryEndFlg = True
                         messageRetryEndValue = -1
                         processingMethod = 0
                         scope = "$[OS_SCOPE]>Linux>"
                         specifyUser = False
                         startCommand = "sleep 1000;ls -la"
                         stopType = 1
                      }
                   createTime = "2019/03/28 15:17:08.838"
                   createUser = "hinemos"
                   description = "Test Job with Queue"
                   endStatus[] =
                      (jobEndStatusInfo){
                         endRangeValue = 0
                         startRangeValue = 0
                         type = 0
                         value = 0
                      },
                      (jobEndStatusInfo){
                         endRangeValue = 1
                         startRangeValue = 1
                         type = 1
                         value = 1
                      },
                      (jobEndStatusInfo){
                         endRangeValue = 0
                         startRangeValue = 0
                         type = 2
                         value = -1
                      },
                   iconId = None
                   id = "CMD_JOB"
                   jobunitId = "TEST"
                   name = "CMD_JOB"
                   normalPriority = 3
                   ownerRoleId = "ALL_USERS"
                   propertyFull = True
                   referJobSelectType = 0
                   registeredModule = False
                   type = 2
                   updateTime = "2019/04/01 13:20:18.564"
                   updateUser = "hinemos"
                   useApprovalReqSentence = False
                   waitRule =
                      (jobWaitRuleInfo){
                         calendar = False
                         calendarEndStatus = 2
                         calendarEndValue = 0
                         condition = 0
                         endCondition = True
                         endStatus = 2
                         endValue = -1
                         end_delay = False
                         end_delay_change_mount = False
                         end_delay_change_mount_value = 1.0
                         end_delay_condition_type = 0
                         end_delay_job = False
                         end_delay_job_value = 1
                         end_delay_notify = False
                         end_delay_notify_priority = 0
                         end_delay_operation = False
                         end_delay_operation_end_status = 2
                         end_delay_operation_end_value = -1
                         end_delay_operation_type = 0
                         end_delay_session = False
                         end_delay_session_value = 1
                         end_delay_time = False
                         exclusiveBranch = False
                         exclusiveBranchEndStatus = 0
                         exclusiveBranchEndValue = 0
                         jobRetry = 10
                         jobRetryFlg = False
                         multiplicityEndValue = -1
                         multiplicityNotify = True
                         multiplicityNotifyPriority = 2
                         multiplicityOperation = 0
                         queueFlg = True
                         queueId = "TESTQ02"
                         skip = False
                         skipEndStatus = 2
                         skipEndValue = 0
                         start_delay = False
                         start_delay_condition_type = 0
                         start_delay_notify = False
                         start_delay_notify_priority = 0
                         start_delay_operation = False
                         start_delay_operation_end_status = 2
                         start_delay_operation_end_value = -1
                         start_delay_operation_type = 4
                         start_delay_session = False
                         start_delay_session_value = 1
                         start_delay_time = False
                         start_delay_time_value = "09:00:00"
                         suspend = False
                      }
                   warnPriority = 2
                }
             jobunitId = "TEST"
             ownerRoleId = "ALL_USERS"
          },
       queueId = "TESTQ02"
       queueName = "TestQueue"
     }

    http://127.0.0.1:8080/HinemosWS/, getJobQueueReferrerViewInfo succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
from hinemos.api.job import JobEndpoint


def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--queueId', action='store', type='string', metavar='ID', dest='queue_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Job Queue ID')
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)
        result = endpoint.getJobQueueReferrerViewInfo(opts.queue_id)

        if result is not None and hasattr(result, 'items'):
            for item in result.items:
                if 'jobInfoWithOwnerRoleId' in item:
                    job_info = item.jobInfoWithOwnerRoleId
                    if 'createTime' in job_info:
                        job_info.createTime = DateConvert.get_datetime_from_epochtime(job_info.createTime)
                    if 'updateTime' in job_info:
                        job_info.updateTime = DateConvert.get_datetime_from_epochtime(job_info.updateTime)
                    if 'waitRule' in job_info:
                        wait_rule_info = job_info.waitRule
                        if 'end_delay_time_value' in wait_rule_info:
                            wait_rule_info.end_delay_time_value = DateConvert.get_time48_from_epochtime(
                                wait_rule_info.end_delay_time_value)
                        if 'start_delay_time_value' in wait_rule_info:
                            wait_rule_info.start_delay_time_value = DateConvert.get_time48_from_epochtime(
                                wait_rule_info.start_delay_time_value)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getJobQueueReferrerViewInfo')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
