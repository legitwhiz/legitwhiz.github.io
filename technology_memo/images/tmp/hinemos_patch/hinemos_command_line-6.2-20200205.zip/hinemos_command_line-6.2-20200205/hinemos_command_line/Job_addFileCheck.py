#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブのファイルチェック実行契機情報を登録する

<概要>
ジョブのファイルチェック実行契機情報を登録します。

<使用例>
[command]
    $ python Job_addFileCheck.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_FC1 -N TEST_FC1 -J JU001/JOB1 -F NODE001 -d /tmp/ -f "output-*.log" -E DEL -e false

[result]
    http://192.168.1.2:8080/HinemosWS/, addFileCheck succeeded.


[command]
    $ python Job_addFileCheck.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_FC2 -N TEST_FC2 -J JU001/JF001 -F NODE001 -d /tmp/ -f "temporary-*.log" -E ADD

[result]
    http://192.168.1.2:8080/HinemosWS/, addFileCheck succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.job import JobUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--filecheckID',  action='store', type='string', metavar='ID', dest='filecheck_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='filecheckID')
    psr.add_option('-N', '--name', action='store', type='string', metavar='STRING', dest='name',
                    default=(None, 'REQUIRED','NOTBLANK'), help='filecheck name')

    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job_path',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                    default='', help='calendarID')
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='facilityID')
    psr.add_option('-d', '--directory', action='store', type='string', metavar='STRING', dest='directory',
                    default=(None, 'REQUIRED','NOTBLANK'), help='directory')
    psr.add_option('-f', '--fileName', action='store', type='string', metavar='STRING', dest='file_name',
                    default=(None, 'REQUIRED','NOTBLANK'), help='fileName')
    psr.add_option('-E', '--eventType', action='store', type='string', metavar='STRING', dest='event_type_raw',converter=JobUtil.convert2file_check_event_type,
                    default=(None, {'INLIST':JobUtil._file_check_event_type_}), help='eventType = ' + ' or '.join(JobUtil._file_check_event_type_) + ' (default: ADD)')
    psr.add_option('-M', '--modifyType', action='store', type='string', metavar='STRING', dest='modify_type_raw',converter=JobUtil.convert2file_check_mod_type,
                    default=(None, {'INLIST':JobUtil._file_check_mod_type_}, {'WHEN':{'event_type_raw':'MOD'}, 'DO':('REQUIRED')}), help='modifyType = ' + ' or '.join(JobUtil._file_check_mod_type_))

    psr.add_option('-e', '--enable', action='store', type='string', metavar='STRING', dest='enable_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false (default: true)')

    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=('ALL_USERS', 'NOTBLANK'), help='ownerRoleID (default: ALL_USERS)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job_path)
        job_file_check = endpoint.create_job_file_check(\
                    opts.filecheck_id,\
                    opts.name,\
                    job_map,\
                    opts.facility_id,\
                    opts.directory,\
                    opts.file_name,\
                    opts.event_type,\
                    opts.modify_type,\
                    opts.owner_role_id,\
                    opts.calendar_id,\
                    opts.enable)

        endpoint.addFileCheck(job_file_check)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addFileCheck')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
