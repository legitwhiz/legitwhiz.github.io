#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
「開始遅延」タブの情報を変更する

<概要>
「開始遅延」タブの情報を変更します。

<使用例>
- 開始遅延タブの開始遅延を有効にします。
[command]
    $ python Job_modifyJob_StartDelayTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JF001 -e true

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- 開始遅延タブの設定を変更します。
[command]
    $ python Job_modifyJob_StartDelayTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JF001 -e false

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


[command]
    $ python Job_modifyJob_StartDelayTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JF001 -T true -V 23:00:00

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


[command]
    $ python Job_modifyJob_StartDelayTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JF001 -N true -P INFO

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


[command]
    $ python Job_modifyJob_StartDelayTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/JF001 -C OR -O true -X WAIT

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil
from hinemos.util.common import ResultPrinter, SettingUtil, DateConvert
from hinemos.util.modifier import ObjectModifier
from hinemos.util.notify import NotifyUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    ### 開始遅延タブ設定項目 ###

    psr.add_option('-e', '--enableDelay', action='store', type='string', metavar='STRING', dest='enable_raw', converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='endDelay: enable=true, disable=false')

    psr.add_option('-S', '--sessionDelay', action='store', type='string', metavar='STRING', dest='session_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='sessionDelay: enable=true, disable=false')
    psr.add_option('-M', '--sessionDelayValue', action='store', type='int', metavar='INT', dest='session_value',
                    default=None, help='sessionDelayValue : positive integer [min]')
    psr.add_option('-T', '--timeDelay', action='store', type='string', metavar='STRING', dest='time_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='timeDelay: enable=true, disable=false')
    psr.add_option('-V', '--timeDelayValue', action='store', type='string', metavar='STRING', dest='time_value',
                    default=(None, 'NOTBLANK', {'REGEXP':[r'\d{1,2}:\d{1,2}:\d{1,2}$', ' must be in format HH:MM:SS']}), help='timeDelayValue : HH:MM:SS')

    psr.add_option('-C', '--condition', action='store', type='string', metavar='STRING', dest='condition_type_raw',converter=JobUtil.convert2condition,
                    default=(None, {'INLIST':JobUtil._condition_}), help='endDelayConditionType = AND or OR')

    psr.add_option('-N', '--notify', action='store', type='string', metavar='STRING', dest='notify_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='notify: enable=true, disable=false')
    psr.add_option('-P', '--notifyPriority', action='store', type='string', metavar='STRING', dest='notify_priority_raw',converter=NotifyUtil.convert2priority,
                    default=(None, {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN']}), help='notifyPriority = INFO or WARN or CRITICAL or UNKNOWN')

    psr.add_option('-O', '--enableOperation', action='store', type='string', metavar='STRING', dest='operation_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='endDelayOperation: enable=true, disable=false')
    psr.add_option('-X', '--operationType', action='store', type='string', metavar='STRING', dest='operation_type_raw', converter=JobUtil.convert2start_delay_operation_type,
                    default=(None, {'INLIST':JobUtil._start_delay_operation_type_.keys()}), help='operationType : ' + ' or '.join(JobUtil._start_delay_operation_type_.keys()))
    psr.add_option('-Y', '--operationEndStatus', action='store', type='string', metavar='STRING', dest='operation_end_status_raw',converter=JobUtil.convert2end_status,
                    default=(None, {'INLIST':JobUtil._end_status_}), help='operationEndStatus = ' + ' or '.join(JobUtil._end_status_))
    psr.add_option('-Z', '--operationEndValue', action='store', type='int', metavar='INT', dest='operation_end_value',
                    default=None, help='operationEndValue = integer')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job)
        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, job_map['jobunitId'])
        del job_tree_full

        job_info = JobUtil.find_job_info(job_tree, job_map['jobId'])
        if job_info is None:
            raise ErrorHandler.ArgumentError('Job {:s} not found!'.format(job_map['jobId']))

        job_type_label = JobUtil.convert2job_type_label(job_info.type)
        if job_type_label in ('JOBUNIT',): # TODO Do not use exclusion condition
            raise ErrorHandler.ArgumentError('This operation is not available for %s!' % job_type_label)

        new_job_info = endpoint.getJobFull(endpoint.create_job_info_minimal(job_map['jobunitId'], job_map['jobId']))
        with ObjectModifier(new_job_info) as modifier:
            modifier.change_ptr('waitRule')
            modifier.set_if_first_not_none('start_delay', opts.enable)
            modifier.set_if_first_not_none('start_delay_condition_type', opts.condition_type)
            modifier.set_if_first_not_none('start_delay_notify', opts.notify)
            modifier.set_if_first_not_none('start_delay_notify_priority', opts.notify_priority)
            modifier.set_if_first_not_none('start_delay_operation', opts.operation)
            modifier.set_if_first_not_none('start_delay_operation_end_status', opts.operation_end_status)
            modifier.set_if_first_not_none('start_delay_operation_end_value', opts.operation_end_value)
            modifier.set_if_first_not_none('start_delay_operation_type', opts.operation_type)
            modifier.set_if_first_not_none('start_delay_session', opts.session)
            modifier.set_if_first_not_none('start_delay_session_value', opts.session_value)
            modifier.set_if_first_not_none('start_delay_time', opts.time)
            if opts.time_value:
                modifier.set_if_first_not_none('start_delay_time_value', DateConvert.get_epochtime_from_time(opts.time_value))

        JobUtil.replace_job_info(job_tree, new_job_info)

        # Clean up and replace none with blank
        JobUtil.cleanup_and_fixnone(job_tree)

        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJob')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
