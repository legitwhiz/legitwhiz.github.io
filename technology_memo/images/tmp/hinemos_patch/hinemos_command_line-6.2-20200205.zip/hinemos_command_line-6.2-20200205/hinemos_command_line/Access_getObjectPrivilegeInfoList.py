#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
オブジェクト権限検索条件に基づき、オブジェクト権限一覧情報を取得する

<概要>
オブジェクト権限検索条件に基づき、オブジェクト権限一覧情報を取得して表示します。

<使用例>
[command]
    $ python Access_getObjectPrivilegeInfoList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -O INTERNAL

[result]
    [(objectPrivilegeInfo){
    createDate = "2012/04/01 00:00:00"
    createUserId = "hinemos"
    modifyDate = "2012/04/01 00:00:00"
    modifyUserId = "hinemos"
    objectId = "INTERNAL"
    objectPrivilege = "READ"
    objectType = "PLT_REP"
    roleId = "ALL_USERS"
    }, (objectPrivilegeInfo){
    createDate = "2012/04/01 00:00:00"
    createUserId = "hinemos"
    modifyDate = "2012/04/01 00:00:00"
    modifyUserId = "hinemos"
    objectId = "INTERNAL"
    objectPrivilege = "MODIFY"
    objectType = "PLT_REP"
    roleId = "ALL_USERS"
    }, (objectPrivilegeInfo){
    createDate = "2012/04/01 00:00:00"
    createUserId = "hinemos"
    modifyDate = "2012/04/01 00:00:00"
    modifyUserId = "hinemos"
    objectId = "INTERNAL"
    objectPrivilege = "EXEC"
    objectType = "PLT_REP"
    roleId = "ALL_USERS"
    }]
    http://192.168.1.2:8080/HinemosWS/, getObjectPrivilegeInfoList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
from hinemos.api.access import AccessEndpoint
import hinemos.api.exceptions as ErrorHandler

def main():

    psr = MyOptionParser()
    psr.add_option('-O', '--objectID',  action='store', type='string', metavar='ID', dest='object_id',
                    default=None, help='objectID')
    psr.add_option('-P', '--objectPrivilege', action='store', type='string', metavar='STRING', dest='object_privilege',
                    default=(None, {'INLIST':('READ', 'MODIFY', 'EXEC')}), help='objectPrivilege = READ or MODIFY or EXEC')
    psr.add_option('-T', '--objectType', action='store', type='string', metavar='STRING', dest='object_type',
                    default=None, help='objectType')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=None, help='ownerRoleID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = AccessEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        filter_info = endpoint.create_object_privilege_filter_info(object_id=opts.object_id, object_privilege=opts.object_privilege, object_type=opts.object_type, role_id=opts.owner_role_id)
        result = endpoint.getObjectPrivilegeInfoList(filter_info)
        if result is not None:
            for res in result:
                res.createDate = DateConvert.get_datetime_from_epochtime(res.createDate)
                res.modifyDate = DateConvert.get_datetime_from_epochtime(res.modifyDate)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getObjectPrivilegeInfoList' )
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
