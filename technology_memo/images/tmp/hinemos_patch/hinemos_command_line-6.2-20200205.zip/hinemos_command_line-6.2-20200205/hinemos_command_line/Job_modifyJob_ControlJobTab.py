#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
「制御(ジョブ)」タブの情報を変更する

<概要>
「制御(ジョブ)」タブの情報を変更します。

<使用例>
- 制御タブの情報を変更します。
[command]
    $ python Job_modifyJob_ControlJobTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/J001 -C true -I CAL001 -E WARNING -V 10

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- カレンダを無効化します。
[command]
    $ python Job_modifyJob_ControlJobTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/J001 -C false

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- 保留を有効化します。
[command]
    $ python Job_modifyJob_ControlJobTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/J001 -S false -P true -Q WARNING -R 1

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- スキップを有効化します。
[command]
    $ python Job_modifyJob_ControlJobTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/J001 -S true -P false

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.


- キューを有効化します。
[command]
    $ python Job_modifyJob_ControlJobTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/J001 -q true -i TESTQ

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.modifier import ObjectModifier
from hinemos.api.exceptions import ObjectNotFoundError

def main():

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    ### 制御タブ設定項目 ###
    psr.add_option('-C', '--calendar', action='store', type='string', metavar='STRING', dest='calendar_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='calendar: enable=true, disable=false')
    psr.add_option('-I', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                    default=(None, 'NOTBLANK', {'WHEN':{'calendar':'yes'},'DO':('REQUIRED')}), help='calendarID: calendar ID')
    psr.add_option('-E', '--calendarEndStatus', action='store', type='string', metavar='STRING', dest='calendar_end_status_raw',converter=JobUtil.convert2end_status,
                    default=(None, {'INLIST':JobUtil._end_status_}), help='skipEndStatus = ' + ' or '.join(JobUtil._end_status_))
    psr.add_option('-V', '--calendarEndValue', action='store', type='int', metavar='INT', dest='calendar_end_value',
                    default=None, help='calendarEndValue: calendar end value')

    psr.add_option('-S', '--skip', action='store', type='string', metavar='STRING', dest='skip_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='skip: enable=true, disable=false')

    psr.add_option('-P', '--suspend', action='store', type='string', metavar='STRING', dest='suspend_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='suspend: enable=true, disable=false')
    psr.add_option('-Q', '--skipEndStatus', action='store', type='string', metavar='STRING', dest='skip_end_status_raw',converter=JobUtil.convert2end_status,
                    default=(None, {'INLIST':JobUtil._end_status_}), help='skipEndStatus = ' + ' or '.join(JobUtil._end_status_))
    psr.add_option('-R', '--skipEndValue', action='store', type='int', metavar='INT', dest='skip_end_value',
                    default=None, help='skipEndValue: skip end value')

    psr.add_option('-q', '--queue', action='store', type='string', metavar='STRING', dest='queueFlg_raw',
                   converter=SettingUtil.convert2nint, default=(None, {'INLIST': ['true', 'false']}),
                   help='queue: enable=true, disable=false')
    psr.add_option('-i', '--queueID',  action='store', type='string', metavar='ID', dest='queue_id',
                   default=(None, 'NOTBLANK', {'WHEN': {'queueFlg_raw': 'true'}, 'DO': 'REQUIRED'}),
                   help='queueID: Queue ID')

    psr.add_option('-X', '--jobRetry', action='store', type='string', metavar='STRING', dest='job_retry_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='job retry: enable=true, disable=false')
    psr.add_option('-Y', '--jobRetryEndStatus', action='store', type='string', metavar='STRING', dest='job_retry_finish_status_raw',converter=JobUtil.convert2finish_status,
                    default=(None, {'INLIST':JobUtil._job_finish_status_}), help='finish statuses: ' + ', '.join(JobUtil._job_finish_status_))
    psr.add_option('-Z', '--jobRetryCount', action='store', type='int', metavar='INT', dest='job_retry_count',
                    default=None, help='number of retries')

    psr.add_option('-L', '--runNextJobOrder', action='store', type='string', metavar='STRING', dest='run_order_flag_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='run next job in order: enable=true, disable=false')
    psr.add_option('-M', '--noRunNextEndStatus', action='store', type='string', metavar='STRING', dest='no_run_next_end_status_raw',converter=JobUtil.convert2end_status,
                    default=(None, {'INLIST':JobUtil._end_status_}), help='End value of not started next jobs : ' + ', '.join(JobUtil._end_status_))
    psr.add_option('-N', '--notStartedJobEndValue', action='store', type='int', metavar='INT', dest='not_started_end_val',
                    default=None, help='End value of not started next jobs')
    psr.add_option('-O', '--nextJobsIDs', action='store', type='string', metavar='STRING', dest='next_job_ids',
                   default=None, help='ordered list of IDs of jobs dependant on finish of this job nextJobsIDs= id3,id2,...,idN')


    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job)
        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, job_map['jobunitId'])
        del job_tree_full

        job_info = JobUtil.find_job_info(job_tree, job_map['jobId'])
        if job_info is None:
            raise ObjectNotFoundError('%s doe s not exist.' % opts.job)

        job_type_label = JobUtil.convert2job_type_label(job_info.type)
        if job_type_label not in ('JOBNET','JOB','FILEJOB','APPROVALJOB','MONITORJOB'):
            raise ErrorHandler.ArgumentError('This operation is not available for %s!' % job_type_label)

        new_job_info = endpoint.getJobFull(endpoint.create_job_info_minimal(job_map['jobunitId'], job_map['jobId']))

        if opts.next_job_ids is not None:
            if 'exclusiveBranchNextJobOrderList' in new_job_info.waitRule:
                opts.next_job_ids = JobUtil.sortNextJobIds(new_job_info.waitRule.exclusiveBranchNextJobOrderList, opts.next_job_ids)
            else:
                ResultPrinter.warning('No jobs are depending on this job, setting next job ids will be ommited.')

        with ObjectModifier(new_job_info) as modifier:
            modifier.change_ptr('waitRule')
            modifier.set_if_first_not_none('calendar', opts.calendar, calendarId = opts.calendar_id)
            modifier.set_if_first_not_none('calendarEndStatus', opts.calendar_end_status)
            modifier.set_if_first_not_none('calendarEndValue', opts.calendar_end_value)

            modifier.set_if_first_not_none('skip', opts.skip)
            modifier.set_if_first_not_none('skipEndStatus', opts.skip_end_status)
            modifier.set_if_first_not_none('skipEndValue', opts.skip_end_value)

            modifier.set_if_first_not_none('suspend', opts.suspend)
            modifier.set_if_first_not_none('queueFlg', opts.queueFlg, queueId=opts.queue_id)

            modifier.set_if_first_not_none('jobRetryFlg', opts.job_retry)
            if opts.job_retry_finish_status_raw:
                modifier.set_attr(jobRetryEndStatus=opts.job_retry_finish_status)
            modifier.set_if_first_not_none('jobRetry', opts.job_retry_count)

            modifier.set_if_first_not_none('exclusiveBranch', opts.run_order_flag)
            modifier.set_if_first_not_none('exclusiveBranchEndStatus', opts.no_run_next_end_status)
            modifier.set_if_first_not_none('exclusiveBranchEndValue', opts.not_started_end_val)
            modifier.set_if_first_not_none('exclusiveBranchNextJobOrderList', opts.next_job_ids)

        JobUtil.replace_job_info(job_tree, new_job_info)

        # Clean up and replace none with blank
        JobUtil.cleanup_and_fixnone(job_tree)

        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJob')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
