#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
イベントカスタムコマンドの設定を取得する

<概要>
イベントカスタムコマンドの設定を取得します。

<使用例>
[command]
    $ python Monitor_getEventCustomCommandSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    (eventCustomCommandInfoData){
       evemtCustomCommandMap =
          (evemtCustomCommandMap){
             entry[] =
                (entry){
                   key = 1
                   value =
                      (eventCustomCommandInfo){
                         buffer = 512
                         command = "ls -la"
                         dateFormat = "yyyyMMddHHmmssSSS"
                         description = "get details of current working directory"
                         displayName = "GET_CWD_DTL"
                         enable = True
                         encode = "UTF-8"
                         errorRc = 2
                         login = False
                         maxEventSize = 10
                         mode = "auto"
                         queue = 20
                         resultPollingDelay = 5000
                         resultPollingInterval = 30000
                         resultPollingKeeptime = 600000
                         thread = 5
                         timeout = 600000
                         user = "hinemos"
                         warnRc = 1
                      }
                },

                ...中略...

                (entry){
                   key = 4
                   value =
                      (eventCustomCommandInfo){
                         buffer = 512
                         command = None
                         dateFormat = "yyyyMMddHHmmssSSS"
                         description = None
                         displayName = None
                         enable = False
                         encode = "UTF-8"
                         errorRc = 2
                         login = False
                         maxEventSize = 10
                         mode = "auto"
                         queue = 20
                         resultPollingDelay = 5000
                         resultPollingInterval = 30000
                         resultPollingKeeptime = 600000
                         thread = 5
                         timeout = 600000
                         user = None
                         warnRc = 1
                      }
                },
          }
     }

    http://127.0.0.1:8080/HinemosWS/, getEventCustomCommandSettingInfo succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.monitor import MonitorEndpoint
from hinemos.util.common import ResultPrinter


def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = MonitorEndpoint(opts.mgr_url, opts.user, opts.passwd)
        result = endpoint.getEventCustomCommandSettingInfo()
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getEventCustomCommandSettingInfo')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
