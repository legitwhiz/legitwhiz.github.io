#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
収集蓄積(転送)情報を登録する

<概要>
収集蓄積(転送)情報を登録します。

<使用例>
[command]
    $ python Hub_addTransferInfo.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TRAN001 -A event -E fluentd -T realtime -e false

[result]
    http://192.168.1.2:8080/HinemosWS/, addTransferInfo succeeded.


- 転送間隔を「一定間隔で転送」に指定(1 or 3 or 6 or 12 or 24[時間])
[command]
    $ python Hub_addTransferInfo.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TRAN002 -A job -E fluentd -T batch -N 12

[result]
    http://192.168.1.2:8080/HinemosWS/, addTransferInfo succeeded.


- 転送間隔を「保存期間を経て転送」に指定(10 or 20 or 30 or 60 or 90[日間保存後転送])
[command]
    $ python Hub_addTransferInfo.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TRAN003 -A numeric -E fluentd -T delay -N 30

[result]
    http://192.168.1.2:8080/HinemosWS/, addTransferInfo succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.hub import HubUtil
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.hub import HubEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--transferID',  action='store', type='string', metavar='ID', dest='info_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='LogFormat ID')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default='', help='Description')
    psr.add_option('-C', '--calendarId', action='store', type='string', metavar='STRING', dest='calendar_id',
                    default=None, help='calendar ID')
    psr.add_option('-A', '--dataType', action='store', type='string', metavar='STRING', dest='data_type',
                    default=(None, 'REQUIRED', {'INLIST':HubUtil._data_type_}), help='data type (' + ', '.join(HubUtil._data_type_)+ ')')

    psr.add_option('-E', '--destTypeID',  action='store', type='string', metavar='ID', dest='dest_type_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='Destination type ID, e.g. "fluentd"')
    psr.add_option('-P', '--destProps',  action='my_x_append', type='string', metavar='LIST', dest='destProps',
                    default=None, help='Destination properties, e.g. "fluentd.url=http://192.168.1.2:8888/" "fluentd.connect_timeout=5000" "fluentd.request_timeout=10000"')

    psr.add_option('-T', '--transType', action='store', type='string', metavar='STRING', dest='trans_type',
                    default=('realtime', {'INLIST':HubUtil._transfer_type_}), help='transfer type (' + ', '.join(HubUtil._transfer_type_)+ ')')
    psr.add_option('-N', '--interval', action='store', type='int', metavar='INT', dest='interval',
                    default=None, help='interval')
    psr.add_option('-e', '--enable', action='store', type='string', metavar='BOOL', dest='enable_raw', converter=SettingUtil.convert2nbool,
                    default=('true', {'INLIST':['true','false']}), help='enable=true, disable=false')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=('ALL_USERS', 'NOTBLANK'), help='ownerRoleID (default: ALL_USERS)')

    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = HubEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Format inputs
        if opts.description is None:
            opts.description = ''
        if opts.calendar_id == '':
            opts.calendar_id = None
        if opts.enable == None:
            opts.enable = True
        elif opts.enable != True:
            opts.enable = False

        info = HubUtil.set_transfer_info(
            endpoint.create_transfer_info(opts.info_id, opts.owner_role_id),
            opts.description, opts.calendar_id,
            opts.data_type,
            opts.dest_type_id, endpoint.get_dest_type_prop_msts(opts.dest_type_id),
            opts.trans_type,opts.interval,
            opts.enable)

        # Replace dest props
        if opts.destProps is not None:
            for arg in opts.destProps:
                pair = arg.split('=', 1)
                for subinfo in info.destProps:
                    if subinfo.name == pair[0]:
                        subinfo.value = pair[1]
                        break
        result = endpoint.addTransferInfo(info)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'addTransferInfo')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
