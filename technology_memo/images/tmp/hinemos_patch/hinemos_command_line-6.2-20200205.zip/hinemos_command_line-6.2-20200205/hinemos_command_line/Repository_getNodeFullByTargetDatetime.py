#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
対象日時時点のノードの詳細プロパティを取得する

<概要>
対象日時時点のノードの詳細プロパティを取得します。

<使用例>
対象日時を指定した場合、対取象日時までのノードの詳細情報を得して表示されます。対象日時を指定しない場合、最新のノードの詳細情報を取得して表示されます。
[command]
    $ python Repository_getNodeFullByTargetDatetime.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_NODE -T "2019/06/26 00:00:00"

[result]
    [
      {
        'ownerRoleId': ALL_USERS,
        'builtInFlg': False,
        'createDatetime': 2019/06/10 10:23:46.888,
        'createUserId': hinemos,
        'description': Auto detect at Mon Jun 10 10:23:44 +09:00 2019,
        'displaySortOrder': 100,
        'facilityId': TEST_NODE,
        'facilityName': TEST_NODE,
        'facilityType': 1,
        'iconImage': None,
        'modifyDatetime': 2019/06/11 14:23:51.568,
        'modifyUserId': HINEMOS_AGENT,
        'notReferFlg': True,
        'valid': True,
        'administrator': Root <root@localhost> (configure /etc/snmp/snmp.local.conf),
        'agentAwakePort': 24005,
        'autoDeviceSearch': False,
        'cloudLocation': None,
        'cloudResourceId': None,
        'cloudResourceName': None,
        'cloudResourceType': None,
        'cloudScope': None,
        'cloudService': None,
        'contact': None,
        'hardwareType': None,

                ...中略...

    　　'nodeCpuInfo': [
          {
            'deviceDescription': Intel(R) Xeon(R) CPU E5-2403 v2 @ 1.80GHz,
            'deviceDisplayName': cpu0,
            'deviceIndex': 0,
            'deviceName': 196608,
            'deviceSize': 0,
            'deviceSizeUnit': None,
            'deviceType': cpu,
            'clockCount': 1800,
            'coreCount': 1,
            'regDate': None,
            'regUser': None,
            'searchTarget': False,
            'threadCount': 1,
            'updateDate': 2019/06/10 14:23:51.568,
            'updateUser': HINEMOS_AGENT,
          },

                ...中略...

        'subPlatformFamily': None,
        'wbemPort': 5988,
        'wbemProtocol': http,
        'wbemRetryCount': 3,
        'wbemTimeout': 5000,
        'wbemUser': root,
        'wbemUserPassword': None,
        'wbemUserPasswordCrypt': zFH4qd2QoBg=,
        'winrmPort': 5985,
        'winrmProtocol': http,
        'winrmRetries': 3,
        'winrmTimeout': 5000,
        'winrmUser': Administrator,
        'winrmUserPassword': None,
        'winrmUserPasswordCrypt': zFH4qd2QoBg=,
        'winrmVersion': 2.0,
      }
    ]

    http://127.0.0.1:8080/HinemosWS/, getNodeFullByTargetDatetime succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.repository import RepositoryEndpoint_Zeep
from hinemos.util.common import DateConvert, ResultPrinter


def main():
    psr = MyOptionParser()
    psr.add_option('-I', '--facilityID', action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Facility ID')
    psr.add_option('-T', '--targetDateTime', action='store', type='string', metavar='DATE', dest='target_date_time_raw',
                   converter=DateConvert.get_epochtime_from_datetime,
                   default=(None, {'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$',
                                              'must be in [yyyy/mm/dd HH:MM:SS] format']}),
                   help='Target Date Time [yyyy/mm/dd HH:MM:SS]')
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = RepositoryEndpoint_Zeep(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getNodeFullByTargetDatetime(opts.facility_id, opts.target_date_time, None)

        if result is not None:
            format_result_date_time(result)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getNodeFullByTargetDatetime')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


def format_result_date_time(result):
    result.createDatetime = DateConvert.get_datetime_from_epochtime(result.createDatetime)
    result.modifyDatetime = DateConvert.get_datetime_from_epochtime(result.modifyDatetime)
    result.nodeConfigTargetDatetime = DateConvert.get_datetime_from_epochtime(result.nodeConfigTargetDatetime)

    if hasattr(result, 'nodeOsInfo') and getattr(result, 'nodeOsInfo') is not None:
        node_os_info_obj = result.nodeOsInfo
        if hasattr(node_os_info_obj, 'regDate') and getattr(node_os_info_obj, 'regDate') is not None:
            node_os_info_obj.regDate = DateConvert.get_datetime_from_epochtime(node_os_info_obj.regDate)
        if hasattr(node_os_info_obj, 'updateDate') and getattr(node_os_info_obj, 'updateDate') is not None:
            node_os_info_obj.updateDate = DateConvert.get_datetime_from_epochtime(node_os_info_obj.updateDate)
        if hasattr(node_os_info_obj, 'startupDateTime') and getattr(node_os_info_obj, 'startupDateTime') is not None:
            node_os_info_obj.startupDateTime = DateConvert.get_datetime_from_epochtime(
                node_os_info_obj.startupDateTime) if node_os_info_obj.startupDateTime > 0 else 0

    obj_list = ['nodeCpuInfo', 'nodeCustomInfo', 'nodeDiskInfo', 'nodeFilesystemInfo', 'nodeHostnameInfo',
                'nodeLicenseInfo', 'nodeMemoryInfo', 'nodeNetstatInfo', 'nodeNetworkInterfaceInfo', 'nodePackageInfo',
                'nodeProcessInfo', 'nodeProductInfo', 'nodeVariableInfo']

    for obj in obj_list:
        if hasattr(result, obj):
            obj_value = getattr(result, obj)
            for item in obj_value:
                if hasattr(item, 'regDate') and getattr(item, 'regDate') is not None:
                    item.regDate = DateConvert.get_datetime_from_epochtime(item.regDate)
                if hasattr(item, 'updateDate') and getattr(item, 'updateDate') is not None:
                    item.updateDate = DateConvert.get_datetime_from_epochtime(item.updateDate)
                if hasattr(item, 'expirationDate') and getattr(item, 'expirationDate') is not None:
                    # nodeLicenseInfo用
                    item.expirationDate = DateConvert.get_datetime_from_epochtime(item.expirationDate)
                if hasattr(item, 'installDate') and getattr(item, 'installDate') is not None:
                    # nodePackageInfo用
                    item.installDate = DateConvert.get_datetime_from_epochtime(item.installDate)
                if hasattr(item, 'startupDateTime') and getattr(item, 'startupDateTime') is not None:
                    # nodeProcessInfo用
                    item.startupDateTime = DateConvert.get_datetime_from_epochtime(item.startupDateTime)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
