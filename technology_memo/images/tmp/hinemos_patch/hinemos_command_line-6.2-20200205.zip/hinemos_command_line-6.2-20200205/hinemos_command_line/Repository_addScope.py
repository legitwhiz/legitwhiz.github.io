#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
スコープを新規に追加する

<概要>
スコープを新規に追加します。

<使用例>
[command]
    $ python Repository_addScope.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F APITEST_SCOPE -N APITEST_SCOPE

[result]
    http://192.168.1.2:8080/HinemosWS/, addScope succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.common import ResultPrinter

def main():

    psr = MyOptionParser()
    psr.add_option('-P', '--parentFacilityID',  action='store', type='string', metavar='ID', dest='parent_facility_id',
                    default='', help='parent facility ID')
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='facility ID')
    psr.add_option('-N', '--facilityName', action='store', type='string', metavar='STRING', dest='facility_name',
                    default=(None, 'REQUIRED','NOTBLANK'), help='facility name')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default='', help='description')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=('ALL_USERS', 'NOTBLANK'), help='ownerRoleID (default: ALL_USERS)')
    psr.add_option('-I', '--iconImage', action='store', type='string', metavar='STRING', dest='icon_image',
                    default='', help='icon image')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit###
        ### scopeInfo parameter####
        scope_info = endpoint.create_scope_info(opts.facility_id, opts.facility_name, opts.description, opts.owner_role_id, opts.icon_image)

        # TODO Remove the following hardcode
        scope_info.facilityType = 0

        endpoint.addScope(opts.parent_facility_id, scope_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addScope')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
