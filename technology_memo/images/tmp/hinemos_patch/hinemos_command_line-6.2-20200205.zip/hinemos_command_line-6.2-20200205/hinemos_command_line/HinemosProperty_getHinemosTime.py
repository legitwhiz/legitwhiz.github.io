#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
現在のHinemos時刻を返す

<概要>
現在のHinemos時刻を返します。

<使用例>
[command]
    $ python HinemosProperty_getHinemosTime.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    1552992553143

    http://127.0.0.1:8080/HinemosWS/, getHinemosTime succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.util.common import ResultPrinter
from hinemos.api.hinemosproperty import HinemosPropertyEndpoint


def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = HinemosPropertyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getHinemosTime()
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getHinemosTime')
    except Exception, e:
        return_code = ResultPrinter.failure(e)

    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
