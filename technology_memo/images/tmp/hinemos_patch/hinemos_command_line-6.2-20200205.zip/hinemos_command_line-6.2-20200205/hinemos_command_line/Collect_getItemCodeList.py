#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
収集項目コードのリストを取得する

<概要>
収集項目コードのリストを取得します


<使用例>
[command]
    $ python Collect_getItemCodeList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE

[result]
    [(collectKeyInfoPK){
       displayName = None
       facilityid = "TEST_NODE"
       itemName = "$[JMX_JVM_HEAP_SIZE]"
       monitorId = "JMX01"
     }, (collectKeyInfoPK){
       displayName = None
       facilityid = "TEST_NODE"
       itemName = "応答時間"
       monitorId = "PING01"
     }]
    http://192.168.1.2:8080/HinemosWS/, getItemCodeList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.collect import CollectEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='facilityID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = CollectEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getItemCodeList(opts.facility_id)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getItemCodeList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
