#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したメンテナンス情報を追加する

<概要>
引数で指定したメンテナンス情報を追加します。

<使用例>
[command]
    $ python Maintenance_addMaintenance.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_MA -D TEST_MA -T DELETE_EVENT_LOG_ALL -A MYAPP -E 30 -S "12/01 00:00" -e true

[result]
    http://192.168.1.2:8080/HinemosWS/, addMaintenance succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.maintenance import MaintenanceEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.maintenance import MaintenanceSettingUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--maintenanceID',  action='store', type='string', metavar='ID', dest='maintenance_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='maintenance_id')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='description')
    psr.add_option('-T', '--typeID',  action='store', type='string', metavar='ID', dest='type_id',
                    default=(None, 'REQUIRED',{'INLIST':MaintenanceSettingUtil._type_}), help='typeID = ' + ' or '.join(MaintenanceSettingUtil._type_))
    psr.add_option('-E', '--dataRetentionPeriod', action='store', type='int', metavar='INT', dest='data_retention_period',
                    default=(None, 'REQUIRED'), help='data retention period [day]')
    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                    default=None, help='calendarID')
    psr.add_option('-S', '--schedule', action='store', type='string', metavar='STRING', dest='schedule',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='format : "[[mm/]DD or WEEKDAY] HH:MM" e.g. "12:00", "02 23:59", "12/01 00:00", "Sun 02:12". WEEKDAY = Sun, Mon, Tue, Wed, Thu, Fri, Sat')
    psr.add_option('-N', '--notifyIDs', action='store_split', type='string', metavar='STRING', dest='notify_ids_raw',
                    default=None, help='notifyIDList notifyID1,notifyID2,...,notifyIDN')
    psr.add_option('-A', '--application', action='store', type='string', metavar='STRING', dest='application',
                    default=(None, 'REQUIRED','NOTBLANK'), help='application')
    psr.add_option('-e', '--enable', action='store', type='string', metavar='STRING', dest='enable_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false (default: true)')

    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=('ALL_USERS', 'NOTBLANK'), help='ownerRoleID (default: ALL_USERS)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MaintenanceEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Notify
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)
        notify_infos = []
        if opts.notify_ids is not None:
            notify_id_lst = opts.notify_ids[:]
            for a in notify_endpoint.getNotifyList():
                if a.notifyId in notify_id_lst:
                    notify_infos.append(a)
                    notify_id_lst.remove(a.notifyId)
            if 0 < len(notify_id_lst):
                ResultPrinter.warning('Notify ' + (', '.join(notify_id_lst)) + ' will be ignored!')
        if 0 == len(notify_infos):
            notify_infos = None

        endpoint.addMaintenance(endpoint.create_maintenance_info(\
                opts.maintenance_id,\
                opts.type_id,\
                opts.data_retention_period,\
                opts.application,\
                endpoint.create_schedule_from_str(opts.schedule),\
                opts.calendar_id,\
                opts.description,\
                opts.owner_role_id,\
                opts.enable,\
                notify_infos))

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMaintenance')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
