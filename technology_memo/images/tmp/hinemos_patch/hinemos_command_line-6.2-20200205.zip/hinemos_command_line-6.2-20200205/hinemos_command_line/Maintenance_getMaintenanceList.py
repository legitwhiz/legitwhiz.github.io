#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
メンテナンス情報の一覧を取得する

<概要>
メンテナンス情報の一覧を取得して表示します。

<使用例>
[command]
    $ python Maintenance_getMaintenanceList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    [(maintenanceInfo){
       ownerRoleId = "ADMINISTRATORS"
       application = "MT-COL-N-1RD-DEFAULT"
       dataRetentionPeriod = 7
       description = "Collect history deletion"
       maintenanceId = "MT-COL-N-1RD-DEFAULT"
       notifyGroupId = "SYS_MTN-MT-COL-N-1RD-DEFAULT-0"
       regDate = "2017/02/09 15:46:15.577"
       regUser = "hinemos"
       schedule =
          (schedule){
             hour = 5
             minute = 20
             type = 1
          }
       typeId = "DELETE_COLLECT_DATA_RAW"
       updateDate = "2017/02/09 15:46:15.577"
       updateUser = "hinemos"
       validFlg = True
       ... 中略 ...
     }, (maintenanceInfo){
       ownerRoleId = "ALL_USERS"
       application = "MYAPP"
       dataRetentionPeriod = 30
       description = "TEST_MA"
       maintenanceId = "TEST_MA"
       notifyGroupId = "MAINTENANCE-TEST_MA-0"
       regDate = "2017/03/03 17:25:06.407"
       regUser = "hinemos"
       schedule =
          (schedule){
             day = 1
             hour = 0
             minute = 0
             month = 12
             type = 1
          }
       typeId = "DELETE_EVENT_LOG_ALL"
       updateDate = "2017/03/03 17:25:06.407"
       updateUser = "hinemos"
       validFlg = True
     }]
    http://192.168.1.2:8080/HinemosWS/, getMaintenanceList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.maintenance import MaintenanceEndpoint

def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MaintenanceEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = endpoint.getMaintenanceList()
        if result is not None:
            for i in range(len(result)):
                result[i].regDate = DateConvert.get_datetime_from_epochtime(result[i].regDate)
                result[i].updateDate = DateConvert.get_datetime_from_epochtime(result[i].updateDate)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getMaintenanceList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
