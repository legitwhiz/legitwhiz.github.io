#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したファシリティIDのノードの詳細プロパティ（構成情報含めて）を取得する

<概要>
引数で指定したファシリティIDのノードの詳細プロパティ（構成情報含めて）を取得して表示します。

<使用例>
[command]
    $ python Repository_getNodeFull.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE

[result]
    (nodeInfo){
       ownerRoleId = "ALL_USERS"
       builtInFlg = False
       createDatetime = "2019/04/10 14:14:51.233"
       createUserId = "hinemos"
       description = "Auto detect at Wed Apr 10 14:14:42 +09:00 2019"
       displaySortOrder = 100
       facilityId = "TEST_NODE"
       facilityName = "TEST_NODE"
       facilityType = 1
       iconImage = None
       modifyDatetime = "2019/04/10 14:14:51.233"
       modifyUserId = "hinemos"

               ...中略...

       nodeHostnameInfo[] =
          (nodeHostnameInfo){
             hostname = "TEST_NODE"
             regDate = "2019/04/10 14:14:51.233"
             regUser = "hinemos"
             searchTarget = False
          },
       nodeHostnameRegisterFlag = 0
       nodeLicenseRegisterFlag = 0
       nodeMemoryRegisterFlag = 0
       nodeName = "TEST_NODE"
       nodeNetstatRegisterFlag = 0
       nodeProcessInfo[] =
          (nodeProcessInfo){
             execUser = "root"
             path = "/usr/sbin/NetworkManager --no-daemon"
             pid = 701
             processName = "NetworkManager"
             regDate = "2019/04/10 18:07:32.483"
             regUser = "HINEMOS_AGENT"
             searchTarget = False
             startupDateTime = 1554179465000
          },

                ...中略...

       nodeNetworkInterfaceInfo[] =
          (nodeNetworkInterfaceInfo){
             deviceDescription = None
             deviceDisplayName = "ens192"
             deviceIndex = 2
             deviceName = "ens192"
             deviceSize = 0
             deviceSizeUnit = None
             deviceType = "nic"
             nicIpAddress = "172.16.44.141"
             nicMacAddress = "00:50:56:9F:06:12"
             regDate = "2019/04/10 14:14:51.233"
             regUser = "hinemos"
             searchTarget = False
             updateDate = "2019/04/10 14:14:51.233"
             updateUser = "hinemos"
          },
       nodeNetworkInterfaceRegisterFlag = 0
       nodeNoteInfo[] =
          (nodeNoteInfo){
             note = None
             noteId = 0
          },
       nodeOsInfo =
          (nodeOsInfo){
             characterSet = None
             facilityId = "TEST_NODE"
             osName = "Linux"
             osRelease = None
             osVersion = "Linux TEST_NODE 3.10.0-862.el7.x86_64 #1 SMP Wed Mar 21 18:14:51 EDT 2018 x86_64"
             regDate = "2019/04/10 14:14:51.233"
             regUser = "hinemos"
             searchTarget = False
             startupDateTime = 0
             updateDate = "2019/04/10 14:14:51.233"
             updateUser = "hinemos"
          }
       nodeOsRegisterFlag = 0a

               ...中略...

       wbemUserPassword = None
       wbemUserPasswordCrypt = "zFH4qd2QoBg="
       winrmPort = 5985
       winrmProtocol = "http"
       winrmRetries = 3
       winrmTimeout = 5000
       winrmUser = "Administrator"
       winrmUserPassword = None
       winrmUserPasswordCrypt = "zFH4qd2QoBg="
       winrmVersion = "2.0"
     }

    http://127.0.0.1:8080/HinemosWS/, getNodeFull succeeded.


※ 実行結果のうち、snmpVersionの値については、
ノードの詳細プロパティに登録されているSNMPのバージョンに応じて
以下のものが表示されます。

  - SNMPバージョン 1   => 「snmpVersion = 0」
  - SNMPバージョン 2c  => 「snmpVersion = 1」
  - SNMPバージョン 3   => 「snmpVersion = 3」
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
from hinemos.api.repository import RepositoryEndpoint


def main():

    psr = MyOptionParser()
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Facility ID')
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getNodeFull(opts.facility_id)
        if result is not None:
            format_result_date_time(result)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getNodeFull')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


def format_result_date_time(result):
    result.createDatetime = DateConvert.get_datetime_from_epochtime(result.createDatetime)
    result.modifyDatetime = DateConvert.get_datetime_from_epochtime(result.modifyDatetime)
    result.nodeConfigTargetDatetime = DateConvert.get_datetime_from_epochtime(result.nodeConfigTargetDatetime)

    if 'nodeOsInfo' in result:
        node_os_info_obj = result.nodeOsInfo
        if 'regDate' in node_os_info_obj:
            node_os_info_obj.regDate = DateConvert.get_datetime_from_epochtime(node_os_info_obj.regDate)
        if 'updateDate' in node_os_info_obj:
            node_os_info_obj.updateDate = DateConvert.get_datetime_from_epochtime(node_os_info_obj.updateDate)

    obj_list = ['nodeCpuInfo', 'nodeCustomInfo', 'nodeDiskInfo', 'nodeFilesystemInfo', 'nodeHostnameInfo',
                'nodeLicenseInfo', 'nodeMemoryInfo', 'nodeNetstatInfo', 'nodeNetworkInterfaceInfo', 'nodePackageInfo',
                'nodeProcessInfo', 'nodeProductInfo', 'nodeVariableInfo']

    for obj in obj_list:
        if obj in result:
            obj_value = getattr(result, obj)
            for item in obj_value:
                if 'regDate' in item:
                    item.regDate = DateConvert.get_datetime_from_epochtime(item.regDate)
                if 'updateDate' in item:
                    item.updateDate = DateConvert.get_datetime_from_epochtime(item.updateDate)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
