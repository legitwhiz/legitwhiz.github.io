#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
フィルタ条件に合うノード一覧を取得する

<概要>
フィルタ条件に合うノード一覧を取得して表示します。

<使用例>
[command]
    $ python Repository_getFilterNodeList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_NODE

[result]
    [(nodeListInfo){
       facilityId = "TEST_NODE"
       facilityName = "TEST_NODE"
       ipAddressVersion = 4
       ipAddressV4 = "192.168.0.2"
       ipAddressV6 = None
       description = "Auto detect at Mon Mar 06 11:47:07 +09:00 2017"
       ownerRoleId = "ALL_USERS"
     }]
    http://192.168.1.2:8080/HinemosWS/, getFilterNodeList succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.repository import ResultSet

def main():

    psr = MyOptionParser()
    psr.add_option('-F', '--facilityid', action='store', type='string', metavar='STRING', dest='facilityid',
                    default='', help='facilityid')
    psr.add_option('-N', '--facilityname', action='store', type='string', metavar='STRING', dest='facilityname',
                    default='', help='facilityname')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default='', help='description')
    psr.add_option('-4', '--ipaddressv4', action='store', type='string', metavar='STRING', dest='ipaddressv4',
                    default='', help='ipaddressv4')
    psr.add_option('-6', '--ipaddressv6', action='store', type='string', metavar='STRING', dest='ipaddressv6',
                    default='', help='ipaddressv6')
    psr.add_option('-O', '--osname', action='store', type='string', metavar='STRING', dest='osname',
                    default='', help='osname')
    psr.add_option('-R', '--osrelease', action='store', type='string', metavar='STRING', dest='osrelease',
                    default='', help='osrelease')
    psr.add_option('-A', '--administrator', action='store', type='string', metavar='STRING', dest='administrator',
                    default='', help='administrator')
    psr.add_option('-C', '--contact', action='store', type='string', metavar='STRING', dest='contact',
                    default='', help='contact')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:

        ### argument check ###
        if len(opts.facilityid) == 0 and \
           len(opts.facilityname) == 0 and \
           len(opts.description) == 0 and \
           len(opts.ipaddressv4) == 0 and \
           len(opts.ipaddressv6) == 0 and \
           len(opts.osname) == 0 and \
           len(opts.osrelease) == 0 and \
           len(opts.administrator) == 0 and \
           len(opts.contact) == 0 :
            raise ErrorHandler.ArgumentError('Please specify at least one filter!')

        ### login ###
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        node_info = endpoint.create_node_info(opts.facilityid, opts.facilityname, opts.description, opts.ipaddressv4, opts.ipaddressv6, opts.osname, opts.osrelease, opts.administrator, opts.contact)

        result = endpoint.getFilterNodeList(node_info)
        list = []
        list = ResultSet.nodeListInfo(result)
        return_code = ResultPrinter.success(list, opts.mgr_url, 'getFilterNodeList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
