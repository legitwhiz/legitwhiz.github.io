#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したジョブのジョブ操作を行う

<概要>
引数で指定したジョブのジョブ操作を行い、実行したジョブのSESSIONIDを表示します。

また、-W/--waitオプションを付与した場合、LIMITで指定した時間のまでの間、
SLEEPTIMEで指定した時間の間隔でジョブの状態確認し、ジョブが終了するまで待機します。

<使用例>
- 実行状態を確認せず、ジョブのみ実行します。
[command]
    $ python Job_runJob.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J TEST_JOBU -I TEST_JOB

[result]
    JobsessionId : 20170307150702-000
    http://192.168.1.2:8080/HinemosWS/, runJob succeeded.


- タイムアウトまでの時間を60秒としてジョブを実行し、実行終了、またはタイムアウトまで待機します。
[command]
    $ python Job_runJob.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J TEST_JOBU -I TEST_JOB -W -L 60

[result]
    JobsessionId : 20170307150727-000
    status:300
    20170307150727-000 is complete
    http://192.168.1.2:8080/HinemosWS/, runJob succeeded.


- ランタイムジョブ変数Param1にvalue1、Param2にvalue2、Param3にvalue3を入力したジョブのマニュアル実行を行います。
[command]
    $ python Job_runJob.py -w hinemos -K TEST_JOBK -P Param1 Param2 Param3 -V value1 value2 value3

[result]
    JobsessionId :  20170728163901-000
    http://192.168.1.2:8080/HinemosWS/, runJob succeeded.


なお、値を空白にする場合は、以下のように "" を指定します。
[command]
    $ python Job_runJob.py -w hinemos -K TEST_JOBK -P Param1 Param2 -V "" value2

[result]
    JobsessionId :  20170728164223-000
    http://192.168.1.2:8080/HinemosWS/, runJob succeeded.

"""

import os
import sys
import codecs, locale
import time
import logging
from logging.config import fileConfig
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import OptionUtil
from hinemos.api.exceptions import ArgumentError
from hinemos.util.job import JobUtil

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-J', '--jobunitID',  action='store', type='string', metavar='ID', dest='jobunitID',
                    default=(None,'NOTBLANK',{'WHEN':{'jobKickID':None, 'runtimeParamIds':None ,'runtimeParamValues':None}, 'DO':('REQUIRED')}), help='Jobunit ID')
    psr.add_option('-I', '--jobID',  action='store', type='string', metavar='ID', dest='job_id',
                    default=(None,'NOTBLANK',{'WHEN':{'jobKickID':None, 'runtimeParamIds':None ,'runtimeParamValues':None}, 'DO':('REQUIRED')}), help='Job ID')
    psr.add_option('-D', '--trginfo', action='store', type='string', metavar='STRING', dest='trigger_info',
                    default='hinemos', help='Sepcify trigger information')
    psr.add_option('-T', '--trgtype', action='store', type='int', metavar='INT', dest='trigger_type',
                    default=(2, 'REQUIRED',{'INLIST':[1,2,3,4]}), help='Specify trigger type. SCHEDULE = 1, MANUAL = 2, MONITOR = 3, FILECHECK = 4')
    psr.add_option('-K', '--jobKickID', action='store', type='string', metavar='ID', dest='jobKickID',
                    default=(None,'NOTBLANK', {'WHEN':{'jobunitID':None, 'job_id':None}, 'DO':('REQUIRED')}, {'WHEN':{'runtimeParamIds!=':None}, 'DO':('REQUIRED')}, {'WHEN':{'runtimeParamValues!=':None}, 'DO':('REQUIRED')}),
                     help='jobkick ID (If you run the jobkick, this option is required instead of -J and -I.)')
    psr.add_option('-P', '--runtimeParamIds', action='my_x_append', type='string', metavar='LIST', dest='runtimeParamIds',
                   default=(None,{'WHEN':{'runtimeParamValues!=':None}, 'DO':('REQUIRED')}), help='runtime param IDs, e.g. Param1 Param2 Param3')
    psr.add_option('-V', '--runtimeParamValues', action='my_x_append', type='string', metavar='LIST', dest='runtimeParamValues',
                   default=(None,{'WHEN':{'runtimeParamIds!=':None}, 'DO':('REQUIRED')}), help='runtime param values, e.g. value1 value2 value3')
    psr.add_option('-W', '--wait', action='store_true', dest='wait',
                    default=None, help='Wait till the completion of job run' )
    psr.add_option('-L', '--limit', action='store', type='int', metavar='INT', dest='limit',
                    default=(None, {'WHEN':{'wait':True}, 'DO':('REQUIRED')}), help='Specify timeout [sec]')
    psr.add_option('-S', '--sleeptime', action='store', type='int', metavar='INT', dest='sleeptime',
                    default=10, help='Wait interval [sec]')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        t1 = time.time()

        jobunit_id = None
        job_id = None
        if opts.jobunitID is not None:
            jobunit_id = opts.jobunitID
        if opts.job_id is not None:
            job_id = opts.job_id

        ### runJob trigger ##
        job_trigger_info = endpoint.create_job_trigger_info(trigger_type=opts.trigger_type, trigger_info=opts.trigger_info)
        if opts.jobKickID:
            if jobunit_id: 
                LOGGER.warning('Option -J/--jobunitID will be overridden by -K/--jobKickID')
            if job_id:
                LOGGER.warning('Option -I/--jobID will be overridden by -K/--jobKickID')

            job_trigger_info.jobkickId = opts.jobKickID

            jobkick_info = endpoint.getJobKick(opts.jobKickID)
            jobunit_id = jobkick_info.jobunitId
            job_id = jobkick_info.jobId

            # argument format -> dict
            runtime_params = None
            try:
                runtime_params = OptionUtil.zip_pairs(opts.runtimeParamIds, opts.runtimeParamValues)
            except ArgumentError, e:
                raise ErrorHandler.ArgumentError('The number of runtimeParamIds and runtimeParamValues are different.' + e.message)

            if not hasattr(jobkick_info, 'jobRuntimeParamList'):
                setattr(jobkick_info, 'jobRuntimeParamList', [])

            for runtime_param in jobkick_info.jobRuntimeParamList:
                if runtime_param.paramId not in runtime_params:
                    if runtime_param.requiredFlg:
                        raise ErrorHandler.ArgumentError('Required runtime parameter missing: %s' % runtime_param.paramId)
                    else:
                        #runtime_param.value = runtime_param.value # Just use default value
                        pass
                else:
                    # check if FIXED
                    if runtime_param.paramType == JobUtil.convert2param_type('FIXED'): 
                        raise ErrorHandler.ArgumentError('Invalid change for FIXED type: %s' % runtime_param.paramId)
                    else:
                        # check default value
                        if 'value' not in runtime_param:
                            setattr(runtime_param, 'value', None)
                        runtime_param.value = runtime_params[runtime_param.paramId] # Use input value
                        del runtime_params[runtime_param.paramId]

                        if (runtime_param.paramType == JobUtil.convert2param_type('COMBO') or runtime_param.paramType == JobUtil.convert2param_type('INPUT')) and runtime_param.value == '':
                            # normalization, as None
                            runtime_param.value = None
                            if runtime_param.requiredFlg:
                                raise ErrorHandler.ArgumentError('Required runtime parameter missing: %s' % runtime_param.paramId)

                        # check out of range
                        if runtime_param.paramType == JobUtil.convert2param_type('RADIO') or (runtime_param.paramType == JobUtil.convert2param_type('COMBO') and runtime_param.value is not None):
                            if runtime_param.value not in (a.paramValue for a in runtime_param.jobRuntimeParamDetailList):
                                raise ErrorHandler.ArgumentError('Invalid runtime parameter value: %s' % runtime_param.value)

                job_trigger_info.jobRuntimeParamList.append(runtime_param)

            if 0 < len(runtime_params):
                LOGGER.warning('Invalid runtime parameter ID(s): %s', ', '.join(runtime_params.keys()))

        output_basic_info = endpoint.create_output_basic_info()

        ### runJob execute ###
        sessionId = endpoint.runJob(jobunit_id, job_id, output_basic_info, job_trigger_info)
        print 'JobsessionId : ' + sessionId

        #### Waiting for completion ###
        if opts.wait:
            limits = opts.limit
            sleeptime = opts.sleeptime

            # First wait for a while because run_job might be being executed asynchronously now
            time.sleep(sleeptime)

            timeout_flg = 0
            rslist = endpoint.getJobDetailList(sessionId)
            while timeout_flg == 0 and (rslist[0][0].detail.status == 100 or rslist[0][0].detail.status == 101):
                time.sleep(sleeptime)
                rslist = endpoint.getJobDetailList(sessionId)
                t2 = time.time()
                runtime = t2 - t1
                if runtime >= limits:
                    timeout_flg = 1
            else:
                if timeout_flg == 1:
                    raise Exception('Time limit is exceeded, status: ' +str(rslist[0][0].detail.status))
                print 'status:' + str(rslist[0][0].detail.status)
                if rslist[0][0].detail.status == 300:
                    print sessionId + ' is complete'
                elif rslist[0][0].detail.status == 301 or rslist[0][0].detail.status == 200:
                    print sessionId + ' is interrupted'
                elif rslist[0][0].detail.status == 201:
                    print sessionId + ' is command stop'
        return_code = ResultPrinter.success(None, opts.mgr_url, 'runJob')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
