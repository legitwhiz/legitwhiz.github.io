#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
通知情報一覧を取得する

<概要>
通知情報一覧を取得し、一覧表示します。

<使用例>
[command]
    $ python Notify_getNotifyList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    [(notifyInfo){
       ownerRoleId = "ALL_USERS"
       initialCount = 1
       notFirstNotify = False
       notifyCommandInfo =
          (notifyCommandInfo){
             criticalValidFlg = False
             infoValidFlg = True
             unknownValidFlg = False
             warnValidFlg = False
             infoCommand = "echo test"
             infoEffectiveUser = "root"
             setEnvironment = True
             timeout = 15000
          }
       notifyId = "COMMAND00"
       notifyType = 5
       regDate = "2017/02/23 14:02:36.602"
       regUser = "hinemos"
       renotifyType = 0
       updateDate = "2017/02/23 14:02:36.602"
       updateUser = "hinemos"
       validFlg = True
       ... 中略 ...
     }, (notifyInfo){
       ownerRoleId = "ALL_USERS"
       initialCount = 1
       notFirstNotify = False
       notifyId = "status"
       notifyStatusInfo =
          (notifyStatusInfo){
             criticalValidFlg = True
             infoValidFlg = True
             unknownValidFlg = True
             warnValidFlg = True
             statusInvalidFlg = 11
             statusUpdatePriority = 2
             statusValidPeriod = 10
          }
       notifyType = 0
       regDate = "2017/02/21 15:59:21.058"
       regUser = "hinemos"
       renotifyType = 0
       updateDate = "2017/02/21 15:59:21.058"
       updateUser = "hinemos"
       validFlg = True
     }]
    http://192.168.1.2:8080/HinemosWS/, getNotifyList succeeded.
"""

### import ###
import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.notify import NotifyEndpoint

def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getNotifyList()
        if result is not None:
            for i in range(len(result)):
                result[i].regDate = DateConvert.get_datetime_from_epochtime(result[i].regDate)
                result[i].updateDate = DateConvert.get_datetime_from_epochtime(result[i].updateDate)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getNotifyList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
