#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
構成情報取得設定を取得する

<概要>
構成情報取得設定を取得します。

<使用例>
[command]
    $ python Repository_getNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING

[result]
    (nodeConfigSettingInfo){
       ownerRoleId = "ALL_USERS"
       calendarId = None
       description = None
       facilityId = "LINUX"
       nodeConfigCustomList[] =
          (nodeConfigCustomInfo){
             command = "ls -l"
             description = None
             displayName = "TEST_COMMAND"
             effectiveUser = "hinemos"
             settingCustomId = "TEST_COMMAND"
             specifyUser = True
             validFlg = True
          },
       nodeConfigSettingItemList[] =
          (nodeConfigSettingItemInfo){
             settingItemId = "CUSTOM"
          },
          (nodeConfigSettingItemInfo){
             settingItemId = "NETSTAT"
          },
          (nodeConfigSettingItemInfo){
             settingItemId = "OS"
          },
          (nodeConfigSettingItemInfo){
             settingItemId = "HW_CPU"
          },
          (nodeConfigSettingItemInfo){
             settingItemId = "PROCESS"
          },
       notifyGroupId = "NODE_CONFIG_SETTING-TEST_SETTING"
       notifyRelationList[] =
          (notifyRelationInfo){
             notifyGroupId = "NODE_CONFIG_SETTING-TEST_SETTING"
             notifyId = "event01"
             notifyType = 1
          },
       regDate = "2019/04/10 11:50:25.053"
       regUser = "hinemos"
       runInterval = 21600
       scope = "$[OS_SCOPE]>Linux>"
       settingId = "TEST_SETTING"
       settingName = "TEST_SETTING"
       updateDate = "2019/04/10 12:44:17.641"
       updateUser = "hinemos"
       validFlg = True
     }

    http://127.0.0.1:8080/HinemosWS/, getNodeConfigSettingInfo succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.common import ResultPrinter, DateConvert


def main():
    psr = MyOptionParser()

    psr.add_option('-I', '--settingId', action='store', type='string', metavar='STRING', dest='setting_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Node Configuration Setting ID')

    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)
        result = endpoint.getNodeConfigSettingInfo(opts.setting_id)

        if result is not None:
            if 'regDate' in result:
                result.regDate = DateConvert.get_datetime_from_epochtime(result.regDate)
            if 'updateDate' in result:
                result.updateDate = DateConvert.get_datetime_from_epochtime(result.updateDate)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getNodeConfigSettingInfo')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
