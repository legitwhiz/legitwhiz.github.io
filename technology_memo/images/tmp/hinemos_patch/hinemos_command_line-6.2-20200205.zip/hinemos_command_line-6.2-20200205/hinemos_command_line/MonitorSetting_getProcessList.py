#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
プロセス監視設定一覧を取得する

<概要>
プロセス監視設定一覧を取得して表示します。

<使用例>
[command]
    $ python MonitorSetting_getProcessList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    [(monitorInfo){
       ownerRoleId = "ALL_USERS"
       application = "process01"
       collectorFlg = False
       delayTime = 0
       facilityId = "TEST_NODE"
       failurePriority = 1
       itemName = "プロセス数"
       measure = "個"
       monitorFlg = True
       monitorId = "PROCESS01"
       monitorType = 1
       monitorTypeId = "MON_PRC_N"
       notifyGroupId = "MON_PRC_N-PROCESS01-0"
       numericValueInfo[] =
          (monitorNumericValueInfo){
             monitorId = "PROCESS01"
             priority = 3
             thresholdLowerLimit = 1.0
             thresholdUpperLimit = 99.0
          },
          (monitorNumericValueInfo){
             monitorId = "PROCESS01"
             priority = 2
             thresholdLowerLimit = 99.0
             thresholdUpperLimit = 99.0
          },
          (monitorNumericValueInfo){
             monitorId = "PROCESS01"
             priority = 0
             thresholdLowerLimit = 0.0
             thresholdUpperLimit = 0.0
          },
          (monitorNumericValueInfo){
             monitorId = "PROCESS01"
             priority = 1
             thresholdLowerLimit = 0.0
             thresholdUpperLimit = 0.0
          },
       processCheckInfo =
          (processCheckInfo){
             monitorId = "PROCESS01"
             caseSensitivityFlg = False
             command = "java"
             param = ".*"
          }
       regDate = "2017/03/07 20:28:25.408"
       regUser = "hinemos"
       runInterval = 300
       scope = "TEST_NODE"
       triggerType = "NONE"
       updateDate = "2017/03/07 20:28:25.408"
       updateUser = "hinemos"
     }]
    http://192.168.1.2:8080/HinemosWS/, getProcessList succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint

def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getProcessList()
        if result is not None:
            for i in range(len(result)):
                result[i].regDate = DateConvert.get_datetime_from_epochtime(result[i].regDate)
                result[i].updateDate = DateConvert.get_datetime_from_epochtime(result[i].updateDate)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getProcessList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
