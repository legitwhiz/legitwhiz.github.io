#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数のフィルタ条件に対応する監視設定一覧情報を取得する

<概要>
引数のフィルタ条件に対応する監視設定一覧情報を取得します。

<使用例>
[command]
    $ python MonitorSetting_getMonitorBeanListByCondition.py

[result]

    http://192.168.1.2:8080/HinemosWS/, getMonitorBeanListByCondition succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import DateConvert, ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
from hinemos.api.monitorsetting import MonitorSettingEndpoint


def parse_args(args):
    psr = MyOptionParser()
    psr.add_option('-I', '--monitorId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='monitorId',
                   default=None,
                   help='monitor id')
    psr.add_option('--monitorTypeId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='monitorTypeId',
                   default=None,
                   help='monitor type id')
    psr.add_option('-F', '--facilityId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='facilityId',
                   default=None,
                   help='facility id')
    psr.add_option('-R', '--ownerRoleId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='ownerRoleId',
                   default=None,
                   help='owner role id')
    psr.add_option('-D', '--description',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='description',
                   default=None,
                   help='description')
    psr.add_option('-C', '--calendarId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='calendarId',
                   default=None,
                   help='calendar id')
    psr.add_option('-m', '--monitor',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='monitor_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='monitor: true/false')
    psr.add_option('-c', '--collect',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='collect_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='collect: true/false')
    psr.add_option('--regUser',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='regUser',
                   default=None,
                   help='register user')
    psr.add_option('--regFrom',
                   action='store',
                   type='string',
                   metavar='DATETIME',
                   converter=DateConvert.get_epochtime_from_datetime,
                   dest='regFrom_raw',
                   default=(None, {
                       'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$',
                                  'must be in datetime format']
                   }),
                   help='only show records after a specific date'
                   ' [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('--regTo',
                   action='store',
                   type='string',
                   metavar='DATETIME',
                   converter=DateConvert.get_epochtime_from_datetime,
                   dest='regTo_raw',
                   default=(None, {
                       'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$',
                                  'must be in datetime format']
                   }),
                   help='only show records before a specific date'
                   ' [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('--updateUser',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='updateUser',
                   default=None,
                   help='update user')
    psr.add_option('--updateFrom',
                   action='store',
                   type='string',
                   metavar='DATETIME',
                   converter=DateConvert.get_epochtime_from_datetime,
                   dest='updateFrom_raw',
                   default=(None, {
                       'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$',
                                  'must be in datetime format']
                   }),
                   help='only show records after a specific date'
                   ' [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('--updateTo',
                   action='store',
                   type='string',
                   metavar='DATETIME',
                   converter=DateConvert.get_epochtime_from_datetime,
                   dest='updateTo_raw',
                   default=(None, {
                       'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$',
                                  'must be in datetime format']
                   }),
                   help='only show records before a specific date'
                   ' [yyyy/mm/dd HH:MM:SS]')
    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    ### login ###
    endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)
    info = endpoint.create_monitor_filter_info(opts.calendarId,
                                               opts.collect,
                                               opts.description,
                                               opts.facilityId,
                                               opts.monitor,
                                               opts.monitorId,
                                               opts.monitorTypeId,
                                               opts.regFrom,
                                               opts.regTo,
                                               opts.regUser,
                                               opts.updateFrom,
                                               opts.updateTo,
                                               opts.updateUser,
                                               opts.ownerRoleId)

    try:
        result = endpoint.call('getMonitorBeanListByCondition', info)
        return_code = ResultPrinter.success(
            result, opts.mgr_url, 'getMonitorBeanListByCondition')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
