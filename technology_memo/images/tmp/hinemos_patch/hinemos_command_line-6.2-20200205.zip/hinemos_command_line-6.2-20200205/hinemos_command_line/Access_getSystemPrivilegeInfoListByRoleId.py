#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
指定されたロールIDを条件としてシステム権限一覧情報を取得する

<概要>
指定されたロールIDを条件としてシステム権限一覧情報を取得して表示します。

<使用例>
[command]
    $ python Access_getSystemPrivilegeInfoListByRoleId.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -R ALL_USERS

[result]
    [(systemPrivilegeInfo){
       editType = "1"
       systemFunction = "Hub"
       systemPrivilege = "ADD"
     }, (systemPrivilegeInfo){
       editType = "1"
       systemFunction = "Calendar"
       systemPrivilege = "ADD"
     }, (systemPrivilegeInfo){
       editType = "1"
       systemFunction = "CloudManagement"
       systemPrivilege = "READ"
     }, (systemPrivilegeInfo){
       editType = "1"
       systemFunction = "Infra"
       systemPrivilege = "EXEC"
     }, (systemPrivilegeInfo){
     ... 中略 ...
      editType = "1"
      systemFunction = "Repository"
      systemPrivilege = "EXEC"
    }, (systemPrivilegeInfo){
      editType = "1"
      systemFunction = "MonitorResult"
      systemPrivilege = "MODIFY"
    }, (systemPrivilegeInfo){
      editType = "1"
      systemFunction = "Repository"
      systemPrivilege = "READ"
    }]
    http://192.168.1.2:8080/HinemosWS/, getSystemPrivilegeInfoListByRoleId succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.access import AccessEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='ownerRoleID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = AccessEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = endpoint.getSystemPrivilegeInfoListByRoleId(opts.owner_role_id)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getSystemPrivilegeInfoListByRoleId')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
