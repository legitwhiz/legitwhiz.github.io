#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
パスワードを変更する

<概要>
引数で指定したユーザのパスワードを変更します。

<使用例>
[command]
    $ python Access_changePassword.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST01 -W TESTPASS

[result]
    http://192.168.1.2:8080/HinemosWS/, ChangePassword succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import PasswordConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser

import hinemos.api.exceptions as ErrorHandler
from hinemos.api.access import AccessEndpoint

def is_character_for_passwd(param_str):
    # asciiの半角英数記号（制御記号とブランク除く）かどうかを判別し、真偽値を返します。
    chr_int = int( param_str.encode('hex'), 16)
    if chr_int <= 126 and chr_int >= 33:
        return True
    return False

def is_str_for_passwd(str_rel):
    # asciiの半角英数記号（制御記号とブランク除く）のみの文字列かどうかを判別し、真偽値を返します。
    for i in range(0 , len(str_rel) ) :
        if not is_character_for_passwd(str_rel[i]):
            return False
    return True 

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--userID',  action='store', type='string', metavar='ID', dest='user_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='userID')
    psr.add_option('-W', '--changePasswd', action='store', type='string', metavar='STRING', dest='change_passwd',
                    default=(None, 'REQUIRED','NOTBLANK'), help='changePasswd')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    #change_passwd encode check
    if not is_str_for_passwd(opts.change_passwd) :
        ResultPrinter.failure('The parameter (--changePasswd or -W) is invalid. Contains unusable characters')
        return(return_code)

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = AccessEndpoint(opts.mgr_url, opts.user, opts.passwd)

        passwd_hash = PasswordConvert.slappasswd(opts.change_passwd)
        endpoint.changePassword(opts.user_id, passwd_hash)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'changePassword')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
