#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
外部から直接イベント通知処理を実行する

<概要>
外部から直接イベント通知処理を実行します。

<使用例>
[command]
    $ python Notify_notifyUserExtentionEvent.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -A TEST_APP
    -C UNCONFIRMED -F LINUX -G "2019/04/24 16:00:00" -I TEST_SYSLOG -P MON_SYSLOG_S -p INFO -S INTERNAL -D "Monitor Dtl"
    -R ALL_USERS --userItem01 "Test User Item"

[result]
    (eventDataInfo){
       application = "TEST_APP"
       collectGraphFlg = False
       comment = None
       commentUser = None
       confirmUser = None
       confirmed = 0
       facilityId = "LINUX"
       generationDate = 1556089200000
       monitorDetailId = "Monitor Dtl"
       monitorId = "TEST_SYSLOG"
       outputDate = 1556092369288
       ownerRoleId = "ALL_USERS"
       parentMonitorDetailId = "Monitor Dtl"
       pluginId = "MON_SYSLOG_S"
       position = 3859
       predictGenerationDate = 1556089200000
       priority = 3
       scopeText = "INTERNAL"
       userItem01 = "Test User Item"
     }

    http://127.0.0.1:8080/HinemosWS/, notifyUserExtentionEvent succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.notify import NotifyUtil


def main():

    psr = MyOptionParser()
    psr.add_option('-A', '--application', action='store', type='string', metavar='STRING', dest='application',
                   default=(None, 'REQUIRED'), help='application')
    psr.add_option('-C', '--confirmFlg', action='store', type='string', metavar='STRING', dest='confirm_flg_raw',
                   converter=NotifyUtil.convert2confirm_flg,
                   default=('UNCONFIRMED', {'INLIST':['UNCONFIRMED', 'CONFIRMED', 'CONFIRMING']}),
                   help='Confirm Flag= UNCONFIRMED, CONFIRMED, CONFIRMING(default: UNCONFIRMED)')
    psr.add_option('-F', '--facilityID', action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None, 'REQUIRED'), help='Facility ID')
    psr.add_option('-G', '--generationDate',  action='store', type='string', metavar='STRING',
                   converter=DateConvert.get_epochtime_from_datetime, dest='generation_date_raw',
                   default=(None, 'REQUIRED', {'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$',
                                                          ' must be in [yyyy/mm/dd HH:MM:SS] format']}),
                   help='Generation Date [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-M', '--message', action='store', type='string', metavar='STRING', dest='message',
                   default=None, help='Message')
    psr.add_option('-O', '--messageOrg', action='store', type='string', metavar='STRING', dest='message_org',
                   default=None, help='Original Message')
    psr.add_option('-D', '--monitorDetail', action='store', type='string', metavar='STRING', dest='monitor_detail',
                   default=(None, 'REQUIRED'), help='Monitor Details')
    psr.add_option('-I', '--monitorID', action='store', type='string', metavar='ID', dest='monitor_id',
                   default=(None, 'REQUIRED'), help='Monitor ID')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                   default=(None, 'REQUIRED'), help='Owner role ID')
    psr.add_option('-P', '--pluginID', action='store', type='string', metavar='ID', dest='plugin_id',
                   default=(None, 'REQUIRED'), help='pluginID')
    psr.add_option('-p', '--priority', action='store', type='string', metavar='STRING', dest='priority_raw',
                   converter=NotifyUtil.convert2priority,
                   default=(None, 'REQUIRED', {'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']}),
                   help='Priority = INFO or WARN or CRITICAL or UNKNOWN')
    psr.add_option('-S', '--scope', action='store', type='string', metavar='STRING', dest='scope_text',
                   default=(None, 'REQUIRED'), help='Scope')

    # User Item
    psr.add_option('--userItem01', action='store', type='string', metavar='STRING', dest='user_item_01',
                   default=None, help='User item01')

    psr.add_option('--userItem02', action='store', type='string', metavar='STRING', dest='user_item_02',
                   default=None, help='User item02')

    psr.add_option('--userItem03', action='store', type='string', metavar='STRING', dest='user_item_03',
                   default=None, help='User item03')

    psr.add_option('--userItem04', action='store', type='string', metavar='STRING', dest='user_item_04',
                   default=None, help='User item04')

    psr.add_option('--userItem05', action='store', type='string', metavar='STRING', dest='user_item_05',
                   default=None, help='User item05')

    psr.add_option('--userItem06', action='store', type='string', metavar='STRING', dest='user_item_06',
                   default=None, help='User item06')

    psr.add_option('--userItem07', action='store', type='string', metavar='STRING', dest='user_item_07',
                   default=None, help='User item07')

    psr.add_option('--userItem08', action='store', type='string', metavar='STRING', dest='user_item_08',
                   default=None, help='User item08')

    psr.add_option('--userItem09', action='store', type='string', metavar='STRING', dest='user_item_09',
                   default=None, help='User item09')

    psr.add_option('--userItem10', action='store', type='string', metavar='STRING', dest='user_item_10',
                   default=None, help='User item10')

    psr.add_option('--userItem11', action='store', type='string', metavar='STRING', dest='user_item_11',
                   default=None, help='User item11')

    psr.add_option('--userItem12', action='store', type='string', metavar='STRING', dest='user_item_12',
                   default=None, help='User item12')

    psr.add_option('--userItem13', action='store', type='string', metavar='STRING', dest='user_item_13',
                   default=None, help='User item13')

    psr.add_option('--userItem14', action='store', type='string', metavar='STRING', dest='user_item_14',
                   default=None, help='User item14')

    psr.add_option('--userItem15', action='store', type='string', metavar='STRING', dest='user_item_15',
                   default=None, help='User item15')

    psr.add_option('--userItem16', action='store', type='string', metavar='STRING', dest='user_item_16',
                   default=None, help='User item16')

    psr.add_option('--userItem17', action='store', type='string', metavar='STRING', dest='user_item_17',
                   default=None, help='User item17')

    psr.add_option('--userItem18', action='store', type='string', metavar='STRING', dest='user_item_18',
                   default=None, help='User item18')

    psr.add_option('--userItem19', action='store', type='string', metavar='STRING', dest='user_item_19',
                   default=None, help='User item19')

    psr.add_option('--userItem20', action='store', type='string', metavar='STRING', dest='user_item_20',
                   default=None, help='User item20')

    psr.add_option('--userItem21', action='store', type='string', metavar='STRING', dest='user_item_21',
                   default=None, help='User item21')

    psr.add_option('--userItem22', action='store', type='string', metavar='STRING', dest='user_item_22',
                   default=None, help='User item22')

    psr.add_option('--userItem23', action='store', type='string', metavar='STRING', dest='user_item_23',
                   default=None, help='User item23')

    psr.add_option('--userItem24', action='store', type='string', metavar='STRING', dest='user_item_24',
                   default=None, help='User item24')

    psr.add_option('--userItem25', action='store', type='string', metavar='STRING', dest='user_item_25',
                   default=None, help='User item25')

    psr.add_option('--userItem26', action='store', type='string', metavar='STRING', dest='user_item_26',
                   default=None, help='User item26')

    psr.add_option('--userItem27', action='store', type='string', metavar='STRING', dest='user_item_27',
                   default=None, help='User item27')

    psr.add_option('--userItem28', action='store', type='string', metavar='STRING', dest='user_item_28',
                   default=None, help='User item28')

    psr.add_option('--userItem29', action='store', type='string', metavar='STRING', dest='user_item_29',
                   default=None, help='User item29')

    psr.add_option('--userItem30', action='store', type='string', metavar='STRING', dest='user_item_30',
                   default=None, help='User item30')

    psr.add_option('--userItem31', action='store', type='string', metavar='STRING', dest='user_item_31',
                   default=None, help='User item31')

    psr.add_option('--userItem32', action='store', type='string', metavar='STRING', dest='user_item_32',
                   default=None, help='User item32')

    psr.add_option('--userItem33', action='store', type='string', metavar='STRING', dest='user_item_33',
                   default=None, help='User item33')

    psr.add_option('--userItem34', action='store', type='string', metavar='STRING', dest='user_item_34',
                   default=None, help='User item34')

    psr.add_option('--userItem35', action='store', type='string', metavar='STRING', dest='user_item_35',
                   default=None, help='User item35')

    psr.add_option('--userItem36', action='store', type='string', metavar='STRING', dest='user_item_36',
                   default=None, help='User item36')

    psr.add_option('--userItem37', action='store', type='string', metavar='STRING', dest='user_item_37',
                   default=None, help='User item37')

    psr.add_option('--userItem38', action='store', type='string', metavar='STRING', dest='user_item_38',
                   default=None, help='User item38')

    psr.add_option('--userItem39', action='store', type='string', metavar='STRING', dest='user_item_39',
                   default=None, help='User item39')

    psr.add_option('--userItem40', action='store', type='string', metavar='STRING', dest='user_item_40',
                   default=None, help='User item40')

    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        event_notify_info = endpoint.create_event_notify_info(
            opts.application, opts.confirm_flg, opts.facility_id, opts.generation_date, opts.message, opts.message_org,
            opts.monitor_detail, opts.monitor_id, opts.owner_role_id, opts.plugin_id, opts.priority, opts.scope_text,
            opts.user_item_01, opts.user_item_02, opts.user_item_03, opts.user_item_04, opts.user_item_05,
            opts.user_item_06, opts.user_item_07, opts.user_item_08, opts.user_item_09, opts.user_item_10,
            opts.user_item_11, opts.user_item_12, opts.user_item_13, opts.user_item_14, opts.user_item_15,
            opts.user_item_16, opts.user_item_17, opts.user_item_18, opts.user_item_19, opts.user_item_20,
            opts.user_item_21, opts.user_item_22, opts.user_item_23, opts.user_item_24, opts.user_item_25,
            opts.user_item_26, opts.user_item_27, opts.user_item_28, opts.user_item_29, opts.user_item_30,
            opts.user_item_31, opts.user_item_32, opts.user_item_33, opts.user_item_34, opts.user_item_35,
            opts.user_item_36, opts.user_item_37, opts.user_item_38, opts.user_item_39, opts.user_item_40)

        result = endpoint.notifyUserExtentionEvent(event_notify_info)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'notifyUserExtentionEvent')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
