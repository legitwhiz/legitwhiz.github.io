#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
参照ジョブの基本情報を登録する

<概要>
参照ジョブの基本情報を登録します。

<使用例>
- ジョブIDで参照ジョブを作成します。
[command]
    $ python Job_addJob_ReferJob.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001 -P JN001 -I JR001 -N ReferJob1 -R J001

[result]
    http://192.168.1.2:8080/HinemosWS/, addJob succeeded.

- モジュールIDで参照ジョブを作成します。
[command]
    $ python Job_addJob_ReferJob.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001 -P JU001 -I JR002 -N ReferJob2 -S JN001

[result]
    http://192.168.1.2:8080/HinemosWS/, addJob succeeded.
"""

import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-J', '--jobunitID',  action='store', type='string', metavar='ID', dest='jobunit_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Jobunit ID')
    psr.add_option('-P', '--parentID',  action='store', type='string', metavar='ID', dest='parent_id',
                   default=(None, 'NOTBLANK'), help='Parent job ID')
    psr.add_option('-I', '--jobID',  action='store', type='string', metavar='ID', dest='job_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Job ID')
    psr.add_option('-N', '--jobName', action='store', type='string', metavar='STRING', dest='name',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Job name')

    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='description')

    psr.add_option('--iconID',  action='store', type='string', metavar='ID', dest='iconID',
                   default=None, help='Icon ID')

    psr.add_option('-R', '--referJobID',  action='store', type='string', metavar='ID', dest='referJobID',
                    default=(None, 'NOTBLANK'), help='Refer job ID')
    psr.add_option('-S', '--referModuleID',  action='store', type='string', metavar='ID', dest='referModuleID',
                    default=(None,'NOTBLANK'), help='Refer module ID')
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Format argument
        refer_map = {'referJobUnitId':None, 'referJobId':None, 'referJobSelectType': 0}
        if opts.referModuleID is not None:
            refer_map['referJobSelectType'] = 1
            refer_map['referJobUnitId'] = opts.jobunit_id
            refer_map['referJobId'] = opts.referModuleID
        elif opts.referJobID is not None:
            refer_map['referJobSelectType'] = 0
            refer_map['referJobUnitId'] = opts.jobunit_id
            refer_map['referJobId'] = opts.referJobID
        else:
            raise ErrorHandler.ArgumentError('Either referModuleID or referJobID is required!')

        LOGGER.debug(refer_map)

        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, opts.jobunit_id)
        del job_tree_full

        # ユニットのロール確保
        owner_role_id = endpoint.getJobFull(job_tree.data).ownerRoleId

        # Check job type
        refer_info = JobUtil.get_job(endpoint, refer_map['referJobUnitId'], refer_map['referJobId'])
        LOGGER.debug(refer_info)
        if refer_info.type == JobUtil.convert2job_type('JOBNET'):
            job_type = JobUtil.convert2job_type('REFERJOBNET')
        else:
            job_type = JobUtil.convert2job_type('REFERJOB')

        new_job_tree = endpoint.create_job_tree_item_basic(\
                    job_type,\
                    opts.jobunit_id,\
                    opts.job_id,\
                    opts.name,\
                    opts.description,\
                    owner_role_id,\
                    None,\
                    opts.iconID)

        new_job_tree.data.referJobSelectType = refer_map['referJobSelectType']
        new_job_tree.data.referJobUnitId = refer_map['referJobUnitId']
        new_job_tree.data.referJobId = refer_map['referJobId']

        setattr(new_job_tree.data, 'waitRule', endpoint.create_wait_rule_info())
        LOGGER.debug(new_job_tree)

        parent_id = opts.parent_id
        if parent_id is None:
            parent_id = opts.jobunit_id
        added = JobUtil.add_child(job_tree, parent_id, new_job_tree)
        if not added:
            raise ErrorHandler.ArgumentError('Failed to add new job!')

        LOGGER.debug(job_tree)
        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addJob')
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
