#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
リポジトリの最終更新時刻を取得する

<概要>
リポジトリの最終更新時刻を取得して表示します。

<使用例>
[command]
    $ python Repository_getLastUpdate.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    2017/03/06 11:48:02.051
    http://192.168.1.2:8080/HinemosWS/, getLastUpdate succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.repository import RepositoryEndpoint

def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit###
        result = endpoint.getLastUpdate()
        if result is not None:
            result = DateConvert.get_datetime_from_epochtime(result)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getLastUpdate')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
