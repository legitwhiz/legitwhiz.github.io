#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
イベント通知を作成する

<概要>
イベント通知を作成します。

<使用例>
[command]
    $ python Notify_addNotify_Event.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I EVENT1 -c 1 -t 1 -l 1

[result]
    addNotify EVENT1...
    http://192.168.1.2:8080/HinemosWS/, addNotify_Event succeeded.
"""

### import ###
import sys
import codecs, locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.notify import NotifyEndpoint

def main():

    ### argument setting ###
    psr = MyOptionParser()
    psr.add_option('-I', '--notifyID',  action='store', type='string', metavar='ID', dest='notify_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='notifyID')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                   default='', help='description')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                   default=(None,'NOTBLANK'), help='ownerRoleID (default: ALL_USERS)')
    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                   default=(None,'NOTBLANK'), help='calendar ID')

    psr.add_option('-c', '--initialCount', action='store', type='int', metavar='INT', dest='initial_count',
                   default=(None, 'REQUIRED'), help='initialCount')
    psr.add_option('-F', '--notFirstNotify', action='store', type='string', metavar='STRING', dest='not_first_notify',
                   default=(None,{'INLIST':['true','false']}), help='notify after validated (default: false)')

    psr.add_option('-T', '--renotifyType', action='store', type='int', metavar='INT', dest='renotify_type',
                   default=(None, {'INLIST':[0,1,2]}), help='renotifyType Always = 0, Time Suppressing = 1, Don\'t notify = 2 (default: 0)')
    psr.add_option('-P', '--renotifyPeriod', action='store', type='int', metavar='INT', dest='renotify_period',
                   default=(None, {'WHEN':{'renotify_type':1}, 'DO':('REQUIRED')}), help='renotifyPeriod')

    psr.add_option('-i', '--infoFlg', action='store', type='int', metavar='INT', dest='info_flg',
                   default=(None, {'INLIST':[0,1]}), help='infoFlg : valid = 1, invalid = 0')
    psr.add_option('-a', '--warningFlg', action='store', type='int', metavar='INT', dest='warning_flg',
                   default=(None, {'INLIST':[0,1]}), help='warningFlg : valid = 1, invalid = 0')
    psr.add_option('-t', '--criticalFlg', action='store', type='int', metavar='INT', dest='critical_flg',
                   default=(None, {'INLIST':[0,1]}), help='criticalFlg : valid = 1, invalid = 0')
    psr.add_option('-u', '--unknownFlg', action='store', type='int', metavar='INT', dest='unknown_flg',
                   default=(None, {'INLIST':[0,1]}), help='unknownFlg : valid = 1, invalid = 0')
    psr.add_option('-o', '--eventNormalStateInfo', action='store', type='int', metavar='INT', dest='event_normal_state_info',
                   default=(None, {'INLIST':[0,1,2]}), help='eventNormalState_info Unconfirmed=0, Confirmed=1, Confirming=2')
    psr.add_option('-g', '--eventNormalStateWarning', action='store', type='int', metavar='INT', dest='event_normal_state_warning',
                   default=(None, {'INLIST':[0,1,2]}), help='eventNormalState_warning Unconfirmed=0, Confirmed=1, Confirming=2')
    psr.add_option('-l', '--eventNormalStateCritical', action='store', type='int', metavar='INT', dest='event_normal_state_critical',
                   default=(None, {'INLIST':[0,1,2]}), help='eventNormalState_critical Unconfirmed=0, Confirmed=1, Confirming=2')
    psr.add_option('-n', '--eventNormalStateUnknown', action='store', type='int', metavar='INT', dest='event_normal_state_unknown',
                   default=(None, {'INLIST':[0,1,2]}), help='eventNormalState_unknown Unconfirmed=0, Confirmed=1, Confirming=2')

    psr.add_option('-e', '--enable', action='store', type='string', metavar='STRING', dest='enable_raw',converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false (default: true)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ResultPrinter.info('addNotify %s...' % opts.notify_id)
        ### notifyInfo parameter ###
        endpoint.add_notify_event(\
            opts.notify_id,\
            opts.initial_count,\
            opts.description,\
            opts.owner_role_id,\
            opts.calendar_id,\
            SettingUtil.convert2nint(opts.not_first_notify),\
            opts.renotify_type,\
            opts.renotify_period,\
            opts.enable,\
            opts.info_flg,\
            opts.event_normal_state_info,\
            opts.warning_flg,\
            opts.event_normal_state_warning,\
            opts.critical_flg,\
            opts.event_normal_state_critical,\
            opts.unknown_flg,\
            opts.event_normal_state_unknown)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addNotify_Event')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
