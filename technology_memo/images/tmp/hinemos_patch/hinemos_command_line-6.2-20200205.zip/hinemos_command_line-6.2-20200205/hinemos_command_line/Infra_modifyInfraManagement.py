#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
環境構築設定を変更する

<概要>
環境構築設定を変更します。

<使用例>
[command]
    $ python Infra_modifyInfraManagement.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I AGENT_INSTALL_LINUX -e false

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyInfraManagement succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.infra import InfraEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.notify import NotifyUtil
from hinemos.util.modifier import ObjectModifier

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--managementID',  action='store', type='string', metavar='ID', dest='management_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='management ID')
    psr.add_option('-N', '--name', action='store', type='string', metavar='STRING', dest='name',
                   default=(None,'NOTBLANK'), help='name')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                   default=None, help='description')
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None,'NOTBLANK'), help='facility ID')
    psr.add_option('-S', '--startPriorityString', action='store', type='string', metavar='STRING', dest='start_priority_raw',converter=NotifyUtil.convert2priority,
                   default=(None, {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN','']}), help='startPriorityString = INFO or WARN or CRITICAL or UNKNOWN or \'\'(empty)')
    psr.add_option('-W', '--normalPriorityRun', action='store', type='string', metavar='STRING', dest='normal_priority_run_raw',converter=NotifyUtil.convert2priority,
                   default=(None,{'INLIST':['INFO','WARN','CRITICAL','UNKNOWN','']}), help='normalPriorityRun = INFO or WARN or CRITICAL or UNKNOWN or \'\'(empty)')
    psr.add_option('-X', '--abnormalPriorityRun', action='store', type='string', metavar='STRING', dest='abnormal_priority_run_raw',converter=NotifyUtil.convert2priority,
                   default=(None,{'INLIST':['INFO','WARN','CRITICAL','UNKNOWN','']}), help='abnormalPriorityRun = INFO or WARN or CRITICAL or UNKNOWN or \'\'(empty)')
    psr.add_option('-Y', '--normalPriorityCheck', action='store', type='string', metavar='STRING', dest='normal_priority_check_raw',converter=NotifyUtil.convert2priority,
                   default=(None,{'INLIST':['INFO','WARN','CRITICAL','UNKNOWN','']}), help='normalPriorityCheck = INFO or WARN or CRITICAL or UNKNOWN or \'\'(empty)')
    psr.add_option('-Z', '--abnormalPriorityCheck', action='store', type='string', metavar='STRING', dest='abnormal_priority_check_raw',converter=NotifyUtil.convert2priority,
                   default=(None,{'INLIST':['INFO','WARN','CRITICAL','UNKNOWN','']}), help='abnormalPriorityCheck = INFO or WARN or CRITICAL or UNKNOWN or \'\'(empty)')

    psr.add_option('-a', '--addNotifyIDs', action='store_split', type='string', metavar='STRING', dest='add_notify_ids_raw',
                    default=(None, 'NOTBLANK'), help='add notifications. addNotifyIDs = notifyID1,notifyID2,...,notifyIDN')
    psr.add_option('-d', '--deleteNotifyIDs', action='store_split', type='string', metavar='STRING', dest='del_notify_ids_raw',
                    default=(None, 'NOTBLANK'), help='delete notifications. deleteNotifyIDs = notifyID1,notifyID2,...,notifyIDN')

    psr.add_option('-e', '--enable', action='store', type='string', metavar='BOOL', dest='enable_raw',converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = InfraEndpoint(opts.mgr_url, opts.user, opts.passwd)

        infra_management_info = endpoint.getInfraManagement(opts.management_id)

        # Modification
        with ObjectModifier(infra_management_info) as modifier:
            modifier.set_if_first_not_none('name', opts.name)
            modifier.set_if_first_not_none('facilityId', opts.facility_id, scope = ' ')
            modifier.set_if_first_not_none('startPriority', opts.start_priority)
            modifier.set_if_first_not_none('description', opts.description)
            modifier.set_if_first_not_none('abnormalPriorityCheck', opts.abnormal_priority_run)
            modifier.set_if_first_not_none('abnormalPriorityRun', opts.abnormal_priority_check)
            modifier.set_if_first_not_none('normalPriorityCheck', opts.normal_priority_check)
            modifier.set_if_first_not_none('normalPriorityRun', opts.normal_priority_run)
            modifier.set_if_first_not_none('validFlg', opts.enable)

        # Notify
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)
        if opts.add_notify_ids is not None:
            if not hasattr(infra_management_info, 'notifyRelationList'):
                setattr(infra_management_info, 'notifyRelationList', [])

            # Check if notification already exists
            ids = set(opts.add_notify_ids)
            existed_ids = tuple([x.notifyId for x in infra_management_info.notifyRelationList])
            # Then add
            for x in filter((lambda x: x not in existed_ids), ids):
                infra_management_info.notifyRelationList.append(\
                    endpoint.create_notify_relation_info(notify_endpoint.getNotify(x),\
                        infra_management_info.managementId))

        if opts.del_notify_ids is not None and hasattr(infra_management_info, 'notifyRelationList') and 0 < len(infra_management_info.notifyRelationList):
            ids = set(opts.del_notify_ids)
            for i in reversed(xrange(len(infra_management_info.notifyRelationList))):
                if infra_management_info.notifyRelationList[i].notifyId in ids:
                    del infra_management_info.notifyRelationList[i]

        endpoint.modifyInfraManagement(infra_management_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyInfraManagement')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
