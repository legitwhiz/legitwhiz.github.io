#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ノードサーチ(SNMP)を利用して指定したIPアドレスの範囲のノードの情報を一括登録する

<概要>
ノードサーチ(SNMP)を利用して指定したIPアドレスの範囲のノードの情報を一括登録します。
また、登録したノードの情報を表示します。

<使用例>
[command]
    $ python Repository_searchNodesBySNMP.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -f 192.168.0.10 -t 192.168.0.254 -P 161 -C public -V 2c

[result]
    NODE web01(192.168.0.11) has been added.
    NODE web02(192.168.0.12) has been added.
    NODE web03(192.168.0.13) has been added.
    ... 中略 ...
    NODE db01(192.168.0.31) has been added.
    http://192.168.1.2:8080/HinemosWS/, searchNodesBySNMP succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.repository import RepositoryEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-f', '--ipAddressFrom', action='store', type='string', metavar='STRING', dest='ip_address_from',
                    default=(None, 'REQUIRED','NOTBLANK'), help='IP address from. (e.g. 192.168.1.2)')
    psr.add_option('-t', '--ipAddressTo', action='store', type='string', metavar='STRING', dest='ip_address_to',
                    default=(None, 'REQUIRED','NOTBLANK'), help='IP address to. (e.g. 192.168.1.254)')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=(None,'NOTBLANK'), help='ownerRoleID (default: ALL_USERS)')
    psr.add_option('-P', '--port', action='store', type='int', metavar='INT', dest='port',
                    default=None, help='SNMP port (default: 161)')
    psr.add_option('-C', '--community', action='store', type='string', metavar='STRING', dest='community',
                    default=(None,'NOTBLANK'), help='SNMP community (default: public)')
    psr.add_option('-V', '--snmpVersion', action='store', type='string', metavar='STRING', dest='version',
                    default=('2c',{'INLIST':['1','2c','3']}), help='SNMP version (default: 2c)')

    psr.add_option('--snmpSecurityLevel', action='store', type='string', metavar='STRING', dest='snmpSecurityLevel',
                    default=('noauth_nopriv', {'INLIST':['noauth_nopriv', 'auth_nopriv', 'auth_priv']}), help='security level: noauth_nopriv or auth_nopriv or auth_priv (SNMPv3 only)')
    psr.add_option('--snmpUser', action='store', type='string', metavar='STRING', dest='snmpUser',
                    default='', help='username (SNMPv3 only)')
    psr.add_option('--snmpAuthPasswd', action='store', type='string', metavar='STRING', dest='snmpAuthPasswd',
                    default='', help='auth pass (SNMPv3 only)')
    psr.add_option('--snmpPrivPasswd', action='store', type='string', metavar='STRING', dest='snmpPrivPasswd',
                    default='', help='priv pass (SNMPv3 only)')
    psr.add_option('--snmpAuthProtocol', action='store', type='string', metavar='STRING', dest='snmpAuthProtocol',
                    default=('MD5', {'INLIST':['MD5', 'SHA']}), help='auth protocol: MD5 or SHA (SNMPv3 only)')
    psr.add_option('--snmpPrivProtocol', action='store', type='string', metavar='STRING', dest='snmpPrivProtocol',
                    default=('DES', {'INLIST':['DES', 'AES']}), help='priv protocol: DES or AES (SNMPv3 only)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.searchNodesBySNMP(opts.owner_role_id, opts.ip_address_from, opts.ip_address_to, opts.port, opts.community, opts.version, None, opts.snmpSecurityLevel, opts.snmpUser, opts.snmpAuthPasswd, opts.snmpPrivPasswd, opts.snmpAuthProtocol, opts.snmpPrivProtocol)

        if result is not None:
            if 0 == len(result):
                print 'No node(s) found.'
            else:
                for node_info_device_search in result:
                    print 'NODE %s(%s) has been added.' % (node_info_device_search.nodeInfo.facilityId, node_info_device_search.nodeInfo.ipAddressV4)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'searchNodesBySNMP')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
