#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブのスケジュール実行契機情報を登録する

<概要>
ジョブのスケジュール実行契機情報を登録します。

<使用例>
- 毎日0時にジョブが実行されるスケジュール設定を登録します。
[command]
    $ python Job_addSchedule.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_SC -N TEST_SC -J JU001/JF001 -S "DAILY *:00" -e false -R ADMINISTRATORS

[result]
    http://192.168.1.2:8080/HinemosWS/, addSchedule succeeded.


- スケジュール設定を毎週に設定し、登録します。
[command]
    $ python Job_addSchedule.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_SC2 -N TEST_SC2 -J JU001/JF001 -S "WEEKLY Mon 09:00"

[result]
    http://192.168.1.2:8080/HinemosWS/, addSchedule succeeded.


- スケジュール設定を毎時に設定し、登録します。
[command]
    $ python Job_addSchedule.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_SC3 -N TEST_SC3 -J JU001/JOB1 -S "HOURLY 00/15"

[result]
    http://192.168.1.2:8080/HinemosWS/, addSchedule succeeded.
"""

import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.job import JobUtil

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-I', '--scheduleID',  action='store', type='string', metavar='ID', dest='schedule_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='schedule ID')

    psr.add_option('-N', '--name', action='store', type='string', metavar='STRING', dest='name',
                    default=(None, 'REQUIRED','NOTBLANK'), help='schedule name')

    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='cal_id',
                    default=None, help='calendarID')
    psr.add_option('-S', '--schedule', action='store', type='string', metavar='STRING', dest='schedule',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='schedule = "DAILY *:00", "DAILY 12:00", "WEEKLY Sun *:30", "WEEKLY Mon 23:59", "HOURLY 00/05", "HOURLY 00/60". Hour format : 0-48 or *; week format : Sun, Mon, Tue, Wed, Thu, Fri, Sat; HOURLY format : 0-29/[5,10,15,20,30]')

    psr.add_option('-e', '--enable', action='store', type='string', metavar='STRING', dest='enable_raw',converter=SettingUtil.convert2nint,
                    default=('true', {'INLIST':['true','false']}), help='enable=true, disable=false (default: true)')

    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='or_id',
                    default=('ALL_USERS', 'NOTBLANK'), help='ownerRoleID (default: ALL_USERS)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_map = JobUtil.convert2job(opts.job)
        LOGGER.debug(job_map)
        schedule_map = JobUtil.convert2schedule(opts.schedule)
        LOGGER.debug(schedule_map)

        info = JobUtil.set_schedule(
            endpoint.create_job_schedule(opts.schedule_id, opts.or_id),
            opts.name,
            job_map,
            schedule_map,
            opts.cal_id,
            opts.enable,
            None) # Only available in Job_modifySchedule
        LOGGER.debug(info)
        endpoint.addSchedule(info)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addSchedule')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
