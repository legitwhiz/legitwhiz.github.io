#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
システム権限一覧情報を取得する

<概要>
システム権限一覧情報を取得して表示します。

<使用例>
[command]
    $ python Access_getSystemPrivilegeInfoList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    [(systemPrivilegeInfo){
       editType = "1"
       systemFunction = "AccessControl"
       systemPrivilege = "ADD"
     }, (systemPrivilegeInfo){
       editType = "1"
       systemFunction = "AccessControl"
       systemPrivilege = "MODIFY"
     }, (systemPrivilegeInfo){
       editType = "1"
       systemFunction = "AccessControl"
       systemPrivilege = "READ"
     }, (systemPrivilegeInfo){
       editType = "1"
       systemFunction = "Calendar"
       systemPrivilege = "ADD"
       ... 中略 ...
    }, (systemPrivilegeInfo){
      editType = "1"
      systemFunction = "Repository"
      systemPrivilege = "EXEC"
    }, (systemPrivilegeInfo){
      editType = "1"
      systemFunction = "Repository"
      systemPrivilege = "MODIFY"
    }, (systemPrivilegeInfo){
      editType = "1"
      systemFunction = "Repository"
      systemPrivilege = "READ"
    }]
    http://192.168.1.2:8080/HinemosWS/, getSystemPrivilegeInfoList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.access import AccessEndpoint

def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = AccessEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = endpoint.getSystemPrivilegeInfoList()
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getSystemPrivilegeInfoList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
