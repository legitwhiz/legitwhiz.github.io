#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したIDに対応カレンダパターン情報を取得する

<概要>
引数で指定したIDに対応カレンダパターン情報を取得して表示します。

<使用例>
[command]
    $ python Calendar_getCalendarPattern.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -C TEST_CP

[result]
    (calendarPatternInfo){
       ownerRoleId = "ALL_USERS"
       calPatternId = "TEST_CP"
       calPatternName = "TEST_CP"
       regDate = "2017/03/03 14:35:15.143"
       regUser = "hinemos"
       updateDate = "2017/03/03 14:35:15.143"
       updateUser = "hinemos"
       ymd[] =
          (ymd){
             calPatternId = "TEST_CP"
             day = 20
             month = 3
             year = 2017
          },
     }
    http://192.168.1.2:8080/HinemosWS/, getCalendarPattern succeeded.
"""
import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.calendar import CalendarEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-C', '--calendarPatternID',  action='store', type='string', metavar='ID', dest='calendar_pattern_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='calendarPatternID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = CalendarEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.get_calendar_pattern_formatted(opts.calendar_pattern_id)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getCalendarPattern')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
