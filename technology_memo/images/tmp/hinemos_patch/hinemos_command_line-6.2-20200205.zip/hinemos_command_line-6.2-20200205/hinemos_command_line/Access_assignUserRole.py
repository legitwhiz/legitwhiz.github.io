#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ロールに対するユーザの所属、及び所属解除を行う

<概要>
ロールに対するユーザの所属、及び所属解除を行います。

<使用例>
ロールROLE01にユーザUSER01を所属させる場合
[command]
    $ python Access_assignUserRole.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -R ROLE01 -I USER01

[result]
    http://192.168.1.2:8080/HinemosWS/, assignUserRole succeeded.

ロールROLE01にユーザUSER01、USER02を所属させる場合
[command]
    $ python Access_assignUserRole.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -R ROLE01 -I "USER01,USER02"

[result]
    http://192.168.1.2:8080/HinemosWS/, assignUserRole succeeded.

ロールROLE01から全ユーザの所属解除を行う場合
[command]
    $ python Access_assignUserRole.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -R ROLE01 -I ""

[result]
    http://192.168.1.2:8080/HinemosWS/, assignUserRole succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser

import hinemos.api.exceptions as ErrorHandler
from hinemos.util.common import ResultPrinter
from hinemos.api.access import AccessEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='ownerRoleID')
    psr.add_option('-I', '--userIDs', action='store', type='string', metavar='STRING', dest='user_ids',
                    default=(None, 'REQUIRED'), help='userID1,userID2,...')

    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        endpoint = AccessEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        if not opts.user_ids:
            user_ids = []
        else:
            user_ids = opts.user_ids.split(',')
        endpoint.assignUserRole(opts.owner_role_id, user_ids)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'assignUserRole')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
