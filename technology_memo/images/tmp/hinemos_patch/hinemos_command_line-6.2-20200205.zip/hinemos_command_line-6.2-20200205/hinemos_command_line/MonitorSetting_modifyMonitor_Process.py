#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
プロセス監視の監視設定情報を変更する

<概要>
プロセス監視の監視設定情報を変更します。

<使用例>
[command]
    $ python MonitorSetting_modifyMonitor_Process.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I PROC1 -A MYAPP -F SCOPE001 -X postgres

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.modifier import ObjectModifier
from hinemos.util.notify import NotifyUtil
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_modify_args_parser(help_default_info)

    psr.add_option('-X', '--checkCommand', action='store', type='string',
                   metavar='STRING', dest='check_command',
                   default=(None, 'NOTBLANK'), help='command')
    psr.add_option('-G', '--checkArgument', action='store', type='string',
                   metavar='STRING', dest='check_argument',
                   default=None, help='argument (RegEx e.g. ".*")')
    psr.add_option('-S', '--checkCaseSensitive', action='store', type='string',
                   metavar='BOOL', dest='check_case_sensitive_raw',
                   converter=SettingUtil.convert2nbool,
                   default=None, help='checkCaseSensitive')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # login
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Get monitorInfo
        monitor_info = endpoint.getMonitor(opts.monitor_id)

        # Modification
        with ObjectModifier(monitor_info) as modifier:
            endpoint.update_common_infos(modifier, vars(opts))
            endpoint.update_collect_infos(modifier, vars(opts))
            endpoint.update_prediction_info(modifier, vars(opts))
            endpoint.update_change_info(modifier, vars(opts))
            endpoint.updete_judgement_tresholds(modifier, vars(opts))

            modifier.change_ptr('processCheckInfo')
            modifier.set_if_first_not_none(
                'caseSensitivityFlg', opts.check_case_sensitive)
            modifier.set_if_first_not_none('command', opts.check_command)
            modifier.set_if_first_not_none('param', opts.check_argument)

        endpoint.update_notify_ids_info(monitor_info, vars(opts))

        endpoint.modifyMonitor(monitor_info)
        return_code = ResultPrinter.success(
            None, opts.mgr_url, 'modifyMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
