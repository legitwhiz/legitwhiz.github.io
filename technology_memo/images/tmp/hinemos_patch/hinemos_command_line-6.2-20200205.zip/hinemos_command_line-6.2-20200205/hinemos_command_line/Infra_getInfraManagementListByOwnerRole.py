#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定されたオーナーロールIDを条件として環境構築設定一覧を取得する

<概要>
引数で指定されたオーナーロールIDを条件として環境構築設定一覧を取得して表示します。

<使用例>
[command]
    $ python Infra_getInfraManagementListByOwnerRole.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -R ALL_USERS

[result]
    [(infraManagementInfo){
       ownerRoleId = "ALL_USERS"
       abnormalPriorityCheck = 0
       abnormalPriorityRun = 0
       facilityId = "NODE001"
       managementId = "AGENT_INSTALL_LINUX"
       moduleList[] =
          (fileTransferModuleInfo){
             managementId = "AGENT_INSTALL_LINUX"
             moduleId = "RPM_TRANSFER"
             name = "transfer rpm file"
             orderNo = 0
             precheckFlg = True
             stopIfFailFlg = True
             validFlg = True
             backupIfExistFlg = False
             destAttribute = "644"
             destOwner = "root"
             destPath = "/root/"
             fileId = "HINEMOS_AGENT_LINUX"
             sendMethodType = 0
          },
          (commandModuleInfo){
             managementId = "AGENT_INSTALL_LINUX"
             moduleId = "INSTALL"
             name = "install"
             orderNo = 1
             precheckFlg = True
             stopIfFailFlg = True
             validFlg = True
             accessMethodType = 0
             checkCommand = "rpm -q hinemos-6.0-agent"
             execCommand = "HINEMOS_MANAGER=192.168.0.1 rpm -ivh #[FILE:HINEMOS_AGENT_LINUX]"
          },
          (commandModuleInfo){
             managementId = "AGENT_INSTALL_LINUX"
             moduleId = "START"
             name = "start"
             orderNo = 2
             precheckFlg = True
             stopIfFailFlg = False
             validFlg = True
             accessMethodType = 0
             checkCommand = "service hinemos_agent status"
             execCommand = "service hinemos_agent start"
          },
       name = "Hinemos Agent (Linux) install"
       normalPriorityCheck = 3
       normalPriorityRun = 3
       notifyGroupId = "INFRA_AGENT_INSTALL_LINUX"
       regDate = "2017/02/10 22:17:02.683"
       regUser = "hinemos"
       scope = "NODE001"
       startPriority = 3
       updateDate = "2017/03/06 18:32:39.610"
       updateUser = "hinemos"
       validFlg = True
     }]
    http://192.168.1.2:8080/HinemosWS/, getInfraManagementList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.infra import InfraEndpoint
from hinemos.api.helper.infra import list_formatter

def main():

    psr = MyOptionParser()
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=('ALL_USERS', 'NOTBLANK'), help='ownerRoleID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = InfraEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = endpoint.getInfraManagementListByOwnerRole(opts.owner_role_id)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getInfraManagementListByOwnerRole', list_formatter)
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
