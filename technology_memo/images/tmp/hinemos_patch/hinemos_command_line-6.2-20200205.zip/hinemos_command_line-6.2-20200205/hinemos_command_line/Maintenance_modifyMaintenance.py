#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したメンテナンス情報を変更する

<概要>
引数で指定したメンテナンス情報を変更します。

<使用例>
[command]
    $ python Maintenance_modifyMaintenance.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_MA -S "05/27 09:00"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyMaintenance succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
from hinemos.api.maintenance import MaintenanceEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.maintenance import MaintenanceSettingUtil
from hinemos.util.modifier import ObjectModifier

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--maintenanceID',  action='store', type='string', metavar='ID', dest='maintenance_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='maintenance_id')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='description')
    psr.add_option('-T', '--typeID',  action='store', type='string', metavar='ID', dest='type_id',
                    default=(None,{'INLIST':MaintenanceSettingUtil._type_}), help='typeID = ' + ' or '.join(MaintenanceSettingUtil._type_))
    psr.add_option('-E', '--dataRetentionPeriod', action='store', type='int', metavar='INT', dest='data_retention_period',
                    default=None, help='data retention period [day]')
    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                    default=None, help='calendarID')
    psr.add_option('-S', '--schedule', action='store', type='string', metavar='STRING', dest='schedule',
                    default=(None, 'NOTBLANK'), help='format : "[[mm/]DD or WEEKDAY] HH:MM" e.g. "12:00", "02 23:59", "12/01 00:00", "Sun 02:12". WEEKDAY = Sun, Mon, Tue, Wed, Thu, Fri, Sat')

    psr.add_option('-a', '--addNotifyIDs', action='store_split', type='string', metavar='STRING', dest='add_notify_ids_raw',
                    default=None, help='add notifications. addNotifyIDs = notifyID1,notifyID2,...,notifyIDN')
    psr.add_option('-d', '--deleteNotifyIDs', action='store_split', type='string', metavar='STRING', dest='del_notify_ids_raw',
                    default=None, help='delete notifications. deleteNotifyIDs = notifyID1,notifyID2,...,notifyIDN')

    psr.add_option('-A', '--application', action='store', type='string', metavar='STRING', dest='application',
                    default=(None, 'NOTBLANK'), help='application')
    psr.add_option('-e', '--enable', action='store', type='string', metavar='STRING', dest='enable_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MaintenanceEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Get maintenanceInfo
        maintenance_info = endpoint.getMaintenanceInfo(opts.maintenance_id)

        # Modification
        with ObjectModifier(maintenance_info) as modifier:
            if opts.schedule is not None:
                scheduleObj = endpoint.create_schedule_from_str(opts.schedule)
            else:
                scheduleObj = None
            modifier.set_if_first_not_none('typeId', opts.type_id)
            modifier.set_if_first_not_none('dataRetentionPeriod', opts.data_retention_period)
            modifier.set_if_first_not_none('application', opts.application)
            modifier.set_if_first_not_none('schedule', scheduleObj)
            modifier.set_if_first_not_none('calendarId', opts.calendar_id)
            modifier.set_if_first_not_none('description', opts.description)
            modifier.set_if_first_not_none('validFlg', opts.enable)

        # Notify
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)
        if opts.add_notify_ids is not None:
            if not hasattr(maintenance_info, 'notifyId'):
                setattr(maintenance_info, 'notifyId', [])

            # Check if notification already exists
            ids = set(opts.add_notify_ids)
            existed_ids = tuple([x.notifyId for x in maintenance_info.notifyId])

            # Then add
            for x in filter((lambda x: x not in existed_ids), ids):
                maintenance_info.notifyId.append(\
                    endpoint.create_notify_relation_info(notify_endpoint.getNotify(x), maintenance_info.maintenanceId))

        if opts.del_notify_ids is not None and hasattr(maintenance_info, 'notifyId') and 0 < len(maintenance_info.notifyId):
            ids = set(opts.del_notify_ids)
            for i in reversed(xrange(len(maintenance_info.notifyId))):
                if maintenance_info.notifyId[i].notifyId in ids:
                    del maintenance_info.notifyId[i]

        endpoint.modifyMaintenance(maintenance_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyMaintenance')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
