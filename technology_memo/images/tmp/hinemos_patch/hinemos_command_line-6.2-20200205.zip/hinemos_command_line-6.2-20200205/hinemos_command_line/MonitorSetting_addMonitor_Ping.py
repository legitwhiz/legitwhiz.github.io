#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
PING監視の監視設定を登録する

<概要>
PING監視の監視設定を登録します。

<使用例>
[command]
    $ python MonitorSetting_addMonitor_Ping.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I PING1 -A MYAPP -F SCOPE001

[result]
    http://192.168.1.2:8080/HinemosWS/, addMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_add_args_parser(
            help_default_info,
        exclude=[
            'infoLowerThreshold',
            'infoUpperThreshold',
            'warnLowerThreshold',
            'warnUpperThreshold'
        ])

    psr.add_option('-t', '--checkRunCount', action='store', type='int',
                   metavar='INT', dest='check_run_count',
                   default=(None, {'RANGE': [1, 9]}),
                   help='run count = 1 to 9 (default: 1)')
    psr.add_option('-r', '--checkRunInterval', action='store', type='int',
                   metavar='INT', dest='check_run_interval',
                   default=(None, {'RANGE': [0, 5000]}),
                   help='run interval = 0 to 5000 [msec] (default: 1000[msec])')
    psr.add_option('-O', '--checkTimeout', action='store', type='int',
                   metavar='INT', dest='check_timeout', default=None,
                   help='timeout [msec] (default: 5000[msec])')

    psr.add_option('-L', '--infoResponseThreshold', action='store',
                   type='float', metavar='NUMERIC',
                   dest='info_lower_threshold', default=None,
                   help='response time [msec] threshold of INFO'
                   ' (default: 1000[msec])')
    psr.add_option('-P', '--infoPacketLossThreshold', action='store',
                   type='float', metavar='NUMERIC',
                   dest='info_upper_threshold', default=None,
                   help='packet loss [%] threshold of INFO (default: 1[%])')
    psr.add_option('-l', '--warnResponseThreshold', action='store',
                   type='float', metavar='NUMERIC',
                   dest='warn_lower_threshold', default=None,
                   help='response time [msec] threshold of WARN'
                   ' (default: 3000[msec])')
    psr.add_option('-p', '--warnPacketLossThreshold', action='store',
                   type='float', metavar='NUMERIC',
                   dest='warn_upper_threshold', default=None,
                   help='packet loss [%] threshold of WARN (default: 51[%])')
    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)
        endpoint.add_monitor_ping(vars(opts))

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
