#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ロール情報を変更する

<概要>
ロール情報を変更します。

<使用例>
[command]
    $ python Access_modifyRoleInfo.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -R TEST01 -N TEST02

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyRoleInfo succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.access import AccessEndpoint
from hinemos.util.common import ResultPrinter

def main():

    psr = MyOptionParser()
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='ownerRoleID')
    psr.add_option('-N', '--rolename', action='store', type='string', metavar='STRING', dest='name',
                    default=None, help='name')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='description')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = AccessEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        ### roleInfo parameter ###
        role_info = endpoint.getRoleInfo(opts.owner_role_id)
        if role_info is None:
            raise ErrorHandler.ArgumentError('modifyUserInfo failed, ' + 'owner role ' + opts.owner_role_id + ' does not exist')
        if opts.name is not None:
            role_info.roleName = opts.name
        if opts.description is not None:
            role_info.description = opts.description

        endpoint.modifyRoleInfo(role_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyRoleInfo')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.ArgumentError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
