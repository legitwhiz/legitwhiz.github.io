#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブのマニュアル実行契機情報を変更する

<概要>
ジョブのマニュアル実行契機情報を変更します。

<使用例>
- 対象ジョブを変更します。
[command]
    $ python Job_modifyJobManual.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I JMN001 -J JU001/J002 -N updated

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJobManual succeeded.

- 「入力」ランタイムジョブ変数を追加します。
[command]
    $ python Job_modifyJobManual.py -I JMN001 --paramAction ADD --paramName input1 --paramType INPUT --paramRequired true --paramDesc "Input"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJobManual succeeded.

- 「選択(ラジオボタン)」ランタイムジョブ変数を追加します。
[command]
    $ python Job_modifyJobManual.py -I JMN001 --paramAction ADD --paramName radio1 --paramType RADIO --paramDesc "Choose one" --paramChoiceValues "A,B,C,D" --paramChoiceDescs "a,b,c,d" --paramDefaultValue B

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJobManual succeeded.

- 「選択(コンボボックス)」ランタイムジョブ変数を追加します。
[command]
    $ python Job_modifyJobManual.py -I JMN001 --paramAction ADD --paramName combo1 --paramType COMBO --paramRequired false --paramDesc "Choose" --paramChoiceValues "A,B,C,D" --paramChoiceDescs "a,b,c,d" --paramDefaultValue B

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJobManual succeeded.

- 「固定値」ランタイムジョブ変数を追加します。
[command]
    $ python Job_modifyJobManual.py -I JMN001 --paramAction ADD --paramName fixed1 --paramType FIXED --paramDesc "Fixed" --paramDefaultValue "Default value"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJobManual succeeded.


- ランタイムジョブ変数のデフォルト値と説明を変更します。
[command]
    $ python Job_modifyJobManual.py -I JMN001 --paramAction MOD --paramName input1 --paramDefaultValue B --paramDesc "Updated"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJobManual succeeded.

- ランタイムジョブ変数を削除します。
[command]
    $ python Job_modifyJobManual.py -I JMN001 --paramAction DEL --paramName input1

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJobManual succeeded.
"""

import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.job import JobUtil
from hinemos.util.modifier import ObjectModifier

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-I', '--jobKickID',  action='store', type='string', metavar='ID', dest='jobkick_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='Job kick ID')

    psr.add_option('-N', '--name', action='store', type='string', metavar='STRING', dest='name',
                    default=(None,'NOTBLANK'), help='Job kick name')

    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None,'NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    psr.add_option('--paramAction', action='store', type='string', metavar='MODE', dest='action',
                    default=(None, {'INLIST':['ADD','MOD','DEL']}), help='paramAction = ADD or MOD or DEL')
    psr.add_option('--paramName', action='store', type='string', metavar='STRING', dest='paramName',
                    default=(None, 'NOTBLANK', {'WHEN':[{'action':'ADD'},{'action':'MOD'},{'action':'DEL'}], 'DO':('REQUIRED')}), help='paramName')
    psr.add_option('--paramType', action='store', type='string', metavar='STRING', dest='paramType',
                    default=(None, {'INLIST':JobUtil._rt_param_type_}, {'WHEN':{'action':'ADD'}, 'DO':('REQUIRED','NOTBLANK')}), help='paramType = '+' or '.join(JobUtil._rt_param_type_))
    psr.add_option('--paramRequired', action='store', type='string', metavar='BOOL', dest='paramRequired_raw', converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='paramRequired')
    psr.add_option('--paramDesc', action='store', type='string', metavar='STRING', dest='paramDesc',
                    default=None, help='Parameter description')
    psr.add_option('--paramDefaultValue', action='store', type='string', metavar='STRING', dest='paramDefaultValue',
                    default=None, help='paramDefaultValue')
    psr.add_option('--paramChoiceValues', action='store_split', type='string', metavar='STRING', dest='paramChoiceValues_raw',
                    default=None, help='paramChoiceValues = value1,value2,value3')
    psr.add_option('--paramChoiceDescs', action='store_split', type='string', metavar='STRING', dest='paramChoiceDescs_raw',
                    default=None, help='paramChoiceDescs = desc1,desc2,desc3')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Get info
        info_old = endpoint.getJobManual(opts.jobkick_id)
        LOGGER.debug(info_old)

        job_map = JobUtil.convert2job(opts.job)
        LOGGER.debug(job_map)

        if opts.action == 'ADD':
            detail_list = []
            if opts.paramChoiceValues is not None:
                # Format paramChoiceDescs according to paramChoiceValues
                if opts.paramChoiceDescs is None:
                    opts.paramChoiceDescs = [''] * len(opts.paramChoiceValues)
                elif len(opts.paramChoiceDescs) < len(opts.paramChoiceValues):
                    opts.paramChoiceDescs += [''] * (len(opts.paramChoiceValues) - len(opts.paramChoiceDescs))
                for i,val in enumerate(opts.paramChoiceValues):
                    detail_list.append(endpoint.create_job_runtime_param_detail(opts.paramChoiceDescs[i], val))
            LOGGER.debug(detail_list)

            param_info = endpoint.create_job_runtime_param(
                opts.paramName,
                JobUtil.convert2param_type(opts.paramType),
                opts.paramDesc,
                opts.paramRequired,
                opts.paramDefaultValue,
                detail_list)
            LOGGER.debug(param_info)

            # Append a new job runtime parameter
            if 'jobRuntimeParamList' not in info_old:
                setattr(info_old, 'jobRuntimeParamList', [param_info])
            else:
                info_old.jobRuntimeParamList.append(param_info)
        elif opts.action == 'MOD':
            detail_list = None
            if opts.paramChoiceValues is not None:
                detail_list = []
                # Format paramChoiceDescs according to paramChoiceValues
                if opts.paramChoiceDescs is None:
                    opts.paramChoiceDescs = [''] * len(opts.paramChoiceValues)
                elif len(opts.paramChoiceDescs) < len(opts.paramChoiceValues):
                    opts.paramChoiceDescs += [''] * (len(opts.paramChoiceValues) - len(opts.paramChoiceDescs))
                for i,val in enumerate(opts.paramChoiceValues):
                    detail_list.append(endpoint.create_job_runtime_param_detail(opts.paramChoiceDescs[i], val))
            # If paramType is INPUT or FIXED, clear the detail_list.
            if opts.paramType in [JobUtil._rt_param_type_[0], JobUtil._rt_param_type_[3]]:
                detail_list = []
            LOGGER.debug(detail_list)

            # Find the param
            param_info = None
            if 'jobRuntimeParamList' in info_old:
                for a in info_old.jobRuntimeParamList:
                    if a.paramId == opts.paramName:
                        param_info = a
                        break
            if param_info is None:
                LOGGER.debug(param_info)
                raise ErrorHandler.ArgumentError('Parameter "%s" not found!' % opts.paramName)

            # Modify a parameter
            ObjectModifier.replace_if_not_none(
                param_info,
                paramType = JobUtil.convert2param_type(opts.paramType),
                description = opts.paramDesc,
                value = opts.paramDefaultValue,
                requiredFlg = opts.paramRequired,
                jobRuntimeParamDetailList = detail_list)

            # If paramType is COMOBO and default_value is not in list, clear the default_value.
            if param_info.paramType == JobUtil._rt_param_type_.index('COMBO') and opts.paramDefaultValue is None and opts.paramChoiceValues is not None and hasattr(param_info, 'value'):
            
                match = None
                for param_detail in param_info.jobRuntimeParamDetailList:
                    if param_info.value == param_detail.paramValue:
                        match = param_detail.paramValue
                        break
                if match is None:
                    param_info.value = None
        elif opts.action == 'DEL':
            # Find the param
            param_info = None
            if 'jobRuntimeParamList' in info_old:
                for a in info_old.jobRuntimeParamList:
                    if a.paramId == opts.paramName:
                        param_info = a
                        info_old.jobRuntimeParamList.remove(a)
                        break
            if param_info is None:
                LOGGER.debug(param_info)
                raise ErrorHandler.ArgumentError('Parameter "%s" not found!' % opts.paramName)

        info = JobUtil.set_job_kick(
            info_old,
            opts.name,
            job_map,
            None) # parameters are already managed above
        LOGGER.debug(info)

        endpoint.modifyJobManual(info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJobManual')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
