#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
オーナーロールIDを条件としてカレンダ一覧を取得する

<概要>
オーナーロールIDを条件としてカレンダ一覧を取得して一覧表示します。

<使用例>
[command]
    $ python Calendar_getCalendarList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -R ALL_USERS

[result]
    [(calendarInfo){
       ownerRoleId = "ALL_USERS"
       calendarId = "TEST_CAL01"
       calendarName = "TEST_CAL01"
       description = None
       regDate = "2017/03/03 13:46:51.726"
       regUser = "hinemos"
       updateDate = "2017/03/03 13:46:51.726"
       updateUser = "hinemos"
       validTimeFrom = "2015/01/01 00:00:00"
       validTimeTo = "2015/12/31 00:00:00"
     }, (calendarInfo){
       ownerRoleId = "ALL_USERS"
       calendarId = "TEST_CAL02"
       calendarName = "TEST_CAL02"
       description = None
       regDate = "2017/03/03 14:16:09.544"
       regUser = "hinemos"
       updateDate = "2017/03/03 14:24:03.662"
       updateUser = "hinemos"
       validTimeFrom = "2017/03/01 00:00:00"
       validTimeTo = "2017/03/31 23:59:59"
     }]
    http://192.168.1.2:8080/HinemosWS/, getCalendarList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.calendar import CalendarEndpoint
from hinemos.api.helper.calendar import list_formatter

def main():

    psr = MyOptionParser()
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default='', help='ownerRoleID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = CalendarEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = endpoint.getCalendarList(opts.owner_role_id)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getCalendarList', list_formatter)
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
