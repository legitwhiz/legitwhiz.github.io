#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
構成情報取得設定を削除する

<概要>
構成情報取得設定を削除します。

<使用例>
[command]
    $ python Repository_deleteNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING1,TEST_SETTING2

[result]
    http://127.0.0.1:8080/HinemosWS/, deleteNodeConfigSettingInfo succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.common import ResultPrinter


def main():
    psr = MyOptionParser()

    psr.add_option('-I', '--settingIds', action='store', type='string', metavar='STRING', dest='setting_ids',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='Node Configuration Setting IDs. settingIds = SettingID1,SettingID2,...,SettingIDN')

    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        setting_id_list = opts.setting_ids.split(',')

        repo_endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)
        repo_endpoint.deleteNodeConfigSettingInfo(setting_id_list)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'deleteNodeConfigSettingInfo')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
