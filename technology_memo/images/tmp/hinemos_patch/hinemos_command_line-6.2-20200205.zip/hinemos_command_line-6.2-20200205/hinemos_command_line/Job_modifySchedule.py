#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブのスケジュール実行契機情報を変更する

<概要>
ジョブのスケジュール実行契機情報を変更します。

<使用例>
- スケジュール設定を毎週に変更します。
[command]
    $ python Job_modifySchedule.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_SC -S "WEEKLY Sun 10:10"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifySchedule succeeded.


- スケジュール設定を毎日に変更します。
[command]
    $ python Job_modifySchedule.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_SC -S "DAILY *:10"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifySchedule succeeded.


- スケジュール設定を毎時に変更します。
[command]
    $ python Job_modifySchedule.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_SC -S "HOURLY 10/15"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifySchedule succeeded.


- ジョブ変数を追加、変更、削除します。
[command]
    $ python Job_modifySchedule.py -I TEST_SC --paramAction ADD --paramName var1 --paramType FIXED --paramDefaultValue A --paramDesc "This is a fixed parameter"

[command]
    $ python Job_modifySchedule.py -I TEST_SC --paramAction MOD --paramName var1 --paramDefaultValue B --paramDesc "Updated"

[command]
    $ python Job_modifySchedule.py -I TEST_SC --paramAction DEL --paramName var1
"""

import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.job import JobUtil
from hinemos.util.modifier import ObjectModifier

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-I', '--scheduleID',  action='store', type='string', metavar='ID', dest='schedule_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='schedule ID')

    psr.add_option('-N', '--name', action='store', type='string', metavar='STRING', dest='name',
                    default=(None,'NOTBLANK'), help='schedule name')

    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None,'NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')
    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='cal_id',
                    default=None, help='Calendar ID')
    psr.add_option('-S', '--schedule', action='store', type='string', metavar='STRING', dest='schedule',
                    default=(None, 'NOTBLANK'), help='schedule = "DAILY *:00", "DAILY 12:00", "WEEKLY Sun *:30", "WEEKLY Mon 23:59", "HOURLY 00/05", "HOURLY 00/60". Hour format : 0-48 or *; week format : Sun, Mon, Tue, Wed, Thu, Fri, Sat; HOURLY format : 0-29/[5,10,15,20,30]')

    psr.add_option('-e', '--enable', action='store', type='string', metavar='BOOL', dest='enable_raw',converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false')

    psr.add_option('--paramAction', action='store', type='string', metavar='MODE', dest='action',
                    default=(None, {'INLIST':['ADD','MOD','DEL']}), help='paramAction = ADD or MOD or DEL')
    psr.add_option('--paramName', action='store', type='string', metavar='STRING', dest='paramName',
                    default=(None, 'NOTBLANK', {'WHEN':[{'action':'ADD'},{'action':'MOD'},{'action':'DEL'}], 'DO':('REQUIRED')}), help='paramName')
    psr.add_option('--paramType', action='store', type='string', metavar='STRING', dest='paramType',
                    default=(None, {'INLIST':JobUtil._rt_param_type_}, {'WHEN':{'action':'ADD'}, 'DO':('REQUIRED','NOTBLANK')}), help='paramType = '+' or '.join(JobUtil._rt_param_type_))
    psr.add_option('--paramRequired', action='store', type='string', metavar='BOOL', dest='paramRequired_raw', converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='paramRequired')
    psr.add_option('--paramDesc', action='store', type='string', metavar='STRING', dest='paramDesc',
                    default=None, help='Parameter description')
    psr.add_option('--paramDefaultValue', action='store', type='string', metavar='STRING', dest='paramDefaultValue',
                    default=None, help='paramDefaultValue')
    psr.add_option('--paramChoiceValues', action='store_split', type='string', metavar='STRING', dest='paramChoiceValues_raw',
                    default=None, help='paramChoiceValues = value1,value2,value3')
    psr.add_option('--paramChoiceDescs', action='store_split', type='string', metavar='STRING', dest='paramChoiceDescs_raw',
                    default=None, help='paramChoiceDescs = desc1,desc2,desc3')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Get info
        info_old = endpoint.getJobSchedule(opts.schedule_id)
        LOGGER.debug(info_old)

        job_map = JobUtil.convert2job(opts.job)
        LOGGER.debug(job_map)
        schedule_map = JobUtil.convert2schedule(opts.schedule)
        LOGGER.debug(schedule_map)

        if opts.action == 'ADD':
            detail_list = []
            if opts.paramChoiceValues is not None:
                # Format paramChoiceDescs according to paramChoiceValues
                if opts.paramChoiceDescs is None:
                    opts.paramChoiceDescs = [''] * len(opts.paramChoiceValues)
                elif len(opts.paramChoiceDescs) < len(opts.paramChoiceValues):
                    opts.paramChoiceDescs += [''] * (len(opts.paramChoiceValues) - len(opts.paramChoiceDescs))
                for i,val in enumerate(opts.paramChoiceValues):
                    detail_list.append(endpoint.create_job_runtime_param_detail(opts.paramChoiceDescs[i], val))
            LOGGER.debug(detail_list)

            param_info = endpoint.create_job_runtime_param(
                opts.paramName,
                JobUtil.convert2param_type(opts.paramType),
                opts.paramDesc,
                opts.paramRequired,
                opts.paramDefaultValue,
                detail_list)
            LOGGER.debug(param_info)

            # Append a new job runtime parameter
            if 'jobRuntimeParamList' not in info_old:
                setattr(info_old, 'jobRuntimeParamList', [param_info])
            else:
                info_old.jobRuntimeParamList.append(param_info)
        elif opts.action == 'MOD':
            detail_list = None
            if opts.paramChoiceValues is not None:
                detail_list = []
                # Format paramChoiceDescs according to paramChoiceValues
                if opts.paramChoiceDescs is None:
                    opts.paramChoiceDescs = [''] * len(opts.paramChoiceValues)
                elif len(opts.paramChoiceDescs) < len(opts.paramChoiceValues):
                    opts.paramChoiceDescs += [''] * (len(opts.paramChoiceValues) - len(opts.paramChoiceDescs))
                for i,val in enumerate(opts.paramChoiceValues):
                    detail_list.append(endpoint.create_job_runtime_param_detail(opts.paramChoiceDescs[i], val))
            # If paramType is INPUT or FIXED, clear the detail_list.
            if opts.paramType in [JobUtil._rt_param_type_[0], JobUtil._rt_param_type_[3]]:
                detail_list = []
            LOGGER.debug(detail_list)

            # Find the param
            param_info = None
            if 'jobRuntimeParamList' in info_old:
                for a in info_old.jobRuntimeParamList:
                    if a.paramId == opts.paramName:
                        param_info = a
                        break
            if param_info is None:
                LOGGER.debug(param_info)
                raise ErrorHandler.ArgumentError('Parameter "%s" not found!' % opts.paramName)

            # Modify a parameter
            ObjectModifier.replace_if_not_none(
                param_info,
                paramType = JobUtil.convert2param_type(opts.paramType),
                description = opts.paramDesc,
                value = opts.paramDefaultValue,
                requiredFlg = opts.paramRequired,
                jobRuntimeParamDetailList = detail_list)

            # If paramType is COMOBO and default_value is not in list, clear the default_value.
            if param_info.paramType == JobUtil._rt_param_type_.index('COMBO') and opts.paramDefaultValue is None and opts.paramChoiceValues is not None and hasattr(param_info, 'value'):
                match = None
                for param_detail in param_info.jobRuntimeParamDetailList:
                    if param_info.value == param_detail.paramValue:
                        match = param_detail.paramValue
                        break
                if match is None:
                    param_info.value = None
        elif opts.action == 'DEL':
            # Find the param
            param_info = None
            if 'jobRuntimeParamList' in info_old:
                for a in info_old.jobRuntimeParamList:
                    if a.paramId == opts.paramName:
                        param_info = a
                        info_old.jobRuntimeParamList.remove(a)
                        break
            if param_info is None:
                LOGGER.debug(param_info)
                raise ErrorHandler.ArgumentError('Parameter "%s" not found!' % opts.paramName)

        info = JobUtil.set_schedule(
            info_old,
            opts.name,
            job_map,
            schedule_map,
            opts.cal_id,
            opts.enable,
            None) # parameters are already managed above
        LOGGER.debug(info)

        endpoint.modifySchedule(info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifySchedule')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
