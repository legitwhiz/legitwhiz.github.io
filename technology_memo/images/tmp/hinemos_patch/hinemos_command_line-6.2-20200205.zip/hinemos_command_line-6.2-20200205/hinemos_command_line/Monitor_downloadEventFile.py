#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定された条件に一致するイベント情報一覧を指定した場所に出力する

<概要>
引数で指定された条件に一致するイベント情報一覧を指定した場所に出力します。

<使用例>
[command]
    $ python Monitor_downloadEventFile.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I NODE01 -F 1 -f TEST_Event.csv -d /tmp

[result]
    http://192.168.1.2:8080/HinemosWS/, downloadEventFile succeeded.


[command]
    $ python Monitor_downloadEventFile.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I NODE01 -d /opt/hinemos/var/output/ -f EventList-Critical.csv -P CRITICAL

[result]
    http://192.168.1.2:8080/HinemosWS/, downloadEventFile succeeded.
"""

import sys
import codecs, locale
import os
import base64
from hinemos.util.common import SettingUtil, DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitor import MonitorEndpoint
from hinemos.util.notify import NotifyUtil
from hinemos.util.modifier import ObjectModifier


def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='Facility ID')

    # Search all

    psr.add_option('-P', '--priorities', action='store_split', type='string', metavar='STRING', dest='priorities_raw',
                    default=None, help='priorities = INFO, WARN, CRITICAL, UNKNOWN. Download all by default.')

    psr.add_option('-o', '--outputDateFrom', action='store', type='string', metavar='STRING', dest='output_date_from',
                    default='', help='Output date from [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-O', '--outputDateTo', action='store', type='string', metavar='STRING', dest='output_date_to',
                    default='', help='Output date to [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-g', '--createdDateFrom', action='store', type='string', metavar='STRING', dest='generation_date_from',
                    default='', help='Created date from [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-G', '--createdDateTo', action='store', type='string', metavar='STRING', dest='generation_date_to',
                    default='', help='Created date to [yyyy/mm/dd HH:MM:SS]')

    # Monitor ID
    psr.add_option('--monitorID', action='store', type='string', metavar='STRING', dest='monitor_id', default=None,
                   help='Monitor ID')

    # Monitor Detail ID
    psr.add_option('--monitorDetailID', action='store', type='string', metavar='STRING', dest='monitor_detail_id',
                   default=None, help='Monitor Detail ID')

    psr.add_option('-T', '--facilityType', action='store', type='int', metavar='INT', dest='facility_type',
                    default=1, help='Facility type = 0(Sub-scope Facilities Only) or 1(ALL Facilities)')

    psr.add_option('-A', '--application', action='store', type='string', metavar='STRING', dest='application',
                    default='', help='Application')
    psr.add_option('-M', '--message', action='store', type='string', metavar='STRING', dest='message',
                    default='', help='Message')

    psr.add_option('-F', '--confirmFlg', action='store_split', type='string', metavar='STRING',
                   dest='confirm_flg_type_raw', default=None, help='Confirm Flag= UNCONFIRMED, CONFIRMED, CONFIRMING.'
                                                                   'Download UNCONFIRMED,CONFIRMING by default')
    psr.add_option('-N', '--confirmedUser', action='store', type='string', metavar='STRING', dest='confirmed_user',
                    default='', help='Confirmed user')
    psr.add_option('-C', '--comment', action='store', type='string', metavar='STRING', dest='comment',
                    default='', help='Comment')
    psr.add_option('-c', '--commentUser', action='store', type='string', metavar='STRING', dest='comment_user',
                    default='', help='Commented user')

    # Collect Flag
    psr.add_option('-p', '--collectGraphFlg', action='store', type='string', metavar='BOOL',
                   dest='collect_graph_flg_raw', converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['on', 'off']}), help='Performance Graph Flag(on or off)')

    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default='', help='Owner role ID')

    psr.add_option('-f', '--filename', action='store', type='string', metavar='STRING', dest='filename',
                    default=(None, 'REQUIRED','NOTBLANK'), help='Output filename [xxxxxxxx.csv]')
    psr.add_option('-d', '--dir', action='store', type='string', metavar='STRING', dest='output_directory',
                    default=(None, 'REQUIRED','NOTBLANK'), help='Output directory')
    psr.add_option('-l', '--language', action='store', type='string', metavar='STRING', dest='language',
                    default=('en', 'NOTBLANK'), help='Language [en|ja]')
    psr.add_option('--positionFrom', action='store', type='int', metavar='INT', dest='position_from',
                   default=None, help='Position number from NUM')
    psr.add_option('--positionTo', action='store', type='int', metavar='INT', dest='position_to',
                   default=None, help='Position number to NUM')

    # User Item
    psr.add_option('--userItem01', action='store', type='string', metavar='STRING', dest='user_item_01',
                   default=None, help='User item01')

    psr.add_option('--userItem02', action='store', type='string', metavar='STRING', dest='user_item_02',
                   default=None, help='User item02')

    psr.add_option('--userItem03', action='store', type='string', metavar='STRING', dest='user_item_03',
                   default=None, help='User item03')

    psr.add_option('--userItem04', action='store', type='string', metavar='STRING', dest='user_item_04',
                   default=None, help='User item04')

    psr.add_option('--userItem05', action='store', type='string', metavar='STRING', dest='user_item_05',
                   default=None, help='User item05')

    psr.add_option('--userItem06', action='store', type='string', metavar='STRING', dest='user_item_06',
                   default=None, help='User item06')

    psr.add_option('--userItem07', action='store', type='string', metavar='STRING', dest='user_item_07',
                   default=None, help='User item07')

    psr.add_option('--userItem08', action='store', type='string', metavar='STRING', dest='user_item_08',
                   default=None, help='User item08')

    psr.add_option('--userItem09', action='store', type='string', metavar='STRING', dest='user_item_09',
                   default=None, help='User item09')

    psr.add_option('--userItem10', action='store', type='string', metavar='STRING', dest='user_item_10',
                   default=None, help='User item10')

    psr.add_option('--userItem11', action='store', type='string', metavar='STRING', dest='user_item_11',
                   default=None, help='User item11')

    psr.add_option('--userItem12', action='store', type='string', metavar='STRING', dest='user_item_12',
                   default=None, help='User item12')

    psr.add_option('--userItem13', action='store', type='string', metavar='STRING', dest='user_item_13',
                   default=None, help='User item13')

    psr.add_option('--userItem14', action='store', type='string', metavar='STRING', dest='user_item_14',
                   default=None, help='User item14')

    psr.add_option('--userItem15', action='store', type='string', metavar='STRING', dest='user_item_15',
                   default=None, help='User item15')

    psr.add_option('--userItem16', action='store', type='string', metavar='STRING', dest='user_item_16',
                   default=None, help='User item16')

    psr.add_option('--userItem17', action='store', type='string', metavar='STRING', dest='user_item_17',
                   default=None, help='User item17')

    psr.add_option('--userItem18', action='store', type='string', metavar='STRING', dest='user_item_18',
                   default=None, help='User item18')

    psr.add_option('--userItem19', action='store', type='string', metavar='STRING', dest='user_item_19',
                   default=None, help='User item19')

    psr.add_option('--userItem20', action='store', type='string', metavar='STRING', dest='user_item_20',
                   default=None, help='User item20')

    psr.add_option('--userItem21', action='store', type='string', metavar='STRING', dest='user_item_21',
                   default=None, help='User item21')

    psr.add_option('--userItem22', action='store', type='string', metavar='STRING', dest='user_item_22',
                   default=None, help='User item22')

    psr.add_option('--userItem23', action='store', type='string', metavar='STRING', dest='user_item_23',
                   default=None, help='User item23')

    psr.add_option('--userItem24', action='store', type='string', metavar='STRING', dest='user_item_24',
                   default=None, help='User item24')

    psr.add_option('--userItem25', action='store', type='string', metavar='STRING', dest='user_item_25',
                   default=None, help='User item25')

    psr.add_option('--userItem26', action='store', type='string', metavar='STRING', dest='user_item_26',
                   default=None, help='User item26')

    psr.add_option('--userItem27', action='store', type='string', metavar='STRING', dest='user_item_27',
                   default=None, help='User item27')

    psr.add_option('--userItem28', action='store', type='string', metavar='STRING', dest='user_item_28',
                   default=None, help='User item28')

    psr.add_option('--userItem29', action='store', type='string', metavar='STRING', dest='user_item_29',
                   default=None, help='User item29')

    psr.add_option('--userItem30', action='store', type='string', metavar='STRING', dest='user_item_30',
                   default=None, help='User item30')

    psr.add_option('--userItem31', action='store', type='string', metavar='STRING', dest='user_item_31',
                   default=None, help='User item31')

    psr.add_option('--userItem32', action='store', type='string', metavar='STRING', dest='user_item_32',
                   default=None, help='User item32')

    psr.add_option('--userItem33', action='store', type='string', metavar='STRING', dest='user_item_33',
                   default=None, help='User item33')

    psr.add_option('--userItem34', action='store', type='string', metavar='STRING', dest='user_item_34',
                   default=None, help='User item34')

    psr.add_option('--userItem35', action='store', type='string', metavar='STRING', dest='user_item_35',
                   default=None, help='User item35')

    psr.add_option('--userItem36', action='store', type='string', metavar='STRING', dest='user_item_36',
                   default=None, help='User item36')

    psr.add_option('--userItem37', action='store', type='string', metavar='STRING', dest='user_item_37',
                   default=None, help='User item37')

    psr.add_option('--userItem38', action='store', type='string', metavar='STRING', dest='user_item_38',
                   default=None, help='User item38')

    psr.add_option('--userItem39', action='store', type='string', metavar='STRING', dest='user_item_39',
                   default=None, help='User item39')

    psr.add_option('--userItem40', action='store', type='string', metavar='STRING', dest='user_item_40',
                   default=None, help='User item40')

    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### argument check ###
        directory = opts.output_directory.rstrip('\'')
        if not os.path.isdir(os.path.abspath(directory)):
            raise ErrorHandler.ArgumentError('%s does not exist' % directory)

        ### login ###
        endpoint = MonitorEndpoint(opts.mgr_url, opts.user, opts.passwd)

        if opts.generation_date_from != '':
            opts.generation_date_from = DateConvert.get_epochtime_from_datetime(opts.generation_date_from)
        if opts.generation_date_to != '':
            opts.generation_date_to = DateConvert.get_epochtime_from_datetime(opts.generation_date_to)
        if opts.output_date_from != '':
            opts.output_date_from = DateConvert.get_epochtime_from_datetime(opts.output_date_from)
        if opts.output_date_to != '':
            opts.output_date_to = DateConvert.get_epochtime_from_datetime(opts.output_date_to)

        ### method edit###
        eventFilterInfo = endpoint.create_object('eventFilterInfo')

        if opts.priorities is None:
            opts.priorities = ['CRITICAL','WARN','INFO','UNKNOWN']
        eventFilterInfo.priorityList=tuple(NotifyUtil.convert2priority(a) for a in opts.priorities)
        if opts.output_date_from != '':
            eventFilterInfo.outputDateFrom=opts.output_date_from
        if opts.output_date_to != '':
            eventFilterInfo.outputDateTo=opts.output_date_to
        if opts.generation_date_from != '':
            eventFilterInfo.generationDateFrom=opts.generation_date_from
        if opts.generation_date_to != '':
            eventFilterInfo.generationDateTo=opts.generation_date_to
        if opts.facility_type is not None:
            eventFilterInfo.facilityType = opts.facility_type
        if opts.application != '':
            eventFilterInfo.application=opts.application
        if opts.message != '':
            eventFilterInfo.message=opts.message
        if opts.confirm_flg_type is None:
            opts.confirm_flg_type = ['UNCONFIRMED', 'CONFIRMING']
        eventFilterInfo.confirmFlgTypeList = tuple(NotifyUtil.convert2confirm_flg(confirm_flg)
                                                   for confirm_flg in opts.confirm_flg_type)
        if opts.confirmed_user != '':
            eventFilterInfo.confirmedUser=opts.confirmed_user
        if opts.comment != '':
            eventFilterInfo.comment=opts.comment
        if opts.comment_user != '':
            eventFilterInfo.commentUser=opts.comment_user
        if opts.owner_role_id != '':
            eventFilterInfo.ownerRoleId=opts.owner_role_id

        ObjectModifier.replace_if_not_none(
            eventFilterInfo,
            monitorId=opts.monitor_id,
            monitorDetailId=opts.monitor_detail_id,
            collectGraphFlg=opts.collect_graph_flg,
            positionFrom=opts.position_from,
            positionTo=opts.position_to,
            userItem01=opts.user_item_01,
            userItem02=opts.user_item_02,
            userItem03=opts.user_item_03,
            userItem04=opts.user_item_04,
            userItem05=opts.user_item_05,
            userItem06=opts.user_item_06,
            userItem07=opts.user_item_07,
            userItem08=opts.user_item_08,
            userItem09=opts.user_item_09,
            userItem10=opts.user_item_10,
            userItem11=opts.user_item_11,
            userItem12=opts.user_item_12,
            userItem13=opts.user_item_13,
            userItem14=opts.user_item_14,
            userItem15=opts.user_item_15,
            userItem16=opts.user_item_16,
            userItem17=opts.user_item_17,
            userItem18=opts.user_item_18,
            userItem19=opts.user_item_19,
            userItem20=opts.user_item_20,
            userItem21=opts.user_item_21,
            userItem22=opts.user_item_22,
            userItem23=opts.user_item_23,
            userItem24=opts.user_item_24,
            userItem25=opts.user_item_25,
            userItem26=opts.user_item_26,
            userItem27=opts.user_item_27,
            userItem28=opts.user_item_28,
            userItem29=opts.user_item_29,
            userItem30=opts.user_item_30,
            userItem31=opts.user_item_31,
            userItem32=opts.user_item_32,
            userItem33=opts.user_item_33,
            userItem34=opts.user_item_34,
            userItem35=opts.user_item_35,
            userItem36=opts.user_item_36,
            userItem37=opts.user_item_37,
            userItem38=opts.user_item_38,
            userItem39=opts.user_item_39,
            userItem40=opts.user_item_40
        )

        result = endpoint.downloadEventFile(opts.facility_id, eventFilterInfo, opts.filename, opts.language)
        filePath = os.path.abspath(directory  + '/' + opts.filename)

        with open(filePath, 'w') as f:
            f.write(base64.b64decode(result))
        return_code = ResultPrinter.success(None, opts.mgr_url, 'downloadEventFile')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
