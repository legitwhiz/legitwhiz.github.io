#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
カスタム監視(数値)の監視設定情報を変更する

<概要>
カスタム監視(数値)の監視設定情報を変更します。

<使用例>
[command]
    $ python MonitorSetting_modifyMonitor_CustomI.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I CUSTOMN01 -A MYAPP -F SCOPE001 -o command1_changed

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.modifier import ObjectModifier
from hinemos.util.notify import NotifyUtil
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_modify_args_parser(
            help_default_info)
    psr.add_option('-t', '--commandExecType', action='store', type='string',
                   metavar='STRING', dest='command_exec_type',
                   default=(None, {'INLIST': ['INDIVIDUAL', 'SELECTED']}),
                   help='commandExecType = INDIVIDUAL or SELECTED')
    psr.add_option('-f', '--selectedFacilityId', action='store', type='string',
                   metavar='STRING', dest='selected_facility_id',
                   default=(None, 'NOTBLANK'),
                   help='facility ID for running command')
    psr.add_option('-s', '--specifyRunUser', action='store', type='string',
                   metavar='STRING', dest='specify_user',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='specifyRunUser')
    psr.add_option('-e', '--execUser', action='store', type='string',
                   metavar='STRING', dest='run_user',
                   default=None, help='run command as user')
    psr.add_option('-o', '--command', action='store', type='string',
                   metavar='STRING', dest='command',
                   default=(None, 'NOTBLANK'), help='command')
    psr.add_option('-O', '--timeout', action='store', type='int',
                   metavar='INT', dest='timeout',
                   default=None, help='run command with time limit')
    psr.add_option('-r', '--calculateDiff', action='store', type='string',
                   metavar='STRING', dest='cal_diff_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='calculate difference from previous result =true,'
                   'do nothing =false')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # monitorInfo parameter
        monitor_info = endpoint.getMonitor(opts.monitor_id)

        # Modification
        with ObjectModifier(monitor_info) as modifier:
            endpoint.update_common_infos(modifier, vars(opts))
            endpoint.update_collect_infos(modifier, vars(opts))
            endpoint.update_prediction_info(modifier, vars(opts))
            endpoint.update_change_info(modifier, vars(opts))
            endpoint.updete_judgement_tresholds(modifier, vars(opts))

            modifier.change_ptr('customCheckInfo')
            modifier.set_if_first_not_none('command', opts.command)
            modifier.set_if_first_not_none(
                'commandExecType', opts.command_exec_type)
            modifier.set_if_first_not_none('effectiveUser', opts.run_user)
            modifier.set_if_first_not_none(
                'specifyUser', opts.specify_user_converted)
            modifier.set_if_first_not_none('timeout', opts.timeout)
            modifier.set_if_first_not_none('convertFlg', opts.cal_diff)
            if opts.command_exec_type == 'INDIVIDUAL':
                opts.selected_facility_id = ''
            modifier.set_if_first_not_none(
                'selectedFacilityId', opts.selected_facility_id)

        endpoint.update_notify_ids_info(monitor_info, vars(opts))

        endpoint.modifyMonitor(monitor_info)
        return_code = ResultPrinter.success(
            None, opts.mgr_url, 'modifyMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
