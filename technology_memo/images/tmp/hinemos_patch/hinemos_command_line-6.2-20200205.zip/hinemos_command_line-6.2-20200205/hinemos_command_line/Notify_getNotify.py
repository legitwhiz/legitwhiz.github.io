#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定された通知情報を取得する

<概要>
引数で指定された通知情報を取得して表示します。

<使用例>
[command]
    $ python Notify_getNotify.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I STATUS01

[result]
    (notifyInfo){
       ownerRoleId = "ALL_USERS"
       initialCount = 2
       notFirstNotify = False
       notifyId = "STATUS01"
       notifyStatusInfo =
          (notifyStatusInfo){
             criticalValidFlg = True
             infoValidFlg = False
             unknownValidFlg = True
             warnValidFlg = True
             statusInvalidFlg = 11
             statusUpdatePriority = 2
             statusValidPeriod = 10
          }
       notifyType = 0
       regDate = "2017/02/23 14:55:50.360"
       regUser = "hinemos"
       renotifyType = 0
       updateDate = "2017/02/23 20:12:01.654"
       updateUser = "hinemos"
       validFlg = True
     }
    http://192.168.1.2:8080/HinemosWS/, getNotify succeeded.
"""

### import ###
import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.notify import NotifyEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--notifyID',  action='store', type='string', metavar='ID', dest='notify_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='notifyID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getNotify(opts.notify_id)
        if result is not None:
            result.regDate = DateConvert.get_datetime_from_epochtime(result.regDate)
            result.updateDate = DateConvert.get_datetime_from_epochtime(result.updateDate)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getNotify')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
