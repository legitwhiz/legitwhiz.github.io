#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------
u"""
DB取得したバイナリファイルをクライアント送信用に返却する

<概要>
DB取得したバイナリファイルをクライアント送信用に返却します。

<使用例>
[command]
    $ python Binary_downloadBinaryRecord.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -I FACILITYID -M MONITORID --filename binaryfile.txt --clientname FACILITYID_2 --dir "/root" --collectId 0 --dataId 1

[result]
    http://127.0.0.1:8080/HinemosWS/, downloadBinaryRecord succeeded.
"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale

from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.binary import BinaryEndpoint


RETURN_CODE = -1


def parse_options(opt_list):
    psr = MyOptionParser()

    psr.add_option('-I', '--facilityID',  action='store', type='string',
                   metavar='ID', dest='arg0_facilityId',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Facility ID')
    psr.add_option('-M', '--monitorId',  action='store',
                   type='string', metavar='ID', dest='arg0_monitorId',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='Monitor ID')
    psr.add_option('-T', '--collectId', action='store', type='string',
                   metavar='STRING', dest='arg1_collectId',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='Collect ID. Execute Binary_queryCollectBinaryData.py to get collectId of the desired record')
    psr.add_option('-D', '--dataId', action='store', type='string',
                   metavar='STRING', dest='arg1_dataId',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='Data ID. Execute Binary_queryCollectBinaryData.py to get dataId of the desired record')
    psr.add_option('-f', '--filename', action='store', type='string',
                   metavar='STRING', dest='arg2',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='Output filename ')
    psr.add_option('-c', '--clientname', action='store', type='string',
                   metavar='STRING', dest='arg3',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='Client Name')
    psr.add_option('-d', '--dir', action='store', type='string',
                   metavar='STRING', dest='output_directory',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='Output directory')

    opts = psr.parse_opts(opt_list)
    non_empty_opts = dict(
        filter(lambda x: x[1] is not None and x[1] is not '',
               vars(opts).items()))
    return non_empty_opts


def connect_to_endpoint(opts):
    try:
        endpoint = BinaryEndpoint(
            opts['mgr_url'], opts['user'], opts['passwd'])
    except ErrorHandler.LoginError as e:
        sys.exit(ResultPrinter.failure(e))
    except Exception, e:
        sys.exit(ResultPrinter.failure(e))
    return endpoint


def get_request_data_template(endpoint):
    try:
        namespace = 'ns1'
        template = endpoint.get_obj(namespace,'downloadBinaryRecord')
        template.arg0 = endpoint.get_obj(namespace, 'binaryQueryInfo')
        template.arg1 = endpoint.get_obj(namespace, 'collectStringDataPK')
    except Exception, e:
        sys.exit(ResultPrinter.failure(e))
    return template


def fillin_template(data_template, opts):
    binary_record_keys = ['arg0', 'arg1', 'arg2', 'arg3']  # DownloadBinaryRecord クラスの変数
    opts_to_fillin = dict(
        filter(lambda opt: opt[0].split('_')[0] in binary_record_keys,
               opts.items()))

    for opt in opts_to_fillin:
        data = data_template
        path = opt.split('_')
        for level in path:
            if level is path[-1]:
                data[level] = opts_to_fillin[opt]
            else:
                data = data[level]
    data_template['outputdir'] = opts['output_directory']
    return data_template


def downloadBinaryRecord(endpoint, request_data):
    try:
        return endpoint.downloadBinaryRecord(
            request_data.arg0,  # binaryQueryInfo
            request_data.arg1,  # collectStringDataPK
            request_data.arg2,  # filename
            request_data.arg3,  # clientName
            request_data.outputdir)  # OutputDir
    except ErrorHandler.PermissoinError as e:
        sys.exit(ResultPrinter.failure(e))
    except ErrorHandler.APIError as e:
        sys.exit(ResultPrinter.failure(e))


def main():
    opts = parse_options(sys.argv)

    endpoint = connect_to_endpoint(opts)
    request_data = get_request_data_template(endpoint)
    request_data = fillin_template(request_data, opts)

    result = downloadBinaryRecord(endpoint, request_data)
    try:
        ResultPrinter.success(None, opts['mgr_url'], 'downloadBinaryRecord')
    except Exception as e:
        sys.exit(ResultPrinter.failure(e))


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)
    sys.exit(main())
