#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
転送先種別リストを取得する

<概要>
転送先種別リストを取得して表示します。

<使用例>
[command]
    $ python Hub_getTransferInfoDestTypeMstList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    [(transferInfoDestTypeMst){
       description = "fluentd.description"
       destTypeId = "fluentd"
       destTypePropMsts[] =
          (transferDestTypePropMst){
             description = "fluentd.url.description"
             name = "fluentd.url"
             value = "http://127.0.0.1:8888/"
          },
          (transferDestTypePropMst){
             description = "fluentd.connect_timeout.description"
             name = "fluentd.connect_timeout"
             value = "10000"
          },
          (transferDestTypePropMst){
             description = "fluentd.request_timeout.description"
             name = "fluentd.request_timeout"
             value = "60000"
          },
       name = "fluentd"
     }]
    http://192.168.1.2:8080/HinemosWS/, getTransferInfoDestTypeMstList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
from hinemos.util.common import ResultPrinter
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.hub import HubEndpoint

def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = HubEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getTransferInfoDestTypeMstList()
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getTransferInfoDestTypeMstList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
