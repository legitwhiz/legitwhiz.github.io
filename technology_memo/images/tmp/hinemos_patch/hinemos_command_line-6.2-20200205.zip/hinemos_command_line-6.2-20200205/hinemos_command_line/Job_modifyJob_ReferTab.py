#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
「参照」タブの情報を変更する

<概要>
「参照」タブの情報を変更します。

<使用例>
[command]
    $ python Job_modifyJob_ReferTab.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001/RJ001 -R JOB2

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyJob succeeded.
"""

import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil
from hinemos.util.common import ResultPrinter

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')

    ### 参照タブ設定項目 ###
    psr.add_option('-R', '--referJobID',  action='store', type='string', metavar='ID', dest='referJobID',
                    default=(None, 'NOTBLANK'), help='Refer job ID')
    psr.add_option('-S', '--referModuleID',  action='store', type='string', metavar='ID', dest='referModuleID',
                    default=(None,'NOTBLANK'), help='Refer module ID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Format argument
        job_map = JobUtil.convert2job(opts.job)
        refer_map = {'referJobUnitId':None, 'referJobId':None, 'referJobSelectType': 0}
        if opts.referModuleID is not None:
            refer_map['referJobSelectType'] = 1
            refer_map['referJobUnitId'] = job_map['jobunitId']
            refer_map['referJobId'] = opts.referModuleID
        elif opts.referJobID is not None:
            refer_map['referJobSelectType'] = 0
            refer_map['referJobUnitId'] = job_map['jobunitId']
            refer_map['referJobId'] = opts.referJobID
        #else:
        #    raise ErrorHandler.ArgumentError('Either referModuleID or referJobID is required!')

        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, job_map['jobunitId'])
        del job_tree_full

        job_info = JobUtil.find_job_info(job_tree, job_map['jobId'])
        if job_info is None:
            raise ErrorHandler.ArgumentError('Job {:s} not found!'.format(job_map['jobId']))

        job_type_label = JobUtil.convert2job_type_label(job_info.type)
        if job_type_label not in ('REFERJOB', 'REFERJOBNET'):
            raise ErrorHandler.ArgumentError('This operation is not available for %s!' % job_type_label)

        new_job_info = endpoint.getJobFull(endpoint.create_job_info_minimal(job_map['jobunitId'], job_map['jobId']))
        # Skip if not specified
        if refer_map['referJobUnitId'] is not None:
            # Check job type
            refer_info = JobUtil.get_job(endpoint, refer_map['referJobUnitId'], refer_map['referJobId'])
            if refer_info.type == JobUtil.convert2job_type('JOBNET'):
                job_type = JobUtil.convert2job_type('REFERJOBNET')
            else:
                job_type = JobUtil.convert2job_type('REFERJOB')

            new_job_info.type = job_type
            new_job_info.referJobSelectType = refer_map['referJobSelectType']
            new_job_info.referJobUnitId = refer_map['referJobUnitId']
            new_job_info.referJobId = refer_map['referJobId']

        LOGGER.debug(new_job_info)

        JobUtil.replace_job_info(job_tree, new_job_info)

        # Clean up and replace none with blank
        JobUtil.cleanup_and_fixnone(job_tree)

        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyJob')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
