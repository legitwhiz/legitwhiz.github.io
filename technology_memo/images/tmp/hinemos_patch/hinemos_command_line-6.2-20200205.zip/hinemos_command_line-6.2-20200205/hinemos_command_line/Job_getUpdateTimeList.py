#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したジョブユニットの最終更新日時を取得する

<概要>
引数で指定したジョブユニットの最終更新日時を取得して表示します。

<使用例>
[command]
    $ python Job_getUpdateTimeList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_JOBU

[result]
    ['2017/03/07 13:14:25.927']
    http://192.168.1.2:8080/HinemosWS/, getUpdateTimeList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--jobunitIDList', action='store', type='string', metavar='STRING', dest='jobunit_id_list',
                    default=(None, 'REQUIRED','NOTBLANK'), help='jobunitId1,jobunitId2,jobunitId3...')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        jobunit_ids = opts.jobunit_id_list.split(',')
        result = endpoint.getUpdateTimeList(jobunit_ids)
        if result is not None:
            for i in xrange(len(result)):
                result[i] = DateConvert.get_datetime_from_epochtime(result[i])

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getUpdateTimeList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
