#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ログフォーマットの ID 情報一覧を取得する

<概要>
ログフォーマット情報一覧を取得して表示します。

<使用例>
[command]
    $ python Hub_getLogFormatList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    [(logFormat){
       ownerRoleId = "ALL_USERS"
       description = "Logformat for Apache accesslog"
       keyPatternList[] =
          (logFormatKey){
             key = "CLIENT_ID"
             keyType = "parsing"
             pattern = "^[a-zA-Z0-9:\.\-]+ ([a-zA-Z0-9\.\-]+) [a-zA-Z0-9\.\-@]+"
             valueType = "string"
          },
          (logFormatKey){
             key = "DATE"
             keyType = "parsing"
             pattern = "(\[([0-9]{2}/[a-zA-Z]{3}/[0-9]{1,4}:[0-9]{2}:[0-9]{2}:[0-9]{2} [0-9\+-]{5})\])"
             valueType = "string"
          },
          (logFormatKey){
             description = "The first line value of the request."
             key = "FIRST_LINE_VALUE"
             keyType = "parsing"
             pattern = "(\"[a-zA-Z]+ [a-zA-Z0-9/%-_]* [a-zA-Z]+/[0-9\.]+\")"
             valueType = "string"
          },
            ...中略...
          (logFormatKey){
             description = "IPADDRESS"
             key = "IPADDRESS"
             keyType = "parsing"
             pattern = "(([0-9]{1,3}\.){3}[0-9]{1,3})"
             valueType = "string"
          },
       logFormatId = "LOGFORMAT_SYSLOG"
       regDate = 1333206000000
       regUser = "hinemos"
       timestampFormat = "EEE MMM dd HH:mm:ss yyyy"
       timestampRegex = "(\[([a-zA-Z]{3} [a-zA-Z]{3} [0-9]{1,2} [0-9]{2}:[0-9]{2}:[0-9]{2} [0-9]{4})\])"
       updateDate = 1333206000000
       updateUser = "hinemos"
     }, (logFormat){
       ownerRoleId = "ALL_USERS"
       description = "test_logformat"
       logFormatId = "TEST_LOGFORMAT"
       regDate = 1488870609548
       regUser = "hinemos"
       timestampFormat = "2017-03-01 00:00:00"
       timestampRegex = ".*"
       updateDate = 1488870609548
       updateUser = "hinemos"
     }]
    http://192.168.1.2:8080/HinemosWS/, getLogFormatList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
from hinemos.util.common import ResultPrinter
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.hub import HubEndpoint

def main():

    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = HubEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getLogFormatList()
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getLogFormatList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
