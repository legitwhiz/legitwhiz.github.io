#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
オーナーロールIDを条件としてカレンダパターン情報一覧を取得する

<概要>
オーナーロールIDを条件としてカレンダパターン情報一覧を取得して一覧表示します。

<使用例>
[command]
    $ python Calendar_getCalendarPatternList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -R TEST01

[result]
    [(calendarPatternInfo){
       ownerRoleId = "TEST01"
       calPatternId = "TEST_CP02"
       calPatternName = "TEST_CP02"
       regDate = "2017/03/03 14:40:03.469"
       regUser = "hinemos"
       updateDate = "2017/03/03 14:40:03.469"
       updateUser = "hinemos"
       ymd[] =
          (ymd){
             calPatternId = "TEST_CP02"
             day = 20
             month = 3
             year = 2017
          },
     }]
    http://192.168.1.2:8080/HinemosWS/, getCalendarPatternList succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser

import hinemos.api.exceptions as ErrorHandler
from hinemos.api.calendar import CalendarEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default='', help='ownerRoleID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = CalendarEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        result = endpoint.get_calendar_pattern_list_formatted(opts.owner_role_id)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'getCalendarPatternList')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
