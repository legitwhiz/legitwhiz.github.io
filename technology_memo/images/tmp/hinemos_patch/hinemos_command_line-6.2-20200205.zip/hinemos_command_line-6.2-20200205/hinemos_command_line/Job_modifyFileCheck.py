#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブのファイルチェック実行契機情報を変更する

<概要>
ジョブのファイルチェック実行契機情報を変更します。

<使用例>
- ジョブのファイルチェック実行契機情報を変更します。
[command]
    $ python Job_modifyFileCheck.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_FC1 -C CAL001 -F WINDOWS -d /tmp/new -f newfile.txt -E MOD -M FILESIZE -e false

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyFileCheck succeeded.


- カレンダ設定を外します。
[command]
    $ python Job_modifyFileCheck.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_FC1 -C ""

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyFileCheck succeeded.


- ジョブを変更します。
[command]
    $ python Job_modifyFileCheck.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_FC1 -J JU001

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyFileCheck succeeded.
"""

import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.job import JobUtil
from hinemos.util.modifier import ObjectModifier

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-I', '--filecheckID',  action='store', type='string', metavar='ID', dest='filecheck_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='filecheckID')
    psr.add_option('-N', '--name', action='store', type='string', metavar='STRING', dest='name',
                    default=(None, 'NOTBLANK'), help='filecheck name')

    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job_path',
                    default=(None, 'NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')
    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                    default=None, help='calendarID')
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None,'NOTBLANK'), help='facilityID')
    psr.add_option('-d', '--directory', action='store', type='string', metavar='STRING', dest='directory',
                    default=(None, 'NOTBLANK'), help='directory')
    psr.add_option('-f', '--fileName', action='store', type='string', metavar='STRING', dest='file_name',
                    default=(None, 'NOTBLANK'), help='file name')
    psr.add_option('-E', '--eventType', action='store', type='string', metavar='STRING', dest='event_type_raw',converter=JobUtil.convert2file_check_event_type,
                    default=(None,{'INLIST':JobUtil._file_check_event_type_}), help='eventType = ' + ' or '.join(JobUtil._file_check_event_type_))
    psr.add_option('-M', '--modifyType', action='store', type='string', metavar='STRING', dest='modify_type_raw',converter=JobUtil.convert2file_check_mod_type,
                    default=(None, {'INLIST':JobUtil._file_check_mod_type_}, {'WHEN':{'event_type':'MOD'}, 'DO':('REQUIRED')}), help='modifyType = ' + ' or '.join(JobUtil._file_check_mod_type_))

    psr.add_option('-e', '--enable', action='store', type='string', metavar='STRING', dest='enable_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false')

    psr.add_option('--paramAction', action='store', type='string', metavar='MODE', dest='action',
                    default=(None, {'INLIST':['ADD','MOD','DEL']}), help='paramAction = ADD or MOD or DEL')
    psr.add_option('--paramName', action='store', type='string', metavar='STRING', dest='paramName',
                    default=(None, 'NOTBLANK', {'WHEN':[{'action':'ADD'},{'action':'MOD'},{'action':'DEL'}], 'DO':('REQUIRED')}), help='paramName')
    psr.add_option('--paramType', action='store', type='string', metavar='STRING', dest='paramType',
                    default=(None, {'INLIST':JobUtil._rt_param_type_}, {'WHEN':{'action':'ADD'}, 'DO':('REQUIRED','NOTBLANK')}), help='paramType = '+' or '.join(JobUtil._rt_param_type_))
    psr.add_option('--paramRequired', action='store', type='string', metavar='BOOL', dest='paramRequired_raw', converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='paramRequired')
    psr.add_option('--paramDesc', action='store', type='string', metavar='STRING', dest='paramDesc',
                    default=None, help='Parameter description')
    psr.add_option('--paramDefaultValue', action='store', type='string', metavar='STRING', dest='paramDefaultValue',
                    default=None, help='paramDefaultValue')
    psr.add_option('--paramChoiceValues', action='store_split', type='string', metavar='STRING', dest='paramChoiceValues_raw',
                    default=None, help='paramChoiceValues = value1,value2,value3')
    psr.add_option('--paramChoiceDescs', action='store_split', type='string', metavar='STRING', dest='paramChoiceDescs_raw',
                    default=None, help='paramChoiceDescs = desc1,desc2,desc3')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Get info
        info = endpoint.getJobFileCheck(opts.filecheck_id)

        # Modification
        with ObjectModifier(info) as modifier:
            if opts.event_type != JobUtil.convert2file_check_event_type('MOD'):
                opts.modify_type = None
            if opts.job_path is not None:
                job_map = JobUtil.convert2job(opts.job_path)
                modifier.set_if_first_not_none('jobunitId', job_map['jobunitId'], jobName=' ')
                modifier.set_if_first_not_none('jobId', job_map['jobId'])

            modifier.set_if_first_not_none('calendarId', opts.calendar_id)
            modifier.set_if_first_not_none('name', opts.name)
            modifier.set_if_first_not_none('directory', opts.directory)
            modifier.set_if_first_not_none('eventType', opts.event_type)
            modifier.set_if_first_not_none('facilityId', opts.facility_id)
            modifier.set_if_first_not_none('fileName', opts.file_name)
            modifier.set_if_first_not_none('modifyType', opts.modify_type)
            modifier.set_if_first_not_none('valid', opts.enable)

        # Modify paramters
        if opts.action == 'ADD':
            detail_list = []
            if opts.paramChoiceValues is not None:
                # Format paramChoiceDescs according to paramChoiceValues
                if opts.paramChoiceDescs is None:
                    opts.paramChoiceDescs = [''] * len(opts.paramChoiceValues)
                elif len(opts.paramChoiceDescs) < len(opts.paramChoiceValues):
                    opts.paramChoiceDescs += [''] * (len(opts.paramChoiceValues) - len(opts.paramChoiceDescs))
                for i,val in enumerate(opts.paramChoiceValues):
                    detail_list.append(endpoint.create_job_runtime_param_detail(opts.paramChoiceDescs[i], val))
            LOGGER.debug(detail_list)

            param_info = endpoint.create_job_runtime_param(
                opts.paramName,
                JobUtil.convert2param_type(opts.paramType),
                opts.paramDesc,
                opts.paramRequired,
                opts.paramDefaultValue,
                detail_list)
            LOGGER.debug(param_info)

            # Append a new job runtime parameter
            if 'jobRuntimeParamList' not in info:
                setattr(info, 'jobRuntimeParamList', [param_info])
            else:
                info.jobRuntimeParamList.append(param_info)
        elif opts.action == 'MOD':
            detail_list = None
            if opts.paramChoiceValues is not None:
                detail_list = []
                # Format paramChoiceDescs according to paramChoiceValues
                if opts.paramChoiceDescs is None:
                    opts.paramChoiceDescs = [''] * len(opts.paramChoiceValues)
                elif len(opts.paramChoiceDescs) < len(opts.paramChoiceValues):
                    opts.paramChoiceDescs += [''] * (len(opts.paramChoiceValues) - len(opts.paramChoiceDescs))
                for i,val in enumerate(opts.paramChoiceValues):
                    detail_list.append(endpoint.create_job_runtime_param_detail(opts.paramChoiceDescs[i], val))
            # If paramType is INPUT or FIXED, clear the detail_list.
            if opts.paramType in [JobUtil._rt_param_type_[0], JobUtil._rt_param_type_[3]]:
                detail_list = []
            LOGGER.debug(detail_list)

            # Find the param
            param_info = None
            if 'jobRuntimeParamList' in info:
                for a in info.jobRuntimeParamList:
                    if a.paramId == opts.paramName:
                        param_info = a
                        break
            if param_info is None:
                LOGGER.debug(param_info)
                raise ErrorHandler.ArgumentError('Parameter "%s" not found!' % opts.paramName)

            # Modify a parameter
            ObjectModifier.replace_if_not_none(
                param_info,
                paramType = JobUtil.convert2param_type(opts.paramType),
                description = opts.paramDesc,
                value = opts.paramDefaultValue,
                requiredFlg = opts.paramRequired,
                jobRuntimeParamDetailList = detail_list)

            # If paramType is COMOBO and default_value is not in list, clear the default_value.
            if param_info.paramType == JobUtil._rt_param_type_.index('COMBO') and opts.paramDefaultValue is None and opts.paramChoiceValues is not None and hasattr(param_info, 'value'):
                match = None
                for param_detail in param_info.jobRuntimeParamDetailList:
                    if param_info.value == param_detail.paramValue:
                        match = param_detail.paramValue
                        break
                if match is None:
                    param_info.value = None
        elif opts.action == 'DEL':
            # Find the param
            param_info = None
            if 'jobRuntimeParamList' in info:
                for a in info.jobRuntimeParamList:
                    if a.paramId == opts.paramName:
                        param_info = a
                        info.jobRuntimeParamList.remove(a)
                        break
            if param_info is None:
                LOGGER.debug(param_info)
                raise ErrorHandler.ArgumentError('Parameter "%s" not found!' % opts.paramName)

        endpoint.modifyFileCheck(info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyFileCheck')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
