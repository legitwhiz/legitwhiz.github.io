#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
SNMPTRAP監視の監視設定を登録する

<概要>
SNMPTRAP監視の監視設定を登録します。

<使用例>
[command]
    $ python MonitorSetting_addMonitor_Trap.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TRAP1 -A MYAPP -F SCOPE001

[result]
    http://192.168.1.2:8080/HinemosWS/, addMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.util.notify import NotifyUtil
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.argsparserbuilder import MonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = MonitorSettingArgsParserBuilder()\
        .build_monitor_setting_add_args_parser(help_default_info)

    psr.add_option('-l', '--logformatID',  action='store', type='string',
                   metavar='ID', dest='logformat_id',
                   default=(None, {
                       'WHEN': {'collect': 1},
                       'DO': ('REQUIRED', 'NOTBLANK')}),
                   help='Log format ID')

    psr.add_option('-O', '--checkCommunityCheck', action='store',
                   type='string', metavar='STRING',
                   dest='check_community_check',
                   default=None, help='not check =0, check =1 (default: 0)')
    psr.add_option('-o', '--checkCommunityName', action='store', type='string',
                   metavar='STRING', dest='check_community_name',
                   default=None, help='community name')
    psr.add_option('-S', '--checkCharsetConvert', action='store',
                   type='string', metavar='STRING',
                   dest='check_charset_convert',  default=None,
                   help='not convert =0, convert =1 (default: 0)')
    psr.add_option('-s', '--checkCharsetName', action='store', type='string',
                   metavar='STRING', dest='check_charset_name',
                   default=None, help='charset name')
    psr.add_option('-J', '--notifyUnspecified', action='store', type='string',
                   metavar='STRING', dest='notify_unspecified',
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='notify when an unspecified trap received'
                   ' (default: true)')
    psr.add_option('-j', '--notifyUnspecifiedPriority', action='store',
                   type='string', metavar='STRING',
                   dest='notify_unspecified_priority',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                       'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']}),
                   help='notifyUnspecifiedPriority = INFO or WARN or CRITICAL '
                   'or UNKNOWN (default: UNKNOWN)')
    # TODO Presently only one Trap can be added at creating
    psr.add_option('-b', '--trapMIB', action='store', type='string',
                   metavar='STRING', dest='trap_mib',
                   default=None, help='MIB')
    psr.add_option('-u', '--trapUEI', action='store', type='string',
                   metavar='STRING', dest='trap_uei',
                   default=(None, 'NOTBLANK', {'WHEN': {'trap_mib!=': None},
                                               'DO': ('REQUIRED')}),
                   help='trap name(uei)')
    psr.add_option('-v', '--trapVersion', action='store', type='string',
                   metavar='STRING', dest='trap_ver',
                   default=(None, {'INLIST': ['1', '2c/3']}, {
                       'WHEN': {'trap_mib!=': None}, 'DO': ('REQUIRED')}),
                   help='trap version = 1 or 2c/3')
    psr.add_option('-i', '--trapOID',  action='store', type='string',
                   metavar='ID', dest='trap_oid',
                   default=(None, 'NOTBLANK', {
                       'WHEN': {'trap_mib!=': None},
                       'DO': ('REQUIRED')}),
                   help='OID')
    psr.add_option('-G', '--trapGenericID',  action='store', type='string',
                   metavar='ID', dest='trap_generic_id',
                   default=(None, 'NOTBLANK', {
                       'WHEN': {'trap_ver': '1'},
                       'DO': ('REQUIRED')}),
                   help='generic ID')
    psr.add_option('-P', '--trapSpecificID',  action='store', type='string',
                   metavar='ID', dest='trap_specific_id',
                   default=(None, 'NOTBLANK', {
                       'WHEN': {'trap_ver': '1'},
                       'DO': ('REQUIRED')}),
                   help='specific ID')
    psr.add_option('-M', '--trapMsg', action='store', type='string',
                   metavar='STRING', dest='trap_msg',
                   default=(None, 'NOTBLANK', {
                       'WHEN': {'trap_mib!=': None},
                       'DO': ('REQUIRED')}),
                   help='message')
    psr.add_option('-d', '--trapDetail', action='store', type='string',
                   metavar='STRING', dest='trap_detail',
                   default=(None, 'NOTBLANK', {
                       'WHEN': {'trap_mib!=': None},
                       'DO': ('REQUIRED')}),
                   help='detail')
    psr.add_option('-T', '--trapProcessType', action='store', type='string',
                   metavar='STRING', dest='trap_process_type',
                   default=(None, {'INLIST': ['ANY', 'MATCH']}),
                   help='processing type = ANY(notify regardless of the'
                   ' varbind) or MATCH(notify only if the varbind matched)'
                   ' (default: ANY)')
    psr.add_option('-p', '--trapPriority', action='store', type='string',
                   metavar='STRING', dest='trap_priority',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                       'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']}),
                   help='trapPriority = INFO or WARN or CRITICAL or UNKNOWN (default: CRITICAL)')
    psr.add_option('-f', '--varbindFormat', action='store', type='string',
                   metavar='STRING', dest='varbind_format',
                   default=(None, 'NOTBLANK'), help='varbind format')
    psr.add_option('-E', '--trapEnable', action='store', type='string',
                   metavar='STRING', dest='trap_enable',
                   default=None, help='enable=true, disable=false')

    # TODO Presently only one pattern can be added at adding
    psr.add_option('-W', '--varbindPattern', action='store', type='string',
                   metavar='STRING', dest='varbind_pattern',
                   default=(None, 'NOTBLANK', {
                       'WHEN': {'trap_process_type': 'MATCH'},
                       'DO': ('REQUIRED')}),
                   help='match pattern (RegEx)')
    psr.add_option('-X', '--varbindPatternDesc', action='store', type='string',
                   metavar='STRING', dest='varbind_pattern_desc',
                   default=None, help='description')
    psr.add_option('-Y', '--varbindPatternCaseSensitive', action='store',
                   type='string', metavar='BOOL',
                   dest='varbind_pattern_case_sensitive_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='varbindPatternCaseSensitive')
    psr.add_option('-Z', '--varbindPatternProcessType', action='store',
                   type='string', metavar='STRING',
                   dest='varbind_pattern_process_type_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='process when matching =true, or process when'
                   ' not matching =false')
    psr.add_option('-r', '--varbindPatternPriority', action='store',
                   type='string', metavar='STRING',
                   dest='varbind_pattern_priority',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                       'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']}),
                   help='varbindPatternPriority = INFO or WARN or CRITICAL'
                   ' or UNKNOWN (default: CRITICAL)')
    psr.add_option('-e', '--patternEnable', action='store', type='string',
                   metavar='BOOL', dest='pattern_enable_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='enable=true, disable=false')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # Notifications
        notify_infos = []
        if opts.notify_ids is not None:
            notify_infos = []
            notify_id_lst = opts.notify_ids.split(',')
            for a in notify_endpoint.getNotifyList():
                if a.notifyId in notify_id_lst:
                    notify_infos.append(a)
                    notify_id_lst.remove(a.notifyId)
            if 0 < len(notify_id_lst):
                ResultPrinter.warning(
                    'Notify ' + (', '.join(notify_id_lst)) + ' will be ignored!')

        # TRAPs
        trap_value_infos = []
        if opts.trap_mib is not None:
            # Create a varbind match pattern
            var_bind_patterns = []
            if opts.varbind_pattern is not None:
                var_bind_patterns.append(endpoint.create_var_bind_pattern(
                    opts.varbind_pattern,
                    opts.varbind_pattern_desc,
                    opts.varbind_pattern_case_sensitive,
                    opts.varbind_pattern_process_type,
                    opts.varbind_pattern_priority_converted,
                    opts.pattern_enable))

            # Create a trapValueInfo
            trap_process_type = None
            if opts.trap_process_type == 'ANY':
                trap_process_type = 0
            elif opts.trap_process_type == 'MATCH':
                trap_process_type = 1

            trap_value_infos.append(endpoint.create_trap_value_info(
                opts.trap_mib,
                opts.trap_uei,
                opts.trap_oid,
                opts.trap_msg,
                opts.trap_detail,
                opts.trap_ver,
                opts.trap_generic_id,
                opts.trap_specific_id,
                trap_process_type,
                None if opts.trap_priority is None else NotifyUtil.convert2priority(
                    opts.trap_priority),
                opts.varbind_format,
                var_bind_patterns,
                opts.trap_enable))

        ### execute ###
        endpoint.add_monitor_trap(
            opts.monitor_id,
            opts.facility_id,
            opts.calendar_id,
            opts.application,
            opts.description,
            opts.owner_role_id,
            opts.monitor,
            notify_infos,
            opts.check_community_check,
            opts.check_community_name,
            opts.check_charset_convert,
            opts.check_charset_name,
            SettingUtil.convert2nbool(opts.notify_unspecified),
            None if opts.notify_unspecified_priority is None else NotifyUtil.convert2priority(
                opts.notify_unspecified_priority),
            trap_value_infos,
            opts.collect,
            opts.logformat_id)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
