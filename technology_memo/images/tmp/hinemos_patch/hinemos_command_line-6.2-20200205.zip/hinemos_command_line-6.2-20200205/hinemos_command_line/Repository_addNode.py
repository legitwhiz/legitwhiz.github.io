#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ノードを登録する

<概要>
ノードを登録します。
            登録される情報は必須項目のみの為、情報の変更追加を行う場合、modifyNodeを使用してください。

<使用例>
- デバイスサーチ(SNMP)でノードを登録します。
[command]
    $ python Repository_addNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -A 192.168.0.2 -N APITEST_NODE -I APITEST_NODE

[result]
    http://192.168.1.2:8080/HinemosWS/, addNode succeeded.


- ファシリティ名、プラットフォームとノード名を指定してノードを手動(-m)登録します。
[command]
    $ python Repository_addNode.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -m -I NODE001 -N NewNode -A 192.168.0.3 -p LINUX -n new-node

[result]
    http://192.168.1.2:8080/HinemosWS/, addNode succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.common import ResultPrinter

def main():

    psr = MyOptionParser()
    psr.add_option('-A', '--ipAddress', action='store', type='string', metavar='STRING', dest='ip_address',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='IP address')
    psr.add_option('-P', '--port', action='store', type='int', metavar='INT', dest='port',
                    default=161, help='port number (default: 161)')
    psr.add_option('-C', '--community', action='store', type='string', metavar='STRING', dest='community',
                    default=('public', 'NOTBLANK'), help='community name (default: public)')
    psr.add_option('-V', '--snmpVersion', action='store', type='string', metavar='STRING', dest='version',
                    default=(None, {'INLIST':['1', '2c', '3']}), help='version: 1 or 2c or 3 (default: 2c)')
    psr.add_option('-I', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'NOTBLANK'), help='facilityID')
    psr.add_option('-N', '--facilityName', action='store', type='string', metavar='STRING', dest='facility_name',
                    default=(None, 'NOTBLANK'), help='facility Name')
    psr.add_option('-n', '--nodeName', action='store', type='string', metavar='STRING', dest='node_name',
                    default=(None, 'NOTBLANK'), help='node Name')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=('ALL_USERS', 'NOTBLANK'), help='ownerRoleID (default: ALL_USERS)')
    psr.add_option('-p', '--platform', action='store', type='string', metavar='STRING', dest='platform_family',
                    default=(None, 'NOTBLANK'), help='platform')
    psr.add_option('-s', '--subPlatform', action='store', type='string', metavar='STRING', dest='sub_platform_family',
                    default=(None, 'NOTBLANK'), help='sub-platform')
    psr.add_option('-m', '--manual', action='store_false', dest='find_by_snmp', default=True, help='Register manually without SNMP')
    psr.add_option('-S', '--securityLevel', action='store', type='string', metavar='STRING', dest='security_level',
                    default=(None, {'INLIST':['noauth_nopriv', 'auth_nopriv', 'auth_priv']}), help='security level: noauth_nopriv or auth_nopriv or auth_priv (SNMPv3 only)')
    psr.add_option('-u', '--username', action='store', type='string', metavar='STRING', dest='username',
                    default=None, help='username (SNMPv3 only)')
    psr.add_option('-W', '--authPass', action='store', type='string', metavar='STRING', dest='auth_pass',
                    default=None, help='auth pass (SNMPv3 only)')
    psr.add_option('-X', '--privPass', action='store', type='string', metavar='STRING', dest='priv_pass',
                    default=None, help='priv pass (SNMPv3 only)')
    psr.add_option('-Y', '--authProtocol', action='store', type='string', metavar='STRING', dest='auth_protocol',
                    default=(None, {'INLIST':['MD5', 'SHA']}), help='auth protocol: MD5 or SHA (SNMPv3 only)')
    psr.add_option('-Z', '--privProtocol', action='store', type='string', metavar='STRING', dest='priv_protocol',
                    default=(None, {'INLIST':['DES', 'AES']}), help='priv protocol: DES or AES (SNMPv3 only)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit###
        node_info = None
        if opts.find_by_snmp:
            result = endpoint.getNodePropertyBySNMP(opts.ip_address, opts.port, opts.community, opts.version, None, opts.security_level, opts.username, opts.auth_pass, opts.priv_pass, opts.auth_protocol, opts.priv_protocol)
            if result:
                node_info = result.nodeInfo
        else:
            node_info = endpoint.create_node_info(opts.facility_id, opts.facility_name, '', opts.ip_address, '', '', '', '', '')
            node_info.ipAddressVersion = 4 # TODO hard-code

        if node_info:
            if opts.facility_id:
                node_info.facilityId = opts.facility_id
            if opts.facility_name:
                node_info.facilityName = opts.facility_name
            if opts.node_name is not None:
                node_info.nodeName = opts.node_name
            if opts.platform_family is not None:
                node_info.platformFamily = opts.platform_family
            if opts.sub_platform_family is not None:
                node_info.subPlatformFamily = opts.sub_platform_family
            if not hasattr(node_info, 'ownerRoleId'):
                setattr(node_info, 'ownerRoleId', opts.owner_role_id)
            else:
                node_info.ownerRoleId = opts.owner_role_id

            endpoint.addNode(node_info)
            return_code = ResultPrinter.success(None, opts.mgr_url, 'addNode')
        else:
            raise ErrorHandler.APIError('getNodePropertyBySNMP failed!')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
