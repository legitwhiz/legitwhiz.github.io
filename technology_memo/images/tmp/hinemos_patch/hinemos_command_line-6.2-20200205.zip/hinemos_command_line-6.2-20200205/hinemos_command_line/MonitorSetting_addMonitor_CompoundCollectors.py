#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
収集値統合監視設定を登録する

<概要>
収集値統合監視設定を登録します。

<使用例>
[command]
    $ python MonitorSetting_addMonitor_CompoundCollectors.py
[result]
    http://192.168.1.2:8080/HinemosWS/, addMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.util.notify import NotifyUtil
from hinemos.util.monitorsetting import MonitorSettingUtil
from hinemos.util.argsparserbuilder import MonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = MonitorSettingArgsParserBuilder()\
        .build_monitor_setting_add_args_parser(help_default_info,
                                               exclude=['collect'])

    psr.add_option('--timeout',
                   action='store',
                   type='int',
                   metavar='INT',
                   dest='check_timeout',
                   default=60,
                   help='timeout (default: 60[min])')
    psr.add_option('--notCollectOrder',
                   action='store',
                   type='string',
                   metavar='BOOL',
                   dest='check_notOrder_raw',
                   converter=SettingUtil.convert2nbool,
                   default=('false', {'INLIST': ['true', 'false']}),
                   help='do not consider the order of collection'
                   ' (default: false)')
    psr.add_option('--checkMessageOK',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='check_messageOk',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='message OK')
    psr.add_option('--checkMessageNG',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='check_messageNg',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='message NG')
    # judgement conditions
    psr.add_option('--jcDescription',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='jcDescription',
                   default=None,
                   help='judgement condition description')
    psr.add_option('--jcUseMonitoringScope',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='jcMonitorNode_raw',
                   converter=SettingUtil.convert2nbool,
                   default=('true', {'INLIST': ['true', 'false']}),
                   help='use monitoring scope: true/false (default: true)')
    psr.add_option('--jcTagetNode',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='jcTargetFacilityId',
                   default=(None, {
                       'WHEN': {'jcMonitorNode_raw': 'false'},
                       'DO': ('REQUIRED', 'NOTBLANK')
                   }),
                   help='target node ID')
    psr.add_option('--jcCollectType',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='jcTargetMonitorType_raw',
                   converter=MonitorSettingUtil.converter2ccCollectType,
                   default=('numeric', {'INLIST': ['numeric', 'string']}),
                   help='collection type: numeric/string (default: numeric)')
    psr.add_option('--jcTargetMonitorId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='jcTargetMonitorId',
                   default=(None, {
                       'WHEN': {'monitor_raw': 'true'},
                       'DO': ('REQUIRED', 'NOTBLANK')
                   }),
                   help='target monitor ID')
    psr.add_option('--jcComparisonMethod',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='jcComparisonMethod',
                   default=(None, {
                       'WHEN': {'monitor_raw': 'true'},
                       'DO': ('REQUIRED', 'NOTBLANK'),
                       'INLIST': ['=', '>', '<', '>=', '<=']
                   }),
                   help='comparison method: =, >, <, >=, <= (for string colect'
                   ' type only "=" method is avaliable)')
    psr.add_option('--jcComparisonValue',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='jcComparisonValue',
                   default=(None, {
                       'WHEN': {'monitor_raw': 'true'},
                       'DO': ('REQUIRED', 'NOTBLANK')
                   }),
                   help='comparison value')
    psr.add_option('--jcIsAnd',
                   action='store',
                   type='string',
                   metavar='BOOL',
                   dest='jcIsAnd_raw',
                   converter=SettingUtil.convert2nbool,
                   default=('true', {'INLIST': ['true', 'false']}),
                   help='AND=true, OR=false (default: true)')

    # judgement
    psr.add_option('--priorityOK',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='priorityOk_raw',
                   converter=NotifyUtil.convert2priority,
                   default=('INFO', 'NOTBLANK',  {
                       'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']
                   }),
                   help='priority = INFO or WARN or CRITICAL or'
                   ' UNKNOWN (default: INFO)')
    psr.add_option('--priorityNG',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='priorityNg_raw',
                   converter=NotifyUtil.convert2priority,
                   default=('CRITICAL', 'NOTBLANK',  {
                          'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']
                   }),
                   help='priority = INFO or WARN or CRITICAL or'
                   ' UNKNOWN (default: CRITICAL)')
    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    ### login ###
    endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

    try:
        endpoint.add_monitor_compound_collectors(vars(opts))
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMonitor')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    # sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    # sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
