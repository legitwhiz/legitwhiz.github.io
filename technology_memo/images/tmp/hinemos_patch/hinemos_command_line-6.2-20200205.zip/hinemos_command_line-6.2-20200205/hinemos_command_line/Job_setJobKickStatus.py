#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定した、ジョブの実行契機情報の有効/無効を変更する(マニュアル実行契機以外)

<概要>
引数で指定した、ジョブの実行契機情報の有効/無効を変更します。(マニュアル実行契機以外)

<使用例>
[command]
    $ python Job_setJobKickStatus.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_SC -e true

[result]
    http://192.168.1.2:8080/HinemosWS/, setJobKickStatus succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.common import ResultPrinter, SettingUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--jobKickID',  action='store', type='string', metavar='ID', dest='job_kick_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='jobKickID')
    psr.add_option('-e', '--enable', action='store', type='string', metavar='BOOL', dest='enable_raw', converter=SettingUtil.convert2nbool,
                    default=(None, 'REQUIRED', {'INLIST':['true','false']}), help='enable=true, disable=false')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit##
        endpoint.setJobKickStatus(opts.job_kick_id, opts.enable)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'setJobKickStatus')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
