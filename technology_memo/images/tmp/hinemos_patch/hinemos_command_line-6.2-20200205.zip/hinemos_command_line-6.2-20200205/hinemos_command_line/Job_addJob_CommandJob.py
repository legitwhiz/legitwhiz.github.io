#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブの基本情報を登録する

<概要>
ジョブの基本情報を登録します。

<使用例>
[command]
    $ python Job_addJob_CommandJob.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J JU001 -I JOB1 -P JU001 -N Job-1 -F SCOPE01 -C "/root/myscript.sh" -D "job for test"

[result]
    http://192.168.1.2:8080/HinemosWS/, addJob succeeded.
"""

import os
import sys
import codecs, locale
import logging
from logging.config import fileConfig

from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil

def main():
    global LOGGER
    try:
        if not LOGGER:
            LOGGER = logging.getLogger(__name__)
    except NameError:
        LOGGER = logging.getLogger(__name__)

    psr = MyOptionParser()
    psr.add_option('-J', '--jobunitID',  action='store', type='string', metavar='ID', dest='jobunit_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Jobunit ID')
    psr.add_option('-P', '--parentID',  action='store', type='string', metavar='ID', dest='parent_id',
                   default=(None, 'NOTBLANK'), help='Parent job ID')
    psr.add_option('-I', '--jobID',  action='store', type='string', metavar='ID', dest='job_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Job ID')
    psr.add_option('-N', '--jobName', action='store', type='string', metavar='STRING', dest='name',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Job name')

    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='description')

    psr.add_option('-M', '--modularize', action='store', type='string', metavar='BOOL', dest='modularize_raw', converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST':['true','false']}), help='Set as module')
    psr.add_option('--iconID',  action='store', type='string', metavar='ID', dest='iconID',
                   default=None,  help='Icon ID')

    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='facility ID')
    psr.add_option('-C', '--startCommand', action='store', type='string', metavar='STRING', dest='start_command',
                    default=(None, 'REQUIRED', 'NOTBLANK'), help='start command')

    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        # Login
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_tree_full = endpoint.getJobTree('', True)
        job_tree = JobUtil.get_job_unit_tree_item(job_tree_full, opts.jobunit_id)
        del job_tree_full

        # ユニットのロール確保
        owner_role_id = endpoint.getJobFull(job_tree.data).ownerRoleId

        new_job_tree = endpoint.create_job_tree_item_basic(\
                    JobUtil.convert2job_type('JOB'),\
                    opts.jobunit_id,\
                    opts.job_id,\
                    opts.name,\
                    opts.description,\
                    owner_role_id,\
                    opts.modularize,\
                    opts.iconID)
        new_job_tree.data.command = endpoint.create_job_command_info(opts.facility_id, opts.start_command)
        new_job_tree.data.waitRule = endpoint.create_wait_rule_info()

        LOGGER.debug(new_job_tree)

        parent_id = opts.parent_id
        if parent_id is None:
            parent_id = opts.jobunit_id
        added = JobUtil.add_child(job_tree, parent_id, new_job_tree)
        if not added:
            raise ErrorHandler.ArgumentError('Failed to add new job!')

        LOGGER.debug(job_tree)
        endpoint.registerJobunit(job_tree)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addJob')
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    fileConfig(os.path.join(os.path.dirname(__file__), 'logging.ini'))
    LOGGER = logging.getLogger(os.path.splitext(os.path.basename(__file__))[0])

    sys.exit(main())
