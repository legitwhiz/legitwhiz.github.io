#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
パケットキャプチャ監視の監視設定を登録する

<概要>
パケットキャプチャ監視の監視設定を登録します。

<使用例>
[command]
    $ python MonitorSetting_addMonitor_PacketCapture.py

[result]
    http://192.168.1.2:8080/HinemosWS/, addMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.util.argsparserbuilder import MonitorSettingArgsParserBuilder
from hinemos.util.monitorsetting import MonitorSettingUtil as util
from hinemos.util.notify import NotifyUtil


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = MonitorSettingArgsParserBuilder()\
        .build_monitor_setting_add_args_parser(help_default_info,
                                               exclude=['runInterval'])

    psr.add_option('--filter',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='filterStr',
                   default=None,
                   help='filter')
    psr.add_option('--promiscuousMode',
                   action='store',
                   type='string',
                   metavar='BOOL',
                   dest='promiscuousMode_raw',
                   converter=SettingUtil.convert2nbool,
                   default=('false', {'INLIST': ['true', 'false']}),
                   help='enable=true, disable=false (default: false)')
    # judgement definition - only one can be added at first
    psr.add_option('--bfSearch',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='bfgrepString',
                   default=(None,
                            {
                                'WHEN': {'monitor_raw': 'true'},
                                'DO': ('REQUIRED', 'NOTBLANK')
                            }),
                   help='binary filter search text, --bfSearch is REQUIRED to'
                   ' create binary filter')
    psr.add_option('--bfDescription',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='bfDescription',
                   default=None,
                   help='binary filter description')
    psr.add_option('--bfProcessMatched',
                   action='store',
                   type='string',
                   metavar='BOOL',
                   dest='bfprocessType_raw',
                   converter=SettingUtil.convert2nbool,
                   default=('true', {'INLIST': ['true', 'false']}),
                   help='enable=true, disable=false (default: true)')
    psr.add_option('--bfEncoding',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='bfencoding',
                   default='UTF-8',
                   help='binary filter encoding (default: UTF-8)')
    psr.add_option('--bfPriority',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='bfpriority_raw',
                   converter=NotifyUtil.convert2priority,
                   default=(NotifyUtil._priorities_[0], 'NOTBLANK',
                            {'INLIST': NotifyUtil._priorities_}),
                   help='binary filter priority: %s (default: %s)'
                   % (NotifyUtil._priorities_[:4], NotifyUtil._priorities_[0]))
    psr.add_option('--bfMsg',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='bfmessage',
                   default='#[BINARY_LINE]',
                   help='binary filter message (default: #[BINARY_LINE])')
    psr.add_option('--bfEnable',
                   action='store',
                   type='string',
                   metavar='BOOL',
                   dest='bfvalidFlg_raw',
                   converter=SettingUtil.convert2nbool,
                   default=('true', {'INLIST': ['true', 'false']}),
                   help='enable=true, disable=false (default: true)')
    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    ### login ###
    endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

    try:
        endpoint.add_monitor_packet_capture(vars(opts))
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addMonitor')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    # sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    # sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
