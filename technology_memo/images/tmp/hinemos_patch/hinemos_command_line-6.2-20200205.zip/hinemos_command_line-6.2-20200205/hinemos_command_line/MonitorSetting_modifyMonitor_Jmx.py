#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
JMX監視の監視設定情報を変更する

<概要>
JMX監視の監視設定情報を変更します。

<使用例>
[command]
    $ python MonitorSetting_modifyMonitor_Jmx.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I JMX1 -A MYAPP -F SCOPE001 -M JMX_CLASS_LOADING_LOADED_CLASS_COUNT -x 4321 -c false

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
import os
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.notify import NotifyUtil
from hinemos.util.modifier import ObjectModifier
from hinemos.api.jmxmaster import JmxMasterEndpoint
from hinemos.util.argsparserbuilder import NumericMonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = NumericMonitorSettingArgsParserBuilder()\
        .build_numeric_monitor_setting_modify_args_parser(help_default_info)

    psr.add_option('-M', '--monitorItem', action='store', type='string',
                   metavar='STRING', dest='master_id',
                   default=(None, 'NOTBLANK'),
                   help='monitor item. (e.g. JMX_CLASS_LOADING_LOADED_CLASS_COUNT,'
                   'JMX_CLASS_LOADING_TOTAL_LOADED_CLASS_COUNT, etc.)')
    psr.add_option('-x', '--jmxPort', action='store', type='int',
                   metavar='INT', dest='port', default=None, help='JMX port')
    psr.add_option('-j', '--authUser', action='store', type='string',
                   metavar='STRING', dest='auth_user', default=None,
                   help='authentication username')
    psr.add_option('-k', '--authPassword', action='store', type='string',
                   metavar='STRING', dest='auth_password', default=None,
                   help='authentication password')
    psr.add_option('-f', '--calculateDiff', action='store', type='string',
                   metavar='STRING', dest='cal_diff_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='calculate difference from previous result =true,'
                   ' do nothing =false')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        # Check JMX master list at first
        if opts.master_id is not None:
            endpoint = JmxMasterEndpoint(opts.mgr_url, opts.user, opts.passwd)
            jmx_master_info_list = endpoint.get_jmx_master_info_list()
            for x in jmx_master_info_list:
                if x.id == opts.master_id:
                    if opts.item_name is None:
                        opts.item_name = x.name
                    if opts.unit is None:
                        opts.unit = x.measure
                    break
            else:
                print 'monitorItem must be one of: ' + os.linesep + os.linesep.join(('\t%s (%s)' % (x.id, x.name)) for x in jmx_master_info_list)
                raise ErrorHandler.ObjectNotFoundError(
                    'the specified monitorItem(%s) does not existed!' % opts.master_id)

        # login
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # monitor_info
        monitor_info = endpoint.getMonitor(opts.monitor_id)

        # Modification
        with ObjectModifier(monitor_info) as modifier:
            endpoint.update_common_infos(modifier, vars(opts))
            endpoint.update_collect_infos(modifier, vars(opts))
            endpoint.update_prediction_info(modifier, vars(opts))
            endpoint.update_change_info(modifier, vars(opts))
            endpoint.updete_judgement_tresholds(modifier, vars(opts))

            modifier.change_ptr('jmxCheckInfo')
            modifier.set_if_first_not_none('masterId', opts.master_id)
            modifier.set_if_first_not_none('port', opts.port)
            modifier.set_if_first_not_none('authUser', opts.auth_user)
            modifier.set_if_first_not_none('authPassword', opts.auth_password)
            modifier.set_if_first_not_none('convertFlg', opts.cal_diff)

        endpoint.update_notify_ids_info(monitor_info, vars(opts))

        endpoint.modifyMonitor(monitor_info)
        return_code = ResultPrinter.success(
            None, opts.mgr_url, 'modifyMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
