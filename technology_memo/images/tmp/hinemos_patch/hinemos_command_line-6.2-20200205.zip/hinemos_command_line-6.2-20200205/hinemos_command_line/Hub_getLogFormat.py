#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したログフォーマットIDに対応するログフォーマットを取得する

<概要>
引数で指定したログフォーマットIDに対応するログフォーマットを取得して表示します。

<使用例>
[command]
    $ python Hub_getLogFormat.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I TEST_LOGFORMAT

[result]
    (logFormat){
       ownerRoleId = "ALL_USERS"
       description = "test_logformat"
       logFormatId = "TEST_LOGFORMAT"
       regDate = "2017/03/07 16:10:09.548"
       regUser = "hinemos"
       timestampFormat = "2017-03-01 00:00:00"
       timestampRegex = ".*"
       updateDate = "2017/03/07 16:10:09.548"
       updateUser = "hinemos"
     }
    http://192.168.1.2:8080/HinemosWS/, getLogFormat succeeded.
"""

import sys
import codecs, locale
from hinemos.util.opt import MyOptionParser
from hinemos.util.common import DateConvert, ResultPrinter
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.hub import HubEndpoint

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--logFormatID',  action='store', type='string', metavar='ID', dest='logformat_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='LogFormatID')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = HubEndpoint(opts.mgr_url, opts.user, opts.passwd)

        result = endpoint.getLogFormat(opts.logformat_id)
        if result is not None:
            result.regDate = DateConvert.get_datetime_from_epochtime(result.regDate)
            result.updateDate = DateConvert.get_datetime_from_epochtime(result.updateDate)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getLogFormat')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
