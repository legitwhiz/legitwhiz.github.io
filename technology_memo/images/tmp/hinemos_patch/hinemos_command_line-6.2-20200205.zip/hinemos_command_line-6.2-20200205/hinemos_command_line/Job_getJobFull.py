#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
引数で指定したジョブのジョブツリー情報を取得する

<概要>
引数で指定したジョブのジョブツリー情報を取得して表示します。

<使用例>
[command]
    $ python Job_getJobFull.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -J TEST_JOBU/TEST_JOB

[result]
    (jobInfo){
       abnormalPriority = 0
       approvalReqMailBody = None
       approvalReqMailTitle = None
       approvalReqRoleId = None
       approvalReqSentence = None
       approvalReqUserId = None
       beginPriority = 3
       command =
          (jobCommandInfo){
             commandRetry = 10
             commandRetryFlg = False
             facilityID = "hinemos60_rhel7"
             managerDistribution = False
             messageRetry = 10
             messageRetryEndFlg = True
             messageRetryEndValue = -1
             processingMethod = 0
             scope = "hinemos60_rhel7"
             specifyUser = False
             startCommand = "sleep 10"
             stopType = 1
          }
       createTime = "2017/03/01 17:11:03.692"
       createUser = "hinemos"
        ...中略...
             skip = False
             skipEndStatus = 2
             skipEndValue = 0
             start_delay = False
             start_delay_condition_type = 0
             start_delay_notify = False
             start_delay_notify_priority = 0
             start_delay_operation = False
             start_delay_operation_end_status = 2
             start_delay_operation_end_value = -1
             start_delay_operation_type = 4
             start_delay_session = False
             start_delay_session_value = 1
             start_delay_time = False
             start_delay_time_value = "09:00:00"
             suspend = False
          }
       warnPriority = 2
     }
    http://192.168.1.2:8080/HinemosWS/, getJobFull succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.job import JobEndpoint
from hinemos.util.job import JobUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-J', '--job', action='store', type='string', metavar='STRING', dest='job',
                    default=(None, 'REQUIRED','NOTBLANK',{'REGEXP':(r'[-.@\w]+(/[-.@\w]+|)$',' must be in format "jobunitID/jobID"!')}), help='job = "jobunitID/jobID" or "jobunitID/jobnetID" or "jobunitID"')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### jobInfo Parameter ###
        job_map = JobUtil.convert2job(opts.job)

        result = JobUtil.get_job(endpoint, job_map['jobunitId'], job_map['jobId'])
        if result is not None:
            if 'createTime' in result:
                result.createTime = DateConvert.get_datetime_from_epochtime(result.createTime)
                result.updateTime = DateConvert.get_datetime_from_epochtime(result.updateTime)

            if job_map['jobunitId'] != job_map['jobId']:
                if 'end_delay_time_value' in result.waitRule:
                    result.waitRule.end_delay_time_value = DateConvert.get_time48_from_epochtime(result.waitRule.end_delay_time_value)
                if 'start_delay_time_value' in result.waitRule:
                    result.waitRule.start_delay_time_value = DateConvert.get_time48_from_epochtime(result.waitRule.start_delay_time_value)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getJobFull')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
