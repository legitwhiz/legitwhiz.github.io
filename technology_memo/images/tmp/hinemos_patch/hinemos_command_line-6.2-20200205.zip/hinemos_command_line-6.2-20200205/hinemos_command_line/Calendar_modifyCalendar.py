#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
指定したカレンダのカレンダ情報を変更する

<概要>
指定したカレンダのカレンダ情報を変更します。

<使用例>
- カレンダ詳細を追加します。
[command]
    $ python Calendar_modifyCalendar.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I CAL001 -a ADD -e "2017/03 Daily"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyCalendar succeeded.


- カレンダ詳細を変更します。
[command]
    $ python Calendar_modifyCalendar.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I CAL001 -a MOD -z 1 -e "2017/03/20"

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyCalendar succeeded.


- カレンダ詳細を削除します。
[command]
    $ python Calendar_modifyCalendar.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I CAL001 -a DEL -z 1

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyCalendar succeeded.
"""

import sys
import codecs, locale
from hinemos.util.common import DateConvert, ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser

import hinemos.api.exceptions as ErrorHandler
from hinemos.api.calendar import CalendarEndpoint
from hinemos.util.modifier import ObjectModifier
from hinemos.util.calendar import CalendarUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='calendar ID')
    psr.add_option('-N', '--calendarName', action='store', type='string', metavar='STRING', dest='calendar_name',
                    default=None, help='calendar Name')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default=None, help='description')
    psr.add_option('-F', '--validTimeFrom', action='store', type='string', metavar='STRING', dest='valid_time_from_raw', converter=DateConvert.get_epochtime_from_datetime,
                   default=(None, {'REGEXP':[r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}), help='valid time from = \'yyyy/MM/dd HH:mm:ss\'')
    psr.add_option('-T', '--validTimeTo', action='store', type='string', metavar='STRING', dest='valid_time_to_raw', converter=DateConvert.get_epochtime_from_datetime,
                   default=(None, {'REGEXP':[r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$', 'must be in datetime format']}), help='valid time to = \'yyyy/MM/dd HH:mm:ss\'')

    psr.add_option('-a', '--detailAction', action='store', type='string', metavar='MODE', dest='action',
                    default=(None, {'INLIST':['ADD', 'MOD', 'DEL']}), help='add a detail setting = ADD, modify a detail = MOD, delete a detail = DEL')
    psr.add_option('-z', '--detailNo', action='store', type='int', metavar='INT', dest='detail_n',
                    default=(None, {'WHEN':[{'action':'MOD'},{'action':'DEL'}], 'DO':('REQUIRED')}), help='detail orderNo')
    psr.add_option('-y', '--detailNewNo', action='store', type='int', metavar='INT', dest='detail_n_new',
                    default=None, help='change detail order to detailNewNo')

    psr.add_option('-d', '--detailDescription', action='store', type='string', metavar='STRING', dest='detail_description',
                   help='detailDescription')
    psr.add_option('-e', '--detail', action='store', type='string', metavar='STRING', dest='detail',
                    default=(None, 'NOTBLANK', {'REGEXP':[r'(Yearly|\d{4})[/ ](Monthly|\w+)[ /](Daily|\d{1,2}|Every-\w+|[1-5]-\w+|Pattern [^\s]+)$', 'format incorrect!']}, {'WHEN':{'action':'ADD'},'DO':('REQUIRED')}),
                    help='format : "$YEAR $MONTH $DAY/$PATTERN". e.g. "Yearly Monthly Daily", "1998/12 Daily", "Yearly 01 Pattern holiday2013-2020", "2015 Monthly 30", "2015/02/28", "2015/12 Every-Sun", "2015/12 1-Sun"')
# Detail examples:
#     "Yearly Monthly Daily"
#     "1998/12 Daily"
#     "Yearly 01 Pattern holiday2013-2020"
#     "2015 Monthly 30"
#     "2015/02/28"
#     "2015/12 Every-Sun"
#     "2015/12 1-Sun"

    psr.add_option('-p', '--dayAfter', action='store', type='int', metavar='INT', dest='afterday',
                   default=None, help='day after. A negative (\'-\') integer means day(s) before')
    psr.add_option('-f', '--substituteFlg', action='store', type='string', metavar='BOOL', dest='substitute_flg_raw', converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='substituteFlg =true, non-substituteFlg =false')
    psr.add_option('-l', '--substituteLimit', action='store', type='int', metavar='INT', dest='substitute_limit',
                    default=None, help='substituteLimit = integer')
    psr.add_option('-m', '--substituteTime', action='store', type='int', metavar='INT', dest='substitute_time',
                    default=None, help='substituteTime = integer')
    psr.add_option('-s', '--timeFrom', action='store', type='string', metavar='STRING', dest='time_from_raw', converter=DateConvert.get_epochtime_from_time,
                    default=(None,{'REGEXP':[r'^\d\d:\d\d:\d\d$', 'format must be HH:MM:SS']}), help='time from =  HH:mm:ss')
    psr.add_option('-t', '--timeTo', action='store', type='string', metavar='STRING', dest='time_to_raw', converter=DateConvert.get_epochtime_from_time,
                    default=(None, {'REGEXP':[r'^\d\d:\d\d:\d\d$', 'format must be HH:MM:SS']}), help='time to = HH:mm:ss')
    psr.add_option('-o', '--operational', action='store', type='string', metavar='BOOL', dest='operational_raw', converter=SettingUtil.convert2nbool,
                    default=(None, {'INLIST':['true','false']}), help='operational =true, non-operational =false')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = CalendarEndpoint(opts.mgr_url, opts.user, opts.passwd)

        calendar_info = endpoint.getCalendar(opts.calendar_id)

        # Modification
        with ObjectModifier(calendar_info) as modifier:
            modifier.set_if_first_not_none('calendarName', opts.calendar_name)
            modifier.set_if_first_not_none('description', opts.description)
            modifier.set_if_first_not_none('validTimeFrom', opts.valid_time_from)
            modifier.set_if_first_not_none('validTimeTo', opts.valid_time_to)

        if opts.action == 'ADD':
            if not hasattr(calendar_info, 'calendarDetailList'):
                setattr(calendar_info, 'calendarDetailList', [])
            pattern = endpoint.create_calendar_detail_info(opts.detail_description, opts.afterday, opts.substitute_flg, opts.substitute_limit, opts.substitute_time, opts.time_from, opts.time_to, opts.operational)
            CalendarUtil.set_calendar_ymddetail(pattern, opts.detail)
            if opts.detail_n is None:
                calendar_info.calendarDetailList.append(pattern)
            else:
                calendar_info.calendarDetailList.insert(opts.detail_n-1, pattern)

        elif opts.action == 'MOD':
            if not hasattr(calendar_info, 'calendarDetailList') or opts.detail_n < 1 or opts.detail_n > len(calendar_info.calendarDetailList):
                raise ErrorHandler.ObjectNotFoundError('CalendarDetail(no=%d) does not exist!' % opts.detail_n)
            else:
                pattern_info = calendar_info.calendarDetailList[opts.detail_n-1]
                ObjectModifier.replace_if_not_none(pattern_info,\
                        description = opts.detail_description,\
                        afterday = opts.afterday,\
                        substituteFlg = opts.substitute_flg,\
                        substituteLimit = opts.substitute_limit,\
                        substituteTime = opts.substitute_time,\
                        timeFrom = opts.time_from,\
                        timeTo = opts.time_to,\
                        operateFlg = opts.operational)
                if opts.detail:
                    CalendarUtil.set_calendar_ymddetail(pattern_info, opts.detail)

                # Change order
                if opts.detail_n_new is not None:
                    calendar_info.calendarDetailList.insert(\
                        opts.detail_n_new-1, calendar_info.calendarDetailList.pop(opts.detail_n-1))

        elif opts.action == 'DEL':
            if not hasattr(calendar_info, 'calendarDetailList') or opts.detail_n < 1 or opts.detail_n > len(calendar_info.calendarDetailList):
                raise ErrorHandler.ObjectNotFoundError('CalendarDetail(no=%d) does not exist!' % opts.detail_n)
            else:
                del calendar_info.calendarDetailList[opts.detail_n-1]

        endpoint.modifyCalendar(calendar_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyCalendar')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
