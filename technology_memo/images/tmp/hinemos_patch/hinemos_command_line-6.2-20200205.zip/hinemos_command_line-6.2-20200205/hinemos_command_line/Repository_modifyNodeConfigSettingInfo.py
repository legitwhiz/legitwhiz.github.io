#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
構成情報取得設定を変更する

<概要>
構成情報取得設定を変更します。

<使用例>
- 構成情報取得設定を変更します。
[command]
    $ python Repository_modifyNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING -N "Modified Setting" -F LINUX -D "Modified Test Description" -n 12h -v false

[result]
    http://127.0.0.1:8080/HinemosWS/, modifyNodeConfigSettingInfo succeeded.

- 「基本情報」設定を追加します。
[command]
    $ python Repository_modifyNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING -i OS,PACKAGE

[result]
    http://127.0.0.1:8080/HinemosWS/, modifyNodeConfigSettingInfo succeeded.

- 「基本情報」設定を削除します。
[command]
    $ python Repository_modifyNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING -e OS,PACKAGE

[result]
    http://127.0.0.1:8080/HinemosWS/, modifyNodeConfigSettingInfo succeeded.

- 「通知オプション」設定を追加します。
[command]
    $ python Repository_modifyNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING -a event01,status01

[result]
    http://127.0.0.1:8080/HinemosWS/, modifyNodeConfigSettingInfo succeeded.

- 「通知オプション」設定を削除します。
[command]
    $ python Repository_modifyNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING -d event01,status01

[result]
    http://127.0.0.1:8080/HinemosWS/, modifyNodeConfigSettingInfo succeeded.

- 「ユーザ任意情報」設定を追加します。
[command]
    $ python Repository_modifyNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING --userOptionAction ADD --customId TEST_CUSTOM_SETTING --customName "Test Custom Setting"
    --command "ls -la" --customValidFlg true --specifyUser false

[result]
    http://127.0.0.1:8080/HinemosWS/, modifyNodeConfigSettingInfo succeeded.

- 「ユーザ任意情報」設定を変更します。
[command]
    $ python Repository_modifyNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING --userOptionAction MOD --customId TEST_CUSTOM_SETTING --customName "Modified Custom Setting"
    --command "echo Hello" --customValidFlg false --specifyUser true --effectiveUser hinemos

[result]
    http://127.0.0.1:8080/HinemosWS/, modifyNodeConfigSettingInfo succeeded.

- 「ユーザ任意情報」設定を削除します。
[command]
    $ python Repository_modifyNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING --userOptionAction DEL --customId TEST_CUSTOM_SETTING

[result]
    http://127.0.0.1:8080/HinemosWS/, modifyNodeConfigSettingInfo succeeded.

"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
from hinemos.api.repository import RepositoryEndpoint
from hinemos.api.notify import NotifyEndpoint
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.modifier import ObjectModifier


def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--settingId',  action='store', type='string', metavar='ID', dest='setting_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Node Configuration Setting ID')
    psr.add_option('-N', '--settingName', action='store', type='string', metavar='STRING', dest='setting_name',
                   default=(None, 'NOTBLANK'), help='Node Configuration Setting name')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                   default=None, help='Node Configuration Setting Description')
    psr.add_option('-F', '--facilityId',  action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None, 'NOTBLANK'), help='Facility ID')
    psr.add_option('-n', '--runInterval', action='store', type='string', metavar='STRING', dest='run_interval_raw',
                   converter=SettingUtil.convert2sec, default=(None, {'INLIST': ['6h', '12h', '24h']}),
                   help='Run Interval(6h, 12h, 24h)')
    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id', default=None,
                   help='Calendar ID')
    psr.add_option('-v', '--validFlg', action='store', type='string', metavar='BOOL', dest='valid_flg_raw',
                   converter=SettingUtil.convert2nbool, default=(None, {'INLIST': ['true', 'false']}),
                   help='Enable Setting=true, Disable Setting=false')

    # 基本情報オプション
    psr.add_option('-i', '--addSettingItemIds', action='store_split', type='string', metavar='STRING',
                   dest='add_setting_item', default=None,
                   help='Add Configuration Setting IDs. settingItemIds = SettingID1,SettingID2,...,SettingIDN'
                        ' HOSTNAME,HW_MEMORY,NETSTAT,HW_CPU,PACKAGE,HW_NIC,PROCESS,OS,HW_FILESYSTEM,HW_DISK')
    psr.add_option('-e', '--deleteSettingItemIds', action='store_split', type='string', metavar='STRING',
                   dest='delete_setting_item', default=None,
                   help='Delete Configuration Setting IDs. settingItemIds = SettingID1,SettingID2,...,SettingIDN'
                        ' HOSTNAME,HW_MEMORY,NETSTAT,HW_CPU,PACKAGE,HW_NIC,PROCESS,OS,HW_FILESYSTEM,HW_DISK')

    # 通知オプション
    psr.add_option('-a', '--addNotifyIDs', action='store_split', type='string', metavar='STRING', dest='add_notify_ids',
                   default=None, help='Add Notifications. addNotifyIDs = notifyID1,notifyID2,...,notifyIDN')
    psr.add_option('-d', '--deleteNotifyIDs', action='store_split', type='string', metavar='STRING',
                   dest='del_notify_ids', default=None,
                   help='Delete Notifications. deleteNotifyIDs = notifyID1,notifyID2,...,notifyIDN')

    # ユーザ任意情報オプション
    psr.add_option('--userOptionAction', action='store', type='string', metavar='MODE', dest='action',
                   default=(None, {'INLIST': ['ADD', 'MOD', 'DEL']}), help='userOptionAction = ADD or MOD or DEL')
    psr.add_option('--customId', action='store', type='string', metavar='STRING', dest='custom_id',
                   default=(None, 'NOTBLANK',
                            {'WHEN': [{'action': 'ADD'}, {'action': 'MOD'}, {'action': 'DEL'}], 'DO': 'REQUIRED'}),
                   help='ID Of Custom Info Setting. Required when userOptionAction=ADD or MOD or DEL')
    psr.add_option('--command', action='store', type='string', metavar='STRING', dest='command',
                   default=(None, 'NOTBLANK', {'WHEN': [{'action': 'ADD'}], 'DO': 'REQUIRED'},
                            {'WHEN': [{'action': 'MOD'}], 'DO': ()}),
                   help='Command for Custom Info Setting. Required when userOptionAction=ADD')
    psr.add_option('--customName', action='store', type='string', metavar='STRING', dest='custom_name',
                   default=(None, 'NOTBLANK', {'WHEN': [{'action': 'ADD'}], 'DO': 'REQUIRED'},
                            {'WHEN': [{'action': 'MOD'}], 'DO': ()}),
                   help='Name Of Custom Info Setting. Required when userOptionAction=ADD')
    psr.add_option('--customValidFlg', action='store', type='string', metavar='BOOL', dest='custom_valid_flg_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']},
                            {'WHEN': [{'action': 'ADD'}, {'action': 'MOD'}], 'DO': ()}),
                   help='Enable Custom Setting=true, Disable Custom Setting=false')
    psr.add_option('--specifyUser', action='store', type='string', metavar='BOOL', dest='specify_user_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']},
                            {'WHEN': [{'action': 'ADD'}, {'action': 'MOD'}], 'DO': ()}),
                   help='Specify User for Custom Setting=true')
    psr.add_option('--effectiveUser', action='store', type='string', metavar='STRING', dest='effective_user',
                   default=(None, {'WHEN': [{'specify_user_raw': 'true'}], 'DO': 'REQUIRED'}),
                   help='User for Custom Setting. Required when specifyUser=true')
    psr.add_option('--customDescription', action='store', type='string', metavar='STRING', dest='custom_description',
                   default=(None, {'WHEN': [{'action': 'ADD'}, {'action': 'MOD'}], 'DO': ()}),
                   help='Description of Custom Info Setting')

    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        node_config_setting = endpoint.getNodeConfigSettingInfo(opts.setting_id)
        if node_config_setting is None:
            raise ErrorHandler.ArgumentError('modifyNodeConfigSettingInfo failed, ' + 'setting id ' + opts.setting_id +
                                             ' does not exist')

        ObjectModifier.replace_if_not_none(
            node_config_setting,
            calendarId=opts.calendar_id,
            description=opts.description,
            facilityId=opts.facility_id,
            runInterval=opts.run_interval,
            settingName=opts.setting_name,
            validFlg=opts.valid_flg)

        # 構成情報取得対象設定変更
        if opts.add_setting_item_converted is not None:
            if not hasattr(node_config_setting, 'nodeConfigSettingItemList'):
                setattr(node_config_setting, 'nodeConfigSettingItemList', [])

            ids = set(opts.add_setting_item_converted)
            existed_ids = tuple(
                [setting_item.settingItemId for setting_item in node_config_setting.nodeConfigSettingItemList])

            for item_id in filter((lambda item_id: item_id not in existed_ids), ids):
                node_config_setting.nodeConfigSettingItemList.append(
                    endpoint.create_node_config_setting_item_info(item_id))

        if opts.delete_setting_item_converted is not None and hasattr(node_config_setting, 'nodeConfigSettingItemList')\
                and (len(node_config_setting.nodeConfigSettingItemList) > 0):
            ids = set(opts.delete_setting_item_converted)
            del_item_len = len(ids)
            for i in reversed(xrange(len(node_config_setting.nodeConfigSettingItemList))):
                if node_config_setting.nodeConfigSettingItemList[i].settingItemId in ids:
                    del_item_len = del_item_len - 1
                    del node_config_setting.nodeConfigSettingItemList[i]
            if del_item_len > 0:
                raise ErrorHandler.ArgumentError('Invalid custom config ID provided for deletion')

        # 通知設定変更
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)
        if opts.add_notify_ids_converted is not None:
            if not hasattr(node_config_setting, 'notifyRelationList'):
                setattr(node_config_setting, 'notifyRelationList', [])

            ids = set(opts.add_notify_ids_converted)
            existed_ids = tuple(
                [notify_relation.notifyId for notify_relation in node_config_setting.notifyRelationList])

            for notify_id in filter((lambda notify_id: notify_id not in existed_ids), ids):
                node_config_setting.notifyRelationList.append(
                    endpoint.create_notify_relation_info(notify_endpoint.getNotify(notify_id),
                                                         node_config_setting.settingId))

        if opts.del_notify_ids_converted is not None and hasattr(node_config_setting, 'notifyRelationList') \
                and (len(node_config_setting.notifyRelationList) > 0):
            ids = set(opts.del_notify_ids_converted)
            del_item_len = len(ids)
            for i in reversed(xrange(len(node_config_setting.notifyRelationList))):
                if node_config_setting.notifyRelationList[i].notifyId in ids:
                    del_item_len = del_item_len - 1
                    del node_config_setting.notifyRelationList[i]
            if del_item_len > 0:
                raise ErrorHandler.ArgumentError('Invalid notification ID provided for deletion')

        # ユーザ任意情報設定変更
        if opts.action == 'ADD':
            specify_user = False
            custom_valid_flg = True
            custom_description = ''
            if opts.specify_user is not None:
                specify_user = opts.specify_user
            if opts.custom_valid_flg is not None:
                custom_valid_flg = opts.custom_valid_flg
            if opts.custom_description is not None:
                custom_description = opts.custom_description

            custom_config_info = endpoint.create_node_custom_config_info(
                opts.custom_id,
                opts.custom_name,
                custom_description,
                opts.command,
                custom_valid_flg,
                specify_user,
                opts.effective_user)

            if not hasattr(node_config_setting, 'nodeConfigCustomList'):
                setattr(node_config_setting, 'nodeConfigCustomList', [custom_config_info])
            else:
                node_config_setting.nodeConfigCustomList.append(custom_config_info)

            if not hasattr(node_config_setting, 'nodeConfigSettingItemList'):
                setattr(node_config_setting, 'nodeConfigSettingItemList', [])
            ids = {'CUSTOM'}
            existed_ids = tuple(
                [setting_item.settingItemId for setting_item in node_config_setting.nodeConfigSettingItemList])
            for item_id in filter((lambda item_id: item_id not in existed_ids), ids):
                node_config_setting.nodeConfigSettingItemList.append(
                    endpoint.create_node_config_setting_item_info(item_id))

        elif opts.action == 'MOD':
            custom_config_info = None
            if hasattr(node_config_setting, 'nodeConfigCustomList'):
                for i in reversed(xrange(len(node_config_setting.nodeConfigCustomList))):
                    if node_config_setting.nodeConfigCustomList[i].settingCustomId == opts.custom_id:
                        custom_config_info = node_config_setting.nodeConfigCustomList[i]
                        break
            if custom_config_info is None:
                raise ErrorHandler.ArgumentError('Custom Config Info For "%s" not found!' % opts.custom_id)

            ObjectModifier.replace_if_not_none(
                custom_config_info,
                displayName=opts.custom_name,
                description=opts.custom_description,
                command=opts.command,
                specifyUser=opts.specify_user,
                effectiveUser=opts.effective_user,
                validFlg=opts.custom_valid_flg
            )

            if opts.specify_user is False:
                custom_config_info.effectiveUser = None

        elif opts.action == 'DEL':
            custom_config_info = None
            if hasattr(node_config_setting, 'nodeConfigCustomList'):
                for i in reversed(xrange(len(node_config_setting.nodeConfigCustomList))):
                    if node_config_setting.nodeConfigCustomList[i].settingCustomId == opts.custom_id:
                        custom_config_info = node_config_setting.nodeConfigCustomList[i]
                        del node_config_setting.nodeConfigCustomList[i]
                        break
            if custom_config_info is None:
                raise ErrorHandler.ArgumentError('Custom Config Info For "%s" not found!' % opts.custom_id)

            if hasattr(node_config_setting, 'nodeConfigSettingItemList') and \
                    (len(node_config_setting.nodeConfigSettingItemList) > 0) and \
                    (len(node_config_setting.nodeConfigCustomList) == 0):
                ids = {'CUSTOM'}
                for i in reversed(xrange(len(node_config_setting.nodeConfigSettingItemList))):
                    if node_config_setting.nodeConfigSettingItemList[i].settingItemId in ids:
                        del node_config_setting.nodeConfigSettingItemList[i]

        # 変更実行
        endpoint.modifyNodeConfigSettingInfo(node_config_setting)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyNodeConfigSettingInfo')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
