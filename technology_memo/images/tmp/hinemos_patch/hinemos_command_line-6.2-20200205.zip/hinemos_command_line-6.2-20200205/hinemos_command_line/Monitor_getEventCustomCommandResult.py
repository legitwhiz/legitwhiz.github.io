#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
イベントカスタムコマンドの実行結果を取得する

<概要>
イベントカスタムコマンドの実行結果を取得します。

<使用例>
[command]
    $ python Monitor_getEventCustomCommandResult.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I d54198f3-f14d-45c8-a84b-a7915d10e29b

[result]
    (eventCustomCommandResultRoot){
       commandEndTime = "2019/04/22 18:55:24.131"
       commandKickTime = "2019/04/22 18:55:24.098"
       commandNo = 2
       commandStartTime = "2019/04/22 18:55:24.098"
       count = 1
       eventResultList[] =
          (eventCustomCommandResult){
             endTime = "2019/04/22 18:55:24.127"
             event =
                (eventDataInfo){
                   facilityId = "INTERNAL"
                   monitorDetailId = None
                   monitorId = "SYS"
                   outputDate = "2019/04/22 11:36:20.510"
                   pluginId = "MNG"
                }
             message = "$[MESSAGE_EVENT_CUSTOM_COMMAND_OUT:"Hello World
    ":""]"
             returnCode = 0
             startTime = "2019/04/22 18:55:24.099"
             status = 1
          },
     }

    http://127.0.0.1:8080/HinemosWS/, getEventCustomCommandResult succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.monitor import MonitorEndpoint
from hinemos.util.common import DateConvert, ResultPrinter


def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--commandResultId',  action='store', type='string', metavar='ID', dest='command_result_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='Command Result ID obtained after executing Monitor_execEventCustomCommand.py')
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = MonitorEndpoint(opts.mgr_url, opts.user, opts.passwd)
        result = endpoint.getEventCustomCommandResult(opts.command_result_id)

        if result is not None:
            if 'commandEndTime' in result:
                result.commandEndTime = DateConvert.get_datetime_from_epochtime(result.commandEndTime)
            if 'commandKickTime' in result:
                result.commandKickTime = DateConvert.get_datetime_from_epochtime(result.commandKickTime)
            if 'commandStartTime' in result:
                result.commandStartTime = DateConvert.get_datetime_from_epochtime(result.commandStartTime)
            if 'eventResultList' in result:
                for custom_command_result in result.eventResultList:
                    if 'startTime' in custom_command_result:
                        custom_command_result.startTime = DateConvert.get_datetime_from_epochtime(
                            custom_command_result.startTime)
                    if 'endTime' in custom_command_result:
                        custom_command_result.endTime = DateConvert.get_datetime_from_epochtime(
                            custom_command_result.endTime)
                    if 'event' in custom_command_result and hasattr(custom_command_result.event, 'outputDate'):
                        custom_command_result.event.outputDate = DateConvert.get_datetime_from_epochtime(
                            custom_command_result.event.outputDate)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getEventCustomCommandResult')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
