#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# ---------------------------------------------------
# Hinemos Command-Line Tools Suite
# Copyright (c) 2018 NTT DATA INTELLILINK Corporation
# ---------------------------------------------------
u"""
プリセットのリストを取得する

<概要>
プリセットのリストを取得します。

<使用例>
[command]
    $ python Binary_getPresetList.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    http://192.168.1.2:8080/HinemosWS/, getPresetList succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale

from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.binary import BinaryEndpoint


def parse_options(opt_list):
    psr = MyOptionParser()
    psr.add_option('--detailed',
                   action='store_true',
                   metavar='FLG',
                   dest='detailed',
                   default=False,
                   help='show data structure details')

    return psr.parse_opts(opt_list)


def main():
    opts = vars(parse_options(sys.argv))

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        endpoint = BinaryEndpoint(
            opts['mgr_url'], opts['user'], opts['passwd'])

        result = endpoint.getPresetList()
        if result:
            if opts['detailed'] is True:
                print(result)
            else:
                print([preset['tagType'] for preset in result])

        return_code = ResultPrinter.success(
            None, opts['mgr_url'], 'getPresetList')
    except Exception, exc:
        return_code = ResultPrinter.failure(exc)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)
    sys.exit(main())
