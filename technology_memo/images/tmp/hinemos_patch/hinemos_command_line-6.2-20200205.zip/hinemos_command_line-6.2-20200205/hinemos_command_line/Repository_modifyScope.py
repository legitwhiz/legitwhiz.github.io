#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
スコープの情報を変更する

<概要>
スコープの情報を変更します。

<使用例>
[command]
    $ python Repository_modifyScope.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -F TEST_SCOPE -N TEST_SCOPE1

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyScope succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs, locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.common import ResultPrinter

def main():

    psr = MyOptionParser()
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='facilityID')
    psr.add_option('-N', '--facilityName', action='store', type='string', metavar='STRING', dest='facility_name',
                    default=None, help='facilityName')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                   default=None, help='description')
    psr.add_option('-I', '--Iconimage', action='store', type='string', metavar='STRING', dest='icon_image',
                   default=(None, 'NOTBLANK'), help='iconImage')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)

        ### method edit###
        ### scopeInfo parameter####
        scopeInfo = endpoint.getScope(opts.facility_id)
        if opts.facility_name is not None:
            scopeInfo.facilityName = opts.facility_name
        if opts.description is not None:
            scopeInfo.description = opts.description
        if opts.icon_image is not None:
            scopeInfo.iconImage = opts.icon_image

        endpoint.modifyScope(scopeInfo)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyScope')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
