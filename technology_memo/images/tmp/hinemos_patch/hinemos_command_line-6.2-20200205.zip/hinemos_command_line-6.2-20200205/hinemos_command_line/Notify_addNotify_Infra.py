#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
環境構築通知を作成する

<概要>
環境構築通知を作成します。

<使用例>
[command]
    $ python Notify_addNotify_Infra.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I INFRA1 -c 1 -i 1 -o INFRA01

[result]
    addNotify INFRA1...
    http://192.168.1.2:8080/HinemosWS/, addNotify_Event succeeded.
"""

### import ###
import sys
import codecs, locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.notify import NotifyUtil

def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--notifyID',  action='store', type='string', metavar='ID', dest='notify_id',
                    default=(None, 'REQUIRED','NOTBLANK'), help='notifyID')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                    default='', help='description')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=(None,'NOTBLANK'), help='ownerRoleID (default: ALL_USERS)')
    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id',
                    default=(None,'NOTBLANK'), help='calendar ID')

    psr.add_option('-c', '--initialCount', action='store', type='int', metavar='INT', dest='initial_count',
                    default=(None, 'REQUIRED'), help='initialCount')
    psr.add_option('-F', '--notFirstNotify', action='store', type='string', metavar='STRING', dest='not_first_notify',
                    default=(None,{'INLIST':['true','false']}), help='notify after validated (default: false)')

    psr.add_option('-T', '--renotifyType', action='store', type='int', metavar='INT', dest='renotify_type',
                    default=(None, {'INLIST':[0,1,2]}), help='renotifyType Always = 0, Time Suppressing = 1, Don\'t notify = 2 (default: 0)')
    psr.add_option('-P', '--renotifyPeriod', action='store', type='int', metavar='INT', dest='renotify_period',
                    default=(None, {'WHEN':{'renotify_type':1}, 'DO':('REQUIRED')}), help='renotifyPeriod')

    psr.add_option('-E', '--infraExecFacilityFlg', action='store', type='int', metavar='INT', dest='infra_exec_facility_flg',
                    default=(None, {'INLIST':[0,1]}), help='occurred scope = 0, fixed scope = 1 (default: 0)')
    psr.add_option('-d', '--infraExecFacility', action='store', type='string', metavar='STRING', dest='infra_exec_facility',
                    default=(None, {'WHEN':{'infra_exec_facility_flg':1}, 'DO':('REQUIRED')}), help='infraExecFacility')

    psr.add_option('-i', '--infoFlg', action='store', type='int', metavar='INT', dest='info_flg',
                    default=(None, {'INLIST':[0,1]}), help='infoFlg valid = 1, invalid = 0')
    psr.add_option('-a', '--warningFlg', action='store', type='int', metavar='INT', dest='warning_flg',
                    default=(None, {'INLIST':[0,1]}), help='warningFlg valid = 1, invalid = 0')
    psr.add_option('-t', '--criticalFlg', action='store', type='int', metavar='INT', dest='critical_flg',
                    default=(None, {'INLIST':[0,1]}), help='criticalFlg valid = 1, invalid = 0')
    psr.add_option('-u', '--unknownFlg', action='store', type='int', metavar='INT', dest='unknown_flg',
                    default=(None, {'INLIST':[0,1]}), help='unknownFlg valid = 1, invalid = 0')
    psr.add_option('-o', '--infraInfo', action='store', type='string', metavar='STRING', dest='infra_info',
                    default=(None, {'WHEN':{'info_flg':1}, 'DO':('REQUIRED','NOTBLANK')}), help='infraInfo =  managementId')
    psr.add_option('-g', '--infraWarning', action='store', type='string', metavar='STRING', dest='infra_warning',
                    default=(None, {'WHEN':{'warning_flg':1}, 'DO':('REQUIRED','NOTBLANK')}), help='infraWarning =  managementId')
    psr.add_option('-l', '--infraCritical', action='store', type='string', metavar='STRING', dest='infra_critical',
                    default=(None, {'WHEN':{'critical_flg':1}, 'DO':('REQUIRED','NOTBLANK')}), help='infraCritical =  managementId')
    psr.add_option('-k', '--infraUnknown', action='store', type='string', metavar='STRING', dest='infra_unknown',
                    default=(None, {'WHEN':{'unknown_flg':1}, 'DO':('REQUIRED','NOTBLANK')}), help='infraUnknown =  managementId')
    psr.add_option('-O', '--infraFailurePriorityInfo', action='store', type='string', metavar='STRING', dest='infra_failure_priority_info',
                    converter=NotifyUtil.convert2priority,
                    default=(None, {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN']}), help='infraFailurePriorityInfo = INFO or WARN or CRITICAL or UNKNOWN')
    psr.add_option('-G', '--infraFailurePriorityWarning', action='store', type='string', metavar='STRING', dest='infra_failure_priority_warning',
                    converter=NotifyUtil.convert2priority,
                    default=(None, {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN']}), help='infraFailurePriorityWarning = INFO or WARN or CRITICAL or UNKNOWN')
    psr.add_option('-L', '--infraFailurePriorityCritical', action='store', type='string', metavar='STRING', dest='infra_failure_priority_critical',
                    converter=NotifyUtil.convert2priority,
                    default=(None, {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN']}), help='infraFailurePriorityCritical = INFO or WARN or CRITICAL or UNKNOWN')
    psr.add_option('-K', '--infaraFailurePriorityUnknown', action='store', type='string', metavar='STRING', dest='infra_failure_priority_unknown',
                    converter=NotifyUtil.convert2priority,
                    default=(None, {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN']}), help='infraFailurePriorityUnknown = INFO or WARN or CRITICAL or UNKNOWN')

    psr.add_option('-e', '--enable', action='store', type='string', metavar='STRING', dest='enable_raw',converter=SettingUtil.convert2nint,
                    default=(None, {'INLIST':['true','false']}), help='enable=true, disable=false (default: true)')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        info_infra_failure_priority = None if opts.infra_failure_priority_info is None else NotifyUtil.convert2priority(opts.infra_failure_priority_info)
        warn_infra_failure_priority = None if opts.infra_failure_priority_warning is None else NotifyUtil.convert2priority(opts.infra_failure_priority_warning)
        critical_infra_failure_priority = None if opts.infra_failure_priority_critical is None else NotifyUtil.convert2priority(opts.infra_failure_priority_critical)
        unknown_infra_failure_priority = None if opts.infra_failure_priority_unknown is None else NotifyUtil.convert2priority(opts.infra_failure_priority_unknown)


        ResultPrinter.info('addNotify %s...' % opts.notify_id)
        endpoint.add_notify_infra(\
                opts.notify_id,\
                opts.initial_count,\
                opts.description,\
                opts.owner_role_id,\
                opts.calendar_id,\
                SettingUtil.convert2nint(opts.not_first_notify),\
                opts.renotify_type,\
                opts.renotify_period,\
                opts.enable,\
                opts.infra_exec_facility,\
                opts.infra_exec_facility_flg,\
                opts.info_flg,\
                opts.infra_info,\
                info_infra_failure_priority,\
                opts.warning_flg,\
                opts.infra_warning,\
                warn_infra_failure_priority,\
                opts.critical_flg,\
                opts.infra_critical,\
                critical_infra_failure_priority,\
                opts.unknown_flg,\
                opts.infra_unknown,\
                unknown_infra_failure_priority)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addNotify_Infra')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
