#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ユーザ情報をパスワード込みで更新する

<概要>
ユーザ情報をパスワード込みで更新します。

<使用例>
[command]
    $ python Access_modifyUserInfoWithHashedPassword.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST01 -N TEST01 -D "Test User" -M "abc@hinemos.co.jp" -P "test"

[result]
    http://127.0.0.1:8080/HinemosWS/, modifyUserInfoWithHashedPassword succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.access import AccessEndpoint
from hinemos.util.common import PasswordConvert, ResultPrinter


def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--userID',  action='store', type='string', metavar='ID', dest='user_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='User ID')
    psr.add_option('-N', '--userName', action='store', type='string', metavar='STRING', dest='user_name',
                   default=None, help='User Name')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                   default=None, help='User Description')
    psr.add_option('-M', '--mailAddress', action='store', type='string', metavar='STRING', dest='mail_address',
                   default=None, help='User Mail Address')
    psr.add_option('-P', '--password', action='store', type='string', metavar='PASSWORD', dest='password',
                   default=None, help='Password')

    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = AccessEndpoint(opts.mgr_url, opts.user, opts.passwd)

        user_info = endpoint.getUserInfo(opts.user_id)
        if user_info is None:
            raise ErrorHandler.ArgumentError('modifyUserInfoWithHashedPassword failed, ' + 'userID:' + opts.user_id +
                                             ' does not exist')
        if opts.user_name is not None:
            user_info.userName = opts.user_name
        if opts.description is not None:
            user_info.description = opts.description
        if opts.mail_address is not None:
            user_info.mailAddress = opts.mail_address
        if opts.password is not None:
            password_hash = PasswordConvert.slappasswd(opts.password)
            user_info.password = password_hash

        endpoint.modifyUserInfoWithHashedPassword(user_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'modifyUserInfoWithHashedPassword')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
