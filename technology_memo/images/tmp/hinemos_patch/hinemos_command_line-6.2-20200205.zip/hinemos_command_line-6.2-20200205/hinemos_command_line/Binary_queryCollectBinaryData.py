#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# ---------------------------------------------------
# Hinemos Command-Line Tools Suite
# Copyright (c) 2018 NTT DATA INTELLILINK Corporation
# ---------------------------------------------------
u"""
バイナリ収集情報を検索する

<概要>
バイナリ収集情報を検索します。

<使用例>
[command]
    $ python Binary_queryCollectBinaryData.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    http://192.168.1.2:8080/HinemosWS/, queryCollectBinaryData succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale
from hinemos.util.common import DateConvert, ResultPrinter
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.binary import BinaryEndpoint
from hinemos.util.hub import HubUtil
from  hinemos.util import api as apiUtils
from collections import OrderedDict


def parse_options(opt_list):
    psr = MyOptionParser()
    psr.add_option('--from',
                   action='store',
                   type='string',
                   metavar='DATETIME',
                   converter=DateConvert.get_epochtime_from_datetime,
                   dest='from_raw',
                   default=(None, {
                       'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$',
                                  'must be in datetime format']
                   }),
                   help='only show records after a specific date'
                   ' [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('--to',
                   action='store',
                   type='string',
                   metavar='DATETIME',
                   converter=DateConvert.get_epochtime_from_datetime,
                   dest='to_raw',
                   default=(None, {
                       'REGEXP': [r'^\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d$',
                                  'must be in datetime format']
                   }),
                   help='only show records before a specific date'
                   ' [yyyy/mm/dd HH:MM:SS]')
    psr.add_option('-I',
                   '--monitorId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='monitorId',
                   default=None,
                   help='monitor ID')
    psr.add_option('-F',
                   '--facilityId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='facilityId',
                   default=(None, 'REQUIRED', 'NOTBLANK'),
                   help='facility ID')
    psr.add_option('--keywords',
                   action='store',
                   type='string',
                   metavar='STRING',
                   dest='keywords',
                   default='',
                   help='keywords')
    psr.add_option('--operator',
                   action='store',
                   type='string',
                   metavar='OPERATOR',
                   dest='operator_raw',
                   default=(None, {'INLIST': ['AND', 'OR']}),
                   converter=HubUtil.convert2operator,
                   help='condition operator (default: AND)')
    psr.add_option('--offset',
                   action='store',
                   type='int',
                   metavar='INT',
                   dest='dispOffset',
                   default=0,
                   help='show records starting at offset')
    psr.add_option('--maxCount',
                   action='store',
                   type='int',
                   metavar='INT',
                   dest='size',
                   default=HubUtil.PAGE_MAX_DEFAULT,
                   help='limit the number of records to output')
    psr.add_option('--encoding',
                   action='store',
                   type='string',
                   metavar='ENCODING',
                   dest='textEncoding',
                   default=None,
                   help='encode the keywords using an encoding. e.g. UTF-8')
    psr.add_option('--download',
                   action='store',
                   type='string',
                   metavar='MODE',
                   dest='download',
                   default=(None, {'INLIST': ['ONE', 'ALL']}),
                   help='download=ONE to download particular file, '
                   'download=ALL to download all listed files ')
    psr.add_option('--recordKey',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='recordKey',
                   default=(None, {
                       'WHEN': {'download': 'ONE'},
                       'DO': ('REQUIRED', 'NOTBLANK')}),
                   help='recordKey of a listed item')
    psr.add_option('--clientName',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='clientName',
                   default='',
                   help='client name')
    psr.add_option('--dir',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='dir',
                   default=(''),
                   help='output dir (default: current working directory)')
    return psr.parse_opts(opt_list)


def main():
    opts = vars(parse_options(sys.argv))
    ### execute ###
    return_code = -1

    endpoint = BinaryEndpoint(opts['mgr_url'], opts['user'], opts['passwd'],
                              xml_strict=False)
    try:
        result = endpoint.manageBinaryData(opts)
        if result is not None:
            print result
        return_code = ResultPrinter.success(
            None, opts['mgr_url'], 'getPresetList')
    except Exception, exc:
        return_code = ResultPrinter.failure(exc)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)
    sys.exit(main())
