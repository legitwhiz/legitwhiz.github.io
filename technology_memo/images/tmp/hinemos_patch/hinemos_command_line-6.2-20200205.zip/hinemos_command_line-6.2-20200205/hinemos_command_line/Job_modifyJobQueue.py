#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
ジョブキュー(同時実行制御キュー)の設定を変更する

<概要>
ジョブキュー(同時実行制御キュー)の設定を変更します。

<使用例>
[command]
    $ python Job_modifyJobQueue.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos -I TESTQ01 -N TESTQ1 -C 100

[result]

    http://127.0.0.1:8080/HinemosWS/, modifyJobQueue succeeded.
"""

import sys
import codecs
import locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
from hinemos.api.job import JobEndpoint
import hinemos.api.exceptions as ErrorHandler
from hinemos.util.modifier import ObjectModifier


def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--queueId', action='store', type='string', metavar='ID', dest='queue_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Job Queue ID')
    psr.add_option('-N', '--queueName', action='store', type='string', metavar='STRING', dest='queue_name',
                   default=(None, 'NOTBLANK'), help='New Job Queue name')
    psr.add_option('-C', '--concurrency', action='store', type='int', metavar='INT', dest='concurrency',
                   default=(None, 'INTEGER'), help='New Concurrency Value')
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = JobEndpoint(opts.mgr_url, opts.user, opts.passwd)

        job_queue_setting = endpoint.getJobQueue(opts.queue_id)
        if job_queue_setting is None:
            raise ErrorHandler.ArgumentError('modifyJobQueue failed, ' + 'queue id ' + opts.queue_id +
                                             ' does not exist')
        ObjectModifier.replace_if_not_none(
            job_queue_setting,
            name=opts.queue_name,
            concurrency=opts.concurrency)

        result = endpoint.modifyJobQueue(job_queue_setting)
        return_code = ResultPrinter.success(result, opts.mgr_url, 'modifyJobQueue')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
