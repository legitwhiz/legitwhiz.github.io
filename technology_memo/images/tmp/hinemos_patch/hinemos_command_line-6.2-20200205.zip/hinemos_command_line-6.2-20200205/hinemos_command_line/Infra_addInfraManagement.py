#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
環境構築設定を作成する

<概要>
環境構築設定を作成します。

<使用例>
[command]
    $ python Infra_addInfraManagement.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I MAN001 -N "My management setting" -F LINUX -S INFO -W WARN -X UNKNOWN -Y INFO -Z WARN -e true

[result]
    http://192.168.1.2:8080/HinemosWS/, addInfraManagement succeeded.
"""

import sys
import codecs, locale
import json
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.infra import InfraEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.notify import NotifyUtil


def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--managementID',  action='store', type='string', metavar='ID', dest='management_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='management ID')
    psr.add_option('-N', '--name', action='store', type='string', metavar='STRING', dest='name',
                   default=(None, 'REQUIRED','NOTBLANK'), help='name')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                   default=None, help='description')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                    default=None, help='ownerRoleID (default: ALL_USERS)')
    psr.add_option('-F', '--facilityID',  action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None, 'REQUIRED','NOTBLANK'), help='facility ID')

    psr.add_option('-S', '--startPriority', action='store', type='string', metavar='STRING', dest='start_priority_raw', converter=NotifyUtil.convert2priority,
                   default=(None, {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN','']}), help='startPriority = INFO or WARN or CRITICAL or UNKNOWN or \'\'(empty) (default: INFO)')
    psr.add_option('-W', '--normalPriorityRun', action='store', type='string', metavar='STRING', dest='normal_priority_run_raw', converter=NotifyUtil.convert2priority,
                   default=(None, {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN','']}), help='normalPriorityRun = INFO or WARN or CRITICAL or UNKNOWN or \'\'(empty) (default: INFO)')
    psr.add_option('-X', '--abnormalPriorityRun', action='store', type='string', metavar='STRING', dest='abnormal_priority_run_raw', converter=NotifyUtil.convert2priority,
                   default=(None, {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN','']}), help='abnormalPriorityRun = INFO or WARN or CRITICAL or UNKNOWN or \'\'(empty) (default: CRITICAL)')
    psr.add_option('-Y', '--normalPriorityCheck', action='store', type='string', metavar='STRING', dest='normal_priority_check_raw', converter=NotifyUtil.convert2priority,
                   default=(None, {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN','']}), help='normalPriorityCheck = INFO or WARN or CRITICAL or UNKNOWN or \'\'(empty) (default: INFO)')
    psr.add_option('-Z', '--abnormalPriorityCheck', action='store', type='string', metavar='STRING', dest='abnormal_priority_check_raw', converter=NotifyUtil.convert2priority,
                   default=(None, {'INLIST':['INFO','WARN','CRITICAL','UNKNOWN','']}), help='abnormalPriorityCheck = INFO or WARN or CRITICAL or UNKNOWN or \'\'(empty) (default: CRITICAL)')
    psr.add_option('-n', '--notifyIDs', action='store', type='string', metavar='STRING', dest='notify_ids',
                   default=None, help='notifyIDs = notifyID1,notifyID2,...,notifyIDN')
    psr.add_option('-e', '--enable', action='store', type='string', metavar='STRING', dest='enable_raw',converter=SettingUtil.convert2nint,
                    default=('true' ,{'INLIST':['true','false']}), help='enable=true, disable=false (default: true)')
    psr.add_option('-p', '--paramList', action='store', type='string', metavar='STRING', dest='param_list',
                   default=None, help='[{"paramId": <name - required>, "value": <value - required>, "description": <optional>, "passwordFlg": <true/false - optional default=false>}]')
    psr.add_option('-P', '--paramListJsonFile', action='store', type='string', metavar='JSON', dest='param_list_file',
                    default=None, help='JSON input file path, file content: [{"paramId": <name - required>, "value": <value - required>, "description": <optional>, "passwordFlg": <true/false - optional default=false>}]')
    opts = psr.parse_opts(sys.argv)
    del psr

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = InfraEndpoint(opts.mgr_url, opts.user, opts.passwd)

        if opts.notify_ids is None:
            notify_id_list = []
        else:
            notify_id_list = [a.strip() for a in opts.notify_ids.split(',') if a.strip() != '']

        notify_endpoint = None
        if 0 < len(notify_id_list):
            notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        param_list = None
        if opts.param_list:
            param_list = json.loads(opts.param_list)
        if opts.param_list_file:
            param_list = json.load(open(opts.param_list_file))

        infra_management_info = endpoint.create_infra_management_info(
            opts.management_id,
            opts.name,
            opts.description,
            opts.owner_role_id,
            opts.facility_id,
            opts.start_priority,
            opts.normal_priority_run,
            opts.abnormal_priority_run,
            opts.normal_priority_check,
            opts.abnormal_priority_check,
            opts.enable,
            notify_endpoint,
            notify_id_list,
            param_list
        )

        endpoint.addInfraManagement(infra_management_info)
        return_code = ResultPrinter.success(None, opts.mgr_url, 'addInfraManagement')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)

if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
