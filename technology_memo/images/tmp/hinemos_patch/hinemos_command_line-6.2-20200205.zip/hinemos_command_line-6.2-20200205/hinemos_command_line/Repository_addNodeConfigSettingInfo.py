#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
構成情報取得設定を追加する

<概要>
構成情報取得設定を追加します。

<使用例>
- 構成情報取得設定を追加します。
[command]
    $ python Repository_addNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING -N "Test Setting" -F LINUX -D "Test Description" -n 6h -v true

[result]
    http://127.0.0.1:8080/HinemosWS/, addNodeConfigSettingInfo succeeded.

- 「基本情報」設定を含めて、構成情報取得設定を追加します。
[command]
    $ python Repository_addNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING -N "Test Setting" -F LINUX -D "Test Description" -n 6h -v true -i NETSTAT,HW_CPU,PROCESS

[result]
    http://127.0.0.1:8080/HinemosWS/, addNodeConfigSettingInfo succeeded.

- 「通知オプション」を含めて、構成情報取得設定を追加します。
[command]
    $ python Repository_addNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING -N "Test Setting" -F LINUX -D "Test Description" -n 6h -v true -a event01,status01

[result]
    http://127.0.0.1:8080/HinemosWS/, addNodeConfigSettingInfo succeeded.

- 「ユーザ任意情報」設定を含めて、構成情報取得設定を追加します。
[command]
    $ python Repository_addNodeConfigSettingInfo.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos
    -I TEST_SETTING -N "Test Setting" -F LINUX -D "Test Description" -n 6h -v true -c true --customId TEST_SETTING
    --customName "Test Custom Setting" --command "ls -la" --customValidFlg true --specifyUser false

[result]
    http://127.0.0.1:8080/HinemosWS/, addNodeConfigSettingInfo succeeded.

"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.repository import RepositoryEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.api.exceptions import APIError


def main():

    psr = MyOptionParser()
    psr.add_option('-I', '--settingId',  action='store', type='string', metavar='ID', dest='setting_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Node Configuration Setting ID')
    psr.add_option('-N', '--settingName', action='store', type='string', metavar='STRING', dest='setting_name',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Node Configuration Setting name')
    psr.add_option('-D', '--description', action='store', type='string', metavar='STRING', dest='description',
                   default=None, help='Node Configuration Setting Description')
    psr.add_option('-F', '--facilityId',  action='store', type='string', metavar='ID', dest='facility_id',
                   default=(None, 'REQUIRED', 'NOTBLANK'), help='Facility ID')
    psr.add_option('-R', '--ownerRoleID',  action='store', type='string', metavar='ID', dest='owner_role_id',
                   default=('ALL_USERS', 'NOTBLANK'), help='Owner role ID (default: ALL_USERS)')
    psr.add_option('-n', '--runInterval', action='store', type='string', metavar='STRING', dest='run_interval_raw',
                   converter=SettingUtil.convert2sec, default=('6h', {'INLIST': ['6h', '12h', '24h']}),
                   help='Run Interval(6h, 12h, 24h)')
    psr.add_option('-C', '--calendarID',  action='store', type='string', metavar='ID', dest='calendar_id', default=None,
                   help='Calendar ID')
    psr.add_option('-v', '--validFlg', action='store', type='string', metavar='BOOL', dest='valid_flg_raw',
                   converter=SettingUtil.convert2nbool, default=('true', {'INLIST': ['true', 'false']}),
                   help='Enable Setting=true, Disable Setting=false (default: true)')

    # 通知オプション
    psr.add_option('-a', '--notifyIds', action='store_split', type='string', metavar='STRING', dest='notify_ids',
                   default=None, help='Add notifications. addNotifyIDs = notifyID1,notifyID2,...,notifyIDN')

    # 基本情報オプション
    psr.add_option('-i', '--settingItemIds', action='store_split', type='string', metavar='STRING',
                   dest='setting_item_ids', default=None,
                   help='Add Configuration Setting IDs. settingItemIds = SettingID1,SettingID2,...,SettingIDN'
                        ' HOSTNAME,HW_MEMORY,NETSTAT,HW_CPU,PACKAGE,HW_NIC,PROCESS,OS,HW_FILESYSTEM,HW_DISK')

    # ユーザ任意情報オプション
    psr.add_option('-c', '--addCustomInfo', action='store', type='string', metavar='BOOL', dest='custom_info_raw',
                   converter=SettingUtil.convert2nbool, default=('false', {'INLIST': ['true', 'false']}),
                   help='Add Custom Info Settings=true (default: false)')
    psr.add_option('--command', action='store', type='string', metavar='STRING', dest='command',
                   default=(None, 'NOTBLANK', {'WHEN': [{'custom_info_raw': 'true'}], 'DO': 'REQUIRED'}),
                   help='Command for Custom Info Setting')
    psr.add_option('--customId', action='store', type='string', metavar='STRING', dest='custom_id',
                   default=(None, 'NOTBLANK', {'WHEN': [{'custom_info_raw': 'true'}], 'DO': 'REQUIRED'}),
                   help='ID Of Custom Info Setting')
    psr.add_option('--customName', action='store', type='string', metavar='STRING', dest='custom_name',
                   default=(None, 'NOTBLANK', {'WHEN': [{'custom_info_raw': 'true'}], 'DO': 'REQUIRED'}),
                   help='Name Of Custom Info Setting')
    psr.add_option('--customValidFlg', action='store', type='string', metavar='BOOL', dest='custom_valid_flg_raw',
                   converter=SettingUtil.convert2nbool,
                   default=('true', {'INLIST': ['true', 'false']}, {'WHEN': [{'custom_info_raw': 'true'}], 'DO': ()}),
                   help='Enable Custom Setting=true, Disable Custom Setting=false (default: true)')
    psr.add_option('--specifyUser', action='store', type='string', metavar='BOOL', dest='specify_user_raw',
                   converter=SettingUtil.convert2nbool,
                   default=('false', {'INLIST': ['true', 'false']}, {'WHEN': [{'custom_info_raw': 'true'}], 'DO': ()}),
                   help='Specify User for Custom Setting=true, (default: false)')
    psr.add_option('--effectiveUser', action='store', type='string', metavar='STRING', dest='effective_user',
                   default=(None, {'WHEN': [{'specify_user_raw': 'true'}], 'DO': 'REQUIRED'}),
                   help='User for Custom Setting')
    psr.add_option('--custom_description', action='store', type='string', metavar='STRING', dest='custom_description',
                   default=(None, {'WHEN': [{'custom_info_raw': 'true'}], 'DO': ()}),
                   help='Description of Custom Info Setting')

    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        repo_endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # 構成情報取得対象⇒基本情報
        setting_item_info_lst = []
        if opts.setting_item_ids_converted is not None:
            setting_item_lst = opts.setting_item_ids_converted
            for setting_item in setting_item_lst:
                setting_item_info = repo_endpoint.create_node_config_setting_item_info(setting_item)
                setting_item_info_lst.append(setting_item_info)

        # 構成情報取得対象⇒ユーザ任意情報
        custom_config_info_lst = []
        if opts.custom_info:
            custom_config_info = repo_endpoint.create_node_custom_config_info(
                opts.custom_id,
                opts.custom_name,
                opts.custom_description,
                opts.command,
                opts.custom_valid_flg,
                opts.specify_user,
                opts.effective_user
            )
            custom_config_info_lst.append(custom_config_info)
            setting_item_info = repo_endpoint.create_node_config_setting_item_info('CUSTOM')
            setting_item_info_lst.append(setting_item_info)

        # 通知設定
        notify_relation_info_lst = []
        if opts.notify_ids_converted is not None:
            notify_id_lst = opts.notify_ids_converted
            for notify_id in notify_id_lst:
                notify_info = notify_endpoint.getNotify(notify_id)
                if notify_info is None:
                    raise APIError('getNotification Detail failed. Invalid Notify IDs provided.')
                notify_relation_info = repo_endpoint.create_notify_relation_info(notify_info, opts.setting_id)
                notify_relation_info_lst.append(notify_relation_info)

        node_config_setting = repo_endpoint.create_object('nodeConfigSettingInfo')
        node_config_setting.settingId = opts.setting_id
        node_config_setting.settingName = opts.setting_name
        node_config_setting.description = opts.description
        node_config_setting.facilityId = opts.facility_id
        node_config_setting.ownerRoleId = opts.owner_role_id
        node_config_setting.runInterval = opts.run_interval
        node_config_setting.calendarId = opts.calendar_id
        node_config_setting.validFlg = opts.valid_flg
        node_config_setting.nodeConfigSettingItemList = setting_item_info_lst
        node_config_setting.notifyRelationList = notify_relation_info_lst
        node_config_setting.nodeConfigCustomList = custom_config_info_lst

        repo_endpoint.addNodeConfigSettingInfo(node_config_setting)

        return_code = ResultPrinter.success(None, opts.mgr_url, 'addNodeConfigSettingInfo')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
