#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2019 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
構成情報取得設定の一覧を取得する

<概要>
構成情報取得設定の一覧を取得します。

<使用例>
[command]
    $ python Repository_getNodeConfigSettingList.py -H http://127.0.0.1:8080/HinemosWS/ -U hinemos -w hinemos

[result]
    [(nodeConfigSettingInfo){
       ownerRoleId = "ALL_USERS"
       calendarId = None
       description = None
       facilityId = "LINUX"
       notifyGroupId = "NODE_CONFIG_SETTING-TEST_SETTING1"
       regDate = "2019/04/10 11:49:34.479"
       regUser = "hinemos"
       runInterval = 21600
       scope = "$[OS_SCOPE]>Linux>"
       settingId = "TEST_SETTING1"
       settingName = "TEST_SETTING1"
       updateDate = "2019/04/10 11:49:34.479"
       updateUser = "hinemos"
       validFlg = True
     }, (nodeConfigSettingInfo){
       ownerRoleId = "ALL_USERS"
       calendarId = None
       description = None
       facilityId = "LINUX"
       nodeConfigSettingItemList[] =
          (nodeConfigSettingItemInfo){
             settingItemId = "HW_CPU"
          },
          (nodeConfigSettingItemInfo){
             settingItemId = "NETSTAT"
          },
          (nodeConfigSettingItemInfo){
             settingItemId = "HOSTNAME"
          },
          (nodeConfigSettingItemInfo){
             settingItemId = "HW_MEMORY"
          },
       notifyGroupId = "NODE_CONFIG_SETTING-TEST_SETTING2"
       notifyRelationList[] =
          (notifyRelationInfo){
             notifyGroupId = "NODE_CONFIG_SETTING-TEST_SETTING2"
             notifyId = "status01"
             notifyType = 0
          },
       regDate = "2019/04/10 11:49:55.888"
       regUser = "hinemos"
       runInterval = 21600
       scope = "$[OS_SCOPE]>Linux>"
       settingId = "TEST_SETTING2"
       settingName = "TEST_SETTING2"
       updateDate = "2019/04/10 11:49:55.888"
       updateUser = "hinemos"
       validFlg = True
     }, (nodeConfigSettingInfo){
       ownerRoleId = "ALL_USERS"
       calendarId = None
       description = None
       facilityId = "LINUX"
       nodeConfigCustomList[] =
          (nodeConfigCustomInfo){
             command = "ls -l"
             description = None
             displayName = "abc"
             effectiveUser = "hinemos"
             settingCustomId = "abc"
             specifyUser = True
             validFlg = True
          },
       nodeConfigSettingItemList[] =
          (nodeConfigSettingItemInfo){
             settingItemId = "CUSTOM"
          },
          (nodeConfigSettingItemInfo){
             settingItemId = "HW_CPU"
          },
          (nodeConfigSettingItemInfo){
             settingItemId = "OS"
          },
          (nodeConfigSettingItemInfo){
             settingItemId = "NETSTAT"
          },
          (nodeConfigSettingItemInfo){
             settingItemId = "PROCESS"
          },
       notifyGroupId = "NODE_CONFIG_SETTING-TEST_SETTING3"
       notifyRelationList[] =
          (notifyRelationInfo){
             notifyGroupId = "NODE_CONFIG_SETTING-TEST_SETTING3"
             notifyId = "event01"
             notifyType = 1
          },
       regDate = "2019/04/10 11:50:25.053"
       regUser = "hinemos"
       runInterval = 21600
       scope = "$[OS_SCOPE]>Linux>"
       settingId = "TEST_SETTING3"
       settingName = "TEST_SETTING3"
       updateDate = "2019/04/10 12:44:17.641"
       updateUser = "hinemos"
       validFlg = True
     }]

    http://127.0.0.1:8080/HinemosWS/, getNodeConfigSettingList succeeded.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))
import codecs
import locale
from hinemos.util.opt import MyOptionParser
from hinemos.api.repository import RepositoryEndpoint
from hinemos.util.common import ResultPrinter, DateConvert


def main():
    psr = MyOptionParser()
    opts = psr.parse_opts(sys.argv)
    del psr

    try:
        endpoint = RepositoryEndpoint(opts.mgr_url, opts.user, opts.passwd)
        result = endpoint.getNodeConfigSettingList()

        if result is not None:
            for node_config_setting in result:
                if 'regDate' in node_config_setting:
                    node_config_setting.regDate = DateConvert.get_datetime_from_epochtime(node_config_setting.regDate)
                if 'updateDate' in node_config_setting:
                    node_config_setting.updateDate = DateConvert.get_datetime_from_epochtime(
                        node_config_setting.updateDate)

        return_code = ResultPrinter.success(result, opts.mgr_url, 'getNodeConfigSettingList')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return return_code


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
