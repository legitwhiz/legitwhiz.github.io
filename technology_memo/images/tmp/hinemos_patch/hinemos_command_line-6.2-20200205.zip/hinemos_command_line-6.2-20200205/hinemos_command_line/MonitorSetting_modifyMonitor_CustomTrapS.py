#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
カスタムトラップ監視(文字列)の監視設定情報を変更する

<概要>
カスタムトラップ監視(文字列)の監視設定情報を変更します。

<使用例>
[command]
    $ python MonitorSetting_modifyMonitor_CustomTrapS.py -H http://192.168.1.2:8080/HinemosWS/ -U hinemos -w hinemos -I CUSTOMTRAPS01 -A MYAPP -F SCOPE001 -k key_changed

[result]
    http://192.168.1.2:8080/HinemosWS/, modifyMonitor succeeded.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'site-packages'))

import codecs
import locale
from hinemos.util.common import ResultPrinter, SettingUtil
from hinemos.util.opt import MyOptionParser
import hinemos.api.exceptions as ErrorHandler
from hinemos.api.monitorsetting import MonitorSettingEndpoint
from hinemos.api.notify import NotifyEndpoint
from hinemos.util.modifier import ObjectModifier
from hinemos.util.notify import NotifyUtil
from hinemos.util.argsparserbuilder import MonitorSettingArgsParserBuilder


def parse_args(args):
    # add key value pairs to override defaults from argsparserbuilder.py
    help_default_info = {}
    psr = MonitorSettingArgsParserBuilder()\
        .build_monitor_setting_modify_args_parser(help_default_info)

    psr.add_option('-l', '--logFormatID',  action='store', type='string',
                   metavar='ID', dest='logformat_id',
                   default=(None, {
                       'WHEN': {'collect': 1},
                         'DO': ('REQUIRED', 'NOTBLANK')}),
                   help='Log format ID')

    psr.add_option('-k', '--Keypattern', action='store', type='string',
                   metavar='STRING', dest='key_pattern',
                   default=(None, 'NOTBLANK'), help='keypattern')
    psr.add_option('-f', '--calculateDiff', action='store', type='string',
                   metavar='STRING', dest='cal_diff_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='calculate difference from previous result =true, do nothing =false')

    psr.add_option('-p', '--patternAction', action='store', type='string',
                   metavar='MODE', dest='pattern_action',
                   default=(None, {'INLIST': ['ADD', 'MOD', 'DEL']}),
                   help='add a pattern = ADD, modify a pattern = MOD,'
                   ' delete a pattern = DEL')
    psr.add_option('-z', '--patternNo', action='store', type='int',
                   metavar='INT', dest='pattern_n',
                   default=(None, {
                       'WHEN': [{'pattern_action': 'MOD'},
                                {'pattern_action': 'DEL'}],
                       'DO': ('REQUIRED')}),
                   help='pattern orderNo')
    psr.add_option('-y', '--patternNewNo', action='store', type='int',
                   metavar='INT', dest='pattern_n_new',
                   default=None, help='change pattern order to patternNewNo')
    psr.add_option('-P', '--pattern', action='store', type='string',
                   metavar='STRING', dest='pattern',
                   default=(None, 'NOTBLANK', {
                       'WHEN': {'pattern_action': 'ADD'},
                       'DO': ('REQUIRED')}), help='pattern')
    psr.add_option('-r', '--patternDescription', action='store', type='string',
                   metavar='STRING', dest='pattern_description',
                   default=None, help='pattern description')
    psr.add_option('-t', '--patternProcessType', action='store', type='string',
                   metavar='STRING', dest='pattern_process_type_raw',
                   converter=SettingUtil.convert2nint,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='process when matching =true, or process when not'
                   ' matching =false')
    psr.add_option('-S', '--patternCaseSensitive', action='store',
                   type='string', metavar='BOOL',
                   dest='pattern_case_sensitive_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='patternCaseSensitive')
    psr.add_option('-i', '--patternPriority', action='store', type='string',
                   metavar='STRING', dest='pattern_priority_raw',
                   converter=NotifyUtil.convert2priority,
                   default=(None, {
                       'INLIST': ['INFO', 'WARN', 'CRITICAL', 'UNKNOWN']}),
                   help='pattern_priority = INFO or WARN or CRITICAL'
                   ' or UNKNOWN')
    psr.add_option('-E', '--patternMessage', action='store', type='string',
                   metavar='STRING', dest='pattern_message',
                   default=(None, 'NOTBLANK'), help='pattern message')
    psr.add_option('-e', '--patternEnable', action='store', type='string',
                   metavar='BOOL', dest='pattern_enable_raw',
                   converter=SettingUtil.convert2nbool,
                   default=(None, {'INLIST': ['true', 'false']}),
                   help='enable=true, disable=false')

    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    # pylint: disable=W0703
    try:
        ### login ###
        endpoint = MonitorSettingEndpoint(opts.mgr_url, opts.user, opts.passwd)

        # monitorInfo parameter
        monitor_info = endpoint.getMonitor(opts.monitor_id)

        # Modification
        with ObjectModifier(monitor_info) as modifier:
            modifier.set_if_first_not_none('application', opts.application)
            modifier.set_if_first_not_none('calendarId', opts.calendar_id)
            modifier.set_if_first_not_none('description', opts.description)
            modifier.set_if_first_not_none(
                'facilityId', opts.facility_id, scope=' ')
            modifier.set_if_first_not_none(
                'monitorFlg', opts.monitor)

            modifier.set_if_first_not_none('runInterval', opts.run_interval)
            modifier.set_if_first_not_none(
                'collectorFlg', opts.collect)
            modifier.set_if_first_not_none('logFormatId', opts.logformat_id)

            modifier.change_ptr('customTrapCheckInfo')
            modifier.set_if_first_not_none('convertFlg', opts.cal_diff)
            modifier.set_if_first_not_none('targetKey', opts.key_pattern)

        if opts.pattern_action == 'ADD':
            if not hasattr(monitor_info, 'stringValueInfo'):
                setattr(monitor_info, 'stringValueInfo', [])
            if not opts.pattern_message:
                opts.pattern_message = '#[LOG_LINE]'
            pattern = endpoint.create_monitor_string_value_info(
                opts.monitor_id,
                opts.pattern,
                opts.pattern_description,
                opts.pattern_case_sensitive,
                opts.pattern_process_type,
                opts.pattern_priority,
                opts.pattern_message,
                opts.pattern_enable)
            if opts.pattern_n is None:
                monitor_info.stringValueInfo.append(pattern)
            else:
                monitor_info.stringValueInfo.insert(
                    opts.pattern_n - 1, pattern)

        elif opts.pattern_action == 'MOD':
            if opts.pattern_n < 1 or opts.pattern_n > len(monitor_info.stringValueInfo):
                raise ErrorHandler.ObjectNotFoundError(
                    'Pattern(no=%d) does not exist!' % opts.pattern_n)
            else:
                pattern_info = monitor_info.stringValueInfo[opts.pattern_n - 1]
                ObjectModifier.replace_if_not_none(pattern_info,
                                                   pattern=opts.pattern,
                                                   description=opts.pattern_description,
                                                   caseSensitivityFlg=opts.pattern_case_sensitive,
                                                   processType=opts.pattern_process_type,
                                                   priority=opts.pattern_priority,
                                                   message=opts.pattern_message,
                                                   validFlg=opts.pattern_enable)
                # Change order
                if opts.pattern_n_new is not None:
                    monitor_info.stringValueInfo.insert(
                        opts.pattern_n_new - 1, monitor_info.stringValueInfo.pop(opts.pattern_n - 1))

        elif opts.pattern_action == 'DEL':
            if opts.pattern_n < 1 or opts.pattern_n > len(monitor_info.stringValueInfo):
                raise ErrorHandler.ObjectNotFoundError(
                    'Pattern(no=%d) does not exist!' % opts.pattern_n)
            else:
                del monitor_info.stringValueInfo[opts.pattern_n - 1]

        # Notify
        notify_endpoint = NotifyEndpoint(opts.mgr_url, opts.user, opts.passwd)
        if opts.add_notify_ids_converted is not None:
            if not hasattr(monitor_info, 'notifyRelationList'):
                setattr(monitor_info, 'notifyRelationList', [])

            # Check if notification already exists
            ids = set(opts.add_notify_ids_converted)
            existed_ids = tuple(
                [x.notifyId for x in monitor_info.notifyRelationList])

            # Then add
            for x in filter((lambda x: x not in existed_ids), ids):
                monitor_info.notifyRelationList.append(
                    endpoint.create_notify_relation_info(notify_endpoint.getNotify(x),
                                                         monitor_info.monitorTypeId, monitor_info.monitorId))

        if opts.del_notify_ids_converted is not None and hasattr(monitor_info, 'notifyRelationList') and 0 < len(monitor_info.notifyRelationList):
            ids = set(opts.del_notify_ids_converted)
            for i in reversed(xrange(len(monitor_info.notifyRelationList))):
                if monitor_info.notifyRelationList[i].notifyId in ids:
                    del monitor_info.notifyRelationList[i]

        endpoint.modifyMonitor(monitor_info)
        return_code = ResultPrinter.success(
            None, opts.mgr_url, 'modifyMonitor')
    except ErrorHandler.LoginError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.PermissoinError, e:
        return_code = ResultPrinter.failure(e)
    except ErrorHandler.APIError, e:
        return_code = ResultPrinter.failure(e)
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
