#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# --------------------------------------------------
# Hinemos Command Line Tool Suite
# Copyright (c) 2017 NTT DATA INTELLILINK Corporation
# --------------------------------------------------

u"""
参照環境構築モジュールの選択対象一覧情報を取得する

<概要>
参照環境構築モジュールの選択対象一覧情報を取得します。

<使用例>
[command]
    $ python Infra_getReferManagementIdList.py
[result]
    http://192.168.1.2:8080/HinemosWS/, getReferManagementIdList succeeded.
"""
import sys
import codecs, locale
from hinemos.util.common import ResultPrinter
from hinemos.util.opt import MyOptionParser
from hinemos.api.infra import InfraEndpoint


def parse_args(args):
    psr = MyOptionParser()
    psr.add_option('-R', '--ownerRoleId',
                   action='store',
                   type='string',
                   metavar='ID',
                   dest='ownerRoleId',
                   default=None,
                   help='owner role id')
    return psr.parse_opts(args)


def main():

    opts = parse_args(sys.argv)

    ### execute ###
    return_code = -1

    ### login ###
    endpoint = InfraEndpoint(opts.mgr_url, opts.user, opts.passwd)

    try:
        result = endpoint.call('getReferManagementIdList', opts.ownerRoleId)
        return_code = ResultPrinter.success(
            result, opts.mgr_url, 'getCheckResultList')
    except Exception, e:
        return_code = ResultPrinter.failure(e)
    return(return_code)


if __name__ == '__main__':
    # sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
    # sys.stderr = codecs.getwriter(locale.getpreferredencoding())(sys.stderr)

    sys.exit(main())
