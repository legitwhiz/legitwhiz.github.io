﻿最終更新日時：2019/7/1

■概要

エンタープライズ機能、またはクラウド管理・VM管理機能を利用するために、
サブスクリプションの提供物に含まれる下記アクティベーションパッチとキーファイルを適用して
有効化する必要があります。
※ 別途アクティベーションキーファイルを入手してください。


- Hinemosアクティベーションパッチ
  
  patch_manager_activation_for6.2.x_yyyymmdd.tar.gz
  
- アクティベーションキーファイル
  
  yyyymm_xxx_enterprise   (エンタープライズ機能)
  yyyymm_xxx_xcloud       (クラウド管理・VM管理機能)

    ※ファイル名の形式について
      ファイル名の形式: yyyymm_xxx_functionname
      キーファイルのファイル名先頭6文字が、そのキーファイルの有効期限を表します。
        yyyy：有効期限(年)
        mm  ：有効期限(月)
        xxx ：利用者コード
        functionname: オプション機能のコード


■適用手順(Linux版マネージャ)

[事前準備]

 - patch_manager_activation_for6.2.x_yyyymmdd.tar.gzをHinemosマネージャのインストールサーバに配置し、解凍してください。
 - yyyymm_xxx_enterpriseをHinemosマネージャのインストールサーバに配置してください。
 - クラウド管理・VM管理機能をご利用の場合、yyyymm_xxx_xcloudをHinemosマネージャのインストールサーバに配置してください。
 ※以下では、上記ファイルを/tmp配下に配置したもの、インストールディレクトリはprefixオプションで変更していないものとして手順を記載します。

 - 上書きするファイルの事前バックアップを各自取得してください。(*注)
 - 環境の切り戻しについては、上書きするファイルを上書き前のファイルに戻して頂くことで実現できます。

(*注)
    以下の例のようにバックアップファイルは /opt/hinemos/lib/ 以外に配置してください。
    ・例(/root/backup/ 配下にバックアップファイルを取得する)
    (root) # cp -p /opt/hinemos/lib/Publish.jar /root/backup/


[手順(ミッションクリティカルオプション未利用環境)]

手順A-1 Hinemosマネージャを停止する

    パッチを適用するためには、Hinemosマネージャを停止する必要があります。
    Hinemosマネージャの停止方法については、以下のマニュアルをご参照ください。

    『インストールマニュアル(Linux版マネージャ)  4.3 Linux版マネージャの停止』

手順A-2 Hinemosアクティベーションパッチを適用する

     作業ディレクトリの移動
    (root) # cd /tmp/patch_manager_activation_for6.1.x_yyyymmdd

     ファイルのコピー
    (root) # cp -p Publish.jar /opt/hinemos/lib/

     ファイルの権限変更
    (root) # chown hinemos:hinemos /opt/hinemos/lib/Publish.jar

手順A-3 アクティベーションキーを配置する

    エンタープライズ機能をご利用の場合は、キーファイルyyyymm_xxx_enterpriseを
    Hinemosマネージャサーバのインストール先のetcディレクトリに配置します。

    (root) # cp -p yyyymm_xxx_enterprise /opt/hinemos/etc/


    クラウド管理・VM管理機能をご利用の場合は、キーファイルyyyymm_xxx_enterpriseと
    キーファイルyyyymm_xxx_xcloudを両方配置します。

    (root) # cp -p yyyymm_xxx_enterprise /opt/hinemos/etc/
    (root) # cp -p yyyymm_xxx_xcloud /opt/hinemos/etc/

手順A-4 Hinemosマネージャを起動する

    Hinemosマネージャの起動方法については、以下のマニュアルをご参照ください。

    『インストールマニュアル(Linux版マネージャ)  4.2 Linux版マネージャの起動』

    起動後、エンタープライズ機能またはクラウド管理・VM管理機能が有効となっていることを
    ご確認ください。


[手順(ミッションクリティカルオプション利用環境)]

下記ドキュメントに従い、両系のHinemosマネージャにパッチを適用してください。

    Hinemosミッションクリティカル機能 ver.6.2 ユーザマニュアル (Linux版) 第1版
    5.5 Hinemosマネージャ(HA構成)へのパッチ適用

各マネージャサーバへのパッチとアクティベーションキーの適用手順については、
手順A-2と手順A-3をご参照ください。


■注意事項

1. Hinemosアクティベーションパッチの適用後、必ず有効なアクティベーションキーを配置してください。
   アクティベーションキーが正しく配置されていない、もしくは有効でない場合は、
   Hinemosマネージャが正しく起動しません。

2. Hinemosクライアント側は特に追加の設定は不要ですが、
   Hinemosマネージャ側でエンタープライズ機能またはクラウド管理・VM管理機能を有効化すると、
   初回ログイン時のみHinemosクライアントが初期画面(スタートアップパースペクティブ)にリセットされます。


■MD5
Name         MD5                               Bytes
-----------  --------------------------------  ------
Publish.jar  A4AAEC3117AEFFCA5D795116E31DD06F   8,511
-----------------------------------------------------
Total  1 Files  8,511 Bytes
