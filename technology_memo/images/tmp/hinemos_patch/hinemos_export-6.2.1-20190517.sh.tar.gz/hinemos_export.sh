
#!/bin/bash

#Copyright (C) since 2015 NTT DATA Corporation
#
#This program is free software; you can redistribute it and/or
#Modify it under the terms of the GNU General Public License
#as published by the Free Software Foundation, version 2.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details

# version 6.1

# bash configuration
SCRIPT_DIR=$(cd $(dirname $0);pwd)
. ${SCRIPT_DIR}/../../hinemos.cfg
. ${SCRIPT_DIR}/../hinemos_utility.sh

USER=`/usr/bin/whoami`
HOST=`hostname`
# LANG=en_US.UTF-8
# LANG=ja_JP.UTF-8

########################################
# Local Variable
########################################
DB_USER=hinemos
DB_NAME=hinemos
DB_PORT=24001

DATE=`date "+%Y-%m-%d_%H%M%S"`

EXPORT_EVENT_DIR=hinemos_event_${DATE}
EXPORT_JOB_DIR=hinemos_job_${DATE}
EXPORT_PERF_DIR=hinemos_perf_${DATE}
EXPORT_LOG_DIR=hinemos_log_${DATE}
EXPORT_BINARY_DIR=hinemos_binary_${DATE}

REV=0

########################################
#  Local Message
########################################

# INFO
MSG_I021="Start to get events from Hinemos."
MSG_I031="Start to get job histories from Hinemos."
MSG_I041="Start to get collected performance data from Hinemos."
MSG_I051="Start to get collected log data from Hinemos."
MSG_I061="Start to get collected binary data from Hinemos."
MSG_I901="Done."

# WARN
#MSG_W001="xxx"

# ERROR
MSG_E001="Failed."


########################################
# Function
########################################
function usage {
    cat <<EOF
Usage: ${PROG} [options] output_directory

Options:
    -e                          export events
    -j                          export job histories
    -p MODE                     export performance data
                                   MODE : m    fetch collected data by monitor ID
                                   MODE : f    fetch collected data by facility ID
    -l MODE                     export log data
                                   MODE : m    fetch collected data by monitor ID
                                   MODE : f    fetch collected data by facility ID
    -b MONITOR_ID [FACILITY_ID] export binary data
                                   MONITOR_ID  : monitor ID
                                   FACILITY_ID : facility ID
    -f 'yyyy-MM-dd HH:mm:ss'    from 'yyyy-MM-dd HH:mm:ss'
    -t 'yyyy-MM-dd HH:mm:ss'    to   'yyyy-MM-dd HH:mm:ss'
    -w PASSWORD                 set password (for Hinemos RDBM Server)

EOF
}

########################################
# Function
########################################

## export event function
function export_event_all {
    ## event download
    Logging "${MSG_I021}"

    ## output directory
    DIR=${DUMP_PATH}/${EXPORT_EVENT_DIR}
    if [ -d "${DIR}" ]; then
        Logging "${MSG_E001} ${DIR} is already exist!"
        exit 4
    else
        Logging "output dir is ${DIR}"
        mkdir -p "${DIR}"
        chown hinemos:hinemos "${DIR}/"
    fi

    FILE_NAME="${DIR}/hinemos_event_all.csv"
    Logging "file name : ${FILE_NAME}"
    if [ -e "${FILE_NAME}" ]; then
        Logging "${MSG_E001} file "${FILE_NAME}" already exists. please remove it at first,and try again."
        exit 4
    fi

    ## create temporary table for monitor name translation
    TEMPORARY_TBL=$(build_temp_table_sql)

    ## cast generation_date bigint to timestamp using TO_TIMESTAMP
    if [ -n "${FROM}" -a -n "${TO}" ]; then
        WHERE_CLAUSE="
            WHERE
                ( TO_TIMESTAMP(generation_date / 1000) >= (timestamp '${FROM}'))
                AND ( TO_TIMESTAMP(generation_date / 1000) <= (timestamp '${TO}'))
"
    elif [ -n "${FROM}" ]; then
        WHERE_CLAUSE="
            WHERE
                TO_TIMESTAMP(generation_date / 1000) >= (timestamp '${FROM}')
"
    elif [ -n "${TO}" ]; then
        WHERE_CLAUSE="
            WHERE
                TO_TIMESTAMP(generation_date / 1000) <= (timestamp '${TO}')
"
    else
        WHERE_CLAUSE=""
    fi

    SQL="
        ${TEMPORARY_TBL}
        COPY (
            SELECT
                e.monitor_id,
                e.monitor_detail_id,
                e.plugin_id,
                TO_CHAR(TO_TIMESTAMP(e.generation_date / 1000), 'YYYY-MM-DD HH24:MI:SS') AS generation_date,
                e.facility_id,
                e.scope_text,
                e.application,
                pg_temp.replace_message(e.message) AS message,
                pg_temp.replace_message(e.message_org) AS message_org,
                e.priority,
                e.confirm_flg,
                e.confirm_date,
                e.confirm_user,
                e.duplication_count,
                TO_CHAR(TO_TIMESTAMP(e.output_date / 1000), 'YYYY-MM-DD HH24:MI:SS') AS output_date,
                e.inhibited_flg,
                e.comment_date,
                e.comment_user,
                e.comment,
                e.collect_graph_flg,
                e.owner_role_id,
                e.position,
                e.user_item01,
                e.user_item02,
                e.user_item03,
                e.user_item04,
                e.user_item05,
                e.user_item06,
                e.user_item07,
                e.user_item08,
                e.user_item09,
                e.user_item10,
                e.user_item11,
                e.user_item12,
                e.user_item13,
                e.user_item14,
                e.user_item15,
                e.user_item16,
                e.user_item17,
                e.user_item18,
                e.user_item19,
                e.user_item20,
                e.user_item21,
                e.user_item22,
                e.user_item23,
                e.user_item24,
                e.user_item25,
                e.user_item26,
                e.user_item27,
                e.user_item28,
                e.user_item29,
                e.user_item30,
                e.user_item31,
                e.user_item32,
                e.user_item33,
                e.user_item34,
                e.user_item35,
                e.user_item36,
                e.user_item37,
                e.user_item38,
                e.user_item39,
                e.user_item40
            FROM
                log.cc_event_log e
            ${WHERE_CLAUSE}
            ORDER BY e.generation_date, e.facility_id, e.monitor_id
        ) TO '${FILE_NAME}' WITH CSV HEADER
"

    SQL_FILE=./tmp_sql.sql
    echo "${SQL}" > ${SQL_FILE}
    MSG=`${PG_HOME}/bin/psql -U ${DB_USER} -p ${DB_PORT} -f ${SQL_FILE}`
    rm -f ${SQL_FILE}
    RET=$?
    if [ ${RET} -ne 0 ]; then
        Logging "${MSG}"
        Logging "${MSG_E001} export ${FILE_NAME} failed!"
        RET=$((16 + ${RET}))
        return ${RET}
    fi

    return 0
}


## export job histories function
function export_job_histories {
    ## job histories download
    Logging "${MSG_I031}"

    ## output directory
    DIR=${DUMP_PATH}/${EXPORT_JOB_DIR}
    if [ -d "${DIR}" ]; then
        Logging "${MSG_E001} ${DIR} is already exist!"
        exit 4
    else
        Logging "output dir is ${DIR}"
        mkdir -p "${DIR}"
        chown hinemos:hinemos "${DIR}/"
    fi

    FILE_NAME="${DIR}/hinemos_job_history_all.csv"
    Logging "file name : ${FILE_NAME}"
    if [ -e "${FILE_NAME}" ]; then
        Logging "${MSG_E001} file "${FILE_NAME}" already exists. please remove it at first,and try again."
        exit 4
    fi

    ## cast start_date bigint to timestamp using TO_TIMESTAMP
    F=`echo -n ${FROM} | tr -d ": -"`
    T=`echo -n ${TO} | tr -d ": -"`
    if [ -n "${FROM}" -a -n "${TO}" ]; then
        WHERE_CLAUSE="
            WHERE
                session_id >= '${F}-000' AND session_id <= '${T}-000' AND jobunit_id <> '_ROOT_'
"
    elif [ -n "${FROM}" ]; then
        WHERE_CLAUSE="
            WHERE
                session_id >= '${F}-000' AND jobunit_id <> '_ROOT_'
"
    elif [ -n "${TO}" ]; then
        WHERE_CLAUSE="
            WHERE
                session_id <= '${T}-000' AND jobunit_id <> '_ROOT_'
"
    else
        WHERE_CLAUSE="
            WHERE
               jobunit_id <> '_ROOT_'
"
    fi
    SQL="
        COPY (
            SELECT
                session_id,
                jobunit_id,
                job_id,
                scope_text,
                status,
                TO_CHAR(TO_TIMESTAMP(start_date / 1000), 'YYYY-MM-DD HH24:MI:SS') AS start_date,
                TO_CHAR(TO_TIMESTAMP(end_date / 1000), 'YYYY-MM-DD HH24:MI:SS') AS end_date,
                end_value,
                end_status,
                result,
                end_staus_check_flg,
                delay_notify_flg,
                parent_jobunit_id,
                parent_job_id,
                owner_role_id
            FROM log.cc_job_session_job
            ${WHERE_CLAUSE}
            ORDER BY session_id
        ) TO '${FILE_NAME}' WITH CSV HEADER
"

    MSG=`${PG_HOME}/bin/psql -U ${DB_USER} -p ${DB_PORT} -c "${SQL}"`
    RET=$?
    if [ ${RET} -ne 0 ]; then
        Logging "${MSG}"
        Logging "${MSG_E001} export ${FILE_NAME} failed!"
        RET=$((16 + ${RET}))
        return ${RET}
    fi

    return 0
}


## export performance data function
function export_collect_perform {
    ## setting
    EXPORT_MODE=$1

    ## collect data download
    Logging "${MSG_I041}  mode=${EXPORT_MODE}"

    ## output directory
    DIR=${DUMP_PATH}/${EXPORT_PERF_DIR}
    if [ -d "${DIR}" ]; then
        Logging "${MSG_E001} ${DIR} is already exist!"
        exit 4
    else
        Logging "output dir is ${DIR}"
        mkdir -p "${DIR}"
        chown hinemos:hinemos "${DIR}/"
    fi

    ## output a period of time setting
    ## cast time bigint to timestamp using TO_TIMESTAMP
    if [ -n "${FROM}" -a -n "${TO}" ]; then
        WHERE_TIME="TO_TIMESTAMP(time / 1000) >= (timestamp '${FROM}') AND TO_TIMESTAMP(time / 1000) <= (timestamp '${TO}')"
    elif [ -n "${FROM}" ]; then
        WHERE_TIME="TO_TIMESTAMP(time / 1000) >= (timestamp '${FROM}')"
    elif [ -n "${TO}" ]; then
        WHERE_TIME="TO_TIMESTAMP(time / 1000) <= (timestamp '${TO}')"
    else
        WHERE_TIME=""
    fi


    ## main logic
    if [ "${EXPORT_MODE}" == "m" ]; then
        ## create temporary table for monitor name translation
        TEMPORARY_TBL=$(build_temp_table_sql)

        ## get monitorid list
        LIST="${DIR}/monitorid.list"

        if [ -n "${WHERE_TIME}" ]; then
            SQL="
            COPY (
                SELECT distinct k.monitor_id FROM log.cc_collect_key k WHERE k.collector_id in ( 
                    SELECT distinct collector_id from log.cc_collect_data_raw WHERE ${WHERE_TIME}
                    UNION
                    SELECT distinct collector_id from log.cc_collect_summary_hour WHERE ${WHERE_TIME}
                    UNION
                    SELECT distinct collector_id from log.cc_collect_summary_day WHERE ${WHERE_TIME}
                    UNION
                    SELECT distinct collector_id from log.cc_collect_summary_month WHERE ${WHERE_TIME}
                )
            ) TO '${LIST}' WITH CSV
"
        else
            SQL="COPY (SELECT distinct monitor_id FROM log.cc_collect_key) TO '${LIST}' WITH CSV"
        fi

        MSG=`${PG_HOME}/bin/psql -U ${DB_USER} -p ${DB_PORT} -c "${SQL}"`
        RET=$?
        if [ ${RET} -ne 0 ]; then
            Logging "${MSG}"
            Logging "${MSG_E001} export ${LIST} failed! please check ${DIR} is accessable for hinemos user!"
            RET=$((16 + ${RET}))
            return ${RET}
        fi

        ## loop for collector list
        ## raw data
        for MONID in `cat "${LIST}"`
        do
            ## settings
            EXPORT_FILE="${DIR}/${MONID}.csv"
            VALUE_COLUMNS="
                d.value,
                d.average,
                d.standard_deviation
"
            DATA_TBL='log.cc_collect_data_raw'

            if [ -n "${WHERE_TIME}" ]; then
                WHERE_CLAUSE="AND ${WHERE_TIME}"
            else
                WHERE_CLAUSE=""
            fi
            SQL=$(build_collect_sql)
            ## export
            export_zip
        done

        ## hour summary
        for MONID in `cat "${LIST}"`
        do
            ## settings
            EXPORT_FILE="${DIR}/${MONID}_summary_hour.csv"
            VALUE_COLUMNS="
                d.avg,
                d.min,
                d.max,
                d.count,
                d.average_avg,
                d.average_count,
                d.standard_deviation_avg,
                d.standard_deviation_count
"
            DATA_TBL='log.cc_collect_summary_hour'

            if [ -n "${WHERE_TIME}" ]; then
                WHERE_CLAUSE="AND ${WHERE_TIME}"
            else
                WHERE_CLAUSE=""
            fi
            SQL=$(build_collect_sql)
            ## export
            export_zip
        done

        ## day summary
        for MONID in `cat "${LIST}"`
        do
            ## settings
            EXPORT_FILE="${DIR}/${MONID}_summary_day.csv"
            VALUE_COLUMNS="
                d.avg,
                d.min,
                d.max,
                d.count,
                d.average_avg,
                d.average_count,
                d.standard_deviation_avg,
                d.standard_deviation_count
"
            DATA_TBL='log.cc_collect_summary_day'

            if [ -n "${WHERE_TIME}" ]; then
                WHERE_CLAUSE="AND ${WHERE_TIME}"
            else
                WHERE_CLAUSE=""
            fi
            SQL=$(build_collect_sql)
            ## export
            export_zip
        done

        ## month summary
        for MONID in `cat "${LIST}"`
        do
            ## settings
            EXPORT_FILE="${DIR}/${MONID}_summary_month.csv"
            VALUE_COLUMNS="
                d.avg,
                d.min,
                d.max,
                d.count,
                d.average_avg,
                d.average_count,
                d.standard_deviation_avg,
                d.standard_deviation_count
"
            DATA_TBL='log.cc_collect_summary_month'

            if [ -n "${WHERE_TIME}" ]; then
                WHERE_CLAUSE="AND ${WHERE_TIME}"
            else
                WHERE_CLAUSE=""
            fi
            SQL=$(build_collect_sql)
            ## export
            export_zip
        done

    elif [ "${EXPORT_MODE}" == "f" ]; then
        ## create temporary table for monitor name translation
        TEMPORARY_TBL=$(build_temp_table_sql)

        ## get monitorid and facility list
        LIST="${DIR}/monitorid_facility.list"

        if [ -n "${WHERE_TIME}" ]; then
            SQL="
            COPY (
                SELECT  k.monitor_id,  k.facility_id FROM log.cc_collect_key k
                WHERE k.collector_id in ( 
                    SELECT distinct collector_id from log.cc_collect_data_raw WHERE ${WHERE_TIME}
                    UNION
                    SELECT distinct collector_id from log.cc_collect_summary_hour WHERE ${WHERE_TIME}
                    UNION
                    SELECT distinct collector_id from log.cc_collect_summary_day WHERE ${WHERE_TIME}
                    UNION
                    SELECT distinct collector_id from log.cc_collect_summary_month WHERE ${WHERE_TIME}
                )
                GROUP BY  k.monitor_id, k.facility_id
                ORDER BY  k.monitor_id, k.facility_id
            ) TO '${LIST}' WITH CSV
"
        else
            SQL="COPY (SELECT monitor_id,facility_id FROM log.cc_collect_key GROUP BY monitor_id,facility_id ORDER BY monitor_id,facility_id) TO '${LIST}' WITH CSV"
        fi

        MSG=`${PG_HOME}/bin/psql -U ${DB_USER} -p ${DB_PORT} -c "${SQL}"`
        RET=$?
        if [ ${RET} -ne 0 ]; then
            Logging "${MSG}"
            Logging "${MSG_E001} export ${LIST} failed! please check ${DIR} is accessable for hinemos user!"
            RET=$((16 + ${RET}))
            exit ${RET}
        fi

        ## loop for collector list
        for IDS in `cat "${LIST}"`
        do
            ## settings
            MONID=`echo ${IDS} | awk -F "," '{ print $1 }'`
            FACID=`echo ${IDS} | awk -F "," '{ print $2 }'`
            EXPORT_FILE="${DIR}/${MONID}_${FACID}.csv"
            VALUE_COLUMNS="
                d.value,
                d.average,
                d.standard_deviation
"
            DATA_TBL='log.cc_collect_data_raw'

            if [ -n "${WHERE_TIME}" ]; then
                WHERE_CLAUSE="AND k.facility_id = '${FACID}' AND ${WHERE_TIME}"
            else
                WHERE_CLAUSE="AND k.facility_id = '${FACID}'"
            fi
            SQL=$(build_collect_sql)
            ## export
            export_zip
        done

        ## hour summary
        for IDS in `cat "${LIST}"`
        do
            ## settings
            MONID=`echo ${IDS} | awk -F "," '{ print $1 }'`
            FACID=`echo ${IDS} | awk -F "," '{ print $2 }'`
            EXPORT_FILE="${DIR}/${MONID}_${FACID}_summary_hour.csv"
            VALUE_COLUMNS="
                d.avg,
                d.min,
                d.max,
                d.count,
                d.average_avg,
                d.average_count,
                d.standard_deviation_avg,
                d.standard_deviation_count
"
            DATA_TBL='log.cc_collect_summary_hour'

            if [ -n "${WHERE_TIME}" ]; then
                WHERE_CLAUSE="AND k.facility_id = '${FACID}' AND ${WHERE_TIME}"
            else
                WHERE_CLAUSE="AND k.facility_id = '${FACID}'"
            fi
            SQL=$(build_collect_sql)
            ## export
            export_zip
        done

        ## day summary
        for IDS in `cat "${LIST}"`
        do
            ## settings
            MONID=`echo ${IDS} | awk -F "," '{ print $1 }'`
            FACID=`echo ${IDS} | awk -F "," '{ print $2 }'`
            EXPORT_FILE="${DIR}/${MONID}_${FACID}_summary_day.csv"
            VALUE_COLUMNS="
                d.avg,
                d.min,
                d.max,
                d.count,
                d.average_avg,
                d.average_count,
                d.standard_deviation_avg,
                d.standard_deviation_count
"
            DATA_TBL='log.cc_collect_summary_day'

            if [ -n "${WHERE_TIME}" ]; then
                WHERE_CLAUSE="AND k.facility_id = '${FACID}' AND ${WHERE_TIME}"
            else
                WHERE_CLAUSE="AND k.facility_id = '${FACID}'"
            fi
            SQL=$(build_collect_sql)
            ## export
            export_zip
        done

        ## month summary
        for IDS in `cat "${LIST}"`
        do
            ## settings
            MONID=`echo ${IDS} | awk -F "," '{ print $1 }'`
            FACID=`echo ${IDS} | awk -F "," '{ print $2 }'`
            EXPORT_FILE="${DIR}/${MONID}_${FACID}_summary_month.csv"
            VALUE_COLUMNS="
                d.avg,
                d.min,
                d.max,
                d.count,
                d.average_avg,
                d.average_count,
                d.standard_deviation_avg,
                d.standard_deviation_count
"
            DATA_TBL='log.cc_collect_summary_month'

            if [ -n "${WHERE_TIME}" ]; then
                WHERE_CLAUSE="AND k.facility_id = '${FACID}' AND ${WHERE_TIME}"
            else
                WHERE_CLAUSE="AND k.facility_id = '${FACID}'"
            fi
            SQL=$(build_collect_sql)
            ## export
            export_zip
        done

    else
        Logging "${MSG_E001} internal error MODE ${EXPORT_MODE} is not supported"
        return 1
    fi

    return 0
}


## export log data function
function export_collect_log {
    ## setting
    EXPORT_MODE=$1

    ## collect data download
    Logging "${MSG_I051}  mode=${EXPORT_MODE}"

    ## output directory
    DIR=${DUMP_PATH}/${EXPORT_LOG_DIR}
    if [ -d "${DIR}" ]; then
        Logging "${MSG_E001} ${DIR} is already exist!"
        exit 4
    else
        Logging "output dir is ${DIR}"
        mkdir -p "${DIR}"
        chown hinemos:hinemos "${DIR}/"
    fi

    ## output a period of time setting
    ## cast time bigint to timestamp using TO_TIMESTAMP
    if [ -n "${FROM}" -a -n "${TO}" ]; then
        WHERE_TIME="TO_TIMESTAMP(time / 1000) >= (timestamp '${FROM}') AND TO_TIMESTAMP(time / 1000) <= (timestamp '${TO}')"
    elif [ -n "${FROM}" ]; then
        WHERE_TIME="TO_TIMESTAMP(time / 1000) >= (timestamp '${FROM}')"
    elif [ -n "${TO}" ]; then
        WHERE_TIME="TO_TIMESTAMP(time / 1000) <= (timestamp '${TO}')"
    else
        WHERE_TIME=""
    fi


    ## main logic
    if [ "${EXPORT_MODE}" == "m" ]; then
        ## create temporary table for monitor name translation
        TEMPORARY_TBL=$(build_temp_table_sql)
        ## get monitorid list
        LIST="${DIR}/monitorid.list"

        if [ -n "${WHERE_TIME}" ]; then
            SQL="
            COPY (
                SELECT
                    distinct k.monitor_id
                FROM
                    log.cc_collect_string_key k
                INNER JOIN
                    log.cc_collect_data_string d
                    ON k.collect_id = d.collect_id
                WHERE ${WHERE_TIME}
            ) TO '${LIST}' WITH CSV
"

        else
            SQL="
            COPY (
                SELECT
                    distinct k.monitor_id
                FROM
                    log.cc_collect_string_key k
                INNER JOIN
                    log.cc_collect_data_string d
                    ON k.collect_id = d.collect_id
            ) TO '${LIST}' WITH CSV
"
        fi

        MSG=`${PG_HOME}/bin/psql -U ${DB_USER} -p ${DB_PORT} -c "${SQL}"`
        RET=$?
        if [ ${RET} -ne 0 ]; then
            Logging "${MSG}"
            Logging "${MSG_E001} export ${LIST} failed! please check ${DIR} is accessable for hinemos user!"
            RET=$((16 + ${RET}))
            return ${RET}
        fi

        ## collected log string
        for MONID in `cat "${LIST}"`
        do
            ## settings
            EXPORT_FILE="${DIR}/${MONID}.csv"

            if [ -n "${WHERE_TIME}" ]; then
                WHERE_CLAUSE="AND ${WHERE_TIME}"
            else
                WHERE_CLAUSE=""
            fi
            SQL=$(build_collect_log_sql)
            ## export
            export_zip
        done

    elif [ "${EXPORT_MODE}" == "f" ]; then
        ## create temporary table for monitor name translation
        TEMPORARY_TBL=$(build_temp_table_sql)
        ## get log monitorid and facility list
        LIST="${DIR}/monitorid_facility.list"

        if [ -n "${WHERE_TIME}" ]; then
            SQL="
            COPY (
                SELECT
                    k.monitor_id,
                    k.facility_id
                FROM
                    log.cc_collect_string_key k
                INNER JOIN
                    log.cc_collect_data_string d
                    ON k.collect_id = d.collect_id
                WHERE
                    ${WHERE_TIME}
                GROUP BY
                    k.monitor_id, k.facility_id
                ORDER BY
                    k.monitor_id, k.facility_id

            ) TO '${LIST}' WITH CSV
"
        else
            SQL="
            COPY (
                SELECT
                    k.monitor_id,
                    k.facility_id
                FROM
                    log.cc_collect_string_key k
                INNER JOIN
                    log.cc_collect_data_string d
                    ON k.collect_id = d.collect_id
                GROUP BY
                    k.monitor_id, k.facility_id
                ORDER BY
                    k.monitor_id, k.facility_id

            ) TO '${LIST}' WITH CSV
"
        fi

        MSG=`${PG_HOME}/bin/psql -U ${DB_USER} -p ${DB_PORT} -c "${SQL}"`
        RET=$?
        if [ ${RET} -ne 0 ]; then
            Logging "${MSG}"
            Logging "${MSG_E001} export ${LIST} failed! please check ${DIR} is accessable for hinemos user!"
            RET=$((16 + ${RET}))
            exit ${RET}
        fi

        ## collected log string
        for IDS in `cat "${LIST}"`
        do
            ## settings
            MONID=`echo ${IDS} | awk -F "," '{ print $1 }'`
            FACID=`echo ${IDS} | awk -F "," '{ print $2 }'`
            EXPORT_FILE="${DIR}/${MONID}_${FACID}.csv"

            if [ -n "${WHERE_TIME}" ]; then
                WHERE_CLAUSE="AND k.facility_id = '${FACID}' AND ${WHERE_TIME}"
            else
                WHERE_CLAUSE="AND k.facility_id = '${FACID}'"
            fi
            SQL=$(build_collect_log_sql)
            ## export
            export_zip
        done

    else
        Logging "${MSG_E001} internal error MODE ${EXPORT_MODE} is not supported"
        return 1
    fi

    return 0
}

## export binary log data function
function export_collect_binary {
    ## setting
    if [ "x$FROM" = "x" ]
    then
        FROM=`date '+%Y%m%d'`
        B_FROM=`date '+%Y-%m-%d %T' --date ${FROM}`
    else
        B_FROM=$FROM
    fi
    if [ "x$TO" = "x" ]
    then
        B_TO=`date '+%Y-%m-%d %T' --date 'today'`
    else
        B_TO=$TO
    fi
    if [ "x$B_FID" = "x" ]
    then
        B_FID="all"
    fi

    ## collect data download
    Logging "${MSG_I061}"
    Logging "conditions :"
    Logging "  monitorID  = [${B_MONID}]"
    Logging "  facilityID = [${B_FID}]"
    Logging "  time       = [${B_FROM}] --> [${B_TO}]"

    ## output a period of time setting
    ## cast time bigint to timestamp using TO_TIMESTAMP
    WHERE_TIME="TO_TIMESTAMP(d.time / 1000) >= (timestamp '${B_FROM}') AND TO_TIMESTAMP(d.time / 1000) <= (timestamp '${B_TO}')"
    
    ## cast time to add file name
    B_FROM=`echo -n ${B_FROM} | sed -e "s/-/\//g"`
    B_FROM=`date '+%Y-%m-%d-%H-%M-%S' --date "${B_FROM}"`
    B_TO=`echo -n ${B_TO} | sed -e "s/-/\//g"`
    B_TO=`date '+%Y-%m-%d-%H-%M-%S' --date "${B_TO}"`

    ## check exist data
    if [ ${B_FID} = "all" ]
    then
        WHERE_FID=""
    else
        WHERE_FID="AND k.facility_id = '${B_FID}'"
    fi
    VIEW_CONDITION="
        FROM
            log.cc_collect_data_binary d
        INNER JOIN
            log.cc_collect_string_key k
            ON k.collect_id = d.collect_id
        INNER JOIN
            setting.cc_monitor_info s
            ON s.monitor_id = k.monitor_id
        WHERE
            s.monitor_id = '${B_MONID}'
            ${WHERE_FID}
            AND d.file_position = 'file.position.end'
            AND ${WHERE_TIME}
"
    SQL="
        SELECT
            COUNT(DISTINCT d)
        ${VIEW_CONDITION}
"
    MSG=`${PG_HOME}/bin/psql -t -A -p ${DBPORT} -U ${DB_USER} -d ${DB_NAME} -c "${SQL}" 2>&1`
    RET=$?
    if [ ${RET} -ne 0 ]; then
        Logging "${MSG}"
        Logging "${MSG_E001} export failed!"
        RET=$((16 + ${RET}))
        exit ${RET}
    fi
    if [ ! ${MSG} -gt 0 ]; then
        Logging "${MSG_E001} Data under the conditions doesn't exist!"
        exit 4
    fi

    ## output directory
    DIR=${DUMP_PATH}/${EXPORT_BINARY_DIR}
    if [ -d "${DIR}" ]; then
        Logging "${MSG_E001} ${DIR} is already exist!"
        exit 4
    else
        Logging "output dir is ${DIR}"
        mkdir -p "${DIR}"
        chown hinemos:hinemos "${DIR}/"
    fi

    ## main logic
    ## get primary keys
    SQL="
        SELECT
            d.collect_id,
            d.data_id,
            k.facility_id
        ${VIEW_CONDITION}
"
    KEYS=`${PG_HOME}/bin/psql -t -A -p ${DBPORT} -U ${DB_USER} -d ${DB_NAME} -c "${SQL}" 2>&1`
    RET=$?
    if [ ${RET} -ne 0 ]; then
        Logging "${KEYS}"
        Logging "${MSG_E001} export failed!"
        RET=$((16 + ${RET}))
        exit ${RET}
    fi
    COLLECT_IDS=()
    DATA_IDS=()
    FACILITY_IDS=()
    for VALUE in ${KEYS}
    do
        TMP=`echo -n ${VALUE} | sed -e "s/|.*$//"`
        COLLECT_IDS+=("${TMP}")
        TMP=`echo -n ${VALUE} | sed -e "s/^${TMP}|//"`
        TMP2=`echo -n ${TMP} | sed -e "s/|.*$//"`
        DATA_IDS+=("${TMP2}")
        TMP=`echo -n ${TMP} | sed -e "s/^.*|//"`
        FACILITY_IDS+=("${TMP}")
    done
    
    ## process by a primary key
    EXPORT_LIST=()
    COUNT=`expr ${#COLLECT_IDS[*]} - 1`
    for i in `seq 0 ${COUNT}`
    do        
        ## set directory
        DIR="${DUMP_PATH}/${EXPORT_BINARY_DIR}/${B_MONID}_${FACILITY_IDS[${i}]}"
        if [ ! -d "${DIR}" ]; then
            mkdir -p "${DIR}"
            chown hinemos:hinemos "${DIR}/"
            EXPORT_LIST+=("${DIR}")
        fi
        
        ## set query to get tag data
        TAG_SQL="
            SELECT
                tag_value
            FROM
                log.cc_collect_binary_data_tag
            WHERE
                collect_id = '${COLLECT_IDS[${i}]}' AND
                data_id = '${DATA_IDS[${i}]}' AND
"
        
        ## get collect type
        SQL="
            SELECT
                collect_type
            FROM
                log.cc_collect_data_binary
            WHERE
                collect_id = '${COLLECT_IDS[${i}]}' AND
                data_id = '${DATA_IDS[${i}]}'
"

        MSG=`${PG_HOME}/bin/psql -t -A -p ${DBPORT} -U ${DB_USER} -d ${DB_NAME} -c "${SQL}" 2>&1`
        RET=$?
        if [ ${RET} -ne 0 ]; then
            Logging "${MSG}"
            Logging "${MSG_E001} export failed!"
            RET=$((16 + ${RET}))
            exit ${RET}
        fi
        COLLECT_TYPE=${MSG}

        ## get file name
        SQL="${TAG_SQL}
                tag_key = 'FileName'
"
        MSG=`${PG_HOME}/bin/psql -t -A -p ${DBPORT} -U ${DB_USER} -d ${DB_NAME} -c "${SQL}" 2>&1`
        RET=$?
        if [ ${RET} -ne 0 ]; then
            Logging "${MSG}"
            Logging "${MSG_E001} export failed!"
            RET=$((16 + ${RET}))
            exit ${RET}
        fi
        FILE_NAME=${MSG}
        
        ## cut only file name
        TMP=`echo -n ${FILE_NAME} | sed -e "s/^.*[/]//"`
        if [ ${TMP} = ${FILE_NAME} ]
        then
            FILE_NAME=`echo -n ${FILE_NAME} | sed -e "s/^.*[\]//"`
        else
            FILE_NAME=${TMP}
        fi
        
        ## create file
        if [ "${COLLECT_TYPE}" = "binary.collect.type.individual" ]
        then
            ## get time of a record
            SQL="
                SELECT
                    time
                FROM
                    log.cc_collect_data_binary
                WHERE
                    collect_id = '${COLLECT_IDS[${i}]}' AND
                    data_id = '${DATA_IDS[${i}]}'
"
            MSG=`${PG_HOME}/bin/psql -t -A -p ${DBPORT} -U ${DB_USER} -d ${DB_NAME} -c "${SQL}" 2>&1`
            RET=$?
            if [ ${RET} -ne 0 ]; then
                Logging "${MSG}"
                Logging "${MSG_E001} export failed!"
                RET=$((16 + ${RET}))
                exit ${RET}
            fi
            RECORD_TIME=${MSG}
            RECORD_TIME=`expr ${RECORD_TIME} / 1000`
            RECORD_TIME=`date '+%Y-%m-%d-%H-%M-%S' --date @${RECORD_TIME}`
            
            ## add collected time to file name
            FILE_NAME="${DIR}/${FILE_NAME}.${RECORD_TIME}"
            HEX_FILE="${FILE_NAME}.hex"
            
            ## get file key
            SQL="
                SELECT
                    file_key
                FROM
                    log.cc_collect_data_binary
                WHERE
                    collect_id = '${COLLECT_IDS[${i}]}' AND
                    data_id = '${DATA_IDS[${i}]}'
"
            MSG=`${PG_HOME}/bin/psql -t -A -p ${DBPORT} -U ${DB_USER} -d ${DB_NAME} -c "${SQL}" 2>&1`
            RET=$?
            if [ ${RET} -ne 0 ]; then
                Logging "${MSG}"
                Logging "${MSG_E001} export failed!"
                RET=$((16 + ${RET}))
                exit ${RET}
            fi
            FILE_KEY=${MSG}
            
            ## get primary keys of a file
            SQL="
                SELECT
                    collect_id,
                    data_id
                FROM
                    log.cc_collect_data_binary
                WHERE
                    file_key = '${FILE_KEY}'
                ORDER BY record_key
"
            KEYS=`${PG_HOME}/bin/psql -t -A -p ${DBPORT} -U ${DB_USER} -d ${DB_NAME} -c "${SQL}" 2>&1`
            RET=$?
            if [ ${RET} -ne 0 ]; then
                Logging "${KEYS}"
                Logging "${MSG_E001} export failed!"
                RET=$((16 + ${RET}))
                exit ${RET}
            fi
            FILE_COLLECT_IDS=()
            FILE_DATA_IDS=()
            for VALUE in ${KEYS}
            do
                TMP=`echo -n ${VALUE} | sed -e "s/|.*$//"`
                FILE_COLLECT_IDS+=("${TMP}")
                TMP=`echo -n ${VALUE} | sed -e "s/^.*|//"`
                FILE_DATA_IDS+=("${TMP}")
            done
            
            ## process by a record of a file
            REC_COUNT=`expr ${#FILE_COLLECT_IDS[*]} - 1`
            for j in `seq 0 ${REC_COUNT}`
            do
                ## export hex file
                SQL="
                    COPY (
                        SELECT
                            encode(value, 'hex')
                        FROM
                            log.cc_collect_data_binary
                        WHERE
                            collect_id = '${FILE_COLLECT_IDS[${j}]}' AND
                            data_id = '${FILE_DATA_IDS[${j}]}'
                    ) TO '${HEX_FILE}';
"
                MSG=`${PG_HOME}/bin/psql -t -A -p ${DBPORT} -U ${DB_USER} -d ${DB_NAME} -c "${SQL}"`
                RET=$?
                if [ ${RET} -ne 0 ]; then
                    Logging "${MSG}"
                    Logging "${MSG_E001} export ${FILE_NAME} failed! please check ${DIR} is accessable for hinemos user!"
                    RET=$((16 + ${RET}))
                    exit ${RET}
                fi
                #convert the content of temp file to binary format
                xxd -p -r "${HEX_FILE}" >> "${FILE_NAME}"
                
                #remove temp file
                rm -f "${HEX_FILE}"
            done
        else
            ## add collected time to file name
            FILE_NAME="${DIR}/${FILE_NAME}.${B_FROM}_${B_TO}"
            HEX_FILE="${FILE_NAME}.hex"
            
            ## export hex file
            SQL="
                COPY (
                    SELECT
                        encode(value, 'hex')
                    FROM
                        log.cc_collect_data_binary
                    WHERE
                        collect_id = '${COLLECT_IDS[${i}]}' AND
                        data_id = '${DATA_IDS[${i}]}'
                ) TO '${HEX_FILE}';
"
            MSG=`${PG_HOME}/bin/psql -t -A -p ${DBPORT} -U ${DB_USER} -d ${DB_NAME} -c "${SQL}"`
            RET=$?
            if [ ${RET} -ne 0 ]; then
                Logging "${MSG}"
                Logging "${MSG_E001} export ${FILE_NAME} failed! please check ${DIR} is accessable for hinemos user!"
                RET=$((16 + ${RET}))
                exit ${RET}
            fi
            
            #check to exist exported file
            if [ -e "${FILE_NAME}" ]
            then
                ## get file header size
                SQL="
                    SELECT
                        file_head_size
                    FROM
                        log.cc_collect_data_binary
                    WHERE
                        collect_id = '${COLLECT_IDS[${i}]}' AND
                        data_id = '${DATA_IDS[${i}]}'
"
                MSG=`${PG_HOME}/bin/psql -t -A -p ${DBPORT} -U ${DB_USER} -d ${DB_NAME} -c "${SQL}" 2>&1`
                RET=$?
                if [ ${RET} -ne 0 ]; then
                    Logging "${MSG}"
                    Logging "${MSG_E001} export failed!"
                    RET=$((16 + ${RET}))
                    exit ${RET}
                fi
                FILE_HEADER_SIZE=${MSG}
                
                ## set file header size 
                if [ "x${FILE_HEADER_SIZE}" = "x" ] || [ ${FILE_HEADER_SIZE} -le 0 ]
                then
                    FILE_HEADER_SIZE=0
                fi
                
                ## cut file header
                FILE_HEADER_SIZE=`expr ${FILE_HEADER_SIZE} \* 2`
                FILE_HEADER_SIZE=`expr ${FILE_HEADER_SIZE} + 1`
                RECORD_SIZE=`cat "${HEX_FILE}" | wc -m`
                if [ ${FILE_HEADER_SIZE} -lt ${RECORD_SIZE} ]
                then
                    cat "${HEX_FILE}" | cut -c ${FILE_HEADER_SIZE}-${RECORD_SIZE} > "${HEX_FILE}"
                else
                    echo"" > "${HEX_FILE}"
                fi
            fi
            
            ## convert the content of temp file to binary format
            xxd -p -r "${HEX_FILE}" >> "${FILE_NAME}"
            
            ## remove temp file
            rm -f "${HEX_FILE}"
        fi
    done
    
    # compress export directory
    for i in `seq 1 ${#EXPORT_LIST[@]}`
    do
        EXPORT_FILE=${EXPORT_LIST[i-1]}
        Logging "export ${EXPORT_FILE}"
        ## compress export file
        zip -r "${EXPORT_FILE}.zip" "${EXPORT_FILE}"
        rm -rf "${EXPORT_FILE}"
    done
    return 0
}
# execute sql and create zipped csv
function export_zip {
    Logging "export ${EXPORT_FILE}"

    SQL_FILE=./tmp_sql.sql
    echo "${SQL}" > ${SQL_FILE}
    MSG=`${PG_HOME}/bin/psql -U ${DB_USER} -p ${DB_PORT} -f ${SQL_FILE}`
    rm -f ${SQL_FILE}
    RET=$?
    if [ ${RET} -ne 0 ]; then
        Logging "${MSG}"
        Logging "${MSG_E001} export ${EXPORT_FILE} failed!"
        RET=$((16 + ${RET}))
        return ${RET}
    fi

    ## compress export file
    zip "${EXPORT_FILE}.zip" "${EXPORT_FILE}"
    if [ ${RET} -eq 0 ]; then
        rm -f "${EXPORT_FILE}"
    fi
}

function build_temp_table_sql {
    ## translate monitor name from message file
    if [ "${LANG}" == "ja_JP.UTF-8" ]; then
        MESSAGE_FILE="${SCRIPT_DIR}/../../lib/messages_common_ja.properties"
    else
        MESSAGE_FILE="${SCRIPT_DIR}/../../lib/messages_common.properties"
    fi

    ## postgresql table function can't access pg_temp schema.
    ## so create temporary table in log schema and drop it finally.
    ## set client_min_messages warning on this session for disable table already exists notice.
    TEMPORARY_TBL="
        SET client_min_messages TO WARNING;
        CREATE TABLE IF NOT EXISTS log.temp_messages_map 
        AS SELECT item_name, item_message FROM ( VALUES
"
    while read -r line || [ -n "$line" ]
    do
        KEY=`echo ${line} | cut -d '=' -f 1`
        VAL=`echo ${line} | cut -d '=' -f 2-`
        ## remove last back slash if exists and escape single quotes
        VAL=e\'$(echo ${VAL} | sed -e 's/\\*$//g' | sed -e "s/'/\\\'/g")\'
        TEMPORARY_TBL="${TEMPORARY_TBL}('\$[${KEY}]', $VAL),"  ## insert values
    done < ${MESSAGE_FILE}
    ## remove last semi coron
    TEMPORARY_TBL=`echo ${TEMPORARY_TBL} | sed -e 's/.$//'`
    TEMPORARY_TBL="${TEMPORARY_TBL}) AS t (item_name, item_message);"

    ## add function to replace message
    ## event message and item_name of collect data contains following placeholders.
    ## replace these placeholders using messages_common table and functions.  
    ## 
    ## e.g.
    ## "$[PERF_CPU_USAGE] : xx %"  -> "CPU Usage : xx %"  
    ## 
    ## some messages also contain params as following.
    ## e.g.
    ## "$[FOO:param1\param2]" -> "foo({0}, {1})" -> "foo(param1, param2)"
    ##   
    TEMPORARY_TBL="
        ${TEMPORARY_TBL}
        CREATE FUNCTION pg_temp.replace_message(varchar)
        RETURNS varchar AS
        \$BODY\$
        DECLARE str varchar;
        DECLARE pattern_record record;
        DECLARE pattern varchar;
        DECLARE placeholder varchar;
        DECLARE name varchar;
        DECLARE message varchar;
        DECLARE params varchar[];
        BEGIN
            str = \$1;
            FOR pattern_record in select regexp_matches(str, '\\$\\[[^]]*\\]', 'g')
            LOOP
                pattern = (pattern_record.regexp_matches)[1];
                placeholder = regexp_replace(pattern, ':[^]]*\\]', ']');
                params = string_to_array(substring((regexp_matches(pattern, ':[^]]*'))[1] from 2), ':');
                SELECT item_name, item_message INTO name, message FROM log.temp_messages_map
                    WHERE item_name = placeholder;
                IF message IS NOT NULL THEN
                    IF params IS NOT NULL THEN
                        message = pg_temp.replace_param(message, params);
                    END IF;
                    str = replace(str, pattern, message);
                END IF;
            END LOOP;
            RETURN str;
        END;
        \$BODY\$
        LANGUAGE 'plpgsql';

        CREATE FUNCTION pg_temp.replace_param(varchar, varchar[])
        RETURNS varchar AS
        \$BODY\$
        DECLARE message varchar;
        DECLARE placeholder_record record;
        DECLARE placeholder varchar;
        DECLARE params varchar[];
        DECLARE param varchar;
        DECLARE index int;
        BEGIN
            message = \$1;    
            params = \$2;    
            index = 1;
            FOR placeholder_record in select regexp_matches(message, '\\{[0-9]*\\}', 'g')
            LOOP
                placeholder = (placeholder_record.regexp_matches)[1];
                param = params[index];
                message = replace(message, placeholder, param);
                index = index + 1;
            END LOOP;
            RETURN message;
        END;
        \$BODY\$
        LANGUAGE 'plpgsql';
"
    echo ${TEMPORARY_TBL}
}

function build_collect_sql {
    COLLECT_SQL="
        ${TEMPORARY_TBL}
        COPY (
            SELECT
                k.monitor_id,
                pg_temp.replace_message(k.item_name) AS item_name,
                k.display_name,
                TO_CHAR(TO_TIMESTAMP(d.time / 1000), 'YYYY-MM-DD HH24:MI:SS') AS date_time,
                k.facility_id,
                ${VALUE_COLUMNS}
            FROM
                log.cc_collect_key k
            INNER JOIN
                ${DATA_TBL} d
                ON k.collector_id = d.collector_id
            WHERE k.monitor_id = '${MONID}'
                  ${WHERE_CLAUSE}
            ORDER BY d.time, k.facility_id, k.item_name

        ) TO '${EXPORT_FILE}' WITH CSV HEADER
"
    echo ${COLLECT_SQL}
}

function build_collect_log_sql {
    COLLECT_LOG_SQL="
        ${TEMPORARY_TBL}
        COPY (
            SELECT
                TO_CHAR(TO_TIMESTAMP(d.time / 1000), 'YYYY-MM-DD HH24:MI:SS') AS date_time,
                k.facility_id,
                k.monitor_id,
                pg_temp.replace_message(d.value) AS value,
                d.value,
                t.tags
            FROM
                log.cc_collect_string_key k
                INNER JOIN log.cc_collect_data_string d
                    ON k.collect_id = d.collect_id
                LEFT JOIN (
                    SELECT
                        collect_id,
                        data_id,
                        string_agg(tag, ',') AS tags
                    FROM (
                            SELECT
                                collect_id,
                                data_id,
                                array_to_string(array[tag_key, tag_value], '=') AS tag
                            FROM log.cc_collect_data_tag
                        ) tmp
                        GROUP BY collect_id, data_id
                        ORDER BY collect_id, data_id
                    ) t
                    ON d.collect_id = t.collect_id
                        AND d.data_id = t.data_id
            WHERE k.monitor_id = '${MONID}'
                  ${WHERE_CLAUSE}
            ORDER BY d.time, k.facility_id, k.monitor_id, k.target_name, d.value
        ) TO '${EXPORT_FILE}' WITH CSV HEADER
"
    echo ${COLLECT_LOG_SQL}
}


## export event function
function check_arguments  {
    if [ "x$1" = "x" ]
    then
        ExitIllegalOptionErrorWithoutLogger
    fi
    if [ "$1" = -e ] || [ "$1" = -j ] || [ "$1" = -p ] || [ "$1" = -l ] || [ "$1" = -f ] || [ "$1" = -t ] || [ "$1" = -w ]
    then
        ExitIllegalOptionErrorWithoutLogger
    fi
}

function drop_temp_table {
    Logging "drop temporary table"
    
    SQL="DROP TABLE IF EXISTS log.temp_messages_map"
    MSG=`${PG_HOME}/bin/psql -U ${DB_USER} -p ${DB_PORT} -c "${SQL}"`
    RET=$?
    if [ ${RET} -ne 0 ]; then
        Logging "${MSG}"
        Logging "${MSG_E001} drop temporary table failed!"
        RET=$((16 + ${RET}))
        return ${RET}
    fi
}

########################################
# Main
########################################

# help chekc
if [ "$1" == "" ] || [ "$1" != --help ] && [ "$1" != -h ] && [ "$1" != -e ] && [ "$1" != -j ] && [ "$1" != -p ] && [ "$1" != -l ] && [ "$1" != -b ] && [ "$1" != -f ] && [ "$1" != -t ] && [ "$1" != -w ]
	then
		ExitIllegalOptionErrorWithoutLogger
		exit 0
	fi
for OPT in $@
do
    case $OPT in
         --help|-h)
            usage
            exit 0
            ;;
    esac
done


# option check
while [ -n "$1" ]
do
    case "$1" in
        -e)
            ARGS="${ARGS} e"
            ;;
        -j)
            ARGS="${ARGS} j"
            ;;
        -p)
            ARGS="${ARGS} p"
            shift 1
            check_arguments "$1"
            COLLECT_MODE="$1"
            ;;
        -l)
            ARGS="${ARGS} l"
            shift 1
            check_arguments "$1"
            COLLECT_MODE="$1"
            ;;
        -b)
            ARGS="${ARGS} b"
            shift 1
            check_arguments "$1"
            B_MONID="$1"
            if [ "x$2" = "x" ]
            then
                ExitIllegalOptionErrorWithoutLogger
            fi
            if [ "$2" != -e ] && [ "$2" != -j ] && [ "$2" != -p ] && [ "$2" != -l ] && [ "$2" != -f ] && [ "$2" != -t ] && [ "$2" != -w ]
            then
                if [ "x$3" != "x" ]
                then
                    shift 1
                    B_FID="$1"
                fi
            fi
            ;;
        -f)
            shift 1
            check_arguments "$1"
            FROM="$1"
            ;;
        -t)
            shift 1
            check_arguments "$1"
            TO="$1"
            ;;
        -w)
            shift 1
            check_arguments "$1"
            export PGPASSWORD="$1"
            ;;
        *)
            if [ "x${DUMP_PATH}" != "x" ]
            then
                ExitIllegalOptionErrorWithoutLogger
            fi
            DUMP_PATH="$1"
            ;;
    esac
    shift 1
done

# check process
CheckPostgreSQLProcessRunning


# main
AskPostgreSQLPasswd

for ARG in ${ARGS}
do
    case ${ARG} in
        e)
            export_event_all
            drop_temp_table
            RET=$?
            ;;
        j)
            export_job_histories
            RET=$?
            ;;
        p)
            export_collect_perform ${COLLECT_MODE}
            drop_temp_table
            RET=$?
            ;;
        l)
            export_collect_log ${COLLECT_MODE}
            drop_temp_table
            RET=$?
            ;;
        b)
            export_collect_binary
            RET=$?
            ;;
    esac
done

########################################
# Termination Processing
########################################

Logging "${MSG_I901}"

exit ${RET}
