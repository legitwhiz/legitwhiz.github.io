#!/bin/bash

# Copyright (c) 2018 NTT DATA INTELLILINK Corporation. All rights reserved.
#
# Hinemos (http://www.hinemos.info/)
#
# See the LICENSE file for licensing information.

# bash configuration
SCRIPT_DIR=$(cd $(dirname $0);pwd)
. ${SCRIPT_DIR}/../hinemos_web.cfg


export PROG=`basename $0`
DIR=`dirname $0`
USER=`/usr/bin/whoami`
HOST=`hostname`

cd ${HINEMOS_WEB_HOME}/var/log

########################################
#  Local Variable
########################################

# java version check
JAVA_CHECK_REGEX='version "1.8.0.*"'
OPENJDK_CHECK_REGEX=OpenJDK

########################################
#  Enviroment Variable
########################################

unset _JAVA_OPTIONS
export CATALINA_OUT=${HINEMOS_WEB_HOME}/var/log/catalina.out
export LOGGING_CONFIG="-Dlog4j.configuration=file://${TOMCAT_HOME}/lib/log4j.properties"

CATALINA_OPTS="${CATALINA_OPTS} -server -DHinemos_Web"
CATALINA_OPTS="${CATALINA_OPTS} -XX:CMSInitiatingOccupancyFraction=75 -XX:+UseCMSInitiatingOccupancyOnly"
CATALINA_OPTS="${CATALINA_OPTS} -XX:+UseConcMarkSweepGC -XX:+CMSParallelRemarkEnabled -XX:+UseParNewGC -XX:+DisableExplicitGC"
CATALINA_OPTS="${CATALINA_OPTS} -XX:SurvivorRatio=3 -XX:MaxTenuringThreshold=15 -XX:TargetSurvivorRatio=90"
CATALINA_OPTS="${CATALINA_OPTS} -Dorg.eclipse.rap.rwt.service.FileSettingStore.dir=${HINEMOS_WEB_HOME}/var/rap"
CATALINA_OPTS="${CATALINA_OPTS} ${JVM_HEAP_OPTS}"
CATALINA_OPTS="${CATALINA_OPTS} ${JVM_JCONSOLE_OPTS}"
CATALINA_OPTS="${CATALINA_OPTS} ${JVM_GCLOG_OPTS}"
CATALINA_OPTS="${CATALINA_OPTS} ${JVM_OOM_OPTS}"
CATALINA_OPTS="${CATALINA_OPTS} ${JVM_SSL_OPTS}"
CATALINA_OPTS="${CATALINA_OPTS} ${JVM_WIDGET_ID_OPTS}"
CATALINA_OPTS="${CATALINA_OPTS} ${JVM_MAX_USER_OPTS}"
CATALINA_OPTS="${CATALINA_OPTS} ${JVM_MAX_EVTCUSTOMCMD_OPTS}"
CATALINA_OPTS="${CATALINA_OPTS} ${JVM_SCOPE_NODECOUNT_OPTS}"
CATALINA_OPTS="${CATALINA_OPTS} -Djava.security.egd=file:/dev/./urandom"
CATALINA_OPTS="${CATALINA_OPTS} -Dhinemos.web.conf.dir=${HINEMOS_WEB_HOME}/conf"
export CATALINA_OPTS

########################################
#  Local Message
########################################

# INFO
MSG_I001="waiting for WebClient startup..."
MSG_I002="WebClient started."
MSG_I003="Please access http://[IP ADDRESS]:"

# WARN
MSG_W001="\
***************************************************************************\
\n\
*** Don't use this script! You should use \"service(systemctl)\" command. ***\
\n\
***************************************************************************"

# ERROR
MSG_E001="failed to start WebClient."
MSG_E002="This Java version is not supported."
MSG_E003="This Java is not supported."

########################################
# Function
########################################

# Logging
function Logging() {
	MODE=$2
	OPTS="-e"
	case ${MODE} in
		withline)
			EchoLine
			Logging "$1"
			EchoLine
			return 0
			;;
		noreturn)
			OPTS="${OPTS} -n"
			;;
		*)
			;;
	esac
	echo ${OPTS} "$1" >&2
	/usr/bin/logger "${PROG} $1"
}

function usage {
	echo "usage : ${PROG} [-F|-W]"
	echo "options:"
	echo "  -q   quiet start"
	echo "  -F   force immediate shutdown without process check (dependency, current status)"
	echo "  -W   do not wait until operation completes"
}

function startup {

	# check process
	if [ "x${FORCE}" != "xtrue" ]
	then
		if [ -f ${CATALINA_PID} ]
		then
			read PID < ${CATALINA_PID}
			if [ `ps --no-headers --pid ${PID} e | grep -- "-DHinemos_Web" | wc -l` -gt 0 ]
			then
				Logging "Hinemos WebClient is running..."
				exit 1
			fi
		fi
	fi

	# check java version
	if [ `${JAVA_HOME}/bin/java -version 2>&1 | grep "${JAVA_CHECK_REGEX}" | wc -l` -eq 0 ]
	then
		Logging "${MSG_E002}"
		${JAVA_HOME}/bin/java -version 2>&1
		exit -9
	fi
	if [ `${JAVA_HOME}/bin/java -version 2>&1 | grep "${OPENJDK_CHECK_REGEX}" | wc -l` -eq 0 ]
	then
		Logging "${MSG_E003}"
		${JAVA_HOME}/bin/java -version 2>&1
		exit -9
	fi

    # clear cache
    ${HINEMOS_WEB_HOME}/sbin/mng/hinemos_web_clear_tmp.sh

	rm -rf ${TOMCAT_HOME}/work/*
	rm -rf ${HINEMOS_WEB_LOG_DIR}/catalina_boot.log

	Logging "${MSG_I001}"
	${TOMCAT_HOME}/bin/catalina.sh start
	
	touch ${HINEMOS_LOCK_FILE}
	
	TIME_COUNT=0
	while [ 1 ]
	do
		if [ "x${STARTUP_WAIT}" = "xfalse" ]
		then
				Logging "${MSG_I002} (with -W option)"
				break
		fi
		
		if [ -f ${HINEMOS_WEB_LOG_DIR}/catalina_boot.log ]
		then
			if [ `grep -a 'Server startup in' ${HINEMOS_WEB_LOG_DIR}/catalina_boot.log | wc -l` -gt 0 ]
			then
				echo "done"
				TOMCAT_PORT=$(grep 'Starting ProtocolHandler' ${HINEMOS_WEB_LOG_DIR}/webclient.log | tail -1 | sed -e 's/.*http-nio-\([0-9]*\).*/\1/')
				Logging "${MSG_I002}"
				Logging "${MSG_I003}${TOMCAT_PORT}/"
				break
			fi
		fi
		
		if [ "${TIME_COUNT}" -ge ${STARTUP_CHECK_TIMEOUT} ]
		then
			Logging "${MSG_E001}"
			exit 1
		fi
	
		sleep ${STARTUP_CHECK_INTERVAL}
		TIME_COUNT=$((${TIME_COUNT} + ${STARTUP_CHECK_INTERVAL}))
		echo -n "."
	done
}

########################################
# SHELL
########################################

# check argument
for OPT in $@
do
	case ${OPT} in
		--help)
			usage
			exit 0
			;;
	esac
done

# option check
FORCE="false"
STARTUP_WAIT="true"
QUIET=0
while getopts qFW OPT
do
	case ${OPT} in
		q)
			QUIET=1
			;;
		F)
			FORCE="true"
			;;
		W)
			STARTUP_WAIT="false"
			;;
		*)
			ExitIllegalOptionErrorWithoutLogger
			;;
	esac
done

shift $(( $OPTIND - 1 ))

if [ ! $# = 0 ]
then
	ExitIllegalArgumentError
fi

if [ ${QUIET} -ne 1 ]
then
	Logging "${MSG_W001}"
fi

# startup tomcat
startup

exit $?
