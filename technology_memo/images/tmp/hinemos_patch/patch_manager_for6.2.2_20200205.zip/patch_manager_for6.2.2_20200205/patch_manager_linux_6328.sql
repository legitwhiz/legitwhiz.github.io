BEGIN;

-- setting.cc_collector_item_code_mst
INSERT INTO setting.cc_collector_item_code_mst VALUES ('MEM0100_MEM_UTIL_NETSNMP_BUG1250060_FIX', 'C001_MEM', NULL, '$[PERF_MEMORY_USAGE_NETSNMP_BUG1250060_FIX]', '%', FALSE, '', TRUE);
INSERT INTO setting.cc_collector_item_code_mst VALUES ('MEM0101_MEM_UTIL_SWAP_NETSNMP_BUG1250060_FIX', 'C001_MEM', 'MEM0100_MEM_UTIL_NETSNMP_BUG1250060_FIX', '$[PERF_MEMORY_USAGE_SWAP_NETSNMP_BUG1250060_FIX]', '%', FALSE, '', TRUE);
INSERT INTO setting.cc_collector_item_code_mst VALUES ('MEM0102_MEM_UTIL_PHYS_NETSNMP_BUG1250060_FIX', 'C001_MEM', 'MEM0100_MEM_UTIL_NETSNMP_BUG1250060_FIX', '$[PERF_MEMORY_USAGE_PHYSICAL_NETSNMP_BUG1250060_FIX]', '%', FALSE, '', TRUE);
INSERT INTO setting.cc_collector_item_code_mst VALUES ('MEM0300_PHYS_UTIL_NETSNMP_BUG1250060_FIX', 'C001_MEM', NULL, '$[PERF_PHYSICAL_MEMORY_USAGE_NETSNMP_BUG1250060_FIX]', '%', FALSE, '', TRUE);
INSERT INTO setting.cc_collector_item_code_mst VALUES ('MEM0301_PHYS_UTIL_USR_NETSNMP_BUG1250060_FIX', 'C001_MEM', 'MEM0300_PHYS_UTIL_NETSNMP_BUG1250060_FIX', '$[PERF_PHYSICAL_MEMORY_USAGE_USER_NETSNMP_BUG1250060_FIX]', '%', FALSE, '', TRUE);
INSERT INTO setting.cc_collector_item_code_mst VALUES ('MEM0302_PHYS_UTIL_BUF_NETSNMP_BUG1250060_FIX', 'C001_MEM', 'MEM0300_PHYS_UTIL_NETSNMP_BUG1250060_FIX', '$[PERF_PHYSICAL_MEMORY_USAGE_BUFFER_NETSNMP_BUG1250060_FIX]', '%', FALSE, '', TRUE);
INSERT INTO setting.cc_collector_item_code_mst VALUES ('MEM0303_PHYS_UTIL_CAC_NETSNMP_BUG1250060_FIX', 'C001_MEM', 'MEM0300_PHYS_UTIL_NETSNMP_BUG1250060_FIX', '$[PERF_PHYSICAL_MEMORY_USAGE_CACHED_NETSNMP_BUG1250060_FIX]', '%', FALSE, '', TRUE);

-- setting.cc_collector_polling_mst
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0100_MEM_UTIL_NETSNMP_BUG1250060_FIX', 'var0', '.1.3.6.1.4.1.2021.4.11.0', 'Integer32', '.1.3.6.1.4.1.2021.4.11', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0100_MEM_UTIL_NETSNMP_BUG1250060_FIX', 'var1', '.1.3.6.1.4.1.2021.4.14.0', 'Integer32', '.1.3.6.1.4.1.2021.4.14', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0100_MEM_UTIL_NETSNMP_BUG1250060_FIX', 'var2', '.1.3.6.1.4.1.2021.4.15.0', 'Integer32', '.1.3.6.1.4.1.2021.4.15', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0100_MEM_UTIL_NETSNMP_BUG1250060_FIX', 'var3', '.1.3.6.1.4.1.2021.4.3.0', 'Integer32', '.1.3.6.1.4.1.2021.4.3', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0100_MEM_UTIL_NETSNMP_BUG1250060_FIX', 'var4', '.1.3.6.1.4.1.2021.4.5.0', 'Integer32', '.1.3.6.1.4.1.2021.4.5', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0101_MEM_UTIL_SWAP_NETSNMP_BUG1250060_FIX', 'var0', '.1.3.6.1.4.1.2021.4.3.0', 'Integer32', '.1.3.6.1.4.1.2021.4.3', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0101_MEM_UTIL_SWAP_NETSNMP_BUG1250060_FIX', 'var1', '.1.3.6.1.4.1.2021.4.5.0', 'Integer32', '.1.3.6.1.4.1.2021.4.5', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0101_MEM_UTIL_SWAP_NETSNMP_BUG1250060_FIX', 'var2', '.1.3.6.1.4.1.2021.4.4.0', 'Integer32', '.1.3.6.1.4.1.2021.4.4', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0102_MEM_UTIL_PHYS_NETSNMP_BUG1250060_FIX', 'var0', '.1.3.6.1.4.1.2021.4.5.0', 'Integer32', '.1.3.6.1.4.1.2021.4.5', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0102_MEM_UTIL_PHYS_NETSNMP_BUG1250060_FIX', 'var1', '.1.3.6.1.4.1.2021.4.3.0', 'Integer32', '.1.3.6.1.4.1.2021.4.3', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0102_MEM_UTIL_PHYS_NETSNMP_BUG1250060_FIX', 'var2', '.1.3.6.1.4.1.2021.4.6.0', 'Integer32', '.1.3.6.1.4.1.2021.4.6', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0102_MEM_UTIL_PHYS_NETSNMP_BUG1250060_FIX', 'var3', '.1.3.6.1.4.1.2021.4.14.0', 'Integer32', '.1.3.6.1.4.1.2021.4.14', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0102_MEM_UTIL_PHYS_NETSNMP_BUG1250060_FIX', 'var4', '.1.3.6.1.4.1.2021.4.15.0', 'Integer32', '.1.3.6.1.4.1.2021.4.15', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0300_PHYS_UTIL_NETSNMP_BUG1250060_FIX', 'var0', '.1.3.6.1.4.1.2021.4.5.0', 'Integer32', '.1.3.6.1.4.1.2021.4.5', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0300_PHYS_UTIL_NETSNMP_BUG1250060_FIX', 'var1', '.1.3.6.1.4.1.2021.4.6.0', 'Integer32', '.1.3.6.1.4.1.2021.4.6', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0300_PHYS_UTIL_NETSNMP_BUG1250060_FIX', 'var2', '.1.3.6.1.4.1.2021.4.14.0', 'Integer32', '.1.3.6.1.4.1.2021.4.14', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0300_PHYS_UTIL_NETSNMP_BUG1250060_FIX', 'var3', '.1.3.6.1.4.1.2021.4.15.0', 'Integer32', '.1.3.6.1.4.1.2021.4.15', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0301_PHYS_UTIL_USR_NETSNMP_BUG1250060_FIX', 'var0', '.1.3.6.1.4.1.2021.4.6.0', 'Integer32', '.1.3.6.1.4.1.2021.4.6', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0301_PHYS_UTIL_USR_NETSNMP_BUG1250060_FIX', 'var1', '.1.3.6.1.4.1.2021.4.5.0', 'Integer32', '.1.3.6.1.4.1.2021.4.5', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0302_PHYS_UTIL_BUF_NETSNMP_BUG1250060_FIX', 'var0', '.1.3.6.1.4.1.2021.4.14.0', 'Integer32', '.1.3.6.1.4.1.2021.4.14', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0302_PHYS_UTIL_BUF_NETSNMP_BUG1250060_FIX', 'var1', '.1.3.6.1.4.1.2021.4.5.0', 'Integer32', '.1.3.6.1.4.1.2021.4.5', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0303_PHYS_UTIL_CAC_NETSNMP_BUG1250060_FIX', 'var0', '.1.3.6.1.4.1.2021.4.15.0', 'Integer32', '.1.3.6.1.4.1.2021.4.15', NULL);
INSERT INTO setting.cc_collector_polling_mst VALUES ('SNMP', 'LINUX', '', 'MEM0303_PHYS_UTIL_CAC_NETSNMP_BUG1250060_FIX', 'var1', '.1.3.6.1.4.1.2021.4.5.0', 'Integer32', '.1.3.6.1.4.1.2021.4.5', NULL);

-- setting.cc_collector_calc_method_mst
INSERT INTO setting.cc_collector_calc_method_mst VALUES ('100_sub_[R0_sub_R1_sub_R2]_div_[R3_add_R4]_mul_100', 'com.clustercontrol.performance.operator.RevercePorlishNotation', '100.0 var0 var1 - var2 - var3 var4 + / 100.0 * -');
INSERT INTO setting.cc_collector_calc_method_mst VALUES ('[R0_sub_R2_sub_R3_sub_R4]_div_[R0_add_R1]_mul_100', 'com.clustercontrol.performance.operator.RevercePorlishNotation', 'var0 var2 - var3 + var4 + var0 var1 + / 100.0 *');
INSERT INTO setting.cc_collector_calc_method_mst VALUES ('100_sub_[R1_sub_R2_sub_R3]_div_R0_mul_100', 'com.clustercontrol.performance.operator.RevercePorlishNotation', '100.0 var1 var2 - var3 - var0 / 100.0 * -');

-- setting.cc_collector_item_calc_method_mst
INSERT INTO setting.cc_collector_item_calc_method_mst VALUES ('SNMP', 'LINUX', '', 'MEM0100_MEM_UTIL_NETSNMP_BUG1250060_FIX', '100_sub_[R0_sub_R1_sub_R2]_div_[R3_add_R4]_mul_100');
INSERT INTO setting.cc_collector_item_calc_method_mst VALUES ('SNMP', 'LINUX', '', 'MEM0101_MEM_UTIL_SWAP_NETSNMP_BUG1250060_FIX', '[R0_sub_R2]_div_[R0_add_R1]_mul_100');
INSERT INTO setting.cc_collector_item_calc_method_mst VALUES ('SNMP', 'LINUX', '', 'MEM0102_MEM_UTIL_PHYS_NETSNMP_BUG1250060_FIX', '[R0_sub_R2_sub_R3_sub_R4]_div_[R0_add_R1]_mul_100');
INSERT INTO setting.cc_collector_item_calc_method_mst VALUES ('SNMP', 'LINUX', '', 'MEM0300_PHYS_UTIL_NETSNMP_BUG1250060_FIX', '100_sub_[R1_sub_R2_sub_R3]_div_R0_mul_100');
INSERT INTO setting.cc_collector_item_calc_method_mst VALUES ('SNMP', 'LINUX', '', 'MEM0301_PHYS_UTIL_USR_NETSNMP_BUG1250060_FIX', '100_sub_R0_div_R1_mul_100');
INSERT INTO setting.cc_collector_item_calc_method_mst VALUES ('SNMP', 'LINUX', '', 'MEM0302_PHYS_UTIL_BUF_NETSNMP_BUG1250060_FIX', 'R0_div_R1_mul_100');
INSERT INTO setting.cc_collector_item_calc_method_mst VALUES ('SNMP', 'LINUX', '', 'MEM0303_PHYS_UTIL_CAC_NETSNMP_BUG1250060_FIX', 'R0_div_R1_mul_100');

COMMIT;