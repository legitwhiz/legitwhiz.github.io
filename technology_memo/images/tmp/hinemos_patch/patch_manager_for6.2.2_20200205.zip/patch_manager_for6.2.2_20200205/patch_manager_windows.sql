use hinemos;
go

SET XACT_ABORT ON;

BEGIN TRANSACTION

INSERT INTO setting.cc_hinemos_property (property_key,value_string,value_numeric,value_boolean,value_type,description,owner_role_id,create_user_id,create_datetime,modify_user_id,modify_datetime)
SELECT 'multitenant.enable', null, null, 0, 3, 'Enables the multi-tenant control feature.', 'ADMINISTRATORS', 'hinemos', 1333206000000, 'hinemos', 1333206000000
WHERE NOT EXISTS (SELECT 1 FROM setting.cc_hinemos_property WHERE property_key = 'multitenant.enable');
go

INSERT INTO setting.cc_hinemos_property (property_key,value_string,value_numeric,value_boolean,value_type,description,owner_role_id,create_user_id,create_datetime,modify_user_id,modify_datetime)
SELECT 'multitenant.01.enable', null, null, 1, 3, 'Enables the tenant 01.', 'ADMINISTRATORS', 'hinemos', 1333206000000, 'hinemos', 1333206000000
WHERE NOT EXISTS (SELECT 1 FROM setting.cc_hinemos_property WHERE property_key = 'multitenant.01.enable');
go

INSERT INTO setting.cc_hinemos_property (property_key,value_string,value_numeric,value_boolean,value_type,description,owner_role_id,create_user_id,create_datetime,modify_user_id,modify_datetime)
SELECT 'multitenant.01.roles', 'ALL_USERS, INTERNAL', null, null, 1, 'The role IDs belonging with the tenant 01', 'ADMINISTRATORS', 'hinemos', 1333206000000, 'hinemos', 1333206000000
WHERE NOT EXISTS (SELECT 1 FROM setting.cc_hinemos_property WHERE property_key = 'multitenant.01.roles');
go

INSERT INTO setting.cc_hinemos_property (property_key,value_string,value_numeric,value_boolean,value_type,description,owner_role_id,create_user_id,create_datetime,modify_user_id,modify_datetime)
SELECT 'multitenant.01.addressgroup', '', null, null, 1, 'The subnets allowed for IP addresses of nodes', 'ADMINISTRATORS', 'hinemos', 1333206000000, 'hinemos', 1333206000000
WHERE NOT EXISTS (SELECT 1 FROM setting.cc_hinemos_property WHERE property_key = 'multitenant.01.addressgroup');
go

INSERT INTO setting.cc_hinemos_property (property_key,value_string,value_numeric,value_boolean,value_type,description,owner_role_id,create_user_id,create_datetime,modify_user_id,modify_datetime)
SELECT 'multitenant.01.nodesearch.facilityid.prefix', '', null, null, 1, 'The prefix for a facility ID registered by node-search', 'ADMINISTRATORS', 'hinemos', 1333206000000, 'hinemos', 1333206000000
WHERE NOT EXISTS (SELECT 1 FROM setting.cc_hinemos_property WHERE property_key = 'multitenant.01.nodesearch.facilityid.prefix');
go

INSERT INTO setting.cc_hinemos_property (property_key,value_string,value_numeric,value_boolean,value_type,description,owner_role_id,create_user_id,create_datetime,modify_user_id,modify_datetime)
SELECT 'multitenant.01.xcloud.snmp.community', '', null, null, 1, 'The SNMP community of a node registered by the cloud/VM option', 'ADMINISTRATORS', 'hinemos', 1333206000000, 'hinemos', 1333206000000
WHERE NOT EXISTS (SELECT 1 FROM setting.cc_hinemos_property WHERE property_key = 'multitenant.01.xcloud.snmp.community');
go

INSERT INTO setting.cc_hinemos_property (property_key,value_string,value_numeric,value_boolean,value_type,description,owner_role_id,create_user_id,create_datetime,modify_user_id,modify_datetime)
SELECT 'utility.expimp.xcloud.keyprotect.enable', null, null, 0, 3, 'Allow to empty cloud/VM secret keys when exporting/importing settings', 'ADMINISTRATORS', 'hinemos', 1333206000000, 'hinemos', 1333206000000
WHERE NOT EXISTS (SELECT 1 FROM setting.cc_hinemos_property WHERE property_key = 'utility.expimp.xcloud.keyprotect.enable');
go

COMMIT TRANSACTION;
go

return